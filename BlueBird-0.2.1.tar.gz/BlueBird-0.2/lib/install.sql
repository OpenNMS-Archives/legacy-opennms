CREATE FUNCTION iplike(text,text) RETURNS bool
	AS '/usr/lib/opennms/iplike.so'
	LANGUAGE 'c'
	WITH(isstrict);

CREATE FUNCTION eventtime(text) RETURNS float8
	AS '/usr/lib/opennms/eventtime.so'
	LANGUAGE 'c'
	WITH(isstrict);


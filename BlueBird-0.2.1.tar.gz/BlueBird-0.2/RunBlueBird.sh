#!/bin/sh

. run.sh

COMMAND="java -mx32m -classpath $CLASSPATH $PROPERTIES org.opennms.bb.eui.LoginFrame $@"
echo "$COMMAND"
echo ""

$COMMAND

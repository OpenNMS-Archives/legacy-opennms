#!/bin/sh

echo ------------------------------------------------------------------------------
echo 'Bluebird Command ($Id: run.sh,v 1.1 2000/11/12 04:22:18 ben Exp $)'
echo ------------------------------------------------------------------------------
echo

if [ -z "$JAVA_HOME" ]; then
  echo "ERROR: JAVA_HOME not found in your environment."
  echo ""
  echo "Please, set the JAVA_HOME environment variable to match the"
  echo "root directory of the Java Virtual Machine you want to use."
  echo ""
  exit;
fi

if [ -z "$BB_HOME" ]; then
  echo "ERROR: BB_HOME not found in your environment."
  echo ""
  echo "Please, set the BB_HOME environment variable to match the"
  echo "root directory where BlueBird is installed.  If you have"
  echo "built from source, you can set this to the full path to"
  echo "the BlueBird-X.X/ directory."
  echo ""
  exit;
fi

if [ -e "$JAVA_HOME/lib/tools.jar" ]; then
  CLASSPATH="$JAVA_HOME/lib/tools.jar"
else
  echo "ERROR: Either your JDK is too old, or I was unable to find"
  echo "lib/tools.jar in your JAVA_HOME directory.  Please make"
  echo "sure you have a Java2-compliant compiler and JVM.  JDK/JRE"
  echo "version earlier than 1.3 may work with BlueBird on some"
  echo "platforms, but are not supported."
fi

BLUEBIRD="$BB_HOME/bin/BlueBird-0.2.jar"
HELPVIEWER="$BB_HOME/bin/helpviewer-0.5.jar"
XERCES="$BB_HOME/bin/xerces.jar"
CUP="$BB_HOME/bin/JCup-ONMS.jar"
LEX="$BB_HOME/bin/JLex.jar"
POSTGRES="$BB_HOME/bin/postgresql.jar"

CLASSPATH="$CLASSPATH:$BLUEBIRD:$XERCES:$CUP:$LEX:$POSTGRES:$HELPVIEWER"
PATH="$JAVA_HOME/bin:$BB_HOME:$BB_HOME/bin:$PATH"

PROPERTIES="-Dorg.opennms.bluebird.dp.xml.directory=/data/common/conf -Dbb.home=$BB_HOME"

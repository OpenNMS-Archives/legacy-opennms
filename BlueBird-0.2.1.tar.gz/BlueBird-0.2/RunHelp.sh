#!/bin/sh

. run.sh

PROPERTIES="$PROPERTIES -Dhelpviewer.prefix=$BB_HOME/doc/html/adminref"
COMMAND="java -mx32m -classpath $CLASSPATH $PROPERTIES HelpFrame $@"

echo "$COMMAND"
echo ""

$COMMAND

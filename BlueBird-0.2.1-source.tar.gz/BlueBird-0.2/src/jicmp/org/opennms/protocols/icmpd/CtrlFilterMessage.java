//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
// $Id: CtrlFilterMessage.java,v 1.6 2000/04/17 22:01:30 weave Exp $
//
//
package org.opennms.protocols.icmpd;

import java.lang.*;
import java.util.*;
import java.io.*;

import org.opennms.protocols.icmpd.MessageHeader;

/**
 * Defines the control filter message for filtering received icmp
 * messages from a remote host. The format of the message is as follows:
 *
 * <PRE>
 *
 * +--------+--------+----------------+
 * |  TYPE  |  CODE  |   SEQUENCE     |
 * +--------+--------+--------+-------+
 * |     LENGTH      |FILTERON| ACTION|
 * +-----------------+--------+-------+
 * |           PACKET OFFSET          |
 * +----------------------------------+
 * |           FILTER LENGTH          |
 * +----------------------------------+
 * |            FILTER DATA           |
 * |                                  |
 * +----------------------------------+
 *
 * </PRE>
 *
 * @author	Brian Weaver <weave@opennms.org>
 * @version	0.1
 *
 */
public final class CtrlFilterMessage extends MessageHeader
{
	/**
	 * The type for the class.
	 */
	public static final byte TYPE	= (byte)1;

	/**
	 * The code for the class.
	 */
	public static final byte CODE	= (byte)3;

	/**
	 * Filter on the IP Header.
	 */
	public static final byte FILTER_ON_IPHEADER	= (byte)1;

	/**
	 * Filter on the ICMP message.
	 */
	public static final byte FILTER_ON_ICMP		= (byte)2;

	/**
	 * If the filter matches discard the datagram.
	 */
	public static final byte ACTION_DISCARD		= (byte)1;

	/**
	 * If the filter matches return the datagram.
	 */
	public static final byte ACTION_PASS		= (byte)0;

	/**
	 * The offset into the icmp or ip header packet.
	 */
	private int	m_packetOffset;
	/**
	 * The actual filter data.
	 */
	private byte[]	m_filterData;
	/**
	 * The valid length of the filter data
	 */
	private int	m_filterLen;

	private void calculateLength()
	{
		super.m_length = (short)(8  + 8  + (m_filterData != null ? m_filterData.length : 0));
	}

	/**
	 * Creates a new control filter message for sending to
	 * the icmp daemon. The values in the object are set to
	 * the default value. The offset is set to zero and the
	 * data field to null. By default the filter is set to
	 * icmp and action is pass.
	 *
	 */
	public CtrlFilterMessage( )
	{
		super.m_type	= TYPE;
		super.m_code	= CODE;
		super.m_sequence= MessageHeader.nextSequenceId();
		super.m_length	= (short)0;
		super.m_reserved= MessageHeader.makeShort(FILTER_ON_ICMP, ACTION_PASS);

		m_packetOffset = 0;
		m_filterData   = null;
		m_filterLen    = 0;

		calculateLength();
	}

	/**
	 * Creates a new control filter message based on the 
	 * message header and the input stream. If the stream
	 * encounters an error or there is insufficent data then
	 * an IOException is thrown. If the header is not valid
	 * then an IllegalArgumentException is thrown.
	 *
	 * @param hdr		The message header.
	 * @param istream	The input stream containing the reamining data.
	 *
	 * @exception IOException Thrown if an error occurs with the input stream
	 * @exception IllegalArgumentException Thrown if the header is not valid.
	 *
	 */
	CtrlFilterMessage(MessageHeader hdr, InputStream istream)
		throws IOException
	{
		super(hdr);
		if(hdr.m_type != TYPE || hdr.m_code != CODE)
			throw new IllegalArgumentException("Invalid type/code in header");


		//
		// set the fields to zero initially
		//
		m_packetOffset	= 0;
		m_filterLen	= 0;
		m_filterData	= null;

		//
		// Find out how many bytes remain in the channel
		//
		int remain = super.m_length - 8;
		byte[] buf = new byte[remain];
		int rc     = istream.read(buf);
		if(rc != remain)
		{
			throw new IOException("Insufficent data returned from server");
		}

		//
		// Decode the data
		//
		m_packetOffset = MessageHeader.makeInt(buf[0], buf[1], buf[2], buf[3]);
		m_filterLen    = MessageHeader.makeInt(buf[4], buf[5], buf[6], buf[7]);

		//
		// Now copy out the filter data
		//
		m_filterData   = new byte[align4(m_filterLen)];
		int x;
		for(x = 0; x < m_filterLen; x++)
		{
			m_filterData[x] = buf[x+8];
		}

		//
		// pad the data
		//
		for(; x < m_filterData.length; x++)
		{
			m_filterData[x] = (byte)0;
		}

		calculateLength();
	}

	/**
	 * Creates a new control filter message based 
	 * on the passed parameters.
	 *
	 * @param filterOn	Filter on IP header or ICMP data.
	 * @param action	Pass or Discard matched packets.
	 * @param offset	The offset into the packet.
	 * @param data		The filter data.
	 *
	 */
	public CtrlFilterMessage( byte	filterOn, 
				  byte	action, 
				  int	offset, 
				  byte[] data )
	{
		this();
		setFilter(offset, data);
		m_reserved = MessageHeader.makeShort(filterOn, action);
	}

	/**
	 * Returns true if the filter is set to check IP headers
	 */
	public boolean isIPFilter( )
	{
		return ((m_reserved >>> 8) == FILTER_ON_IPHEADER);
	}
	
	/**
	 * Returns true fi the filter is set to check ICMP messages.
	 */
	public boolean isICMPFilter( )
	{
		return ((m_reserved >>> 8) == FILTER_ON_ICMP);
	}
	
	/**
	 * Sets teh filter field of the object. The filterOn
	 * parameter should be either FILTER_ON_IPHEADER ||
	 * FILTER_ON_ICMP.
	 *
	 * @param filterOn The part of the received message to
	 *	perform filtering on.
	 *
	 */
	public void setFilterOn(byte filterOn)
	{
		m_reserved &= 0xff;
		m_reserved |= (short)((short)filterOn << 8);
	}

	/**
	 * Sets the encapsulated filter data. When the method
	 * is called the passed data is copied so that any
	 * changes after the call to the data parameter will
	 * not affect the object.
	 *
	 * @param offset	The offset into the packet.
	 * @param data		The comparison data.
	 *
	 */
	public void setFilter(int offset, byte[] data)
	{
		//
		// set the offset and get a new buffer
		// for the filter data. The buffer length
		// must follow the rule ((sz % 4) == 0)
		//
		m_packetOffset = offset;
		m_filterLen    = data.length;
		m_filterData   = new byte[align4(data.length)];

		//
		// copy in the first part of the data
		//
		int x;
		for(x = 0; x < data.length; x++)
			m_filterData[x] = data[x];
		
		//
		// pad the filler elements
		//
		for(; x < m_filterData.length; x++)
			m_filterData[x] = (byte)0;


		calculateLength();
	}

	/**
	 * Returns the encapsulated filter data. The length of
	 * the data will alsways be an integral multiple of 4
	 * (i.e. (length % 4) == 0). The actual number of valid
	 * bytes can be determined with a call to getFilterLength()
	 * method.
	 *
	 * @return The array of bytes containing the filter data
	 *
	 * @see #getFilterLength
	 */
	public byte[] getFilter()
	{
		return m_filterData;
	}

	/**
	 * Returns the number of valid bytes of filter data
	 */
	public int getFilterLength()
	{
		return m_filterLen;
	}

	/**
	 * Returns the starting offset for the filter when
	 * comparing it against retreived icmp messages or
	 * received ip headers.
	 *
	 * @return the 32-bit offset.
	 */
	public int getOffset( )
	{
		return m_packetOffset;
	}

	/**
	 * Returns true if the filter is marked for discarding
	 * matched packets.
	 *
	 */
	public boolean isDiscardAction( )
	{
		return (m_reserved & 0xff) == ACTION_DISCARD;
	}
	
	/**
	 * Returns true if the filter is marked for sending
	 * matched packets.
	 *
	 */
	public boolean isPassAction( )
	{
		return (m_reserved & 0xff) == ACTION_PASS;
	}

	/**
	 * Sets the action for the filter object. The action
	 * should be on of the two values: ACTION_PASS || 
	 * ACTION_DISCARD.
	 *
	 * @param byte The action to be performed by the filter.
	 */
	public void setAction(byte action)
	{
		m_reserved &= 0xff00;
		m_reserved |= (short)action;
	}

	/**
	 * Seralizes the object to the icmp daemon using
	 * the passed connection stream.
	 *
	 * @param ostream The connection sink.
	 *
	 * @exception IOException Thrown if an I/O error occurs.
	 */
	void write(OutputStream ostream) throws IOException
	{
		byte[] buf = new byte[getLength() - 8];

		//
		// load in the data
		//
		int ndx = 0;
		buf[ndx++] = (byte)((m_packetOffset >> 24) & 0xff);
		buf[ndx++] = (byte)((m_packetOffset >> 16) & 0xff);
		buf[ndx++] = (byte)((m_packetOffset >>  8) & 0xff);
		buf[ndx++] = (byte)(m_packetOffset & 0xff);

		buf[ndx++] = (byte)((m_filterLen >> 24) & 0xff);
		buf[ndx++] = (byte)((m_filterLen >> 16) & 0xff);
		buf[ndx++] = (byte)((m_filterLen >>  8) & 0xff);
		buf[ndx++] = (byte)(m_filterLen & 0xff);

		for(int x = 0; x < m_filterData.length; x++)
		{
			buf[ndx++] = m_filterData[x];
		}

		//
		// write the data
		//
		super.write(ostream);		
		ostream.write(buf);
	}
}
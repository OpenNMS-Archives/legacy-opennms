//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
// $Id: MessageHeader.java,v 1.5 2000/04/17 22:01:32 weave Exp $
//
//
package org.opennms.protocols.icmpd;

import java.lang.*;
import java.util.*;
import java.io.*;

/**
 * The base message class for communications with the icmp daemon.
 * The basic message begins with an eight byte header. The header 
 * consist of a type, code, sequence number, length, and reserved field
 *
 * <PRE>
 * +--------+--------+----------------+
 * | Type   |  Code  |   Sequence #   |
 * +--------+--------+----------------+
 * |    Length       |   Reserved     |
 * +-----------------+----------------+
 * </PRE>
 *
 */
public class MessageHeader extends java.lang.Object
{
	/**
	 * The class type
	 */
	protected byte	m_type;
	/**
	 * The class code
	 */
	protected byte	m_code;
	/**
	 * The class sequence
	 */
	protected short	m_sequence;
	/**
	 * The total length of the message.
	 */
	protected short	m_length;
	/**
	 * Reserved for use by different messages.
	 */
	protected short	m_reserved;

	private static short sm_seq = 0;

	public static final byte	TYPE_CONTROL	= 1;
	public static final byte	TYPE_DATA	= 2;

	/**
	 * Returns the next sequence identitifer
	 * for the class.
	 *
	 * @return The next unique sequence identifier.
	 *
	 */
	public static synchronized short nextSequenceId( )
	{
		if(sm_seq == 0)
		{
			Date d = new Date();
			Random r = new Random(d.getTime());
			sm_seq = (short)(r.nextInt());
		}
		return ++sm_seq;
	}

	/**
	 * Aligns the number by making sure the number
	 * is divisable by four. If the number is not
	 * divisiable by four then the number is rouned
	 * up to the next boundry number.
	 *
	 * @param sz The number to align
	 *
	 * @return The aligned value
	 *
	 */
	public static int align4(int sz)
	{
		if((sz % 4) != 0)
		{
			int remain = sz % 4;
			sz += (4 - remain);
		}
		return sz;
	}

	/**
	 * Converts two eight bit bytes to a sixteen bit
	 * short. The first byte becomes the high order
	 * byte and the second byte becomes the lower order
	 * byte.
	 *
	 * @param a	The high order byte.
	 * @param b	The lo order byte.
	 *
	 * @return The converted 16-bit number.
	 *
	 */
	public static short makeShort(byte a, byte b)
	{
		short sa = (short)a;
		short sb = (short)b;
		if(sa < 0) sa += 256;
		if(sb < 0) sb += 256;

		return (short)(sa << 8 | sb);
	}

	/**
	 * Converts the four passed bytes into a single 32-bit
	 * value. The bytes are converted with the first parameter
	 * becomming the hi order byte and the last parameter
	 * becoming the lo order byte.
	 *
	 * @param a	The high order byte, bit position 31-24
	 * @param b	Bit positions 23-16.
	 * @param c	Bit positions 15-8.
	 * @param d	The lo order byte, bit position 7-0.
	 *
	 * @return The built 32-bit value.
	 *
	 */
	public static int makeInt(byte a, byte b, byte c, byte d)
	{
		int ia = (int)a;
		int ib = (int)b;
		int ic = (int)c;
		int id = (int)d;

		if(ia < 0) ia += 256;
		if(ib < 0) ib += 256;
		if(ic < 0) ic += 256;
		if(id < 0) id += 256;

		return (ia << 24 | ib << 16 | ic << 8 | id);
	}

	/**
	 * Creates a default message header
	 */
	MessageHeader( )
	{
		m_type		= (byte)0;
		m_code		= (byte)0;
		m_sequence	= (short)0;
		m_length	= (short)0;
		m_reserved	= (short)0;
	}

	/**
	 * Creates a duplicate of the passed header.
	 *
	 * @param hdr The header object to duplicate.
	 *
	 */
	MessageHeader(MessageHeader hdr)
	{
		m_type		= hdr.m_type;
		m_code		= hdr.m_code;
		m_sequence	= hdr.m_sequence;
		m_length	= hdr.m_length;
		m_reserved	= hdr.m_reserved;
	}

	/**
	 * Write the header to the output stream, effectively
	 * seralizing the object for the icmp daemon.
	 *
	 * @param ostream	The output stream
	 *
	 * @exception IOException Thrown if an error occurs with ostream.
	 *
	 */
	void write(OutputStream ostream) throws IOException
	{
		byte[] buf = new byte[8];
		
		buf[0] = m_type;
		buf[1] = m_code;
		buf[2] = (byte)(m_sequence >>> 8);
		buf[3] = (byte)(m_sequence & 0xff);
		buf[4] = (byte)(m_length >>> 8);
		buf[5] = (byte)(m_length & 0xff);
		buf[6] = (byte)(m_reserved >>> 8);
		buf[7] = (byte)(m_reserved & 0xff);
		
		ostream.write(buf);
	}


	/**
	 * Reads in the first 8 bytes of the message. This
	 * is then converted to the member fields of the
	 * object. If an error occurs then an excetpion is
	 * thown.
	 *
	 * @param istream The input stream contain the "seralized" object.
	 *
	 * @exception IOException Thrown if an error occurs with ostream.
	 *
	 */
	void read(InputStream istream) throws IOException
	{
		byte[] buf = new byte[8];

		int rc = istream.read(buf);
		if(rc != 8)
			throw new IOException("Insufficent bytes sent by daemon");

		m_type		= buf[0];
		m_code		= buf[1];
		m_sequence	= makeShort(buf[2], buf[3]);
		m_length	= makeShort(buf[4], buf[5]);
		m_reserved	= makeShort(buf[6], buf[7]);
	}

	/**
	 * Returns the type for the object.
	 */
	public byte getType()
	{
		return m_type;
	}

	/**
	 * Returns the code for the object.
	 */
	public byte getCode()
	{
		return m_code;
	}

	/**
	 * Returns the current sequence of the object.
	 */
	public short getSequence()
	{
		return m_sequence;
	}

	/**
	 * sets the current sequence of the object
	 */
	public short setSequence(short seq)
	{
		return (m_sequence = seq);
	}

	/**
	 * returns the current length of the entire message.
	 * This would be the number of bytes seralized to the
	 * icmp daemon if a message were sent.
	 *
	 */
	public int getLength()
	{
		int l = (int)m_length;
		if(l < 0)
			l += 0x10000;

		return l;
	}
}
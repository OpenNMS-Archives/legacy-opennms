//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
// $Id: DataRecvMessage.java,v 1.4 2000/04/17 22:01:31 weave Exp $
//
//
package org.opennms.protocols.icmpd;

import java.lang.*;
import java.util.*;
import java.io.*;
import java.net.*;

import org.opennms.protocols.icmpd.MessageHeader;

/**
 * The message class for receiving ICMP infomation from the icmp daemon.
 * The basic message begins with an eight byte header. The header 
 * consist of a type, code, sequence number, length, and reserved field.
 * The remain fields are specific to the received message.
 *
 * <PRE>
 * +--------+--------+----------------+
 * | Type   |  Code  |     Sequence # |
 * +--------+--------+----------------+
 * |    Length       |   IP Hdr Len   |
 * +-----------------+----------------+
 * |             IP HEADER            |
 * |                                  |
 * +----------------------------------+
 * |        ICMP MESSAGE LENGTH       |
 * +----------------------------------+
 * |           ICMP DATA              |
 * |                                  |
 * +----------------------------------+
 * </PRE>
 *
 */public final class DataRecvMessage extends MessageHeader
{
	//
	// Address Length is 16-bit reserved short
	//
	private byte[]		m_ipHeader;
	private byte[]		m_icmp;
	private int		m_icmpLen;

	/**
	 * The class type.
	 */
	public static final byte TYPE	= (byte)2;
	/**
	 * The class code
	 */
	public static final byte CODE	= (byte)1;

	/**
	 * Constructs a default message with a
	 * blank IP header and no data.
	 *
	 */
	public DataRecvMessage( )
	{
		super.m_type	= TYPE;
		super.m_code	= CODE;
		super.m_sequence= MessageHeader.nextSequenceId();
		super.m_length	= (short)0;
		super.m_reserved= (short)0;

		super.m_reserved = (short)20;
		m_ipHeader = new byte[20];
		for(int x = 0; x < 20; x++)
			m_ipHeader[x] = (byte)0;

		m_icmpLen = 0;
		m_icmp    = null;

		calculateLength();
	}

	/**
	 * Constructs a new data recevied object with
	 * the specified header and reads the remaining
	 * information from the input stream.
	 *
	 * @param hdr	The header to use in this message
	 * @param istream The input stream to get the rest of data.
	 *
	 * @exception IOException Thrown if an error occurs reading from
	 *	the stream.
	 * @exception IllegalArgumentException Thrown if the type or code
	 *	in the passed header are not correct.
	 *
	 */
	DataRecvMessage(MessageHeader hdr, InputStream istream) throws IOException
	{
		super(hdr);
		if(hdr.m_code != CODE || hdr.m_type != TYPE)
			throw new IllegalArgumentException("The type/code for the object is not correct");


		byte[] buf = new byte[getLength() - 8];
		int rc     = istream.read(buf);
		if(rc != buf.length)
			throw new IOException("Insufficent data returned from server");

		//
		// get the address data first
		//
		m_ipHeader = new byte[align4(super.m_reserved)];

		int ndx = 0;
		for(int x = 0; x < m_ipHeader.length; x++)
			m_ipHeader[x] = buf[ndx++];

		//
		// get the integer packet length next
		//
		m_icmpLen = MessageHeader.makeInt(buf[ndx++],
						  buf[ndx++],
						  buf[ndx++],
						  buf[ndx++]);

		//
		// now get the rest of the data
		//
		if(m_icmpLen == 0)
		{
			m_icmp = null;
		}
		else
		{
			m_icmp = new byte[align4(m_icmpLen)];
			for(int x = 0; x < m_icmp.length; x++)
				m_icmp[x] = buf[ndx++];
		}

		calculateLength();

	}

	/**
	 * Constructs a new received message with the specified
	 * header and icmp data.
	 *
	 * @param header	The IP header data
	 * @param icmp		The ICMP data
	 *
	 */
	public DataRecvMessage(byte[] header, byte[] icmp)
	{
		this();
		
		//
		// create and copy the header data
		//
		m_ipHeader = new byte[align4(header.length)];
		for(int x = 0; x < header.length; x++)
			m_ipHeader[x] = header[x];

		for(int x = align4(header.length)-1; x >= header.length; --x)
			m_ipHeader[x] = (byte)0;

		super.m_reserved = (short)m_ipHeader.length;
		
		//
		// create and copy the icmp data
		//
		if(icmp != null)
		{
			m_icmpLen = icmp.length;
			m_icmp = new byte[align4(icmp.length)];
			for(int x = 0; x < icmp.length; x++)
				m_icmp[x] = icmp[x];

			for(int x = align4(icmp.length)-1; x >= icmp.length; --x)
				m_icmp[x] = (byte)0;
		}
		else
		{
			m_icmp = null;
			m_icmpLen = 0;
		}

		calculateLength();
	}

	/**
	 * Returns the true length of the IP header
	 *
	 */
	public int getIPHeaderLength()
	{
		return (int)(super.m_reserved);
	}

	/**
	 * Returns the array of information that is the
	 * IP header. The buffer is aligned to be a multiple
	 * of four. The true length of valid data is returned
	 * via a call to getIPHeaderLength()
	 *
	 * @return The IP Header bytes
	 *
	 * @see #getIPHeaderLength
	 *
	 */
	public byte[] getIPHeader()
	{
		return m_ipHeader;
	}

	/**
	 * Sets the IP Header data. The length
	 * is set to the length of the passed array.
	 *
	 * @param buf The IP Header data.
	 *
	 */
	public void setIPHeader(byte[] buf)
	{
		if(buf == null)
		{
			m_ipHeader = new byte[20];
			for(int x = 0; x < 20; x++)
				m_ipHeader[x] = (byte)0;
			super.m_reserved = (short)20;
		}
		else
		{
			super.m_reserved = (short)buf.length;
			m_ipHeader = new byte[align4(buf.length)];

			for(int x = 0; x < buf.length; x++)
				m_ipHeader[x] = buf[x];

			for(int x = align4(buf.length)-1; x >= buf.length; --x)
				m_ipHeader[x] = (byte)0;
		}

		calculateLength();
	}

	/**
	 * Returns the length of valid data in
	 * the ICMP byte array.
	 *
	 * @see #getICMPData
	 *
	 */
	public int getICMPLength( )
	{
		return m_icmpLen;
	}

	/**
	 * Returns the array of bytes that is 
	 * the ICMP message. The array size is
	 * a multiple of 4 and the length of valid
	 * data is available via a call to getICMPLength()
	 *
	 * @return The ICMP message
	 *
	 * @see #getICMPLength
	 *
	 */
	public byte[] getICMPData()
	{
		return m_icmp;
	}

	/**
	 * Sets the current ICMP data encapsulated
	 * within the object equal to the passed data.
	 * The length is set to the length of the byte
	 * array.
	 *
	 * @param buf The icmp message.
	 *
	 */
	public void setICMPData(byte[] buf)
	{
		if(buf == null)
		{
			m_icmp = null;
			m_icmpLen = 0;
		}
		else
		{
			m_icmpLen = buf.length;
			m_icmp = new byte[align4(buf.length)];

			for(int x = 0; x < buf.length; x++)
				m_icmp[x] = buf[x];

			for(int x = align4(buf.length)-1; x >= buf.length; --x)
				m_icmp[x] = (byte)0;
		}

		calculateLength();
	}

	/**
	 * calcuates the length of the packet based
	 * on the encapsulate data.
	 *
	 */
	private void calculateLength()
	{
		super.m_length = (short)(8 + 
					 4 + 
					 ((m_icmp != null) ? m_icmp.length : 0) + 
					 ((m_ipHeader != null) ? m_ipHeader.length : 0));
	}

	/**
	 * Writes the object to the output stream in a format
	 * that can be read by the ICMP daemon.
	 *
	 * @param ostream The output stream
	 *
	 * @exception IOException Thrown if an error occurs with the 
	 *	output stream.
	 *
	 */
	void write(OutputStream ostream) throws IOException
	{
		byte[] buf = new byte[getLength() - 8];

		//
		// write the address data first
		//
		int ndx = 0;
		for(int x = 0; x < m_ipHeader.length; x++)
			buf[ndx++] = m_ipHeader[x];

		//
		// write the length next
		//
		buf[ndx++] = (byte)((m_icmpLen >> 24) & 0xff);
		buf[ndx++] = (byte)((m_icmpLen >> 16) & 0xff);
		buf[ndx++] = (byte)((m_icmpLen >>  8) & 0xff);
		buf[ndx++] = (byte)(m_icmpLen & 0xff);

		//
		// write the data next
		//
		if(m_icmp != null)
		{
			for(int x = 0; x < m_icmp.length; x++)
				buf[ndx++] = m_icmp[x];
		}

		super.write(ostream);
		ostream.write(buf);
	}
}
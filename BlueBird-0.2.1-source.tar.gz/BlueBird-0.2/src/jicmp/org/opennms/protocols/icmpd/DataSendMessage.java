//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
// $Id: DataSendMessage.java,v 1.4 2000/04/17 22:01:31 weave Exp $
//
//
package org.opennms.protocols.icmpd;

import java.lang.*;
import java.util.*;
import java.io.*;
import java.net.*;

import org.opennms.protocols.icmpd.MessageHeader;

/**
 * Defines the data send message for the transmission of an icmp
 * message to a remote host. The icmp message is treated as an array
 * of bytes and should be placed onto the wire raw by the daemon.
 * The format of the message is as follows:
 *
 * <PRE>
 * +--------+--------+----------------+
 * |  TYPE  |  CODE  |   SEQUENCE     |
 * +--------+--------+----------------+
 * |     LENGTH      |   ADDR LEN     |
 * +-----------------+----------------+
 * |            ADDRESS DATA          |
 * |                                  |
 * +----------------------------------+
 * |            DATA LENGTH           |
 * +----------------------------------+
 * |            ICMP DATA             |
 * |                                  |
 * +----------------------------------+
 * </PRE>
 *
 * @author	Brian Weaver <weave@opennms.org>
 * @version	0.1
 *
 */
public final class DataSendMessage extends MessageHeader
{
	//
	// Address Length is 16-bit reserved short
	//
	private byte[]		m_addrData;
	private byte[]		m_data;
	private int		m_dataLen;

	/**
	 * The type for the message
	 */
	public static final byte TYPE	= (byte)2;

	/**
	 * The code for the message
	 */
	public static final byte CODE	= (byte)0;

	/**
	 * Class constructor. Constructs a new object with
	 * the default information. When the object is
	 * constructed the next sequence number in the class
	 * is assigned to the object.
	 *
	 * By default the address is set to the IPv4 address "0.0.0.0".
	 *
	 */
	public DataSendMessage( )
	{
		super.m_type	= TYPE;
		super.m_code	= CODE;
		super.m_sequence= MessageHeader.nextSequenceId();
		super.m_length	= (short)0;
		super.m_reserved= (short)0;

		super.m_reserved = 4;
		m_addrData = new byte[4];
		for(int x = 0; x < 4; x++)
			m_addrData[x] = (byte)0;

		m_dataLen = 0;
		m_data = null;

		calculateLength();
	}

	/**
	 * Constructs a new object with the passed header and reads
	 * the remaining information from the passed input stream. The
	 * header argument contains the first eight bytes of data for the
	 * class. The remaining data must be pulled from the input stream.
	 *
	 * If there is not enough data in the stream, or an error occurs with
	 * the stream, an IOException is thrown. Should the header have an invalid
	 * type or code then an IllegalArgumentException is thrown by the
	 * constructor.
	 *
	 * @param hdr	The header object to copy into self.
	 * @param istream The stream containing the remaining data for the object.
	 *
	 * @exception IOException Thrown if an error occurs with the input stream
	 *	or there is insufficent data returned from the stream.
	 * @exception IllegalArgumentException Thrown if the header's type and
	 *	code fields are not valid for the object.
	 *
	 */
	DataSendMessage(MessageHeader hdr, InputStream istream) throws IOException
	{
		//
		// initialize the first eight bytes
		//
		super(hdr);
		if(hdr.m_type != TYPE || hdr.m_code != CODE)
			throw new IllegalArgumentException("Illegal type/code field in the header, not a DataSendMessage object");


		//
		// get the remaining bytes
		//
		byte[] buf = new byte[getLength() - 8];
		int rc     = istream.read(buf);
		if(rc != buf.length)
			throw new IOException("Insufficent data returned from server");

		//
		// get the address data first
		//
		m_addrData = new byte[align4(super.m_reserved)];

		int ndx = 0;
		for(int x = 0; x < m_addrData.length; x++)
			m_addrData[x] = buf[ndx++];

		//
		// get the integer packet length next
		//
		m_dataLen = MessageHeader.makeInt(buf[ndx++],
						  buf[ndx++],
						  buf[ndx++],
						  buf[ndx++]);

		//
		// now get the rest of the data
		//
		if(m_dataLen == 0)
		{
			m_data = null;
		}
		else
		{
			m_data = new byte[align4(m_dataLen)];
			for(int x = 0; x < m_data.length; x++)
				m_data[x] = buf[ndx++];
		}

		calculateLength();

	}

	/**
	 * Constructs a new DataSendMessage object with the specified
	 * IP address and ICMP data. 
	 *
	 */
	public DataSendMessage(InetAddress addr, byte[] icmp)
	{
		this();

		byte[] saddr = addr.getAddress();
		super.m_reserved = (short)m_addrData.length;

		//
		// copy in the address data
		//
		m_addrData = new byte[align4(saddr.length)];
		for(int x = 0; x < saddr.length; x++)
			m_addrData[x] = saddr[x];

		for(int x = align4(saddr.length)-1; x >= saddr.length; --x)
			m_addrData[x] = (byte)0;

		//
		// copy the icmp data into the object
		//
		m_dataLen = icmp.length;
		m_data = new byte[align4(icmp.length)];
		for(int x = 0; x < icmp.length; x++)
			m_data[x] = icmp[x];

		for(int x = align4(icmp.length) - 1; x >= icmp.length; --x)
			m_data[x] = (byte)0;

		calculateLength();
	}

	/**
	 * Returns the length of the IP address information.
	 * The address length is limited to 32767 bytes in length.
	 *
	 * @return The length of the address data.
	 *
	 */
	public int getAddressLength()
	{
		return (int)(super.m_reserved);
	}

	/**
	 * Returns the byte array that contains the address data
	 * for the object. The length of the buffer will always
	 * be an integral multiple of 4 (i.e. 0, 4, 8, 12, ...). 
	 * To find out exactly how many of the bytes are valid the
	 * application should call the getAddressLength() method.
	 *
	 * @return The address data array.
	 *
	 * @see #getAddressLength
	 *
	 */
	public byte[] getAddress()
	{
		return m_addrData;
	}

	/**
	 * Used to set the address data contained by the message
	 * object. The address data is copied into the object and
	 * the valid length is set to the length of the passed
	 * array. 
	 *
	 * @param buf	The address data.
	 *
	 */
	public void setAddress(byte[] buf)
	{
		if(buf == null)
		{
			m_addrData = new byte[4];
			for(int x = 0; x < 4; x++)
				m_addrData[x] = (byte)0;
			super.m_reserved = (short)4;
		}
		else
		{
			super.m_reserved = (short)buf.length;
			m_addrData = new byte[align4(buf.length)];
			for(int x = 0; x < buf.length; x++)
				m_addrData[x] = buf[x];

			for(int x = align4(buf.length)-1; x >= buf.length; --x)
				m_addrData[x] = (byte)0;
		}

		calculateLength();
	}

	/**
	 * Sets the address for the object.
	 *
	 * @param addr The new address for the message.
	 *
	 */
	public void setAddress(InetAddress addr)
	{
		setAddress(addr.getAddress());
	}

	/**
	 * Returns the length of the data encapsulated
	 * by the class.
	 *
	 * @return The data length in bytes
	 *
	 */
	public int getDataLength( )
	{
		return m_dataLen;
	}

	/**
	 * Retreives the actual data encapsulated by the
	 * class. The array that is returned will always
	 * be an intergral of 4 in length (i.e. 0, 4, 8, 12, ...).
	 * The actual length of the valid data contained in
	 * the buffer can be retreived via a call to getDataLength().
	 *
	 * @return The encapsulated data buffer.
	 *
	 * @see #getDataLength
	 *
	 */
	public byte[] getData()
	{
		return m_data;
	}

	/**
	 * Used to set the current data encapsulated by the class.
	 * The length of the data is set to the length of the passed
	 * array. The bytes in the passed array are actually copied
	 * into the object. Any modifications after the call to the
	 * passed buffer will not affect the objects data.
	 *
	 * @param buf The buffer encapsulate in the object.
	 *
	 */
	public void setData(byte[] buf)
	{
		if(buf == null)
		{
			m_data = null;
			m_dataLen = 0;
		}
		else
		{
			m_dataLen = buf.length;
			m_data = new byte[align4(buf.length)];
			for(int x = 0; x < buf.length; x++)
				m_data[x] = buf[x];

			for(int x = align4(buf.length)-1; x >= buf.length; --x)
				m_data[x] = (byte)0;
		}

		calculateLength();
	}

	/**
	 * Calculates the length of the packet based
	 * on the current values of the private fields.
	 * This value is updated in the super class 
	 * member m_length.
	 */
	private void calculateLength()
	{
		super.m_length = (short)(8 + 
					 4 + 
					 ((m_data != null) ? m_data.length : 0) + 
					 ((m_addrData != null) ? m_addrData.length : 0));
	}

	/**
	 * Writes self to the passed output stream.
	 * This method serializes the class in the format
	 * desired for the icmp daemon.
	 *
	 * @param ostream The output stream to write self to.
	 *
	 * @exception IOException Thrown if an error occurs with the
	 *	ostream object.
	 *
	 */
	void write(OutputStream ostream) throws IOException
	{
		byte[] buf = new byte[getLength() - 8];

		//
		// write the address data first
		//
		int ndx = 0;
		for(int x = 0; x < m_addrData.length; x++)
			buf[ndx++] = m_addrData[x];

		//
		// write the length next
		//
		buf[ndx++] = (byte)((m_dataLen >> 24) & 0xff);
		buf[ndx++] = (byte)((m_dataLen >> 16) & 0xff);
		buf[ndx++] = (byte)((m_dataLen >>  8) & 0xff);
		buf[ndx++] = (byte)(m_dataLen & 0xff);

		//
		// write the data next
		//
		if(m_data != null)
		{
			for(int x = 0; x < m_data.length; x++)
				buf[ndx++] = m_data[x];
		}

		super.write(ostream);
		ostream.write(buf);
	}
}
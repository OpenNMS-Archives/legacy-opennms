//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
// $Id: CtrlCloseMessage.java,v 1.4 2000/04/17 22:01:30 weave Exp $
//
//
package org.opennms.protocols.icmpd;

import java.lang.*;
import java.util.*;
import java.io.*;

import org.opennms.protocols.icmpd.MessageHeader;


/**
 * Defines the control message for an orderly shutdown of the communications
 * channel with the icmpd server. Once the control message is sent the
 * daemon should close the channel without responding. The format of the
 * message is as follows:
 *
 * <PRE>
 * +--------+--------+----------------+
 * |  TYPE  |  CODE  |   SEQUENCE     |
 * +--------+--------+----------------+
 * |     LENGTH      |   RESERVED     |
 * +-----------------+----------------+
 * </PRE>
 *
 * @author	Brian Weaver <weave@opennms.org>
 * @version	0.1
 *
 */
public final class CtrlCloseMessage extends MessageHeader
{
	/**
	 * The type for the message
	 */
	public static final byte TYPE	= (byte)1;

	/**
	 * The code for the message
	 */
	public static final byte CODE	= (byte)4;

	/**
	 * Class constructor. Constructs the control
	 * close message with the appropiate values.
	 *
	 */
	public CtrlCloseMessage( )
	{
		super.m_type	= TYPE;
		super.m_code	= CODE;
		super.m_sequence= MessageHeader.nextSequenceId();
		super.m_length	= (short)8;
		super.m_reserved= (short)0;
	}

	/**
	 * Constructs a control close message using the values
	 * specified in the header.
	 *
	 * @param hdr The header to copy into self.
	 *
	 * @exception IllegalArgumentException Thrown if the headers is
	 *	not a control close message.
	 */
	public CtrlCloseMessage(MessageHeader hdr)
	{
		super(hdr);
		if(hdr.m_type != TYPE || hdr.m_code != CODE)
			throw new IllegalArgumentException("The passed header is not a Control Close message");
	}
}
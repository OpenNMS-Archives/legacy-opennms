//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
// $Id: DaemonConnection.java,v 1.8 2000/11/02 04:46:13 weave Exp $
//
//
package org.opennms.protocols.icmpd;

import java.lang.*;
import java.io.*;
import java.net.*;

import org.opennms.protocols.icmpd.*;

/**
 * Creates a default connection to the ICMP daemon
 * for sending and receiving ICMP messages.
 *
 * @version	0.1
 * @author	Brian Weaver <weave@opennms.org>
 *
 */
public class DaemonConnection extends java.lang.Object
{
	Socket		m_channel;	// the communication channel
	// boolean	m_debug;	// enable for debug
	// PrintStream	m_debugTo;

	private Object	m_sendSync;
	private Object	m_recvSync;

	//private void printHex(int num, int width)
	//{
	//	m_debugTo.print("0x");
	//	for(int x = width-1; x >= 0; --x)
	//	{
	//		byte b = (byte)((num >> (x*4)) & 0xf);
	//		if(b < 10)
	//			m_debugTo.print(b);
	//		else
	//		{
	//			b -= (byte)10;
	//			char c = (char)('a' + (char)b);
	//			m_debugTo.print(c);
	//		}
	//	}
	//}

	//private void dump(byte[] buf)
	//{
	//	dump(buf, "Dumping packet of length " + buf.length);
	//}

	//private void dump(byte[] buf, String msg)
	//{
	//
	//	m_debugTo.println(msg);
	//	for(int x = 0; x < buf.length; x++)
	//	{
	//		if((x % 8) == 0)
	//		{
	//			if(x != 0) m_debugTo.println("");
	//			printHex(x, 4);
	//			m_debugTo.print(": ");
	//		}
	//		int t = (int)(buf[x]);
	//		if(t < 0)
	//			t+= 256;
	//		printHex(t, 2);
	//		m_debugTo.print(" ");
	//	}
	//	m_debugTo.println("");
	//}

	/**
	 * The default port to connect on the local host.
	 */
	public static final int		DEFAULT_PORT	= 5813;

	/**
	 * The default service name for the ICMP daemon.
	 */
	public static final String	SERVICE_NAME	= "icmpd";

	/**
	 * Creates a new connection on the local host to the
	 * default port.
	 *
	 * @exception UnknownHostException Thrown if 127.0.0.1 is an unknown host
	 * @exception IOException Thrown if an error occurs connecting to the port.
	 */
	public DaemonConnection( ) 
		throws UnknownHostException,
		       IOException
	{
		m_channel = new Socket("127.0.0.1", DEFAULT_PORT);
		//m_debug   = false;
		//m_debugTo = null;

		m_sendSync = new Object();
		m_recvSync = new Object();
	}

	/**
	 * Creates a new daemon connnection to the specified port on
	 * on the local machine.
	 *
	 * @param port The port to connect to on the loopback interface.
	 *
	 * @exception UnknownHostException Thrown if 127.0.0.1 is an unknown host
	 * @exception IOException Thrown if an error occurs connecting to the port.
	 *
	 */
	public DaemonConnection(int port) 
		throws UnknownHostException,
		       IOException
	{
		m_channel = new Socket("127.0.0.1", port);
		//m_debug   = false;
		//m_debugTo = null;

		m_sendSync = new Object();
		m_recvSync = new Object();
	}

	/**
	 * Closes the connection with the icmp daemon
	 *
	 * @exception IOException Thrown if an error occurs closing the connection.
	 *
	 */
	public void close( ) throws IOException
	{
		//
		// closeing the socket will call
		// the blocking read/writes to 
		// fail!
		//
		if(m_channel != null)
			m_channel.close();
		
		//
		// This should avoid a null pointer exception!
		//
		synchronized(m_sendSync)
		{
			synchronized(m_recvSync)
			{
				m_channel = null;
			}
		}
	}

	/**
	 * Sends the message to the icmp daemon. 
	 * 
	 * @param hdr	The message to be sent
	 *
	 * @exception IOException Thrown if an error occurs writing the object.
	 *
	 */
	public void sendMessage(MessageHeader hdr) throws IOException
	{
		synchronized(m_sendSync)
		{
			if(m_channel == null)
				throw new IOException("Channel is closed");

			hdr.write(m_channel.getOutputStream());
		}
	}
	
	/**
	 * Receives a message from the daemon and returns message header
	 * object. The object is actually one of the derived classes.
	 *
	 * @return The MessageHeader base object received.
	 *
	 * @exception IOException Thrown if an error occurs.
	 *
	 */
	public MessageHeader recvMessage( ) throws IOException
	{
		MessageHeader hdr = new MessageHeader();
		synchronized(m_recvSync)
		{
			if(m_channel == null)
				throw new IOException("Channel is closed");

			hdr.read(m_channel.getInputStream());
			if(hdr.getType() == MessageHeader.TYPE_CONTROL)
			{
				switch(hdr.getCode())
				{
				case CtrlFilterMessage.CODE:
					hdr = new CtrlFilterMessage(hdr, m_channel.getInputStream());
					break;

				case CtrlCloseMessage.CODE:
					hdr = new CtrlCloseMessage(hdr);
					break;

				case CtrlResponseMessage.CODE:
					hdr = new CtrlResponseMessage(hdr);
					break;

				case CtrlSuspendMessage.CODE:
					hdr = new CtrlSuspendMessage(hdr);
					break;

				case CtrlResumeMessage.CODE:
					hdr = new CtrlResumeMessage(hdr);
					break;

				default:
					if(hdr.getLength() > 8)
					{
						byte[] t = new byte[hdr.getLength()-8];
						int rc = m_channel.getInputStream().read(t);
						if(rc < (hdr.getLength() - 8))
							throw new IOException("Insufficent data returned from server");
					}
					break;
				}
			}
			else if(hdr.getType() == MessageHeader.TYPE_DATA)
			{
				switch(hdr.getCode())
				{
				case DataSendMessage.CODE:
					hdr = new DataSendMessage(hdr, m_channel.getInputStream());
					break;

				case DataRecvMessage.CODE:
					hdr = new DataRecvMessage(hdr, m_channel.getInputStream());
					break;

				default:
					if(hdr.getLength() > 8)
					{
						byte[] t = new byte[hdr.getLength()-8];
						int rc = m_channel.getInputStream().read(t);
						if(rc < (hdr.getLength() - 8))
							throw new IOException("Insufficent data returned from server");
					}
					break;
				}
			}

		} // end synchronization
		return hdr;
	}

	//public synchronized void setDebug(PrintStream output)
	//{
	//	if(output == null)
	//	{
	//		m_debug = false;
	//		m_debugTo = null;
	//	}
	//	else
	//	{
	//		m_debug = true;
	//		m_debugTo = output;
	//	}
	//}

}

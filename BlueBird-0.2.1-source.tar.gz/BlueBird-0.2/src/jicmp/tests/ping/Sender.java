//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
// $Id: Sender.java,v 1.5 2000/10/01 19:57:18 weave Exp $
//
//
package org.opennms.tests.ping;

import java.lang.*;
import java.net.*;
import java.io.*;
import java.util.*;
import org.opennms.protocols.ip.*;
import org.opennms.protocols.icmpd.*;
import org.opennms.protocols.icmp.*;


public class Sender extends Thread
{
	private DaemonConnection m_daemon;
	private short		 m_ident;
	private InetAddress 	 m_addr;

	public Sender(DaemonConnection comm, InetAddress addr, short ident)
	{
		m_daemon = comm;
		m_ident  = ident;
		m_addr   = addr;
	}

	public void run( )
	{
		while(true)
		{
			//System.out.println("Sender building PingPacket");
			PingPacket pkt = new PingPacket( );
			pkt.setIdentity(m_ident);

			byte [] pktArray = pkt.toBytes();
			OC16ChecksumProducer summer = new OC16ChecksumProducer();
			
			int x = 0;
			for(; x < pktArray.length; x+=2)
				summer.add(pktArray[x], pktArray[x+1]);
			
			if(x < pktArray.length)
				summer.add(pktArray[x]);

			pkt.setChecksum(summer.getChecksum());

			pkt.storeToBuffer(pktArray, 0);


			DataSendMessage msg = new DataSendMessage(m_addr, pktArray);

			try
			{
				System.out.println("Sending packet at time " + (new Date()).getTime());
				m_daemon.sendMessage(msg);
				//System.out.println("Packet sent");
			}
			catch(IOException e)
			{
				System.out.println("Exception: " + e.getMessage());
				System.exit(1);
			}
			
			try
			{
				sleep(1000);
			}
			catch(InterruptedException e)
			{
				// do nothing
			}
		}
	}
}

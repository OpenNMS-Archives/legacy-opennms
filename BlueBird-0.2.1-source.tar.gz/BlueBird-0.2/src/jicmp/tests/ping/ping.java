//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
// $Id: ping.java,v 1.5 2000/10/01 19:57:18 weave Exp $
//
//
package org.opennms.tests.ping;

import java.lang.*;
import java.net.*;
import java.io.*;
import java.util.*;
import org.opennms.protocols.icmpd.*;
import org.opennms.protocols.icmp.*;
import org.opennms.protocols.ip.*;

public class ping
{
	//
	// Usage: java ping host
	//
	public static void main(String[] args)
	{
		if(args.length != 1)
		{
			System.out.println("Usage: java ping host");
			System.exit(1);
		}

		Random rnd = new Random((new Date()).getTime());
		short seqId = (short)(rnd.nextInt());
		
		DaemonConnection dc = null;
		try
		{
			dc = new DaemonConnection();
			//dc.setDebug(System.out);
		}
		catch(IOException e)
		{
			System.out.println("Exception: " + e.getMessage());
			System.exit(1);
		}
				
		//
		// Setup a filter
		//
		byte[] filterOne = new byte[1];
		filterOne[0] = ICMPHeader.TYPE_ECHO_REPLY;

		byte[] filterTwo = new byte[2];
		filterTwo[0] = (byte)(seqId >>> 8);
		filterTwo[1] = (byte)(seqId & 0xff);

		CtrlFilterMessage fone = new CtrlFilterMessage(CtrlFilterMessage.FILTER_ON_ICMP,
							       CtrlFilterMessage.ACTION_PASS,
							       0,
							       filterOne);

		CtrlFilterMessage ftwo = new CtrlFilterMessage(CtrlFilterMessage.FILTER_ON_ICMP,
							       CtrlFilterMessage.ACTION_PASS,
							       4,
							       filterTwo);

		try
		{
			//
			// push the filters onto the channel
			//
			dc.sendMessage(fone);
			dc.sendMessage(ftwo);

			//
			// receive the two responses
			//
			MessageHeader hdr = dc.recvMessage();
			if(hdr instanceof CtrlResponseMessage)
			{
				CtrlResponseMessage response = (CtrlResponseMessage)hdr;
				if(response.getErrorCode() != 0)
				{
					System.err.println("Error pushing filter onto channel");
					System.exit(1);
				}
			}
			else
			{
				System.out.println("Recevied unknown message: Type = " + 
						   hdr.getType() + ", Code = " + hdr.getCode());
				System.exit(1);
			}

			hdr = dc.recvMessage();
			if(hdr instanceof CtrlResponseMessage)
			{
				CtrlResponseMessage response = (CtrlResponseMessage) hdr;
				if(response.getErrorCode() != 0)
				{
					System.err.println("Error pushing filter onto channel");
					System.exit(2);
				}
			}
			else
			{
				System.out.println("Recevied unknown message: Type = " + 
						   hdr.getType() + ", Code = " + hdr.getCode());
				System.exit(1);
			}

			CtrlResumeMessage fresume = new CtrlResumeMessage();
			dc.sendMessage(fresume);
		}
		catch(IOException e)
		{
			System.out.println("Exception: " + e.getMessage());
			System.exit(1);
		}

		try
		{
			Receiver r = new Receiver(dc);
			Sender   s = new Sender(dc, InetAddress.getByName(args[0]), seqId);
			r.start();
			s.start();
		}
		catch(UnknownHostException e)
		{
			System.out.println("Exception: " + e.getMessage());
			System.exit(1);
		}

	}
}


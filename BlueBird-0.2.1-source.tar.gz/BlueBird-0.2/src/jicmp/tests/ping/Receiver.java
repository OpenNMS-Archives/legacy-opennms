//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
// $Id: Receiver.java,v 1.4 2000/10/01 19:57:18 weave Exp $
//
//
package org.opennms.tests.ping;

import java.lang.*;
import java.net.*;
import java.io.*;
import java.util.*;
import org.opennms.protocols.icmpd.*;
import org.opennms.protocols.icmp.*;
import org.opennms.protocols.ip.*;


public class Receiver extends Thread
{
	private DaemonConnection m_daemon;

	public Receiver(DaemonConnection comm)
	{
		m_daemon = comm;
	}

	public void run( )
	{
		//
		// receive all messages
		//
		try
		{
			while(true)
			{
				MessageHeader hdr = m_daemon.recvMessage();
				Date recv = new Date();

				if(hdr instanceof CtrlResponseMessage)
				{
					CtrlResponseMessage response = (CtrlResponseMessage)hdr;
					if(response.getErrorCode() != 0)
					{
						System.out.println("Response Error: " + response.getErrorCode());
						System.exit(1);
					}
				}
				else if(hdr instanceof DataRecvMessage)
				{
					DataRecvMessage pkt = (DataRecvMessage)hdr;
					if(pkt.getICMPLength() < PingPacket.getNetworkSize())
					{
						System.out.println("Received short icmp packet");
					}
					else
					{
						PingPacket p = new PingPacket(pkt.getICMPData());
						IPHeader  ip = new IPHeader(pkt.getIPHeader(), 0);
						System.out.println("Receive Response from " +
								    IPHeader.addressToString(ip.getSourceAddress()) +
								    ", at " + recv.getTime() + ", ms = " +
								    (recv.getTime() - p.getSentTime()));
					}
				}
				else
				{
					System.out.println("Received unexpected packet from daemon");
				}
			}
		}
		catch(IOException err)
		{
			System.out.println("Exception: " + err.getMessage());
			System.exit(1);
		}
	}
}

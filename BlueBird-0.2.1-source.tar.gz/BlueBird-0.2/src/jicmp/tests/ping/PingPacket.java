//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
// $Id: PingPacket.java,v 1.5 2000/10/01 19:57:18 weave Exp $
//
//
package org.opennms.tests.ping;

import java.lang.*;
import java.util.*;

import org.opennms.protocols.ip.*;
import org.opennms.protocols.icmp.*;
import org.opennms.protocols.exceptions.*;

public final class PingPacket extends ICMPHeader
{
	private long	m_sent;
	private long	m_recv;
	private byte[]	m_pad;

	/**
	 * This is the amount of padding required to make the ICMP
	 * echo request 56 bytes in length. This is just following
	 * the available code for ping ;)
	 */
	private static final int	PAD_SIZE	= 32;

	static private long byteToLong(byte b)
	{
		long r = (long)b;
		if(r < 0) 
			r+= 256;
		return r;
	}

	public PingPacket( )
	{
		super(ICMPHeader.TYPE_ECHO_REQUEST, (byte)0);
		setNextSequenceId();
		m_sent = (new Date()).getTime();
		m_pad  = new byte[PAD_SIZE];
		for(int x = 0; x < PAD_SIZE; x++)
			m_pad[x] = (byte)x;
	}

	public PingPacket(byte[] buf)
	{
		loadFromBuffer(buf,0);
	}

	public long getSentTime()
	{
		return m_sent;
	}

	public long setSentTime()
	{
		m_sent = (new Date()).getTime();
		return m_sent;
	}

	public void setSentTime(long time)
	{
		m_sent = time;
	}

	public long getReceivedTime()
	{
		return m_recv;
	}

	public long setReceivedTime()
	{
		m_recv = (new Date()).getTime();
		return m_recv;
	}

	public void setReceivedTime(long time)
	{
		m_recv = time;
	}

	public static int getNetworkSize( )
	{
		return (ICMPHeader.getNetworkSize() + 16 + PAD_SIZE);
	}

	public void setChecksum(short sum)
	{
		super.setChecksum(sum);
	}

	public int loadFromBuffer(byte[] buf, int offset)
	{
		if((buf.length - offset) < getNetworkSize())
			throw new InsufficientDataException("Insufficient Data");

		offset = super.loadFromBuffer(buf, offset);
		if(!isEchoReply() && !isEchoRequest())
			throw new IllegalArgumentException("Invalid type, must be echo request/reply packet");

		m_sent = 0;
		for(int x = 0; x < 8; x++)
		{
			m_sent <<= 8;
			m_sent |= byteToLong(buf[offset++]);
		}
		m_recv = 0;
		for(int x = 0; x < 8; x++)
		{
			m_recv <<= 8;
			m_recv |= byteToLong(buf[offset++]);
		}
	
		if(m_pad == null)
			m_pad = new byte[PAD_SIZE];
		for(int x = 0; x < PAD_SIZE; x++)
			m_pad[x] = buf[offset++];

		return offset;
	}
	
	public int storeToBuffer(byte[] buf, int offset)
	{
		if((buf.length - offset) < getNetworkSize())
			throw new InsufficientDataException("Insufficient Buffer Size");

		offset = super.storeToBuffer(buf, offset);

		long t = m_sent;
		for(int x=0; x < 8; x++)
		{
			buf[offset++] = (byte)(t >>> 56);
			t <<= 8;
		}

		t = m_recv;
		for(int x=0; x < 8; x++)
		{
			buf[offset++] = (byte)(t >>> 56);
			t <<= 8;
		}

		for(int x = 0; x < PAD_SIZE; x++)
			buf[offset++] = m_pad[x];

		return offset;
	}


	public byte[] toBytes()
	{
		byte[]	buf = new byte[getNetworkSize()];
		storeToBuffer(buf, 0);
		return buf;
	}
}

//-------------------------------------------------------------------------------------------
//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

//--------------------------------------------------------------------------------------------

package org.opennms.bb.eui.admin.distpoller.configure.dpconf;

import javax.swing.*;
import javax.swing.text.*;
import javax.swing.tree.*;
import javax.swing.border.*;
import javax.swing.JTree; 
import javax.swing.event.*;

import java.awt.*;
import java.awt.event.*;
import java.awt.dnd.*; 
import java.awt.datatransfer.*; 
import java.awt.Point; 
import java.util.Vector;

import java.io.IOException; 


public class DropTree extends JTree {

    private DragSource		    dragSource; 
    private DropTarget		    dropTarget; 

    //public DummyTree dummyTree;
	
    private TreeGestureListener	    gestureListener; 
    private TreeSourceListener	    sourceListener; 
    private TreeTargetListener	    targetListener; 
	boolean firstnode = false; 

    private DefaultMutableTreeNode  dragNode = null; 

    DefaultTreeModel ppModel, dpModel;
	Vector ppVector = new Vector();
	Vector dpVector = new Vector();
	Vector ppNodeVector = new Vector();

    private class TreeGestureListener implements DragGestureListener { 
	public void dragGestureRecognized(DragGestureEvent e) { 
	    Point		    nodeLocation = e.getDragOrigin(); 
	    DefaultMutableTreeNode  treeNode = getTreeNode(nodeLocation); 


	    if (treeNode != null) { 
		dragNode = treeNode; 


		// Start the drag. 
		dragSource.startDrag(e, DragSource.DefaultCopyDrop, 
				    new StringSelection(treeNode.toString()), 
				    sourceListener); 
	    } 
	} 
    } 


    private class TreeSourceListener implements DragSourceListener { 
	public void dragDropEnd(DragSourceDropEvent e) { 
	    // Do Nothing. 
	} 


	public void dragEnter(DragSourceDragEvent e) { 
	    // Do Nothing. 
	} 


	public void dragExit(DragSourceEvent e) { 
	    // Do Nothing. 
	} 


	public void dragOver(DragSourceDragEvent e) { 
	    // Do Nothing. 
	} 


	public void dropActionChanged(DragSourceDragEvent e) { 
	    // Do Nothing. 
	} 
    } 


    private class TreeTargetListener implements DropTargetListener { 
	public void drop(DropTargetDropEvent e) { 
	    try { 
		Point			dropLocation = e.getLocation(); 
		DefaultMutableTreeNode	treeNode = getTreeNode(dropLocation); 
		DataFlavor		stringFlavor = DataFlavor.stringFlavor; 
		Transferable		data = e.getTransferable();
	
	// code to restrict the dropping on wrong nodes starts here

		String temp = new String(treeNode.toString());
		String tempString = null;
	
		int childCount =  treeNode.getChildCount();
		if (childCount == 0 ) firstnode = true;
		else firstnode = false;
		if (childCount != 0) {
			for (int j = 0; j < childCount; j++ ) {
				tempString = (treeNode.getChildAt(j)).toString();
				ppNodeVector.addElement(tempString);
			}
		}

		ppModel = DPConfigF.m_PollerPackageModel;
		MutableTreeNode root	=     (MutableTreeNode)ppModel.getRoot();
		int index = ppModel.getChildCount(root);
	
		Object node[] = new Object[index];
		String ppStr = null;
					
		for (int i = 0; i < index; i++) {
			node[i] = ppModel.getChild(root, i);
			ppStr = node[i].toString();
			ppVector.addElement(ppStr);
	
		}

		dpModel = DPConfigF.m_DistPollerModel;
		MutableTreeNode root1	=     (MutableTreeNode)dpModel.getRoot();
		int index1 = dpModel.getChildCount(root1);
	
		Object node1[] = new Object[index1];
		String dpStr = null;
					
		for (int i = 0; i < index1; i++) {
			node1[i] = dpModel.getChild(root1, i);
			dpStr = node1[i].toString();
			dpVector.addElement(dpStr);
	

		}
	

	// upto this place

		if (treeNode != null &&  e.isDataFlavorSupported(stringFlavor) && dpVector.contains(temp)  ) { 
		    String text = (String) data.getTransferData(stringFlavor); 


		  if (  ppVector.contains(text) && !ppNodeVector.contains(text) ) {

		    e.acceptDrop(DnDConstants.ACTION_COPY_OR_MOVE); 


		    // Creat a new Node with the text. 
		    DefaultMutableTreeNode newNode = new DefaultMutableTreeNode(text); 


		    // Add the new node to the current node. 
		    treeNode.add(newNode); 
		    ((DefaultTreeModel)getModel()).reload(treeNode);			

			if (UserManager.m_oDPP.containsKey( (treeNode.toString()).trim() + " : " + text.trim() ))
			{
				UserManager.m_oDPP.remove( (treeNode.toString()).trim() + " : " + text.trim() );
			}
			UserManager.m_oDPP.put( (treeNode.toString()).trim() + " : " + text.trim(), "packageName");

		    e.dropComplete(true); 	
			ppNodeVector.removeAllElements();//dpVector.removeAllElements();

		  }

		  else {
	
				ppNodeVector.removeAllElements();
	
				dpVector.removeAllElements();
		  }
	
		} 
		else { 
			Toolkit.getDefaultToolkit().beep();
		    e.rejectDrop();

			 ppNodeVector.removeAllElements();
				
				dpVector.removeAllElements();

		} 
	    } 
	    catch(IOException ioe) { 
		ioe.printStackTrace(); 
	    } 
	    catch(UnsupportedFlavorException ufe) { 
		ufe.printStackTrace(); 
	    } 
	} 


	public void dragEnter(DropTargetDragEvent e) { 
	    if (isDragOk(e) == false) { 
		//Toolkit.getDefaultToolkit().beep();
		e.rejectDrag(); 
		return; 
	    } 


	    e.acceptDrag(DnDConstants.ACTION_COPY_OR_MOVE); 
	} 


	public void dragExit(DropTargetEvent e) { 
	    // Do Nothing. 
	} 


	public void dragOver(DropTargetDragEvent e) { 
	    Point	dragLocation = e.getLocation(); 
	    TreePath	treePath = getPathForLocation(dragLocation.x, dragLocation.y); 


	    if (isDragOk(e) == false || treePath == null) { 
	//	Toolkit.getDefaultToolkit().beep();
		e.rejectDrag(); 
		return; 
	    } 


	    // Make the node active. 
	    setSelectionPath(treePath); 


	    e.acceptDrag(DnDConstants.ACTION_COPY_OR_MOVE); 
	} 


	public void dropActionChanged(DropTargetDragEvent e) { 
	    if (isDragOk(e) == false) { 
		//Toolkit.getDefaultToolkit().beep();
		e.rejectDrag(); 
		return; 
	    } 


	    e.acceptDrag(DnDConstants.ACTION_COPY_OR_MOVE); 
	} 


	private boolean isDragOk(DropTargetDragEvent e) { 
	    return(true); 
	} 
    } 


    
	public DropTree() {
		// Default Constructor
	}    
 
    public DropTree(TreeNode root) { 
	super(root); 

	//dummyTree = new DummyTree();
	gestureListener = new TreeGestureListener(); 
	sourceListener = new TreeSourceListener(); 
	targetListener = new TreeTargetListener(); 


	// Set up the tree to be a drop target. 
	dropTarget = new DropTarget(this, DnDConstants.ACTION_COPY_OR_MOVE, targetListener, true); 


	// Set up the tree to be a drag source. 
	dragSource = DragSource.getDefaultDragSource(); 
	dragSource.createDefaultDragGestureRecognizer(this, 
							DnDConstants.ACTION_COPY_OR_MOVE, 
							gestureListener); 
    } 


    private DefaultMutableTreeNode getTreeNode(Point location) { 
	TreePath treePath = getPathForLocation(location.x, location.y); 


	if (treePath != null) { 
	    return((DefaultMutableTreeNode) treePath.getLastPathComponent()); 
	} 
	else { 
	    return(null); 
	} 
    } 
}

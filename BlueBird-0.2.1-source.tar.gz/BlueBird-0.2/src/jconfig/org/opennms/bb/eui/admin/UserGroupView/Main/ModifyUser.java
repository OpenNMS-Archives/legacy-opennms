//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
package org.opennms.bb.eui.admin.UserGroupView.Main;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class ModifyUser extends JDialog
{
	private boolean	m_bNew	= false;
	private String	sOldId	= "";

	public ModifyUser(JFrame parent, boolean modal, String userName)
	{
		super(parent, modal);

		JLabel oUserIdLabel		= new JLabel();
		JLabel oPasswordLabel	= new JLabel();
		JLabel oUserNameLabel	= new JLabel();
		JLabel oCommentsLabel	= new JLabel();
		JLabel oPasswordConfLabel= new JLabel();

		getContentPane().setLayout(null);

		setBackground(java.awt.Color.lightGray);
		setSize(375,240);
		setVisible(false);

		getContentPane().add(m_oUserIdInput);
		getContentPane().add(m_oUserNameInput);
		getContentPane().add(m_oPasswordInput);
		getContentPane().add(m_oPasswordConfInput);
		getContentPane().add(m_oCommentsInput);

		if(!m_bNew)
		{
			String sBuffer = (String)UserManager.m_oUsers.get(userName);
			if(sBuffer != null)
			{
				StringTokenizer oTokenizer = new StringTokenizer(sBuffer,":");

				String sTok = "";
				try
				{
					sTok = oTokenizer.nextToken();
				} catch(NoSuchElementException  e) { sTok = ""; }
				m_oPasswordInput.setText(sTok);
				m_oPasswordConfInput.setText(sTok);

				try
				{
					sTok = oTokenizer.nextToken();
				} catch(NoSuchElementException  e) { sTok = ""; }
				m_oUserNameInput.setText(sTok);

				try
				{
					sTok = oTokenizer.nextToken();
				} catch(NoSuchElementException  e) { sTok = ""; }
				m_oCommentsInput.setText(sTok);
			}
		}


		oUserIdLabel.setText("User ID:");
		oUserIdLabel.setHorizontalAlignment(JLabel.LEFT);
		getContentPane().add(oUserIdLabel);
		oUserIdLabel.setBounds(8,12,110,24);
		m_oOkButton.setText("OK");
		getContentPane().add(m_oOkButton);
		m_oOkButton.setBounds(151,203,85,25);
		Dimension oButtonSize = new Dimension(85, 25);
		m_oOkButton.setPreferredSize(oButtonSize);
		m_oOkButton.setMinimumSize(oButtonSize);
		m_oOkButton.setMaximumSize(oButtonSize);
		m_oOkButton.setBorderPainted(true);

		m_oUserIdInput.setText(userName);
		m_oUserIdInput.selectAll();
		sOldId = userName;
		
		m_oUserIdInput.setBounds(124,12,240,24);
		oUserNameLabel.setText("Full Name:");
		oUserNameLabel.setHorizontalAlignment(JLabel.LEFT);
		getContentPane().add(oUserNameLabel);
		oUserNameLabel.setBounds(8,37,110,24);
		m_oUserNameInput.setBounds(124,37,240,24);
		oPasswordLabel.setText("Password:");
		oPasswordLabel.setHorizontalAlignment(JLabel.LEFT);
		getContentPane().add(oPasswordLabel);
		oPasswordLabel.setBounds(8,63,110,24);
		m_oPasswordInput.setBounds(124,63,240,24);
		oPasswordConfLabel.setText("Confirm password:");
		oPasswordConfLabel.setHorizontalAlignment(JLabel.LEFT);
		getContentPane().add(oPasswordConfLabel);
		oPasswordConfLabel.setBounds(8,90,110,24);
		m_oPasswordConfInput.setBounds(124,90,240,24);
		oCommentsLabel.setText("Comments:");
		oCommentsLabel.setHorizontalAlignment(JLabel.LEFT);
		getContentPane().add(oCommentsLabel);
		oCommentsLabel.setBounds(8,116,110,24);
		m_oCommentsInput.setBounds(124,116,240,78);

		JScrollPane	oTextAreaScrollPane	= new JScrollPane(m_oCommentsInput,
														  JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
														  JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED );
		oTextAreaScrollPane.setBounds(124,116,240,78);
		getContentPane().add(oTextAreaScrollPane);

		setTitle("Modify User");
        
		SymWindow oSymWindow = new SymWindow();
		this.addWindowListener(oSymWindow);
		SymAction oSymAction = new SymAction();
		m_oOkButton.addActionListener(oSymAction);

		MouseListener	oMouseListener = new TheMouseListener();
		KeyListener		oKeyListener   = new TheKeyListener();
		m_oUserIdInput.addMouseListener(oMouseListener);
		m_oUserIdInput.addKeyListener(oKeyListener);
		m_oPasswordInput.addMouseListener(oMouseListener);
		m_oPasswordInput.addKeyListener(oKeyListener);
		m_oPasswordConfInput.addMouseListener(oMouseListener);
		m_oPasswordConfInput.addKeyListener(oKeyListener);

		setResizable(false);

	}
    
	public ModifyUser(JFrame parent, String title, boolean modal, String userName)
	{
		this(parent, modal, userName);
		setTitle(title);
	}

	public ModifyUser(JFrame parent, String title, boolean modal, String userName, boolean isNew)
	{
		this(parent, title, modal, userName);
		m_bNew = isNew;
	}

	class TheMouseListener implements MouseListener
	{
		public void mousePressed(MouseEvent e)
		{
			m_oUserIdInput.setBackground(java.awt.Color.white);
			m_oPasswordInput.setBackground(java.awt.Color.white);
			m_oPasswordConfInput.setBackground(java.awt.Color.white);
		}
		public void mouseClicked(MouseEvent e)
		{
			m_oUserIdInput.setBackground(java.awt.Color.white);
			m_oPasswordInput.setBackground(java.awt.Color.white);
			m_oPasswordConfInput.setBackground(java.awt.Color.white);
		}

		public void mouseEntered(MouseEvent e){}
		public void mouseExited(MouseEvent e){}
		public void mouseReleased(MouseEvent e){}
	}

	class TheKeyListener implements KeyListener
	{
		public void keyTyped(java.awt.event.KeyEvent e)
		{
			m_oUserIdInput.setBackground(java.awt.Color.white);
			m_oPasswordInput.setBackground(java.awt.Color.white);
			m_oPasswordConfInput.setBackground(java.awt.Color.white);
		}
		public void keyPressed(java.awt.event.KeyEvent e)
		{
			m_oPasswordInput.setBackground(java.awt.Color.white);
			m_oPasswordInput.setBackground(java.awt.Color.white);
			m_oPasswordConfInput.setBackground(java.awt.Color.white);
		}

		public void keyReleased(KeyEvent e){}
 	}
    
	public void addNotify()
	{
		Dimension d = getSize();

		super.addNotify();

		if (m_bComponentsAdjusted)
			return;

		Insets insets = getInsets();
		setSize(insets.left + insets.right + d.width, insets.top + insets.bottom + d.height);
		Component components[] = getComponents();
		for (int i = 0; i < components.length; i++)
		{
			Point p = components[i].getLocation();
			p.translate(insets.left, insets.top);
			components[i].setLocation(p);
		}

		m_bComponentsAdjusted = true;
	}

	public void setVisible(boolean b)
	{
	    if (b)
	    {
    		Rectangle bounds = getParent().getBounds();
    		Rectangle abounds = getBounds();

    		setLocation(bounds.x + (bounds.width - abounds.width)/ 2,
    			 bounds.y + (bounds.height - abounds.height)/2);
	    }

		super.setVisible(b);
	}

	JButton			m_oOkButton			= new JButton();
	JTextField		m_oUserIdInput		= new JTextField();
	JPasswordField	m_oPasswordInput	= new JPasswordField();
	JTextField		m_oUserNameInput	= new JTextField();
	JPasswordField	m_oPasswordConfInput= new JPasswordField();
	JTextArea		m_oCommentsInput	= new JTextArea();
    
    // Used for addNotify check.
	boolean m_bComponentsAdjusted = false;

	class SymAction implements java.awt.event.ActionListener
	{
		public void actionPerformed(java.awt.event.ActionEvent event)
		{
			Object object = event.getSource();
			if (object == m_oOkButton)
			{
				String sId = m_oUserIdInput.getText();
				if( (sId == null) || sId.trim().equals("") )
				{
					Toolkit.getDefaultToolkit().beep();
				    m_oUserIdInput.setBackground(java.awt.Color.red);
					return;
				}
				sId = new String(m_oPasswordInput.getPassword());
				if( (sId == null) || sId.trim().equals(""))
				{
					Toolkit.getDefaultToolkit().beep();
				    m_oPasswordInput.setBackground(java.awt.Color.red);
					return;
				}
				sId = new String(m_oPasswordConfInput.getPassword());
				if( (sId == null) || sId.trim().equals("") || (!sId.equals(new String(m_oPasswordInput.getPassword()))) )
				{
					Toolkit.getDefaultToolkit().beep();
				    m_oPasswordConfInput.setBackground(java.awt.Color.red);
					return;
				}
				try
				{
					sId = m_oUserIdInput.getText();
					if(m_bNew)
					{
						if(UserManager.m_oUsers.containsKey(sId))
						{
							Toolkit.getDefaultToolkit().beep();
						    m_oUserIdInput.setBackground(java.awt.Color.red);
							return;
						}
						UserManager.add(UserManager.USER, m_oUserIdInput.getText());
						UserManager.m_sBuffer= new String(m_oPasswordInput.getPassword());
						UserManager.m_sBuffer+= ":";
						String sTmp = m_oUserNameInput.getText();
						if(sTmp==null || (sTmp.trim().equals("")))
						{
							sTmp = "(unknown)";
						}
						UserManager.m_sBuffer+= sTmp;
						UserManager.m_sBuffer+= ":";
						sTmp = m_oCommentsInput.getText();
						if(sTmp==null || (sTmp.trim().equals("")))
						{
							sTmp = "(none)";
						}
						UserManager.m_sBuffer+= sTmp;
						UserManager.m_sBuffer+= ":";
						//UserManager.ok();
					}
					else
					{
						if((!sOldId.equals(sId)) && UserManager.m_oUsers.containsKey(sId))
						{
							Toolkit.getDefaultToolkit().beep();
						    m_oUserIdInput.setBackground(java.awt.Color.red);
							return;
						}
						UserManager.modify(UserManager.USER, sOldId);
						UserManager.m_sNewId = m_oUserIdInput.getText();
						UserManager.m_sBuffer= new String(m_oPasswordInput.getPassword());
						UserManager.m_sBuffer+= ":";
						String sTmp = m_oUserNameInput.getText();
						if(sTmp==null || (sTmp.trim().equals("")))
						{
							sTmp = "(unknown)";
						}
						UserManager.m_sBuffer+= sTmp;
						UserManager.m_sBuffer+= ":";
						sTmp = m_oCommentsInput.getText();
						if(sTmp==null || (sTmp.trim().equals("")))
						{
							sTmp = "(none)";
						}
						UserManager.m_sBuffer+= sTmp;
						UserManager.m_sBuffer+= ":";
						//UserManager.ok();
					}
				    setVisible(false);
					dispose();
				}
				catch (Exception e)
				{
					UserManager.cancel();
				}
			}
		}
	}

	class SymWindow extends java.awt.event.WindowAdapter
	{
		public void windowClosing(java.awt.event.WindowEvent event)
		{
			Object object = event.getSource();
			if (object == ModifyUser.this)
			{
				try
				{
				    setVisible(false);
					UserManager.cancel();
					dispose();
				}
				catch (Exception e)
				{
				}
			}
		}
	}

	public static void main(String[] args)
	{
		JFrame frame = new JFrame();
		frame.setSize(383,240);
		try
		{
			(new ModifyUser(frame, true, "Name")).setVisible(true);
		}
		catch (Exception e)
		{
		}
	}

}

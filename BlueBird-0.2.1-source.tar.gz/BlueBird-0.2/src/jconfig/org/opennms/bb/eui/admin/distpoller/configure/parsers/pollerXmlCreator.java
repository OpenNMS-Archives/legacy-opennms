//-------------------------------------------------------------------------------------------
//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

//--------------------------------------------------------------------------------------------

package org.opennms.bb.eui.admin.distpoller.configure.parsers;

import org.opennms.bb.eui.admin.distpoller.configure.dpconf.*;

import java.io.*;
import java.util.*;

/**
 * pollerXmlCreator creates a 'pollersXML' xml file using the data in the
 * Hashtables present in UserManager.java
 *
 * @author Jaya Krishna Chakravarthula
 *
 */

public class pollerXmlCreator 
{
	final String PACKAGE		=	 "<package>";
	final String PACKAGE_CLS		=	 "</package>\n";

	final String POLLERS			= 	"<pollers>";
	final String POLLERS_CLS		=	 "</pollers>\n";
	
	final String DISCLIMIT			= 	"<discLimit>";
	final String DISCLIMIT_CLS		=	 "</discLimit>\n";

	final String POLLER			= 	"<poller>";
	final String POLLER_CLS			=	 "</poller>\n";

	final String POLLERID			= 	"<pollerID>";
	final String POLLERID_CLS			=	 "</pollerID>\n";

	final String POLLERNAME			= 	"<pollerName>";
	final String POLLERNAME_CLS			=	 "</pollerName>\n";

	final String POLLERIP			= 	"<pollerIP>";
	final String POLLERIP_CLS			=	 "</pollerIP>\n";

	final String POLLERCOMMENTS		= 	"<pollerComments>";
	final String POLLERCOMMENTS_CLS	= 	"</pollerComments>\n";

	final String POLLERHOST			= 	"<pollerHost>";
	final String POLLERHOST_CLS		= 	"</pollerHost>\n";

	Vector dppVector = new Vector();
	
	int 	iNumParms=0;


	/**
 	 * Writes into the file 'pollersXML.xml'
 	 */

	public pollerXmlCreator() throws IOException
	{
		writeInto("data/common/conf/pollersXML.xml");
	}

	/**
 	 * Writes into the filename passed in
 	 */

	public pollerXmlCreator(String filename)	throws IOException
	{
		writeInto(filename);
	}
	
	private void writeInto(String fileName) throws IOException
	{
		FileReader fileReader;
		FileWriter fileWriter;

		boolean bReadDTD=true;
		StringBuffer DTDBuffer=new StringBuffer();

		try
		{
			fileReader = new FileReader(fileName);
			readDTD(fileReader, DTDBuffer);

		} catch (IOException e)
		{
			e.printStackTrace();

			bReadDTD = false;
		}

		fileWriter = new FileWriter(fileName);
			
		// write the DTD first
		if (!bReadDTD)
			writeDTD(fileWriter);
		else
			writeDTD(fileWriter, DTDBuffer);

		fileWriter.write("<dpollers>\n");

		// now the header..
		writeHeader(fileWriter);
		

		/**
		 write filters, rangedef, irange, erange, specific, url, services, calendars
		 into the package
		*/

		fileWriter.write("\t" + "<pollers>\n");

		Enumeration  dppEnum = UserManager.m_oDPP.keys();
		while (dppEnum.hasMoreElements())
		{
			dppVector.addElement((String)dppEnum.nextElement());
		}

		int pCount = UserManager.m_oDP.size();

		Enumeration pEnum = UserManager.m_oDP.keys();

		for (int i = 0; i < pCount; i++)
		{

			fileWriter.write("\t\t" + POLLER+ "\n");

			String str = (String)pEnum.nextElement();
			str = str.trim();
						
			fileWriter.write("\t\t\t" + POLLERID);
			fileWriter.write(str);
			fileWriter.write(POLLERID_CLS);

			String pComment = (String)UserManager.m_oDP.get(str);
			StringTokenizer pstok = new StringTokenizer(pComment, ":");
		
			while (pstok.hasMoreTokens())
			{
			
				String stok1 = (String)pstok.nextToken();
				stok1 = stok1.trim();
		
				fileWriter.write("\t\t\t" + POLLERNAME);
				fileWriter.write(stok1);
				fileWriter.write(POLLERNAME_CLS);

				stok1 = (String)pstok.nextToken();
				stok1 = stok1.trim();

				fileWriter.write("\t\t\t" + POLLERIP);
				fileWriter.write(stok1);
				fileWriter.write(POLLERIP_CLS);

				stok1 = (String)pstok.nextToken();
				stok1 = stok1.trim();

				fileWriter.write("\t\t\t" + DISCLIMIT);
				fileWriter.write(stok1);
				fileWriter.write(DISCLIMIT_CLS);
				
				stok1 = (String)pstok.nextToken();
				stok1 = stok1.trim();

				fileWriter.write("\t\t\t" + POLLERCOMMENTS);
				fileWriter.write(stok1);
				fileWriter.write(POLLERCOMMENTS_CLS);

			}					

			int count = 0;
			int size = dppVector.size();

			while (count < size)
			{
				String dppstr = (String)dppVector.elementAt(count);
				StringTokenizer dpstok = new StringTokenizer(dppstr,":");

				String dstok1 = (String)dpstok.nextToken();
				dstok1 = dstok1.trim();
			
				String dstok2 = (String)dpstok.nextToken();
				dstok2 = dstok2.trim();
			
				if (dstok1.equals(str))
				{
								
					fileWriter.write("\t\t\t" + PACKAGE);
					fileWriter.write(dstok2);
					fileWriter.write(PACKAGE_CLS);
				}
				++count;
			}

			fileWriter.write("\t\t" + POLLER_CLS+ "\n");
				
		}

		fileWriter.write("\t" + "</pollers>\n");
		fileWriter.write("</dpollers>\n");
		fileWriter.flush();

	}

	void readDTD(FileReader fileReader, StringBuffer DTDBuffer) 
													throws IOException
	{
		int curInt = fileReader.read();
		char curChar = (char)curInt;
		char prevChar = curChar;

		while ( curInt != -1)
		{
			if (curChar == '>' && prevChar == ']')
			{
				DTDBuffer.append(curChar);
				DTDBuffer.append('\n');
				DTDBuffer.append('\n');
				break;
			}

			if (curChar != '\r')
				DTDBuffer.append(curChar);

			prevChar = curChar;
			curInt = fileReader.read();
			curChar = (char)curInt;
		}
	}

	void writeDTD(FileWriter fileWriter, StringBuffer DTDBuffer) 
													throws IOException
	{
		fileWriter.write(DTDBuffer.toString());
	}

	void writeHeader(FileWriter fileWriter) throws IOException
	{
		// get current date
		Calendar curCal = new java.util.GregorianCalendar();

		// milliseconds since Jan 1st 1970
		long ms = curCal.getTime().getTime();

		int year = curCal.get(Calendar.YEAR);
		int month = curCal.get(Calendar.MONTH) + 1;
		int day = curCal.get(Calendar.DAY_OF_MONTH);
		int hour = curCal.get(Calendar.HOUR_OF_DAY);
		int min = curCal.get(Calendar.MINUTE);
		int sec = curCal.get(Calendar.SECOND);

		StringBuffer createdDate = new StringBuffer("<created year=\""+ year +"\"");
		createdDate.append(" month=\"" +month+"\"");
		createdDate.append(" day=\"" + day + "\"");
		createdDate.append(" hour=\"" + hour +"\"");
		createdDate.append(" min=\"" + min + "\"");
		createdDate.append(" sec=\"" + sec + "\">");

		fileWriter.write("\t<header>\n");
		fileWriter.write("\t\t<ver>.9</ver>\n");

		fileWriter.write("\t\t" + createdDate + "\n");
		fileWriter.write("\t\t\t" + ms + "\n");
		fileWriter.write("\t\t</created>\n");
		fileWriter.write("\t\t<mstation>master.nmanage.com</mstation>\n");
		fileWriter.write("\t</header>\n");
	}

	void writeDTD(FileWriter fileWriter) throws IOException
	{

		fileWriter.write("<?xml version=\"1.0\"?>\n");
		fileWriter.write("<?XML-stylesheet type=\"text/xsl\" href=\"pollers.xsl\"?>\n");
		fileWriter.write("<!DOCTYPE dpollers [\n");
		fileWriter.write("<!ELEMENT	dpollers	(header, pollers)			>\n");
		fileWriter.write("<!ELEMENT	header	(ver, created, mstation)	>\n");
		fileWriter.write("<!ELEMENT	ver		(#PCDATA)				>\n");
		fileWriter.write("<!ELEMENT	mstation	(#PCDATA)				>\n");
		fileWriter.write("<!ELEMENT	created 	(#PCDATA)				>\n");
		fileWriter.write("<!ATTLIST	created year	CDATA	#REQUIRED\n");
		fileWriter.write("			month	CDATA	#REQUIRED\n");
		fileWriter.write("			day	CDATA	#REQUIRED\n");
		fileWriter.write("			hour	CDATA	#REQUIRED\n");
		fileWriter.write("			min	CDATA	#REQUIRED\n");
		fileWriter.write("			sec	CDATA	#REQUIRED			>\n");
		fileWriter.write("<!ELEMENT	pollers		(poller+)				>\n");
		fileWriter.write("<!ELEMENT	poller		(pollerID, pollerName, pollerIP, \n");
		fileWriter.write("				discLimit, pollerHost?, 	\n");
		fileWriter.write("					pollerComments, package+)>\n");
		fileWriter.write("<!ELEMENT	pollerID	(#PCDATA)				>\n");
		fileWriter.write("<!ELEMENT	pollerName	(#PCDATA)				>\n");
		fileWriter.write("<!ELEMENT	pollerIP	(#PCDATA)				>\n");
		fileWriter.write("<!ATTLIST	pollerIP	type	(int|hex|string) \"string\"	>\n");
		fileWriter.write("<!ELEMENT	discLimit	(#PCDATA)				>\n");
		fileWriter.write("<!ELEMENT	pollerHost	(#PCDATA)				>\n");
		fileWriter.write("<!ELEMENT	pollerComments	(#PCDATA)				>\n");
		fileWriter.write("<!ELEMENT	package		(#PCDATA)				>\n");
		fileWriter.write("]>\n\n");
	}

}

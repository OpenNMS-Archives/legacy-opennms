//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.admin.servmodel.panels;

import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;

import java.io.*;
import java.util.*;

import org.opennms.bb.eui.common.components.AboutDialog;
import org.opennms.bb.eui.admin.servmodel.utils.*;

/**
 * ServiceModelConfigPanel is the core panel for the 'ServiceModelConfig' 
 *
 * @author Sowmya
 *
 */

public class ServiceModelConfigPanel extends JPanel implements	ActionListener,
														ListSelectionListener,
												   		TableColumnModelListener
{ 
	JFrame			servModelFrame; 

	// status bar
	JLabel			statusLabel;

	ServiceModelsPanel 			servMPanel;
	ServiceModelBehaviourPanel	servMBPanel;

	/*
	 * XML TAGS
	 */
	final String MODELS		="models";
	final String MODEL		="model";
	final String MODELNAME	="modelName";
	final String MODELDESCR	="modelDescr";

	final String INTERVALS	="intervals";
	final String INTERVAL	="interval";
	final String BEGIN		="begin";
	final String END		="end";
	final String VALUE		="value";

	// user profile values
	final String XPOS		="xPos";
	final String YPOS		="yPos";
	final String WIDTH		="Width";
	final String HEIGHT		="Height";
	final String LOOKNFEEL	="lookAndFeel";

	// views level xml tags
	final String LABEL		="label";
	final String ENAME		="ename";
	final String EDESCR		="edescr";


	Vector		servicesData;

	int			iLastServiceSelected=-1;
	int			iServiceToDelete = -1;
	int			iServiceCopied	 = -1;

	boolean		bParseException=false;

	// menu items
	JMenuItem	copyMMenuItem, pasteMMenuItem, addMMenuItem, deleteMMenuItem;
	JMenuItem	copyMBMenuItem, pasteMBMenuItem, addMBMenuItem; 
	JMenuItem	deleteMBMenuItem, checkMBMenuItem;

	String		userID;

	// user profile related
	boolean					bLandFAtStartUp=true;
	Hashtable				userProfile;

	protected void ServiceModelConfigInit(JFrame frame, String userID)
	{
		// store the frame
		servModelFrame = frame;

		//
		this.userID = userID;

		// try parsing the data first
		ServiceModelsParser parser=null;

		try
		{
			parser=new ServiceModelsParser();
			parser.parse("data/common/conf/models.xml");

		} catch (Exception e)
		{
	 		JOptionPane.showMessageDialog(new JFrame(), 
					e.getMessage(),
					"Error! Unable to parse input xml file", 
					JOptionPane.ERROR_MESSAGE);

			bParseException = true;
		}

		if (bParseException)
		{
			handleWindowClose();
			return;
		}

		servicesData = parser.getServicesData();


		// get user profile
		readUserProfile();

		// set look and feel
		String landf = String.valueOf(userProfile.get(LOOKNFEEL));
		if (landf != null)
			handleMenuToolBarActions(landf);

		bLandFAtStartUp = false;

		// menu panel
		JPanel menuPanel = new JPanel();
		menuPanel.setLayout(new BorderLayout());

		// Create the menu
		JMenuBar servModelMenu = createMenu();
		menuPanel.add(servModelMenu, BorderLayout.NORTH);

		// create the panels
		Vector serviceTableData = extractServiceTableData();
		servMPanel = new ServiceModelsPanel(this, serviceTableData);

		Vector serviceMBData = extractServiceMBDataForService(0);
		servMBPanel = new ServiceModelBehaviourPanel(this, serviceMBData);

		JPanel actualPanel = new JPanel();
		actualPanel.setLayout(new GridLayout(0, 1));
		actualPanel.add(servMPanel);
		actualPanel.add(servMBPanel);

		// Create the status bar
		JLabel statusLabel = createStatusBar();

		setLayout(new BorderLayout());
		add(menuPanel, BorderLayout.NORTH);
		add(actualPanel, BorderLayout.CENTER);
		add(statusLabel, BorderLayout.SOUTH);

		// If we got here display frame
		servModelFrame.setVisible(true);

		// add table listselection listener
		servMPanel.getTable().getSelectionModel().addListSelectionListener(this);
		// listen to changes in column values
		servMPanel.getTable().getColumnModel().addColumnModelListener(this);
		servMBPanel.getTable().getColumnModel().addColumnModelListener(this);

		// Set user position/dimension preferences
		setUserPosDimPreferences();

	}
	
	/**
	 * Reads the user preferences from the user profile file
	 */
	protected void readUserProfile()
	{
		SMUserProfParser userProfParser=null;
		boolean	bUserProfileRead=true;

		String userxml = "data/users/" + userID + ".xml";

		// if file does not exist, just take defaults
		File userFile = new File(userxml);
		if (userFile.exists() && userFile.canRead())
		{
			// get user profile
			try
			{
				userProfParser = new SMUserProfParser();
				userProfParser.parse(userxml);
			}
			catch (Exception e)
			{
				// if the profile has an error, just prompt and continue
	 			JOptionPane.showMessageDialog(new JFrame(), 
					e.getMessage(),
					"Error! Unable to parse user profile file", 
					JOptionPane.ERROR_MESSAGE);

				bUserProfileRead = false;
			}
		}
		else
				bUserProfileRead = false;
		
		// 
		if (bUserProfileRead)
		{
			userProfile = userProfParser.getUserProfile();
			if (userProfile == null)
				userProfile = new Hashtable(5);
		}
		else
			userProfile = new Hashtable(5);
	}

	/**
	 * Sets the (x,y) and size preferences of the user
	 */
	protected void setUserPosDimPreferences()
	{
		// set the location of the frame
		Object xPos = userProfile.get(XPOS);
		Object yPos = userProfile.get(YPOS);
		if (xPos != null && yPos != null)
		{
			servModelFrame.setLocation(((Integer)xPos).intValue(), 
								((Integer)yPos).intValue());
		}
		else
			servModelFrame.setLocation(100, 100);

		// set the size
		Object width = userProfile.get(WIDTH);
		Object height = userProfile.get(HEIGHT);
		if (width != null && height != null)
		{
			setPreferredSize(new Dimension(((Integer)width).intValue(),
										  ((Integer)height).intValue()));
		}
		else
		{
			setPreferredSize(new Dimension(500, 600));
		
		}
	}


	/**
	 * Sets intial focus to first cell of the default panel
	 */
	public void handleWindowOpen()
	{
		if (bParseException)
			return;

		iLastServiceSelected =0;
		servMPanel.setInitialFocus();
	}

	/**
	 * Exits only if tabbedpane is clean
	 */
	public void handleWindowClose()
	{
		if (!bParseException)
		{
			servMPanel.requestFocus();
			handleExit();
		}
		else
		{
			servModelFrame.dispose();
		}
	}

	private void setStatus()
	{
		if (servMPanel.isTableChanged() || servMBPanel.isTableChanged())
			statusLabel.setText("Configuration Modified");
		else
			statusLabel.setText("Ready");
	}

	public ServiceModelConfigPanel(JFrame frame, String userID)
	{
		ServiceModelConfigInit(frame, userID);
	}

	/**
	 * Creates the menubar
	 */
	protected JMenuBar createMenu()
	{
		JMenuBar	servModelMenuBar;
		JMenu		servModelMenu;
		JMenuItem	menuItem;

		servModelMenuBar = new JMenuBar();

		// The file menu
		servModelMenu = new JMenu("File");
		servModelMenu.setMnemonic('F');
		servModelMenuBar.add(servModelMenu);

		menuItem = new JMenuItem("Save", KeyEvent.VK_S);
		menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S,
														ActionEvent.CTRL_MASK));
		menuItem.addActionListener(this);
		servModelMenu.add(menuItem);

		menuItem = new JMenuItem("Exit",  KeyEvent.VK_X);
		menuItem.addActionListener(this);
		servModelMenu.add(menuItem);

		// The Edit  menu
		servModelMenu = new JMenu("Edit");
		servModelMenu.setMnemonic('E');
		servModelMenuBar.add(servModelMenu);

		// Service Model 
		JMenu modelMenu = new JMenu("Service Model");
		modelMenu.setMnemonic(KeyEvent.VK_M);
		servModelMenu.add(modelMenu);

		copyMMenuItem = new JMenuItem("Copy",  KeyEvent.VK_C);
		copyMMenuItem.addActionListener(this);
		copyMMenuItem.setActionCommand("CopyM");
		modelMenu.add(copyMMenuItem);

		pasteMMenuItem = new JMenuItem("Paste",  KeyEvent.VK_P);
		pasteMMenuItem.addActionListener(this);
		pasteMMenuItem.setActionCommand("PasteM");
		modelMenu.add(pasteMMenuItem);

		addMMenuItem = new JMenuItem("Add",  KeyEvent.VK_A);
		addMMenuItem.addActionListener(this);
		addMMenuItem.setActionCommand("AddM");
		modelMenu.add(addMMenuItem);

		deleteMMenuItem = new JMenuItem("Delete",  KeyEvent.VK_D);
		deleteMMenuItem.addActionListener(this);
		deleteMMenuItem.setActionCommand("DeleteM");
		modelMenu.add(deleteMMenuItem);

		// Service Model Behaviour
		modelMenu = new JMenu("Service Model Behaviour");
		modelMenu.setMnemonic(KeyEvent.VK_M);
		servModelMenu.add(modelMenu);

		copyMBMenuItem = new JMenuItem("Copy",  KeyEvent.VK_C);
		copyMBMenuItem.addActionListener(this);
		copyMBMenuItem.setActionCommand("CopyMB");
		modelMenu.add(copyMBMenuItem);

		pasteMBMenuItem = new JMenuItem("Paste",  KeyEvent.VK_P);
		pasteMBMenuItem.setEnabled(false);
		pasteMBMenuItem.addActionListener(this);
		pasteMBMenuItem.setActionCommand("PasteMB");
		modelMenu.add(pasteMBMenuItem);

		addMBMenuItem = new JMenuItem("Add",  KeyEvent.VK_A);
		addMBMenuItem.addActionListener(this);
		addMBMenuItem.setActionCommand("AddMB");
		modelMenu.add(addMBMenuItem);

		deleteMBMenuItem = new JMenuItem("Delete",  KeyEvent.VK_D);
		deleteMBMenuItem.addActionListener(this);
		deleteMBMenuItem.setActionCommand("DeleteMB");
		modelMenu.add(deleteMBMenuItem);

		checkMBMenuItem = new JMenuItem("Check",  KeyEvent.VK_H);
		checkMBMenuItem.addActionListener(this);
		checkMBMenuItem.setActionCommand("CheckMB");
		modelMenu.add(checkMBMenuItem);

		// The Options  menu
		servModelMenu = new JMenu("Options");
		servModelMenu.setMnemonic('O');
		servModelMenuBar.add(servModelMenu);

		// Look and Feel
		JMenu lfMenu = new JMenu("Look And Feel");
		lfMenu.setMnemonic(KeyEvent.VK_L);
		lfMenu.addActionListener(this);
		servModelMenu.add(lfMenu);

        // Look and Feel Radio control
		ButtonGroup group = new ButtonGroup();
		JRadioButtonMenuItem radioMenuItem;

	    radioMenuItem = new JRadioButtonMenuItem("Metal");
		radioMenuItem.setSelected(
				UIManager.getLookAndFeel().getName().equals("Metal"));
		lfMenu.add(radioMenuItem);
		group.add(radioMenuItem);
		radioMenuItem.addActionListener(this);

        radioMenuItem = new JRadioButtonMenuItem("CDE/Motif");
		radioMenuItem.setSelected(
				UIManager.getLookAndFeel().getName().equals("CDE/Motif"));
		lfMenu.add(radioMenuItem);
		group.add(radioMenuItem);
		radioMenuItem.addActionListener(this);

        radioMenuItem = new JRadioButtonMenuItem("Windows");
		radioMenuItem.setSelected(
				UIManager.getLookAndFeel().getName().equals("Windows"));
		lfMenu.add(radioMenuItem);
		group.add(radioMenuItem);
		radioMenuItem.addActionListener(this);

		servModelMenuBar.add(Box.createHorizontalGlue());

		// The Help  menu
		servModelMenu = new JMenu("Help");
		servModelMenu.setMnemonic('H');
		servModelMenuBar.add(servModelMenu);

		menuItem = new JMenuItem("About",  KeyEvent.VK_A);
		menuItem.addActionListener(this);
		servModelMenu.add(menuItem);
		
		return servModelMenuBar;
	}

	/**
	 * Creates the statusbar
	 */
	protected JLabel createStatusBar()
	{
		statusLabel  = new JLabel();

		statusLabel.setText("Ready");
		statusLabel.setBorder(BorderFactory.createLoweredBevelBorder());
		statusLabel.setFont(new Font("Helvetica",Font.BOLD, 12));

		return statusLabel;
	}

	/**
	 * Listen to service model list selection changes
	 */
	public void valueChanged(ListSelectionEvent e)
	{
		ListSelectionModel lsm = (ListSelectionModel)e.getSource();
		if (!lsm.isSelectionEmpty())
		{
			servMPanel.enableAll();
			servMBPanel.enableAll();
			enableAll();

			// store where the user moved to
			int iSelRow = lsm.getLeadSelectionIndex();

			// check if the earlier service validated
			if (iLastServiceSelected != iServiceToDelete &&
				checkAutoFlow(iLastServiceSelected))
			{
				// update behaviour data for previous service
				updateServiceModelBehaviourForService(iLastServiceSelected);

				// display the new model and its behaviour
				servMPanel.selectService(iSelRow);
				setServiceModelBehaviourData(iSelRow);
				
				iLastServiceSelected = iSelRow;
			}

			else if (iLastServiceSelected == iServiceToDelete)
			{
				// if last row deleted, select previous row
				if (iLastServiceSelected == servMPanel.getRowCount())
					iLastServiceSelected --;

				if(iLastServiceSelected != -1)
					servMPanel.selectService(iLastServiceSelected);
			}

			else
			{
				// go back to last row
				servMPanel.selectService(iLastServiceSelected);
			}
		}
		else
		{
			disableAll();
			servMPanel.disableAll();
			servMBPanel.disableAll();

			// clear out the behaviour table
			setServiceModelBehaviourData(-1);
		}
	}

	/**
	 * Table(s) column selection listener 
	 */
	public void columnSelectionChanged(ListSelectionEvent e)
	{
		setStatus();
	}

	public void columnAdded(TableColumnModelEvent e) { }
	public void columnMoved(TableColumnModelEvent e) { }
	public void columnRemoved(TableColumnModelEvent e) { }
	public void columnMarginChanged(ChangeEvent e) { }

	/**
	 * Handles actions for all the menu items and the toolbar buttons
	 */
	public void actionPerformed(ActionEvent e)
	{
		String actionStr = e.getActionCommand();

		handleMenuToolBarActions(actionStr);
	}

	/**
	 * handlemenuToolBarAction() is called by the model and behaviour panels 
	 * when a edit to their tables should be reflected in the other panel and
	 * to update the central data
	 */
	public void handleMenuToolBarActions(String actionStr)
	{
		if (actionStr.equals("Save"))
		{
			boolean bRet = validateValuesInTables();
			if (bRet == false)
			{
				return;		// Do not save until values are valid
			}

			handleSave();
		}
		else if (actionStr.equals("Exit"))
		{
			handleExit();
		}

		else if (actionStr.equals("CopyM") ||
				 actionStr.equals("PasteM") ||
				 actionStr.equals("AddM") )
		{
			if (checkAutoFlow(iLastServiceSelected))
				handleServiceModelsAction(actionStr);
			
			setStatus();
		}

		else if (actionStr.equals("DeleteM"))
		{
			handleServiceModelsAction(actionStr);

			setStatus();
		}

		else if (actionStr.equals("CopyMB") ||
				 actionStr.equals("PasteMB") ||
				 actionStr.equals("AddMB") ||
				 actionStr.equals("DeleteMB") ||
				 actionStr.equals("CheckMB"))
		{
			handleServiceModelBehaviourAction(actionStr);

			setStatus();
		}


		else if (actionStr.equals("About"))
		{
			new AboutDialog(new JFrame(), "About BlueBird");
		}

		// options
		else if (actionStr.equals("Metal"))
		{
        	setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");
		}

		else if (actionStr.equals("CDE/Motif"))
		{
       		UIManager.put("Table.background", Color.white); 
       		UIManager.put("ScrollPane.background", Color.white); 
			setLookAndFeel("com.sun.java.swing.plaf.motif.MotifLookAndFeel");
		}

		else if (actionStr.equals("Windows"))
		{
			setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		}
	}

	private void setLookAndFeel(String str)
	{
	    setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));

		try 
		{

        	UIManager.setLookAndFeel(str);

			if (!bLandFAtStartUp)
			{
	   			SwingUtilities.updateComponentTreeUI(this);
			}

		} catch (Exception exc) 
		{
			System.err.println("can't get to the " + str + " look and feel");

			// try and go back to default
			try
			{
				UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
	   			SwingUtilities.updateComponentTreeUI(this);
			}
			catch (Exception e)
			{
				// Don't really do anything?
			}
		}

	   	setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
	}

	private void handleExit()
	{
		//  Check if the table content modifications are saved yet
		boolean bModelChanged = servMPanel.isTableChanged();
		boolean bModelBChanged = servMBPanel.isTableChanged();

		boolean bConfigChanged = bModelChanged | bModelBChanged;

		// Check if contents have been saved
		if (bConfigChanged == true)
		{

			Object[] options = {"Save and exit", "Exit without save", "Cancel"};

			int value = JOptionPane.showOptionDialog(this,
							"Changes to configurations have NOT been saved. Save now?",
							"SNMP Configuration Exit..",
							JOptionPane.YES_NO_CANCEL_OPTION,
							JOptionPane.QUESTION_MESSAGE,
							null,
							options,
							options[0]);


			if (value == JOptionPane.YES_OPTION)
			{
				boolean bRet = validateValuesInTables();
				if (bRet == false)
				{
					return;		// Do not save until duplicates are removed
				}

				handleSave();
			}
			else if (value == JOptionPane.CANCEL_OPTION)
			{
				// cancel exit
				return;
			}
			else if (value == JOptionPane.CLOSED_OPTION)
			{
				// Don't let the user bypass this dialog
				handleExit();
				return;
			}
		}

		// Save User Profile
		saveUserProfile();

		servModelFrame.dispose();

	}

	protected boolean validateValuesInTables()
	{
		boolean ret=false;

		// Check in the service model panel
		ret = servMPanel.validateValues();
		if (ret == false)
			return ret;

		// Check in the service model behaviour panel
		ret = servMBPanel.checkAutoFlow();
		if (ret == false)
			return ret;

		return true;
	}

	private void handleSave()
	{
		updateServiceModelNames();

		// Save into xml
		try
		{
			new ServiceModelsWriter(servicesData);
		}
		catch (Exception e)
		{
	 		JOptionPane.showMessageDialog(new JFrame(), 
					"Unable to save changes to xml file!\n" + e.getMessage(),
					"Error! ", 
					JOptionPane.ERROR_MESSAGE);

			return;
		}

		servMPanel.setTableSaved();
		servMBPanel.setTableSaved();

		statusLabel.setText("Ready");
	}

	/**
	 * <pre>Handles the storing of user preferences to the user profile 
	 * file. If the write into the profile file fails, the step is retried 
	 * thrice as a minimum mechanism to offset the possiblity of a different
	 * application currently writing into the profile
	 */
	protected void saveUserProfile()
	{
		// Update the userProfile Hashtable

		// position
		Integer xpos = new Integer(servModelFrame.getX());
		Integer ypos = new Integer(servModelFrame.getY());

		// dimension
		Dimension frameSize = servModelFrame.getSize();
		Integer width = new Integer(frameSize.width);
		Integer height = new Integer(frameSize.height);

		userProfile.put(XPOS, xpos);
		userProfile.put(YPOS, ypos);
		userProfile.put(WIDTH, width);
		userProfile.put(HEIGHT, height);

		// look and feel
		String landf = UIManager.getLookAndFeel().getName();
		userProfile.put(LOOKNFEEL, landf);
		
		boolean bNotWritten = true;
		int		iNumTries=0;

		while(bNotWritten && iNumTries < 3)
		{
			try
			{
				new SMUserProfWriter(userProfile, userID);
				bNotWritten = false;
			}
			catch (Exception e)
			{
				bNotWritten = true;
			}
			
			if (bNotWritten)
			{
				iNumTries++;

				try
				{
					Thread.sleep(300);
				}
				catch (InterruptedException ex) { }

			}
		}
	}

	public void disableAll()
	{
		copyMMenuItem.setEnabled(false);
		pasteMMenuItem.setEnabled(false);
		deleteMMenuItem.setEnabled(false);
	}

	public void enableAll()
	{
		if (!copyMMenuItem.isEnabled())	// check if disabled
		{
			copyMMenuItem.setEnabled(true);
			pasteMMenuItem.setEnabled(true);
			deleteMMenuItem.setEnabled(true);
		}
	}
	
	void handleServiceModelsAction(String actionStr)
	{
		if (actionStr.equals("AddM"))
		{
			servMPanel.handleAction(actionStr);
		
			servMBPanel.handleAction(actionStr);
			
			int iService = servMPanel.getSelectedService();
			addNewService(iService);
		}

		else if (actionStr.equals("CopyM"))
		{
			servMPanel.handleAction(actionStr);

			iServiceCopied = servMPanel.getSelectedService();
		}

		else if (actionStr.equals("PasteM"))
		{
			servMPanel.handleAction(actionStr);
			
			// extract data for the copied service and add a new copy
			pasteService();

		}

		else if (actionStr.equals("DeleteM"))
		{
			iServiceToDelete = servMPanel.getSelectedService();

			servMPanel.handleAction(actionStr);

			// remove from data
			deleteService(iServiceToDelete);
		
			int iService = servMPanel.getSelectedService();
			setServiceModelBehaviourData(iService);

			if (iService == -1)
			{
				servMPanel.disableAll();
				servMBPanel.disableAll();
				disableAll();
			}
			
			iServiceToDelete = -1;
		}
	}

	void handleServiceModelBehaviourAction(String actionStr)
	{
		servMBPanel.handleAction(actionStr);

		if (actionStr.equals("AddMB") || 
			actionStr.equals("PasteMB") ||
			actionStr.equals("DeleteMB"))
		{
			int iService = servMPanel.getSelectedService();
			updateServiceModelBehaviourForService(iService);
		}
	}
	
	/**
	 * Extracts the data for the services table from the servicesData
	 */
	Vector extractServiceTableData()
	{
		int iNumServices = servicesData.size();

		Vector serviceTableData = new Vector();

		for (int iIndex=0; iIndex<iNumServices; iIndex++)
		{
			Hashtable temp = (Hashtable)servicesData.elementAt(iIndex);

			String modName = (String)temp.get(MODELNAME);
			String modDescr = (String)temp.get(MODELDESCR);

			Vector tempSer = new Vector(2);
			tempSer.add(modName);
			tempSer.add(modDescr);
			
			serviceTableData.add(tempSer);
		}
		
		return serviceTableData;
	}

	/**
	 * Extract the service model behaviour for the service
	 */
	Vector extractServiceMBDataForService(int iService)
	{
		int iNumServices = servicesData.size();
		
		Vector behaviour=null;

		if (iService != -1 && iService < iNumServices)
		{
			Hashtable temp = (Hashtable)servicesData.elementAt(iService);

			return (Vector)temp.get(INTERVALS);
		}
		else
			return null;

	}

	/**
	 * Sets the behaviour data for the service selected
	 */
	void setServiceModelBehaviourData(int iSelRow)
	{
		Vector mb = extractServiceMBDataForService(iSelRow);
		servMBPanel.setTableData(mb);

		servMBPanel.setServiceName((String)getServiceName(iSelRow));
	}

	/**
	 * Updates the behaviour data for the service currently selected
	 */
	void updateServiceModelBehaviourForService(int iSelService)
	{
		if (iSelService == -1 || iSelService >= servicesData.size())
			return;
		
		else
		{
			// get to the services data row
			Hashtable temp = (Hashtable)servicesData.elementAt(iSelService);

			Vector behaviour = servMBPanel.getTableData();

			temp.put(INTERVALS, behaviour);
		}
	}

	/**
	 * Add a new service
	 */
	void addNewService(int iService)
	{
		Vector serviceData = servMPanel.getDataForService(iService);
		
		Hashtable temp = new Hashtable(3);
		temp.put(MODELNAME, serviceData.elementAt(0));
		temp.put(MODELDESCR, serviceData.elementAt(1));
		
		servicesData.add(iService, temp);
			
		updateServiceModelBehaviourForService(iService);
	}

	/**
	 * Delete a service
	 */
	void deleteService(int iService)
	{
		servicesData.remove(iService);
	}

	/**
	 * Paste service
	 */
	 void pasteService()
	 {
		// extract data for the copied service and add a new copy
		Hashtable temp = (Hashtable)servicesData.elementAt(iServiceCopied);

		Hashtable copyOfTemp = new Hashtable(3);
		copyOfTemp.put(MODELNAME, temp.get(MODELNAME));
		copyOfTemp.put(MODELDESCR, temp.get(MODELDESCR));
		copyOfTemp.put(INTERVALS, ((Vector)temp.get(INTERVALS)).clone());

		int iService = servMPanel.getSelectedService();
		servicesData.add(iService, copyOfTemp);

		setServiceModelBehaviourData(iService);

		servMPanel.selectService(0);
		servMPanel.selectService(iService);
	 }
	
	/**
	 * check if model behaviour is without holes
	 */
	boolean checkAutoFlow(int iService)
	{
		return servMBPanel.checkAutoFlow();
	}

	String getServiceName(int iService)
	{
		return servMPanel.getServiceName(iService);
	}

	void setServiceName(String serviceName)
	{
		servMBPanel.setServiceName(serviceName);
	}

	void updateServiceModelName(Object value, int row, int col)
	{
		Hashtable temp = (Hashtable)servicesData.elementAt(row);
		
		if (col == 1)
			temp.put(MODELNAME, value);
		else if (col == 2)
			temp.put(MODELDESCR, value);
	}
	
	void updateServiceModelNames()
	{
		Vector serviceModelNames = servMPanel.getTableData();
		
		int iNum = serviceModelNames.size();
		for(int iIndex=0; iIndex<iNum; iIndex++)
		{
			Hashtable temp = (Hashtable)servicesData.elementAt(iIndex);

			Vector serviceModel = (Vector)serviceModelNames.elementAt(iIndex);

			temp.put(MODELNAME, serviceModel.elementAt(0));
			temp.put(MODELDESCR, serviceModel.elementAt(1));
		}
	}
}


//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
package org.opennms.bb.eui.admin.UserGroupView.Parser;

import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
import org.w3c.dom.*;
import javax.swing.tree.DefaultMutableTreeNode;

import org.opennms.bb.eui.admin.UserGroupView.Main.UserManager;
import org.opennms.bb.eui.admin.UserGroupView.UserGroupViewMain;

class Category
{
	String _sName = null;
	String _sRule = null;
	String _sNormal = null;
	String _sWarning = null;

	Category()
	{
	}

	Category(String name, String rule, String normal, String warning)
	{
		_sName = name;
		_sRule = rule;
		_sNormal = normal;
		_sWarning = warning;
	}
}

class View
{
	String _sViewName = "";
	String _sViewTitle = "";
	String _sViewComments = "";
	Vector _vMembers = new Vector();
	Vector _vCategories = new Vector();

	public String toString()
	{
		return (_sViewName+":"+propertiesString());
	}

	public String propertiesString()
	{
		int iSize = _vMembers.size();
		String sProperties = "";

		for(int j = 0; j<_vCategories.size(); j++)
		{
			sProperties += ((Category)_vCategories.get(j))._sName+"$"+ ((Category)_vCategories.get(j))._sNormal+"$"+((Category)_vCategories.get(j))._sWarning+"$"+ ((Category)_vCategories.get(j))._sRule+"%";
		}
		sProperties += "!@#";
		if((_sViewTitle == null) || (_sViewTitle.trim().equals("")))
		{
			_sViewTitle = "(none)";
		}
		if((_sViewComments == null) || (_sViewComments.trim().equals("")))
		{
			_sViewComments = "(none)";
		}
		sProperties += _sViewTitle+":"+_sViewComments+":";

		for(int i = 0; i<iSize; i++)
		{
			sProperties += (String)_vMembers.get(i)+":";
		}
		return (sProperties);
	}
}

/**
 * @author Chitta Basu
 *
 * Modifications:
 * 04/18/00 - Changed the parser to account for ParserBase extending BBParser 
 *          - Sowmya
 *
 */
public class ViewParser extends ParserBase
{
	static FileWriter _oFileWriter = null;

	boolean _bViewName = false;
	boolean _bViewTitle = false;
	boolean _bViewComments = false;
	boolean _bMemberId = false;
	boolean _bLabel = false;
	boolean _bRule = false;
	boolean _bNormal = false;
	boolean _bWarning = false;

	static Vector _vViews = new Vector();

	public ViewParser()
	{
		super();
		_vViews = new Vector();
	}

	protected boolean processElement(Element el)
	{
		if(el.getTagName().equals("view"))
		{
			_vViews.add(new View());
		}
		else if(el.getTagName().equals("viewname"))
		{
			_bViewName = true;
			_bViewTitle = false;
			_bViewComments = false;
			_bMemberId = false;
			_bLabel = false;
			_bRule = false;
			_bNormal = false;
			_bWarning = false;
		}
		else if(el.getTagName().equals("viewTitle"))
		{
			_bViewName = false;
			_bViewTitle = true;
			_bViewComments = false;
			_bMemberId = false;
			_bLabel = false;
			_bRule = false;
			_bNormal = false;
			_bWarning = false;

		}
		else if(el.getTagName().equals("viewComments"))
		{
			_bViewName = false;
			_bViewTitle = false;
			_bViewComments = true;
			_bMemberId = false;
			_bLabel = false;
			_bRule = false;
			_bNormal = false;
			_bWarning = false;

		}
		else if(el.getTagName().equals("category"))
		{
			((View)_vViews.lastElement())._vCategories.add(new Category());
			//_vCategories.add(new Category());

			_bViewName = false;
			_bViewTitle = false;
			_bViewComments = false;
			_bMemberId = false;
			_bLabel = false;
			_bRule = false;
			_bNormal = false;
			_bWarning = false;

		}
		else if(el.getTagName().equals("member"))
		{
			_bViewName = false;
			_bViewTitle = false;
			_bViewComments = false;
			_bMemberId = true;
			_bLabel = false;
			_bRule = false;
			_bNormal = false;
			_bWarning = false;

		}
		else if(el.getTagName().equals("label"))
		{
			_bViewName = false;
			_bViewTitle = false;
			_bViewComments = false;
			_bMemberId = false;
			_bLabel = true;
			_bRule = false;
			_bNormal = false;
			_bWarning = false;

		}
		else if(el.getTagName().equals("rule"))
		{
			_bViewName = false;
			_bViewTitle = false;
			_bViewComments = false;
			_bMemberId = false;
			_bLabel = false;
			_bRule = true;
			_bNormal = false;
			_bWarning = false;

		}
		else if(el.getTagName().equals("normal"))
		{
			_bViewName = false;
			_bViewTitle = false;
			_bViewComments = false;
			_bMemberId = false;
			_bLabel = false;
			_bRule = false;
			_bNormal = true;
			_bWarning = false;
		}
		else if(el.getTagName().equals("warning"))
		{
			_bViewName = false;
			_bViewTitle = false;
			_bViewComments = false;
			_bMemberId = false;
			_bLabel = false;
			_bRule = false;
			_bNormal = false;
			_bWarning = true;
		}

		NodeList nl = el.getChildNodes();
		int size = nl.getLength();
		for(int i = 0;i < size;i++)
		{
			processNode(nl.item(i));
		}
		
		return true;
	}

	protected void processText(Text text)
	{
		String sText = text.getData();
		if(sText.trim().length() != 0)
		{
			if(_bViewName)
			{
				((View)_vViews.lastElement())._sViewName = sText;
			}
			else if(_bViewComments)
			{
				((View)_vViews.lastElement())._sViewComments = sText;
			}
			else if(_bViewTitle)
			{
				((View)_vViews.lastElement())._sViewTitle = sText;
			}
			else if(_bMemberId)
			{
				((View)_vViews.lastElement())._vMembers.add(sText);
			}
			else if(_bLabel)
			{
				((Category)(((View)_vViews.lastElement())._vCategories.lastElement()))._sName = sText;
			}
			/**
			else if(_bRule)
			{
				((Category)(((View)_vViews.lastElement())._vCategories.lastElement()))._sRule = sText;
			}
			**/
			else if(_bNormal)
			{
				((Category)(((View)_vViews.lastElement())._vCategories.lastElement()))._sNormal = sText;
			}
			else if(_bWarning)
			{
				((Category)(((View)_vViews.lastElement())._vCategories.lastElement()))._sWarning = sText;
			}
		}
	}

	protected void processCDATASection(CDATASection sData)
	{      
		if(_bRule)
		{
			((Category)(((View)_vViews.lastElement())._vCategories.lastElement()))._sRule = sData.getData();
		}
	}

	public static void load(String sFile)
	{
		ViewParser oParser = null;

		try
		{
			oParser = new ViewParser();
			oParser.parse(sFile);
		}
		catch (IOException e) 
		{
			System.err.println("Unable to parse views from file: " + sFile);
			return;
		}

		UserManager.m_oViews.clear();
		for(Enumeration e=oParser._vViews.elements(); e.hasMoreElements(); )
		{
			View tmp = (View)e.nextElement();
			UserManager.m_oViews.put(tmp._sViewName, tmp.propertiesString());
		}
	}

	public static void save(String sFile) throws IOException
	{
		_oFileWriter = new FileWriter(sFile);

		_oFileWriter.write("<?xml version=\"1.0\"?>\n");
		_oFileWriter.write("<!-- <?XML-stylesheet type=\"text/xsl\" href=\"iceberg.xsl\"?> -->\n");
		_oFileWriter.write("<!DOCTYPE viewinfo [\n");
		_oFileWriter.write("<!ELEMENT   viewinfo       (header, views)            >\n");
		_oFileWriter.write("<!ELEMENT   header          (ver, created, mstation)    >\n");
		_oFileWriter.write("<!ELEMENT   ver             (#PCDATA)                   >\n");
		_oFileWriter.write("<!ELEMENT   mstation        (#PCDATA)                   >\n");
		_oFileWriter.write("<!ELEMENT   created         (#PCDATA)                   >\n");
		_oFileWriter.write("<!ATTLIST   created year    CDATA  #REQUIRED\n");
		_oFileWriter.write("                    month   CDATA  #REQUIRED\n");
		_oFileWriter.write("                    day	    CDATA  #REQUIRED\n");
		_oFileWriter.write("                    hour    CDATA  #REQUIRED\n");
		_oFileWriter.write("                    min	    CDATA  #REQUIRED\n");
		_oFileWriter.write("                    sec	    CDATA  #REQUIRED            >\n");
		_oFileWriter.write("<!ELEMENT   views          (view+)                    >\n");
		_oFileWriter.write("<!ELEMENT   view           (viewname, viewTitle, viewComments?,  \n");
		_oFileWriter.write("                            categories?, membership?)               >\n");
		_oFileWriter.write("<!ELEMENT   viewname       (#PCDATA)                   >\n");
		_oFileWriter.write("<!ELEMENT   viewTitle      (#PCDATA)                   >\n");
		_oFileWriter.write("<!ELEMENT   viewComments   (#PCDATA)                   >\n");
		_oFileWriter.write("<!ELEMENT   categories     (category+)                 >\n");
		_oFileWriter.write("<!ELEMENT   category       (label, rule, normal, warning)               >\n");
		_oFileWriter.write("<!ELEMENT   label          (#PCDATA)                   >\n");
		_oFileWriter.write("<!ELEMENT   rule           (#PCDATA)                   >\n");
		_oFileWriter.write("<!ELEMENT   normal	       (#PCDATA)		   >\n");
		_oFileWriter.write("<!ELEMENT   warning	       (#PCDATA)		   >\n");	
		_oFileWriter.write("<!ELEMENT   membership     (member+)                   >\n");
		_oFileWriter.write("<!ELEMENT   member         (#PCDATA)                   >\n");
		_oFileWriter.write("]>\n\n");

		_oFileWriter.write("<viewinfo>\n");

		_oFileWriter.write("        <header>\n");
		{
			_oFileWriter.write("	       <ver>"+UserManager.m_sVersion+"</ver>\n");

			Calendar oCalendar = new GregorianCalendar();
			_oFileWriter.write("	       <created "
							+"year=\""+oCalendar.get(oCalendar.YEAR)
							  +"\" month=\""+(1+oCalendar.get(oCalendar.MONTH))
							  +"\" day=\""+oCalendar.get(oCalendar.DAY_OF_MONTH)
							  +"\" hour=\""+oCalendar.get(oCalendar.HOUR)
							  +"\" min=\""+oCalendar.get(oCalendar.MINUTE)
							  +"\" sec=\""+oCalendar.get(oCalendar.SECOND)
							  +"\">\n");
			_oFileWriter.write("			76625255\n");
			_oFileWriter.write("	       </created>\n");
			_oFileWriter.write("	       <mstation>"+UserManager.m_sMsStation+"</mstation>\n");
		}
		_oFileWriter.write("        </header>\n");

		_oFileWriter.write("        <views>\n");
		{
			for(Enumeration e=UserManager.m_oViews.keys(); e.hasMoreElements(); )
			{
				_oFileWriter.write("            <view>\n");
				String sId = (String)e.nextElement();

				_oFileWriter.write("                <viewname>"+sId+"</viewname>\n");
				StringTokenizer oTokenizer = new StringTokenizer((String)UserManager.m_oViews.get(sId),":");
				_oFileWriter.write("                <viewTitle>"+oTokenizer.nextToken()+"</viewTitle>\n");
				_oFileWriter.write("                <viewComments>"+oTokenizer.nextToken()+"</viewComments>\n");

				_oFileWriter.write("                <categories>\n");

				String sRuleCats = (String)UserManager.m_oRules.get(sId);
				oTokenizer = new StringTokenizer(sRuleCats,"%");

				//sRuleBuffer.substring(iCutOff+1, sRuleBuffer.length())

				for(;oTokenizer.hasMoreTokens(); )
				{
					_oFileWriter.write("                    <category>\n");

					String sRuleBuffer = oTokenizer.nextToken();
					StringTokenizer st = new StringTokenizer(sRuleBuffer, "$");
					String common = st.nextToken();
					String normal = st.nextToken();
					String warning = st.nextToken();
					String rule = st.nextToken();

					int iCutOff = sRuleBuffer.indexOf("$");
					_oFileWriter.write("                        <label>"
									   +sRuleBuffer.substring(0,iCutOff)
									   +"</label>\n");
					_oFileWriter.write("                        <normal>"
									   +normal
									   +"</normal>\n");
					_oFileWriter.write("                        <warning>"
									   +warning
									   +"</warning>\n");
					_oFileWriter.write("                        <rule>"

									   +"<![CDATA["
									   + rule
									   +"]]>"
									   +"</rule>\n");
					_oFileWriter.write("                    </category>\n");
				}
				_oFileWriter.write("                </categories>\n");

				DefaultMutableTreeNode oViews	= (DefaultMutableTreeNode)UserGroupViewMain.m_oViewsTree.getModel().getRoot();
				if(!oViews.isLeaf())
				{
					DefaultMutableTreeNode tmp = null;
					for(Enumeration en=oViews.children(); en.hasMoreElements(); )
					{
						tmp = (DefaultMutableTreeNode)en.nextElement();
						if(sId.equals(tmp.toString()))
						{
							break;
						}
						tmp = null;
					}
					if((tmp!=null) && !tmp.isLeaf())
					{
						_oFileWriter.write("                <membership>\n");
						for(Enumeration en2=tmp.children(); en2.hasMoreElements(); )
						{
							_oFileWriter.write("                    <member>"+((DefaultMutableTreeNode)en2.nextElement()).toString()+"</member>\n");
						}
						_oFileWriter.write("                </membership>\n");
					}
				}
				_oFileWriter.write("            </view>\n");
			}
		}
		_oFileWriter.write("	   </views>\n");

		_oFileWriter.write("</viewinfo>\n");
		_oFileWriter.flush();
	}

}

//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.admin.servmodel.utils;

import java.io.*;
import java.util.Vector;
import java.util.Hashtable;
import java.util.Calendar;

/**
 * <pre>ServiceModelsWriter creates a 'serviceModels' xml file using the data
 * passed in
 *
 * It throws an IOException if the xml file is not accesible or if there
 * are any errors while writing into the file <pre>
 *
 * @author Sowmya
 *
 */
public class ServiceModelsWriter 
{
	Vector	servicesData;

	final String SERVICE_MODELS		="<serviceModels>\n";
	final String SERVICE_MODELS_CLS	="</serviceModels>\n";

	final String MODELS			="\t<models>\n";
	final String MODELS_CLS		="\t</models>\n";

	final String MODEL 			="\t\t<model>\n";
	final String MODEL_CLS		="\t\t</model>\n";

	final String MODEL_NAME		="\t\t\t<modelName>";
	final String MODEL_NAME_CLS	="</modelName>\n";

	final String MODEL_DESCR	="\t\t\t<modelDescr>";
	final String MODEL_DESCR_CLS="</modelDescr>\n";

	final String INTERVALS		="\t\t\t<intervals>\n";
	final String INTERVALS_CLS	="\t\t\t</intervals>\n";

	final String INTERVAL		="\t\t\t\t<interval>\n";
	final String INTERVAL_CLS	="\t\t\t\t</interval>\n";

	final String BEGIN			="\t\t\t\t\t<begin>";
	final String BEGIN_CLS		="</begin>\n";

	final String END			="\t\t\t\t\t<end>";
	final String END_CLS		="</end>\n";

	final String VALUE			="\t\t\t\t\t<value>";
	final String VALUE_CLS		="</value>\n";

	final String MODEL_NAME_STR	="modelName";
	final String MODEL_DESCR_STR="modelDescr";
	final String INTERVALS_STR	="intervals";
	final String REMOVE_STR		="<remove>";

	/**
 	 * Writes into the standard file 'models.xml'
 	 */
	public ServiceModelsWriter(Vector inpServicesData) throws IOException
	{
		servicesData   = inpServicesData;

		writeInto("data/common/conf/models.xml");
	}

	/**
 	 * Writes into the filename passed in
 	 */
	public ServiceModelsWriter(String filename, Vector inpServicesData) 
														throws IOException
	{
		servicesData   = inpServicesData;

		writeInto(filename);
	}

	private void writeInto(String fileName) throws IOException
	{
		FileReader fileReader;
		FileWriter fileWriter;

		boolean bReadDTD=true;
		StringBuffer DTDBuffer=new StringBuffer();

		try
		{
			fileReader = new FileReader(fileName);
			readDTD(fileReader, DTDBuffer);

		} catch (IOException e)
		{
			e.printStackTrace();

			bReadDTD = false;
		}

		fileWriter = new FileWriter(fileName);
			
		// write the DTD first
		if (!bReadDTD)
			writeDTD(fileWriter);
		else
			writeDTD(fileWriter, DTDBuffer);

		fileWriter.write(SERVICE_MODELS);

		// now the header..
		writeHeader(fileWriter);

		// models
		writeModels(fileWriter); 

		fileWriter.write(SERVICE_MODELS_CLS);

		fileWriter.flush();

	}

	void readDTD(FileReader fileReader, StringBuffer DTDBuffer) 
													throws IOException
	{
		int curInt = fileReader.read();
		char curChar = (char)curInt;
		char prevChar = curChar;

		while ( curInt != -1)
		{
			if (curChar == '>' && prevChar == ']')
			{
				DTDBuffer.append(curChar);
				DTDBuffer.append('\n');
				DTDBuffer.append('\n');
				break;
			}

			if (curChar != '\r')
				DTDBuffer.append(curChar);

			prevChar = curChar;
			curInt = fileReader.read();
			curChar = (char)curInt;
		}
	}

	void writeDTD(FileWriter fileWriter, StringBuffer DTDBuffer) 
													throws IOException
	{
		fileWriter.write(DTDBuffer.toString());
	}

	void writeHeader(FileWriter fileWriter) throws IOException
	{
		// get current date
		Calendar curCal = new java.util.GregorianCalendar();

		// milliseconds since Jan 1st 1970
		long ms = curCal.getTime().getTime();

		int year = curCal.get(Calendar.YEAR);
		int month = curCal.get(Calendar.MONTH) + 1;
		int day = curCal.get(Calendar.DAY_OF_MONTH);
		int hour = curCal.get(Calendar.HOUR_OF_DAY);
		int min = curCal.get(Calendar.MINUTE);
		int sec = curCal.get(Calendar.SECOND);

		StringBuffer createdDate = new StringBuffer("<created year=\""+ year +"\"");
		createdDate.append(" month=\"" +month+"\"");
		createdDate.append(" day=\"" + day + "\"");
		createdDate.append(" hour=\"" + hour +"\"");
		createdDate.append(" min=\"" + min + "\"");
		createdDate.append(" sec=\"" + sec + "\">");

		fileWriter.write("\t<header>\n");
		fileWriter.write("\t\t<ver>.9</ver>\n");

		fileWriter.write("\t\t" + createdDate + "\n");
		fileWriter.write("\t\t\t" + ms + "\n");
		fileWriter.write("\t\t</created>\n");
		fileWriter.write("\t\t<mstation>master.nmanage.com</mstation>\n");
		fileWriter.write("\t</header>\n");
	}


	void writeModels(FileWriter fileWriter) throws IOException
	{
		int iNumServices = servicesData.size();

		fileWriter.write(MODELS);

		for (int iIndex=0; iIndex < iNumServices; iIndex++)
		{
			fileWriter.write(MODEL);

			Hashtable temp = (Hashtable)servicesData.elementAt(iIndex);

			String modelName = (String)temp.get(MODEL_NAME_STR);
			String modelDescr = (String)temp.get(MODEL_DESCR_STR);

			fileWriter.write(MODEL_NAME + modelName + MODEL_NAME_CLS);
			fileWriter.write(MODEL_DESCR + modelDescr + MODEL_DESCR_CLS);

			Vector intervals = (Vector)temp.get(INTERVALS_STR);
			int iNumIntervals=intervals.size();

			fileWriter.write(INTERVALS);

			for (int iIntIndex=0; iIntIndex < iNumIntervals; iIntIndex++)
			{
				fileWriter.write(INTERVAL);

				Vector interval = (Vector)intervals.elementAt(iIntIndex);

				String begin = (String)interval.elementAt(0);
				String end	 = (String)interval.elementAt(1);
				String beha	 = (String)interval.elementAt(2);

				// begin
				fileWriter.write(BEGIN + begin + BEGIN_CLS);

				// end
				if (!(end.equals("-")))
					fileWriter.write(END + end + END_CLS);

				// behaviour
				if (beha.equals(REMOVE_STR))
					fileWriter.write(VALUE + "<![CDATA[" + REMOVE_STR + "]]>" + VALUE_CLS);
				else
					fileWriter.write(VALUE + beha + VALUE_CLS);

				fileWriter.write(INTERVAL_CLS);
			}

			fileWriter.write(INTERVALS_CLS);

			fileWriter.write(MODEL_CLS);
		}

		fileWriter.write(MODELS_CLS);
	}

	void writeDTD(FileWriter fileWriter) throws IOException
	{
		fileWriter.write("<?xml version=\"1.0\"?>\n\n");
		fileWriter.write("<?XML-stylesheet type=\"text/xsl\" href=\"models.xsl\"?>\n");
		fileWriter.write("<!DOCTYPE serviceModels [\n");
		fileWriter.write("<!ELEMENT	serviceModels		(header, default, ranges, specifics, urls)		>\n");
		fileWriter.write("<!ELEMENT	header		(ver, created, mstation)	>\n");
		fileWriter.write("<!ELEMENT	ver		(#PCDATA)				>\n");
		fileWriter.write("<!ELEMENT	mstation	(#PCDATA)				>\n");
		fileWriter.write("<!ELEMENT	created 	(#PCDATA)				>\n");
		fileWriter.write("<!ATTLIST	created year	CDATA	#REQUIRED\n");
		fileWriter.write("			month	CDATA	#REQUIRED\n");
		fileWriter.write("			day	CDATA	#REQUIRED\n");
		fileWriter.write("			hour	CDATA	#REQUIRED\n");
		fileWriter.write("			min	CDATA	#REQUIRED\n");
		fileWriter.write("			sec	CDATA	#REQUIRED			>\n");
		fileWriter.write("<!ELEMENT	models		(model+)				>\n");
		fileWriter.write("<!ELEMENT	model		(modelName,modelDescr,intervals)			>\n");
		fileWriter.write("<!ELEMENT	modelName		(#PCDATA)				>\n");
		fileWriter.write("<!ELEMENT	modelDescr		(#PCDATA)				>\n");
		fileWriter.write("<!ELEMENT	intervals		(interval+)				>\n");
		fileWriter.write("<!ELEMENT	interval		(begin,end?,value)			>\n");
		fileWriter.write("<!ELEMENT	begin		(#PCDATA)				>\n");
		fileWriter.write("<!ELEMENT	end		(#PCDATA)				>\n");
		fileWriter.write("<!ELEMENT	value		(#PCDATA)				>\n");
		fileWriter.write("<!ATTLIST	value		type (string|int) \"string\"	>\n");
		fileWriter.write("\n]>\n\n");

	}

}

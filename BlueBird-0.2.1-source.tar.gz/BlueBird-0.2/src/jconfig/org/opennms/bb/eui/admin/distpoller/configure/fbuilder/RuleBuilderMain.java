//-------------------------------------------------------------------------------------------
//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

//--------------------------------------------------------------------------------------------

package org.opennms.bb.eui.admin.distpoller.configure.fbuilder;

import java.util.Vector;
import java.util.Enumeration;
import javax.swing.JTabbedPane;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.tree.*;
import java.awt.dnd.*;
import java.awt.*;
import java.awt.event.*;

import org.opennms.bb.eui.common.components.*;
import org.opennms.bb.eui.admin.distpoller.configure.dpconf.UserManager;
import org.opennms.bb.eui.admin.distpoller.configure.dpconf.BlueObject;
import org.opennms.bb.eui.admin.UserGroupView.RuleBuilder.RuleResultsDialog;

/**
 *
 * Modifications:
 * 10/5/2000 - Added a button to test the rule and display the results. Called
 *             "Test rule" and appears next to "Redo Layout".
 *             Changed the hard coded custom and template rules to match the
 *             new expression format. The custom and template rules should be
 *             read from a persistent store and not be hard coded. - Jason
 *
 * Changed the deprecated 'getComponentAtIndex(int i)' method of 'JPopupMenu'
 * to 'getComponent(int i)' for the move to JDK 1.3 - Sowmya

   @author <A HREF="http://www.opennms.org/">OpenNMS</A>
   @version $Revision: 1.13 $
 */
public class RuleBuilderMain extends JDialog
{
    RuleDragDropTree	m_oCustomTree	  = null;
    RuleDragTree	m_oTemplateTree	  = null;
    JTabbedPane		m_oTabbedPane	  = new JTabbedPane();
    RuleAreaPanel 	m_oDrawPanel	  = null;
    JTextField		m_oStatusText	  = new JTextField();
    TreeSelectionModel	m_oSelectionModel = null;
    JPopupMenu		m_oPopup	  = null;
    JPopupMenu		m_oPopupTab	  = null;
    MouseListener	m_oPopupListener  = new PopupListener();
    JTextField          oTextRule         = new JTextField();

    DropTarget oDropTarget = new DropTarget(null, DnDConstants.ACTION_COPY_OR_MOVE, null, true);
    
    /**Constructor that builds a new rule builder screen populated with a 
       new expression rule.
       @param String sRule, a rule to be put into the graphical area of the
                            new screen.
     */
    public RuleBuilderMain(String sRule)
    {
	setSize(650,600);
	setModal(true);
	
	addMenuBar();
	
	//build the uppermost panel where the prepopulated rule trees live
	JPanel treePanel = new JPanel();
	treePanel.setLayout(new BoxLayout(treePanel, BoxLayout.X_AXIS));
	treePanel.setBorder(BorderFactory.createEmptyBorder(0, 10, 10, 10));
	treePanel.add(loadCustomRules());
	treePanel.add(Box.createRigidArea(new Dimension(10, 0)));
	treePanel.add(loadTemplateRules());
	
	getContentPane().add(treePanel, BorderLayout.NORTH);
	getContentPane().add(newTabPanel(sRule), BorderLayout.CENTER);
	getContentPane().add(addStatusBar(), BorderLayout.SOUTH);
	
	addPopupMenu();
	addKeyListener(new KeyAdapter()
	               {
			   public void keyPressed(KeyEvent e)
			   {
			       if(e.getKeyCode() == KeyEvent.VK_DELETE)
			       {
				   cut();
			       }
			   }
	               });
	
	m_oSelectionModel = m_oCustomTree.getSelectionModel();
	m_oCustomTree.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
	m_oTemplateTree.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
	
	m_oCustomTree.addTreeSelectionListener(new TreeSelectionListener()
	                                       {
						   public void valueChanged(TreeSelectionEvent e)
						   {
						       if( m_oSelectionModel != m_oCustomTree.getSelectionModel())
						       {
							   m_oSelectionModel.clearSelection();
							   m_oSelectionModel = m_oCustomTree.getSelectionModel();
						       }
						   }
	                                        });
	
	m_oTemplateTree.addTreeSelectionListener(new TreeSelectionListener()
						 {
						     public void valueChanged(TreeSelectionEvent e)
						     {
							 if( m_oSelectionModel != m_oTemplateTree.getSelectionModel())
							     {
								 m_oSelectionModel.clearSelection();
								 m_oSelectionModel = m_oTemplateTree.getSelectionModel();
							     }
						     }
	                                          });
	
	setTitle("Filter Rule Builder");
    }
    
    public void update(Graphics g)
    {
	((DefaultTreeCellRenderer)m_oCustomTree.getCellRenderer()).setBackground(java.awt.Color.lightGray);
	((DefaultTreeCellRenderer)m_oCustomTree.getCellRenderer()).setBackgroundNonSelectionColor(java.awt.Color.lightGray);
	((DefaultTreeCellRenderer)m_oTemplateTree.getCellRenderer()).setBackground(java.awt.Color.lightGray);
	((DefaultTreeCellRenderer)m_oTemplateTree.getCellRenderer()).setBackgroundNonSelectionColor(java.awt.Color.lightGray);
	
	super.update(g);
    }

    class PopupListener extends MouseAdapter implements ActionListener
    {
	private int x = -1, y = -1;
	private Object m_oSource = null;
	
	public void actionPerformed(ActionEvent e)
	{
	    if(e.getActionCommand().equals("Cut"))
	    {
		cut();
	    }
	    else if(e.getActionCommand().equals("Copy"))
	    {
		copy();
	    }
	    else if(e.getActionCommand().equals("Paste"))
	    {
		paste();
	    }
	    else if(e.getActionCommand().equals("Modify"))
	    {
		TreePath oPath =  m_oSelectionModel.getSelectionPath();
		if(oPath.getPathCount() < 1)
		{
		    return;
		}
				//if(m_oSelectionModel == m_oCustomTree.getSelectionModel())
		if(m_oSource == m_oCustomTree)
		{
		    m_oCustomTree.setEditable(true);
		    m_oCustomTree.startEditingAtPath(oPath);
		}
				//else if(m_oSelectionModel == m_oTemplateTree.getSelectionModel())
		else if(m_oSource == m_oTemplateTree)
		{
		    m_oTemplateTree.setEditable(true);
		    m_oTemplateTree.startEditingAtPath(oPath);
		}
	    }
	}
	
	public void mousePressed(MouseEvent e)
	{
	    if(m_oCustomTree.isEditable())
	    {
		if(m_oCustomTree.isEditing())
		{
		    m_oCustomTree.stopEditing();
		}
		m_oCustomTree.setEditable(false);
	    }
	    else if(m_oTemplateTree.isEditable())
	    {
		if(m_oTemplateTree.isEditing())
		{
		    m_oTemplateTree.stopEditing();
		}
		m_oTemplateTree.setEditable(false);
	    }
	    popupAction(e);
	}
	
	public void mouseReleased(MouseEvent e)
	{
	    popupAction(e);
	}
	
	void popupAction(MouseEvent e)
	{
	    if (e.isPopupTrigger())
	    {
		Point pLocation	= new Point(e.getX(),e.getY());
		boolean bPopup = false;
		
		if(e.getSource() == m_oTabbedPane)
		{
		    if(m_oTabbedPane.getSelectedIndex()==0)
		    {
			m_oPopupTab.getComponent(1).setEnabled(false);
			m_oPopupTab.getComponent(2).setEnabled(false);
		    }
		    else
		    {
			m_oPopupTab.getComponent(1).setEnabled(true);
			m_oPopupTab.getComponent(2).setEnabled(true);
		    }
		    m_oPopupTab.show((Component)e.getSource(),
				     e.getX(),
				     e.getY());
		}
		else if(e.getSource() == m_oCustomTree)
		{
		    m_oSource = m_oCustomTree;
		    DefaultMutableTreeNode	oTreeNode = m_oCustomTree.getTreeNode(pLocation);
		    if(oTreeNode != null)
		    {
			bPopup = true;
			((DefaultTreeSelectionModel)m_oCustomTree.getSelectionModel()).clearSelection();
			((DefaultTreeSelectionModel)m_oCustomTree.getSelectionModel()).setSelectionPath(new TreePath(oTreeNode.getPath()));
		    }
		}
		else if(e.getSource() == m_oTemplateTree)
		{
		    m_oSource = m_oTemplateTree;
		    DefaultMutableTreeNode	oTreeNode = m_oTemplateTree.getTreeNode(pLocation);
		    if(oTreeNode != null)
		    {
			bPopup = true;
			((DefaultTreeSelectionModel)m_oTemplateTree.getSelectionModel()).clearSelection();
			((DefaultTreeSelectionModel)m_oTemplateTree.getSelectionModel()).setSelectionPath(new TreePath(oTreeNode.getPath()));
		    }
		}
		
		if(bPopup)
		{
		    x = e.getX();
		    y = e.getY();
		    m_oSource = e.getSource();
		    if(UserManager.m_sEditBuffer == null)
		    {
			m_oPopup.getComponent(2).setEnabled(false);
		    }
		    else
		    {
			m_oPopup.getComponent(2).setEnabled(true);
		    }
		    m_oPopup.show((Component)e.getSource(),
				  e.getX(),
				  e.getY());
		}
	    }
	}
    }
    
    /**This method builds the panel that holds the controls
       used to both graphically and textually build a new rule.
       @param String sText, a rule to be put into the graphical area
     */
    protected JPanel newTabPanel(String sText)
    {
	JPanel oPanel = new JPanel();
	oPanel.setDropTarget(null);
	oPanel.addMouseListener(null);
	
	//build the button to redraw the graphical area
	JButton oRedoButton = new JButton("Redo Layout");
	oRedoButton.setFont(new Font("Dialog", Font.BOLD, 11));
	oPanel.add(oRedoButton, BorderLayout.SOUTH);
	oRedoButton.addActionListener(new RuleLearner());
	
	//build the button to test the rule
	JButton testButton = new JButton("Test Rule");
	testButton.setFont(new Font("Dialog", Font.BOLD, 11));
	testButton.addActionListener(new ActionListener()
	    {
		/**This method calls the dialog box responsible for displaying the results
		   of an expression rule. The rule is taken from the m_oRule text field.
		   The RuleResutlsDialog is opened to be non modal so several rules can
		   be compared.
		*/
		public void actionPerformed(ActionEvent e)
		{
		    //need semi colon to terminat a rule
		    (new RuleResultsDialog(true, "Results", oTextRule.getText()+";")).setVisible(true);
		}
	    }); 
	
	//build the text box to enable a user to enter a new rule,
	JLabel oRuleLabel = new JLabel();
	oRuleLabel.setText("Text Rule:");
	oRuleLabel.setFont(new Font("Courier", Font.PLAIN, 11));
	
	//add the new rule to the text box
	oTextRule.setBorder(BorderFactory.createLoweredBevelBorder());
	oTextRule.setText(sText);
	
	JPanel flowPanel = new JPanel();
	flowPanel.setLayout(new BoxLayout(flowPanel, BoxLayout.X_AXIS));
	flowPanel.setBorder(BorderFactory.createEmptyBorder(0, 10, 10, 10));
	flowPanel.add(oRuleLabel);
	flowPanel.add(Box.createRigidArea(new Dimension(5, 0)));
	flowPanel.add(oTextRule);
	flowPanel.add(Box.createRigidArea(new Dimension(5,0)));
	flowPanel.add(testButton);
	flowPanel.add(Box.createRigidArea(new Dimension(5,0)));
	flowPanel.add(oRedoButton);
	
	m_oDrawPanel= new RuleAreaPanel(oTextRule);
	
	m_oDrawPanel.setBackground(java.awt.Color.white);
	
	JScrollPane oDrawScrollPane = new JScrollPane(m_oDrawPanel,
						      JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
						      JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED );
	
	oDrawScrollPane.setPreferredSize(new Dimension(422,295));
	oPanel.setPreferredSize(new Dimension(400,200));
	m_oDrawPanel.setPreferredSize(new Dimension(1000,1000));
	
	oPanel.setLayout(new BorderLayout());
	oPanel.add(oDrawScrollPane, BorderLayout.CENTER);
	oPanel.add(flowPanel, BorderLayout.SOUTH);
	
	return oPanel;
    }
    
    class RuleLearner implements ActionListener
    {
	public void actionPerformed(ActionEvent e)
	{
	    m_oDrawPanel.save();
	}
    }
    
    public void dragEnter(DropTargetDragEvent e)
    {
	e.acceptDrag(DnDConstants.ACTION_COPY_OR_MOVE);
    }
    
    public void dragExit(DropTargetEvent e)
    {
    }
    
    public void dragOver(DropTargetDragEvent e)
    {
	e.acceptDrag(DnDConstants.ACTION_COPY_OR_MOVE);
    }
    
    public void dropActionChanged(DropTargetDragEvent e)
    {
	e.acceptDrag(DnDConstants.ACTION_COPY_OR_MOVE);
    }
    
    private void addMenuBar()
    {
	JMenuBar	oMainMenuBar		= new JMenuBar();
	JMenu		oFileMenu		= new JMenu();
	JMenu		oEditMenu		= new JMenu();
	JMenu		oHelpMenu		= new JMenu();
	JMenu		oViewMenu		= new JMenu();
	JMenu		oLnFMenu		= new JMenu();
	JMenuItem	oExitMenuItem		= new JMenuItem();
	JMenuItem	oCutMenuItem		= new JMenuItem();
	JMenuItem	oCopyMenuItem		= new JMenuItem();
	JMenuItem	oPasteMenuItem		= new JMenuItem();
	JMenuItem	oLnFSubMenu1		= new JMenuItem();
	JMenuItem	oLnFSubMenu2		= new JMenuItem();
	JMenuItem	oLnFSubMenu3		= new JMenuItem();
	JMenuItem	oAboutMenuItem		= new JMenuItem();
	
	oFileMenu.setText("File");
	oFileMenu.setMnemonic('F');
	oMainMenuBar.add(oFileMenu);
	oExitMenuItem.setText("Close");
	oExitMenuItem.setActionCommand("Close");
	oExitMenuItem.setMnemonic('e');
	oFileMenu.add(oExitMenuItem);
	oExitMenuItem.addActionListener(new MenuBarListener());
	oEditMenu.setText("Edit");
	oEditMenu.setMnemonic('E');
	oMainMenuBar.add(oEditMenu);
	oCutMenuItem.setText("Cut");
	oCutMenuItem.setActionCommand("Cut");
	oCutMenuItem.setMnemonic('C');
	oCutMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X,Event.CTRL_MASK ));
	oEditMenu.add(oCutMenuItem);
	oCutMenuItem.addActionListener(new MenuBarListener());
	oCopyMenuItem.setText("Copy");
	oCopyMenuItem.setActionCommand("Copy");
	oCopyMenuItem.setMnemonic('o');
	oCopyMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C,Event.CTRL_MASK ));
	oEditMenu.add(oCopyMenuItem);
	oCopyMenuItem.addActionListener(new MenuBarListener());
	oPasteMenuItem.setText("Paste");
	oPasteMenuItem.setActionCommand("Paste");
	oPasteMenuItem.setMnemonic('P');
	oPasteMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_V,Event.CTRL_MASK ));
	oEditMenu.add(oPasteMenuItem);
	oPasteMenuItem.addActionListener(new MenuBarListener());
	
	oViewMenu.setText("View");
	oViewMenu.setActionCommand("View");
	oViewMenu.setMnemonic('V');
	oMainMenuBar.add(oViewMenu);
	
	oLnFMenu.setText("Look and Feel");
	oLnFMenu.setActionCommand("LnF");
	oLnFMenu.setMnemonic('L');
	oViewMenu.add(oLnFMenu);
	
	oLnFSubMenu1.setText("Metal");
	oLnFSubMenu1.setActionCommand("Metal");
	oLnFSubMenu1.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_J,Event.CTRL_MASK ));
	oLnFMenu.add(oLnFSubMenu1);
	oLnFSubMenu1.addActionListener(new MenuBarListener());
	
	oLnFSubMenu2.setText("Motif");
	oLnFSubMenu2.setActionCommand("Motif");
	oLnFSubMenu2.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_M,Event.CTRL_MASK ));
	oLnFMenu.add(oLnFSubMenu2);
	oLnFSubMenu2.addActionListener(new MenuBarListener());
	
	oLnFSubMenu3.setText("Windows");
	oLnFSubMenu3.setActionCommand("Windows");
	oLnFSubMenu3.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_W,Event.CTRL_MASK ));
	oLnFMenu.add(oLnFSubMenu3);
	oLnFSubMenu3.addActionListener(new MenuBarListener());
	
	oHelpMenu.setText("Help");
	oHelpMenu.setMnemonic('H');
	oMainMenuBar.add(oHelpMenu);
	oHelpMenu.add(oAboutMenuItem);
	oAboutMenuItem.addActionListener(new MenuBarListener());
	oAboutMenuItem.setText("About...");
	oAboutMenuItem.setActionCommand("About");
	oAboutMenuItem.setMnemonic('A');
	oMainMenuBar.setBorder(BorderFactory.createEtchedBorder());
	
	setJMenuBar(oMainMenuBar);
    }
    
    class MenuBarListener implements ActionListener
    {
	public void actionPerformed(ActionEvent e)
	{
	    if(e.getActionCommand().equals("Close"))
	    {
		UserManager.m_textRule = oTextRule.getText();
		dispose();
	    }
	    else if(e.getActionCommand().equals("Cut"))
	    {
		cut();
	    }
	    else if(e.getActionCommand().equals("Copy"))
	    {
		copy();
	    }
	    else if(e.getActionCommand().equals("Paste"))
	    {
		paste();
	    }
	    else if(e.getActionCommand().equals("About"))
	    {
		new AboutDialog(new JFrame(), "About BlueBird");
	    }
	    else
	    {
		BlueObject.setLookAndFeel(e.getActionCommand());
		SwingUtilities.updateComponentTreeUI(RuleBuilderMain.this);
	    }
	}
    }
    
    /**This method loads the custom rules into a tree list. Currently the
       values are hard coded and need to be changed to read rules from a 
       persistent storage.
       @return JPanel, the completed panel with the custom rule tree populated
     */
    private JPanel loadCustomRules()
    {
	JPanel customPanel = new JPanel(new BorderLayout());
	
	JLabel oCustomLabel = new JLabel();
	
	oCustomLabel.setText("Custom Rules");
	oCustomLabel.setHorizontalAlignment(JTextField.CENTER);
	oCustomLabel.setFont(new Font("Dialog", Font.BOLD, 10));
	oCustomLabel.setBorder(BorderFactory.createLoweredBevelBorder());
	
	customPanel.add(oCustomLabel, BorderLayout.NORTH);
	
	//THESE NODES ARE HARD CODED!
	DefaultMutableTreeNode	oRoot = new DefaultMutableTreeNode("CUSTOM");
	{
	    DefaultMutableTreeNode tmp = new DefaultMutableTreeNode("IP Information");
	    tmp.add(new DefaultMutableTreeNode("IPAddr IPLIKE 199.72.52.*"));
	    tmp.add(new DefaultMutableTreeNode("IPAddr IPLIKE 199.72.52.128-256"));
	    tmp.add(new DefaultMutableTreeNode("IPHostName LIKE 'ws%52'"));
	    oRoot.add(tmp);
	}
	{
	    DefaultMutableTreeNode tmp = new DefaultMutableTreeNode("Interface Information");
	    tmp.add(new DefaultMutableTreeNode("IFType == 6"));
	    tmp.add(new DefaultMutableTreeNode("IFType == 22"));
	    oRoot.add(tmp);
	}
	{
	    DefaultMutableTreeNode tmp = new DefaultMutableTreeNode("SNMP Information");
	    tmp.add(new DefaultMutableTreeNode("SNMPsysDescr LIKE 'bay'"));
	    tmp.add(new DefaultMutableTreeNode("SNMPsysCon LIKE 'sally jones'"));
	    tmp.add(new DefaultMutableTreeNode("SNMPsysCon LIKE 'bob adams';"));
	    tmp.add(new DefaultMutableTreeNode("SNMPsysOID LIKE '.1.3.6.1.4.1.11.2.3.%'"));
	    tmp.add(new DefaultMutableTreeNode("SNMPsysLoc LIKE 'east coast'"));
	    tmp.add(new DefaultMutableTreeNode("SNMPsysName LIKE 'router'"));
	    oRoot.add(tmp);
	}
	{
	    DefaultMutableTreeNode tmp = new DefaultMutableTreeNode("Miscellaneous");
	    oRoot.add(tmp);
	}
	
	m_oCustomTree = new RuleDragDropTree(oRoot);
	m_oCustomTree.setRootVisible(false);
	m_oCustomTree.setEditable(false);
	m_oCustomTree.setBorder(BorderFactory.createLoweredBevelBorder());
	
	m_oCustomTree.setBackground(java.awt.Color.lightGray);
	JScrollPane oCustomScrollPane = new JScrollPane(m_oCustomTree,
							JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
							JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED );
	
	((DefaultTreeCellRenderer)m_oCustomTree.getCellRenderer()).setBackground(java.awt.Color.lightGray);
	((DefaultTreeCellRenderer)m_oCustomTree.getCellRenderer()).setBackgroundNonSelectionColor(java.awt.Color.lightGray);
	
	oCustomScrollPane.setPreferredSize(new Dimension(350,150));
	
	customPanel.add(oCustomScrollPane, BorderLayout.SOUTH);
	
	return customPanel;
    }
    
    /**This method laods the template rules into a tree list. Currently the
       values are hard coded and need to be changed to read rules from a 
       persistent storage.
       @return JPanel, the completed panel with the template rule tree populated
     */
    private JPanel loadTemplateRules()
    {
	JPanel rulePanel = new JPanel(new BorderLayout());
	
	JLabel	oTemplateLabel = new JLabel();
	
	oTemplateLabel.setText("Template Rules");
	oTemplateLabel.setHorizontalAlignment(JTextField.CENTER);
	oTemplateLabel.setFont(new Font("Dialog", Font.BOLD, 10));
	oTemplateLabel.setBorder(BorderFactory.createLoweredBevelBorder());
	
	rulePanel.add(oTemplateLabel, BorderLayout.NORTH);
	
	//THESE NODES ARE HARD CODED!
	DefaultMutableTreeNode	oRoot = new DefaultMutableTreeNode("TEMPLATE");
	{
	    DefaultMutableTreeNode tmp = new DefaultMutableTreeNode("IP Information");
	    tmp.add(new DefaultMutableTreeNode("IPAddr IPLIKE *.*.*.*"));
	    tmp.add(new DefaultMutableTreeNode("IPHostName LIKE '%'"));
	    oRoot.add(tmp);
	}
	{
	    DefaultMutableTreeNode tmp = new DefaultMutableTreeNode("Interface Information");
	    tmp.add(new DefaultMutableTreeNode("IFType == x"));
	    oRoot.add(tmp);
	}
	{
	    DefaultMutableTreeNode tmp = new DefaultMutableTreeNode("SNMP Information");
	    tmp.add(new DefaultMutableTreeNode("SNMPsysDescr LIKE '%'"));
	    tmp.add(new DefaultMutableTreeNode("SNMPsysCon LIKE '%'"));
	    tmp.add(new DefaultMutableTreeNode("SNMPsysCon LIKE '%'"));
	    tmp.add(new DefaultMutableTreeNode("SNMPsysOID LIKE '.1.3.6.1.4.1.%'"));
	    tmp.add(new DefaultMutableTreeNode("SNMPsysLoc LIKE '%'"));
	    tmp.add(new DefaultMutableTreeNode("SNMPsysName LIKE '%'"));
	    oRoot.add(tmp);
	}
	{
	    DefaultMutableTreeNode tmp = new DefaultMutableTreeNode("Miscellaneous");
	    oRoot.add(tmp);
	}
	
	m_oTemplateTree = new RuleDragTree(oRoot);
	m_oTemplateTree.setRootVisible(false);
	m_oTemplateTree.setEditable(false);
	m_oTemplateTree.setBorder(BorderFactory.createLoweredBevelBorder());
	
	m_oTemplateTree.setBackground(java.awt.Color.lightGray);
	JScrollPane oTemplateScrollPane	= new JScrollPane(m_oTemplateTree,
							  JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
							  JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED );
	
	((DefaultTreeCellRenderer)m_oTemplateTree.getCellRenderer()).setBackground(java.awt.Color.lightGray);
	((DefaultTreeCellRenderer)m_oTemplateTree.getCellRenderer()).setBackgroundNonSelectionColor(java.awt.Color.lightGray);
	
	oTemplateScrollPane.setPreferredSize(new Dimension(350,150));
	
	rulePanel.add(oTemplateScrollPane, BorderLayout.SOUTH);
	
	return rulePanel;
    }
    
    private JPanel addStatusBar()
    {
	JPanel oStatusBar = new JPanel();
	
	oStatusBar.setFont(new Font("Dialog", Font.PLAIN, 11));
	oStatusBar.setBorder(BorderFactory.createLoweredBevelBorder());
	oStatusBar.setAlignmentX(LEFT_ALIGNMENT);
	oStatusBar.setAlignmentY(TOP_ALIGNMENT);
	
	m_oStatusText.setEditable(false);
	m_oStatusText.setHorizontalAlignment(JTextField.LEFT);
	m_oStatusText.setFont(new Font("Courier", Font.BOLD, 11));
	oStatusBar.add(m_oStatusText);
	oStatusBar.setLayout(new BorderLayout());
	oStatusBar.add(m_oStatusText, BorderLayout.NORTH);
	
	setStatus("Ready");
	
	return oStatusBar;
    }
    
    private void setStatus(String msg)
    {
	m_oStatusText.setBackground(java.awt.Color.lightGray);
	m_oStatusText.setForeground(java.awt.Color.black);
	m_oStatusText.setText(msg);
    }
    
    void addPopupMenu()
    {
	/*
	 * Create the popup menu.
	 */
	JMenuItem oMenuItem;
	m_oPopup = new JPopupMenu();
	
	oMenuItem = new JMenuItem("Cut");
	oMenuItem.setActionCommand("Cut");
	oMenuItem.addActionListener((ActionListener)m_oPopupListener);
	m_oPopup.add(oMenuItem);
	oMenuItem = new JMenuItem("Copy");
	oMenuItem.setActionCommand("Copy");
	oMenuItem.addActionListener((ActionListener)m_oPopupListener);
	m_oPopup.add(oMenuItem);
	oMenuItem = new JMenuItem("Paste");
	oMenuItem.setActionCommand("Paste");
	oMenuItem.addActionListener((ActionListener)m_oPopupListener);
	m_oPopup.add(oMenuItem);
	oMenuItem = new JMenuItem("Modify..");
	oMenuItem.setActionCommand("Modify");
	oMenuItem.addActionListener((ActionListener)m_oPopupListener);
	m_oPopup.add(oMenuItem);
	
	/*
	 * Add listener to components that can bring up popup menus.
	 */
	m_oCustomTree.addMouseListener(m_oPopupListener);
	m_oTemplateTree.addMouseListener(m_oPopupListener);
    }
    
    void cut()
    {
	try
	{
	    TreePath oPath =  m_oSelectionModel.getSelectionPath();
	    if(oPath.getPathCount() < 1)
	    {
		return;
	    }
	    DefaultMutableTreeNode oNode	= (DefaultMutableTreeNode)oPath.getLastPathComponent();
	    DefaultMutableTreeNode oParent	= (DefaultMutableTreeNode)oNode.getParent();
	    UserManager.m_sEditBuffer = oNode.toString();
	    DefaultTreeModel oTreeModel = null;
	    if(oParent.isRoot())
	    {
		UserManager.m_sEditBuffer = null;
		setStatus("Can't cut "+oNode.toString());
		Toolkit.getDefaultToolkit().beep();
		return;
	    }
	    if(m_oSelectionModel == m_oCustomTree.getSelectionModel())
	    {
		oTreeModel = (DefaultTreeModel)m_oCustomTree.getModel();
	    }
	    else if(m_oSelectionModel == m_oTemplateTree.getSelectionModel())
	    {
		oTreeModel = (DefaultTreeModel)m_oTemplateTree.getModel();
	    }
	    oTreeModel.removeNodeFromParent(oNode);
	    oTreeModel.reload(oParent);
	}
	catch(Exception e)
	{
	    setStatus("Must select a node first.");
	    Toolkit.getDefaultToolkit().beep();
	}
    }
    
    void copy()
    {
	try
	{
	    TreePath oPath =  m_oSelectionModel.getSelectionPath();
	    if(oPath.getPathCount() < 1)
	    {
		return;
	    }
	    DefaultMutableTreeNode oNode = (DefaultMutableTreeNode)oPath.getLastPathComponent();
	    DefaultMutableTreeNode oParent = (DefaultMutableTreeNode)oNode.getParent();
	    UserManager.m_sEditBuffer = oNode.toString();
	    DefaultTreeModel oTreeModel = null;
	    if(oParent.isRoot())
	    {
		UserManager.m_sEditBuffer = null;
		setStatus("Can't copy "+oNode.toString());
		Toolkit.getDefaultToolkit().beep();
		return;
	    }
	}
	catch(Exception e)
	{
	    setStatus("Must select a node first.");
	    Toolkit.getDefaultToolkit().beep();
	}
    }
    
    void paste()
    {
	if(UserManager.m_sEditBuffer != null)
	{
	    try
	    {
		TreePath oPath =  m_oSelectionModel.getSelectionPath();
		if(oPath == null || oPath.getPathCount() < 1)
		{
		    return;
		}
		DefaultMutableTreeNode oNode = (DefaultMutableTreeNode)oPath.getLastPathComponent();
		if(!((DefaultMutableTreeNode)oNode.getParent()).isRoot())
		{
		    UserManager.m_sEditBuffer = null;
		    setStatus("Can't paste "+UserManager.m_sEditBuffer+" onto "+oNode.toString());
		    Toolkit.getDefaultToolkit().beep();
		    return;
		}
		DefaultTreeModel oTreeModel = null;
		if(m_oSelectionModel == m_oCustomTree.getSelectionModel())
		{
		    oTreeModel = (DefaultTreeModel)m_oCustomTree.getModel();
		}
		else if(m_oSelectionModel == m_oTemplateTree.getSelectionModel())
		{
		    oTreeModel = (DefaultTreeModel)m_oTemplateTree.getModel();
		}
		Enumeration en=oNode.children();
		for(; en.hasMoreElements();)
		{
		    if(en.nextElement().toString().equals(UserManager.m_sEditBuffer))
		    {
			setStatus("Node "+UserManager.m_sEditBuffer+" is already assigned to "+oNode.toString());
			Toolkit.getDefaultToolkit().beep();
			return;
		    }
		}
		oTreeModel.insertNodeInto(new DefaultMutableTreeNode(UserManager.m_sEditBuffer),
					  oNode,
					  oNode.getChildCount());
		if(oNode.getChildCount()<=1)
		{
		    oTreeModel.reload(oNode);
		}
		UserManager.m_sEditBuffer = null;
	    }
	    catch(Exception e)
	    {
		setStatus("Must select a node first.");
		Toolkit.getDefaultToolkit().beep();
	    }
	    UserManager.m_sEditBuffer = null;
	}
	else
	{
	    setStatus("Can't paste: Clip board empty");
	    Toolkit.getDefaultToolkit().beep();
	}
    }
}

//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.operator.components;

import javax.swing.*;

import java.awt.*;
import java.awt.event.*;

import java.io.IOException;
import java.util.Vector;

import org.opennms.bb.eui.operator.panels.OperatorInterfacePanel;
import org.opennms.bb.eui.operator.utils.*;
import org.opennms.bb.eui.common.components.BBScrollPane;

/**
 * <pre>OperatorPanel is the component that the tabs in the operator 
 * interface tabbedpane hold
 *
 * It holds either the chartpanel and the ruler or the events table
 * based on the current level
 *
 * @author Sowmya
 */
public class OperatorPanel extends JPanel
{
	OperatorChartPanel	chartPanel;
	ChartRuler			rulerPanel;
	JScrollPane			scrPane;

	OperatorEventsPanel	eventsPanel;

	String				level;
	String				ID;

	public OperatorPanel(OperatorInterfacePanel operatorParent, 
						 String ID, String levelName, String dataFileName)

						 throws IOException
	{
		level = levelName;
		this.ID	  = ID;
		
		if (levelName.equals(operatorParent.EVENTS_LEVEL))
		{
			createEventsPanel(ID, dataFileName);
		}
		else
		{
			createChart(operatorParent, ID, levelName, dataFileName);
		}
	}

	void createEventsPanel(String ID, String dataFileName)

						 throws IOException
	{

		eventsPanel = new OperatorEventsPanel(ID, dataFileName);

		// center scroll pane
		JPanel upPanel = new JPanel();
		upPanel.setLayout(new BoxLayout(upPanel, BoxLayout.Y_AXIS));
		upPanel.setBorder(BorderFactory.createEtchedBorder());

		upPanel.add(Box.createVerticalGlue());
		upPanel.add(eventsPanel);
		upPanel.add(Box.createVerticalGlue());

		// actual layout
		setLayout(new BorderLayout());
		add(upPanel, BorderLayout.CENTER);
	}

	void createChart( OperatorInterfacePanel operatorParent, 
						 String ID, String levelName, String dataFileName)

						 throws IOException
	{

		// create chart panel
		chartPanel = new OperatorChartPanel(	operatorParent, 
												ID, 
												levelName,
												dataFileName);


		// add to scrollpane
		scrPane = new JScrollPane();
		scrPane.setViewportView(chartPanel);

	    //scrPane.setPreferredSize(new Dimension(550, 350));
		scrPane.setBorder(BorderFactory.createEmptyBorder(1, 1, 1, 1));

		// create ruler
		rulerPanel = new ChartRuler();
		Dimension rulerPanelSize = chartPanel.getPreferredSize();
		rulerPanel.setPreferredSize(new Dimension(rulerPanelSize.width, 25));

		// center scroll pane
		JPanel upPanel = new JPanel();
		upPanel.setLayout(new BoxLayout(upPanel, BoxLayout.Y_AXIS));
		upPanel.setBorder(BorderFactory.createEtchedBorder());

		upPanel.add(Box.createVerticalGlue());
		upPanel.add(scrPane);
		upPanel.add(Box.createVerticalGlue());

		// actual layout
		setLayout(new BorderLayout());
		add(upPanel, BorderLayout.CENTER);
		add(rulerPanel, BorderLayout.SOUTH);
	}

	/**
	 * ChartRuler draws itself according to the zoom level by querying the
	 * chart panel for the maximum bar width and the starting point of the
	 * bars
	 */
	protected class ChartRuler extends JComponent
	{
		boolean bZoomIn=false;

		ChartRuler()
		{
			super();
			setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
		}

		protected void zoomIn()
		{
			bZoomIn = true;
			repaint();
		}

		protected void zoomOut()
		{
			bZoomIn = false;
			repaint();
		}

		/*
		 * NOTE: paintChildren() paints the components in reverse order
		 * i.e. last component first ..
		 * In the case of the OperatorPanel however we require that 
		 * the ruler get painted after the chart, so in the chart's 
		 * paintComponent, force a repaint of the ruler 
		 */
		public void paintComponent(Graphics g)             
		{
			int chartX	= chartPanel.getChartX(this);

			int iWidth = (int)chartPanel.getChartWidth();
			int iHeight = getSize().height;

			g.setColor(Color.black);
			g.setFont(new Font("Dialog", Font.PLAIN, 9));

			int axisPos = iHeight-18;
			g.drawLine(chartX, axisPos, chartX+(iWidth-1), axisPos);

			int tickStart = iHeight-20;
			int tickEnd   = iHeight-16;

			int stringY	  = iHeight-5;
			int stringX	  = chartX;
			
			if (isZoomOn())
			{
				// draw ticks

				// initial '. .'
				int xPos = chartX;
				g.drawLine(xPos, tickStart, xPos, tickEnd);
				g.drawString(String.valueOf('.'), stringX, stringY);
				g.drawString(String.valueOf('.'), stringX+4, stringY);

				// get chart details
				double lowestLen   = chartPanel.getLowestLen();
				double highestLen  = chartPanel.getHighestLen();
				double lowestScale = highestLen - lowestLen;

				for (int iIndex=0; iIndex <= 10; iIndex += 2)
				{
					double curLen = lowestLen + (iIndex * lowestScale / 10);

					double curScale = highestLen - curLen;

					stringX = xPos - 3;

					if (curLen == lowestLen)
					{
						xPos = (int)(chartX + (0.1 * iWidth));

						stringX = xPos - 9;
					}

					else if (curLen == highestLen)
					{
						xPos = (int)(chartX + iWidth - 1);

						stringX = xPos - 11;
					}
					else
					{
						xPos = (int) (chartX + 
								  (lowestScale-curScale)*iWidth/lowestScale);

						stringX = xPos - 9;
					}

					// tick
					g.drawLine(xPos, tickStart, xPos, tickEnd);

					// string
					String curLenStr = String.valueOf(curLen);
					if (curLenStr.length() > 6)
					 	curLenStr = String.valueOf(curLen).substring(0, 6);

					g.drawString(curLenStr, stringX, stringY);
					
				}

			}
			else
			{
				// draw ticks
				int tickInterval = iWidth/10;
				for (int iIndex=0; iIndex < 10; iIndex++)
				{
					int xPos = (iIndex * tickInterval) + chartX;
					g.drawLine(xPos, tickStart, xPos, tickEnd);

					// tick string
					int tickNum = 10 * iIndex;

					if (tickNum == 0)
						g.drawString(String.valueOf(tickNum),xPos+1, stringY);

					else if (tickNum % 20 == 0)
						g.drawString(String.valueOf(tickNum),xPos-3, stringY);

				}

				int lastX = chartX + (iWidth-1);
				g.drawLine(lastX, tickStart, lastX, tickEnd);
				g.drawString(String.valueOf(100), lastX-6, stringY);
			}

			super.paintComponent(g);
		}

	}


	public void nameSort()
	{
		chartPanel.nameSort();
	}
	
	public void severitySort()
	{
		chartPanel.severitySort();
	}

	public void zoomIn()
	{
		chartPanel.zoomIn();
		rulerPanel.zoomIn();
	}

	public void zoomOut()
	{
		chartPanel.zoomOut();
		rulerPanel.zoomOut();
	}

	public boolean isZoomOn()
	{
		return chartPanel.isZoomOn();
	}

	public String getID()
	{
		// change the representation from '!#' to ': ' for the user
		String userRep = ID.replace('!', ':');
		userRep = userRep.replace('#', ' ');

		return userRep;
	}

	public String getSysID()
	{
		return ID;
	}

	public String getLevel()
	{
		return level;
	}

	public ChartRuler getRuler()
	{
		return rulerPanel;
	}
}

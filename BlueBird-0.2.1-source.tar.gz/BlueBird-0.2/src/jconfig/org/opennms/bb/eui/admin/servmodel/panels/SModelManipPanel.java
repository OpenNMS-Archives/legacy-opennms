//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.admin.servmodel.panels;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;

import java.util.*;

import org.opennms.bb.eui.common.panels.TableManipulationPanel;
import org.opennms.bb.eui.admin.servmodel.components.SMManipTable;

/**
 * <pre> SModelManipPanel extends TableManipPanel and holds the
 * service model table
 *
 * @author Sowmya
 *
 */

class SModelManipPanel extends TableManipulationPanel 
{
	protected SModelManipPanel(Vector colNames)
	{
		super(colNames);
	}

	protected SModelManipPanel(Vector rowData, Vector colNames)
	{
		super(rowData, colNames);
	}

	protected void createTable(Vector rowData, Vector colNames)
	{
		//Create the table
		infoTable = new  SMManipTable(rowData, colNames);

		infoTableModel = ((SMManipTable)infoTable).getTableModel();

		setViewportView(infoTable);
	}

	/**
	 * Creates an empty SMManipTable with column names 'colNames'
	 */
	protected void createTable(Vector colNames)
	{
		//Create the table
		infoTable = new  SMManipTable(colNames);

		infoTableModel = ((SMManipTable)infoTable).getTableModel();

		setViewportView(infoTable);

	}

	protected void addEntryToTable()
	{
		Vector data = new Vector();
		data.add("<model name>");
		data.add("<model descr>");

		addRow(data);
	}

	protected boolean validateValues()
	{
		if (checkForDuplicateEntries())
			return false;

		return true;
	}

	/**
	 * Checks if rows contain duplicate values
	 *
	 */
	protected boolean checkForDuplicateEntries()
	{
		Vector data = getTableData();
		int    iNumEntries = getRowCount();

		for(int iIndex1=0; iIndex1<(iNumEntries-1); iIndex1++)
		{
			Vector vector1=(Vector)data.elementAt(iIndex1);

			for(int iIndex2=iIndex1+1; iIndex2<iNumEntries; iIndex2++)
			{
				Vector vector2=(Vector)data.elementAt(iIndex2);

				// compare from address
				String mName1 = (String)vector1.elementAt(0);
				String mName2 = (String)vector2.elementAt(0);

				if(mName1.equals(mName2))
				{
		 			JOptionPane.showMessageDialog(null, 
							"Duplicate entry found for service model: " + 
							mName1,
							"Duplicate Entries in Service Models!", 
							JOptionPane.WARNING_MESSAGE);

					// found duplicate!
					return true;
				}
			}
		}

		return false;

	}

	public String getServiceName(int iService)
	{
		int iNumServices = infoTable.getRowCount();

		if (iService != -1 && iService < iNumServices)
		{
			return infoTable.getValueAt(iService, 1).toString();
		}
		else
			return null;

	}
}

//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.admin.servmodel.panels;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.event.*;
import javax.swing.table.*;

import java.util.Vector;

import org.opennms.bb.eui.common.components.BBTBButton;
import org.opennms.bb.eui.admin.servmodel.components.*;

/**
 * <pre> ServiceModelBehaviourPanel is the behaviour model panel
 * It handles all the editing related with the behaviour model
 *
 * @author Sowmya
 */
class ServiceModelBehaviourPanel extends JPanel implements ActionListener
{
	ServiceModelConfigPanel		smParent;
	JLabel						label;
	JCheckBox					autoCheckBox;
	SModelBehaviourManipPanel	tablePanel;

	BBTBButton 	copyButton, pasteButton, addButton, deleteButton, checkButton;

	private Vector	clipBoardVector=null;

	protected ServiceModelBehaviourPanel(ServiceModelConfigPanel smcPanel, Vector modelData)
	{
		smParent = smcPanel;

		JPanel upPanel = new JPanel();
		upPanel.setLayout(new BoxLayout(upPanel, BoxLayout.X_AXIS));

		label = new JLabel("Service Model  Behaviour");
		autoCheckBox = new JCheckBox("Autoflow during Edit");

		upPanel.add(label);
		upPanel.add(Box.createHorizontalGlue());
		upPanel.add(autoCheckBox);

		JPanel sPanel = new JPanel();
		sPanel.setLayout(new BoxLayout(sPanel, BoxLayout.X_AXIS));

		JPanel toolPanel = createToolPanel();
		toolPanel.setAlignmentY(Component.TOP_ALIGNMENT);

		tablePanel = createTablePanel(modelData);
		tablePanel.setAlignmentY(Component.TOP_ALIGNMENT);

		sPanel.add(toolPanel);
		sPanel.add(Box.createHorizontalStrut(5));
		sPanel.add(tablePanel);

		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		Border inBorder = BorderFactory.createEmptyBorder(5, 5, 5, 5);
		Border outBorder= BorderFactory.createLoweredBevelBorder();
		setBorder(BorderFactory.createCompoundBorder(outBorder, inBorder));

		upPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		sPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		add(upPanel);
		add(sPanel);

		// size
		Dimension toolSize = toolPanel.getPreferredSize();
		toolPanel.setPreferredSize(toolSize);
		toolPanel.setMaximumSize(new Dimension(50, toolSize.height*2));

		Dimension dim = tablePanel.getPreferredSize();
		tablePanel.setPreferredSize(new Dimension(400, 200));
		
		// control on/off of the autoflow and the checkbox
		autoCheckBox.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				JCheckBox cb = (JCheckBox)e.getSource();

				if (cb.isSelected())
				{
					setAutoFlowOn();
				}
				else
				{
					setAutoFlowOff();
				}
			}
		});
		
		// turn on by default
		autoCheckBox.setSelected(true);
		setAutoFlowOn();

		getTable().getSelectionModel().addListSelectionListener(new ListSelectionListener()
		{
			public void valueChanged(ListSelectionEvent e)
			{
				ListSelectionModel lsm = (ListSelectionModel)e.getSource();
				if (!lsm.isSelectionEmpty())
				{
					enableAll();
				}
				else
				{
					disableAll();
				}
			}
		});
	}

	SModelBehaviourManipPanel  createTablePanel(Vector modelData)
	{
		Vector colNames = new Vector(3);
		colNames.add("From");
		colNames.add("To");
		colNames.add("Behaviour");
		
		SModelBehaviourManipPanel panel = new SModelBehaviourManipPanel(modelData, colNames);
		return panel;
	}

	JPanel createToolPanel()
	{
		JPanel panel = new JPanel();
		panel.setBorder(BorderFactory.createLoweredBevelBorder());

		JToolBar toolBar = new JToolBar(SwingConstants.VERTICAL);
		toolBar.setFloatable(false);

		// copy
		copyButton = new BBTBButton("data/images/copy.gif", "CopyMB", "Copy current row");
		copyButton.addActionListener(this);
		toolBar.add(copyButton);

		// paste
		pasteButton = new BBTBButton("data/images/paste.gif", "PasteMB", "Paste row from clipboard");
		pasteButton.setEnabled(false);
		pasteButton.addActionListener(this);
		toolBar.add(pasteButton);

		// add
		addButton = new BBTBButton("data/images/new.gif", "AddMB", "Add new row");
		addButton.addActionListener(this);
		toolBar.add(addButton);

		// delete
		deleteButton = new BBTBButton("data/images/delete.gif", "DeleteMB", "Delete current row");
		deleteButton.addActionListener(this);
		toolBar.add(deleteButton);

		// check
		checkButton = new BBTBButton("data/images/check.gif", "CheckMB", "Check current config");
		checkButton.addActionListener(this);
		toolBar.add(checkButton);

		panel.add(toolBar);
		return panel;
	}
	
	public void actionPerformed(ActionEvent e)
	{
		smParent.handleMenuToolBarActions(e.getActionCommand());
	}

	/**
	 * handleAction() handles all the edits to the table
	 */
	public void handleAction(String actionStr)
	{
		if (actionStr.equals("CopyMB"))
		{
			int iSelRow = tablePanel.getSelectedRow();
			if (iSelRow != -1)
			{
				// Get the selected row
				Vector selRow = (Vector)tablePanel.getTableData().elementAt(iSelRow);

				// Make a copy of this row in the clipboard
				int iSize = selRow.size();
				clipBoardVector = new Vector(iSize);
				for (int iIndex=0; iIndex < iSize; iIndex++)
					clipBoardVector.add(selRow.elementAt(iIndex));

				pasteButton.setEnabled(true);
				smParent.pasteMBMenuItem.setEnabled(true);
			}
		}

		else if (actionStr.equals("PasteMB"))
		{
			tablePanel.pasteRow(clipBoardVector);
		}

		else if (actionStr.equals("AddMB"))
		{
			tablePanel.addEntryToTable();
		}

		else if (actionStr.equals("DeleteMB"))
		{
			int iSelRow = tablePanel.getSelectedRow();
			if (iSelRow != -1)
			{
				tablePanel.removeRow(iSelRow);
			}
		}

		else if (actionStr.equals("AddM"))
		{
			tablePanel.createNewModelBehaviour();
			setServiceName("<new model>");
		}

		else if (actionStr.equals("CheckMB"))
		{
			boolean bRet = tablePanel.checkAutoFlow();
			if (bRet)
			{
		 		JOptionPane.showMessageDialog(null, 
						"Intervals validated successfully!", 
						"Autoflow check", 
						JOptionPane.WARNING_MESSAGE);
			}

		}

	}

	public void disableAll()
	{
		copyButton.setEnabled(false);
		pasteButton.setEnabled(false);
		addButton.setEnabled(false);
		deleteButton.setEnabled(false);
		checkButton.setEnabled(false);
	}

	public void enableAll()
	{
		if (!copyButton.isEnabled())	// check if disabled
		{
			copyButton.setEnabled(true);
			addButton.setEnabled(true);
			deleteButton.setEnabled(true);
			checkButton.setEnabled(true);
		}
	}
	
	public void setTableData(Vector tableData)
	{
		SMBManipTable table = (SMBManipTable)tablePanel.getTable();
		table.setDataVector(tableData);

		if (table.getRowCount() > 0)
			table.setInitialFocus();
	}

	protected void setAutoFlowOn()
	{
		((SMBManipTable)tablePanel.getTable()).setAutoFlowOn();
	}

	protected void setAutoFlowOff()
	{
		((SMBManipTable)tablePanel.getTable()).setAutoFlowOff();
	}

	public boolean checkAutoFlow()
	{
		return tablePanel.checkAutoFlow();
	}
	
	public JTable getTable()
	{
		return tablePanel.getTable();
	}
	
	public Vector getTableData()
	{
		return tablePanel.getTableData();
	}

	public void setServiceName(String serviceName)
	{
		if (serviceName != null)
			label.setText("Service Model  Behaviour: " + serviceName);
		else
			label.setText("Service Model  Behaviour");
	}
	
	public boolean isTableChanged()
	{
		return tablePanel.isTableChanged();
	}

	public void setTableSaved()
	{
		tablePanel.setTableSaved();
	}
}

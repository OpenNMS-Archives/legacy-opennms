//-------------------------------------------------------------------------------------------
//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

//--------------------------------------------------------------------------------------------

package org.opennms.bb.eui.admin.distpoller.configure.parsers;

import org.opennms.bb.eui.admin.distpoller.configure.dpconf.*;

import org.w3c.dom.*;

import java.io.*;
import java.util.Vector;
import java.util.Enumeration;

import org.opennms.bb.common.utils.BBParser;

/**
 * Modifications:
 * 04/18/200 - Changed the parser to extend BBParser - sk
 */

public class repcalXmlParser extends BBParser
{
	
	Vector 	nodesData 		= 	new Vector();
	Vector	rangesData		= 	new Vector();
	Vector	dowData		= 	new Vector();
	Vector	domData		= 	new Vector();
	Vector 	calendarData	=	new Vector();
	Vector 	calDetailsVector;

	/*
	 * XML TAGS
	 */
	final String PARMS		=	"parms";
	final String PARM 		=	"parm";
	final String PARM_NAME		=	"parmName";
	final String PARM_VALUE		=	"value";

	final String CALENDAR 		= 	"calendar";
	final String CALNAME		= 	"calName";
	final String CALDESCR		= 	"calDescr";
	final String DAYOFWEEK		= 	"dayofWeek";
	final String DOW			= 	"dow";
	final String DOWNAME 		= 	"dowName";
	final String DAYOFMONTH		= 	"dayofMonth";
	final String DOM		 	= 	"dom";

	final String DOMNUM		= 	"domNum";
	final String NODES	 	= 	"nodes";
	final String NODE		 	= 	"node";
	final String RANGES		=	"ranges";
	final String RANGE		=	"range";


	// Number of default parameters
	int 	iNumDefParms	=	0;

	public repcalXmlParser()
	{
		super();
	}

	protected boolean processElement(Element el, boolean isRoot)
	{
		boolean bRet	=	false;
		String tag	 	= 	el.getTagName();

		if (tag.equals(CALENDAR))
		{
			bRet = processCalendarParms(el);

		}
		else
		{
			boolean bNodeRet	=	true;
			NodeList nl 	= 	el.getChildNodes();
			int size 		=	nl.getLength();

			for(int i = 0;i < size && bNodeRet ;i++)
				bNodeRet = processNode(nl.item(i));
			
			bRet 			=	 bNodeRet;
		}
		return bRet;
	}

	
	protected boolean processCalendarParms(Node parmsNode)
	{
		boolean bRet		=	 true;
		String tempElement 	=	 null;
		NodeList nl 		=	 parmsNode.getChildNodes();
		calDetailsVector		=	new Vector();
		int size 			=	 nl.getLength();

		for(int i = 0;i < size && bRet;i++)
		{
			Node curNode 	=	 nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
						
				if (curTag.equals(CALNAME))
				{
					tempElement		=	 processPollerValue(curNode);
					//System.out.println("Ajalias");
					if (null != tempElement)
						calDetailsVector.addElement(curTag + " : " + tempElement);
					else
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}

					
				}
				else if (curTag.equals(CALDESCR))
				{
					tempElement 	=	 processPollerValue(curNode);
					if (null != tempElement)
						calDetailsVector.addElement(curTag + " : " +tempElement);
					else
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}

				}
				else if (curTag.equals(DAYOFMONTH))
				{
					boolean packageRet =  processDateOfMonth(curNode);
					bRet = packageRet;
				}
				else if (curTag.equals(DAYOFWEEK))
				{
					boolean packageRet =  processDateOfWeek(curNode);
					bRet = packageRet;
				}
				else if (curTag.equals(NODES))
				{
					boolean packageRet =  processNodesParms(curNode);
					bRet = packageRet;

				}
				
			}
		}

		return bRet;
	}


	protected boolean processNodesParms(Node parmsNode)
	{

		boolean bRet 			= 	true;
		String tempElement 		= 	null;
		Vector nodeNamesVector	 	= 	new Vector();
		NodeList nl 			= 	parmsNode.getChildNodes();
		int size 				= 	nl.getLength();

		for(int i = 0;i < size && bRet;i++)
		{
			Node curNode 		= 	nl.item(i);

			if(curNode.getNodeType()== 	Node.ELEMENT_NODE)
			{
				String curTag	= 	((Element)curNode).getTagName();
					
				if (curTag.equals(NODE))
				{
					tempElement	= 	processPollerValue(curNode);
					if (null 	!= tempElement)
					{
						nodeNamesVector.addElement(tempElement);
					}
					else
					{
						bRet 		= 	false;
						m_errNum 	=	NULL_VALUE_ERR;
					}
				}

			}
		}

		nodesData.addElement(nodeNamesVector);

		if ( !calDetailsVector.contains(nodeNamesVector))
		{
			calDetailsVector.addElement(nodeNamesVector);
		}


		calendarData.addElement(calDetailsVector);
		return bRet;
	
	}

		
	protected boolean processDateOfMonth(Node parmsNode)
	{
		boolean bRet 		= 	true;
		NodeList nl 		=	parmsNode.getChildNodes();
		int size 		=	 nl.getLength();

		for(int i = 0;i < size && bRet;i++)
		{
			Node curNode 	=	nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag 	=	 ((Element)curNode).getTagName();
				if (curTag.equals(DOM))
				{
					boolean calRet 		=	 processDOMParms(curNode);
					bRet 				=	 calRet;
				}
			}
		}

		return bRet;
	}

	protected boolean processDateOfWeek(Node parmsNode)
	{
		boolean bRet 		= 	true;
		NodeList nl 		=	parmsNode.getChildNodes();
		int size	 		=	 nl.getLength();

		for(int i = 0;i < size && bRet;i++)
		{
			Node curNode 	=	nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag 	=	 ((Element)curNode).getTagName();
				if (curTag.equals(DOW))
				{
					boolean calRet 		=	 processDOWParms(curNode);
					bRet 				=	 calRet;
				}
			
			}
		}

		return bRet;
	}

	protected String processPollerValue(Node parmValueNode)
	{
		String value	=	null;
		Node temp		=	parmValueNode.getChildNodes().item(0);
	
		if (temp.getNodeType() == Node.TEXT_NODE)
			value = ((Text)temp).getData();
		else if (temp.getNodeType() == Node.CDATA_SECTION_NODE)
			value = ((CDATASection)temp).getData();
			
		return value;
	}

	
	protected boolean processDOWParms(Node parmsNode)
	{
		boolean bRet 		=	 true;
		NodeList nl			=	 parmsNode.getChildNodes();
		int size 			=	 nl.getLength();
		String tempElement 	= 	 null;
		Vector dowVector	 	= 	 new Vector();

		for(int i = 0;i < size && bRet;i++)
		{
			Node curNode 	= 	nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{

				String curTag	 =	 ((Element)curNode).getTagName();
			
				if(curTag.equals(DOWNAME))
				{
					tempElement	= 	processPollerValue(curNode);
					if (null 	!= tempElement)
					{
						dowVector.addElement(curTag + " : "+tempElement);
						calDetailsVector.addElement(curTag + " : "+tempElement);
					}
					else
					{
						bRet 		= 	false;
						m_errNum 	=	NULL_VALUE_ERR;
					}
				}
				else if (curTag.equals(RANGES)) 
				{
					bRet 		=	 processRanges(curNode);	
				}
				
			}
		}

		return bRet;
	}


	protected boolean processDOMParms(Node parmsNode)
	{
		boolean bRet 		=	 true;
		NodeList nl			=	 parmsNode.getChildNodes();
		int size 			=	 nl.getLength();
		String tempElement 	= 	 null;
		Vector domVector	 	= 	 new Vector();

		for(int i = 0;i < size && bRet;i++)
		{
			Node curNode 	= 	nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{

				String curTag	 =	 ((Element)curNode).getTagName();
			
				if(curTag.equals(DOMNUM))
				{
					tempElement	= 	processPollerValue(curNode);
					if (null 	!= tempElement)
					{
						domVector.addElement(curTag + " : "+tempElement);
						calDetailsVector.addElement(curTag + " : "+tempElement);
					}
					else
					{
						bRet 		= 	false;
						m_errNum 	=	NULL_VALUE_ERR;
					}
				}
				else if (curTag.equals(RANGES)) 
				{
					bRet 		=	 processRanges(curNode);	
				}
				
			}
		}

		return bRet;
	}
	
	protected boolean processRanges(Node rangeDefNode)
	{
		boolean bRet 		= 	true;
		NodeList nl 		= 	rangeDefNode.getChildNodes();
		int size 			= 	nl.getLength();
	
		for(int i = 0;i < size; i++)
		{
			Node curNode	 = 	nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = 	((Element)curNode).getTagName();
		
				if(curTag.equals(RANGE))
				{
					bRet 	= 	processRange(curNode);
				}
			}
		}
		
		return bRet;

	}


	protected boolean processRange(Node rangesNode)
	{
		boolean bRet	 =	 true;
		Vector rangeVector = 	new Vector();
		NodeList nl 	 =	 rangesNode.getChildNodes();
		int size		 = 	nl.getLength();

		for(int i = 0;i < size; i++)
		{
			Node curNode = 	nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = 	((Element)curNode).getTagName();
				if(curTag.equals(PARMS))
				{
					int iNumParms 	=	 processParms(curNode, rangeVector);
				}
			}
		}
		rangesData.addElement(rangeVector);
		calDetailsVector.addElement(rangeVector);
		return bRet;
	}

	
	
	protected int processParms(Node tabNode, Vector tabVector)
	{
		int iNumParms	=	0;
		NodeList nl 	=	tabNode.getChildNodes();
		int size 		= 	nl.getLength();

		for(int i = 0;i < size;i++)
		{
			Node curNode 	= 	nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
				
				if(curTag.equals(PARM))
				{
					Vector parm		=	 processParm(curNode);

					if ( (!parm.isEmpty()) && (parm.size() == 2))
					{
						String parmName 	=	(String)parm.elementAt(0);
						String parmValue 	=	 (String)parm.elementAt(1);
						tabVector.add(parmName);
						tabVector.add(parmValue);
						iNumParms++;
					}
				}

			}
		}

		return iNumParms;
	}


	protected Vector processParm(Node parmsNode)
	{
		Vector parm		=	new Vector(2);
		NodeList nl		= 	parmsNode.getChildNodes();
		int size 		=	nl.getLength();

		for(int i = 0;i < size;i++)
		{

			Node curNode = nl.item(i);
			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
				if(curTag.equals(PARM_NAME))
				{
					String name = processParmName(curNode);
					if (null != name)
						parm.add(name);
				}
				else if(curTag.equals(PARM_VALUE))
				{
					String value = processParmValue(curNode);
					if (null != value)
						parm.add(value);
				}

			}
		}
		
		return parm;
	}

	protected String processParmName(Node parmNameNode)
	{
		String parmName	=	null;
		Node temp 		=	parmNameNode.getChildNodes().item(0);

		if (temp.getNodeType() == Node.TEXT_NODE)
			parmName = ((Text)temp).getData();
		
		return parmName;
	}

	//returns packages details data
	public Vector getCalendarData()
	{
		return calendarData;
	}


	public void printCalData()
	{
		System.out.println("---------------PACKAGE------------");

		Enumeration enum = calendarData.elements();
		while (enum.hasMoreElements())
		{
			Vector temp = (Vector)enum.nextElement();	
			Enumeration en = temp.elements();
			while (en.hasMoreElements())
			{
				Object dummy = en.nextElement();
				if (dummy instanceof Vector)
				{
					System.out.println("");
					Vector temp1 = (Vector)dummy;
					Enumeration en1 = temp1.elements();
					while (en1.hasMoreElements())
						System.out.println(en1.nextElement());
				}
				else 
				if (dummy instanceof String)
				{
					System.out.println(dummy);
				}
			}
			System.out.println(" ");
		}
		System.out.println("---------------END PACKAGE------------");
	}

	
	/*public static void main(String args[]) throws Exception 
	{
		repcalXmlParser ice = new repcalXmlParser();
		ice.printCalData();
	}*/
}

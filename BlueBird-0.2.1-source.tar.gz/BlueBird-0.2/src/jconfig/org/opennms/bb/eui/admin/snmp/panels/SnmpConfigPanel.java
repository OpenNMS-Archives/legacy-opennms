//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.admin.snmp.panels;

import javax.swing.*;

import javax.swing.event.ListSelectionListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.TableColumnModelListener;
import javax.swing.event.TableColumnModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.event.TableModelEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;

import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;

import java.beans.*;
import java.awt.*;
import java.awt.event.*;

import java.io.*;
import java.util.*;

import org.opennms.bb.eui.common.components.*;
import org.opennms.bb.eui.common.panels.TableManipulationPanel;
import org.opennms.bb.eui.admin.snmp.utils.SnmpXmlParser;
import org.opennms.bb.eui.admin.snmp.utils.SnmpXmlWriter;

import org.opennms.bb.eui.admin.snmp.utils.SnmpUserProfParser;
import org.opennms.bb.eui.admin.snmp.utils.SnmpUserProfWriter;

/**
 * SnmpConfigPanel is the core panel for the 'SnmpConfig' 
 *
 * <p>This creates the tabbedpanes, the menu, toolbar to operate on the
 * tables of these tabbed panes 
 *
 * @author Sowmya
 *
 */

public class SnmpConfigPanel extends JPanel implements	
													ActionListener, 
													ListSelectionListener,
													TableColumnModelListener,
													TableModelListener
{ 
	JFrame						snmpFrame; 
	boolean						bParseException=false;

	BBTabbedPane 				snmpTabbedPane;
	DefaultManipPanel 			dPanel;
	IPRangesManipPanel 			iprPanel;
	SpecificDevicesManipPanel 	sdPanel;
	UrlConfigManipPanel 		ucPanel;

	/** The 'Default' tab  */
	final int DEF_MANIP_PANEL = 0;

	/** The 'Ranges' tab  */
	final int IPR_MANIP_PANEL = 1;

	/** The 'Specific Devices' tab  */
	final int SD_MANIP_PANEL  = 2;

	/** The 'URL' tab  */
	final int UC_MANIP_PANEL  = 3;

	final String tabPaneID="SnmpConfig";

	// Toolbar
	BBTabbedPaneMenuItem copyMenuItem, pasteMenuItem, addMenuItem, deleteMenuItem;
	BBTabbedPaneTBButton copyButton, pasteButton, addButton, deleteButton;

	// Clipboard related vars
	private Vector				clipBoardVector=null;
	private int					iCopyPanel;
	private int					iCurrentActivePanel=0;
	private int					iLastActivePanel=-1;
	private ListSelectionModel	iprRowSM, sdRowSM, ucRowSM;
	private TableColumnModel	iprColM, sdColM, ucColM;

	// status bar
	JLabel			statusLabel;

	String			userID;

	// user profile values
	final String XPOS		="xPos";
	final String YPOS		="yPos";
	final String WIDTH		="Width";
	final String HEIGHT		="Height";
	final String LOOKNFEEL	="lookAndFeel";

	// user profile related
	boolean					bLandFAtStartUp=true;
	Hashtable				userProfile;

	protected void SnmpConfigInit(JFrame frame, String userID)
	{
		// store the frame
		snmpFrame = frame;

		//
		this.userID = userID;

		// get user profile
		readUserProfile();

		// set look and feel
		String landf = String.valueOf(userProfile.get(LOOKNFEEL));
		if (landf != null)
			handleMenuToolBarActions(landf);

		bLandFAtStartUp = false;

		// tabbed pane panel
		JPanel tabPanel = new JPanel();
		tabPanel.setLayout(new BorderLayout());

		// Create the tabbed panes
		snmpTabbedPane = createBBTabbedPanes();
		if (bParseException)
		{
			handleWindowClose();
			return;
		}

		tabPanel.add(snmpTabbedPane, BorderLayout.SOUTH);

		// menu toolbar  panel
		JPanel menuToolbarPanel = new JPanel();
		menuToolbarPanel.setLayout(new BorderLayout());

		// Create the menu
		JMenuBar snmpMenu = createMenu();
		menuToolbarPanel.add(snmpMenu, BorderLayout.NORTH);

		// Create the toolbar
		JPanel toolPanel = new JPanel();
		toolPanel.setLayout(new BorderLayout());
		
		JToolBar toolBar = createToolBar();
	 	toolPanel.add(toolBar, BorderLayout.SOUTH);

		menuToolbarPanel.add(toolPanel);

		// Create the status bar
		JLabel statusLabel = createStatusBar();

		// actual panel
		setLayout(new BorderLayout());
		add(menuToolbarPanel, BorderLayout.NORTH);
		add(snmpTabbedPane, BorderLayout.CENTER);
		add(statusLabel, BorderLayout.SOUTH);

		// Enable/disable the copy/delete option based on the row selection
		// in the tables
		iprRowSM = iprPanel.getTable().getSelectionModel();
		iprRowSM.addListSelectionListener(this);

		sdRowSM = sdPanel.getTable().getSelectionModel();
		sdRowSM.addListSelectionListener(this);

		ucRowSM = ucPanel.getTable().getSelectionModel();
		ucRowSM.addListSelectionListener(this);

		// Listen to the table model as well
		dPanel.getTableModel().addTableModelListener(this);
		iprPanel.getTableModel().addTableModelListener(this);
		sdPanel.getTableModel().addTableModelListener(this);
		ucPanel.getTableModel().addTableModelListener(this);

		// Listen to column selection changes
		iprColM = iprPanel.getTable().getColumnModel();
		iprColM.addColumnModelListener(this);

		sdColM = sdPanel.getTable().getColumnModel();
		sdColM.addColumnModelListener(this);

		ucColM = ucPanel.getTable().getColumnModel();
		ucColM.addColumnModelListener(this);

		// listen to see which is the current tab
		snmpTabbedPane.addChangeListener(new ChangeListener()
		{
			public void stateChanged(ChangeEvent e)
			{
				// Store the current panel 
				iLastActivePanel    = iCurrentActivePanel;
				iCurrentActivePanel = snmpTabbedPane.getSelectedIndex();

				// Grey out the 'copy/paste' if necessary
				if (iCurrentActivePanel == DEF_MANIP_PANEL)
				{
					pasteMenuItem.setEnabled(false);
					pasteButton.setEnabled(false);

					addButton.setEnabled(false);
					addMenuItem.setEnabled(false);

					disableCopyDelete();

					dPanel.clearSelection();
					dPanel.initialFocus();

				}
				else
				{
					addButton.setEnabled(true);
					addMenuItem.setEnabled(true);

					disableCopyDelete();

					iprPanel.clearSelection();
					sdPanel.clearSelection();
					ucPanel.clearSelection();

					if (iLastActivePanel != iCurrentActivePanel)
					{
						boolean		 bFocusRet = false;

						if (iCurrentActivePanel == IPR_MANIP_PANEL)
							bFocusRet = iprPanel.initialFocus();

						else if (iCurrentActivePanel == SD_MANIP_PANEL)
							bFocusRet = sdPanel.initialFocus();

						else if (iCurrentActivePanel == UC_MANIP_PANEL)
							bFocusRet = ucPanel.initialFocus();

						if (bFocusRet)
							enableCopyDelete();
					}

					// If the panel is the same as the one the copy
					// was made in, allow a paste; else disable it

					if (iCurrentActivePanel == iCopyPanel)
					{
						pasteMenuItem.setEnabled(true);
						pasteButton.setEnabled(true);
					}
					else
					{
						pasteMenuItem.setEnabled(false);
						pasteButton.setEnabled(false);
					}

				}
				
				// set status
				setStatus();
			}
		});

		// Set user position/dimension preferences
		setUserPosDimPreferences();

		// If we got here display frame
		snmpFrame.setVisible(true);
	}
	
	/**
	 * Sets intial focus to first cell of the default panel
	 */
	public void handleWindowOpen()
	{
		if(!bParseException)
			dPanel.initialFocus();
	}

	/**
	 * Exits only if tabbedpane is clean
	 */
	public void handleWindowClose()
	{
		if (bParseException)
		{
			snmpFrame.dispose();
		}
		else
		{
			// The text cell editors of the tables don't get a 
			// focusLost() on window close - so force one
			snmpTabbedPane.getSelectedComponent().requestFocus();

			if (!snmpTabbedPane.isDirty("SnmpConfig"))
				handleExit();
		}
	}

	/**
	 * Reads the user preferences from the user profile file
	 */
	protected void readUserProfile()
	{
		SnmpUserProfParser userProfParser=null;
		boolean	bUserProfileRead=true;

		String userxml = "data/users/" + userID + ".xml";

		// if file does not exist, just take defaults
		File userFile = new File(userxml);
		if (userFile.exists() && userFile.canRead())
		{
			// get user profile
			try
			{
				userProfParser = new SnmpUserProfParser();
				userProfParser.parse(userxml);
			}
			catch (Exception e)
			{
				// if the profile has an error, just prompt and continue
	 			JOptionPane.showMessageDialog(new JFrame(), 
					e.getMessage(),
					"Error! Unable to parse user profile file", 
					JOptionPane.ERROR_MESSAGE);

				bUserProfileRead = false;
			}
		}
		else
				bUserProfileRead = false;
		
		// 
		if (bUserProfileRead)
		{
			userProfile = userProfParser.getUserProfile();

			if (userProfile == null)
				userProfile = new Hashtable(5);
		}

		else
			userProfile = new Hashtable(5);
	}

	/**
	 * Sets the (x,y) and size preferences of the user
	 */
	protected void setUserPosDimPreferences()
	{
		// set the location of the frame
		Object xPos = userProfile.get(XPOS);
		Object yPos = userProfile.get(YPOS);
		if (xPos != null && yPos != null)
		{
			snmpFrame.setLocation(((Integer)xPos).intValue(), 
								((Integer)yPos).intValue());
		}
		else
			snmpFrame.setLocation(100, 100);

		// set the size
		Object width = userProfile.get(WIDTH);
		Object height = userProfile.get(HEIGHT);
		if (width != null && height != null)
		{
			setPreferredSize(new Dimension(((Integer)width).intValue(),
										  ((Integer)height).intValue()));
		}
		else
			setPreferredSize(new Dimension(500, 400));
	}

	/**
	 * Table(s) row selection model listener to enable/disable copy and delete
	 */
	public void valueChanged(ListSelectionEvent e)
	{
		ListSelectionModel lsm = (ListSelectionModel)e.getSource();

		if(lsm.isSelectionEmpty())
		{
			disableCopyDelete();
		}
		else
		{
			enableCopyDelete();
		}
	}

	/**
	 * Table(s) model listener to set status and enable/diable 'delete'
	 */
	public void tableChanged(TableModelEvent e)
	{
		DefaultTableModel tableModel= (DefaultTableModel)e.getSource();

		if (e.getType() == e.DELETE && tableModel.getRowCount() <= 0)
			disableCopyDelete();

		// set status
		setStatus();
	}

	/**
	 * Table(s) column selection listener to set status
	 */
	public void columnSelectionChanged(ListSelectionEvent e)
	{
		setStatus();
	}

	public void columnAdded(TableColumnModelEvent e) { }
	public void columnMoved(TableColumnModelEvent e) { }
	public void columnRemoved(TableColumnModelEvent e) { }
	public void columnMarginChanged(ChangeEvent e) { }

	private void setStatus()
	{
		if(dPanel.isTableChanged() || iprPanel.isTableChanged() ||
			sdPanel.isTableChanged() || ucPanel.isTableChanged())
		{
			statusLabel.setText("Configuration Modified");
		}
		else
			statusLabel.setText("Ready");
	}

	private void disableCopyDelete()
	{
		copyMenuItem.setEnabled(false);
		copyButton.setEnabled(false);

		deleteButton.setEnabled(false);
		deleteMenuItem.setEnabled(false);
	}

	private void enableCopyDelete()
	{
		copyMenuItem.setEnabled(true);
		copyButton.setEnabled(true);

		deleteButton.setEnabled(true);
		deleteMenuItem.setEnabled(true);
	}

	/**
	 * Set the tab titles from the array
	 */
	protected void setTabTitles(String[] titles)
	{
		for(int iIndex=0; iIndex < 4; iIndex++)
			snmpTabbedPane.setTitleAt(iIndex, titles[iIndex]);
	}


	public SnmpConfigPanel(JFrame frame, String userID)
	{
		SnmpConfigInit(frame, userID);
	}

	/**
	 * Creates the menubar
	 */
	protected JMenuBar createMenu()
	{
		JMenuBar				snmpMenuBar;
		BBTabbedPaneMenu		snmpMenu;
		BBTabbedPaneMenuItem	menuItem;

		snmpMenuBar = new JMenuBar();

		// The file menu
		snmpMenu = new BBTabbedPaneMenu("File", tabPaneID);
		snmpMenu.setMnemonic('F');
		snmpMenuBar.add(snmpMenu);

		menuItem = new BBTabbedPaneMenuItem("Save", KeyEvent.VK_S, tabPaneID);
		//menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, ActionEvent.CTRL_MASK));

		menuItem.addActionListener(this);
		snmpMenu.add(menuItem);

		menuItem = new BBTabbedPaneMenuItem("Exit",  KeyEvent.VK_X, tabPaneID);
		menuItem.addActionListener(this);
		snmpMenu.add(menuItem);

		// The Edit  menu
		snmpMenu = new BBTabbedPaneMenu("Edit", tabPaneID);
		snmpMenu.setMnemonic('E');
		snmpMenuBar.add(snmpMenu);

		copyMenuItem = new BBTabbedPaneMenuItem("Copy",  KeyEvent.VK_C, tabPaneID);
		//copyMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C, ActionEvent.CTRL_MASK));

		copyMenuItem.addActionListener(this);
		copyMenuItem.setEnabled(false);
		snmpMenu.add(copyMenuItem);

		pasteMenuItem = new BBTabbedPaneMenuItem("Paste",  KeyEvent.VK_P, tabPaneID);
		//pasteMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_V, ActionEvent.CTRL_MASK));
		pasteMenuItem.addActionListener(this);
		pasteMenuItem.setEnabled(false);
		snmpMenu.add(pasteMenuItem);

		snmpMenu.addSeparator();

		addMenuItem = new BBTabbedPaneMenuItem("Add",  KeyEvent.VK_A, tabPaneID);
		//addMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_A, ActionEvent.CTRL_MASK));
		addMenuItem.addActionListener(this);
		addMenuItem.setEnabled(false);
		snmpMenu.add(addMenuItem);

		deleteMenuItem = new BBTabbedPaneMenuItem("Delete",  KeyEvent.VK_D, tabPaneID);
		//deleteMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_D, ActionEvent.CTRL_MASK));
		deleteMenuItem.addActionListener(this);
		deleteMenuItem.setEnabled(false);
		snmpMenu.add(deleteMenuItem);

		// The Options  menu
		snmpMenu = new BBTabbedPaneMenu("Options", tabPaneID);
		snmpMenu.setMnemonic('O');
		snmpMenuBar.add(snmpMenu);

		// Look and Feel
		JMenu lfMenu = new JMenu("Look And Feel");
		lfMenu.setMnemonic(KeyEvent.VK_L);
		lfMenu.addActionListener(this);
		snmpMenu.add(lfMenu);

        // Look and Feel Radio control
		ButtonGroup group = new ButtonGroup();
		JRadioButtonMenuItem radioMenuItem;

	    radioMenuItem = new JRadioButtonMenuItem("Metal");
		radioMenuItem.setSelected(
				UIManager.getLookAndFeel().getName().equals("Metal"));
		lfMenu.add(radioMenuItem);
		group.add(radioMenuItem);
		radioMenuItem.addActionListener(this);

        radioMenuItem = new JRadioButtonMenuItem("CDE/Motif");
		radioMenuItem.setSelected(
				UIManager.getLookAndFeel().getName().equals("CDE/Motif"));
		lfMenu.add(radioMenuItem);
		group.add(radioMenuItem);
		radioMenuItem.addActionListener(this);

        radioMenuItem = new JRadioButtonMenuItem("Windows");
		radioMenuItem.setSelected(
				UIManager.getLookAndFeel().getName().equals("Windows"));
		lfMenu.add(radioMenuItem);
		group.add(radioMenuItem);
		radioMenuItem.addActionListener(this);

		snmpMenuBar.add(Box.createHorizontalGlue());

		// The Help  menu
		snmpMenu = new BBTabbedPaneMenu("Help", tabPaneID);
		snmpMenu.setMnemonic('H');
		snmpMenuBar.add(snmpMenu);

		menuItem = new BBTabbedPaneMenuItem("About",  KeyEvent.VK_A, tabPaneID);
		menuItem.addActionListener(this);
		snmpMenu.add(menuItem);
		
		return snmpMenuBar;
	}

	/**
	 * Creates the toolbar
	 */
	protected JToolBar createToolBar()
	{
		JToolBar toolBar = new JToolBar();

		// Save
		BBTabbedPaneTBButton saveButton = new BBTabbedPaneTBButton("data/images/save.gif", "Save", "Save the current file", tabPaneID);
		saveButton.addActionListener(this);
		toolBar.add(saveButton);

		toolBar.addSeparator(new Dimension(10, 10));

		// Copy
		copyButton = new BBTabbedPaneTBButton("data/images/copy.gif", "Copy", "Copy the current row",tabPaneID);
		copyButton.addActionListener(this);
		copyButton.setEnabled(false);
		toolBar.add(copyButton);

		toolBar.addSeparator(new Dimension(5, 5));

		// Paste
		pasteButton = new BBTabbedPaneTBButton("data/images/paste.gif", "Paste", "Paste row from clipboard",tabPaneID);
		pasteButton.addActionListener(this);
		pasteButton.setEnabled(false);
		toolBar.add(pasteButton);

		toolBar.addSeparator(new Dimension(10, 10));

		// Add
		addButton = new BBTabbedPaneTBButton("data/images/new.gif", "Add", "Add a new row",tabPaneID);
		addButton.addActionListener(this);
		addButton.setEnabled(false);
		toolBar.add(addButton);

		toolBar.addSeparator(new Dimension(5, 5));

		// Delete
		deleteButton = new BBTabbedPaneTBButton("data/images/delete.gif", "Delete", "Delete the current row",tabPaneID);
		deleteButton.addActionListener(this);
		deleteButton.setEnabled(false);
		toolBar.add(deleteButton);

		toolBar.setFloatable(false);

		return toolBar;
	}

	/**
	 * Creates the statusbar
	 */
	protected JLabel createStatusBar()
	{
		statusLabel  = new JLabel();

		statusLabel.setText("Ready");
		statusLabel.setBorder(BorderFactory.createLoweredBevelBorder());
		statusLabel.setFont(new Font("Helvetica",Font.BOLD, 12));

		return statusLabel;
	}

	/**
	 * Handles actions for all the menu items and the toolbar buttons
	 */
	public void actionPerformed(ActionEvent e)
	{
		String actionStr = e.getActionCommand();
		
		handleMenuToolBarActions(actionStr);
	}

	void handleMenuToolBarActions(String actionStr)
	{
		if (actionStr.equals("Save"))
		{
			boolean bRet = validateValuesInTables();
			if (bRet == false)
			{
				return;		// Do not save until duplicates are removed
			}

			handleSave();
		}
		else if (actionStr.equals("Exit"))
		{
			handleExit();
		}
		else if (actionStr.equals("Copy"))
		{
			handleCopy();
		}
		else if (actionStr.equals("Paste"))
		{
			handlePaste();

		}
		else if (actionStr.equals("Delete"))
		{
			handleDelete();
		}
		else if (actionStr.equals("Add"))
		{
			handleAdd();
		}
		else if (actionStr.equals("About"))
		{
			new AboutDialog(new JFrame(), "About BlueBird");
		}

		// options
		else if (actionStr.equals("Metal"))
		{
        	setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");
		}

		else if (actionStr.equals("CDE/Motif"))
		{
       			UIManager.put("Table.background", Color.white); 
       			UIManager.put("ScrollPane.background", Color.white); 
			setLookAndFeel("com.sun.java.swing.plaf.motif.MotifLookAndFeel");
		}

		else if (actionStr.equals("Windows"))
		{
			setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		}
	}

	private void setLookAndFeel(String str)
	{
	    setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));

		try 
		{

        	UIManager.setLookAndFeel(str);

			if (!bLandFAtStartUp)
			{
	   			SwingUtilities.updateComponentTreeUI(this);
			}

		} catch (Exception exc) 
		{
			System.err.println("can't get to the " + str + " look and feel");

			// try and go back to default
			try
			{
				UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
	   			SwingUtilities.updateComponentTreeUI(this);
			}
			catch (Exception e)
			{
				// Don't really do anything?
			}
		}

	   	setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
	}

	private void handleCopy()
	{
		TableManipulationPanel selectedPanel=null;

		// Get selected panel
		if (iCurrentActivePanel == DEF_MANIP_PANEL)
		{
			return;
		}
		else if (iCurrentActivePanel == IPR_MANIP_PANEL)
			selectedPanel = (IPRangesManipPanel)iprPanel;

		else if (iCurrentActivePanel == SD_MANIP_PANEL)
			selectedPanel = (SpecificDevicesManipPanel)sdPanel;

		else if (iCurrentActivePanel == UC_MANIP_PANEL)
			selectedPanel = (UrlConfigManipPanel)ucPanel;

		int iSelectedRow    = selectedPanel.getSelectedRow();
		if (iSelectedRow <= -1)
					return;
	
		// Get the selected row
		Vector selRow = (Vector)selectedPanel.getTableData().elementAt(iSelectedRow);

		// Make a copy of this row in the clipboard
		int iSize = selRow.size();
		clipBoardVector = new Vector(iSize);
		for (int iIndex=0; iIndex < iSize; iIndex++)
			clipBoardVector.add(selRow.elementAt(iIndex));

		// Store as the panel the last copy occurred
		iCopyPanel    = iCurrentActivePanel;

		//enable paste is same panel
		pasteMenuItem.setEnabled(true);
		pasteButton.setEnabled(true);
	}

	private void handleDelete()
	{
		// handle row removal
		if (iCurrentActivePanel == DEF_MANIP_PANEL)
		{
			return;
		}
		else if (iCurrentActivePanel == IPR_MANIP_PANEL)
		{
			int iSelectedRow    = iprPanel.getSelectedRow();

			// Remove row
			if (iSelectedRow > -1)
				iprPanel.removeRow(iSelectedRow);

		}

		else if (iCurrentActivePanel == SD_MANIP_PANEL)
		{
			int iSelectedRow    = sdPanel.getSelectedRow();

			// Remove row
			if (iSelectedRow > -1)
				sdPanel.removeRow(iSelectedRow);

		}

		else if (iCurrentActivePanel == UC_MANIP_PANEL)
		{
			int iSelectedRow    = ucPanel.getSelectedRow();

			// Remove row
			if (iSelectedRow > -1)
				ucPanel.removeRow(iSelectedRow);

		}

	}

	private void handlePaste()
	{
		if (iCopyPanel != iCurrentActivePanel)
		{
	 		JOptionPane.showMessageDialog(null, "Paste Warning!", "Can only copy a row from the same panel", JOptionPane.WARNING_MESSAGE);
		}
		else
		{
			if(iCurrentActivePanel == IPR_MANIP_PANEL)
			{
				iprPanel.pasteRow(clipBoardVector);

			}
			else if(iCurrentActivePanel == SD_MANIP_PANEL)
			{
				sdPanel.pasteRow(clipBoardVector);
			}
			else if(iCurrentActivePanel == UC_MANIP_PANEL)
			{
				ucPanel.pasteRow(clipBoardVector);
			}
		}
	}

	private void handleExit()
	{
		// Also check if the table contents were modified
		// in any of the panels by an add/modify

		boolean bDefChanged = dPanel.isTableChanged();
		boolean bIprChanged = iprPanel.isTableChanged();
		boolean bSdChanged  = sdPanel.isTableChanged();
		boolean bUcChanged  = ucPanel.isTableChanged();

		boolean bConfigChanged = bDefChanged | bIprChanged | bSdChanged | bUcChanged;

		// Check if contents have been saved
		if (bConfigChanged == true)
		{

			Object[] options = {"Save and exit", "Exit without save", "Cancel"};

			int value = JOptionPane.showOptionDialog(this,
							"Changes to configurations have NOT been saved. Save now?",
							"SNMP Configuration Exit..",
							JOptionPane.YES_NO_CANCEL_OPTION,
							JOptionPane.QUESTION_MESSAGE,
							null,
							options,
							options[0]);


			if (value == JOptionPane.YES_OPTION)
			{
				boolean bRet = validateValuesInTables();
				if (bRet == false)
				{
					return;		// Do not save until duplicates are removed
				}

				handleSave();
			}
			else if (value == JOptionPane.CANCEL_OPTION)
			{
				// cancel exit
				return;
			}
			else if (value == JOptionPane.CLOSED_OPTION)
			{
				// Don't let the user bypass this dialog
				handleExit();
				return;
			}
		}

		// Save User Profile
		saveUserProfile();

		snmpFrame.dispose();

	}

	/**
	 * <pre>Handles the storing of user preferences to the user profile 
	 * file. If the write into the profile file fails, the step is retried 
	 * thrice as a minimum mechanism to offset the possiblity of a different
	 * application currently writing into the profile
	 */
	protected void saveUserProfile()
	{
		// Update the userProfile Hashtable

		// position
		Integer xpos = new Integer(snmpFrame.getX());
		Integer ypos = new Integer(snmpFrame.getY());

		// dimension
		Dimension frameSize = snmpFrame.getSize();
		Integer width = new Integer(frameSize.width);
		Integer height = new Integer(frameSize.height);

		userProfile.put(XPOS, xpos);
		userProfile.put(YPOS, ypos);
		userProfile.put(WIDTH, width);
		userProfile.put(HEIGHT, height);

		// look and feel
		String landf = UIManager.getLookAndFeel().getName();
		userProfile.put(LOOKNFEEL, landf);
		
		boolean bNotWritten = true;
		int		iNumTries=0;

		while(bNotWritten && iNumTries < 3)
		{
			try
			{
				new SnmpUserProfWriter(userProfile, userID);
				bNotWritten = false;
			}
			catch (Exception e)
			{
				bNotWritten = true;
			}
			
			if (bNotWritten)
			{
				iNumTries++;

				try
				{
					Thread.sleep(300);
				}
				catch (InterruptedException ex) { }

			}
		}
	}
	private void handleAdd()
	{

		if(iCurrentActivePanel == DEF_MANIP_PANEL)
		{
			return;
		}
		else if(iCurrentActivePanel == IPR_MANIP_PANEL)
		{
			iprPanel.addEntryToTable();

		}
		else if(iCurrentActivePanel == SD_MANIP_PANEL)
		{
			sdPanel.addEntryToTable();

		}
		else if(iCurrentActivePanel == UC_MANIP_PANEL)
		{
				ucPanel.addEntryToTable();
		}
	}

	private void handleSave()
	{
		// Save into xml
		try
		{
			new SnmpXmlWriter(	dPanel.getTableData(),
								iprPanel.getTableColumns(),
								iprPanel.getTableData(),
								sdPanel.getTableColumns(),
								sdPanel.getTableData(),
								ucPanel.getTableColumns(),
								ucPanel.getTableData());
		}
		catch (Exception e)
		{
	 		JOptionPane.showMessageDialog(new JFrame(), 
					"Unable to save changes to xml file!\n" + e.getMessage(),
					"Error! ", 
					JOptionPane.ERROR_MESSAGE);

			return;
		}

		// Set the panels to indicate the saved state
		dPanel.setTableSaved();
		iprPanel.setTableSaved();
		sdPanel.setTableSaved();
		ucPanel.setTableSaved();

		statusLabel.setText("Ready");
	}

	protected boolean validateValuesInTables()
	{
		boolean ret=false;

		// Check in the default panel
		ret = dPanel.validateValues();
		if (ret == false)
			return ret;

		// Check in the IP Ranges panel
		ret = iprPanel.validateValues();
		if (ret == false)
			return ret;

		// Check in the specific devices panel
		ret = sdPanel.validateValues();
		if (ret == false)
			return ret;

		// Check in the url panel
		ret = ucPanel.validateValues();
		if (ret == false)
			return ret;

		return true;
	}

	/**
	 * Creates the tabbed pane by reading data from the xml file
	 */
	protected BBTabbedPane createBBTabbedPanes()
	{
		SnmpXmlParser  				parser;

		try
		{
			parser=new SnmpXmlParser();
			parser.parse("data/common/conf/snmpXML.xml");

		} catch (Exception e)
		{
	 		JOptionPane.showMessageDialog(new JFrame(), 
					e.getMessage(),
					"Error! Unable to parse input xml file", 
					JOptionPane.ERROR_MESSAGE);

			bParseException=true;
			return null;
		}

		BBTabbedPane snmpPane = new BBTabbedPane("SnmpConfig");

		createDefaultPanel(parser);
		snmpPane.addTab("Default", null, dPanel, "Configure Default Parameters");
		snmpPane.setMnemonicAt(DEF_MANIP_PANEL, 'D');

		createRangesPanel(parser);
		snmpPane.addTab("Ranges", null, iprPanel, "Configure IP Ranges");
		snmpPane.setMnemonicAt(IPR_MANIP_PANEL, 'R');

		createSpecificDevicesPanel(parser);
		snmpPane.addTab("Specific Devices", null, sdPanel, "Configure Specific Devices");
		snmpPane.setMnemonicAt(SD_MANIP_PANEL, 'S');

		createUrlConfigPanel(parser);
		snmpPane.addTab("URL Configuration", null, ucPanel, "Configure local files or URLs");
		snmpPane.setMnemonicAt(UC_MANIP_PANEL, 'U');

		return snmpPane;
	}

	/**
	 * Creates the 'Default' panel
	 */
	protected void createDefaultPanel(SnmpXmlParser parser)
	{
		dPanel = new DefaultManipPanel(parser.getDefaultData(), 
										parser.getDefaultColumns());
	}

	/**
	 * Creates the 'Ranges' panel
	 */
	protected void createRangesPanel(SnmpXmlParser parser)
	{
		iprPanel = new IPRangesManipPanel(parser.getRangesData(), 
												parser.getRangesColumns());
	}

	/**
	 * Creates the 'Specific Devices' panel
	 */
	protected void createSpecificDevicesPanel(SnmpXmlParser parser)
	{
		sdPanel = new SpecificDevicesManipPanel(parser.getSpecificsData(), 
												parser.getSpecificsColumns());
	}

	/**
	 * Creates the 'Url' panel
	 */
	protected void createUrlConfigPanel(SnmpXmlParser parser)
	{
		ucPanel = new UrlConfigManipPanel(parser.getUrlsData(), 
												parser.getUrlsColumns());
	}

}


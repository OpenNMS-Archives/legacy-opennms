//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.common.utils;

import java.io.*;
import java.util.Calendar;

/**
 * <pre>UserProfWriter is a general user profile writer that each application
 * can extend.
 *
 * It provides the mechanism to write the DTD, header and all other 
 * applications. Also skips the old information for the current application
 * All subclasses need to do is override the 'writeCurApplInfo()' method
 * to write out the current application block and call the 'writeInto()'
 * method with the appropriate filename
 *
 * It throws an IOException if the user profile file write fails for
 * any reason
 *
 * @author Sowmya
 *
 */
public class UserProfWriter 
{
	public String APPL_NAME		=null;
	public final String APPL_CLS="</appl>";

	final String PERSPROF		="<persProf>\n";
	final String PERSPROF_CLS	="</persProf>\n";

	/**
 	 * Writes into the filename passed in
 	 */
	public UserProfWriter(String applName) throws IOException
	{
		APPL_NAME = new String("<appl name=\"" + applName + "\">");
	}

	protected void writeInto(String fileName) throws IOException
	{
		FileReader fileReader;
		FileWriter fileWriter;

		StringBuffer DTDBuffer=new StringBuffer();

		try
		{
			fileReader = new FileReader(fileName);
			readDTD(fileReader, DTDBuffer);

		} catch (IOException e)
		{
			throw(e);
		}

		// skip header
		skipHeader(fileReader);

		// read data till this appl
		StringBuffer bufTillCurAppl=new StringBuffer();

		try
		{
			readTillCurAppl(fileReader, bufTillCurAppl);

		} catch (IOException readTillExc)
		{
			throw(readTillExc);
		}

		// get to the correct offset - skip old info
		skipCurApplOldInfo(fileReader);

		// read data after this appl
		StringBuffer bufAfterCurAppl=new StringBuffer();

		try
		{
			readAfterCurAppl(fileReader, bufAfterCurAppl);

		} catch (IOException readAfterExc)
		{
			throw(readAfterExc);
		}


		fileWriter = new FileWriter(fileName);

		// write DTD
		writeInfo(fileWriter, DTDBuffer);

		// now write the right header..
		writeHeader(fileWriter);

		// write the appls before this one
		writeInfo(fileWriter, bufTillCurAppl);
		
		// write most current application values
		writeCurApplInfo(fileWriter);
		
		// write the appls after this one
		writeInfo(fileWriter, bufAfterCurAppl);

		fileWriter.flush();

	}

	void writeInfo(FileWriter fileWriter, StringBuffer infoBuffer) 
													throws IOException
	{
		fileWriter.write(infoBuffer.toString());
	}

	void writeHeader(FileWriter fileWriter) throws IOException
	{
		fileWriter.write(PERSPROF);

		// get current date
		Calendar curCal = new java.util.GregorianCalendar();

		// milliseconds since Jan 1st 1970
		long ms = curCal.getTime().getTime();

		int year = curCal.get(Calendar.YEAR);
		int month = curCal.get(Calendar.MONTH) + 1;
		int day = curCal.get(Calendar.DAY_OF_MONTH);
		int hour = curCal.get(Calendar.HOUR_OF_DAY);
		int min = curCal.get(Calendar.MINUTE);
		int sec = curCal.get(Calendar.SECOND);

		StringBuffer createdDate = new StringBuffer("<created year=\""+ year +"\"");
		createdDate.append(" month=\"" +month+"\"");
		createdDate.append(" day=\"" + day + "\"");
		createdDate.append(" hour=\"" + hour +"\"");
		createdDate.append(" min=\"" + min + "\"");
		createdDate.append(" sec=\"" + sec + "\">");

		fileWriter.write("\t<header>\n");

		fileWriter.write("\t\t" + createdDate + "\n");
		fileWriter.write("\t\t\t" + ms + "\n");
		fileWriter.write("\t\t</created>\n");
		fileWriter.write("\t\t<MSname>master.nmanage.com</MSname>\n");
		fileWriter.write("\t\t<rev>1.1a</rev>\n");
		fileWriter.write("\t</header>");
	}

	protected void writeCurApplInfo(FileWriter fileWriter) throws IOException
	{
		// subclasses to override this method

		// appl name
		fileWriter.write(APPL_NAME + "\n");
		fileWriter.write("\t" + APPL_CLS);

	}

	void readDTD(FileReader fileReader, StringBuffer DTDBuffer) 
													throws IOException
	{
		int curInt = fileReader.read();
		char curChar = (char)curInt;
		char prevChar = curChar;

		while ( curInt != -1)
		{
			if (curChar == '>' && prevChar == ']')
			{
				DTDBuffer.append(curChar);
				DTDBuffer.append('\n');
				DTDBuffer.append('\n');
				break;
			}

			if (curChar != '\r')
				DTDBuffer.append(curChar);

			prevChar = curChar;
			curInt = fileReader.read();
			curChar = (char)curInt;
		}
	}

	void skipHeader(FileReader fileReader) throws IOException
	{
		int curInt = fileReader.read();
		char curChar = (char)curInt;
		char prevChar = curChar;

		while ( curInt != -1)
		{
			if (curChar == '/' && prevChar == '<')
			{
				StringBuffer tempBuf = new StringBuffer("</");

				curInt = fileReader.read();
				curChar = (char)curInt;
				while(curInt != -1 && curChar != '>') 
				{
					tempBuf.append(curChar);

					curInt = fileReader.read();
					curChar = (char)curInt;
				}
				if (curChar == '>')
				{
					tempBuf.append(curChar);
				}

				if (tempBuf.toString().equals("</header>"))
				{
					return;
				}
			}

			prevChar = curChar;
			curInt = fileReader.read();
			curChar = (char)curInt;
		}
	}

	void readTillCurAppl(FileReader fileReader, StringBuffer bufTillCurAppl) 
													throws IOException
	{
		int curInt = fileReader.read();
		char curChar = (char)curInt;
		char prevChar = curChar;

		while ( curInt != -1)
		{
			if (curChar == 'a' && prevChar == '<')
			{
				StringBuffer tempBuf = new StringBuffer("<a");

				curInt = fileReader.read();
				curChar = (char)curInt;
				while(curInt != -1 && curChar != '>') 
				{
					tempBuf.append(curChar);

					curInt = fileReader.read();
					curChar = (char)curInt;
				}
				if (curChar == '>')
					tempBuf.append(curChar);

				if (tempBuf.toString().equals(APPL_NAME))
				{

					bufTillCurAppl.setLength(bufTillCurAppl.length()-1);
					return;
				}
				else
				{
					int len = tempBuf.length();
					tempBuf.delete(0, 1);
					tempBuf.delete(len-2, len-1);

					bufTillCurAppl.append(tempBuf.toString());
				}
			}

			if (curChar != '\r')
				bufTillCurAppl.append(curChar);

			prevChar = curChar;
			curInt = fileReader.read();
			curChar = (char)curInt;
		}

		if (curInt == -1)
		{
			throw new IOException("No preious data available for current application");
		}
	}

	void skipCurApplOldInfo(FileReader fileReader) throws IOException
	{
		int curInt = fileReader.read();
		char curChar = (char)curInt;
		char prevChar = curChar;

		while ( curInt != -1)
		{
			if (curChar == '/' && prevChar == '<')
			{
				StringBuffer tempBuf = new StringBuffer("</");

				curInt = fileReader.read();
				curChar = (char)curInt;
				while(curInt != -1 && curChar != '>') 
				{
					tempBuf.append(curChar);

					curInt = fileReader.read();
					curChar = (char)curInt;
				}
				if (curChar == '>')
					tempBuf.append(curChar);

				if (tempBuf.toString().equals(APPL_CLS))
				{
					return;
				}
			}

			prevChar = curChar;
			curInt = fileReader.read();
			curChar = (char)curInt;
		}

		if (curInt == -1)
		{
			throw new IOException("No preious data available for current application");
		}
	}

	void readAfterCurAppl(FileReader fileReader, StringBuffer bufAfterCurAppl) 
													throws IOException
	{
		int curInt = fileReader.read();
		char curChar = (char)curInt;
		char prevChar = curChar;

		while ( curInt != -1)
		{
			if (curChar != '\r')
				bufAfterCurAppl.append(curChar);

			prevChar = curChar;
			curInt = fileReader.read();
			curChar = (char)curInt;
		}
	}


}

//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.common.components;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.*;

/**
 * BBBrowseRenderer creates a button as the renderer component instead of the
 * default label
 *
 * It extends the DefaultCellEditor and overrides the appropriate methods
 *
 * @author Sowmya
 *
 */
class BBBrowseRenderer extends DefaultTableCellRenderer 
{
	JButton selected;

	/**
	 * Creates the browse renderer and the button that is the renderer
	 * component
	 */
	public BBBrowseRenderer() 
	{
		super();

		selected = new JButton("...");
	}

	/**
	 * Overrides the method in the the parent class and returns the
	 * the renderer component(this)
	 */
	public Component getTableCellRendererComponent(
					JTable table, Object value,
					boolean isSelected,
					boolean hasFocus,
					int row, int col) 
	{

		if (value instanceof String)
		{
			return selected;
		}

		Boolean b = (Boolean)value;
		
		if (b.booleanValue())
		{
			return selected;
		}
		else
		{
			setText("");
			return this;
		}

	}

	/**
	 * Returns the button used to render this cell
	 *
	 * @return the button used to render this cell
	 */
	JButton getButton()
	{
		return selected;
	}
}

//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.common.panels;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;

import java.util.*;

import org.opennms.bb.eui.common.components.*;

/**
 * <pre?FileTableManipulationPanel 
 * - creates/holds a BBFileManipTable
 * - keeps track of changes to the table model
 * - provides wrapper methods around the BBFileManipTable methods for ease
 *   of use </pre>
 *
 * @author Sowmya
 *
 */
public class FileTableManipulationPanel extends TableManipulationPanel 
{
	public FileTableManipulationPanel(Vector colNames)
	{
		super(colNames);
	}

	public FileTableManipulationPanel(Vector rowData, Vector colNames)
	{
		super(rowData, colNames);
	}


	protected void createTable(Vector rowData, Vector colNames)
	{
		//Create the table
		infoTable = new  BBFileManipTable(rowData, colNames);

		infoTableModel = ((BBFileManipTable)infoTable).getTableModel();

		setViewportView(infoTable);
	}

	protected void createTable(Vector colNames)
	{
		//Create the table
		infoTable = new  BBFileManipTable(colNames);

		infoTableModel = ((BBFileManipTable)infoTable).getTableModel();

		setViewportView(infoTable);
	}

	protected void handleTableChanges(int column)
	{
		if (column != ((BBFileManipTable)infoTable).ARROW_COL &&
			column != ((BBFileManipTable)infoTable).BROWSE_COL ) 
									// Don't consider the arrow and browse cols
		{
			bTableDataChanged=true;
		}
	}

	/**
 	 * Sets focus to first column of the first row
 	 */
	public boolean initialFocus()
	{
		clearSelection();
		return ((BBFileManipTable)infoTable).setInitialFocus();
	}

	/**
 	 * Adds the new row passed in at the end of the table
 	 */
	public void addRow(Vector data)
	{
		((BBFileManipTable)infoTable).addRow(data);
		
	}

	/**
 	 * Pastes the new row passed in after the currently selected row
 	 */
	public void pasteRow(Vector data)
	{
		((BBFileManipTable)infoTable).pasteRow(data);
	}

	/**
 	 * Removes the row# iRow
 	 */
	public void removeRow(int iRow)
	{
		((BBFileManipTable)infoTable).removeRow(iRow);	

	}

	public boolean validateValues(String panelName)
	{
		return ((BBFileManipTable)infoTable).validateValues(panelName);
	}

	public DefaultTableModel getTableModel()
	{
		return ((BBFileManipTable)getTable()).getTableModel();
	}

	public Vector getTableColumns()
	{
		return ((BBFileManipTable)infoTable).getColumns();
	}
	
	public Vector getTableData()
	{
		return ((BBFileManipTable)infoTable).getData();
	}
	
	public void clearSelection()
	{
		infoTable.requestFocus();
		infoTable.clearSelection();
	}
}

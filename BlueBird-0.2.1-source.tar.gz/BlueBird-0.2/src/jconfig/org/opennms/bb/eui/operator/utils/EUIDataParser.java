//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.operator.utils;

import org.w3c.dom.*;

import java.io.*;
import java.util.Vector;
import java.util.Hashtable;

import org.opennms.bb.common.utils.BBParser;

/**
 * <pre>EUIDataParser parses the data returned for each level and stores
 * the data in a vector
 *
 * It throws an IOException if the xml file is not found or if it does not
 * conform to its DTD </pre>
 *
 * @author Sowmya
 *
 * Modifications:
 * 04/18/00 - Changed the parser to extend BBParser - Sowmya
 *
 */
public class EUIDataParser extends BBParser
{
	Vector		levelsVector;

	/*
	 * XML TAGS that are relevant
	 */
	public final String LEVELS		="levels";
	public final String LEVEL		="level";
	public final String NAME		="name";
	public final String DESCR		="descr";
	public final String NORMAL		="normal";
	public final String WARNING	="warning";
	public final String ENTITY		="entity";
	public final String LABEL		="label";
	public final String IP			="ip";
	public final String EDESCR		="edescr";
	public final String ENAME		="ename";
	public final String VALUE		="value";

	public final String ENTITIES	="entities";

	/*
	 * initial capacity of the various hashtables used is set to 6
	 * just so space is not wasted 
	 */
	 final int	INITIAL_CAPACITY = 6;

	/**
 	 */
	public EUIDataParser() 
	{
		super();
	}

	protected boolean processElement(Element el,boolean isRoot)
	{
		boolean bRet = false;

		String tag = el.getTagName();

		if (tag.equals(LEVELS))
		{
			m_curElement.replace(0, m_curElement.length(), LEVELS);

			bRet = processLevelsElement(el);
		}

		else
		{
			boolean bNodeRet=true;

			NodeList nl = el.getChildNodes();
			int size = nl.getLength();

			for(int i = 0;i < size && bNodeRet ;i++)
				bNodeRet = processNode(nl.item(i));
			
			bRet = bNodeRet;
		}
		
		return bRet;
	}

	protected boolean processLevelsElement(Node levelsNode)
	{
		boolean bRet = true;

		levelsVector = new Vector();

		NodeList nl = levelsNode.getChildNodes();
		int size = nl.getLength();
		for(int i = 0;i < size && bRet;i++)
		{
			Node curNode = nl.item(i);
			int  nodeType= curNode.getNodeType();

			if ( nodeType == Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();

				if(curTag.equals(LEVEL))
					bRet = processLevelNode(curNode);
			}
			
		}

		return bRet;
	}

	protected boolean processLevelNode(Node levelNode)
	{
		boolean bRet = true;

		NodeList nl = levelNode.getChildNodes();
		int size = nl.getLength();

		m_curElement.replace(0, m_curElement.length(), LEVEL);

		Hashtable levelHash = new Hashtable(INITIAL_CAPACITY);

		Vector	  entities	= new Vector();
		boolean   bEntityFound=false;

		for(int i = 0;i < size && bRet;i++)
		{
			Node curNode = nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();

				if(curTag.equals(NAME))
				{
					m_curElement.replace(0, m_curElement.length(), NAME);

					String levelName = processParmValue(curNode); 

					if (null != levelName)
						levelHash.put(NAME, levelName);
					else
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}
				}

				else if(curTag.equals(DESCR))
				{
					m_curElement.replace(0, m_curElement.length(), DESCR);

					String levelDescr = processParmValue(curNode); 

					if (null != levelDescr)
						levelHash.put(DESCR, levelDescr);
					else
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}
				}

				else if(curTag.equals(NORMAL))
				{
					m_curElement.replace(0, m_curElement.length(), NORMAL);

					String normal = processParmValue(curNode); 

					if (null != normal)
						levelHash.put(NORMAL, normal);
					else
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}
				}

				else if(curTag.equals(WARNING))
				{
					m_curElement.replace(0, m_curElement.length(), WARNING);

					String warning = processParmValue(curNode); 

					if (null != warning)
						levelHash.put(WARNING, warning);
					else
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}
				}

				else if(curTag.equals(ENTITY))
				{
					if (!bEntityFound)
					{
						bEntityFound = true;
					}

					bRet = processEntityNode(curNode, entities);
				}
			}
		}

		if (bEntityFound)
			levelHash.put(ENTITIES, entities);

		levelsVector.add(levelHash);

		return bRet;
	}

	protected boolean processEntityNode(Node entityNode, Vector entities)
	{
		boolean bRet = true;

		NodeList nl = entityNode.getChildNodes();
		int size = nl.getLength();

		m_curElement.replace(0, m_curElement.length(), ENTITY);

		Hashtable  entityHash = new Hashtable(INITIAL_CAPACITY);

		for(int i = 0;i < size && bRet;i++)
		{
			Node curNode = nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();

				if(curTag.equals(LABEL))
				{
					m_curElement.replace(0, m_curElement.length(), LABEL);

					String entityLabel = processParmValue(curNode); 

					if (null != entityLabel)
						entityHash.put(LABEL, entityLabel);
					else
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}
				}

				else if(curTag.equals(IP))
				{
					m_curElement.replace(0, m_curElement.length(), IP);

					String entityIP = processParmValue(curNode); 

					if (null != entityIP)
						entityHash.put(IP, entityIP);
					else
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}
				}

				else if(curTag.equals(EDESCR))
				{
					m_curElement.replace(0, m_curElement.length(), EDESCR);

					String descr = processParmValue(curNode); 

					if (null != descr)
						entityHash.put(EDESCR, descr);
					else
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}
				}

				else if(curTag.equals(ENAME))
				{
					m_curElement.replace(0, m_curElement.length(), ENAME);

					String sysName = processParmValue(curNode); 

					if (null != sysName)
						entityHash.put(ENAME, sysName);
					else
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}
				}

				else if(curTag.equals(VALUE))
				{
					m_curElement.replace(0, m_curElement.length(), VALUE);

					String value = processParmValue(curNode); 

					if (null != value)
						entityHash.put(VALUE, value);
					else
					{
						bRet = false;
					}
				}

			}
		}

		entities.add(entityHash);

		return bRet;
	}

	/**
	 */
	public Vector getLevelsVector()
	{
		return levelsVector;
	}

}

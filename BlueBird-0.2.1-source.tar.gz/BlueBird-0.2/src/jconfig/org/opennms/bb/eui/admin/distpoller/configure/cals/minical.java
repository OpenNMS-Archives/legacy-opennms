//-------------------------------------------------------------------------------------------
//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

//--------------------------------------------------------------------------------------------

package org.opennms.bb.eui.admin.distpoller.configure.cals;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;

import java.util.*;

public class minical extends JPanel 
{

	private String months[] = { "January", "February", "March", "April",
				 "May", "June", "July", "August", "September", "October", "November", "December" };

	JPanel JPanel1;
	JComboBox JComboBox1;
	JTextField JTextField1;
	JScrollBar JScrollBar1;
	JScrollPane JScrollPane1;
	Calendar calendar = new GregorianCalendar();
 	Date trialTime = new Date();
 	Vector data,cols;
	String curMonth = "";
	int curYear = 2000;
      	JTable JTable1;
	roCustomModel TableModel;
	JButton toolb1, toolb2;

	public minical() 
	{

		calendar.setTime(trialTime);
		JPanel1 = new JPanel();

		JComboBox1 = new JComboBox();
		for (int i =0; i < months.length; i++) 
		{
			JComboBox1.addItem(months[i]);
		}

		JComboBox1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int curdate = calendar.get(Calendar.DATE);
				calendar.clear(Calendar.MONTH); 
 				calendar.clear(Calendar.YEAR);
				calendar.clear(Calendar.DATE);
				curMonth = (String)JComboBox1.getSelectedItem();
				int monthNum = checkMonth();
				calendar.set(curYear, monthNum, curdate);
				int maxdays = calendar.getActualMaximum((Calendar.DAY_OF_MONTH));
				populateValues(curYear, monthNum, maxdays);
			}
		});
	

		JComboBox1.setPreferredSize(new Dimension(95, 25));
		JComboBox1.setMaximumSize(new Dimension(95, 25));

		JTextField1 = new JTextField();
		JTextField1.setText("2000");
		JTextField1.setPreferredSize(new Dimension(80, 25));
		JTextField1.setMaximumSize(new Dimension(80, 25));

		JScrollBar1 = new JScrollBar();
		JScrollBar1.addAdjustmentListener(new myAdjustmentListener());
		JScrollBar1.setPreferredSize(new Dimension(25, 25));
		JScrollBar1.setMaximumSize(new Dimension(25, 25));


		JPanel rightPanel = new JPanel();
		rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.X_AXIS));
		rightPanel.add(JTextField1);
		rightPanel.add(JScrollBar1);

		cols = new Vector();
		cols.addElement("S");
		cols.addElement("M");
		cols.addElement("Tu");
		cols.addElement("W");
		cols.addElement("T");
		cols.addElement("F");
		cols.addElement("Sa");

		data = new Vector();
		
	
		int year = 2000;
		int month = 0;

			calendar.set(year, month, 1);
			int date = calendar.get(Calendar.DATE);
			int dayofweek = calendar.get(Calendar.DAY_OF_WEEK);
			int datecounter = date;

			Vector row1 = new Vector();
		
			for (int j = 1; j < dayofweek; j++)
				row1.addElement("");

			for (int k = dayofweek; k <= 7; k++)
			{
				row1.addElement(""+datecounter);
				datecounter++;
			}

			Vector row2 = new Vector();
			for (int i = 0; i < 7; i++)
			{
				row2.addElement(""+datecounter);
				datecounter++;	
			}

			Vector row3 = new Vector();
			for (int i = 0; i < 7; i++)
			{
				row3.addElement(""+datecounter);
				datecounter++;	
			}

			Vector row4 = new Vector();
			for (int i = 0; i < 7; i++)
			{
				row4.addElement(""+datecounter);
				datecounter++;	
			}

			Vector row5 = new Vector();
			for (int i = 0; i < 7; i++)
			{
				if ( datecounter > 31 ) 
				{
					row5.addElement("");	
					break;
				}
				else
				{
					row5.addElement(""+datecounter);
					datecounter++;
				}
			}

			Vector row6 = new Vector();
			for (int i = 0; i < 7; i++)
			{
				if ( datecounter <= 31 ) 
				{
					row6.addElement("" + datecounter);
					datecounter++;
				}
				else
				{
					row6.addElement("");	
				}
							
			}
		
		data.addElement(row1);
		data.addElement(row2);
		data.addElement(row3);
		data.addElement(row4);
		data.addElement(row5);
		data.addElement(row6);
		
		TableModel = new roCustomModel(data,cols);
		JTable1 = new JTable(TableModel);
		JTable1.setRowSelectionAllowed(false);
		JTable1.setCellSelectionEnabled(true);
		JTable1.setShowVerticalLines(false);
		JTable1.setShowHorizontalLines(false);

		JTable1.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
	
		JScrollPane1 = new JScrollPane(JTable1);
		JScrollPane1.setPreferredSize(new Dimension(250,124));
		JScrollPane1.setMaximumSize(new Dimension(250,124));


		JPanel upPanel = new JPanel();
		upPanel.setLayout(new BoxLayout(upPanel, BoxLayout.X_AXIS));
		upPanel.add(JComboBox1);
		upPanel.add(Box.createHorizontalGlue());
		upPanel.add(rightPanel);
     				
		JPanel downPanel = new JPanel();
		downPanel.setLayout(new BoxLayout(downPanel, BoxLayout.X_AXIS));
		downPanel.add(JScrollPane1);

		JPanel1.setLayout(new BoxLayout(JPanel1, BoxLayout.Y_AXIS));
		JPanel1.add(upPanel);
		JPanel1.add(Box.createVerticalGlue());
		JPanel1.add(Box.createRigidArea(new Dimension(0,15)));

		JPanel1.add(downPanel);

	
		JPanel toolp = new JPanel();
		toolp.setLayout(new BoxLayout(toolp, BoxLayout.X_AXIS));
		toolp.add(addToolBar());
		toolp.add(Box.createHorizontalGlue());
		

		setLayout(new BorderLayout());
		add(toolp, BorderLayout.NORTH);
		add(JPanel1, BorderLayout.CENTER);
		
		
	}


	public JButton getToolButton1()
	{
		return toolb1;
	}

	public JButton getToolButton2()
	{
		return toolb2;
	}

	public JPanel addToolBar() {
	
  String imageStr = "data" + System.getProperty("file.separator") + "images";

		JPanel toolPanel = new JPanel();
		JToolBar toolBar = new JToolBar();

		toolb1 = 
          	  (JButton) toolBar.add(
             	  new JButton(loadImageIcon(imageStr+ System.getProperty("file.separator") + "oneDay.gif")));

		toolb2 = 
          	  (JButton) toolBar.add(
             	  new JButton(loadImageIcon(imageStr+ System.getProperty("file.separator") + "oneDayOff.gif")));


		toolb1.setToolTipText("Reset selected day to On");
		toolb2.setToolTipText("Reset selected day to Off");
		
		
		toolPanel.add(toolBar);

		return toolPanel;
	}

	public ImageIcon loadImageIcon(String filename)
	{

		 return new ImageIcon(filename);
	}
	
	class myAdjustmentListener implements AdjustmentListener
	{
		public void adjustmentValueChanged(AdjustmentEvent e) 
		{
			JTextField1.setText( (new Integer(2000 + e.getValue())).toString() );
			String yearVal = JTextField1.getText();
			curYear = Integer.parseInt(yearVal);
			calendar.clear(Calendar.MONTH); 
 			calendar.clear(Calendar.YEAR);
			int curdate = calendar.get(Calendar.DATE);
			calendar.clear(Calendar.DATE);
			int monthNum = checkMonth();
			calendar.set(curYear, monthNum, curdate);
			int maxdays = calendar.getActualMaximum((Calendar.DAY_OF_MONTH));
			populateValues(curYear, monthNum, maxdays);

		}
	}


	void populateValues(int year, int month, int days)
	{
		Vector dataVector = TableModel.getDataVector();

			calendar.set(year, month, 1);
			int date = calendar.get(Calendar.DATE);
			int dayofweek = calendar.get(Calendar.DAY_OF_WEEK);
			int datecounter = date;

			Vector row1 = (Vector)dataVector.elementAt(0);
			row1.removeAllElements();
			for (int j = 1; j < dayofweek; j++)
				row1.addElement("");

			for (int k = dayofweek; k <= 7; k++)
			{
				row1.addElement(""+datecounter);
				datecounter++;
			}

			Vector row2 = (Vector)dataVector.elementAt(1);
			row2.removeAllElements();
			for (int i = 0; i < 7; i++)
			{
				row2.addElement(""+datecounter);
				datecounter++;	
			}

			Vector row3 = (Vector)dataVector.elementAt(2);
			row3.removeAllElements();
			for (int i = 0; i < 7; i++)
			{
				row3.addElement(""+datecounter);
				datecounter++;	
			}

			Vector row4 = (Vector)dataVector.elementAt(3);
			row4.removeAllElements();
			for (int i = 0; i < 7; i++)
			{
				if ( datecounter > days ) 
				{
					row4.addElement("");
					break;
				}
				else
				{
					row4.addElement(""+datecounter);
					datecounter++;
				}
			}

			Vector row5 = (Vector)dataVector.elementAt(4);
			row5.removeAllElements();
			for (int i = 0; i < 7; i++)
			{
				if ( datecounter > days ) 
				{
					row5.addElement("");	
					break;
				}
				else
				{
					row5.addElement(""+datecounter);
					datecounter++;
				}
			}

			Vector row6 = (Vector)dataVector.elementAt(5);
			row6.removeAllElements();
			for (int i = 0; i < 7; i++)
			{
				if ( datecounter <= days ) 
				{
					row6.addElement(""+datecounter);
					datecounter++;
				}
				else
				{
					row6.addElement("");	
					
				}
			
			
			}


		Vector rowVector = new Vector();
		rowVector.addElement(row1);
		rowVector.addElement(row2);
		rowVector.addElement(row3);
		rowVector.addElement(row4);
		rowVector.addElement(row5);
		rowVector.addElement(row6);

		TableModel.setDataVector(rowVector, cols);
		JTable1.sizeColumnsToFit(-1);
	}

	int checkMonth() 
	{
	       if (curMonth == "January") return 0;
		 else if (curMonth == "February") return 1;
	       else  if (curMonth == "March") return 2;
		 else if (curMonth == "April")  return 3;
		 else if (curMonth == "May") return 4;
		 else if (curMonth == "June") return 5;
		 else if (curMonth == "July") return 6;
		 else if (curMonth == "August") return 7;
		 else if (curMonth == "September") return 8;
		 else if (curMonth == "October") return 9;
		 else if (curMonth == "November") return 10;
		 else if (curMonth == "December") return 11;
		 else return 0;

			
	}
	
}
 

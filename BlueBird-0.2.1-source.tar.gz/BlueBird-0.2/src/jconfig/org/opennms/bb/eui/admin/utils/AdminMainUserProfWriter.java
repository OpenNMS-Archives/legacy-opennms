//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.admin.utils;

import java.io.*;
import java.util.Vector;
import java.util.Hashtable;
import java.util.Calendar;

import org.opennms.bb.eui.common.utils.UserProfWriter;

/**
 * <pre>AdminMainUserProfWriter writes the user preferences for the AdminMain
 * config into the user profile file
 *
 * It throws an IOException if the user profile file write fails for
 * any reason
 *
 * @author Sowmya
 *
 */
public class AdminMainUserProfWriter extends UserProfWriter
{
	Hashtable	userProfile;

	final String PERSPROF		="<persProf>\n";
	final String PERSPROF_CLS	="</persProf>\n";

	final String PARM 			="<parm>";
	final String PARM_CLS		="</parm>\n";

	final String PARM_NAME		="<parmName>";
	final String PARM_NAME_CLS	="</parmName>\n";

	final String PARM_VALUE		="<value>";
	final String PARM_VALUE_CLS	="</value>\n";

	// user profile values
	final String XPOS			="xPos";
	final String YPOS			="yPos";
	final String WIDTH			="Width";
	final String HEIGHT			="Height";
	final String LOOKNFEEL		="lookAndFeel";
	final String ROWCOL			="rowCol";
	final String LAYOUT			="layout";

	/**
 	 * Writes into the file for the user
 	 */
	public AdminMainUserProfWriter(Hashtable inpUserProfile, String userID) 
													throws IOException
	{
		super("AdminMain");

		userProfile = inpUserProfile;

		String filename = "data/users/" + userID + ".xml";
		writeInto(filename);
	}

	protected void writeCurApplInfo(FileWriter fileWriter) throws IOException
	{
		// appl name
		fileWriter.write(APPL_NAME + "\n");

		// write position
		writePosition(fileWriter); 

		// Dimension
		writeDimension(fileWriter);

		// Look
		writeLook(fileWriter);

		// Layout
		writeLayout(fileWriter);

		fileWriter.write("\t" + APPL_CLS);
	}

	void writePosition(FileWriter fileWriter) throws IOException
	{
		// write x position
		fileWriter.write("\t\t" + PARM + "\n");
		fileWriter.write("\t\t\t" + PARM_NAME);
		fileWriter.write(XPOS);
		fileWriter.write(PARM_NAME_CLS);

		fileWriter.write("\t\t\t" + PARM_VALUE);
		char[] xpos = String.valueOf(userProfile.get(XPOS)).toCharArray();
		fileWriter.write(xpos);
		fileWriter.write(PARM_VALUE_CLS);

		fileWriter.write("\t\t" + PARM_CLS);

		// write y position
		fileWriter.write("\t\t" + PARM + "\n");
		fileWriter.write("\t\t\t" + PARM_NAME);
		fileWriter.write(YPOS);
		fileWriter.write(PARM_NAME_CLS);

		fileWriter.write("\t\t\t" + PARM_VALUE);
		char[] ypos = String.valueOf(userProfile.get(YPOS)).toCharArray();
		fileWriter.write(ypos);
		fileWriter.write(PARM_VALUE_CLS);

		fileWriter.write("\t\t" + PARM_CLS);
	}

	void writeDimension(FileWriter fileWriter) throws IOException
	{
		// write width
		fileWriter.write("\t\t" + PARM + "\n");
		fileWriter.write("\t\t\t" + PARM_NAME);
		fileWriter.write(WIDTH);
		fileWriter.write(PARM_NAME_CLS);

		fileWriter.write("\t\t\t" + PARM_VALUE);
		char[] width = String.valueOf(userProfile.get(WIDTH)).toCharArray();
		fileWriter.write(width);
		fileWriter.write(PARM_VALUE_CLS);

		fileWriter.write("\t\t" + PARM_CLS);

		// write height
		fileWriter.write("\t\t" + PARM + "\n");
		fileWriter.write("\t\t\t" + PARM_NAME);
		fileWriter.write(HEIGHT);
		fileWriter.write(PARM_NAME_CLS);

		fileWriter.write("\t\t\t" + PARM_VALUE);
		char[] height = String.valueOf(userProfile.get(HEIGHT)).toCharArray();
		fileWriter.write(height);
		fileWriter.write(PARM_VALUE_CLS);

		fileWriter.write("\t\t" + PARM_CLS);
	}

	void writeLook(FileWriter fileWriter) throws IOException
	{
		// write look and feel
		fileWriter.write("\t\t" + PARM + "\n");
		fileWriter.write("\t\t\t" + PARM_NAME);
		fileWriter.write(LOOKNFEEL);
		fileWriter.write(PARM_NAME_CLS);

		fileWriter.write("\t\t\t" + PARM_VALUE);
		char[] landf = String.valueOf(userProfile.get(LOOKNFEEL)).toCharArray();
		fileWriter.write(landf);
		fileWriter.write(PARM_VALUE_CLS);

		fileWriter.write("\t\t" + PARM_CLS);

	}

	void writeLayout(FileWriter fileWriter) throws IOException
	{
		// write layout 
		fileWriter.write("\t\t" + PARM + "\n");
		fileWriter.write("\t\t\t" + PARM_NAME);
		fileWriter.write(LAYOUT);
		fileWriter.write(PARM_NAME_CLS);

		fileWriter.write("\t\t\t" + PARM_VALUE);
		char[] layout = String.valueOf(userProfile.get(LAYOUT)).toCharArray();
		fileWriter.write(layout);
		fileWriter.write(PARM_VALUE_CLS);

		fileWriter.write("\t\t" + PARM_CLS);

		// write rowcol 
		fileWriter.write("\t\t" + PARM + "\n");
		fileWriter.write("\t\t\t" + PARM_NAME);
		fileWriter.write(ROWCOL);
		fileWriter.write(PARM_NAME_CLS);

		fileWriter.write("\t\t\t" + PARM_VALUE);
		char[] rowcol = String.valueOf(userProfile.get(ROWCOL)).toCharArray();
		fileWriter.write(rowcol);
		fileWriter.write(PARM_VALUE_CLS);

		fileWriter.write("\t\t" + PARM_CLS);

	}

}

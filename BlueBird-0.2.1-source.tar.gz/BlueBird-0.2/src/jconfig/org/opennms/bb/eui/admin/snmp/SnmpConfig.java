//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//


package org.opennms.bb.eui.admin.snmp;

import javax.swing.*;
import java.awt.event.*;

import org.opennms.bb.eui.admin.snmp.panels.SnmpConfigPanel;
import org.opennms.bb.eui.admin.interfaces.AdminTool;

/**
 * SnmpConfig is the main frame for the 'SnmpConfig' 
 *
 * @author Sowmya
 *
 */

public class SnmpConfig extends JFrame implements AdminTool
{
	SnmpConfigPanel  snmpConfigPanel;

	public SnmpConfig()
	{
		super("Configure SNMP Parameters");
	}

	public SnmpConfig(String frameTitle)
	{
		super(frameTitle);
	}

	public void start(String userID)
	{
		SnmpConfigInit(userID);
	}

	void SnmpConfigInit(String userID)
	{
		snmpConfigPanel = new SnmpConfigPanel(this, userID);
		getContentPane().add(snmpConfigPanel);

		// listen for close
		addWindowListener(new WindowAdapter()
		{
			public void windowOpened(WindowEvent e)
			{
				snmpConfigPanel.handleWindowOpen();
			}

			public void windowClosing(WindowEvent e)
			{
				snmpConfigPanel.handleWindowClose();
			}
		});

		pack();
		setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
	}

	/**
	 * Creates the SnmpConfig  
	 * Sets the UI to be system dependant - this can be changed later
	 * by using the menu options
	 */
	public static void main(String[] args)
	{
		// Set look and feel
		try
		{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());

			//UIManager.setLookAndFeel("com.sun.java.swing.plaf.motif.MotifLookAndFeel");
        	//UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");
		}
		catch (Exception e)
		{
			// Don't really do anything?
		}


		SnmpConfig snmpConfig = new SnmpConfig("Configure SNMP Parameters");
		snmpConfig.start("admin");
 	}

}

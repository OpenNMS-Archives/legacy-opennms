//-------------------------------------------------------------------------------------------
//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

//--------------------------------------------------------------------------------------------

package org.opennms.bb.eui.admin.distpoller.configure.dpconf;
import org.opennms.bb.eui.admin.interfaces.AdminTool;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class dpconfigframe extends JFrame implements AdminTool
{

	//DPConfigF  dpcf;

	public dpconfigframe()
	{
		super("Configuring Distributed Pollers");
	}

	public dpconfigframe(String frameTitle)
	{
		super(frameTitle);
	}

	public void start(String userID)
	{
		dpconfigframeInit();
	}

	void dpconfigframeInit()
	{
		DPConfigF dpcf  = new DPConfigF();
		dpcf.setVisible(true);

		WindowListener l = new WindowAdapter() 
		{
	    		public void windowClosing(WindowEvent e) 
			{
				dispose();
			}
		};


		// listen for close
		/*addWindowListener(new WindowAdapter()
		{
			public void windowOpened(WindowEvent e)
			{
				servModelConfigPanel.handleWindowOpen();
			}

			public void windowClosing(WindowEvent e)
			{
				servModelConfigPanel.handleWindowClose();
			}
		});*/

		//pack();
		setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
	}

	/**
	 * Sets the User Interface - System look and feel
	 */
	public static void main(String[] args)
	{
		// Set look and feel
		try
		{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		}
		catch (Exception e)
		{
		}


		dpconfigframe dpc = new dpconfigframe("Configure Distributed Pollers");
		dpc.start("admin");
 	}
}
//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.admin.snmp.components;

import java.awt.event.*;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.CellEditorListener;

import org.opennms.bb.eui.common.components.BBColumnEditor;
import org.opennms.bb.eui.common.components.BBTabbedPane;

/**
 * SnmpColumnEditor sets the 'SnmpConfig' tabbed pane to either
 * dirty or clean based on the value just entered
 *
 * @author Sowmya
 *
 */
public class SnmpColumnEditor extends BBColumnEditor
{
	final String TAB_PANE_ID="SnmpConfig";

	public SnmpColumnEditor(final JTextField colText)
	{
		super(colText);

		colText.addFocusListener(new FocusAdapter()
		{
			public void focusLost(FocusEvent e)
			{
				if(colText.isValid())
				{
					BBTabbedPane.setDirty(TAB_PANE_ID, false);
				}
				else
				{
					BBTabbedPane.setDirty(TAB_PANE_ID, true);
				}

			}
		});

		addCellEditorListener(new CellEditorListener()
		{
			public void editingCanceled(ChangeEvent e)
			{
				BBTabbedPane.setDirty(TAB_PANE_ID, false);
			}
	
			public void editingStopped(ChangeEvent e) { }
		});
	}


}


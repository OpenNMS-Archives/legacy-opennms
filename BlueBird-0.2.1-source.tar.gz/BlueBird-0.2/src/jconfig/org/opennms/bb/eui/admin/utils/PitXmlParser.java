//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.admin.utils;

import org.w3c.dom.*;

import java.io.*;
import java.util.Vector;
import java.util.Hashtable;
import java.util.Enumeration;

import org.opennms.bb.common.utils.BBParser;

/**
 * <pre> PitXmlParser parses the PitXML and stores the data read in a vectors
 * This can then be queried for the data using the 'get..' functions
 *
 * It throws an IOException if the xml file is not found or if it does not
 * conform to its DTD </pre>
 *
 * @author Sowmya
 *
 */
public class PitXmlParser  extends BBParser
{
	Hashtable	titleData;
	Hashtable	panelData;
	Hashtable	iconLayoutData;
	Vector		toolsData;

	/*
	 * XML TAGS
	 */
	final String ADMIN_MAIN	="adminMain";
	final String TITLE		="title";
	final String POSITION	="position";
	final String FONT_TYPE	="fontType";
	final String FONT_STYLE	="fontStyle";
	final String FONT_SIZE	="fontSize";

	final String PANEL		="panel";
	final String BGCOLOR	="bgColor";
	final String LAYOUT		="layout";
	final String ROWCOL		="rowCol";

	final String ICONLAYOUT	="iconLayout";
	final String LABELPOS	="labelPos";

	final String TOOLS		="tools";
	final String TOOL		="tool";
	final String ICON		="icon";
	final String HINT		="hint";
	final String CLASSNAME	="classname";
	final String LABEL		="label";
	final String LABELTEXT	="text";
	final String HOTKEY		="hotkey";


	/*
	 * initial capacity of the various hashtables used is set to 6
	 * just so space is not wasted 
	 */
	 final int	INITIAL_CAPACITY = 6;

	/**
 	 * Constructs the DOM parser
 	 */
	public PitXmlParser()
	{
		super();
	}

	protected boolean processElement(Element el,boolean isRoot)
	{
		boolean bRet = false;

		String tag = el.getTagName();

		if (tag.equals(TITLE))
		{
			m_curElement.replace(0, m_curElement.length(), TITLE);

			titleData = new Hashtable(INITIAL_CAPACITY);

			bRet = processTitleElement(el);
		}

		else if (tag.equals(PANEL))
		{
			m_curElement.replace(0, m_curElement.length(), PANEL);

			panelData = new Hashtable(INITIAL_CAPACITY);
			bRet = processPanelElement(el);
		}

		else if (tag.equals(ICONLAYOUT))
		{
			m_curElement.replace(0, m_curElement.length(), ICONLAYOUT);

			iconLayoutData = new Hashtable(INITIAL_CAPACITY);
			bRet = processIconLayoutElement(el);
		}

		else if (tag.equals(TOOLS))
		{
			m_curElement.replace(0, m_curElement.length(), TOOLS);

			// data
			toolsData = new Vector();
			bRet = processToolsElement(el);
		}

		else
		{
			boolean bNodeRet=true;

			NodeList nl = el.getChildNodes();
			int size = nl.getLength();

			for(int i = 0;i < size && bNodeRet ;i++)
				bNodeRet = processNode(nl.item(i));
			
			bRet = bNodeRet;
		}
		
		return bRet;
	}

	protected boolean processTitleElement(Node titleNode)
	{
		boolean bRet = true;

		String titleText = processParmValue(titleNode); 
		if (null != titleText)
			titleData.put(TITLE, titleText.trim()); 
		else
		{
			bRet = false;
			m_errNum = NULL_VALUE_ERR;
		}

		Element titleElem = (Element)titleNode;
		
		// position
		titleData.put(POSITION, titleElem.getAttribute(POSITION));
		titleData.put(FONT_TYPE, titleElem.getAttribute(FONT_TYPE));
		titleData.put(FONT_STYLE, titleElem.getAttribute(FONT_STYLE));
		titleData.put(FONT_SIZE, titleElem.getAttribute(FONT_SIZE));

		return bRet;

	}

	protected boolean processPanelElement(Node panelNode)
	{
		boolean bRet = true;

		Element panelElem = (Element)panelNode;

		// position
		panelData.put(BGCOLOR, panelElem.getAttribute(BGCOLOR));
		panelData.put(LAYOUT, panelElem.getAttribute(LAYOUT));
		panelData.put(ROWCOL, panelElem.getAttribute(ROWCOL));

		return bRet;

	}

	protected boolean processIconLayoutElement(Node iconLayoutNode)
	{
		boolean bRet = true;

		Element iconLayoutElem = (Element)iconLayoutNode;

		iconLayoutData.put(LABELPOS, iconLayoutElem.getAttribute(LABELPOS));
		iconLayoutData.put(FONT_TYPE, iconLayoutElem.getAttribute(FONT_TYPE));
		iconLayoutData.put(FONT_STYLE, iconLayoutElem.getAttribute(FONT_STYLE));
		iconLayoutData.put(FONT_SIZE, iconLayoutElem.getAttribute(FONT_SIZE));

		return bRet;

	}

	protected boolean processToolsElement(Node toolsNode)
	{
		boolean bRet = true;

		NodeList nl = toolsNode.getChildNodes();
		int size = nl.getLength();
		for(int i = 0;i < size && bRet;i++)
		{
			Node curNode = nl.item(i);
			int  nodeType= curNode.getNodeType();

			if ( nodeType == Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();

				if(curTag.equals(TOOL))
					bRet = processToolsTool(curNode);

			}
			
		}

		return bRet;
	}

	protected boolean processToolsTool(Node toolNode)
	{
		boolean bRet = true;

		NodeList nl = toolNode.getChildNodes();
		int size = nl.getLength();

		Hashtable toolHash = new Hashtable(INITIAL_CAPACITY);

		for(int i = 0;i < size && bRet;i++)
		{
			Node curNode = nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				Element toolElem = (Element)curNode;
				String curTag = ((Element)curNode).getTagName();

				if(curTag.equals(ICON))
				{
					String iconValue = processParmValue(curNode); 

					if (null != iconValue)
						toolHash.put(ICON, iconValue);
					else
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}
				}
				else if(curTag.equals(CLASSNAME))
				{
					String classValue = processParmValue(curNode); 

					if (null != classValue)
					{
						toolHash.put(CLASSNAME, classValue);
					}
					else
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}
				}
				else if(curTag.equals(HINT))
				{
					String hintValue = processParmValue(curNode); 

					if (null != hintValue)
						toolHash.put(HINT, hintValue);
					else
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}
				}
				else if(curTag.equals(LABEL))
				{
					bRet = processLabelElement(curNode, toolHash);
				}

			}
		}

		toolsData.add(toolHash);
		
		return bRet;
	}

	protected boolean processLabelElement(Node labelNode, Hashtable toolHash)
	{
		boolean bRet = true;

		NodeList nl = labelNode.getChildNodes();
		int size = nl.getLength();

		for(int i = 0;i < size && bRet;i++)
		{
			Node curNode = nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				Element toolElem = (Element)curNode;
				String curTag = ((Element)curNode).getTagName();

				if(curTag.equals(LABELTEXT))
				{
					String labelText = processParmValue(curNode); 

					if (null != labelText)
						toolHash.put(LABELTEXT, labelText.trim()); 
					else
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}
				}
				else if(curTag.equals(HOTKEY))
				{
					String hotKey = processParmValue(curNode); 

					if (null != hotKey)
						toolHash.put(HOTKEY, hotKey.trim()); 
					else
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}
				}
			}
		}

		return bRet;
	}


	/**
	 * Returns the title information as a hashtable
	 */
	public Hashtable getTitleData()
	{
		return titleData;
	}

	/**
	 * Returns the panel information as a hashtable
	 */
	public Hashtable getPanelData()
	{
		return panelData;
	}

	/**
	 * Returns the panel information as a hashtable
	 */
	public Hashtable getIconLayoutData()
	{
		return iconLayoutData;
	}

	/**
	 * Returns the tools information - the data returned is a vector
	 * of hashtables
	 */
	public Vector getToolsData()
	{
		return toolsData;
	}
}

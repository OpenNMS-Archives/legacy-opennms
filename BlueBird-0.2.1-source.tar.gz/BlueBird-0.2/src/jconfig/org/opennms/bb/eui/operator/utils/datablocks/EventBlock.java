//
// Copyright (C) 2000 N*Manage Company, Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
// $Id: EventBlock.java,v 1.2 2000/11/01 18:04:22 jacinta Exp $

package org.opennms.bb.eui.operator.utils.datablocks;

import java.util.*;

/**
 * EventBlock holds information read from an <event>..</event> block in
 * the incoming event stream
 *
 * @author Sowmya
 * @author <A HREF="http://www.opennms.org">OpenNMS.org</A>
 */
public class EventBlock extends Object
{
	/**
	 * masks for each of the eventblock element that retains 
	 * the incoming value - i.e. the incoming value overrides the
	 * value in 'event.conf'
	 */
	public static final int	SET_UEI		=1;
	public static final int	SET_SNMP	=2;
	public static final int	SET_DESCR	=4;
	public static final int	SET_LOGMSG	=8;
	public static final int	SET_SEVERITY	=16;
	public static final int	SET_OPERINSTR	=32;
	public static final int	SET_AUTOACTION	=64;
	public static final int	SET_OPERACTION	=128;
	public static final int	SET_LOGGROUP	=256;
	public static final int	SET_NOTIFICATION=512;
	public static final int	SET_TTICKET	=1024;
	public static final int	SET_FORWARD	=2048;
	public static final int	SET_MOUSEOVERTEXT=4096;

	/**
	 * A status whose bits indicates the elements whose values are not
	 * taken from the event.conf
	 */
	public int		m_status;

	/**
	 * Flag indicating if this block has been added to the database 
	 */
	public boolean		m_insertedIntoDB;

	/**
	 * The Universal Event Identifier
	 */
	public String		m_uei;

	/**
	 * The source from whihc the event arrives
	 */
	public String		m_source;

	/**
	 * Time at which the event occured
	 */
	public Date		m_time;

	/**
	 * IP address or hostname of event generator from the SNMP packet
	 */
	public String		m_host;

	/**
	 * IP address or hostname of event generator from the IP packet
	 */
	public String		m_snmpHost;

	/**
	 * SNMP info
	 */
	public EventSnmpInfo	m_snmpInfo;

	/**
	 * Parms for the event
	 */
	public Hashtable		m_eventParms;

	/**
	 * Textual description for the event
	 */
	public String		m_descr;

	/**
	 * Format of event in the event browser
	 * Also specifies if logMsg is to be suppressed/logged only/loggd and displayed etc.
	 */
	public String		m_logMsg;


	/**
	 * Severity of the event
	 */
	public String		m_severity;

	/**
	 * Instruction for the operator
	 */
	public String		m_operInstr;

	/**
	 * automatic action to be taken when this event occurs
	 */
	public Vector		m_autoAction;

	/**
	 * Action to be taken by the operator when this event occurs
	 * and the text seen by the operator(which when clicked will need to carry out the 'operaction'
	 */
	public Vector		m_operAction;

	/**
	 * log group to which this event belongs
	 */
	public Vector		m_logGroup;

	/**
	 * log type to which this event belongs
	 */
	public String		m_logType;

	/**
	 * The notification system to forward this event to
	 */
	public Vector		m_notification;

	/**
	 *  The trouble ticket system to which this event is to be forwarded to
	 *  and the trouble ticket system state
	 */
	public String		m_tticket;

	/**
	 * The forwarding detination of this event,
	 * the state of the forwarding detination and
	 * the mechanism to be used to forward(snmpudp/snmptcp/xmltcp/xmludp)
	 */
	public Vector		m_forward;

	/**
	 * The text to show when the mouse is over this event in the event browser
	 */
	public String		m_mouseOverText;

	/**
	 * The header of the event
	 */
	public EventHeader	m_eventHeader;

	/**
	 * Constructs an EventBlock
	 *
	 * NOTE that an 'EventBlock' when created after a parse, gets
	 * constructed with only those values for the event that are
	 * different from the 'event.conf' - the flags are set to 
	 * indicate these elements of the eventblock
	 *
	 */
	public EventBlock(String uei, 
			  String source,
			  Date   time,
			  String host,
			  String snmpHost,
			  EventSnmpInfo snmpInfo,
			  Hashtable parms,
			  String descr, 
			  String logMsg, 
			  String severity, 
			  String operInstr, 
			  Vector autoAction, 
			  Vector operAction, 
			  Vector logGrp, 
			  String logType,
			  Vector notification, 
			  String tticket, 
			  Vector forward, 
			  String mouseText,
			  EventHeader eventHeader)
	{
		m_uei		= uei;
		m_source	= source;
		m_time		= time;
		m_host		= host;
		m_snmpHost	= snmpHost;
		m_snmpInfo	= snmpInfo;
		m_eventParms	= parms;
		m_descr		= descr;
		m_logMsg	= logMsg;
		m_severity	= severity;
		m_operInstr	= operInstr;
		m_autoAction	= autoAction;
		m_operAction	= operAction;
		m_logGroup	= logGrp;
		m_logType 	= logType;
		m_notification	= notification;
		m_tticket	= tticket;
		m_forward	= forward;
		m_mouseOverText	= mouseText;

		m_eventHeader	= eventHeader;
		
		// mark all the relevant flags in this eventBlock
		if (uei != null)
			addStatus(SET_UEI);

		if (snmpInfo != null)
			addStatus(SET_SNMP);

		if (descr != null)
			addStatus(SET_DESCR);

		if (logMsg != null)
			addStatus(SET_LOGMSG);

		if (severity != null)
			addStatus(SET_SEVERITY);

		if (operInstr != null)
			addStatus(SET_OPERINSTR);

		if (autoAction != null)
			addStatus(SET_AUTOACTION);

		if (operAction != null)
			addStatus(SET_OPERACTION);

		if (logGrp != null)
			addStatus(SET_LOGGROUP);

		if (notification != null)
			addStatus(SET_NOTIFICATION);

		if (tticket != null)
			addStatus(SET_TTICKET);

		if (forward != null)
			addStatus(SET_FORWARD);

		if (mouseText != null)
			addStatus(SET_MOUSEOVERTEXT);

		m_insertedIntoDB = false;
	}

	/**
	 * Get the relevant info from the event.conf block
	 *
	 * Note: The incoming event already has been stripped of the values
	 * for elements specified in the event.conf 'doNotOverride' section
	 *
	 * i.e. the incoming event is going to have a null value for elements
	 * for which it did not have a value and for those that are to be
	 * overridden from the event.conf
	 *
	 * So all that needs to be done is that is if an element is null in the
	 * incoming event, it gets the value from event.conf
	 */

/**************************************************************************************************
	public void fillValuesFrom(EventConfBlock eventConfBlock)
	{
		// UEI
		if (m_uei == null && eventConfBlock.m_uei != null)
		{
			m_uei = new String(eventConfBlock.m_uei);
		}

		// SNMP block
		if (m_snmpInfo == null && eventConfBlock.m_snmpInfo != null)
		{
			m_snmpInfo = new EventSnmpInfo(eventConfBlock.m_snmpInfo);
		}
		
		// descr
		if (m_descr == null && eventConfBlock.m_descr != null)
		{
			m_descr = new String(eventConfBlock.m_descr);
		}

		// logmsg
		if (m_logMsg == null && eventConfBlock.m_logMsg != null)
		{
			m_logMsg = new String(eventConfBlock.m_logMsg);
		}

		// severity
		if (m_severity == null && eventConfBlock.m_severity != null)
		{
			m_severity = new String(eventConfBlock.m_severity);
		}

		// operinstruct
		if (m_operInstr == null && eventConfBlock.m_operInstr != null)
		{
			m_operInstr = new String(eventConfBlock.m_operInstr);
		}

		// autoaction
		if (m_autoAction == null && eventConfBlock.m_autoAction != null)
		{
			m_autoAction = (Vector)eventConfBlock.m_autoAction.clone();
		}

		// operaction
		if (m_operAction == null && eventConfBlock.m_operAction != null)
		{
			m_operAction = (Vector)eventConfBlock.m_operAction.clone();
		}

		// loggroup
		if (m_logGroup == null && eventConfBlock.m_logGroup != null)
		{
			m_logGroup = (Vector)eventConfBlock.m_logGroup.clone();
		}

		// notification
		if (m_notification == null && eventConfBlock.m_notification != null)
		{
			m_notification = (Vector)eventConfBlock.m_notification.clone();
		}

		// tticket
		if (m_tticket == null && eventConfBlock.m_tticket != null)
		{
			m_tticket = new String(eventConfBlock.m_tticket);
		}

		// forward
		if (m_forward == null && eventConfBlock.m_forward != null)
		{
			m_forward = (Vector)eventConfBlock.m_forward.clone();
		}

		// mouseovertext
		if (m_mouseOverText == null && eventConfBlock.m_mouseOverText != null)
		{
			m_mouseOverText = new String(eventConfBlock.m_mouseOverText);
		}

	}
*******************************************************************************************/

	/**
	 * Adds the passed status to the status of the event block
	 * 
	 * @param s	status that indcates status bits to be set
	 */
	public void addStatus(int s)
	{
		m_status = m_status | s;
	}

	public String toString()
	{
		StringBuffer str = new StringBuffer();
		str.append("UEI : " + m_uei);
		str.append("SOURCE : " + m_source);
		str.append("TIME : " + m_time);
		str.append("HOST : " + m_host);
		str.append("SNMPHOST : " + m_snmpHost);
		str.append("SNMPINFO : " + m_snmpInfo.toString());
		str.append("PARMS : " + m_eventParms);
		str.append("DESCR : " + m_descr);
		str.append("LOG MSG : " + m_logMsg);
		str.append("SEVERITY : " + m_severity);
		str.append("OPERINSTR : " + m_operInstr);
		str.append("AUTOACTION : " + m_autoAction);
		str.append("OPERACTION : " + m_operAction);
		str.append("LOG GROUP : " + m_logGroup);
		str.append("LOG TYPE : " + m_logType);
		str.append("NOTIFICATION : " + m_notification);
		str.append("TTICKET : " + m_tticket);
		str.append("Forward : " + m_forward);
		str.append("Mouse Over Text : " + m_mouseOverText);
		str.append("Event Header : " + m_eventHeader.toString());
		return str.toString();
	}	
}

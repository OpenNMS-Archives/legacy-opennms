//-------------------------------------------------------------------------------------------
//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

//--------------------------------------------------------------------------------------------

package org.opennms.bb.eui.admin.distpoller.configure.fbuilder;

import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.Toolkit;
import java.awt.dnd.*;
import java.awt.datatransfer.*;
import java.awt.Point;
import java.util.*;
import javax.swing.*;

import org.opennms.bb.eui.admin.distpoller.configure.dpconf.UserManager;
import org.opennms.bb.common.filter.BBFilter;

class Node
{  
	double m_dX;
	double m_dY;
	String m_sDescLbl;
	String m_sLbl;

	boolean m_bFixed;

	Vector m_vNodes = new Vector();
}

class Edge
{
	int m_iFrom;
	int m_iTo;
	double m_dLen;

	boolean isPointInBetween(RuleAreaPanel oGraph, Point oPoint)
	{
		double x1 = oGraph.m_oNodes[m_iFrom].m_dX,
			   x2 = oGraph.m_oNodes[m_iTo].m_dX,
			   y1 = oGraph.m_oNodes[m_iFrom].m_dY,
			   y2 = oGraph.m_oNodes[m_iTo].m_dY;
		int    X  = oPoint.x,
			   Y  = oPoint.y;

		double m  = (y2-y1)/(x2-x1);
		double m1 = (Y -y1)/(X -x1);
		double m2 = (Y -y2)/(X -x2);

		if(Math.atan((m1-m)/(1+m1*m))*Math.atan((m2-m)/(1+m2*m)) <0)
		{
			return true;
		}
		return false;
	}
}

/**
 *
 * Modifications:
 * Changed the deprecated 'getComponentAtIndex(int i)' method of 'JPopupMenu'
 * to 'getComponent(int i)' for the move to JDK 1.3 - Sowmya
 */
class RuleAreaPanel extends JPanel implements MouseListener, 
					      MouseMotionListener,
					      ActionListener, 
					      DropTargetListener
{
    private static boolean _bLoaded = false;
    static void loadLibraries()
    {
	if (!_bLoaded)
	{
	    java.security.AccessController.doPrivileged(new sun.security.action.LoadLibraryAction("awt"));
	    _bLoaded = true;
	}
    }
    private static native void initIDs();
    
    static
    {
	/* ensure that the proper libraries are loaded */
	loadLibraries();
    }
    
    int						m_nNodes, m_nEdges;
    public Node				m_oNodes[] = new Node[20];
    public Edge				m_oEdges[] = new Edge[20];
    
    Node					m_oPick;
    boolean					m_bPickfixed;
    Image					m_oOffscreen;
    Dimension				m_oOffscreensize;
    Graphics				m_oOffgraphics;
    boolean					m_bDrawMode=false;
    boolean					m_bRuleMade = false;
    String					m_sDrawSource = null;
    JPopupMenu				m_oPopupNode = null;
    JPopupMenu				m_oPopupEdge = null;
    JPopupMenu				m_oPopupEdit = null;
    
    JTextField				m_oRule = null;
    
    final Color				FIXED_COLOR = Color.black;
    final Color				SELECT_COLOR = Color.pink;
    final Color				NODE_COLOR = Color.lightGray;
    final Color				ARC_COLOR = Color.black;
    final Color				RULE_COLOR = Color.white;
    
    class RuleTemplate
    {
	Vector _start = null;
	Vector _end   = null;
	
	RuleTemplate()
	{
	    _start = new Vector();
	    _end   = new Vector();
	}
	
	RuleTemplate(int iNode)
	{
	    this();
	    
	    Integer iInt = new Integer(iNode);
	    _start.add(iInt);
	    _end.add(iInt);
	}
	
	RuleTemplate and(RuleTemplate r2)
	{
	    RuleTemplate r = new RuleTemplate();
	    
	    for(Enumeration e=this._end.elements(); e.hasMoreElements(); )
	    {
		int iFrom = ((Integer)e.nextElement()).intValue();
		for(Enumeration e2=r2._start.elements(); e2.hasMoreElements(); )
		{
		    addEdge(m_oNodes[iFrom].m_sDescLbl,
			    m_oNodes[((Integer)e2.nextElement()).intValue()].m_sDescLbl);
		}
	    }
	    r._start = this._start;
	    r._end = r2._end;
	    
	    return r;
	}
	
	RuleTemplate or(RuleTemplate r2)
	{
	    RuleTemplate r = new RuleTemplate();
	    
	    r._start = this._start;
	    r._end = this._end;
	    int i=0;
	    
	    for(;i<r2._start.size();i++)
	    {
		r._start.add(r2._start.get(i));
	    }
	    i=0;
	
	    for(;i<r2._end.size();i++)
	    {
		r._end.add(r2._end.get(i));
	    }
	    
	    return r;
	}
    }

    void init(String sRule)
    {
	StringBuffer sMappedRule = new StringBuffer(sRule);
	Vector vResource = new Vector();
	int iCount = 0;
	
	StringTokenizer oTkz = new StringTokenizer(sRule, "()&|");
	for( ;oTkz.hasMoreTokens(); )
	{
	    String sTmp = oTkz.nextToken();
	    if(sTmp!= null && (!sTmp.trim().equals("")))
	    {
		vResource.add(new RuleTemplate(findNode(sTmp)));
		int i = sMappedRule.toString().indexOf(sTmp);
		int j = i + sTmp.length();
		sMappedRule = sMappedRule.replace(i,j, ""+(iCount++));
	    }
	}
	
	int i=0;
	while((i=sMappedRule.toString().indexOf(")"))>0)
	{
	    int j=sMappedRule.toString().lastIndexOf("(",i);
	    String sTmp = null;
	    try
	    {
		sTmp = sMappedRule.toString().substring(j+1,i);
	    }
	    catch(Exception e)
	    {
		sTmp = "";
	    }
	    
	    StringTokenizer oStk = new StringTokenizer(sTmp,"&|");
	    if(oStk.countTokens()<1)
	    {
		sMappedRule.deleteCharAt(i);
		sMappedRule.deleteCharAt(j);
	    }
	    else
	    {
		String sTok = oStk.nextToken();
		RuleTemplate r = (RuleTemplate)vResource.get(Integer.parseInt(sTok.trim()));
		int iOffset = 0;
		while(oStk.hasMoreTokens())
		{
		    iOffset += sTok.length();
		    sTok = oStk.nextToken();
		    RuleTemplate r2 = (RuleTemplate)vResource.get(Integer.parseInt(sTok.trim()));
		    if(sTmp.charAt(iOffset)=='&')
		    {
			r = r.and(r2);
		    }
		    else
		    {
			r = r.or(r2);
		    }
		    iOffset+=1;
		}
		vResource.add(r);
		sMappedRule.replace(j,i+1, ""+(iCount++));
	    }
	}
	
	String sTmp = sMappedRule.toString();
	
	RuleTemplate r=null;
	StringTokenizer oStk = new StringTokenizer(sTmp,"&|");
	//if(oStk.countTokens()>1)
	{
	    String sTok = oStk.nextToken();
	    r = (RuleTemplate)vResource.get(Integer.parseInt(sTok.trim()));
	    int iOffset = 0;
	    while(oStk.hasMoreTokens())
	    {
		iOffset += sTok.length();
		sTok = oStk.nextToken();
		RuleTemplate r2 = (RuleTemplate)vResource.get(Integer.parseInt(sTok.trim()));
		if(sTmp.charAt(iOffset)=='&')
		{
		    r = r.and(r2);
		}
		else
		{
		    r = r.or(r2);
		}
		iOffset+=1;
	    }
	}
	
	if(r==null)
	{
	    return;
	}
	
	while(r._start.size()>0)
	{
	    addEdge("source",
		    m_oNodes[((Integer)r._start.remove(r._start.size()-1)).intValue()].m_sDescLbl);
	}
	while(r._end.size()>0)
	{
	    addEdge(m_oNodes[((Integer)r._end.remove(r._end.size()-1)).intValue()].m_sDescLbl,
		    "sink");
	}
	
	try
	{
	    m_iLevel = -1;
	    m_iSinkX = -1;
	    m_sRuleBuffer = new StringBuffer("");
	    recognise(0);
	    int nCount = 0;
	    int iNode = 0;
	    for(int j=0; j<m_nNodes; j++)
	    {
		if(m_oNodes[j].m_vNodes.contains(new Integer(1)))
		{
		    iNode = j;
		    if(++nCount > 1)
		    {
			break;
		    }
		}
	    }
	    if(nCount == 1)
	    {
		m_oNodes[iNode].m_dY = m_oNodes[1].m_dY;
	    }
	}
	catch(Exception e)
	{
	}
    }
    
    public RuleAreaPanel(JTextField oRule)
    {
	setAutoscrolls(true);
	
	addMouseListener(this);
	addMouseMotionListener(this);
	addPopupMenu();
	
	setDropTarget(new DropTarget(new JPanel(), DnDConstants.ACTION_COPY_OR_MOVE, RuleAreaPanel.this, true));
	
	setVisible(true);
	
	addNode("source",26,145);
	addNode("sink",384,145);
	
	m_oRule = oRule;
	try
	{
	    init(oRule.getText().trim());
	}
	catch(Exception e)
	{
	}
	repaint();
    }
    
    int findNode(String sLbl)
    {
	for(int i = 0 ; i < m_nNodes ; i++)
	{
	    if(m_oNodes[i].m_sDescLbl.equals(sLbl))
		{
		    return i;
		}
	}
	return addNode(sLbl);
    }
    
    int addNode(String sLbl)
    {
	return addNode(sLbl,20,20);
    }
    
    int addNode(String sLbl, double x, double y)
    {
	Node oNode = new Node();
	oNode.m_dX = x;
	oNode.m_dY = y;
	oNode.m_sDescLbl = sLbl;
	int len = sLbl.length();
	if(len>6)
	{
	    len = 6;
	}
	oNode.m_sLbl = sLbl.substring(0,len);
	m_oNodes[m_nNodes] = oNode;
	
	return m_nNodes++;
    }
    
    void delNode(String sLbl)
    {
	delAllEdge(sLbl);
	int i=0;
	int nThis=-1;
	while(i < m_nNodes)
	{
	    if(m_oNodes[i].m_sDescLbl.equals(sLbl))
	    {
		nThis = i;
		for(int j = i ; j < m_nNodes-1 ; j++)
		{
		    Integer nTemp = new Integer(i);
		    if(m_oNodes[j].m_vNodes.contains(nTemp))
		    {
			m_oNodes[j].m_vNodes.remove(nTemp);
		    }
		    m_oNodes[j] = m_oNodes[j+1];
		}
		for(int k=0 ; k < m_nEdges ; k++)
		{
		    if(m_oEdges[k].m_iFrom > i)
		    {
			--m_oEdges[k].m_iFrom;
		    }
		    if(m_oEdges[k].m_iTo > i)
		    {
			--m_oEdges[k].m_iTo;
		    }
		}
		m_nNodes--;
	    }
	    else
	    {
		++i;
	    }
	}
	for(i = 0 ; i < m_nNodes ; i++)
	{
	    Integer nTemp = new Integer(nThis);
	    if(m_oNodes[i].m_vNodes.contains(nTemp))
	    {
		m_oNodes[i].m_vNodes.remove(nTemp);
	    }
	    //also, if the vector  contains anything greater than nTemp,
	    //reduce the same by 1
	    if(nThis > 1)for(int jj=nThis+1;jj<m_nNodes+1;jj++)
	    {
		nTemp = new Integer(jj);
		if(m_oNodes[i].m_vNodes.contains(nTemp))
		{
		    m_oNodes[i].m_vNodes.remove(nTemp);
		    m_oNodes[i].m_vNodes.add(new Integer(jj-1));
		}
	    }
	}
	repaint();
    }
    
    void addEdge(String sFrom, String sTo, int nLen)
    {
	Edge oEdge = new Edge();
	oEdge.m_iFrom = findNode(sFrom);
	oEdge.m_iTo = findNode(sTo);
	oEdge.m_dLen = nLen;
	m_oEdges[m_nEdges++] = oEdge;
	m_oNodes[oEdge.m_iFrom].m_vNodes.add(new Integer(oEdge.m_iTo));
    }
    
    void addEdge(String sFrom, String sTo)
    {
	Edge oEdge = new Edge();
	oEdge.m_iFrom = findNode(sFrom);
	oEdge.m_iTo = findNode(sTo);
	int x1 = (int)m_oNodes[oEdge.m_iFrom].m_dX;
	int y1 = (int)m_oNodes[oEdge.m_iFrom].m_dY;
	int x2 = (int)m_oNodes[oEdge.m_iTo].m_dX;
	int y2 = (int)m_oNodes[oEdge.m_iTo].m_dY;
	oEdge.m_dLen = (int)Math.abs(Math.sqrt((x1-x2)*(x1-x2) + (y1-y2)*(y1-y2)) - oEdge.m_dLen);
	m_oEdges[m_nEdges++] = oEdge;
	m_oNodes[oEdge.m_iFrom].m_vNodes.add(new Integer(oEdge.m_iTo));
    }
    
    void delEdge(Edge oEdge)
    {
	int i;
	for(i = 0 ; i < m_nEdges ; i++)
	{
	    if(m_oEdges[i] == oEdge)
	    {
		m_oNodes[oEdge.m_iFrom].m_vNodes.remove(new Integer(oEdge.m_iTo));
		for(int j = i ; j < m_nEdges-1 ; j++)
		{
		    m_oEdges[j] = m_oEdges[j+1];
		}
		m_nEdges--;
		break;
	    }
	}
	repaint();
    }
    
    void delAllEdge(String sLbl)
    {
	int i=0;
	//for(i = 0 ; i < m_nEdges ; i++)
	while(i < m_nEdges)
	{
	    if(m_oNodes[m_oEdges[i].m_iFrom].m_sDescLbl.equals(sLbl) || m_oNodes[m_oEdges[i].m_iTo].m_sDescLbl.equals(sLbl))
	    {
		m_oNodes[m_oEdges[i].m_iFrom].m_vNodes.remove(new Integer(m_oEdges[i].m_iTo));
		for(int j = i ; j < m_nEdges-1 ; j++)
		{
		    m_oEdges[j] = m_oEdges[j+1];
		}
		m_nEdges--;
	    }
	    else
	    {
		++i;
	    }
	}
	repaint();
    }
    
    void save()
    {
	m_oNodes[0].m_dX = 26;  m_oNodes[0].m_dY = 145;
	m_oNodes[1].m_dX = 384; m_oNodes[1].m_dY = 145;
	recognise();
	repaint();
    }
    
    int m_iLevel = -1;
    double m_iSinkX = 0;
    void recognise(int iNode) throws Exception
    {
	int n = 0;
	int nBraces = 0;
	if(m_iLevel>=50)
	{
	    String sMsg = "Unable to recognise incomplete or erroneous layout.";
	    JOptionPane.showMessageDialog(getParent(),
					  sMsg,
					  "Rule Builder Error..",
					  JOptionPane.ERROR_MESSAGE);
	    m_sRuleBuffer = null;
	    throw new Exception();
	}
	if(m_nNodes<iNode || (n=m_oNodes[iNode].m_vNodes.size())<=0 || (iNode==1) || (m_sRuleBuffer == null))
	{
	    String sMsg = "Unable to recognise incomplete or erroneous layout.";
	    JOptionPane.showMessageDialog(getParent(),
					  sMsg,
					  "Rule Builder Error..",
					  JOptionPane.ERROR_MESSAGE);
	    m_sRuleBuffer = null;
	    throw new Exception();
	    //return;
	}
	if(!m_oNodes[iNode].m_sDescLbl.equals("source"))
	{
	    //m_sRuleBuffer.append("(");
	    m_sRuleBuffer.append(m_oNodes[iNode].m_sDescLbl);
	    m_sRuleBuffer.append(" & ");
	    if(n>1)
	    {
		m_sRuleBuffer.append("(");
		++nBraces;
	    }
	}
	int i = 0;
	++m_iLevel;
	Node oNode = new Node();
	if((n%2)!=0)
	{
	    oNode = m_oNodes[((Integer)m_oNodes[iNode].m_vNodes.get(n-1)).intValue()];
	    if(oNode.m_sDescLbl.equals("sink"))
	    {
		oNode.m_dX = m_oNodes[iNode].m_dX + 60;
		if(oNode.m_dX<=m_iSinkX)
		{
		    oNode.m_dX = m_iSinkX + 60;
		}
		m_sRuleBuffer.append(oNode.m_sDescLbl);
		if(nBraces>0)
		{
		    m_sRuleBuffer.append(")");
		    --nBraces;
		}
		--m_iLevel;
		return;
	    }
	    oNode.m_dX = m_oNodes[iNode].m_dX + 60;
	    oNode.m_dY = m_oNodes[iNode].m_dY;
	    if(m_iSinkX<oNode.m_dX)
	    {
		m_iSinkX = oNode.m_dX;
	    }
	    if(n>1)
	    {
		m_sRuleBuffer.append("(");
		++nBraces;
	    }
	    
	    recognise(((Integer)m_oNodes[iNode].m_vNodes.get(n-1)).intValue());
	    if(n>1)
	    {
		m_sRuleBuffer.append(")");
		m_sRuleBuffer.append(" | ");
		--nBraces;
	    }
	    //++i;
	    --n;
	}
	while(i<(n/2))
	{
	    oNode = m_oNodes[((Integer)m_oNodes[iNode].m_vNodes.get(i)).intValue()];
	    if(oNode.m_sDescLbl.equals("sink"))
	    {
		oNode.m_dX = m_oNodes[iNode].m_dX + 60;
		if(oNode.m_dX<=m_iSinkX)
		{
		    oNode.m_dX = m_iSinkX+60;
		}
		return;
	    }
	    oNode.m_dX = m_oNodes[iNode].m_dX + 60;
	    //oNode.m_dY = m_oNodes[iNode].m_dY + (240/n)*(i+1);
	    oNode.m_dY = m_oNodes[iNode].m_dY + (85)*(i+1) - m_iLevel*15;
	    if(m_iSinkX<oNode.m_dX)
	    {
		m_iSinkX = oNode.m_dX;
	    }
	    if(n>1)
	    {
		m_sRuleBuffer.append("(");
		++nBraces;
	    }
	    recognise(((Integer)m_oNodes[iNode].m_vNodes.get(i)).intValue());
	    if(n>1)
	    {
		m_sRuleBuffer.append(")");
		m_sRuleBuffer.append(" | ");
		--nBraces;
	    }
	    ++i;
	}
	while(i<n)
	{
	    oNode = m_oNodes[((Integer)m_oNodes[iNode].m_vNodes.get(i)).intValue()];
	    if(oNode.m_sDescLbl.equals("sink"))
	    {
		oNode.m_dX = m_oNodes[iNode].m_dX + 60;
		if(oNode.m_dX<=m_iSinkX)
		{
		    oNode.m_dX = m_iSinkX + 60;
		}
		return;
	    }
	    oNode.m_dX = m_oNodes[iNode].m_dX + 60;
	    //oNode.m_dY = m_oNodes[iNode].m_dY - (240/n)*(n-i);
	    oNode.m_dY = m_oNodes[iNode].m_dY - (85)*(n-i) + m_iLevel*15;
	    if(m_iSinkX<oNode.m_dX)
	    {
		m_iSinkX = oNode.m_dX;
	    }
	    if(n>1)
	    {
		m_sRuleBuffer.append("(");
		++nBraces;
	    }
	    recognise(((Integer)m_oNodes[iNode].m_vNodes.get(i)).intValue());
	    if(n>1)
	    {
		m_sRuleBuffer.append(")");
		
		//shouldn't put an 'or' operator at the end of a rule
		//m_sRuleBuffer.append(" | ");
		
		--nBraces;
	    }
	    ++i;
	}
	if(nBraces>0)
	{
	    m_sRuleBuffer.append(")");
	    --nBraces;
	}
	--m_iLevel;
    }
    
    StringBuffer m_sRuleBuffer = null;
    void recognise()
    {
	m_sRuleBuffer = new StringBuffer("");
	try
	{
	    m_iLevel = -1;
	    m_iSinkX = -1;
	    recognise(0);
	    int nCount = 0;
	    int iNode = 0;
	    for(int i=0; i<m_nNodes; i++)
	    {
		if(m_oNodes[i].m_vNodes.contains(new Integer(1)))
		{
		    iNode = i;
		    if(++nCount > 1)
		    {
			break;
		    }
		}
	    }
	    if(nCount == 1)
	    {
		m_oNodes[iNode].m_dY = m_oNodes[1].m_dY;
	    }
	}
	catch(Exception e)
	{
	    System.out.println("Exception caught.");
	}
	
	int nIdx = -1;
	if(m_sRuleBuffer == null)
	{
	    m_oRule.setText("Type your text rule here..");
	    return;
	}
	while((nIdx=m_sRuleBuffer.toString().indexOf(" & sink"))!= -1)
	{
	    m_sRuleBuffer = m_sRuleBuffer.delete(nIdx, nIdx+7);
	}
	while((nIdx=m_sRuleBuffer.toString().indexOf("sink"))!= -1)
	{
	    m_sRuleBuffer = m_sRuleBuffer.delete(nIdx, nIdx+4);
	}
	while((nIdx=m_sRuleBuffer.toString().indexOf(" | )"))!= -1)
	{
	    m_sRuleBuffer = m_sRuleBuffer.delete(nIdx, nIdx+3);
	}
	while((nIdx=m_sRuleBuffer.toString().indexOf("& ()"))!= -1)
	{
	    m_sRuleBuffer = m_sRuleBuffer.delete(nIdx, nIdx+3);
	}
	while((nIdx=m_sRuleBuffer.toString().indexOf("| ()"))!= -1)
	{
	    m_sRuleBuffer = m_sRuleBuffer.delete(nIdx, nIdx+3);
	}
	while((nIdx=m_sRuleBuffer.toString().indexOf("()"))!= -1)
	{
	    m_sRuleBuffer = m_sRuleBuffer.delete(nIdx, nIdx+2);
	}
	m_oRule.setText(m_sRuleBuffer.toString());
    }
    
    double distance(Point oPoint, Edge oEdge)
    {
        double x1 = m_oNodes[oEdge.m_iFrom].m_dX,
	       x2 = m_oNodes[oEdge.m_iTo].m_dX,
               y1 = m_oNodes[oEdge.m_iFrom].m_dY,
               y2 = m_oNodes[oEdge.m_iTo].m_dY;
        double dDist  = 0.0;
        int    X  = oPoint.x,
               Y  = oPoint.y;
        
        if(Math.abs(x2-x1) < 0.01)
	{
	    dDist = Math.abs(X-x1);
        }
        if(Math.abs(y2-y1) < 0.01)
        {
            dDist = Math.abs(Y-y1);
        }
        else
        {
            double m = (y2-y1)/(x2-x1);
            dDist = Math.abs(Y-y1-m*(X-x1));
            dDist/= Math.sqrt(1+m*m);
        }
        return dDist;
    }
    
    public void paintNode(Graphics oGraphics, Node oNode, FontMetrics oFm)
    {
	if(!oNode.m_sDescLbl.equals("RULE"))
	{
      String imageStr = "data" + System.getProperty("file.separator") + "images" + System.getProperty("file.separator");
	    
	    int x = (int)oNode.m_dX;
	    int y = (int)oNode.m_dY;
	    oGraphics.setColor((oNode == m_oPick) ? SELECT_COLOR : (oNode.m_bFixed ? FIXED_COLOR : NODE_COLOR));
	    int w = oFm.stringWidth(oNode.m_sLbl) + 10;
	    int h = oFm.getHeight() + 4;
	    //oGraphics.fillRect(x - w/2, y - h/2, w, h);
	    //oGraphics.setColor(Color.black);
	    if(oNode.m_sDescLbl.equals("source"))
	    {
		Image oImage = Toolkit.getDefaultToolkit().getImage(imageStr + "sys28.gif");
		oGraphics.setColor(Color.black);
		oGraphics.drawImage(oImage, x - 8, y - 8, 28, 28, this);
	    }
	    else if(oNode.m_sDescLbl.equals("sink"))
	    {
		Image oImage = Toolkit.getDefaultToolkit().getImage(imageStr + "source28.gif");
		oGraphics.setColor(Color.black);
		oGraphics.drawImage(oImage, x - 8, y - 8, 28, 28, this);
	    }
	    else
	    {
		Image oImage = null;
		if(oNode.m_sDescLbl.startsWith("IF"))
		{
		    oImage = Toolkit.getDefaultToolkit().getImage(imageStr + "if28.gif");
		}
		else if(oNode.m_sDescLbl.startsWith("IP"))
		{
		    oImage = Toolkit.getDefaultToolkit().getImage(imageStr +"ip28.gif");
		}
		else
		{
		    oImage = Toolkit.getDefaultToolkit().getImage(imageStr +"laptop.jpg");
		}
		oGraphics.setColor(Color.black);
		oGraphics.drawImage(oImage, x-8, y-8, 28, 28, this);
				/*
				  oGraphics.fill3DRect(x - w/2, y - h/2, w, h, true);
				  oGraphics.setColor(Color.black);
				  oGraphics.draw3DRect(x - w/2, y - h/2, w-1, h-1, true);
				*/
	    }
	    //oGraphics.drawString(oNode.m_sLbl, x - (w-10)/2, (y - (h-4)/2) + oFm.getAscent());
	    //oGraphics.drawString(oNode.m_sLbl, x - (w)/2, y - (h-56)/2 + oFm.getAscent());
	    oGraphics.drawString(oNode.m_sLbl, x-8, y - (h-56)/2 + oFm.getAscent());
	}
    }
    
    public synchronized void paint(Graphics oGraphics)
    {
	Dimension d = getSize();
	if((m_oOffscreen == null) || (d.width != m_oOffscreensize.width) || (d.height != m_oOffscreensize.height))
	{
	    m_oOffscreen = createImage(d.width, d.height);
	    m_oOffscreensize = d;
	    m_oOffgraphics = m_oOffscreen.getGraphics();
	    m_oOffgraphics.setFont(new Font("Dialog", Font.ITALIC, 9));
	}
	
	m_oOffgraphics.setColor(getBackground());
	m_oOffgraphics.fillRect(0, 0, d.width, d.height);
	for(int i = 0 ; i < m_nEdges ; i++)
	{
	    Edge oEdge = m_oEdges[i];
	    double x1 = m_oNodes[oEdge.m_iFrom].m_dX;
	    double y1 = m_oNodes[oEdge.m_iFrom].m_dY;
	    double x2 = m_oNodes[oEdge.m_iTo].m_dX;
	    double y2 = m_oNodes[oEdge.m_iTo].m_dY;
	    double len = Math.abs(Math.sqrt((x1-x2)*(x1-x2) + (y1-y2)*(y1-y2)) - oEdge.m_dLen);
	    m_oOffgraphics.setColor(ARC_COLOR);
	    m_oOffgraphics.drawLine((int)x1, (int)y1, (int)x2, (int)y2);
	    
	    double midX = (x1+x2)/2;
	    double midY = (y1+y2)/2;
	    
	    if(Math.abs(x2-x1) < 0.01)
	    {
		continue;
	    }
	    double m = (y1-y2)/(x1-x2);
	    double dDirection = (m-(midY+6*Math.sin(Math.PI/4 - Math.atan(m))-y1)/(midX-6*Math.cos(Math.PI/4 - Math.atan(m))-x1));
	    
	    if(dDirection<0)
	    {
		m_oOffgraphics.drawLine((int)midX,
					(int)midY,
					(int)(midX-6*Math.cos(Math.PI/4 - Math.atan(m))),
					(int)(midY+6*Math.sin(Math.PI/4 - Math.atan(m))) );
		m_oOffgraphics.drawLine((int)midX,
					(int)midY,
					(int)(midX-6*Math.sin(Math.PI/4 - Math.atan(m))),
					(int)(midY-6*Math.cos(Math.PI/4 - Math.atan(m))) );
	    }
	    else
	    {
		m_oOffgraphics.drawLine((int)midX,
					(int)midY,
					(int)(midX+6*Math.cos(Math.PI/4 - Math.atan(m))),
					(int)(midY-6*Math.sin(Math.PI/4 - Math.atan(m))) );
		m_oOffgraphics.drawLine((int)midX,
					(int)midY,
					(int)(midX+6*Math.sin(Math.PI/4 - Math.atan(m))),
					(int)(midY+6*Math.cos(Math.PI/4 - Math.atan(m))) );
	    }
	}
	
	FontMetrics oFm = m_oOffgraphics.getFontMetrics();
	for(int i = 0 ; i < m_nNodes ; i++)
	{
	    paintNode(m_oOffgraphics, m_oNodes[i], oFm);
	}
	oGraphics.drawImage(m_oOffscreen, 0, 0, null);
    }
    
    public void mouseClicked(MouseEvent e)
    {
	if(e.getClickCount()>1)
	{
	    int x = e.getX();
	    int y = e.getY();
	    e.consume();
	    m_bDrawMode = true;
	    double bestdist = 1000;
	    for(int i = 0 ; i < m_nNodes ; i++)
	    {
		Node oNode = m_oNodes[i];
		double dist = (oNode.m_dX - x) * (oNode.m_dX - x) + (oNode.m_dY - y) * (oNode.m_dY - y);
		if(dist < bestdist)
		{
		    m_sDrawSource = oNode.m_sDescLbl;
		    break;
		}
	    }
	    if(m_sDrawSource != null)
	    {
		if(!m_bRuleMade)
		{
		    addNode("RULE", x, y);
		    m_bRuleMade = true;
		}
		addEdge(m_sDrawSource,"RULE");
		repaint();
		e.consume();
	    }
	    repaint();
	    return;
	}
    }
    
    public void mousePressed(MouseEvent e) 
    {
	if(e.isPopupTrigger())
	{
	    popupAction(e);
	    e.consume();
	    return;
	}
	addMouseMotionListener(this);
	
	int x = e.getX();
	int y = e.getY();
	if(m_bDrawMode)
	{
	    m_oPick = m_oNodes[findNode("RULE")];
	    m_bPickfixed = m_oPick.m_bFixed;
	    m_oPick.m_bFixed = true;
	    m_oPick.m_dX = x;
	    m_oPick.m_dY = y;
	    repaint();
	    e.consume();
	    return;
	}
	double bestdist = Double.MAX_VALUE;
	for(int i = 0 ; i < m_nNodes ; i++)
	{
	    Node oNode = m_oNodes[i];
	    double dist = (oNode.m_dX - x)*(oNode.m_dX - x) + (oNode.m_dY - y)*(oNode.m_dY - y);
	    if (dist < 400)
	    {
		m_oPick = oNode;
		bestdist = dist;
		break;
	    }
	}
	if(m_oPick !=null)
	{
	    m_bPickfixed = m_oPick.m_bFixed;
	    m_oPick.m_bFixed = true;
	    m_oPick.m_dX = x;
	    m_oPick.m_dY = y;
	    if(m_oPick.m_dX<5)
	    {
		m_oPick.m_dX=5;
	    }
	    if(m_oPick.m_dY<5)
	    {
		m_oPick.m_dY=5;
	    }
	    if(m_oPick.m_dX>980)
	    {
		m_oPick.m_dX=980;
	    }
	    if(m_oPick.m_dY>970)
	    {
		m_oPick.m_dY=970;
	    }
	}
	repaint();
	e.consume();
    }
    
    public void mouseDragged(MouseEvent e)
    {
	if(m_oPick != null)
	{
	    m_oPick.m_dX = e.getX();
	    m_oPick.m_dY = e.getY();
	    
	    if(m_oPick.m_dX<5)
	    {
		m_oPick.m_dX=5;
	    }
	    if(m_oPick.m_dY<5)
	    {
		m_oPick.m_dY=5;
	    }
	    if(m_oPick.m_dX>980)
	    {
		m_oPick.m_dX=980;
	    }
	    if(m_oPick.m_dY>970)
	    {
		m_oPick.m_dY=970;
	    }
	    
	}
	repaint();
	e.consume();
    }
    
    public void mouseReleased(MouseEvent e)
    {
	if(e.isPopupTrigger())
	{
	    popupAction(e);
	    e.consume();
	    /*
	     * DO NOT RETURN FROM HERE.
	     */
	}
	removeMouseMotionListener(this);
	int x = e.getX();
	int y = e.getY();
	
	if(m_bDrawMode)
	{
	    m_bDrawMode = false;
	    m_bRuleMade = false;
	    setCursor(Cursor.getDefaultCursor());
	    for(int i = 0 ; i < m_nNodes ; i++)
	    {
		Node oNode = m_oNodes[i];
		double dist = (oNode.m_dX - x)*(oNode.m_dX - x) + (oNode.m_dY - y)*(oNode.m_dY - y);
		if(dist < 3000) 
		{
		    if(m_sDrawSource != null)
		    {
			addEdge(m_sDrawSource, oNode.m_sDescLbl);
		    }
		    m_sDrawSource = null;
		}
	    }
	}
	delAllEdge("RULE");
	delNode("RULE");
	m_sDrawSource = null;
	if(m_oPick != null)
	{
	    m_oPick.m_dX = x;
	    m_oPick.m_dY = y;
	    if(m_oPick.m_dX<5)
	    {
		m_oPick.m_dX=5;
	    }
	    if(m_oPick.m_dY<5)
	    {
		m_oPick.m_dY=5;
	    }
	    if(m_oPick.m_dX>980)
	    {
		m_oPick.m_dX=980;
	    }
	    if(m_oPick.m_dY>970)
	    {
		m_oPick.m_dY=970;
	    }
	    
	    m_oPick.m_bFixed = m_bPickfixed;
	    m_oPick = null;
	}
	repaint();
	e.consume();
    }
    
    public void mouseEntered(MouseEvent e) 
    {
    }
    
    public void mouseExited(MouseEvent e)
    {
    }
    
    public void mouseMoved(MouseEvent e)
    {
	int x = e.getX(),
	    y = e.getY();
	
	for(int i = 0 ; i < m_nNodes ; i++)
	{
	    Node oNode = m_oNodes[i];
	    double dist = (oNode.m_dX - x)*(oNode.m_dX - x) + (oNode.m_dY - y)*(oNode.m_dY - y);
	    if (dist < 400)
	    {
		m_oNodes[i].m_sLbl = m_oNodes[i].m_sDescLbl;
		repaint();
		break;
	    }
	    else
	    {
		int len = m_oNodes[i].m_sDescLbl.length();
		if(len>6)
		{
		    len = 6;
		}
		m_oNodes[i].m_sLbl = m_oNodes[i].m_sDescLbl.substring(0,len);
		repaint();
	    }
	}
	if(m_oPick != null)
	{
	    m_oPick.m_dX = e.getX();
	    m_oPick.m_dY = e.getY();
	    if(m_oPick.m_dX<5)
	    {
		m_oPick.m_dX=5;
	    }
	    if(m_oPick.m_dY<5)
	    {
		m_oPick.m_dY=5;
	    }
	    if(m_oPick.m_dX>980)
	    {
		m_oPick.m_dX=980;
	    }
	    if(m_oPick.m_dY>970)
	    {
		m_oPick.m_dY=970;
	    }
	}
	repaint();
	e.consume();
    }
    
    public void drop(DropTargetDropEvent e)
    {
	try
	{
	    Point pDropLocation	= e.getLocation();
	    DataFlavor oStringFlavor = DataFlavor.stringFlavor;
	    Transferable oData = e.getTransferable();
	    
	    if(e.isDataFlavorSupported(oStringFlavor))
	    {
		String oText = (String)oData.getTransferData(oStringFlavor);
		
		e.acceptDrop(DnDConstants.ACTION_COPY_OR_MOVE);
		addNode(oText, pDropLocation.getX(), pDropLocation.getY());
		repaint();
		e.dropComplete(true);
	    }
	    else
	    {
		Toolkit.getDefaultToolkit().beep();
		e.rejectDrop();
	    }
	}
	catch(IOException ex)
	{
	    ex.printStackTrace();
	}
	catch(UnsupportedFlavorException exp)
	{
	    exp.printStackTrace();
	}
    }
    
    public void dragEnter(DropTargetDragEvent e)
    {
	if(isDragOk(e) == false)
	{
	    e.rejectDrag();
	    return;
	}
	e.acceptDrag(DnDConstants.ACTION_COPY_OR_MOVE);
    }
    
    public void dragExit(DropTargetEvent e)
    {
    }
    
    public void dragOver(DropTargetDragEvent e)
    {
	Point	oDragLocation	= e.getLocation();
	if(isDragOk(e) == false)
	{
	    e.rejectDrag();
	    return;
	}
	e.acceptDrag(DnDConstants.ACTION_COPY_OR_MOVE);
    }
    
    public void dropActionChanged(DropTargetDragEvent e)
    {
	if(isDragOk(e) == false)
	{
	    e.rejectDrag();
	    return;
	}
	e.acceptDrag(DnDConstants.ACTION_COPY_OR_MOVE);
    }
    
    boolean isDragOk(DropTargetDragEvent e)
    {
	return true;
    }
    
    int m_nSelectedIndex = -1;
    int m_x=0, m_y=0;
    
    void popupAction(MouseEvent e)
    {
	int x = e.getX();
	int y = e.getY();
	for(int i = 0 ; i < m_nNodes ; i++)
	{
	    Node oNode = m_oNodes[i];
	    double dist = (oNode.m_dX - x)*(oNode.m_dX - x) + (oNode.m_dY - y)*(oNode.m_dY - y);
	    if (dist < 400)
	    {
		m_nSelectedIndex = i;
		if(oNode.m_sDescLbl.equals("source") || oNode.m_sDescLbl.equals("sink"))
		{
		    m_oPopupNode.getComponent(2).setEnabled(false);
		    m_oPopupNode.getComponent(3).setEnabled(false);
		    m_oPopupNode.getComponent(5).setEnabled(false);
		}
		else
		{
		    m_oPopupNode.getComponent(2).setEnabled(true);
		    m_oPopupNode.getComponent(3).setEnabled(true);
		    m_oPopupNode.getComponent(5).setEnabled(true);
		}
		if(!oNode.m_sDescLbl.equals("RULE"))
		{
		    m_oPopupNode.show((Component)e.getSource(),
				      (m_x=e.getX()),
				      (m_y=e.getY()));
		}
		e.consume();
		return;
	    }
	}
	
	Point oPoint = new Point(x,y);
	for(int i = 0 ; i < m_nEdges ; i++)
	{
	    Edge oEdge = m_oEdges[i];
	    double dist = distance(oPoint, oEdge);
	    if (dist < 2.5)
	    {
		if(oEdge.isPointInBetween(this,oPoint))
		{
		    m_nSelectedIndex = i;
		    m_oPopupEdge.show((Component)e.getSource(),
				      (m_x=e.getX()),
				      (m_y=e.getY()));
		    e.consume();
		    return;
		}
	    }
	}
	if(UserManager.m_sEditBuffer != null)
	{
	    m_oPopupEdit.getComponent(3).setEnabled(true);
	}
	else
	{
	    m_oPopupEdit.getComponent(3).setEnabled(false);
	}
	m_oPopupEdit.show((Component)e.getSource(),
			  (m_x=e.getX()),
			  (m_y=e.getY()));
	e.consume();
	return;
    }
    
    /**This method is the implementation of actionPerformed for the ActionListener
       interface. The method listens for the right click events coming fromt the
       popup menu build by the addPopupMenu() method.
     */
    public void actionPerformed(ActionEvent e)
    {
	if(e.getActionCommand().equals("Join"))
	{
	    m_bDrawMode = true;
	    if(m_nSelectedIndex != -1)
	    {
		m_sDrawSource = m_oNodes[m_nSelectedIndex].m_sDescLbl;
		if(!m_bRuleMade)
		{
		    //addNode("RULE", m_oNodes[m_nSelectedIndex].m_dX, m_oNodes[m_nSelectedIndex].m_dY);
		    addNode("RULE", m_x, m_y);
		    m_bRuleMade = true;
		}
		addEdge(m_sDrawSource,"RULE");
		m_oPick = m_oNodes[findNode("RULE")];
		m_bPickfixed = m_oPick.m_bFixed;
		m_oPick.m_bFixed = true;
		addMouseMotionListener(this);
				
		/*
		 * TBD: Change the cursor:
		 */
		setCursor(new Cursor(Cursor.HAND_CURSOR));
		repaint();
	    }
	    repaint();
	    return;
	}
	else if(e.getActionCommand().equals("DeleteEdge"))
	{
	    delEdge(m_oEdges[m_nSelectedIndex]);
	    repaint();
	    m_nSelectedIndex = -1;
	}
	else if(e.getActionCommand().equals("AddNode"))
	{
	    //inputRule will do validation on this clause
	    String sTemp = inputRule("Rule:", "Add Rule..", null);

	    if((sTemp!=null) && (!(sTemp=sTemp.trim()).equals("")))
	    {
		addNode(sTemp,m_x,m_y);
		repaint();
	    }
	}
	else if(e.getActionCommand().equals("SaveRule"))
	{
	    save();
	}
	else if(e.getActionCommand().equals("CutNode"))
	{
	    delAllEdge(m_oNodes[m_nSelectedIndex].m_sDescLbl);
	    delNode(m_oNodes[m_nSelectedIndex].m_sDescLbl);
	    
	    repaint();
	    m_nSelectedIndex = -1;
	}
	else if(e.getActionCommand().equals("CopyNode"))
	{
	    UserManager.m_sEditBuffer = m_oNodes[m_nSelectedIndex].m_sDescLbl;
	}
	else if(e.getActionCommand().equals("Paste"))
	{
	    addNode(UserManager.m_sEditBuffer,m_x,m_y);
	    UserManager.m_sEditBuffer = null;
	    repaint();
	}
	else if(e.getActionCommand().equals("Modify"))
	{
	    //inputRule will do validation on this clause
	    String sTemp = inputRule("Changed rule:", "Rename..", m_oNodes[m_nSelectedIndex].m_sDescLbl);

	    if((sTemp!=null) && (!(sTemp=sTemp.trim()).equals("")))
	    {
		m_oNodes[m_nSelectedIndex].m_sDescLbl = sTemp;
		repaint();
	    }
	}
    }
    
    /**This method was added to take the place of just a simple input dialog.
       In addition to getting user input this method will check the syntax of
       the new clause against the filter parser to ensure that the clause is
       syntactically valid. If it is not the user will be warned but will enable
       the user to use the invalid clause.
       @return String, the new rule clause
       @param String label, the label of the input text field
       @param String title, the title of the input dialog
       @param String text, the text to initially display in the text field
     */
    private String inputRule(String label, String title, String text)
    {
	String sTemp = (String)JOptionPane.showInputDialog(this,
							   label,
							   title,
							   JOptionPane.QUESTION_MESSAGE,
							   null,
							   null,
							   text);
	/*Validation should not take place here

	//rules must end with a semi colon
	String result = BBFilter.validateRule(sTemp + ";");

	if (!result.equals(BBFilter.VALID_RULE))
	{
	    int reply = JOptionPane.showConfirmDialog(this, 
						      result + "\nWould you like to fix it?", 
						      "Invalid Rule", 
						      JOptionPane.YES_NO_OPTION);
	    
	    if (reply == JOptionPane.YES_OPTION)
	    {
		sTemp = inputRule(label, title, sTemp);
	    }
	}
	*/
	
	return sTemp;
    }

    void addPopupMenu()
    {
	/*
	 * Create the popup menu.
	 */
	JMenuItem oMenuItem;
	m_oPopupNode = new JPopupMenu();
	
	oMenuItem = new JMenuItem("Join");
	oMenuItem.setActionCommand("Join");
	oMenuItem.addActionListener((ActionListener)this);
	m_oPopupNode.add(oMenuItem);
	m_oPopupNode.addSeparator();
	oMenuItem = new JMenuItem("Cut");
	oMenuItem.setActionCommand("CutNode");
	oMenuItem.addActionListener((ActionListener)this);
	m_oPopupNode.add(oMenuItem);
	oMenuItem = new JMenuItem("Copy");
	oMenuItem.setActionCommand("CopyNode");
	oMenuItem.addActionListener((ActionListener)this);
	m_oPopupNode.add(oMenuItem);
	m_oPopupNode.addSeparator();
	oMenuItem = new JMenuItem("Modify..");
	oMenuItem.setActionCommand("Modify");
	oMenuItem.addActionListener((ActionListener)this);
	m_oPopupNode.add(oMenuItem);
	
	m_oPopupEdge = new JPopupMenu();
	oMenuItem = new JMenuItem("Delete");
	oMenuItem.setActionCommand("DeleteEdge");
	oMenuItem.addActionListener((ActionListener)this);
	m_oPopupEdge.add(oMenuItem);
	
	m_oPopupEdit = new JPopupMenu();
	oMenuItem = new JMenuItem("Add");
	oMenuItem.setActionCommand("AddNode");
	oMenuItem.addActionListener((ActionListener)this);
	m_oPopupEdit.add(oMenuItem);
	oMenuItem = new JMenuItem("Save");
	oMenuItem.setActionCommand("SaveRule");
	oMenuItem.addActionListener((ActionListener)this);
	m_oPopupEdit.add(oMenuItem);
	m_oPopupEdit.addSeparator();
	oMenuItem = new JMenuItem("Paste");
	oMenuItem.setActionCommand("Paste");
	oMenuItem.addActionListener((ActionListener)this);
	m_oPopupEdit.add(oMenuItem);
    }
}

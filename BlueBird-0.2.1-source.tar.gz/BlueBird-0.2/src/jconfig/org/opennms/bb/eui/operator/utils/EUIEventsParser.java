//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.operator.utils;

import org.w3c.dom.*;

import java.io.*;
import java.util.Vector;
import java.util.Hashtable;

import org.opennms.bb.common.utils.BBParser;

/**
 * <pre>EUIEventsParser parses the events level data response and stores
 * data in a vector of vectors(for each event)
 *
 * It throws an IOException if the xml file is not found or if it does not
 * conform to its DTD </pre>
 *
 * @author Sowmya
 *
 * Modifications:
 * 04/18/00 - Changed the parser to extend BBParser - Sowmya
 *
 * Modifications:
 * 10/24/00 - Changed the parser to incorporate the new XML events structure - Jacinta
 */
public class EUIEventsParser extends BBParser
{
	Vector		eventsVector;

	/*
	 * XML TAGS that are relevant
	 */
	final String EVENTS		="events";
	final String EVENT		="event";
	final String SOURCE		="source";
	final String EID		="eid";
	final String TIME		="time";
	final String HOST		="host";
	final String PARMS		="parms";
	final String PARM		="parm";
	final String PARM_NAME	="parmName";
	final String PARM_VALUE	="value";

	final String YEAR		="year";
	final String MONTH		="month";
	final String DAY		="day";
	final String HOUR		="hour";
	final String MIN		="min";
	final String SEC		="sec";
	final String TYPE		="type";

	final String SPECIFIC	="specific";
	final String GENERIC	="generic";
	final String SEVERITY	="Severity";
	final String DESCR		="Description";

	final String INSTRUCTIONS	="Operator Instructions";
	final String EVENT_OVERVIEW	="Event Overview";

	/************************************************************************
		Changes made by Jacinta on Oct 24.
	*/
		
	final String SNMPHOST		="snmphost";
	final String DESCRIP		="descr";
	final String OPERINSTRUCT	="operinstruct";
	final String OPERACTION 	="operaction";
	final String AUTOACTION		="autoaction";
	final String LOGGROUP		="loggroup";
	final String LOGMSG			="logmsg";
	final String DEST			="dest";
	final String NOTIFICATION	="notification";
	final String TTICKET		="tticket";
	final String FORWARD		="forward";
	final String STATE			="state";
	final String MOUSEOVERTEXT	="mouseovertext";
	final String MENUTEXT		="menutext";

	/************************************************************************/


	/*
	 * initial capacity of the various hashtables used is set to 22
	 * just so space is not wasted 
	 */
	 final int	INITIAL_CAPACITY = 22;		// Changed the value from 10 to 22 (Jacinta)


	/**
	 * Creates the DOM parser
 	 */
	public EUIEventsParser()
	{
		super();
	}

	protected boolean processElement(Element el,boolean isRoot)
	{
		boolean bRet = false;

		String tag = el.getTagName();

		if (tag.equals(EVENTS))
		{
			m_curElement.replace(0, m_curElement.length(), EVENTS);

			bRet = processEventsElement(el);
		}

		else
		{
			boolean bNodeRet=true;

			NodeList nl = el.getChildNodes();
			int size = nl.getLength();

			for(int i = 0;i < size && bNodeRet ;i++)
				bNodeRet = processNode(nl.item(i));
			
			bRet = bNodeRet;
		}
		
		return bRet;
	}

	protected boolean processEventsElement(Node eventsNode)
	{
		boolean bRet = true;

		eventsVector = new Vector();

		NodeList nl = eventsNode.getChildNodes();
		int size = nl.getLength();
		for(int i = 0;i < size && bRet;i++)
		{
			Node curNode = nl.item(i);
			int  nodeType= curNode.getNodeType();

			if ( nodeType == Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();

				if(curTag.equals(EVENT))
					bRet = processEventNode(curNode);
			}
			
		}

		return bRet;
	}

	protected boolean processEventNode(Node eventNode)
	{
		boolean bRet = true;

		System.out.println(";;;;;;;;;;;;;;;;;;;;;");
	
		NodeList nl = eventNode.getChildNodes();
		int size = nl.getLength();

		m_curElement.replace(0, m_curElement.length(), EVENT);

		Vector	  eventVector = new Vector();
		Hashtable  eventHash  = new Hashtable(INITIAL_CAPACITY);

		// add the hashtable right at the beginning
		eventVector.add(eventHash);

		for(int i = 0;i < size && bRet;i++)
		{
			Node curNode = nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();

				if(curTag.equals(SOURCE))
				{
					m_curElement.replace(0, m_curElement.length(), SOURCE);

					String sourceName = processParmValue(curNode); 

					if (null != sourceName)
						eventHash.put(SOURCE, sourceName);
					else
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}
				}

				else if(curTag.equals(EID))
				{
					m_curElement.replace(0, m_curElement.length(), EID);

					String eidName = processParmValue(curNode); 

					if (null != eidName)
						eventHash.put(EID, eidName);
					else
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}
				}

				else if(curTag.equals(GENERIC))
				{
					m_curElement.replace(0, m_curElement.length(), GENERIC);

					String generic = processParmValue(curNode); 

					if (null != generic)
						eventHash.put(GENERIC, generic);
					else
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}
				}

				else if(curTag.equals(SPECIFIC))
				{
					m_curElement.replace(0, m_curElement.length(), SPECIFIC);

					String specific = processParmValue(curNode); 

					if (null != specific)
						eventHash.put(SPECIFIC, specific);
					else
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}
				}


				else if(curTag.equals(HOST))
				{
					m_curElement.replace(0, m_curElement.length(), HOST);

					String hostName=null;

					String name = processParmValue(curNode); 
					
					Object type = ((Element)curNode).getAttribute(TYPE);
					if (null != type && !type.toString().equals("string"))
					{
						hostName = name + " (" + type + ")";
					}
					else
						hostName = name;
					

					if (null != hostName)
						eventHash.put(HOST, hostName);
					else
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}
				}


				else if(curTag.equals(TIME))
				{
					m_curElement.replace(0, m_curElement.length(), TIME);

					Element	hElem = (Element)curNode;

					int year  = new Integer(hElem.getAttribute(YEAR)).intValue();
					int month = new Integer(hElem.getAttribute(MONTH)).intValue() - 1;
					int day   = new Integer(hElem.getAttribute(DAY)).intValue();
					int hour  = new Integer(hElem.getAttribute(HOUR)).intValue();
					int min   = new Integer(hElem.getAttribute(MIN)).intValue();
					int sec   = new Integer(hElem.getAttribute(SEC)).intValue();

					java.util.GregorianCalendar cal= new 
								java.util.GregorianCalendar(year, month, day,
															 hour, min, sec);


					java.text.SimpleDateFormat formatter =  
						new java.text.SimpleDateFormat("EEE, MMM d, yyyy hh:mm:ss aaa");
					String timeVal = formatter.format(cal.getTime());

					eventHash.put(TIME, timeVal);
				}

				else if(curTag.equals(PARMS))
				{
					m_curElement.replace(0, m_curElement.length(), PARMS);

					bRet = processParms(curNode, eventVector, eventHash);
				}
				
				/************************************************************************
					Changes made by Jacinta on Oct 24.
				*/
				
				else if(curTag.equals(SNMPHOST))
				{
					m_curElement.replace(0, m_curElement.length(), SNMPHOST);

					String hostName=null;

					String name = processParmValue(curNode); 
					
					Object type = ((Element)curNode).getAttribute(TYPE);
					if (null != type && !type.toString().equals("string"))
					{
						hostName = name + " (" + type + ")";
					}
					else
						hostName = name;
					

					if (null != hostName)
						eventHash.put(SNMPHOST, hostName);
					else
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}

					System.out.println("EUIEventPArser snmp: " + hostName);
				}

				else if(curTag.equals(LOGMSG))
				{
					m_curElement.replace(0, m_curElement.length(), LOGMSG);

					String logmsg=null;

					String name = processParmValue(curNode); 
					
					Object dest = ((Element)curNode).getAttribute(DEST);
					if (null != dest && !dest.toString().equals("logndisplay"))
					{
						logmsg = name + " (" + dest + ")";
					}
					else
						logmsg = name;
					

					if (null != logmsg)
						eventHash.put(LOGMSG, logmsg);
					else
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}

					System.out.println("EUIEventPArser operaction: " + logmsg);
				}

				else if(curTag.equals(OPERINSTRUCT))
				{
					m_curElement.replace(0, m_curElement.length(), OPERINSTRUCT);

					String operinstr = processParmValue(curNode); 

					if (null != operinstr)
						eventHash.put(OPERINSTRUCT, operinstr);
					else
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}

					System.out.println("EUIEventPArser operaction: " + operinstr);

				}

				else if(curTag.equals(AUTOACTION))
				{
					m_curElement.replace(0, m_curElement.length(), AUTOACTION);

					String autoaction = processParmValue(curNode); 

					if (null != autoaction)
						eventHash.put(AUTOACTION, autoaction);
					else
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}
					System.out.println("EUIEventPArser : " + autoaction);
				}

				else if(curTag.equals(OPERACTION))
				{
					m_curElement.replace(0, m_curElement.length(), OPERACTION);

					String operaction = null; 

					String name = processParmValue(curNode); 
					
					Object menutext = ((Element)curNode).getAttribute(MENUTEXT);
					if (null != menutext && !menutext.toString().equals("on"))
					{
						operaction = name + " (" + menutext + ")";
					}
					else
						operaction = name;

					if (null != operaction)
						eventHash.put(OPERACTION, operaction);
					else
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}
					System.out.println("EUIEventPArser operaction: " + operaction);
				}

				else if(curTag.equals(LOGGROUP))
				{
					m_curElement.replace(0, m_curElement.length(), LOGGROUP);

					String loggroup = processParmValue(curNode); 

					if (null != loggroup)
						eventHash.put(OPERACTION, loggroup);
					else
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}

					System.out.println("EUIEventPArser loggroup: " + loggroup);
				}

				else if(curTag.equals(NOTIFICATION))
				{
					m_curElement.replace(0, m_curElement.length(), NOTIFICATION);

					String notification = processParmValue(curNode); 

					if (null != notification)
						eventHash.put(OPERACTION, notification);
					else
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}

					System.out.println("EUIEventPArser notification: " + notification);
				}

				else if(curTag.equals(TTICKET))
				{
					m_curElement.replace(0, m_curElement.length(), TTICKET);

					String tticket = null;

					String name = processParmValue(curNode); 
					
					Object state = ((Element)curNode).getAttribute(STATE);
					if (null != state && !state.toString().equals("on"))
					{
						tticket = name + " (" + state + ")";
					}
					else
						tticket = name;
					

					if (null != tticket)
						eventHash.put(TTICKET, tticket);
					else
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}

					System.out.println("EUIEventPArser tticket: " + tticket);
				}

				else if(curTag.equals(FORWARD))
				{
					m_curElement.replace(0, m_curElement.length(), FORWARD);

					String logmsg=null;

					String name = processParmValue(curNode); 
					
					Object state = ((Element)curNode).getAttribute(DEST);
					if (null != state && !state.toString().equals("logndisplay"))
					{
						logmsg = name + " (" + state + ")";
					}
					else
						logmsg = name;
					

					if (null != logmsg)
						eventHash.put(LOGMSG, logmsg);
					else
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}

					System.out.println("EUIEventPArser logmsg: " + logmsg);
				}

				else if(curTag.equals(DESCRIP))
				{
					m_curElement.replace(0, m_curElement.length(), DESCRIP);

					String descr = processParmValue(curNode); 

					if (null != descr)
						eventHash.put(DESCRIP, descr);
					else
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}

					System.out.println("EUIEventPArser descr: " + descr);
				}

				else if(curTag.equals(MOUSEOVERTEXT))
				{
					m_curElement.replace(0, m_curElement.length(), MOUSEOVERTEXT);

					String mouseover = processParmValue(curNode); 

					if (null != mouseover)
						eventHash.put(MOUSEOVERTEXT, mouseover);
					else
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}

					System.out.println("EUIEventPArser mouseover: " + mouseover);
				}
				/***********************************************************************/
			}
		}

		eventsVector.add(eventVector);

		return bRet;
	}


	protected boolean processParms(Node parmsNode, Vector eventVector, Hashtable eventHash)
	{
		boolean bRet = true;

		NodeList nl = parmsNode.getChildNodes();
		int size = nl.getLength();

		for(int i = 0;i < size && bRet;i++)
		{
			Node curNode = nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
				if(curTag.equals(PARM))
				{
					Vector parm = processParm(curNode);

					if ( (!parm.isEmpty()) && (parm.size() == 2))
					{
						String parmName = (String)parm.elementAt(0);

						if (parmName.equalsIgnoreCase(SEVERITY))
						{
							String parmValue = (String)parm.elementAt(1);

							eventHash.put(SEVERITY, parmValue);
						}

						else if (parmName.equalsIgnoreCase(EVENT_OVERVIEW))
						{
							String parmValue = stripWhiteSpaces((String)parm.elementAt(1));

							eventHash.put(EVENT_OVERVIEW, parmValue);
						}

						else if (parmName.equalsIgnoreCase(DESCR))
						{
							String parmValue = stripWhiteSpaces((String)parm.elementAt(1));

							eventHash.put(DESCR, parmValue);
						}

						else if (parmName.equalsIgnoreCase(INSTRUCTIONS))
						{
							String parmValue = stripWhiteSpaces((String)parm.elementAt(1));

							eventHash.put(INSTRUCTIONS, parmValue);
						}
						else
						{
							eventVector.add(parm);
						}

						bRet = true;
					}
					else
						bRet = false;

				}

			}
		}

		return bRet;
	}


	protected Vector processParm(Node parmsNode)
	{
		Vector parm = new Vector(2);

		NodeList nl = parmsNode.getChildNodes();
		int size = nl.getLength();
		for(int i = 0;i < size;i++)
		{
			Node curNode = nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
				if(curTag.equals(PARM_NAME))
				{
					String name = processParmName(curNode);

					if (null != name)
						parm.add(name);
				}
				else if(curTag.equals(PARM_VALUE))
				{
					String value = processParmValue(curNode);

					if (null != value)
						parm.add(value);
				}

			}
		}
		
		return parm;
	}

	protected String processParmName(Node parmNameNode)
	{
		String parmName=null;

		Node temp = parmNameNode.getChildNodes().item(0);
		if (temp.getNodeType() == Node.TEXT_NODE)
			parmName = ((Text)temp).getData();
		
		return parmName;
	}

	protected String stripWhiteSpaces(String inp)
	{
		int iLen = inp.length();
		StringBuffer out = new StringBuffer(iLen);
		
		char curC  = inp.charAt(0);
		char prevC = curC;

		for(int iIndex=0; iIndex<iLen; iIndex++)
		{
			prevC = curC;
			curC  = inp.charAt(iIndex);

			if (Character.isWhitespace(curC))
			{
				if (!Character.isWhitespace(prevC))
					out.append(' ');
			}
			else
				out.append(curC);

		}
		
		return out.toString();
	}

	/**
	 */
	public Vector getEvents()
	{
		return eventsVector;
	}
}

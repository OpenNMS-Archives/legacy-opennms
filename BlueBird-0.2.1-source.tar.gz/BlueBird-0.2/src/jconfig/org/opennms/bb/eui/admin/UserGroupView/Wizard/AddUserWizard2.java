//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
package org.opennms.bb.eui.admin.UserGroupView.Wizard;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import org.opennms.bb.eui.admin.UserGroupView.Main.UserManager;

public class AddUserWizard2 extends JDialog
{

	public AddUserWizard2(JFrame parent, boolean modal)
	{
		super(parent, modal);

		JLabel oDescriptionLabel	= new JLabel();
		JLabel oPasswordLabel		= new JLabel();
		JLabel oPasswordConfLabel	= new JLabel();

		getContentPane().setLayout(null);
		setBackground(java.awt.Color.lightGray);
		setSize(383,224);
		setVisible(false);

		getContentPane().add(m_oPasswordInput);
		getContentPane().add(m_oPasswordConfInput);
		getContentPane().add(m_oNextButton);
		getContentPane().add(m_oCancelButton);

		oPasswordLabel.setText("Password:");
		getContentPane().add(oPasswordLabel);
		oPasswordLabel.setBounds(24,80,116,24);
		oPasswordConfLabel.setText("Re enter password:");
		getContentPane().add(oPasswordConfLabel);
		oPasswordConfLabel.setBounds(24,112,116,24);
		m_oNextButton.setText("Next >");
		m_oNextButton.setBounds(72,172,85,25);
		m_oPasswordInput.setBounds(140,80,192,24);
		m_oPasswordConfInput.setBounds(140,112,192,24);
		m_oCancelButton.setText("Cancel");
		m_oCancelButton.setBounds(208,172,85,25);
		oDescriptionLabel.setText(
			    " Please choose a password for "
			    +UserManager.m_sNewId
			    +" ..."
		);
		getContentPane().add(oDescriptionLabel);
		oDescriptionLabel.setBounds(24,4,333,60);
		setTitle("New User Wizard Part 2");
		setResizable(false);

		SymWindow oSymWindow = new SymWindow();
		this.addWindowListener(oSymWindow);

		SymAction oSymAction = new SymAction();
		m_oNextButton.addActionListener(oSymAction);
		m_oCancelButton.addActionListener(oSymAction);

		MouseListener	oMouseListener = new TheMouseListener();
		KeyListener		oKeyListener   = new TheKeyListener();
		m_oPasswordInput.addMouseListener(oMouseListener);
		m_oPasswordInput.addKeyListener(oKeyListener);
		m_oPasswordConfInput.addMouseListener(oMouseListener);
		m_oPasswordConfInput.addKeyListener(oKeyListener);

	}

	public AddUserWizard2(JFrame parent, String title, boolean modal)
	{
		this(parent, modal);
		setTitle(title);
	}

	class TheMouseListener implements MouseListener
	{
		public void mousePressed(MouseEvent e)
		{
			m_oPasswordInput.setBackground(java.awt.Color.white);
			m_oPasswordConfInput.setBackground(java.awt.Color.white);
		}
		public void mouseClicked(MouseEvent e)
		{
			m_oPasswordInput.setBackground(java.awt.Color.white);
			m_oPasswordConfInput.setBackground(java.awt.Color.white);
		}

		public void mouseEntered(MouseEvent e){}
		public void mouseExited(MouseEvent e){}
		public void mouseReleased(MouseEvent e){}
	}

	class TheKeyListener implements KeyListener
	{
		public void keyTyped(java.awt.event.KeyEvent e)
		{
			m_oPasswordInput.setBackground(java.awt.Color.white);
			m_oPasswordConfInput.setBackground(java.awt.Color.white);
		}
		public void keyPressed(java.awt.event.KeyEvent e)
		{
			m_oPasswordInput.setBackground(java.awt.Color.white);
			m_oPasswordConfInput.setBackground(java.awt.Color.white);
		}

		public void keyReleased(KeyEvent e){}
 	}
    
	public void addNotify()
	{
		Dimension d = getSize();

		super.addNotify();

		if (m_bComponentsAdjusted)
		{
			return;
		}

		Insets insets = getInsets();
		setSize(insets.left + insets.right + d.width, insets.top + insets.bottom + d.height);
		Component components[] = getComponents();
		for (int i = 0; i < components.length; i++)
		{
			Point p = components[i].getLocation();
			p.translate(insets.left, insets.top);
			components[i].setLocation(p);
		}

		m_bComponentsAdjusted = true;
	}

	public void setVisible(boolean b)
	{
	    if (b)
	    {
    		Rectangle bounds = getParent().getBounds();
    		Rectangle abounds = getBounds();

    		setLocation(bounds.x + (bounds.width - abounds.width)/ 2,
    			 bounds.y + (bounds.height - abounds.height)/2);
	    }

		super.setVisible(b);
	}

	JButton			m_oNextButton		= new JButton();
	JPasswordField	m_oPasswordInput	= new JPasswordField();
	JPasswordField	m_oPasswordConfInput= new JPasswordField();
	JButton			m_oCancelButton		= new JButton();
    
    // Used for addNotify check.
	boolean m_bComponentsAdjusted = false;

	class SymAction implements java.awt.event.ActionListener
	{
		public void actionPerformed(java.awt.event.ActionEvent event)
		{
			Object object = event.getSource();
			if (object == m_oNextButton)
			{
				String sInput1 = new String(m_oPasswordInput.getPassword());
	    
				if( (sInput1 == null) || (sInput1.equals("")) || (sInput1.equals("\0")) || (sInput1.equals("\n")) || (sInput1.equals("\r")) || (sInput1.equals("0x00")) )
				{
				    m_oPasswordInput.setBackground(java.awt.Color.red);
				}
				else
				{
				    String sInput2 = new String(m_oPasswordConfInput.getPassword());
				    if(!sInput1.equals(sInput2))
				    {
				        m_oPasswordConfInput.setBackground(java.awt.Color.red);
				    }
			 	    else
	 			    {
				        try
						{
							UserManager.m_sBuffer= new String(m_oPasswordInput.getPassword());
							UserManager.m_sBuffer+= ":";
							UserManager.m_sBuffer+= "(unknown):";
							UserManager.m_sBuffer+= "(none):";
							setVisible(false);
							dispose();

							// AddUserWizard3 Create and show as modal
							(new AddUserWizard3(((JFrame)getParent()), true)).setVisible(true);
			
				        }
						catch (Exception e)
						{
							UserManager.cancel();
				        }
			 	    }
			 	}
			}
			else if (object == m_oCancelButton)
			{
			    try
				{
					UserManager.cancel();
					setVisible(false);
					dispose();
			    }
				catch (Exception e)
				{
				}
			}
				
		}
	}


	class SymWindow extends java.awt.event.WindowAdapter
	{
		public void windowClosing(java.awt.event.WindowEvent event)
		{
			Object object = event.getSource();
			if (object == AddUserWizard2.this)
			{
				try
				{
					UserManager.cancel();
					setVisible(false);
					dispose();
				}
				catch (Exception e)
				{
				}
			}
		}
	}

}

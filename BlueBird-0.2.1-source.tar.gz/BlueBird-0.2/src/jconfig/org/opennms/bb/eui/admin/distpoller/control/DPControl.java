//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.admin.distpoller.control;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;
import javax.swing.tree.*;
import javax.swing.border.Border;

import java.awt.*;
import java.awt.event.*;

import java.util.Hashtable;
import java.util.Vector;
import java.io.File;

import org.opennms.bb.eui.admin.utils.PitXmlParser;
import org.opennms.bb.eui.admin.distpoller.control.utils.DPControlPollersParser;
import org.opennms.bb.eui.admin.distpoller.control.utils.DPPollerPerfParser;
import org.opennms.bb.eui.common.components.*;

import org.opennms.bb.eui.admin.distpoller.control.utils.DPControlUserProfParser;
import org.opennms.bb.eui.admin.distpoller.control.utils.DPControlUserProfWriter;

import org.opennms.bb.eui.admin.distpoller.control.interfaces.DistPollerController;
import org.opennms.bb.eui.admin.interfaces.AdminTool;

/**
 * <pre>DPControl is the Distributed Poller Control panel. This  
 *  - creates the poller controls from the "dpControlXML.xml"
 *
 *  - builds the poller list and displays their configuration info from the
 *			"pollersXML.xml" file
 *
 * @author Sowmya
 *
 */
public class DPControl extends JFrame implements ActionListener, AdminTool
{
	// parsers
	PitXmlParser			controlsParser;
	DPControlPollersParser	pollersParser;

	// data
	Hashtable				icebergHeader;
	Vector					icebergPollers;

	// data holders
	PictureTextList			pollerList;
	BBDisplayTable			conTable;

	JLabel					opLabel;
	JTree					opTree;
	BBDisplayTable			opTable;

	// scrollpanes
	JScrollPane				listScrPane;
	BBScrollPane			opTableScrPane;
	JScrollPane				opTreeScrPane;

	// panels
	JPanel					toolPanel;
	JPanel					opPanel;

	// currently selected poller
	String					curSelectedPoller;

	// services of the currently selected poller
	Vector					curPollerServiceIDs;

	// services of the currently selected poller and their parameters
	Vector					curPollerServices;

	// temp dir
	final String  TEMP_DIR	="org/opennms/bb/eui/admin/distpoller/control/data/temp/";

	// perf data tag
	final	String MODULENAME ="moduleName";

	// user
	String			userID;

	// user profile values
	final String XPOS		="xPos";
	final String YPOS		="yPos";
	final String WIDTH		="Width";
	final String HEIGHT		="Height";
	final String LOOKNFEEL	="lookAndFeel";

	// user profile related
	boolean					bLandFAtStartUp=true;
	Hashtable				userProfile;

	/**
	 * Creates the panel if the xml files are parsed without error
	 */
	public DPControl()
	{
		super();
	}

	public void start(String userID)
	{
		//
		this.userID = userID;

		// get user profile
		readUserProfile();

		// set look and feel
		String landf = String.valueOf(userProfile.get(LOOKNFEEL));
		if (landf != null)
			handleMenuToolBarActions(landf);

		bLandFAtStartUp = false;

		// load default colors
       	UIManager.put("Table.background", Color.white); 

   		UIManager.put("Tree.textBackground", Color.white); 
   		UIManager.put("Tree.selectionBackground", new Color(0, 0, 128));
   		UIManager.put("Tree.selectionForeground", Color.white);
   		UIManager.put("Tree.background", Color.white); 

		// Parse the required xmls first
		try
		{
			controlsParser=new PitXmlParser();
			controlsParser.parse("data/common/conf/dpControlXML.xml");

			pollersParser=new DPControlPollersParser();
			pollersParser.parse("data/common/conf/pollersXML.xml");

		} catch (Exception e)
		{
	 		JOptionPane.showMessageDialog(new JFrame(), 
					e.getMessage(),
					"Error! Unable to parse input xml file", 
					JOptionPane.ERROR_MESSAGE);

			return;
		}

		icebergHeader = pollersParser.getHeaderInfo();
		icebergPollers = pollersParser.getPollers();

		// menu panel
		JPanel menuPanel = new JPanel();
		menuPanel.setOpaque(false);
		menuPanel.setLayout(new BorderLayout());

		// Create the menu
		JMenuBar dpcMenu = createMenu();
		menuPanel.add(dpcMenu, BorderLayout.NORTH);
		
		// controls
		toolPanel = buildToolPanel();

		// poller list
		JPanel listPanel = buildListPanel(); 

		// configured info
		JPanel conTablePanel = buildConTablePanel(); 

		// operational info
		opPanel = buildOpTablePanel();

		JPanel mainInfoPanel = new JPanel();
		mainInfoPanel.setLayout(new GridLayout(0, 1));

		mainInfoPanel.add(listPanel);
		mainInfoPanel.add(conTablePanel);
		mainInfoPanel.add(opPanel);

		JPanel mainPanel = new JPanel();
		mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.X_AXIS));

		toolPanel.setAlignmentY(Component.TOP_ALIGNMENT);
		mainInfoPanel.setAlignmentY(Component.TOP_ALIGNMENT);

		mainPanel.add(toolPanel);
		mainPanel.add(toolPanel);
		mainPanel.add(mainInfoPanel);

		// set sizes
		adjustSizes();

		// set title
		setTitle("Poller Control Center");

		Container cont = getContentPane();
		cont.setLayout(new BorderLayout());

		cont.add(menuPanel, BorderLayout.NORTH);
		cont.add(mainPanel, BorderLayout.CENTER);

		// Set user position/dimension preferences
		setUserPosDimPreferences();

		pack();
		setVisible(true);

		// list selection listener
		pollerList.addListSelectionListener(new DPControlListListener());

		// window close listener
		addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
				handleExit();
			}
		});

		setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);

	}

	/**
	 * Reads the user preferences from the user profile file
	 */
	protected void readUserProfile()
	{
		DPControlUserProfParser userProfParser=null;
		boolean	bUserProfileRead=true;

		String userxml = "data/users/pers-" + userID + ".xml";

		// if file does not exist, just take defaults
		File userFile = new File(userxml);
		if (userFile.exists() && userFile.canRead())
		{
			// get user profile
			try
			{
				userProfParser = new DPControlUserProfParser();
				userProfParser.parse(userxml);
			}
			catch (Exception e)
			{
				// if the profile has an error, just prompt and continue
	 			JOptionPane.showMessageDialog(new JFrame(), 
					e.getMessage(),
					"Error! Unable to parse user profile file", 
					JOptionPane.ERROR_MESSAGE);

				bUserProfileRead = false;
			}
		}
		else
				bUserProfileRead = false;
		
		// 
		if (bUserProfileRead)
		{
			userProfile = userProfParser.getUserProfile();

			if(userProfile == null)
				userProfile = new Hashtable(5);
		}

		else
			userProfile = new Hashtable(5);
	}

	/**
	 * Sets the (x,y) and size preferences of the user
	 */
	protected void setUserPosDimPreferences()
	{
		// set the location of the frame
		Object xPos = userProfile.get(XPOS);
		Object yPos = userProfile.get(YPOS);
		if (xPos != null && yPos != null)
		{
			setLocation(((Integer)xPos).intValue(), 
								((Integer)yPos).intValue());
		}
		else
			setLocation(100, 100);

		// set the size
		Object width = userProfile.get(WIDTH);
		Object height = userProfile.get(HEIGHT);
		if (width != null && height != null)
		{
			setSize(new Dimension(((Integer)width).intValue(),
										  ((Integer)height).intValue()));
		}
		else
			setSize(new Dimension(700, 600));
	}

	/**
	 * Displays the corresponding configuration info for the poller
	 * selected. Also displays the last operational information available
	 * with the time stamp
	 */
	protected class DPControlListListener implements ListSelectionListener
	{
		final String VER		="ver";
		final String DATE		="date";
	
		final String POLLER		="poller";
		final String POLLERS	="pollers";
		final String POLLERID	="pollerID";
		final String POLLERNAME	="pollerName";
		final String POLLERIP	="pollerIP";
		final String DISCLIMIT	="discLimit";
		final String POLLERHOST	="pollerHost";
		final String POLLERCOMM	="pollerComments";
		final String PACKAGE	="package";
		final String PACKAGES	="packages";

		public void valueChanged(ListSelectionEvent e)
		{
			PictureTextList	list = (PictureTextList)e.getSource();
			PictureTextListModel model = (PictureTextListModel)list.getModel();

			if (!list.isSelectionEmpty())
			{
				curSelectedPoller = model.getName(list.getSelectedValue());

				int iSize = icebergPollers.size();

				for(int iIndex=0; iIndex<iSize; iIndex++)
				{
					Hashtable temp = (Hashtable)icebergPollers.elementAt(iIndex);

					if (String.valueOf(temp.get(POLLERID)).equals(curSelectedPoller))
					{
						// set configured data
						Vector cols = new Vector();
						cols.add("Parameter");
						cols.add("Value");

						Vector conData = new Vector();
						extractConfiguredData(conData, temp);

						((DefaultTableModel)conTable.getModel()).setDataVector(conData, cols);
						String fileName = TEMP_DIR + curSelectedPoller + 
															".perfXML.xml";

						DPPollerPerfParser	perfParser;


						try
						{
							perfParser=new DPPollerPerfParser();
							perfParser.parse(fileName);

						} catch (Exception ex)
						{
							// if the file cannot be parsed for whatever reason,
							// don't display anything

							// reset label
							opLabel.setText("Operational Information");

							// clear out the tree
							DefaultMutableTreeNode root = 
								new DefaultMutableTreeNode(curSelectedPoller);

							DefaultTreeModel treeModel = 
												new DefaultTreeModel(root);

							opTree.setModel(treeModel);

							// clear out opTable
							Vector	opData = new Vector();
							((DefaultTableModel)
								opTable.getModel()).setDataVector(opData, cols);

							return;
						}
						
						// if data can be parsed set tree
						setOperationalData(perfParser.getModules());

						// set label
						setCurOpDataTimeStamp(perfParser.getCreationDate());

						// select first service 
						opTree.setSelectionInterval(0, 0);

					}
				}

			}
		}

		void extractConfiguredData(Vector data, Hashtable table)
		{
			// poller IP
			Vector ip = new Vector();
			ip.add("IP Address");
			ip.add(table.get(POLLERIP));

			// poller host
			Vector host = new Vector();
			host.add("Host Name");
			host.add(table.get(POLLERHOST));

			// poller package count
			Vector numPack = new Vector();
			numPack.add("Poller Packages");
			numPack.add(table.get(PACKAGES));

			// revision
			Vector rev = new Vector();
			rev.add("Revision Number");
			rev.add(icebergHeader.get(VER));

			// date
			Vector cdate = new Vector();
			cdate.add("Created on");
			cdate.add(icebergHeader.get(DATE));

			data.add(ip);
			data.add(host);
			data.add(numPack);
			data.add(rev);
			data.add(cdate);

		}
	}

	/**
	 * Builds the controls panel from the dpControlXML.xml
	 */
	JPanel buildToolPanel()
	{
		JPanel				pollerToolPanel;

		Hashtable			iconLayoutData;
		Vector				pollerControls;

		final String FONT_TYPE	="fontType";
		final String FONT_STYLE	="fontStyle";
		final String FONT_SIZE	="fontSize";

		final String ICONLAYOUT	="iconLayout";
		final String LABELPOS	="labelPos";

		final String LABEL		="label";
		final String LABELTEXT	="text";
		final String HOTKEY		="hotkey";
		final String ICON		="icon";
		final String HINT		="hint";
		final String CLASSNAME	="classname";

		int			iGridRows=0;
		int			iGridCols=0;

		iconLayoutData = controlsParser.getIconLayoutData();

		GridLayout grid = new GridLayout(0, 1, 5, 5);

		pollerToolPanel = new JPanel();
		pollerToolPanel.setOpaque(false);
		pollerToolPanel.setBorder(BorderFactory.createBevelBorder(
								javax.swing.border.BevelBorder.RAISED));

		// set layout
		pollerToolPanel.setLayout(grid);

		// icon layout data
		Integer fSize = new Integer(String.valueOf(iconLayoutData.get(FONT_SIZE)));
		int iFontStyle = getFontStyle(String.valueOf(iconLayoutData.get(FONT_STYLE))); 

		Font labelFont = new Font( 
								String.valueOf(iconLayoutData.get(FONT_TYPE)), 
								iFontStyle,
								fSize.intValue());
	
		String textPos = String.valueOf(iconLayoutData.get(LABELPOS)).toLowerCase();

		// poller controls
		pollerControls = controlsParser.getToolsData();
		int numOptions = pollerControls.size();
		
		StringBuffer mnemonicsSet = new StringBuffer(numOptions);

		for(int iIndex=0; iIndex< numOptions; iIndex++)
		{
			JPanel panel = new JPanel();
			panel.setOpaque(false);
			panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

			Hashtable control = (Hashtable)pollerControls.elementAt(iIndex);

			// create button
			String icon = String.valueOf(control.get(ICON));
			ImageIcon buttonIcon =new ImageIcon(icon);

			BBTBButton button = 
				new BBTBButton(buttonIcon, String.valueOf(control.get(HINT)));

			button.setAlignmentX(Component.CENTER_ALIGNMENT);
			
			// get classname
			final String className=String.valueOf(control.get(CLASSNAME)).trim();

			// scroll to become visible when activated by the label
			button.addFocusListener(new FocusAdapter()
			{
				public void focusGained(FocusEvent e)
				{
					BBTBButton source = (BBTBButton)e.getSource();
					Dimension size = source.getSize();
					source.scrollRectToVisible(new Rectangle(0, 0, size.width, size.height));

					JPanel 	parent = (JPanel)source.getParent();
					Dimension parentSize = parent.getPreferredSize();
					parent.scrollRectToVisible(new Rectangle(0, 0, parentSize.width, parentSize.height));
				}
			});

			// set action
			button.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent event)
				{
					String exceptionMsg="";
					boolean bException=false;

					DistPollerController	controller=null;

					try 
					{
						controller = (DistPollerController)Class.forName(className).newInstance();
					}
					catch (ClassNotFoundException e)
					{
						exceptionMsg = new String("ClassNotFoundException");
						bException=true;
					}
					catch (IllegalAccessException e)
					{
						exceptionMsg = new String("IllegalAccessException");
						bException=true;
					}
					catch (InstantiationException e)
					{
						exceptionMsg = new String("InstantiationException");
						bException=true;
					}

					if (bException)
					{
	 					JOptionPane.showMessageDialog(new JFrame(), 
								"Unable to start poller control \'" + className 
								 + "\'\nException: " + exceptionMsg,
								"Error!", 
								JOptionPane.ERROR_MESSAGE);
					}
					else
					{
						// get the control to do its work
						boolean	bRet = controller.process(curSelectedPoller);
						if (bRet)
						{
							// If the control affects the operational data
							// update the operation tree and table

							Vector	pollerServices= 
										controller.getPollerServices();
							if (null != pollerServices)
							{
								setOperationalData(pollerServices);
							}

							// label
							String	opLabelText = controller.getOpDataTimeStamp();
							if (null != opLabelText)
							{
								setCurOpDataTimeStamp(opLabelText);

							}
						}
					}
				}
			});

			// format the label
			String[]	labelNames;

			if (null != control.get(LABELTEXT))
			{
				labelNames = formatButtonLabel(control);
			}
			else
			{
				labelNames = new String[1];
			}

			// mnemonic
			char mnemonicChar = '\0';
			if (null != control.get(HOTKEY))
				mnemonicChar = String.valueOf(control.get(HOTKEY)).trim().charAt(0);
			// check if duplicate mnemonic
			if(mnemonicChar != '\0')
			{
				if (mnemonicsSet.toString().indexOf(mnemonicChar) != -1) // duplicate
				{
	 				JOptionPane.showMessageDialog(new JFrame(), 
						"Hotkey \'" + mnemonicChar + "\' specified for more than one poller control" +
						"\nOnly the first control can be reached!",

						"Duplicate hotkey!",
						JOptionPane.WARNING_MESSAGE);
				}
				else
					mnemonicsSet.append(mnemonicChar);
			}



			if (textPos.equals("top"))
			{
				panel.add(Box.createVerticalGlue());
				createButtonLabel(labelNames, labelFont, mnemonicChar, button, panel);
				panel.add(button);
			}
			else
			{
				panel.add(button);
				createButtonLabel(labelNames, labelFont, mnemonicChar, button, panel);
			}
			panel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
			pollerToolPanel.add(panel);
		}
		
		// add to scrollpane
		JScrollPane controlsScrPane = new JScrollPane(pollerToolPanel);

		JPanel toolPanel = new JPanel();
		toolPanel.setLayout(new BoxLayout(toolPanel, BoxLayout.Y_AXIS));

		JLabel label1 = new JLabel("Poller", SwingConstants.CENTER);
		label1.setAlignmentX(Component.CENTER_ALIGNMENT);
		JLabel label2 = new JLabel("Control", SwingConstants.CENTER);
		label2.setAlignmentX(Component.CENTER_ALIGNMENT);

		toolPanel.add(Box.createVerticalStrut(5));
		toolPanel.add(label1);
		toolPanel.add(label2);
		toolPanel.add(controlsScrPane);
		toolPanel.add(Box.createVerticalGlue());

		return toolPanel;
	}

	private int getFontStyle(String style)
	{
		int iFontStyle=Font.BOLD;

		if (style.equals("plain"))
			iFontStyle = Font.PLAIN;
		else if (style.equals("BOLD"))
			iFontStyle = Font.BOLD;
		else if (style.equals("italic"))
			iFontStyle = Font.ITALIC;
		else if (style.equals("boldItalic"))
			iFontStyle = Font.BOLD | Font.ITALIC;
		
		return iFontStyle;
	}

	/*
	 * Break the labels into multiple strings
	 */
	private String[] formatButtonLabel(Hashtable control)
	{
		final String LABELTEXT		="text";

		// get button label 
		String inpLabel = String.valueOf(control.get(LABELTEXT)).trim();

		StringBuffer label = new StringBuffer();

		int LINE_LEN =15;
		int iLen     =inpLabel.length();
		int iLastLine=0;
		for(int iIndex=0; iIndex<iLen; iIndex++)
		{
			if (inpLabel.charAt(iIndex) == ' ')
			{
				int iIndex2=0;

				for(iIndex2=iIndex+1; iIndex2<iLen; iIndex2++)
				{
					if (inpLabel.charAt(iIndex2) == ' ')
					{
						break;
					}
				}

				// break  if the current line already has required characters
				// or if the next line will be too long
				if ((iIndex - iLastLine >=LINE_LEN ) || 
				    (iIndex2 - iIndex >= LINE_LEN) ||
					(iLastLine == 0 && (iIndex2 - iLastLine >= LINE_LEN))
				   )
				{
					label.append("\n");

					iLastLine=iIndex;
				}
				else
					label.append(inpLabel.charAt(iIndex));
			}
			else
				label.append(inpLabel.charAt(iIndex));
		}

		return splitStringByLines(label.toString());
	}

	private String[] splitStringByLines( String str )	
	{		
		String[] strs;	

		int lines = 1;		
		int i, c;
        for(i=0, c=str.length() ; i < c ; i++) 
		{
            if( str.charAt(i) == '\n' )            	
				lines++;        
		}
		strs = new String[lines];
		java.util.StringTokenizer st = new java.util.StringTokenizer( str, "\n" );				
		
		int line = 0;
		while( st.hasMoreTokens() )			
			strs[line++] = st.nextToken();					
		return strs;
	}

	/*
	 * Create multiple labels each if which are center justified
	 */
	private void createButtonLabel(String[] labelNames, Font labelFont, 
								   char mnemonicChar, BBTBButton button, 
								   JPanel panel)
	{
		JLabel buttonLabel;
		boolean bMnemonicSet=false;

		if (mnemonicChar == '\0')
			bMnemonicSet = true;

		int iLen = labelNames.length;	
		for(int iIndex=0; iIndex<iLen; iIndex++)
		{
			if (null != labelNames[iIndex])
				buttonLabel = new JLabel(labelNames[iIndex], JLabel.CENTER);
			else
			{
				buttonLabel = new JLabel();
			}
			buttonLabel.setFont(labelFont);
			buttonLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
			buttonLabel.setLabelFor(button);

			if (labelNames[iIndex].indexOf(mnemonicChar) != -1 && !bMnemonicSet)
			{
				buttonLabel.setDisplayedMnemonic(mnemonicChar);
				bMnemonicSet = true;
			}
			panel.add(buttonLabel);
		}

		if (!bMnemonicSet)
		{
			String error;
			if (iLen > 1)
				error = new String("\n\'" + labelNames[0] + "\'..");
			else
				error = new String("\n\'" + labelNames[0] + "\'");

	 		JOptionPane.showMessageDialog(new JFrame(), 
				"Hotkey \'" + mnemonicChar + "\' specified not found in label" +
				error,
				"HotKey not found!",
				JOptionPane.WARNING_MESSAGE);
		}
	}

	/**
	 * Builds the poller list panel
	 */
	JPanel buildListPanel()
	{
		// list
		Vector icons = new Vector();
		Vector values = pollersParser.getPollerIDs();

		for (int iIndex=0; iIndex<values.size(); iIndex++)
		{
			icons.add(new ImageIcon("data/images/computer.50.gif"));
		}

		pollerList = new PictureTextList(icons, values);

		// add to scrollpane
		listScrPane = new JScrollPane(pollerList);
		listScrPane.setAlignmentX(Component.CENTER_ALIGNMENT);
		listScrPane.setBorder(BorderFactory.createLineBorder(Color.black));

		// border
		Border border = BorderFactory.createRaisedBevelBorder();
		Border listBorder = pollerList.getBorder();
		listScrPane.setBorder(BorderFactory.createCompoundBorder(listBorder, border));
		JPanel panel = new JPanel();
		panel.setLayout(new BoxLayout(panel, BoxLayout.X_AXIS));
		panel.add(listScrPane);
		panel.setBorder(BorderFactory.createLoweredBevelBorder());

		// label
		JLabel label1 = new JLabel("Configure Pollers", SwingConstants.CENTER);
		label1.setAlignmentX(Component.CENTER_ALIGNMENT);

		// add to panel
		JPanel listPanel = new JPanel();
		listPanel.setLayout(new BoxLayout(listPanel, BoxLayout.Y_AXIS));
		listPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 10, 5));

		listPanel.add(Box.createVerticalStrut(19));
		listPanel.add(label1);
		listPanel.add(panel);

		return listPanel;
	}

	/**
	 * Builds the configuration table panel
	 */
	JPanel buildConTablePanel()
	{
		Vector data = new Vector();
		Vector cols = new Vector();

		cols.add("Parameter");
		cols.add("Value");

		conTable = new BBDisplayTable( data, cols);

		// add to scrollpane
		final BBScrollPane conTableScrPane = new BBScrollPane(conTable);
		conTableScrPane.setAlignmentX(Component.CENTER_ALIGNMENT);

		conTable.getModel().addTableModelListener(new TableModelListener()
		{
			public void tableChanged(TableModelEvent e)
			{
				if (e.getColumn() == e.ALL_COLUMNS && e.getType() == e.INSERT)
				{
					Dimension curSize = conTable.getPreferredSize();
					conTableScrPane.setPreferredSize(curSize);
				}
			}
		});

		// border
		Border border = BorderFactory.createRaisedBevelBorder();
		Border tableBorder = conTable.getBorder();
		conTableScrPane.setBorder(BorderFactory.createCompoundBorder(tableBorder, border));

		JPanel panel = new JPanel();
		panel.setLayout(new BoxLayout(panel, BoxLayout.X_AXIS));
		panel.add(conTableScrPane);
		panel.setBorder(BorderFactory.createLoweredBevelBorder());

		// label
		JLabel label1 = new JLabel("Configured Information", 
											SwingConstants.CENTER);
		label1.setAlignmentX(Component.CENTER_ALIGNMENT);

		// add to panel
		JPanel conTablePanel = new JPanel();
		conTablePanel.setLayout(new BoxLayout(conTablePanel, BoxLayout.Y_AXIS));

		// border
		conTablePanel.setBorder(BorderFactory.createEmptyBorder(10, 5, 10, 5));

		conTablePanel.add(label1);
		conTablePanel.add(panel);
		
		return conTablePanel;
	}

	/**
	 * Builds the operational info panel
	 */
	JPanel buildOpTablePanel()
	{
		// table
		Vector data = new Vector();
		Vector cols = new Vector();

		cols.add("Parameter");
		cols.add("Value");

		opTable = new BBDisplayTable( data, cols);

		opTableScrPane = new BBScrollPane(opTable);
		opTableScrPane.setAlignmentY(Component.TOP_ALIGNMENT);

		// tree
		opTree = new JTree(data);
		opTree.setBackground(Color.white);

		opTree.getSelectionModel().setSelectionMode(
							TreeSelectionModel.SINGLE_TREE_SELECTION);
		opTree.addTreeSelectionListener(new DPControlTreeListener());

		opTreeScrPane = new JScrollPane(opTree);
		opTreeScrPane.setAlignmentY(Component.TOP_ALIGNMENT);

		opTable.getModel().addTableModelListener(new TableModelListener()
		{
			public void tableChanged(TableModelEvent e)
			{
				if (e.getColumn() == e.ALL_COLUMNS && e.getType() == e.INSERT)
				{
					Dimension treeSize = opTree.getPreferredSize();
					opTreeScrPane.setPreferredSize(treeSize);
					opTree.setPreferredSize(treeSize);
					
					Dimension curSize = opTable.getPreferredSize();
					opTableScrPane.setPreferredSize(curSize);
				}
			}
		});

		// header
		JLabel service = new JLabel("Services", SwingConstants.CENTER);
		service.setOpaque(true);
		service.setSize(new Dimension(service.getPreferredSize().width, 16));
		service.setBorder(BorderFactory.createRaisedBevelBorder());

		opTreeScrPane.setColumnHeaderView(service);

		// tree table panel
		JPanel panel = new JPanel();
		panel.setLayout(new BoxLayout(panel, BoxLayout.X_AXIS));
		panel.setAlignmentX(Component.CENTER_ALIGNMENT);

		// border
		Border treeBorder = opTree.getBorder();
		Border inBorder	 = BorderFactory.createRaisedBevelBorder();

		opTreeScrPane.setBorder(BorderFactory.createCompoundBorder(inBorder, treeBorder));

		Border tableBorder = opTable.getBorder();
		opTableScrPane.setBorder(BorderFactory.createCompoundBorder(tableBorder, inBorder));

		panel.setBorder(BorderFactory.createLoweredBevelBorder());

		panel.add(opTreeScrPane);
		panel.add(opTableScrPane);

		// label
		opLabel = new JLabel("Operational Information", 
													SwingConstants.CENTER);
		opLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

		// add to panel
		JPanel opPanel = new JPanel();
		opPanel.setLayout(new BoxLayout(opPanel, BoxLayout.Y_AXIS));
		opPanel.setBorder(BorderFactory.createEmptyBorder(10, 5, 5, 5));

		opPanel.add(opLabel);
		opPanel.add(panel);
		
		return opPanel;
	}

	/**
	 * Displays the parameters for the service selected in the operational
	 * info. tree
	 */
	protected class DPControlTreeListener implements TreeSelectionListener
	{
		public void valueChanged(TreeSelectionEvent e)
		{
			JTree tree = (JTree)e.getSource();
			
			if (tree.isSelectionEmpty())
				return;
			
			DefaultMutableTreeNode node = 
					(DefaultMutableTreeNode)tree.getLastSelectedPathComponent();

			Vector opData = new Vector();

			int iSize = curPollerServices.size();

			for(int iIndex=0; iIndex<iSize; iIndex++)
			{
				Vector tempM = (Vector)curPollerServices.elementAt(iIndex);
				int  iMSize = tempM.size();

				Vector temp = (Vector)tempM.elementAt(0);

				String id = String.valueOf(temp.elementAt(0));
				String val = String.valueOf(temp.elementAt(1));

				if (id.equals(MODULENAME) && val.equals(node.toString()))
				{
					for(int i=1; i<iMSize; i++)
					{
						temp = (Vector)tempM.elementAt(i);
						opData.add(temp);
					}
				}
			}
			
			// cols
			Vector cols = new Vector();
			cols.add("Parameter");
			cols.add("Value");

			((DefaultTableModel)opTable.getModel()).setDataVector(opData, cols);
			
		}
	}

	/**
	 * Sets panel sizes
	 */
	void adjustSizes()
	{
		final int HEIGHT=125;

		// tool panel
		Dimension toolSize = toolPanel.getPreferredSize();

		int toolHeight = toolSize.height;
		if (toolHeight > 600) 
			toolHeight=600;

		Dimension newToolSize = new Dimension(100, toolHeight);
		toolPanel.setPreferredSize(newToolSize);

		Dimension newToolMaxSize = new Dimension(150, toolHeight*2);
		toolPanel.setMaximumSize(newToolMaxSize);

		// list height
		Dimension listSize = listScrPane.getPreferredSize();
		listScrPane.setPreferredSize(new Dimension(listSize.width, HEIGHT));

		// operational data tree
		opTreeScrPane.setPreferredSize(new Dimension(175, HEIGHT));

		// operational data table
		Dimension opSize = opTableScrPane.getPreferredSize();
		opTable.setTableDimension(opSize.width, HEIGHT);

		// configured data table
		int conSizeWidth = opPanel.getPreferredSize().width;
		conTable.setTableDimension(conSizeWidth, HEIGHT);
	}

	/**
	 * Creates the menu
	 */
	protected JMenuBar createMenu()
	{
		JMenuBar	dpcMenuBar;
		JMenu		dpcMenu;
		JMenuItem	menuItem;

		dpcMenuBar = new JMenuBar();

		// The file menu
		dpcMenu = new JMenu("File");
		dpcMenu.setMnemonic('F');
		dpcMenuBar.add(dpcMenu);

		menuItem = new JMenuItem("Exit",  KeyEvent.VK_X);
		menuItem.addActionListener(this);
		dpcMenu.add(menuItem);

		// The Options  menu
		dpcMenu = new JMenu("Options");
		dpcMenu.setMnemonic('O');
		dpcMenuBar.add(dpcMenu);

		// Look and Feel
		JMenu lfMenu = new JMenu("Look And Feel");
		lfMenu.setMnemonic(KeyEvent.VK_L);
		lfMenu.addActionListener(this);
		dpcMenu.add(lfMenu);

        // Look and Feel Radio control
		ButtonGroup group = new ButtonGroup();
		JRadioButtonMenuItem radioMenuItem;

	    radioMenuItem = new JRadioButtonMenuItem("Metal");
		radioMenuItem.setSelected(
				UIManager.getLookAndFeel().getName().equals("Metal"));
		lfMenu.add(radioMenuItem);
		group.add(radioMenuItem);
		radioMenuItem.addActionListener(this);

        radioMenuItem = new JRadioButtonMenuItem("CDE/Motif");
		radioMenuItem.setSelected(
				UIManager.getLookAndFeel().getName().equals("CDE/Motif"));
		lfMenu.add(radioMenuItem);
		group.add(radioMenuItem);
		radioMenuItem.addActionListener(this);

        radioMenuItem = new JRadioButtonMenuItem("Windows");
		radioMenuItem.setSelected(
				UIManager.getLookAndFeel().getName().equals("Windows"));
		lfMenu.add(radioMenuItem);
		group.add(radioMenuItem);
		radioMenuItem.addActionListener(this);

		dpcMenuBar.add(Box.createHorizontalGlue());

		dpcMenu = new JMenu("Help");
		dpcMenu.setMnemonic('H');
		dpcMenuBar.add(dpcMenu);

		menuItem = new JMenuItem("About",  KeyEvent.VK_A);
		menuItem.addActionListener(this);
		dpcMenu.add(menuItem);
		
		return dpcMenuBar;
	}

	/**
	 * Handles actions for the menu
	 */
	public void actionPerformed(ActionEvent e)
	{
		String actionStr = e.getActionCommand();
		handleMenuToolBarActions(actionStr);
	}

	void handleMenuToolBarActions(String actionStr)
	{
		// exit
		if (actionStr.equals("Exit"))
		{
			handleExit();
		}

		// options
		else if (actionStr.equals("Metal"))
		{
        	setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");
		}

		else if (actionStr.equals("CDE/Motif"))
		{
       		UIManager.put("ScrollPane.background", Color.white); 
			setLookAndFeel("com.sun.java.swing.plaf.motif.MotifLookAndFeel");
		}

		else if (actionStr.equals("Windows"))
		{
			setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		}
		else if (actionStr.equals("About"))
		{
			new AboutDialog(new JFrame(), "About BlueBird");
		}
	}

	void setLookAndFeel(String str)
	{

	    setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));

		try 
		{
        	UIManager.setLookAndFeel(str);

			if(!bLandFAtStartUp)
			{
	   			SwingUtilities.updateComponentTreeUI(this);
			}

		} catch (Exception exc) 
		{
			System.err.println("Cannot load the " + str + " look and feel");
			System.err.println(exc.getMessage());

			// try and go back to default
			try
			{
				UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
	   			SwingUtilities.updateComponentTreeUI(this);
			}
			catch (Exception e)
			{
				// Don't really do anything?
			}
		}

	   	setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
	}

	/**
	 * Deletes the files in the TEMP_DIR and the TEMP_DIR when present
	 * The TEMP_DIR is used by the 'refresh operational info' control
	 * to store temporary files that come in as results to queries to the
	 * pollers
	 */
	void handleExit()
	{
		// clear out temporary data files if any
		File	tempDir = new File(TEMP_DIR);
		
		if (tempDir.exists())
		{
			File[] tempDataFiles = tempDir.listFiles();

			for (int iIndex=0; iIndex < tempDataFiles.length; iIndex++)
			{
				tempDataFiles[iIndex].delete();
			}

			// delete directory
			tempDir.delete();
		}

		// Save User Profile
		saveUserProfile();

		// end
		dispose();
	}

	/**
	 * <pre>Handles the storing of user preferences to the user profile 
	 * file. If the write into the profile file fails, the step is retried 
	 * thrice as a minimum mechanism to offset the possiblity of a different
	 * application currently writing into the profile
	 */
	protected void saveUserProfile()
	{
		// Update the userProfile Hashtable

		// position
		Integer xpos = new Integer(getX());
		Integer ypos = new Integer(getY());

		// dimension
		Dimension frameSize = getSize();
		Integer width = new Integer(frameSize.width);
		Integer height = new Integer(frameSize.height);

		userProfile.put(XPOS, xpos);
		userProfile.put(YPOS, ypos);
		userProfile.put(WIDTH, width);
		userProfile.put(HEIGHT, height);

		// look and feel
		String landf = UIManager.getLookAndFeel().getName();
		userProfile.put(LOOKNFEEL, landf);
		
		boolean bNotWritten = true;
		int		iNumTries=0;

		while(bNotWritten && iNumTries < 3)
		{
			try
			{
				new DPControlUserProfWriter(userProfile, userID);
				bNotWritten = false;
			}
			catch (Exception e)
			{
				bNotWritten = true;
			}
			
			if (bNotWritten)
			{
				iNumTries++;

				try
				{
					Thread.sleep(300);
				}
				catch (InterruptedException ex) { }

			}
		}
	}

	/**
	 * Sets the operational tree data to show the services
	 * Also selects the first service so as to display its parameters
	 */
	void setOperationalData(Vector services)
	{
		curPollerServices = services;

		curPollerServiceIDs = getServiceIDs(curPollerServices);

		// set data in tree
		DefaultMutableTreeNode root = 
							new DefaultMutableTreeNode(curSelectedPoller);

		DefaultTreeModel treeModel = new DefaultTreeModel(root);

		int iSize = curPollerServiceIDs.size();
		for(int iIndex=0; iIndex<iSize; iIndex++)
		{
			DefaultMutableTreeNode child = 
			new DefaultMutableTreeNode(curPollerServiceIDs.elementAt(iIndex));

			treeModel.insertNodeInto(child, root, root.getChildCount());
		}

		opTree.setModel(treeModel);

		// select first service 
		opTree.setSelectionInterval(0, 0);

	}

	/**
	 * Retrieve the service ids
	 */
	Vector getServiceIDs(Vector services)
	{
		Vector serviceIds = new Vector();

		int iSize = services.size();

		for(int iIndex=0; iIndex<iSize; iIndex++)
		{
			Vector tempM = (Vector)services.elementAt(iIndex);

			Vector temp = (Vector)tempM.elementAt(0);

			String id = String.valueOf(temp.elementAt(0));
			if (id.equals(MODULENAME))
				serviceIds.add(temp.elementAt(1));
		}

		return serviceIds;
	}

	/**
	 * Set current operational data timestamp
	 */
	void setCurOpDataTimeStamp(String dateStr)
	{
		opLabel.setText("Operational Information as of " + dateStr);
	}

	public static void main(String[] args)
	{
		try
		{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		}
		catch (Exception e)
		{
			// Don't really do anything?
		}

		DPControl dpc = new DPControl();
		dpc.start("admin");
	}

}

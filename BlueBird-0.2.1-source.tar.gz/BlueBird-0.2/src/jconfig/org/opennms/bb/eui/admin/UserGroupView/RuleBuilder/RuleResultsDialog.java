//-------------------------------------------------------------------------------------------
//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

//--------------------------------------------------------------------------------------------
package org.opennms.bb.eui.admin.UserGroupView.RuleBuilder;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;
import java.util.*;
import java.util.List;

import org.opennms.bb.common.filter.BBFilter;
import org.opennms.bb.common.filter.xml.FilterSchemaParser;
import org.opennms.bb.common.filter.sql.FilterTable;
import org.opennms.bb.common.filter.util.BBIPAddress;
import org.opennms.bb.common.filter.exceptions.FailedParseException;
import org.opennms.bb.common.filter.exceptions.FailedSQLException;
import org.opennms.bb.common.db.DBOpenFailureException;

/**This class is responsible for displaying the results of
   a rule in a dialog box. It is called from the RuleBuilderMain
   class that is the screen for building rules.

   @author <A HREF="mailto:jason@opennms.org">Jason Johns</A>
   @author <A HREF="http://www.opennms.org/">OpenNMS</A>
   @version $Revision: 1.3 $
*/
public class RuleResultsDialog extends JDialog implements ActionListener
{
    /**The model for the result table
     */
    private DefaultTableModel defaultModel;
    
    /**The result table showing what the numeric and string ip addresses
       returned by the rule
     */
    private JTable table;

    /**The button to close the dialog box
     */
    private JButton closeButton;

    /**Constructor that creates a dialog with a modal type, title and a rule
       to populate the result table.
       @param boolean modal, should the dialog be modal or not
       @param String aName, the title of the dialog
       @param String aRule, rule to parse and display results
     */
    public RuleResultsDialog(boolean modal, String aName, String aRule)
    {
	//set up how the window will look and behave
	setDefaultCloseOperation(DISPOSE_ON_CLOSE);
	setModal(modal);
	setBackground(java.awt.Color.lightGray);
	setForeground(java.awt.Color.black);
	setSize(550,300);
	setTitle(aName);
	
	//set up the master pane
	Container contentPane = getContentPane();
	contentPane.setLayout(new BorderLayout());
	
	//add a text box in the top of the master pane
	JPanel rulePanel = new JPanel();
	rulePanel.setLayout(new BoxLayout(rulePanel, BoxLayout.X_AXIS));
	rulePanel.setBorder(BorderFactory.createEmptyBorder(0, 10, 10, 10));
	rulePanel.add(new JLabel("Rule: "));
	rulePanel.add(Box.createRigidArea(new Dimension(5, 0)));
	
	//show the text field at the top of the screen and disable it
	JTextField ruleText = new JTextField(aRule);
	ruleText.setEditable(false);

	rulePanel.add(ruleText);
	rulePanel.add(Box.createRigidArea(new Dimension(5,0)));
	
	contentPane.add(rulePanel, BorderLayout.NORTH);

	//add the result table to the center of the pane
	defaultModel = new DefaultTableModel();
	table = new JTable(defaultModel);
	table.setEnabled(false);
	
	contentPane.add(new JScrollPane(table, 
					JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
					JScrollPane.HORIZONTAL_SCROLLBAR_NEVER), 
			BorderLayout.CENTER);

	defaultModel.addColumn("IP Address");

	//add the close button to the bottom of the pane
	closeButton = new JButton("Close");
	closeButton.addActionListener(this);
					  
	contentPane.add(closeButton, BorderLayout.SOUTH);

	executeRule(aRule);
}

    /**This method implements the interface to the ActionListener.
       Closes the dialog upon a click in the closeButton.
       @param ActionEvent event
     */
    public void actionPerformed(ActionEvent event)
    {
	if (event.getSource() == closeButton)
	{
		dispose();
	}
    }

    /**This method executes a rule and displays the results in the
       table. If there is an error a message box will appear. 
       @param String aRule, the rule to be exectuted
     */
    private void executeRule(String aRule)
    {
	try
	{
	    List list = null;
	
	    //run the rule
	    BBFilter filter = new BBFilter();
	    
	    //get the ip list
	    list = filter.getIPList(aRule);
	    
	    Vector data = null;
	    
	    //populate the table with the results of the rule
	    for (int row = 0; row < list.size(); row++)
	    {
		data = new Vector();
		
		//we want to show the numerical address and the octet strings
		data.add(0, list.get(row));
		
		defaultModel.addRow(data);
	    }
	}
	catch(DBOpenFailureException e)
	{
	    JOptionPane.showMessageDialog(this, 
					  "Could not open the database.\n" + e.toString(),
					  "Error", 
					  JOptionPane.ERROR_MESSAGE);
	}
	catch(FailedParseException e)
	{
	    JOptionPane.showMessageDialog(this, 
					  "Rule is not valid.\n" + e.toString(),
					  "Error", 
					  JOptionPane.ERROR_MESSAGE);
	}
    }
}

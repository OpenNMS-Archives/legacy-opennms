//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
package org.opennms.bb.eui.admin.UserGroupView.Parser;

import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
import org.w3c.dom.*;

import org.opennms.bb.eui.admin.UserGroupView.Main.UserManager;

class User
{
	String _sUserId = "";
	String _sFullName = "";
	String _sUserComments = "";
	String _sPassword = "";

	public String toString()
	{
		return (_sUserId+":"+propertiesString());
	}

	public String propertiesString()
	{
		if((_sFullName == null) || (_sFullName.trim().equals("")))
		{
			_sFullName = "(unknown)";
		}
		if((_sUserComments == null) || (_sUserComments.trim().equals("")))
		{
			_sUserComments = "(none)";
		}
		return (_sPassword+":"+_sFullName+":"+_sUserComments);
	}
}

/**
 * @author Chitta Basu
 *
 * Modifications:
 * 04/18/00 - Changed the parser to account for ParserBase extending BBParser 
 *          - Sowmya
 *
 */
public class UserParser extends ParserBase
{
	static FileWriter _oFileWriter = null;

	boolean _bVersion = false;
	boolean _bMsStation = false;
	boolean _bUserId = false;
	boolean _bFullName = false;
	boolean _bUserComments = false;
	boolean _bPassword = false;

	static Vector _vUsers = new Vector();

	public UserParser()
	{
		super();
		_vUsers = new Vector();
	}

	protected boolean processElement(Element el)
	{
		if(el.getTagName().equals("ver"))
		{
			_bVersion = true;
		}
		else if(el.getTagName().equals("mstation"))
		{
			_bMsStation = true;
		}
		else if(el.getTagName().equals("user"))
		{
			_vUsers.add(new User());
		}
		else if(el.getTagName().equals("userID"))
		{
			_bUserId = true;
			_bFullName = false;
			_bUserComments = false;
			_bPassword = false;
		}
		else if(el.getTagName().equals("fullname"))
		{
			_bUserId = false;
			_bFullName = true;
			_bUserComments = false;
			_bPassword = false;
		}
		else if(el.getTagName().equals("userComments"))
		{
			_bUserId = false;
			_bFullName = false;
			_bUserComments = true;
			_bPassword = false;
		}
		else if(el.getTagName().equals("password"))
		{
			_bUserId = false;
			_bFullName = false;
			_bUserComments = false;
			_bPassword = true;
		}

		NodeList nl = el.getChildNodes();
		int size = nl.getLength();
		for(int i = 0;i < size;i++)
		{
			processNode(nl.item(i));
		}
		
		return true;
	}

	protected void processText(Text text)
	{
		String sText = text.getData();
		if(sText.trim().length() != 0)
		{
			if(_bVersion)
			{
				UserManager.m_sVersion = sText;
				_bVersion = false;
			}
			else if(_bMsStation)
			{
				UserManager.m_sMsStation = sText;
				_bMsStation = false;
			}
			else if(_bUserId)
			{
				((User)_vUsers.lastElement())._sUserId = sText;
			}
			else if(_bFullName)
			{
				((User)_vUsers.lastElement())._sFullName = sText;
			}
			else if(_bUserComments)
			{
				((User)_vUsers.lastElement())._sUserComments = sText;
			}
			else if(_bPassword)
			{
				((User)_vUsers.lastElement())._sPassword = sText;
			}
		}
	}

	public static void load(String sFile)
	{
		UserParser oParser = null;
		try
		{
			oParser = new UserParser();
			oParser.parse(sFile);
		}
		catch (IOException e)
		{
			return;
		}

		UserManager.m_oUsers.clear();
		for(Enumeration e=oParser._vUsers.elements(); e.hasMoreElements(); )
		{
			User tmp = (User)e.nextElement();
			UserManager.m_oUsers.put(tmp._sUserId, tmp.propertiesString());
		}
	}

	public static void save(String sFile) throws IOException
	{
		_oFileWriter = new FileWriter(sFile);

		_oFileWriter.write("<?xml version=\"1.0\"?>\n");
		_oFileWriter.write("<!-- <?XML-stylesheet type=\"text/xsl\" href=\"iceberg.xsl\"?> -->\n");
		_oFileWriter.write("<!DOCTYPE userinfo [\n");
		_oFileWriter.write("<!ELEMENT   userinfo        (header, users)             >\n");
		_oFileWriter.write("<!ELEMENT   header          (ver, created, mstation)    >\n");
		_oFileWriter.write("<!ELEMENT   ver             (#PCDATA)                   >\n");
		_oFileWriter.write("<!ELEMENT   mstation        (#PCDATA)                   >\n");
		_oFileWriter.write("<!ELEMENT   created         (#PCDATA)                   >\n");
		_oFileWriter.write("<!ATTLIST   created year    CDATA  #REQUIRED\n");
		_oFileWriter.write("                    month   CDATA  #REQUIRED\n");
		_oFileWriter.write("                    day	    CDATA  #REQUIRED\n");
		_oFileWriter.write("                    hour    CDATA  #REQUIRED\n");
		_oFileWriter.write("                    min	    CDATA  #REQUIRED\n");
		_oFileWriter.write("                    sec	    CDATA  #REQUIRED            >\n");
		_oFileWriter.write("<!ELEMENT   users           (user+)                     >\n");
		_oFileWriter.write("<!ELEMENT   user            (userID, fullname, userComments?, \n");
		_oFileWriter.write("                            password)                   >\n");
		_oFileWriter.write("<!ELEMENT   userID          (#PCDATA)                   >\n");
		_oFileWriter.write("<!ELEMENT   fullname        (#PCDATA)                   >\n");
		_oFileWriter.write("<!ELEMENT   userComments    (#PCDATA)                   >\n");
		_oFileWriter.write("<!ELEMENT   password        (#PCDATA)                   >\n");
		_oFileWriter.write("]>\n\n");

		_oFileWriter.write("<userinfo>\n");

		_oFileWriter.write("        <header>\n");
		{
			_oFileWriter.write("	       <ver>"+UserManager.m_sVersion+"</ver>\n");

			Calendar oCalendar = new GregorianCalendar();
			_oFileWriter.write("	       <created "
							+"year=\""+oCalendar.get(oCalendar.YEAR)
							  +"\" month=\""+(1+oCalendar.get(oCalendar.MONTH))
							  +"\" day=\""+oCalendar.get(oCalendar.DAY_OF_MONTH)
							  +"\" hour=\""+oCalendar.get(oCalendar.HOUR)
							  +"\" min=\""+oCalendar.get(oCalendar.MINUTE)
							  +"\" sec=\""+oCalendar.get(oCalendar.SECOND)
							  +"\">\n");
			_oFileWriter.write("			76625255\n");
			_oFileWriter.write("	       </created>\n");
			_oFileWriter.write("	       <mstation>"+UserManager.m_sMsStation+"</mstation>\n");
		}
		_oFileWriter.write("        </header>\n");

		_oFileWriter.write("        <users>\n");
		{
			for(Enumeration e=UserManager.m_oUsers.keys(); e.hasMoreElements(); )
			{
				_oFileWriter.write("            <user>\n");
				String sId = (String)e.nextElement();
				_oFileWriter.write("                <userID>"+sId+"</userID>\n");
				StringTokenizer oTokenizer = new StringTokenizer((String)UserManager.m_oUsers.get(sId),":");
				String sPassword = oTokenizer.nextToken();
				_oFileWriter.write("                <fullname>"+oTokenizer.nextToken()+"</fullname>\n");
				_oFileWriter.write("                <userComments>"+oTokenizer.nextToken()+"</userComments>\n");
				_oFileWriter.write("                <password>"+sPassword+"</password>\n");
				_oFileWriter.write("            </user>\n");
			}
		}
		_oFileWriter.write("	   </users>\n");

		_oFileWriter.write("</userinfo>\n");
		_oFileWriter.flush();

	}
}

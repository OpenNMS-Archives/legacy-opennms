//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.common.components;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.event.*;

/**
 * BBColumnEditor is a table cell editor that stops editing on a
 * 'focusLost' instead of the default action of having to press 'enter'
 * (activating) each cell
 *
 * <p>On 'focusLost', it warns the user if the value entered is incorrect
 * The focus is then restored to the same cell until the value entersd
 * is correct or the user presses 'escape' to restore the older correct
 * value
 *
 * @author Sowmya
 *
 */
public class BBColumnEditor extends DefaultCellEditor
{
	JTextField 	textField;

	//weird problem of focusLost() getting called twice
	static int iFocusLostCalled=0;

	public boolean bEditingCancelled=false;

	/**
	 * Creates the column editor
	 */
	public BBColumnEditor(final JTextField colText)
	{
		super(colText);

		textField = colText;

		colText.addFocusListener(new FocusAdapter()
		{
			public void focusGained(FocusEvent e)
			{
				iFocusLostCalled=0;

				bEditingCancelled=false;

				colText.selectAll();
			}

			public void focusLost(FocusEvent e)
			{
				iFocusLostCalled++;
				if (iFocusLostCalled > 1)
				{
					return;
				}

				if(colText.isValid())
				{
					stopCellEditing();
				}
				else
				{
					if (!bEditingCancelled)
					{
 						JOptionPane.showMessageDialog(
							null, 
							"\"" + colText.getText() + "\"" + " is not a valid value", 
							"Value Invalid!", 
							JOptionPane.ERROR_MESSAGE);

						
						SwingUtilities.invokeLater(new Runnable()
						{
							public void run()
							{
								colText.requestFocus();
							}
						});
					}
				}
			}
		});
	}
}


//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.operator.utils;

import java.io.*;
import java.util.Vector;
import java.util.Hashtable;
import java.util.Calendar;

import org.opennms.bb.eui.operator.components.OperatorBar;

/**
 * <pre>EUIDataRequest assembles the data request to be sent out
 * based on the current level and the next level requested
 *
 * @author Sowmya
 *
 */
public class EUIDataRequest 
{
	final String ID_SEPARATOR	= "!#";

	// xml tags/values
	final String	EUI_REQ			="<euiReq>\n";
	final String	EUI_REQ_CLS		="</euiReq>\n";

	final String	HEADER			="\t<header>\n";
	final String	HEADER_CLS		="\t</header>\n";

	final String	VER				="\t\t<ver>";
	final String	VER_CLS			="</ver>\n";

	final String	PARMS			="\t<parms>\n";
	final String	PARMS_CLS		="\t</parms>\n";

	final String	PARM			="\t\t<parm>\n";
	final String	PARM_CLS		="\t\t</parm>\n";

	final String	PARM_NAME		="\t\t\t<parmName>";
	final String	PARM_NAME_CLS	="</parmName>\n";

	final String	PARM_VALUE		="\t\t\t<value>";
	final String	PARM_VALUE_CLS	="</value>\n";

	final String	USER_ID			="userID";
	final String	VIEW			="view";
	final String	CATEGORY		="category";
	final String	NODE			="node";
	final String	DATE			="date";
	final String	TIME			="time";
	final String	DURATION		="duration";
	final String	SERVICES		="services";
	final String	SEVERITY		="severity";
	final String	NUM_NODES		="topN";

	StringBuffer	dataRequest;

	// data retrieved from the ID
	String			view	=null;
	String			category=null;
	String			node	=null;
	String			dateStr	=null;
	String			time	=null;
	String			service =null;

	String			curDate;
	String			curTime;

	public EUIDataRequest(String userID, String nextReqLevel) 
	{
		this(userID, nextReqLevel, null, null, null);
	}

	public EUIDataRequest(String userID, 
						  String nextRequestLevel, 
						  String qty,
						  String severity,
						  String curID)
	{
		dataRequest = new StringBuffer(1024);

		// first do the header
		createRequestHeader();

		// The ID has all levels traversed so far separated by ID_SEPARATOR 
		// retrive the data from the ID
		if (curID != null)
			retrieveDataFromID(curID);

		if (nextRequestLevel.equals(OperatorBar.VIEWS_LEVEL))
		{
			createViewsLevelRequest(userID);
		}

		else if (nextRequestLevel.equals(OperatorBar.CATEGORY_LEVEL))
		{
			createCategoryLevelRequest(userID);
		}

		else if (nextRequestLevel.equals(OperatorBar.DEVICES_LEVEL))
		{
			createNodeLevelRequest(userID, qty);
		}

		else if (nextRequestLevel.equals(OperatorBar.DEVICES_LEVEL))
		{
			createNodeLevelRequest(userID, qty);
		}

		else if (nextRequestLevel.equals(OperatorBar.DAILY_LEVEL))
		{
			createDayLevelRequest(userID, qty);
		}

		else if (nextRequestLevel.equals(OperatorBar.HOURLY_LEVEL))
		{
			createHourlyLevelRequest(userID, qty);
		}

		else if (nextRequestLevel.equals(OperatorBar.SERVICES_LEVEL))
		{
			createServicesLevelRequest(userID, qty);
		}

		else if (nextRequestLevel.equals(OperatorBar.EVENTS_LEVEL))
		{
			createEventsLevelRequest(userID, qty, severity);
		}
	}

	protected void createRequestHeader()
	{
		String tempBuf = new String(EUI_REQ + HEADER + VER + "1.9a" + VER_CLS);

		dataRequest.append(tempBuf);

		// get current date
		Calendar curCal = new java.util.GregorianCalendar();

		// milliseconds since Jan 1st 1970
		long ms = curCal.getTime().getTime();

		int year = curCal.get(Calendar.YEAR);
		int month = curCal.get(Calendar.MONTH) + 1;
		int day = curCal.get(Calendar.DAY_OF_MONTH);
		int hour = curCal.get(Calendar.HOUR_OF_DAY);
		int min = curCal.get(Calendar.MINUTE);
		int sec = curCal.get(Calendar.SECOND);

		StringBuffer createdDate = new StringBuffer("<created year=\""+ year +"\"");
		createdDate.append(" month=\"" +month+"\"");
		createdDate.append(" day=\"" + day + "\"");
		createdDate.append(" hour=\"" + hour +"\"");
		createdDate.append(" min=\"" + min + "\"");
		createdDate.append(" sec=\"" + sec + "\">");


		dataRequest.append("\t\t" + createdDate + "\n");
		dataRequest.append("\t\t\t" + ms + "\n");
		dataRequest.append("\t\t</created>\n");
		dataRequest.append("\t\t<mstation>master.nmanage.com</mstation>\n");
		dataRequest.append("\t</header>\n");
		
		// while at it store the current date
		java.text.SimpleDateFormat formatter =  
					new java.text.SimpleDateFormat("MMM d, yyyy");

		curDate = formatter.format(curCal.getTime());

		formatter =  new java.text.SimpleDateFormat("hh:mm aaa");
		curTime = formatter.format(curCal.getTime());
	}

	protected void retrieveDataFromID(String curID)
	{
		java.util.StringTokenizer st = 
							new java.util.StringTokenizer(curID, ID_SEPARATOR);

		// first token is the view
		if (st.hasMoreTokens())
		{
			view = st.nextToken();
		}

		// category
		if (st.hasMoreTokens())
		{
			category = st.nextToken();
		}

		// node
		if (st.hasMoreTokens())
		{
			node = st.nextToken();
		}

		// date
		if (st.hasMoreTokens())
		{
			dateStr = st.nextToken();
		}

		// time
		if (st.hasMoreTokens())
		{
			time = st.nextToken();
		}

		// service
		if (st.hasMoreTokens())
		{
			service = st.nextToken();
		}

	}

	/*
	 * Add relevant data views level request
	 */
	protected void createViewsLevelRequest(String userID)
	{
		dataRequest.append("\t<request target=\"views\"/>\n");

		dataRequest.append(PARMS);

		dataRequest.append(PARM + 
							PARM_NAME + USER_ID + PARM_NAME_CLS +
							PARM_VALUE + userID + PARM_VALUE_CLS +
							PARM_CLS);

		dataRequest.append(PARMS_CLS + EUI_REQ_CLS);
		
	}

	/*
	 * Add relevant data for category level request
	 */
	protected void createCategoryLevelRequest(String userID)
	{
		dataRequest.append("\t<request target=\"categories\"/>\n");

		dataRequest.append(PARMS);

		dataRequest.append(PARM + 
							PARM_NAME + USER_ID + PARM_NAME_CLS +
							PARM_VALUE + userID + PARM_VALUE_CLS +
							PARM_CLS);

		dataRequest.append( PARM + 
							PARM_NAME + VIEW + PARM_NAME_CLS +
							PARM_VALUE + view + PARM_VALUE_CLS +
							PARM_CLS);

		dataRequest.append(PARMS_CLS + EUI_REQ_CLS);
		
	}

	/*
	 * Add relevant data for node/device level request
	 */
	protected void createNodeLevelRequest(String userID, String qty)
	{
		dataRequest.append("\t<request target=\"nodes\"/>\n");

		dataRequest.append(PARMS);

		dataRequest.append(PARM + 
							PARM_NAME + USER_ID + PARM_NAME_CLS +
							PARM_VALUE + userID + PARM_VALUE_CLS +
							PARM_CLS);

		dataRequest.append( PARM + 
							PARM_NAME + VIEW + PARM_NAME_CLS +
							PARM_VALUE + view + PARM_VALUE_CLS +
							PARM_CLS);

		dataRequest.append(PARM + 
							PARM_NAME + CATEGORY + PARM_NAME_CLS +
							PARM_VALUE + category + PARM_VALUE_CLS +
							PARM_CLS);

		dataRequest.append(PARM + 
							PARM_NAME + NUM_NODES + PARM_NAME_CLS +
							PARM_VALUE + qty + PARM_VALUE_CLS +
							PARM_CLS);

		dataRequest.append(PARMS_CLS + EUI_REQ_CLS);
		
	}

	/*
	 * Add relevant data for day level request
	 */
	protected void createDayLevelRequest(String userID, String qty)
	{
		dataRequest.append("\t<request target=\"days\"/>\n");

		dataRequest.append(PARMS);

		dataRequest.append(PARM + 
							PARM_NAME + USER_ID + PARM_NAME_CLS +
							PARM_VALUE + userID + PARM_VALUE_CLS +
							PARM_CLS);

		dataRequest.append( PARM + 
							PARM_NAME + VIEW + PARM_NAME_CLS +
							PARM_VALUE + view + PARM_VALUE_CLS +
							PARM_CLS);

		dataRequest.append(PARM + 
							PARM_NAME + CATEGORY + PARM_NAME_CLS +
							PARM_VALUE + category + PARM_VALUE_CLS +
							PARM_CLS);

		/** eventually will have date - for now add cur date **/
		dataRequest.append(PARM + 
							PARM_NAME + DATE + PARM_NAME_CLS +
							PARM_VALUE + curDate + PARM_VALUE_CLS +
							PARM_CLS);

		dataRequest.append(PARM + 
							PARM_NAME + DURATION + PARM_NAME_CLS +
							PARM_VALUE + qty + PARM_VALUE_CLS +
							PARM_CLS);

		dataRequest.append(PARMS_CLS + EUI_REQ_CLS);
		
	}


	/*
	 * Add relevant data for hourly level request
	 */
	protected void createHourlyLevelRequest(String userID, String qty)
	{
		dataRequest.append("\t<request target=\"hours\"/>\n");

		dataRequest.append(PARMS);

		dataRequest.append(PARM + 
							PARM_NAME + USER_ID + PARM_NAME_CLS +
							PARM_VALUE + userID + PARM_VALUE_CLS +
							PARM_CLS);

		dataRequest.append( PARM + 
							PARM_NAME + VIEW + PARM_NAME_CLS +
							PARM_VALUE + view + PARM_VALUE_CLS +
							PARM_CLS);

		dataRequest.append(PARM + 
							PARM_NAME + CATEGORY + PARM_NAME_CLS +
							PARM_VALUE + category + PARM_VALUE_CLS +
							PARM_CLS);

		dataRequest.append(PARM + 
							PARM_NAME + NODE + PARM_NAME_CLS +
							PARM_VALUE + node + PARM_VALUE_CLS +
							PARM_CLS);

		if (dateStr == null)
			dateStr = curDate;

		dataRequest.append(PARM + 
							PARM_NAME + DATE + PARM_NAME_CLS +
							PARM_VALUE + dateStr + PARM_VALUE_CLS +
							PARM_CLS);

		dataRequest.append(PARM + 
							PARM_NAME + DURATION + PARM_NAME_CLS +
							PARM_VALUE + qty + PARM_VALUE_CLS +
							PARM_CLS);

		dataRequest.append(PARMS_CLS + EUI_REQ_CLS);
		
	}

	/*
	 * Add relevant data for services level request
	 */
	protected void createServicesLevelRequest(String userID, String qty)
	{
		dataRequest.append("\t<request target=\"services\"/>\n");

		dataRequest.append(PARMS);

		dataRequest.append(PARM + 
							PARM_NAME + USER_ID + PARM_NAME_CLS +
							PARM_VALUE + userID + PARM_VALUE_CLS +
							PARM_CLS);

		dataRequest.append( PARM + 
							PARM_NAME + VIEW + PARM_NAME_CLS +
							PARM_VALUE + view + PARM_VALUE_CLS +
							PARM_CLS);

		dataRequest.append(PARM + 
							PARM_NAME + CATEGORY + PARM_NAME_CLS +
							PARM_VALUE + category + PARM_VALUE_CLS +
							PARM_CLS);

		dataRequest.append(PARM + 
							PARM_NAME + NODE + PARM_NAME_CLS +
							PARM_VALUE + node + PARM_VALUE_CLS +
							PARM_CLS);

		if (dateStr == null)
			dateStr = curDate;

		dataRequest.append(PARM + 
							PARM_NAME + DATE + PARM_NAME_CLS +
							PARM_VALUE + dateStr + PARM_VALUE_CLS +
							PARM_CLS);


		if (time == null)
			time = curTime;

		dataRequest.append(PARM + 
							PARM_NAME + TIME + PARM_NAME_CLS +
							PARM_VALUE + time + PARM_VALUE_CLS +
							PARM_CLS);

		if ( qty == null)
			qty = new String("All");

		dataRequest.append(PARM + 
								PARM_NAME + DURATION + PARM_NAME_CLS +
								PARM_VALUE + qty + PARM_VALUE_CLS +
								PARM_CLS);

		dataRequest.append(PARMS_CLS + EUI_REQ_CLS);
		
	}

	/*
	 * Add relevant data for events level request
	 */
	protected void createEventsLevelRequest(String userID, String qty, 
																String severity)
	{
		dataRequest.append("\t<request target=\"events\"/>\n");

		dataRequest.append(PARMS);

		dataRequest.append(PARM + 
							PARM_NAME + USER_ID + PARM_NAME_CLS +
							PARM_VALUE + userID + PARM_VALUE_CLS +
							PARM_CLS);

		dataRequest.append( PARM + 
							PARM_NAME + VIEW + PARM_NAME_CLS +
							PARM_VALUE + view + PARM_VALUE_CLS +
							PARM_CLS);

		if (category == null)
			category = new String("All");

		dataRequest.append(PARM + 
							PARM_NAME + CATEGORY + PARM_NAME_CLS +
							PARM_VALUE + category + PARM_VALUE_CLS +
							PARM_CLS);

		if (node == null)
			node = new String("All");

		dataRequest.append(PARM + 
							PARM_NAME + NODE + PARM_NAME_CLS +
							PARM_VALUE + node + PARM_VALUE_CLS +
							PARM_CLS);

		if (dateStr == null)
			dateStr = curDate;

		dataRequest.append(PARM + 
							PARM_NAME + DATE + PARM_NAME_CLS +
							PARM_VALUE + dateStr + PARM_VALUE_CLS +
							PARM_CLS);

		if (time == null)
			time = curTime;

		dataRequest.append(PARM + 
							PARM_NAME + TIME + PARM_NAME_CLS +
							PARM_VALUE + time + PARM_VALUE_CLS +
							PARM_CLS);


		if (service == null)
			service = new String("All");

		dataRequest.append(PARM + 
							PARM_NAME + SERVICES + PARM_NAME_CLS +
							PARM_VALUE + service + PARM_VALUE_CLS +
							PARM_CLS);

		if (severity == null)
			severity = new String("All");

		dataRequest.append(PARM + 
							PARM_NAME + SEVERITY + PARM_NAME_CLS +
							PARM_VALUE + severity + PARM_VALUE_CLS +
							PARM_CLS);

		if ( qty == null)
			qty = new String("All");

		dataRequest.append(PARM + 
								PARM_NAME + DURATION + PARM_NAME_CLS +
								PARM_VALUE + qty + PARM_VALUE_CLS +
								PARM_CLS);

		dataRequest.append(PARMS_CLS + EUI_REQ_CLS);
		
	}
	
	/**
	 * Return the data request buffer
	 */
	public String getDataRequestBuffer()
	{
		//System.out.println(dataRequest);
		return dataRequest.toString();
	}
}

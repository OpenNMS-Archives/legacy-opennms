//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
package org.opennms.bb.eui.admin.UserGroupView.RuleBuilder;

import java.util.Vector;
import java.util.Enumeration;
import java.util.StringTokenizer;
import java.util.NoSuchElementException;
import javax.swing.JTabbedPane;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.tree.*;
import java.awt.dnd.*;

import java.awt.*;
import java.awt.event.*;

import org.opennms.bb.eui.common.components.AboutDialog;
import org.opennms.bb.eui.admin.UserGroupView.Main.UserManager;
import org.opennms.bb.eui.admin.UserGroupView.Parser.ViewParser;

/**
 * @author Chitta
 *
 * Modifications:
 * Changed the deprecated 'getComponentAtIndex(int i)' method of 'JPopupMenu'
 * to 'getComponent(int i)' for the move to JDK 1.3 - Sowmya
 */
public class RuleBuilderMain extends JDialog
{
    String		m_sViewName	      = null;
    RuleDragDropTree	m_oCustomTree	      = null;
    RuleDragTree	m_oTemplateTree	      = null;
    JTabbedPane		m_oTabbedPane	      = new JTabbedPane();
    JTextField		m_oStatusText	      = new JTextField();
    TreeSelectionModel	m_oSelectionModel     = null;
    JPopupMenu		m_oPopup	      = null;
    JPopupMenu		m_oPopupTab	      = null;
    MouseListener	m_oPopupListener      = new PopupListener();
    
    GridBagLayout	m_oGridBag	      = new GridBagLayout();
    GridBagConstraints	m_oGridBagConstraints = new GridBagConstraints();
    
    public void update(Graphics g)
    {
	((DefaultTreeCellRenderer)m_oCustomTree.getCellRenderer()).setBackground(java.awt.Color.lightGray);
	((DefaultTreeCellRenderer)m_oCustomTree.getCellRenderer()).setBackgroundNonSelectionColor(java.awt.Color.lightGray);
	((DefaultTreeCellRenderer)m_oTemplateTree.getCellRenderer()).setBackground(java.awt.Color.lightGray);
	((DefaultTreeCellRenderer)m_oTemplateTree.getCellRenderer()).setBackgroundNonSelectionColor(java.awt.Color.lightGray);
	
	super.update(g);
    }
    
    public RuleBuilderMain(JFrame oParent, boolean bModal, String sView)
    {
	super(oParent, bModal);
	setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
	
	if(sView!=null &&!(sView.trim().equals("")))
	{
	    m_sViewName = sView;
	}
	//setSize(550,532);
	getContentPane().setLayout(m_oGridBag);
	
	addWindowListener(new WindowAdapter()
	    { 
		public void windowClosing(WindowEvent e)
		{
		    if(UserManager.m_bRuleUpdated)
		    {
			String sSlash = System.getProperty("file.separator");
			String sMsg = "Rule configurations have not been saved. Save now?";
			int optVal = JOptionPane.showConfirmDialog(RuleBuilderMain.this.getContentPane(),
								   sMsg,
								   "Save Rule Configuration...",
								   JOptionPane.YES_NO_OPTION,
								   JOptionPane.WARNING_MESSAGE,
								   new ImageIcon("data/images/lightbulb.gif"));
			if(optVal==JOptionPane.YES_OPTION)
			{
			    if(!checkThresholds())
			    {
				return;
			    }
			    save();
			    dispose();
			}
			else if(optVal==JOptionPane.NO_OPTION)
			{
			    UserManager.m_bRuleUpdated = false;
			    dispose();
			}
		    }
		    else if(UserManager.m_bFigureUpdated)
		    {
			String sSlash = System.getProperty("file.separator");
			String sMsg = "Are you sure you want to abort the current editing session?";
			int optVal = JOptionPane.showConfirmDialog(RuleBuilderMain.this.getContentPane(),
								   sMsg,
								   "Abort Rule Configuration?",
								   JOptionPane.YES_NO_OPTION,
								   JOptionPane.WARNING_MESSAGE,
								   new ImageIcon("data/images/lightbulb.gif"));
			if(optVal==JOptionPane.YES_OPTION)
			{
			    dispose();
			}
		    }
		    else
		    {
			dispose();
		    }
		}
	    });
	
	addTabbedPane();
	addMenuBar();
	addStatusBar();
	
	loadCustomRules();
	loadTemplateRules();
	
	addPopupMenu();
	
	addKeyListener( new KeyAdapter()
	    {
		public void keyPressed(KeyEvent e)
		{
		    if(e.getKeyCode() == KeyEvent.VK_DELETE)
		    {
			cut();
		    }
		}
	    });
	
	m_oSelectionModel = m_oCustomTree.getSelectionModel();
	m_oCustomTree.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
	m_oTemplateTree.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
	
	m_oCustomTree.addTreeSelectionListener(new TreeSelectionListener()
	    {
		public void valueChanged(TreeSelectionEvent e)
		{
		    if( m_oSelectionModel != m_oCustomTree.getSelectionModel())
		    {
			m_oSelectionModel.clearSelection();
			m_oSelectionModel	= m_oCustomTree.getSelectionModel();
		    }
		}
	    });
	
	m_oTemplateTree.addTreeSelectionListener(new TreeSelectionListener()
	    {
		public void valueChanged(TreeSelectionEvent e)
		{
		    if( m_oSelectionModel != m_oTemplateTree.getSelectionModel())
		    {
			m_oSelectionModel.clearSelection();
			m_oSelectionModel	= m_oTemplateTree.getSelectionModel();
		    }
		}
	    });
	
	setSize(550,532);
	setResizable(true);
	setTitle("View Rule Builder");
    }
    
    class PopupListener extends MouseAdapter implements ActionListener
    {
	private int x = -1,
	            y = -1;
	
	private Object m_oSource = null;
	
	public void actionPerformed(ActionEvent e)
	{
	    if(e.getActionCommand().equals("Cut"))
	    {
		cut();
	    }
	    else if(e.getActionCommand().equals("Copy"))
	    {
		copy();
	    }
	    else if(e.getActionCommand().equals("Paste"))
	    {
		paste();
	    }
	    else if(e.getActionCommand().equals("Modify"))
	    {
		TreePath oPath =  m_oSelectionModel.getSelectionPath();
		if(oPath.getPathCount() < 1)
		{
		    return;
		}
				
		//if(m_oSelectionModel == m_oCustomTree.getSelectionModel())
		if(m_oSource == m_oCustomTree)
		{
		    m_oCustomTree.setEditable(true);
		    m_oCustomTree.startEditingAtPath(oPath);
		}
		//else if(m_oSelectionModel == m_oTemplateTree.getSelectionModel())
		else if(m_oSource == m_oTemplateTree)
		{
		    m_oTemplateTree.setEditable(true);
		    m_oTemplateTree.startEditingAtPath(oPath);
		}
	    }
	    else if(e.getActionCommand().equals("AddTab"))
	    {
		m_oTabbedPane.addTab("Category "+m_oTabbedPane.getTabCount(), null, newTabPanel("Type your text rule here"), "New Panel");
		UserManager.m_bRuleUpdated = true;
	    }
	    else if(e.getActionCommand().equals("RemoveTab"))
	    {
		if(m_oTabbedPane.getSelectedIndex() == 0)
		{
		    setStatus("Can't remove common category.");
		    Toolkit.getDefaultToolkit().beep();
		    return;
		}
		String sMsg = "Are you sure you want to delete ";
		sMsg += m_oTabbedPane.getTitleAt(m_oTabbedPane.getSelectedIndex());
		sMsg += "?";
		String sSlash = System.getProperty("file.separator");
		int optVal = JOptionPane.showConfirmDialog(RuleBuilderMain.this.getContentPane(),
							   sMsg,
							   "Confirm delete "+m_oTabbedPane.getTitleAt(m_oTabbedPane.getSelectedIndex())+"...",
							   JOptionPane.YES_NO_OPTION,
							   JOptionPane.WARNING_MESSAGE,
							   new ImageIcon("data/images/lightbulb.gif"));
		if(optVal == 0)
		{
		    m_oTabbedPane.removeTabAt(m_oTabbedPane.getSelectedIndex());
		    m_oTabbedPane.repaint();
		    UserManager.m_bRuleUpdated = true;
		}
	    }
	    else if(e.getActionCommand().equals("RenameTab"))
	    {
		if(m_oTabbedPane.getSelectedIndex() == 0)
		{
		    setStatus("Can't rename common category.");
		    Toolkit.getDefaultToolkit().beep();
		    return;
		}
		String sTemp = (String)JOptionPane.showInputDialog(RuleBuilderMain.this.getContentPane(),
								   "Changed name:",
								   "Rename "+m_oTabbedPane.getTitleAt(m_oTabbedPane.getSelectedIndex())+" to...",
								   JOptionPane.QUESTION_MESSAGE,
								   null,
								   null,
								   m_oTabbedPane.getTitleAt(m_oTabbedPane.getSelectedIndex()));
		if((sTemp!=null) && (!(sTemp=sTemp.trim()).equals("")))
		{
		    m_oTabbedPane.setTitleAt(m_oTabbedPane.getSelectedIndex(),
					     sTemp);
		    m_oTabbedPane.repaint();
		    UserManager.m_bRuleUpdated = true;
		}
	    }
	}
	
	public void mousePressed(MouseEvent e)
	{
	    if(m_oCustomTree.isEditable())
	    {
		if(m_oCustomTree.isEditing())
		{
		    m_oCustomTree.stopEditing();
		}
		m_oCustomTree.setEditable(false);
	    }
	    else if(m_oTemplateTree.isEditable())
	    {
		if(m_oTemplateTree.isEditing())
		{
		    m_oTemplateTree.stopEditing();
		}
		m_oTemplateTree.setEditable(false);
	    }
	    popupAction(e);
	}
	
	public void mouseReleased(MouseEvent e)
	{
	    popupAction(e);
	}
	
	void popupAction(MouseEvent e)
	{
	    if (e.isPopupTrigger())
	    {
		Point					pLocation	= new Point(e.getX(),e.getY());
		boolean					bPopup = false;
		
		if(e.getSource() == m_oTabbedPane)
		{
		    if(m_oTabbedPane.getSelectedIndex()==0)
		    {
			m_oPopupTab.getComponent(1).setEnabled(false);
			m_oPopupTab.getComponent(2).setEnabled(false);
		    }
		    else
		    {
			m_oPopupTab.getComponent(1).setEnabled(true);
			m_oPopupTab.getComponent(2).setEnabled(true);
		    }
		    m_oPopupTab.show((Component)e.getSource(),
				     e.getX(),
				     e.getY());
		}
		else if(e.getSource() == m_oCustomTree)
		{
		    m_oSource = m_oCustomTree;
		    DefaultMutableTreeNode	oTreeNode = m_oCustomTree.getTreeNode(pLocation);
		    if(oTreeNode != null)
		    {
			bPopup = true;
			((DefaultTreeSelectionModel)m_oCustomTree.getSelectionModel()).clearSelection();
			((DefaultTreeSelectionModel)m_oCustomTree.getSelectionModel()).setSelectionPath(new TreePath(oTreeNode.getPath()));
		    }
		}
		else if(e.getSource() == m_oTemplateTree)
		{
		    m_oSource = m_oTemplateTree;
		    DefaultMutableTreeNode	oTreeNode = m_oTemplateTree.getTreeNode(pLocation);
		    if(oTreeNode != null)
		    {
			bPopup = true;
			((DefaultTreeSelectionModel)m_oTemplateTree.getSelectionModel()).clearSelection();
			((DefaultTreeSelectionModel)m_oTemplateTree.getSelectionModel()).setSelectionPath(new TreePath(oTreeNode.getPath()));
		    }
		}
		
		if(bPopup)
		{
		    x = e.getX();
		    y = e.getY();
		    m_oSource = e.getSource();
		    if(UserManager.m_sEditBuffer == null)
		    {
			m_oPopup.getComponent(2).setEnabled(false);
		    }
		    else
		    {
			m_oPopup.getComponent(2).setEnabled(true);
		    }
		    m_oPopup.show((Component)e.getSource(),
				  e.getX(),
				  e.getY());
		}
	    }
	}
    }
    
    protected Component newTabPanel(String sText)
    {
	RuleCategoryPanel oDrawPanel= new RuleCategoryPanel(sText);
	oDrawPanel.setBounds(1,1,422,295);
	oDrawPanel.init();
	
	return oDrawPanel;
    }
    
    private void addTabbedPane()
    {
	String sBuffer = null;
	if(m_sViewName!=null)
	{
	    sBuffer = (String)UserManager.m_oRules.get(m_sViewName);
	}


	if(sBuffer == null)
	{
	    sBuffer = "Common$Type your text rule here..%";
	}
	
	StringTokenizer oTokenizer = new StringTokenizer(sBuffer,"%");
	String sTok = null;
	while(oTokenizer.hasMoreTokens())
	{
	    try
	    {
		sTok = oTokenizer.nextToken();
		if((sTok!=null) && !(sTok.trim().equals("")) )
		{
		    int iCutOff = sTok.indexOf('$');
		    int iLength = sTok.length();
		    String sLabel = sTok.substring(0,iCutOff);
		    m_oTabbedPane.addTab(sLabel,
					 null,
					 newTabPanel(sTok.substring(iCutOff+1,iLength)),
					 sLabel+" Category"
					 );
		}
	    } catch(NoSuchElementException  exc) {}
	}
	
	m_oTabbedPane.setSelectedIndex(0);
	
	/*
	 * Add the tabbed pane to this panel:
	 */
	//getContentPane().setLayout(null); 
	m_oGridBagConstraints.fill = GridBagConstraints.BOTH;
	m_oGridBagConstraints.weightx = 1.0;
	m_oGridBagConstraints.weighty = 0.9;
	m_oGridBagConstraints.gridx = 0;
	m_oGridBagConstraints.gridy = 2;
	m_oGridBagConstraints.gridwidth = 2;
	m_oGridBagConstraints.ipady = 0;
	m_oGridBagConstraints.insets = new Insets(8,0,0,0);
	m_oGridBag.setConstraints(m_oTabbedPane, m_oGridBagConstraints);
	getContentPane().add(m_oTabbedPane);
	
	/*
	 * Create the popup menu.
	 */
	JMenuItem oMenuItem;
	m_oPopupTab = new JPopupMenu();
	
	oMenuItem = new JMenuItem("Add a category");
	oMenuItem.setActionCommand("AddTab");
	oMenuItem.addActionListener((ActionListener)m_oPopupListener);
	m_oPopupTab.add(oMenuItem);
	oMenuItem = new JMenuItem("Remove this category");
	oMenuItem.setActionCommand("RemoveTab");
	oMenuItem.addActionListener((ActionListener)m_oPopupListener);
	m_oPopupTab.add(oMenuItem);
	oMenuItem = new JMenuItem("Rename..");
	oMenuItem.setActionCommand("RenameTab");
	oMenuItem.addActionListener((ActionListener)m_oPopupListener);
	m_oPopupTab.add(oMenuItem);
	
	/*
	 * Add listener to components that can bring up popup menus.
	 */
	m_oTabbedPane.addMouseListener(m_oPopupListener);
    }
    
    public void dragEnter(DropTargetDragEvent e)
    {
	e.acceptDrag(DnDConstants.ACTION_COPY_OR_MOVE);
    }
    
    public void dragExit(DropTargetEvent e)
    {
    }
    
    public void dragOver(DropTargetDragEvent e)
    {
	e.acceptDrag(DnDConstants.ACTION_COPY_OR_MOVE);
    }
    
    public void dropActionChanged(DropTargetDragEvent e)
    {
	e.acceptDrag(DnDConstants.ACTION_COPY_OR_MOVE);
    }
    
    private void addMenuBar()
    {
	JMenuBar  oMainMenuBar	 = new JMenuBar();
	JMenu 	  oFileMenu	 = new JMenu();
	JMenu	  oEditMenu	 = new JMenu();
	JMenu	  oHelpMenu	 = new JMenu();
	JMenu	  oViewMenu	 = new JMenu();
	JMenu	  oLnFMenu	 = new JMenu();
	JMenuItem oSaveMenuItem	 = new JMenuItem();
	JMenuItem oExitMenuItem	 = new JMenuItem();
	JMenuItem oCutMenuItem	 = new JMenuItem();
	JMenuItem oCopyMenuItem	 = new JMenuItem();
	JMenuItem oPasteMenuItem = new JMenuItem();
	JMenuItem oLnFSubMenu1	 = new JMenuItem();
	JMenuItem oLnFSubMenu2	 = new JMenuItem();
	JMenuItem oLnFSubMenu3	 = new JMenuItem();
	JMenuItem oAboutMenuItem = new JMenuItem();
	
	oFileMenu.setText("File");
	oFileMenu.setMnemonic('F');
	oMainMenuBar.add(oFileMenu);
	oSaveMenuItem.setText("Save");
	oSaveMenuItem.setActionCommand("Save");
	oSaveMenuItem.setMnemonic('S');
	oFileMenu.add(oSaveMenuItem);
	oSaveMenuItem.addActionListener(new MenuBarListener());
	oExitMenuItem.setText("Checkout");
	oExitMenuItem.setActionCommand("Close");
	oExitMenuItem.setMnemonic('e');
	oFileMenu.add(oExitMenuItem);
	oExitMenuItem.addActionListener(new MenuBarListener());
	oEditMenu.setText("Edit");
	oEditMenu.setMnemonic('E');
	oMainMenuBar.add(oEditMenu);
	oCutMenuItem.setText("Cut");
	oCutMenuItem.setActionCommand("Cut");
	oCutMenuItem.setMnemonic('C');
	oCutMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X,Event.CTRL_MASK ));
	oEditMenu.add(oCutMenuItem);
	oCutMenuItem.addActionListener(new MenuBarListener());
	oCopyMenuItem.setText("Copy");
	oCopyMenuItem.setActionCommand("Copy");
	oCopyMenuItem.setMnemonic('o');
	oCopyMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C,Event.CTRL_MASK ));
	oEditMenu.add(oCopyMenuItem);
	oCopyMenuItem.addActionListener(new MenuBarListener());
	oPasteMenuItem.setText("Paste");
	oPasteMenuItem.setActionCommand("Paste");
	oPasteMenuItem.setMnemonic('P');
	oPasteMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_V,Event.CTRL_MASK ));
	oEditMenu.add(oPasteMenuItem);
	oPasteMenuItem.addActionListener(new MenuBarListener());
	
	oViewMenu.setText("View");
	oViewMenu.setActionCommand("View");
	oViewMenu.setMnemonic('V');
	oMainMenuBar.add(oViewMenu);
	
	oLnFMenu.setText("Look and Feel");
	oLnFMenu.setActionCommand("LnF");
	oLnFMenu.setMnemonic('L');
	oViewMenu.add(oLnFMenu);
	
	oLnFSubMenu1.setText("Metal");
	oLnFSubMenu1.setActionCommand("Metal");
	oLnFSubMenu1.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_J,Event.CTRL_MASK ));
	oLnFMenu.add(oLnFSubMenu1);
	oLnFSubMenu1.addActionListener(new MenuBarListener());
	
	oLnFSubMenu2.setText("Motif");
	oLnFSubMenu2.setActionCommand("Motif");
	oLnFSubMenu2.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_M,Event.CTRL_MASK ));
	oLnFMenu.add(oLnFSubMenu2);
	oLnFSubMenu2.addActionListener(new MenuBarListener());
	
	oLnFSubMenu3.setText("Windows");
	oLnFSubMenu3.setActionCommand("Windows");
	oLnFSubMenu3.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_W,Event.CTRL_MASK ));
	oLnFMenu.add(oLnFSubMenu3);
	oLnFSubMenu3.addActionListener(new MenuBarListener());
	
	oHelpMenu.setText("Help");
	oHelpMenu.setMnemonic('H');
	oMainMenuBar.add(oHelpMenu);
	oHelpMenu.add(oAboutMenuItem);
	oAboutMenuItem.addActionListener(new MenuBarListener());
	oAboutMenuItem.setText("About...");
	oAboutMenuItem.setActionCommand("About");
	oAboutMenuItem.setMnemonic('A');
	oMainMenuBar.setBorder(BorderFactory.createEtchedBorder());
	
	setJMenuBar(oMainMenuBar);
    }
    
    class MenuBarListener implements ActionListener
    {
	public void actionPerformed(ActionEvent e)
	{
	    if(e.getActionCommand().equals("Save"))
	    {
		if(!checkThresholds())
		{
		    return;
		}
		save();
	    }
	    else if(e.getActionCommand().equals("Close"))
	    {
		if(UserManager.m_bRuleUpdated)
		{
		    String sMsg = "Configured rules have not been saved. Save now?";
		    String sSlash = System.getProperty("file.separator");
		    int optVal = JOptionPane.showConfirmDialog(RuleBuilderMain.this.getContentPane(),
							       sMsg,
							       "Save Rule Configuration...",
							       JOptionPane.YES_NO_OPTION,
							       JOptionPane.WARNING_MESSAGE,
							       new ImageIcon("data/images/lightbulb.gif"));
		    if(optVal==JOptionPane.YES_OPTION)
		    {
			if(!checkThresholds())
			{
			    return;
			}
			save();
			dispose();
		    }
		    else if(optVal==JOptionPane.NO_OPTION)
		    {
			UserManager.m_bRuleUpdated = false;
			dispose();
		    }
		}
		else if(UserManager.m_bFigureUpdated)
		{
		    String sSlash = System.getProperty("file.separator");
		    String sMsg = "Are you sure you want to abort the current editing session?";
		    int optVal = JOptionPane.showConfirmDialog(RuleBuilderMain.this.getContentPane(),
							       sMsg,
							       "Abort Rule Configuration?",
							       JOptionPane.YES_NO_OPTION,
							       JOptionPane.WARNING_MESSAGE,
							       new ImageIcon("data/images/lightbulb.gif"));
		    if(optVal==JOptionPane.YES_OPTION)
		    {
			dispose();
		    }
		}
		else
		{
		    dispose();
		}
	    }
	    else if(e.getActionCommand().equals("Cut"))
	    {
		cut();
	    }
	    else if(e.getActionCommand().equals("Copy"))
	    {
		copy();
	    }
	    else if(e.getActionCommand().equals("Paste"))
	    {
		paste();
	    }
	    else if(e.getActionCommand().equals("About"))
	    {
		new AboutDialog((JFrame)getParent(), "Help About..");
	    }
	    else
	    {
		org.opennms.bb.eui.admin.utils.LnF.setLookAndFeel(e.getActionCommand());
		SwingUtilities.updateComponentTreeUI(RuleBuilderMain.this);
	    }
	}
    }
    
    private void loadCustomRules()
    {
	JLabel oCustomLabel = new JLabel();
	
	m_oGridBagConstraints.fill = GridBagConstraints.HORIZONTAL;
	m_oGridBagConstraints.weightx = 0.5;
	m_oGridBagConstraints.weighty = 0;
	m_oGridBagConstraints.gridx = 0;
	m_oGridBagConstraints.gridy = 0;
	m_oGridBagConstraints.gridwidth = 1;
	m_oGridBagConstraints.ipadx = 10;
	m_oGridBagConstraints.ipady = 0;
	m_oGridBagConstraints.anchor = GridBagConstraints.WEST;
	m_oGridBagConstraints.insets = new Insets(8,0,0,4);
	m_oGridBag.setConstraints(oCustomLabel, m_oGridBagConstraints);
	getContentPane().add(oCustomLabel);
	
	oCustomLabel.setText("Custom Rules");
	oCustomLabel.setHorizontalAlignment(JTextField.CENTER);
	oCustomLabel.setFont(new Font("Dialog", Font.BOLD, 10));
	//oCustomLabel.setBounds(1,1,270,18);
	oCustomLabel.setBorder(BorderFactory.createLoweredBevelBorder());
	
	DefaultMutableTreeNode	oRoot = new DefaultMutableTreeNode("CUSTOM");
	{
	    DefaultMutableTreeNode tmp = new DefaultMutableTreeNode("IP Information");
	    tmp.add(new DefaultMutableTreeNode("IPAddr IPLIKE 199.72.52.*"));
	    tmp.add(new DefaultMutableTreeNode("IPAddr IPLIKE 199.72.52.128-255"));
	    tmp.add(new DefaultMutableTreeNode("IPHostName ~ ws%52"));
	    oRoot.add(tmp);
	}
	{
	    DefaultMutableTreeNode tmp = new DefaultMutableTreeNode("Interface Information");
	    tmp.add(new DefaultMutableTreeNode("IFType == 6"));
	    tmp.add(new DefaultMutableTreeNode("IFType == 22"));
	    oRoot.add(tmp);
	}
	{
	    DefaultMutableTreeNode tmp = new DefaultMutableTreeNode("SNMP Information");
	    tmp.add(new DefaultMutableTreeNode("SNMPsysDescr ~ 'bay'"));
	    tmp.add(new DefaultMutableTreeNode("SNMPsysCon ~ 'sally jones'"));
	    tmp.add(new DefaultMutableTreeNode("SNMPsysCon ~ 'bob adams'"));
	    tmp.add(new DefaultMutableTreeNode("SNMPsysOID ~ '.1.3.6.1.4.1.11.2.3.%'"));
	    tmp.add(new DefaultMutableTreeNode("SNMPsysLoc ~ 'east coast'"));
	    tmp.add(new DefaultMutableTreeNode("SNMPsysName ~ 'router'"));
	    oRoot.add(tmp);
	}
	{
	    DefaultMutableTreeNode tmp = new DefaultMutableTreeNode("Miscellaneous");
	    oRoot.add(tmp);
	}
	
	m_oCustomTree = new RuleDragDropTree(oRoot);
	m_oCustomTree.setRootVisible(false);
	m_oCustomTree.setEditable(false);
	m_oCustomTree.setBorder(BorderFactory.createLoweredBevelBorder());
	
	m_oCustomTree.setBackground(java.awt.Color.lightGray);
	JScrollPane oCustomScrollPane = new JScrollPane(m_oCustomTree,
							JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
							JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED );
	
	((DefaultTreeCellRenderer)m_oCustomTree.getCellRenderer()).setBackground(java.awt.Color.lightGray);
	((DefaultTreeCellRenderer)m_oCustomTree.getCellRenderer()).setBackgroundNonSelectionColor(java.awt.Color.lightGray);
	//oCustomScrollPane.setPreferredSize(new Dimension(270,80));
	//oCustomScrollPane.setBounds(1,19,270,80);
	
	m_oGridBagConstraints.fill = GridBagConstraints.BOTH;
	m_oGridBagConstraints.weightx = 0.5;
	m_oGridBagConstraints.weighty = 0.1;
	m_oGridBagConstraints.gridx = 0;
	m_oGridBagConstraints.gridy = 1;
	m_oGridBagConstraints.gridwidth = 1;
	m_oGridBagConstraints.ipady = 60;
	m_oGridBagConstraints.insets = new Insets(0,0,0,4);
	m_oGridBag.setConstraints(oCustomScrollPane, m_oGridBagConstraints);
	getContentPane().add(oCustomScrollPane);
	m_oGridBagConstraints.insets = new Insets(0,0,0,0);
	//m_oCustomTree.getModel().addTreeModelListener(m_oTreeModelListener);
    }
    
    private void loadTemplateRules()
    {
	JLabel oTemplateLabel = new JLabel();
	
	m_oGridBagConstraints.fill = GridBagConstraints.HORIZONTAL;
	m_oGridBagConstraints.weightx = 0.5;
	m_oGridBagConstraints.weighty = 0;
	m_oGridBagConstraints.gridx = 1;
	m_oGridBagConstraints.gridy = 0;
	m_oGridBagConstraints.gridwidth = 1;
	m_oGridBagConstraints.ipadx = 0;
	m_oGridBagConstraints.ipady = 0;
	m_oGridBagConstraints.anchor = GridBagConstraints.EAST;
	m_oGridBagConstraints.insets = new Insets(8,4,0,0);
	m_oGridBag.setConstraints(oTemplateLabel, m_oGridBagConstraints);
	getContentPane().add(oTemplateLabel);
	
	oTemplateLabel.setText("Template Rules");
	oTemplateLabel.setHorizontalAlignment(JTextField.CENTER);
	oTemplateLabel.setFont(new Font("Dialog", Font.BOLD, 10));
	//oTemplateLabel.setBounds(271,1,270,18);
	oTemplateLabel.setBorder(BorderFactory.createLoweredBevelBorder());
	
	DefaultMutableTreeNode	oRoot = new DefaultMutableTreeNode("TEMPLATE");
	{
	    DefaultMutableTreeNode tmp = new DefaultMutableTreeNode("IP Information");
	    tmp.add(new DefaultMutableTreeNode("IPAddr IPLIKE *.*.*.*"));
	    tmp.add(new DefaultMutableTreeNode("IPHostName ~ ''"));
	    oRoot.add(tmp);
	}
	{
	    DefaultMutableTreeNode tmp = new DefaultMutableTreeNode("Interface Information");
	    tmp.add(new DefaultMutableTreeNode("IFType == X"));
	    oRoot.add(tmp);
	}
	{
	    DefaultMutableTreeNode tmp = new DefaultMutableTreeNode("SNMP Information");
	    tmp.add(new DefaultMutableTreeNode("SNMPsysDescr ~ ''"));
	    tmp.add(new DefaultMutableTreeNode("SNMPsysCon ~ ''"));
	    tmp.add(new DefaultMutableTreeNode("SNMPsysCon ~ ''"));
	    tmp.add(new DefaultMutableTreeNode("SNMPsysOID ~ '.1.3.6.1.4.1.%'"));
	    tmp.add(new DefaultMutableTreeNode("SNMPsysLoc ~ ''"));
	    tmp.add(new DefaultMutableTreeNode("SNMPsysName ~ ''"));
	    oRoot.add(tmp);
	}
	{
	    DefaultMutableTreeNode tmp = new DefaultMutableTreeNode("Miscellaneous");
	    oRoot.add(tmp);
	}
	
	m_oTemplateTree = new RuleDragTree(oRoot);
	m_oTemplateTree.setRootVisible(false);
	m_oTemplateTree.setEditable(false);
	m_oTemplateTree.setBorder(BorderFactory.createLoweredBevelBorder());
	
	m_oTemplateTree.setBackground(java.awt.Color.lightGray);
	JScrollPane oTemplateScrollPane	= new JScrollPane(m_oTemplateTree,
							  JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
							  JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED );
	((DefaultTreeCellRenderer)m_oTemplateTree.getCellRenderer()).setBackground(java.awt.Color.lightGray);
	((DefaultTreeCellRenderer)m_oTemplateTree.getCellRenderer()).setBackgroundNonSelectionColor(java.awt.Color.lightGray);
	oTemplateScrollPane.setPreferredSize(new Dimension(270,80));
	//oTemplateScrollPane.setBounds(271,19,270,80);
	
	m_oGridBagConstraints.fill = GridBagConstraints.BOTH;
	m_oGridBagConstraints.weightx = 0.5;
	m_oGridBagConstraints.weighty = 0.1;
	m_oGridBagConstraints.gridx = 1;
	m_oGridBagConstraints.gridy = 1;
	m_oGridBagConstraints.gridwidth = 1;
	m_oGridBagConstraints.ipady = 60;
	m_oGridBagConstraints.insets = new Insets(0,4,0,0);
	m_oGridBag.setConstraints(oTemplateScrollPane, m_oGridBagConstraints);
	getContentPane().add(oTemplateScrollPane);
	m_oGridBagConstraints.insets = new Insets(0,0,0,0);
	
	//m_oTemplateTree.getModel().addTreeModelListener(m_oTreeModelListener);
    }
    
    private void addStatusBar()
    {
	/*
	  JPanel		oStatusBar		= new JPanel();
	  getContentPane().add(oStatusBar);
	  oStatusBar.setFont(new Font("Dialog", Font.PLAIN, 10));
	  oStatusBar.setBounds(0,460,541,18);
	  oStatusBar.setBorder(BorderFactory.createLoweredBevelBorder());
	  oStatusBar.setAlignmentX(LEFT_ALIGNMENT);
	  oStatusBar.setAlignmentY(TOP_ALIGNMENT);
	*/
	m_oGridBagConstraints.fill = GridBagConstraints.HORIZONTAL;
	m_oGridBagConstraints.weightx = 1.0;
	m_oGridBagConstraints.weighty = 0;
	m_oGridBagConstraints.gridx = 0;
	m_oGridBagConstraints.gridy = 3;
	m_oGridBagConstraints.gridwidth = 2;
	m_oGridBagConstraints.anchor = GridBagConstraints.SOUTH;
	m_oGridBagConstraints.insets = new Insets(8,0,0,0);
	m_oGridBagConstraints.ipadx = 0;
	m_oGridBagConstraints.ipady = 0;
	m_oGridBag.setConstraints(m_oStatusText, m_oGridBagConstraints);
	getContentPane().add(m_oStatusText);
	
	m_oStatusText.setEditable(false);
	m_oStatusText.setHorizontalAlignment(JTextField.LEFT);
	m_oStatusText.setBorder(BorderFactory.createLoweredBevelBorder());
	m_oStatusText.setFont(new Font("Courier", Font.BOLD, 9));
	//m_oStatusText.setBounds(1,462,536,12);
	/*
	  oStatusBar.add(m_oStatusText);
	  oStatusBar.setLayout(new BorderLayout());
	  oStatusBar.add(m_oStatusText, BorderLayout.NORTH);
	*/
	setStatus("Ready");
    }
    
    private void setStatus(String msg)
    {
	m_oStatusText.setBackground(java.awt.Color.lightGray);
	m_oStatusText.setForeground(java.awt.Color.black);
	m_oStatusText.setText(msg);
    }
    
    void addPopupMenu()
    {
	/*
	 * Create the popup menu.
	 */
	JMenuItem oMenuItem;
	m_oPopup = new JPopupMenu();
	
	oMenuItem = new JMenuItem("Cut");
	oMenuItem.setActionCommand("Cut");
	oMenuItem.addActionListener((ActionListener)m_oPopupListener);
	m_oPopup.add(oMenuItem);
	oMenuItem = new JMenuItem("Copy");
	oMenuItem.setActionCommand("Copy");
	oMenuItem.addActionListener((ActionListener)m_oPopupListener);
	m_oPopup.add(oMenuItem);
	oMenuItem = new JMenuItem("Paste");
	oMenuItem.setActionCommand("Paste");
	oMenuItem.addActionListener((ActionListener)m_oPopupListener);
	m_oPopup.add(oMenuItem);
	oMenuItem = new JMenuItem("Modify..");
	oMenuItem.setActionCommand("Modify");
	oMenuItem.addActionListener((ActionListener)m_oPopupListener);
	m_oPopup.add(oMenuItem);
	
	/*
	 * Add listener to components that can bring up popup menus.
	 */
	m_oCustomTree.addMouseListener(m_oPopupListener);
	m_oTemplateTree.addMouseListener(m_oPopupListener);
    }

	    float loVal  = 0;
	    float hiVal  = 0;
	    Vector loTabVal = null;
	    Vector hiTabVal = null;

    boolean checkThresholds()
    {
	for(int i=0;i<m_oTabbedPane.getTabCount();i++)
	{
	    RuleCategoryPanel ref = (RuleCategoryPanel)m_oTabbedPane.getComponentAt(i);
	    try
	    {
		loVal  = (Float.valueOf(ref.m_oLowThreshold.getText())).floatValue();
	    }
	    catch(Exception e)
	    {
		String sMsg = "In category \""+m_oTabbedPane.getTitleAt(i)+"\", ";
		sMsg += "lower threshold must be a number between 0.0-100.0.";
		JOptionPane.showMessageDialog(RuleBuilderMain.this.getContentPane(),
					      sMsg,
					      "Attention!",
					      JOptionPane.WARNING_MESSAGE);
		return false;
	    }
	    try
	    {
		hiVal  = (Float.valueOf(ref.m_oHighThreshold.getText())).floatValue();
	    }
	    catch(Exception e)
	    {
		String sMsg = "In category \""+m_oTabbedPane.getTitleAt(i)+"\", ";
		sMsg += "higher threshold must be a number between 0.0-100.0.";
		JOptionPane.showMessageDialog(RuleBuilderMain.this.getContentPane(),
					      sMsg,
					      "Attention!",
					      JOptionPane.WARNING_MESSAGE);
		return false;
	    }
	    
	    if(loVal > hiVal)
	    {
		String sMsg = "In category \""+m_oTabbedPane.getTitleAt(i)+"\", ";
		sMsg += "the lower threshold must be a lower number than the higher threshold!";
		JOptionPane.showMessageDialog(RuleBuilderMain.this.getContentPane(),
					      sMsg,
					      "Attention!",
					      JOptionPane.WARNING_MESSAGE);
		return false;
	    }
	}

	return true;
    }
    
    void save()
    {

	String sBuffer = "";
	for(int i=0;i<m_oTabbedPane.getTabCount();i++)
	{
	    RuleCategoryPanel ref = (RuleCategoryPanel)m_oTabbedPane.getComponentAt(i);
	    loVal  = (Float.valueOf(ref.m_oLowThreshold.getText())).floatValue();
	    hiVal  = (Float.valueOf(ref.m_oHighThreshold.getText())).floatValue();

	    sBuffer += m_oTabbedPane.getTitleAt(i)
		+"$" + loVal + "$" + hiVal + "$"
		+((RuleCategoryPanel)m_oTabbedPane.getComponentAt(i)).m_oRule.getText()
		+"%";
	}
	UserManager.m_oRules.remove(m_sViewName);
	UserManager.m_oRules.put(m_sViewName, sBuffer);
	try
	{
	    String sSlash = System.getProperty("file.separator");
	    ViewParser.save("data" + sSlash + "common" + sSlash + "conf" + sSlash + "views.xml");
	}
	catch(Exception e)
	{
	    System.err.println("I/O error opening file for writing!");
	}
	
	UserManager.m_bRuleUpdated = false;
    }
    
    void cut()
    {
	try
	{
	    TreePath oPath =  m_oSelectionModel.getSelectionPath();
	    if(oPath.getPathCount() < 1)
	    {
		return;
	    }
	    DefaultMutableTreeNode oNode	= (DefaultMutableTreeNode)oPath.getLastPathComponent();
	    DefaultMutableTreeNode oParent	= (DefaultMutableTreeNode)oNode.getParent();
	    UserManager.m_sEditBuffer = oNode.toString();
	    DefaultTreeModel oTreeModel = null;
	    if(oParent.isRoot())
	    {
		UserManager.m_sEditBuffer = null;
		setStatus("Can't cut "+oNode.toString());
		Toolkit.getDefaultToolkit().beep();
		return;
	    }
	    if(m_oSelectionModel == m_oCustomTree.getSelectionModel())
	    {
		oTreeModel = (DefaultTreeModel)m_oCustomTree.getModel();
	    }
	    else if(m_oSelectionModel == m_oTemplateTree.getSelectionModel())
	    {
		oTreeModel = (DefaultTreeModel)m_oTemplateTree.getModel();
	    }
	    oTreeModel.removeNodeFromParent(oNode);
	    oTreeModel.reload(oParent);
	}
	catch(Exception e)
	{
	    setStatus("Must select a node first.");
	    Toolkit.getDefaultToolkit().beep();
	}
    }
    
    void copy()
    {
	try
	{
	    TreePath oPath =  m_oSelectionModel.getSelectionPath();
	    if(oPath.getPathCount() < 1)
	    {
		return;
	    }
	    DefaultMutableTreeNode oNode = (DefaultMutableTreeNode)oPath.getLastPathComponent();
	    DefaultMutableTreeNode oParent = (DefaultMutableTreeNode)oNode.getParent();
	    UserManager.m_sEditBuffer = oNode.toString();
	    DefaultTreeModel oTreeModel = null;
	    if(oParent.isRoot())
	    {
		UserManager.m_sEditBuffer = null;
		setStatus("Can't copy "+oNode.toString());
		Toolkit.getDefaultToolkit().beep();
		return;
	    }
	}
	catch(Exception e)
	{
	    setStatus("Must select a node first.");
	    Toolkit.getDefaultToolkit().beep();
	}
    }
    
    void paste()
    {
	if(UserManager.m_sEditBuffer != null)
	{
	    try
	    {
		TreePath oPath =  m_oSelectionModel.getSelectionPath();
		if(oPath == null || oPath.getPathCount() < 1)
		{
		    return;
		}
		DefaultMutableTreeNode oNode	= (DefaultMutableTreeNode)oPath.getLastPathComponent();
		if(!((DefaultMutableTreeNode)oNode.getParent()).isRoot())
		{
		    UserManager.m_sEditBuffer = null;
		    setStatus("Can't paste "+UserManager.m_sEditBuffer+" onto "+oNode.toString());
		    Toolkit.getDefaultToolkit().beep();
		    return;
		}
		DefaultTreeModel oTreeModel = null;
		if(m_oSelectionModel == m_oCustomTree.getSelectionModel())
		{
		    oTreeModel = (DefaultTreeModel)m_oCustomTree.getModel();
		}
		else if(m_oSelectionModel == m_oTemplateTree.getSelectionModel())
		{
		    oTreeModel = (DefaultTreeModel)m_oTemplateTree.getModel();
		}
		Enumeration en=oNode.children();
		for(; en.hasMoreElements();)
		{
		    if(en.nextElement().toString().equals(UserManager.m_sEditBuffer))
		    {
			setStatus("Node "+UserManager.m_sEditBuffer+" is already assigned to "+oNode.toString());
			Toolkit.getDefaultToolkit().beep();
			return;
		    }
		}
		oTreeModel.insertNodeInto(new DefaultMutableTreeNode(UserManager.m_sEditBuffer),
					  oNode,
					  oNode.getChildCount());
		if(oNode.getChildCount()<=1)
		{
		    oTreeModel.reload(oNode);
		}
		UserManager.m_sEditBuffer = null;
	    }
	    catch(Exception e)
	    {
		setStatus("Must select a node first.");
		Toolkit.getDefaultToolkit().beep();
	    }
	    UserManager.m_sEditBuffer = null;
	}
	else
	{
	    setStatus("Can't paste: Clip board empty");
	    Toolkit.getDefaultToolkit().beep();
	}
    }
}

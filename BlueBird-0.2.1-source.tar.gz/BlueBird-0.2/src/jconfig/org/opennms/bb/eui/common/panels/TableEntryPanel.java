//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.common.panels;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;

import java.util.Vector;

import org.opennms.bb.eui.common.components.*;

/**
 * <pre>TableEntryPanel 
 * - creates/holds a BBEntryTable
 * - keeps track of changes to the table model
 * - provides wrapper methods around the BBEntryTable methods for ease
 *   of use </pre>
 *
 * @author Sowmya
 *
 */
public class TableEntryPanel extends BBScrollPane 
{
	protected BBEntryTable infoTable;

	boolean	bTableDataChanged=false;

	final static int TABLE_WIDTH   = 400;
	final static int TABLE_HEIGHT  = 200;

	protected void createTable(Vector rowData, Vector colNames)
	{
		//Create the table
		infoTable = new  BBEntryTable(rowData, colNames);

		setViewportView(infoTable);

	}

	public TableEntryPanel(Vector rowData, Vector colNames)
	{
		createTable(rowData, colNames);

		Dimension preferredPanelSize = getPreferredSize();
		setMaximumSize(preferredPanelSize);
		setPreferredSize(preferredPanelSize);

		// Keep track of changes to the table data model
		infoTable.getTableModel().addTableModelListener(new TableModelListener()
		{
			public void tableChanged(TableModelEvent e)
			{
				handleTableChanges(e.getColumn());
			}
		});

	}

	void handleTableChanges(int column)
	{
		if (column != 0) // Don't consider the arrow row
			bTableDataChanged=true;
	}

	/**
 	 * Sets focus to value column of the first row
 	 */
	public boolean initialFocus()
	{
		clearSelection();
		return ((BBEntryTable)infoTable).setInitialFocus();
	}

	public boolean validateValues(String panelName)
	{
		return ((BBEntryTable)infoTable).validateValues(panelName);
	}

	public JTable getTable()
	{
		return (BBEntryTable)infoTable;
	}

	public DefaultTableModel getTableModel()
	{
		return ((BBEntryTable)getTable()).getTableModel();
	}

	public boolean isTableChanged()
	{
		return bTableDataChanged;
	}

	public void setTableSaved()
	{
		bTableDataChanged=false;
	}

	public Vector getTableColumns()
	{
		return infoTable.getColumns();
	}

	public Vector getTableData()
	{
		return infoTable.getData();
	}

	public void clearSelection()
	{
		infoTable.requestFocus();
		infoTable.clearSelection();
	}

	public void selectCellAt(int row, int col)
	{
		infoTable.selectCellAt(row, col);
	}
 }

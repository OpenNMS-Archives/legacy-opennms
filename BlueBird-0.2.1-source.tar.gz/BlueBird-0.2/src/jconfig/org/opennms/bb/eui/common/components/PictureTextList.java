//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.common.components;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

import java.util.Vector;

public class PictureTextList extends JList
{
	public PictureTextList(Vector icons, Vector values)
	{
		super();
		
		setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

		setSelectionBackground(new Color(0, 0, 128));
		setSelectionForeground(Color.white);
		
		setModel(new PictureTextListModel(icons, values));
		setCellRenderer(new PictureTextListCellRenderer());

		setBackground(Color.white);
	}
}

class PictureTextListCellRenderer extends JLabel implements ListCellRenderer 
{
	private Border 
		lineBorder = BorderFactory.createLineBorder(Color.black, 2),
		emptyBorder = BorderFactory.createEmptyBorder(2,2,2,2);

	public PictureTextListCellRenderer() 
	{
		setOpaque(true);
	}

	public Component getListCellRendererComponent(
							JList list,
							Object value,
							int index,
							boolean isSelected,
							boolean cellHasFocus) 
	{
		PictureTextListModel model = (PictureTextListModel)list.getModel();

		setText(model.getName(value));
		setIcon(model.getIcon(value));

		if(isSelected) 
		{
			setForeground(list.getSelectionForeground());
			setBackground(list.getSelectionBackground());
		}
		else 
		{
			setForeground(list.getForeground());
			setBackground(list.getBackground());
		}

		if(cellHasFocus) 
			setBorder(lineBorder);
		else 			 
			setBorder(emptyBorder);

		return this;
	}
}


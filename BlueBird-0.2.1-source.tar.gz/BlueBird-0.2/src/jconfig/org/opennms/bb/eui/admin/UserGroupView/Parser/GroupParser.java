//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
package org.opennms.bb.eui.admin.UserGroupView.Parser;

import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
import org.w3c.dom.*;
import javax.swing.tree.DefaultMutableTreeNode;

import org.opennms.bb.eui.admin.UserGroupView.Main.UserManager;
import org.opennms.bb.eui.admin.UserGroupView.UserGroupViewMain;

class Group
{
	String _sGroupName = "";
	String _sGroupComments = "";
	Vector _vUsers = new Vector();

	public String toString()
	{
		return (_sGroupName+":"+propertiesString());
	}

	public String propertiesString()
	{
		int iSize = _vUsers.size();
		if((_sGroupComments == null) || (_sGroupComments.trim().equals("")))
		{
			_sGroupComments = "(none)";
		}
		String sProperties = _sGroupComments+":";

		for(int i = 0; i<iSize; i++)
		{
			sProperties += (String)_vUsers.get(i)+":";
		}
		return (sProperties);
	}
}

/**
 * @author Chitta Basu
 *
 * Modifications:
 * 04/18/00 - Changed the parser to account for ParserBase extending BBParser 
 *          - Sowmya
 *
 */
public class GroupParser extends ParserBase
{
	static FileWriter _oFileWriter = null;

	boolean _bGroupName = false;
	boolean _bGroupComments = false;
	boolean _bUserId = false;

	static Vector _vGroups = new Vector();

	public GroupParser()
	{
		super();
		_vGroups = new Vector();
	}

	protected boolean processElement(Element el)
	{
		if(el.getTagName().equals("group"))
		{
			_vGroups.add(new Group());
		}
		else if(el.getTagName().equals("groupname"))
		{
			_bGroupName = true;
			_bGroupComments = false;
			_bUserId = false;
		}
		else if(el.getTagName().equals("groupComments"))
		{
			_bGroupName = false;
			_bGroupComments = true;
			_bUserId = false;
		}
		else if(el.getTagName().equals("userID"))
		{
			_bGroupName = false;
			_bGroupComments = false;
			_bUserId = true;
		}

		NodeList nl = el.getChildNodes();
		int size = nl.getLength();
		for(int i = 0;i < size;i++)
		{
			processNode(nl.item(i));
		}
		
		return true;
	}

	protected void processText(Text text)
	{
		String sText = text.getData();
		if(sText.trim().length() != 0)
		{
			if(_bGroupName)
			{
				((Group)_vGroups.lastElement())._sGroupName = sText;
			}
			else if(_bGroupComments)
			{
				((Group)_vGroups.lastElement())._sGroupComments = sText;
			}
			else if(_bUserId)
			{
				((Group)_vGroups.lastElement())._vUsers.add(sText);
			}
		}
	}

	public static void load(String sFile)
	{
		GroupParser oParser = null;
		try
		{
			oParser = new GroupParser();
			oParser.parse(sFile);
		}
		catch (IOException e)
		{
			return;
		}

		UserManager.m_oGroups.clear();
		for(Enumeration e=oParser._vGroups.elements(); e.hasMoreElements(); )
		{
			Group tmp = (Group)e.nextElement();
			UserManager.m_oGroups.put(tmp._sGroupName, tmp.propertiesString());
		}
	}

	public static void save(String sFile) throws IOException
	{
		_oFileWriter = new FileWriter(sFile);

		_oFileWriter.write("<?xml version=\"1.0\"?>\n");
		_oFileWriter.write("<!-- <?XML-stylesheet type=\"text/xsl\" href=\"iceberg.xsl\"?> -->\n");
		_oFileWriter.write("<!DOCTYPE groupinfo [\n");
		_oFileWriter.write("<!ELEMENT   groupinfo       (header, groups)            >\n");
		_oFileWriter.write("<!ELEMENT   header          (ver, created, mstation)    >\n");
		_oFileWriter.write("<!ELEMENT   ver             (#PCDATA)                   >\n");
		_oFileWriter.write("<!ELEMENT   mstation        (#PCDATA)                   >\n");
		_oFileWriter.write("<!ELEMENT   created         (#PCDATA)                   >\n");
		_oFileWriter.write("<!ATTLIST   created year    CDATA  #REQUIRED\n");
		_oFileWriter.write("                    month   CDATA  #REQUIRED\n");
		_oFileWriter.write("                    day	    CDATA  #REQUIRED\n");
		_oFileWriter.write("                    hour    CDATA  #REQUIRED\n");
		_oFileWriter.write("                    min	    CDATA  #REQUIRED\n");
		_oFileWriter.write("                    sec	    CDATA  #REQUIRED            >\n");
		_oFileWriter.write("<!ELEMENT   groups          (group+)                    >\n");
		_oFileWriter.write("<!ELEMENT   group           (groupname, groupComments?,  \n");
		_oFileWriter.write("                            usermembers?)               >\n");
		_oFileWriter.write("<!ELEMENT   groupname       (#PCDATA)                   >\n");
		_oFileWriter.write("<!ELEMENT   groupComments   (#PCDATA)                   >\n");
		_oFileWriter.write("<!ELEMENT   usermembers     (userID+)                   >\n");
		_oFileWriter.write("<!ELEMENT   userID          (#PCDATA)                   >\n");
		_oFileWriter.write("]>\n\n");

		_oFileWriter.write("<groupinfo>\n");

		_oFileWriter.write("        <header>\n");
		{
			_oFileWriter.write("	       <ver>"+UserManager.m_sVersion+"</ver>\n");

			Calendar oCalendar = new GregorianCalendar();
			_oFileWriter.write("	       <created "
							+"year=\""+oCalendar.get(oCalendar.YEAR)
							  +"\" month=\""+(1+oCalendar.get(oCalendar.MONTH))
							  +"\" day=\""+oCalendar.get(oCalendar.DAY_OF_MONTH)
							  +"\" hour=\""+oCalendar.get(oCalendar.HOUR)
							  +"\" min=\""+oCalendar.get(oCalendar.MINUTE)
							  +"\" sec=\""+oCalendar.get(oCalendar.SECOND)
							  +"\">\n");
			_oFileWriter.write("			76625255\n");
			_oFileWriter.write("	       </created>\n");
			_oFileWriter.write("	       <mstation>"+UserManager.m_sMsStation+"</mstation>\n");
		}
		_oFileWriter.write("        </header>\n");

		_oFileWriter.write("        <groups>\n");
		{
			for(Enumeration e=UserManager.m_oGroups.keys(); e.hasMoreElements(); )
			{
				_oFileWriter.write("            <group>\n");
				String sId = (String)e.nextElement();

				_oFileWriter.write("                <groupname>"+sId+"</groupname>\n");
				StringTokenizer oTokenizer = new StringTokenizer((String)UserManager.m_oGroups.get(sId),":");
				_oFileWriter.write("                <groupComments>"+oTokenizer.nextToken()+"</groupComments>\n");

				DefaultMutableTreeNode oGroups	= (DefaultMutableTreeNode)UserGroupViewMain.m_oGroupsTree.getModel().getRoot();
				if(!oGroups.isLeaf())
				{
					DefaultMutableTreeNode tmp = null;
					for(Enumeration en=oGroups.children(); en.hasMoreElements(); )
					{
						tmp = (DefaultMutableTreeNode)en.nextElement();
						if(sId.equals(tmp.toString()))
						{
							break;
						}
						tmp = null;
					}
					if((tmp!=null) && !tmp.isLeaf())
					{
						_oFileWriter.write("                <usermembers>\n");
						for(Enumeration en2=tmp.children(); en2.hasMoreElements(); )
						{
							_oFileWriter.write("                    <userID>"+((DefaultMutableTreeNode)en2.nextElement()).toString()+"</userID>\n");
						}
						_oFileWriter.write("                </usermembers>\n");
					}
				}
				_oFileWriter.write("            </group>\n");
			}
		}
		_oFileWriter.write("	   </groups>\n");

		_oFileWriter.write("</groupinfo>\n");
		_oFileWriter.flush();

	}
}

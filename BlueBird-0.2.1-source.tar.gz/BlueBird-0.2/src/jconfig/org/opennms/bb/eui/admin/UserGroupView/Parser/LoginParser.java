//
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
// Tab Stop = 8
//
// $Id: LoginParser.java,v 1.1 2000/10/28 17:15:35 shaneo Exp $
//

package org.opennms.bb.eui.admin.UserGroupView.Parser;

import org.w3c.dom.*;

import java.io.*;
import java.net.*;
import java.util.*;

import org.opennms.bb.common.utils.BBParser;

/**
 * <pre> LoginParser parses the 'users.xml' to get 
 * users information for BlueBird
 *
 * It throws an IOException if the xml file is not found or if it does not
 * conform to its DTD </pre>
 *
 * @author Vishwa
 *
 */

public class LoginParser extends BBParser
{
	/**
	* Table of all users and passwords
	*/
	private Hashtable		m_users;

	/**
	 * XML TAGS that are relevant
	 */
	private static final String USERID		= "userID";
	private static final String PASSWORD		= "password";

	private static final String USERINFO		= "userinfo";
	private static final String USERS		= "users";
	private static final String USER		= "user";

	protected boolean processElement(Element el, boolean isRoot)
	{
		boolean bRet = false;

		Node curNode = (Node)el;

		String tag = el.getTagName();

		if (tag.equals(USER))
		{
			m_curElement.replace(0, m_curElement.length(), USER);
			bRet = processUser(el);
			bRet = true;			
		}

		else if (tag.equals(USERS))
		{
			boolean bNodeRet = true;
			NodeList nl = el.getChildNodes();
			int size    = nl.getLength();

			for(int i = 0;i < size && bNodeRet ;i++)
			{
				bNodeRet = processNode(nl.item(i));
				if(bNodeRet == false)
					break;
			}
			bRet = bNodeRet;
		}
		else if (tag.equals(USERINFO))
		{
			boolean bNodeRet = true;
			NodeList nl = el.getChildNodes();
			int size    = nl.getLength();

			for(int i = 0;i < size && bNodeRet ;i++)
			{
				bNodeRet = processNode(nl.item(i));
				if(bNodeRet == false)
					break;
			}
			bRet = bNodeRet;
		}
		else
		{
			boolean bNodeRet=true;

			NodeList nl = el.getChildNodes();
			int size = nl.getLength();

			for(int i = 0;i < size && bNodeRet ;i++)
				bNodeRet = processNode(nl.item(i));
			bRet = bNodeRet;
		}
		return bRet;
	}

	protected boolean processUser(Element userNode)
	{
		boolean bRet = true;

		String user = null;
		String password = null;

		NodeList nl = userNode.getChildNodes();
		int size = nl.getLength();

		for(int i = 0;i < size && bRet;i++)
		{
			Node curNode = nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();

				if(curTag.equals(USERID))
				{
					user = processParmValue(curNode);
				}

				else if(curTag.equals(PASSWORD))
				{
					password = processParmValue(curNode);
				}

				if(user != null && password != null)
				{
					m_users.put(user, password);
					user = null;
					password = null;
				}
			}
		}
		return bRet;
	}
	
	/**
 	 * Parses from the filename passed in
 	 */
	public LoginParser()
	{
		m_users = new Hashtable();
	}

	/**
	 * List of all users and corresponding passwords stored in this object that exist in 'users.xml'
	 */
	public Hashtable getUsers()
	{
		return m_users;
	}
}

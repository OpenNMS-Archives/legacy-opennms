//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
package org.opennms.bb.eui.admin.UserGroupView.Wizard;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.util.Vector;
import java.util.Enumeration;

import org.opennms.bb.eui.admin.UserGroupView.Main.UserManager;

/**
 * @author Chitta Basu
 *
 * Modifications:
 * 05/19/00 - Fixed bug related to adding null values when no item
 *            is selected and the '>>' or '<<' is clicked
 *            The buttons are now selected/deselected according to the
 *            list that is currently selected
 *          - Sowmya
 *
 * 10/18/00 - Changed AWT 'List's to Swing 'JList's
 *          - Sowmya
 *
 */
public class AddUserWizard3 extends JDialog
{

	public static Vector m_oGroups	= new Vector();

	//java.awt.List m_oAssignedList = new java.awt.List(0,true);
	//java.awt.List m_oAssignedList = new java.awt.List(0);
	//java.awt.List m_oAvailabilityList = new java.awt.List(0);

	DefaultListModel m_oAssignedListModel = new DefaultListModel();
	DefaultListModel m_oAvailabilityListModel = new DefaultListModel();

	JList m_oAssignedList = new JList(m_oAssignedListModel);
	JList m_oAvailabilityList = new JList(m_oAvailabilityListModel);

	JButton m_oNextButton = new JButton();
	JButton m_oCancelButton = new JButton();
	JButton m_oBackButton = new JButton();
	JButton m_oAssignButton = new JButton();
	JButton m_oDeassignButton = new JButton();
    
	public AddUserWizard3(JFrame parent, boolean modal)
	{
		super(parent, modal);

		JLabel oDescriptionLabel	= new JLabel();
		JLabel oAvailablityLabel	= new JLabel();
		JLabel oAssignmentLabel		= new JLabel();

		getContentPane().setLayout(null);
		setBackground(java.awt.Color.lightGray);
		setSize(468,350);
		setVisible(false);

		oDescriptionLabel.setText(
				    "Choose the User Group(s) for "+UserManager.m_sNewId
		);
		getContentPane().add(oDescriptionLabel);
		oDescriptionLabel.setBounds(5,12,336,24);
		m_oNextButton.setText("Next >");
		m_oNextButton.setBounds(191,312,85,25);
		m_oCancelButton.setText("Cancel");
		m_oCancelButton.setBounds(293,312,85,25);

		m_oGroups.clear();
		for(Enumeration en=UserManager.m_oGroups.keys(); en.hasMoreElements(); )
		{
			m_oAvailabilityListModel.addElement((String)en.nextElement());
		}

		m_oAvailabilityList.setVisibleRowCount(10);

		JScrollPane avScrollPane = new JScrollPane(m_oAvailabilityList);
		avScrollPane.setBounds(5,72,200,214);
		oAvailablityLabel.setText("Available User Groups");

		m_oAssignedList.setVisibleRowCount(10);

		JScrollPane asScrollPane = new JScrollPane(m_oAssignedList);
		asScrollPane.setBounds(260,72,200,214);

		getContentPane().add(avScrollPane);
		getContentPane().add(m_oAssignButton);
		getContentPane().add(asScrollPane);
		getContentPane().add(m_oDeassignButton);

		getContentPane().add(m_oNextButton);
		getContentPane().add(m_oCancelButton);
		getContentPane().add(m_oBackButton);

		getContentPane().add(oAvailablityLabel);
		oAvailablityLabel.setBounds(5,48,180,24);
		oAssignmentLabel.setText("Group(s) assigned to "+UserManager.m_sNewId);
		getContentPane().add(oAssignmentLabel);
		oAssignmentLabel.setBounds(260,48,204,24);
		m_oBackButton.setText("< Back");
		m_oBackButton.setBounds(90,312,85,25);
		m_oAssignButton.setText(">>");
		m_oAssignButton.setBounds(210,72,48,25);
		m_oDeassignButton.setText("<<");
		m_oDeassignButton.setBounds(210,108,48,25);
		setTitle("New User Wizard Part 3");
		setResizable(false);

		SymWindow oSymWindow = new SymWindow();
		this.addWindowListener(oSymWindow);

		SymAction oSymAction = new SymAction();
		m_oNextButton.addActionListener(oSymAction);
		m_oBackButton.addActionListener(oSymAction);
		m_oCancelButton.addActionListener(oSymAction);
		m_oAssignButton.addActionListener(oSymAction);
		m_oDeassignButton.addActionListener(oSymAction);

		
		// list listeners
		m_oAvailabilityList.addListSelectionListener(new ListSelectionListener()
		{
			public void valueChanged(ListSelectionEvent avListEvent)
			{
				JList lsm = (JList)avListEvent.getSource();
	
				if(lsm.isSelectionEmpty())
					return;
	
				m_oAssignButton.setEnabled(true);
				m_oDeassignButton.setEnabled(false);
				
				m_oAssignedList.clearSelection();
			}
		});

		m_oAssignedList.addListSelectionListener(new ListSelectionListener()
		{
			public void valueChanged(ListSelectionEvent avListEvent)
			{
				JList lsm = (JList)avListEvent.getSource();

				if(lsm.isSelectionEmpty())
					return;

				m_oDeassignButton.setEnabled(true);
				m_oAssignButton.setEnabled(false);
			
				m_oAvailabilityList.clearSelection();
			}
		});

		// Initialize
		if (m_oAvailabilityListModel.getSize() != 0)
			m_oAvailabilityList.setSelectedIndex(0);

		m_oDeassignButton.setEnabled(false);
	}
    
	public AddUserWizard3(JFrame parent, String title, boolean modal)
	{
		this(parent, modal);
		setTitle(title);
	}

	public void addNotify()
	{
        Dimension d = getSize();
		super.addNotify();
		if (m_bComponentsAdjusted)
		{
			return;
		}

		Insets insets = getInsets();
		setSize(insets.left + insets.right + d.width, insets.top + insets.bottom + d.height);
		Component components[] = getComponents();
		for (int i = 0; i < components.length; i++)
		{
			Point p = components[i].getLocation();
			p.translate(insets.left, insets.top);
			components[i].setLocation(p);
		}

		m_bComponentsAdjusted = true;
	}

	public void setVisible(boolean b)
	{
	    if (b)
	    {
    		Rectangle bounds = getParent().getBounds();
    		Rectangle abounds = getBounds();

    		setLocation(bounds.x + (bounds.width - abounds.width)/ 2,
    			 bounds.y + (bounds.height - abounds.height)/2);
	    }

		super.setVisible(b);
	}

    /*
	 * Used for addNotify check.
	 */
	boolean m_bComponentsAdjusted = false;

	class SymAction implements java.awt.event.ActionListener
	{
		public void actionPerformed(java.awt.event.ActionEvent event)
		{
			Object object = event.getSource();
			if (object == m_oAssignButton)
			{
				try
				{
				    Object[] sList = m_oAvailabilityList.getSelectedValues();

					for(int i=0;i<sList.length;i++)
					{
						Object sItem = sList[i];
				    		m_oAssignedListModel.addElement(sItem);
				    	
						int remIndex = m_oAvailabilityListModel.indexOf(sItem);
						m_oAvailabilityListModel.remove(remIndex);
					}

					if (m_oAvailabilityListModel.getSize() == 0)
					{
						m_oAssignedList.setSelectedIndex(0);

						m_oAssignButton.setEnabled(false);
						m_oDeassignButton.setEnabled(true);
					}
					else
					{
						m_oAvailabilityList.setSelectedIndex(0);
					}
				}
				catch (Exception e)
				{
				}
			}
			else if (object == m_oDeassignButton)
			{
				try
				{
					Object[]  sList = m_oAssignedList.getSelectedValues();

					for(int i=0;i<sList.length;i++)
					{
						Object sItem = sList[i];

				    	m_oAvailabilityListModel.addElement(sItem);

						int remIndex = m_oAssignedListModel.indexOf(sItem);
				    	m_oAssignedListModel.remove(remIndex);

					}

					if (m_oAssignedListModel.getSize() == 0)
					{
						m_oAvailabilityList.setSelectedIndex(0);

						m_oDeassignButton.setEnabled(false);
						m_oAssignButton.setEnabled(true);
					}
					else
					{
						m_oAssignedList.setSelectedIndex(0);
					}
				}
				catch (Exception e)
				{
				}
			}
			else if (object == m_oNextButton)
			{
				try
				{
				    setVisible(false);
					dispose();
					for(int i=0;i<m_oAssignedListModel.getSize();i++)
					{
						m_oGroups.addElement(m_oAssignedListModel.get(i));
					}
					// AddUserWizard4 Create and show as modal
					(new AddUserWizard4(((JFrame)getParent()), true)).setVisible(true);
				}
				catch (Exception e)
				{
				}
			}
			else if (object == m_oBackButton)
			{
				try
				{
					m_oGroups.clear();
				    setVisible(false);
					dispose();
					// AddUserWizard2 Create and show as modal
					(new AddUserWizard2(((JFrame)getParent()), true)).setVisible(true);
				}
				catch (Exception e)
				{
				}
			}	
			else if (object == m_oCancelButton)
			{
				try
				{
					UserManager.cancel();
					m_oGroups.clear();
				    setVisible(false);
					dispose();
				}
				catch (Exception e)
				{
				}
			}	
		}
	}

	class SymWindow extends java.awt.event.WindowAdapter
	{
		public void windowClosing(java.awt.event.WindowEvent event)
		{
			Object object = event.getSource();
			if (object == AddUserWizard3.this)
			{
			    setVisible(false);
				dispose();
				UserManager.cancel();
				m_oGroups.clear();
			}
		}
	}


	public static void main(String args[])
	{
		JFrame frame = new JFrame();
		frame.setSize(550,400);
		try
		{
			(new AddUserWizard3(frame, true)).setVisible(true);
		}
		catch(Exception e)
		{
		}
	}

}

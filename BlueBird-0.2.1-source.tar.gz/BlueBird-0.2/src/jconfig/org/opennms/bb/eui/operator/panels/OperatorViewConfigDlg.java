//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.operator.panels;

import javax.swing.*;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.ListSelectionEvent;

import java.awt.*;
import java.awt.event.*;

import java.util.*;

/**
 * <pre> OperatorViewConfigDlg allows the user to configure the views 
 * required from the available views 
 * 
 * @author Sowmya
 */
public class OperatorViewConfigDlg extends JDialog
{
	DefaultListModel avViewsModel;
	DefaultListModel conViewsModel;

	JList  avViewsList;
	JList  conViewsList;

	JButton addButton;
	JButton removeButton;

	JButton moveAll;
	JButton removeAll;

	OperatorInterfacePanel	operatorParent;

	public OperatorViewConfigDlg(JFrame frame, OperatorInterfacePanel panel)
	{
		super(frame);
		setTitle("View Configuration");

		operatorParent = panel;

		Vector availableViewsVector = operatorParent.getAvailableViews();
		Vector configViewsVector = operatorParent.getConfiguredViews();

		// get titles of the available views
		avViewsModel = new DefaultListModel();

		int iSize = availableViewsVector.size();
		for(int iIndex=0; iIndex<iSize; iIndex++)
		{
			Hashtable avView = (Hashtable)availableViewsVector.elementAt(iIndex);
			avViewsModel.addElement(avView.get(panel.LABEL));
		}

		// get titles of the configured views
		conViewsModel = new DefaultListModel();

		int iConSize = configViewsVector.size();
		for(int iIndex=0; iIndex<iConSize; iIndex++)
		{
			Hashtable conView = (Hashtable)configViewsVector.elementAt(iIndex);
			conViewsModel.addElement(conView.get(panel.LABEL));
		}

		// Start construction
	
		Dimension listSize = new Dimension(150, 200);

		// left panel
		JPanel  panel1 = new JPanel();
		panel1.setLayout(new BoxLayout(panel1, BoxLayout.Y_AXIS));
	
		// available views list
		avViewsList = new JList(avViewsModel);
		avViewsList.setVisibleRowCount(10);
		avViewsList.setPrototypeCellValue("xxx xx      xxxxxxxxxxxxxxx");

		JScrollPane avViewsScrPane = new JScrollPane(avViewsList);
		avViewsScrPane.setAlignmentX(Component.LEFT_ALIGNMENT);
	
		JLabel avLabel = new JLabel("Available Views", SwingConstants.LEFT);
		avLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
		
		panel1.add(avLabel);
		panel1.add(avViewsScrPane);
		panel1.add(Box.createVerticalStrut(10));

		moveAll = new JButton(">> Move All");
		moveAll.setMnemonic('M');

		JPanel moveAllPanel = new JPanel();
		moveAllPanel.setLayout(new BoxLayout(moveAllPanel, BoxLayout.X_AXIS));
		moveAllPanel.add(Box.createHorizontalGlue());
		moveAllPanel.add(moveAll);
		moveAllPanel.add(Box.createHorizontalGlue());

		moveAllPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		panel1.add(moveAllPanel);

		// middle panel
		JPanel  panel2 = new JPanel();
		panel2.setLayout(new BoxLayout(panel2, BoxLayout.Y_AXIS));
	
		addButton = new JButton(">>");
		removeButton = new JButton("<<");

		panel2.add(addButton);
		panel2.add(Box.createVerticalStrut(10));
		panel2.add(removeButton);

		// right panel
		JPanel  panel3 = new JPanel();
		panel3.setLayout(new BoxLayout(panel3, BoxLayout.Y_AXIS));
	
		// configured views list
		conViewsList = new JList(conViewsModel);
		conViewsList.setVisibleRowCount(10);
		conViewsList.setPrototypeCellValue("xxx xx      xxxxxxxxxxxxxxx");

		JScrollPane conViewsScrPane = new JScrollPane(conViewsList);
		conViewsScrPane.setAlignmentX(Component.LEFT_ALIGNMENT);
	
		JLabel conLabel = new JLabel("Views in your folder tabs", SwingConstants.LEFT);
		conLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
		
		panel3.add(conLabel);
		panel3.add(conViewsScrPane);
		panel3.add(Box.createVerticalStrut(10));

		removeAll = new JButton("<< Remove All");
		removeAll.setMnemonic('R');

		JPanel removeAllPanel = new JPanel();
		removeAllPanel.setLayout(new BoxLayout(removeAllPanel, BoxLayout.X_AXIS));
		removeAllPanel.add(Box.createHorizontalGlue());
		removeAllPanel.add(removeAll);
		removeAllPanel.add(Box.createHorizontalGlue());

		removeAllPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		panel3.add(removeAllPanel);

		// up
		JPanel upPanel = new JPanel();
		upPanel.setLayout(new BoxLayout(upPanel, BoxLayout.X_AXIS));
	
		upPanel.add(panel1);
		upPanel.add(Box.createHorizontalStrut(10));
		upPanel.add(panel2);
		upPanel.add(Box.createHorizontalStrut(10));
		upPanel.add(panel3);
		upPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		
		// down
		JPanel downPanel = new JPanel();
		downPanel.setLayout(new BoxLayout(downPanel, BoxLayout.X_AXIS));
	
		Dimension dim;

		// OK
		JButton okButton = new JButton("OK");
		okButton.setMnemonic('O');

		dim = okButton.getPreferredSize();
		okButton.setPreferredSize(new Dimension(80, dim.height));
	
		// Cancel
		JButton cancelButton = new JButton("Cancel");
		cancelButton.setMnemonic('C');
		
		dim = cancelButton.getPreferredSize();
		cancelButton.setPreferredSize(new Dimension(80, dim.height));
	
		downPanel.add(Box.createHorizontalGlue());
		downPanel.add(okButton);
		downPanel.add(Box.createHorizontalStrut(10));
		downPanel.add(cancelButton);
		downPanel.add(Box.createHorizontalGlue());
		downPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));

		Container cont = getContentPane();

		cont.setLayout(new BorderLayout());
		cont.add(upPanel, BorderLayout.NORTH);
		cont.add(downPanel, BorderLayout.SOUTH);

		pack();
		setResizable(false);
		setLocationRelativeTo(frame);
		setVisible(true);



		/*
		 * Action Listeners
		 */

		// add to configured list
		addButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent addEvent)
			{
				Object[] selValues = avViewsList.getSelectedValues();
	
				for(int iSelIndex=0; iSelIndex<selValues.length; iSelIndex++)
				{
					Object element = selValues[iSelIndex];
		
					// add to configured list
					conViewsModel.addElement(element);
					
					//remove from available list
					int iRemIndex = avViewsModel.indexOf(element);
					avViewsModel.remove(iRemIndex);
				}

				if(avViewsModel.getSize() == 0)
				{
					conViewsList.setSelectedIndex(0);
				}
				else
				{
					avViewsList.setSelectedIndex(0);
				}
			}
		});
	
		// remove from configured list
		removeButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent removeEvent)
			{
				Object[] selValues = conViewsList.getSelectedValues();
	
				for(int iSelIndex=0; iSelIndex<selValues.length; iSelIndex++)
				{
					Object element = selValues[iSelIndex];
			
					// add to configured list
					avViewsModel.addElement(element);
				
					//remove from available list
					int iRemIndex = conViewsModel.indexOf(element);
					conViewsModel.remove(iRemIndex);
				}

				if(conViewsModel.getSize() == 0)
				{
					avViewsList.setSelectedIndex(0);
				}
				else
				{
					conViewsList.setSelectedIndex(0);
				}
			}
		});
		
		// move all to configured list
		moveAll.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent moveAllEvent)
			{
				Enumeration avEnum = avViewsModel.elements();
				while(avEnum.hasMoreElements())
				{
					Object temp = avEnum.nextElement();
					conViewsModel.addElement(temp);
				}

				avViewsModel.removeAllElements();

				conViewsList.setSelectedIndex(0);
			}
		});
		
		// remove all from configured list
		removeAll.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent removeAllEvent)
			{
				Enumeration conEnum = conViewsModel.elements();
				while(conEnum.hasMoreElements())
				{
					Object temp = conEnum.nextElement();
					avViewsModel.addElement(temp);
				}

				conViewsModel.removeAllElements();

				avViewsList.setSelectedIndex(0);
			}
		});

		// reconfigure on OK
		okButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent okEvent)
			{
				Vector conViewsVector = new Vector();

				// get required views into a vector
				Enumeration conEnum = conViewsModel.elements();
				while(conEnum.hasMoreElements())
				{
					conViewsVector.add(conEnum.nextElement());
				}
			
				operatorParent.configureTabbedPanes(conViewsVector);
				dispose();
			}
		});

		// close on cancel
		cancelButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent cancelEvent)
			{
				dispose();
			}
		});


		// list selection listeners
		avViewsList.addListSelectionListener(new ListSelectionListener()
		{
			public void valueChanged(ListSelectionEvent avListEvent)
			{
				JList lsm = (JList)avListEvent.getSource();

				if(lsm.isSelectionEmpty())
					return;

				addButton.setEnabled(true);
				moveAll.setEnabled(true);

				removeButton.setEnabled(false);
				removeAll.setEnabled(false);
				
				conViewsList.clearSelection();
			}
		});

		conViewsList.addListSelectionListener(new ListSelectionListener()
		{
			public void valueChanged(ListSelectionEvent conListEvent)
			{
				JList lsm = (JList)conListEvent.getSource();

				if(lsm.isSelectionEmpty())
					return;

				addButton.setEnabled(false);
				moveAll.setEnabled(false);

				removeButton.setEnabled(true);
				removeAll.setEnabled(true);

				avViewsList.clearSelection();
			}
		});

		// set up initial selection
		if (iSize != 0)
		{
			avViewsList.setSelectedIndex(0);
		}
		else
		{
			conViewsList.setSelectedIndex(0);
		}

	}
}


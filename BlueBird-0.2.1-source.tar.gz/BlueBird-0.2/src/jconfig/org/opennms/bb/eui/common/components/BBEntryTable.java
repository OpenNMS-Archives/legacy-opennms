//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
// Modification History:
// Oct 2000 - Changed the 'installKeyboardActions()' method of the
//            BBEntryTableUI class  to account for the change to the
//            infrastructure for creating keyboard bindings in JDK 1.3 - Sowmya
//
//

package org.opennms.bb.eui.common.components;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.text.*;
import javax.swing.table.*;
import javax.swing.event.*;

import javax.swing.plaf.basic.BasicTableUI;
import javax.swing.plaf.ActionMapUIResource;

import java.util.Vector;

/**
 * BBEntryTable extends the JTable and has an attribute column and
 * a value column. It visually indicates the row selected and 
 * allows for the user to enter values only in the value column
 *
 * @author Sowmya
 *
 */
public class BBEntryTable extends JTable 
{
	protected BBEntryTableModel infoTableModel;

	final static int TABLE_WIDTH   = 450;
	final static int TABLE_HEIGHT  = 225;

	public final static int ARROW_COLUMN	= 0;
	public final static int ATTRIB_COLUMN	= 1;
	public final static int VALUE_COLUMN 	= 2;

	static int iLastEditingRow = -1;

	/**
	 * Initialize the required table features
	 */
	protected void BBEntryTableInit()
	{
		setUI(new BBEntryTableUI());

		// set single selection
		setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

		// Do not allow reordering of columns
		getTableHeader().setReorderingAllowed(false);

		// Set selection colors
		setSelectionForeground(Color.black);
		setSelectionBackground(Color.white);

		setCellSelectionEnabled(true);

		// Do not show grid
		setShowHorizontalLines(true);
		setShowVerticalLines(false);

		// set column widths
		setTableColumnWidths();

		// Attach a textfield cell editor to the 'Value' column
		BBTextField colText = new BBTextField();
		getColumnModel().getColumn(VALUE_COLUMN).setCellEditor(new BBColumnEditor(colText));

		getColumnModel().getColumn(0).setCellRenderer(new BBArrowRenderer());

		// Track the list selection to set focus to the editor component
		getSelectionModel().addListSelectionListener(new ListSelectionListener()
		{
			public void valueChanged(ListSelectionEvent e)
			{
				int iSelectedRow = getSelectedRow();
				int iNumRows     = getRowCount();

				for (int iIndex=0; iIndex < iNumRows; iIndex++)
				{
					setValueAt(new Boolean(iIndex == iSelectedRow), iIndex, 0);
				}
				repaint();

				ListSelectionModel lsm = (ListSelectionModel)e.getSource();

				if(!(lsm.isSelectionEmpty()))
				{
					editCellAt(iSelectedRow, VALUE_COLUMN);
					getEditorComponent().requestFocus();
				}
				else // selection empty
				{
					int iRowCount    = getRowCount();

					for (int iIndex=0; iIndex < iRowCount; iIndex++)
					{
						setValueAt(Boolean.FALSE, iIndex, 0);
					}

					repaint();
				}
			}
		});
	}

	/**
	 * Create the table
	 */
	public BBEntryTable(Vector inpRowData, Vector inpColNames)
	{
		int iNumRows = inpRowData.size();
		Vector rowData = new Vector(iNumRows);

		for (int iIndex=0; iIndex<iNumRows; iIndex++)
		{
			Vector rowVal = new Vector(3);
			
			rowVal.addElement("");

			Vector temp = (Vector)inpRowData.elementAt(iIndex);
			rowVal.addElement(temp.elementAt(0));
			rowVal.addElement(temp.elementAt(1));

			rowData.addElement(rowVal);
		}

		Vector colNames = new Vector(3);
		colNames.add("");
		colNames.add(inpColNames.elementAt(0));
		colNames.add(inpColNames.elementAt(1));

		infoTableModel = new BBEntryTableModel(rowData, colNames);
		setModel(infoTableModel);

		BBEntryTableInit();
	}

	/**
	 * Sets the table column widths
	 */
	public void setTableColumnWidths()
	{
		TableColumn column=null;

		int iArrowColWidth = 20;
		int iAttribColWidth= getPreferredScrollableViewportSize().width/2;
		int iValueColWidth = TABLE_WIDTH - iArrowColWidth - iAttribColWidth 
								- (int)(getIntercellSpacing().getWidth() * 6);

		int colWidths[] = {iArrowColWidth, iAttribColWidth, iValueColWidth};

		for(int index=0; index < colWidths.length; index++)
		{
			column = getColumnModel().getColumn(index);

			if(index == 0)
			{
				column.setMinWidth(colWidths[index]);
				column.setMaxWidth(colWidths[index]);
			}

			BBDefaultTableHeaderRenderer renderer = new BBDefaultTableHeaderRenderer();

			column.setHeaderRenderer(renderer);

			column.setPreferredWidth(colWidths[index]);
		}

		// set a default viewport size
		setPreferredScrollableViewportSize( new Dimension(TABLE_WIDTH, TABLE_HEIGHT));
	}

	/**
 	 * Updates UI to set it back to BBEntryTableUI
 	 */
	public void updateUI()
	{
		setUI(new BBEntryTableUI());
	}

	/**
 	 * Sets focus to the value column of the first row
 	 */
	public boolean setInitialFocus()
	{
		if (getRowCount() <= 0)
			return false;

		iLastEditingRow = 0;

		clearSelection();
		selectCellAt(iLastEditingRow, VALUE_COLUMN);
		return true;
	}

	/**
 	 * Selects the cell (row, col)
 	 */
	public void selectCellAt(int row, int col)
	{
		setRowSelectionInterval(row, row);
		setColumnSelectionInterval(col, col);
	}

	/**
	 * process key events to regulate the movement inside the
	 * table using arrow keys and tabs
	 */
	protected void processKeyEvent(KeyEvent e)
	{
		final int	MOVE_UP = 1;
		final int	MOVE_DOWN = -1;

		int		iInternalCode=0;
		int		code = e.getKeyCode();

		if (code == KeyEvent.VK_TAB)
		{
			String mode = e.getKeyModifiersText(e.getModifiers());
			if(mode.equals("Shift"))
				iInternalCode = MOVE_UP;
			else
				iInternalCode = MOVE_DOWN;
		}
		else
			super.processKeyEvent(e);

		if (iInternalCode == MOVE_DOWN)
		{

			if (iLastEditingRow < 0) // Ignore the header
			{
				iLastEditingRow = 0;
				selectCellAt(iLastEditingRow, VALUE_COLUMN);
				return;
			}

			if (iLastEditingRow < getRowCount()-1)
			{
				iLastEditingRow++;
				selectCellAt(iLastEditingRow, VALUE_COLUMN);
			}
			else
			{
				iLastEditingRow = 0;
				selectCellAt(iLastEditingRow, VALUE_COLUMN);
			}
		}
		else if (iInternalCode == MOVE_UP)
		{

			if (iLastEditingRow > 0)
			{
				iLastEditingRow--;
				selectCellAt(iLastEditingRow, VALUE_COLUMN);
			}
			else
				clearSelection();
		}
	}

	/**
	 * Returns the attached table model
	 */
	public BBEntryTableModel getTableModel()
	{
		return infoTableModel;
	}

	/**
 	 * <pre>Returns the column names 
	 * Note: The actual table data has an extra column for the 
	 *       arrow. This is not returned in the result
	 * </pre>
 	 */
	public Vector getColumns()
	{
		Vector outCols = new Vector();

		int iColCount = getColumnCount();

		for (int iIndex=1; iIndex<iColCount; iIndex++)
		{
			outCols.add(getColumnName(iIndex));
		}

		return outCols;
	}

	/**
 	 * <pre>Returns the table data
	 * Note: The actual table data has an extra column for the 
	 *       arrow in each row. This is not returned in the result
	 * </pre>
 	 */
	public Vector getData()
	{
		Vector actualData = getTableModel().getDataVector();

		Vector outData = new Vector();

		int iRowCount = getRowCount();

		for (int iIndex=0; iIndex<iRowCount; iIndex++)
		{
			Vector temp = new Vector();

			Vector actualTemp = (Vector)actualData.elementAt(iIndex);

			temp.add(actualTemp.elementAt(ATTRIB_COLUMN));
			temp.add(actualTemp.elementAt(VALUE_COLUMN));

			outData.add(temp);
		}
		
		return outData;
	}

	/**
	 * Returns true by default. Sub-classes override this method if
	 * additional validation is required (for example before a save)
	 */
	public boolean validateValues(String panelName)
	{
		return true;
	}
}


/**
 * The BBEntryTableUI extends the BasicTableUI to handle up/down/escape
 * key actions and the mouse actions so as to dictate move between cells and
 * also validate the cell values on move from a cell 
 */
class BBEntryTableUI extends BasicTableUI
{
	private class BBEntryKeyAction extends AbstractAction
	{
		protected BBEntryKeyAction(String name)
		{
			super(name);
		}

		public void actionPerformed(ActionEvent e)
		{
			BBEntryTable infoTable = (BBEntryTable)e.getSource();

			String command	= (String)getValue(Action.NAME);

			ListSelectionModel rsm = infoTable.getSelectionModel();

			if (command.equals("NextRow"))
			{
				if (infoTable.iLastEditingRow < infoTable.getRowCount()-1)
				{
					infoTable.iLastEditingRow++;
					infoTable.selectCellAt(infoTable.iLastEditingRow, infoTable.VALUE_COLUMN);
				}
			}
			else if (command.equals("PrevRow"))
			{
				if (infoTable.iLastEditingRow > 0)
				{
					infoTable.iLastEditingRow--;
					infoTable.selectCellAt(infoTable.iLastEditingRow, infoTable.VALUE_COLUMN);
				}
			}

			else if (command.equals("Escape"))
			{
            			final CellEditor editor = infoTable.getCellEditor(); 

            			if (editor != null && editor instanceof BBColumnEditor)
				{
					((BBColumnEditor)editor).bEditingCancelled=true;
					editor.cancelCellEditing();
				}
			}

			else if (command.equals("PageUp"))
			{
				Dimension delta = infoTable.getParent().getSize(); 
				int start = rsm.getAnchorSelectionIndex(); 
				Rectangle r = infoTable.getCellRect(start, 0, true); 
				r.y +=  -delta.height; 
				int newRow = infoTable.rowAtPoint(r.getLocation()); 
				if(newRow == -1 && infoTable.getRowCount() > 0)
				{
					newRow = 0;
				}

				infoTable.iLastEditingRow = newRow;
				infoTable.selectCellAt(infoTable.iLastEditingRow, infoTable.VALUE_COLUMN);

			}

			else if (command.equals("PageDown"))
			{
				Dimension delta = infoTable.getParent().getSize(); 
				int start = rsm.getAnchorSelectionIndex(); 

				Rectangle r = infoTable.getCellRect(start, 0, true); 
				r.y += delta.height; 
				int newRow = infoTable.rowAtPoint(r.getLocation()); 
				if(newRow == -1 && infoTable.getRowCount() > 0)
				{ 
					newRow = infoTable.getRowCount()-1; 
				}

				infoTable.iLastEditingRow = newRow;
				infoTable.selectCellAt(infoTable.iLastEditingRow, infoTable.VALUE_COLUMN);

			}
		}
	}

	protected void installKeyboardActions()
	{
		ActionMap map = getActionMap();
		SwingUtilities.replaceUIActionMap(table, map);

		InputMap inputMap = getInputMap(JComponent.
				  WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
		SwingUtilities.replaceUIInputMap(table, JComponent.
					   WHEN_ANCESTOR_OF_FOCUSED_COMPONENT,
					   inputMap);
	}

	private InputMap getInputMap(int condition)
	{
		if (condition == JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT)
		{
			return (InputMap)UIManager.get("Table.ancestorInputMap");
		}
		return null;
	}

	private ActionMap getActionMap()
	{
		ActionMap map = (ActionMap)UIManager.get("Table.actionMap");

		map = changeActionMap(map);

		return map;
	}

	private ActionMap changeActionMap(ActionMap map)
	{
		if (map == null)
			map = new ActionMapUIResource();

		map.put("selectNextRow", new BBEntryKeyAction("NextRow"));
		map.put("selectPreviousRow", new BBEntryKeyAction("PrevRow"));
		map.put("cancel", new BBEntryKeyAction("Escape"));

		map.put("scrollUpChangeSelection", new BBEntryKeyAction("PageUp"));
		map.put("scrollDownChangeSelection", new BBEntryKeyAction("PageDown"));
		return map;
	}

	protected MouseInputListener createMouseInputListener()
	{
		return new BBEMouseInputHandler();
	}

	private class BBEMouseInputHandler implements MouseInputListener 
	{
        	public void mouseClicked(MouseEvent e) {}

        	public void mousePressed(MouseEvent e) 
		{
	    		if (!SwingUtilities.isLeftMouseButton(e)) 
			{
	        		return;
	    		}

			BBEntryTable table = (BBEntryTable)e.getSource();

            		Point p = e.getPoint();
            		int row = table.rowAtPoint(p);
			boolean bPrevCellOK=false;

           		CellEditor editor = table.getCellEditor();
			Component editorComp=null;

           		if (editor != null && editor instanceof BBColumnEditor)
			{
				editorComp = ((BBColumnEditor)editor).getComponent();

				if (editorComp instanceof BBTextField)
				{
					if (!((BBTextField)editorComp).isValid())
						table.requestFocus();
					else
						bPrevCellOK = true;
				}
				else
					bPrevCellOK = true; // if not textfield, don't bother
			}

            		if (row != -1) 
			{
				if (bPrevCellOK  || editorComp == null)
				{
					table.iLastEditingRow = row;
					table.selectCellAt(table.iLastEditingRow, table.VALUE_COLUMN);
				}
			}
            		else if (row == -1) 
			{
				if (table.getRowCount() <= 0 || table.getColumnCount() <= 0)
					return;

				table.iLastEditingRow = 0;
				table.selectCellAt(table.iLastEditingRow, table.VALUE_COLUMN);
			}


			e.consume();
        	}

        	public void mouseReleased(MouseEvent e) { }
	

        	public void mouseEntered(MouseEvent e) {}

        	public void mouseExited(MouseEvent e) {}

        	public void mouseMoved(MouseEvent e) {}

        	public void mouseDragged(MouseEvent e) {}

	}
}

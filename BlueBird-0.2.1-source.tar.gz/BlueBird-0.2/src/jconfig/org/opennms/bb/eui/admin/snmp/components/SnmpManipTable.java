//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.admin.snmp.components;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.table.*;
import javax.swing.event.*;

import java.util.Vector;

import org.opennms.bb.eui.common.components.*;

/**
 * <pre>SnmpManipTable 
 * - sets appropriate cell editors 
 * - sets appropriate tool tips
 * - also provides a method to validate cell values </pre>
 *
 * @author Sowmya
 *
 */
public class SnmpManipTable extends BBManipTable
{
	public SnmpManipTable(Vector inpColNames)
	{
		super(inpColNames);
	}
	
	public SnmpManipTable(Vector inpRowData, Vector inpColNames)
	{
		super(inpRowData, inpColNames);
	}


	public TableCellEditor getCellEditor(int row, int col)
	{
		String value = ((String)getColumnName(col)).toLowerCase();

		if (value.indexOf("ip address") != -1)
		{
			IPAddressTextField colText = new IPAddressTextField();
			return new SnmpColumnEditor(colText);
		}

		else if (value.indexOf("timeout") != -1)
		{
			TimeOutTextField colText = new TimeOutTextField();
			return new SnmpColumnEditor(colText);
		}

		else if (value.indexOf("retries") != -1)
		{
			RetryTextField colText = new RetryTextField();
			return new SnmpColumnEditor(colText);
		}
		
		else
			return super.getCellEditor(row, col);

	}

	public boolean validateValues(String panelName)
	{
		Vector data = getData();
		Vector cols = getColumns();

		int    iNumEntries = data.size();
		int	   iNumCols = cols.size();

		for(int iIndex1=0; iIndex1<iNumEntries; iIndex1++)
		{
			Vector vector1=(Vector)data.elementAt(iIndex1);

			for (int iColIndex=0; iColIndex < iNumCols; iColIndex++)
			{
				Object  temp=vector1.elementAt(iColIndex);

				String colID=((String)cols.elementAt(iColIndex)).toLowerCase();

				if (colID.indexOf("ip address") != -1)
				{
					if (!IPAddressTextField.checkFormat(String.valueOf(temp)))
					{
		 				JOptionPane.showMessageDialog(null, 
							"Invalid IP Address entry \'" + temp + "\' found in" 
							+ "\nrow# \'" + (iIndex1+1) + "\' of " + panelName, 
							"Invalid Entry in " + panelName + "!", 
								JOptionPane.WARNING_MESSAGE);
						return false;
					}
				}

				else if (colID.indexOf("timeout") != -1)
				{
					if (!TimeOutTextField.checkFormat(String.valueOf(temp)))
					{
		 				JOptionPane.showMessageDialog(null, 
							"Invalid timeout entry \' " + temp + "\' found in " 
							+ "\nrow# \'" + (iIndex1+1) + "\' of " + panelName, 
							"Invalid Entry in " + panelName + "!", 
								JOptionPane.WARNING_MESSAGE);
						return false;
					}
				}

				else if (colID.indexOf("retries") != -1)
				{
					if (!RetryTextField.checkFormat(String.valueOf(temp)))
					{
		 				JOptionPane.showMessageDialog(null, 
							"Invalid retry entry  \'" + temp + "\' found in " 
							+ "\nrow# \'" + (iIndex1+1) + "\' of " + panelName, 
							"Invalid Entry in " + panelName + "!", 
							JOptionPane.WARNING_MESSAGE);
						
						return false;
					}
				}
		
			}
		}
		
		return true;
	}

	/**
	 * Sets the column widths of the columns in the table to the 
	 * the viewport width / number of columns or length of the column name 
	 * whichever is greater
	 *
	 * <p>but if the column name indicates 'ip address' width is set to
	 * 100
	 *
	 * <p>Also sets the table scrollpane viewport accordingly
	 */
	public void setTableColumnWidths()
	{
		TableColumn column=null;

		int		iNumCols 		= getColumnCount();
		int		DEF_WIDTH		= getPreferredScrollableViewportSize().width/iNumCols;
		int		iTableWidth 	= 0;

		int		iIntercellWidth = (int) getIntercellSpacing().getWidth();

		// arrow column
		column = getColumnModel().getColumn(0);
		column.setPreferredWidth(20);
		column.setMinWidth(20);
		column.setMaxWidth(20);

		iTableWidth += 20;

		for(int iIndex=1; iIndex < iNumCols; iIndex++)
		{
			int colWidth = DEF_WIDTH;
			String colName = getColumnName(iIndex).toLowerCase();

			column = getColumnModel().getColumn(iIndex);

			if (colName.indexOf("ip address") != -1)
			{
				colWidth = 100;
			}

			TableCellRenderer renderer = column.getHeaderRenderer();
			if (renderer == null)
			{
				renderer = new BBDefaultTableHeaderRenderer();
				column.setHeaderRenderer(renderer);
				setHeaderToolTips();
			}

			Component comp = renderer.getTableCellRendererComponent( this, column.getHeaderValue(), false, false, 0, 0);
			
			int headerWidth = comp.getPreferredSize().width;

			colWidth = Math.max(DEF_WIDTH, colWidth);
			colWidth = Math.max(headerWidth, colWidth);

			column.setPreferredWidth(colWidth);

			iTableWidth += colWidth;
		}

		iTableWidth += (iIntercellWidth * (iNumCols+2));

		if (iTableWidth > 600)
			iTableWidth = 600;

		setPreferredScrollableViewportSize(
									new Dimension(iTableWidth, 300));
	}

	public void setHeaderToolTips()
	{
		int iNumCols = getColumnCount();

		TableColumnModel colModel = getColumnModel();

		for (int iIndex=0; iIndex<iNumCols; iIndex++)
		{
			String value = ((String)getColumnName(iIndex)).toLowerCase();

			TableCellRenderer hdrRenderer = columnModel.getColumn(iIndex).getHeaderRenderer();

			if (hdrRenderer == null)
				continue;

			Component hdrComponent = hdrRenderer.getTableCellRendererComponent(this, value, false, false, 0, 0);

			//check if tooltip can be set
			if (!(hdrComponent instanceof JComponent))
				continue;

			JComponent comp = (JComponent)hdrComponent;
			if (comp.getToolTipText() != null)
				continue;

			if (value.indexOf("from ip address") != -1)
			{
				comp.setToolTipText("Starting IP Address of the range in the format [0-255].[0-255].[0-255].[0-255]");
			}

			else if (value.indexOf("to ip address") != -1)
			{
				comp.setToolTipText("Ending IP Address of the range in the format [0-255].[0-255].[0-255].[0-255]");
			}

			else if (value.indexOf("ip address") != -1)
			{
				comp.setToolTipText("IP Address in the format [0-255].[0-255].[0-255].[0-255]");
			}

			else if (value.indexOf("timeout") != -1)
			{
				comp.setToolTipText("Time out in seconds");
			}
	
			else if (value.indexOf("retries") != -1)
			{
				comp.setToolTipText("Number of retries");
			}
		
			else if (value.indexOf("community") != -1 )
			{
				if (value.indexOf("get") != -1)
					comp.setToolTipText("Get Community String");
				
				else if (value.indexOf("set") != -1)
					comp.setToolTipText("Set Community String");
			}
		
		}
	}
}



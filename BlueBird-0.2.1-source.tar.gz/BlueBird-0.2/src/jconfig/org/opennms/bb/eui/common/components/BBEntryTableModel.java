//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.common.components;

import javax.swing.*;
import javax.swing.table.*;
import java.util.Vector;

/**
 * BBEntryTableModel is the table model for the BBEntryTable
 * It extends the DefaultTableModel and sets the 'attribute' column
 * to be non-editable 
 *
 * @author Sowmya
 *
 */
public class BBEntryTableModel extends DefaultTableModel
{
	public BBEntryTableModel()
	{
		super();
	}

	public BBEntryTableModel(Vector inpData, Vector inpColNames)
	{
		super(inpData, inpColNames);
	}

	/** 
	 *  Sets the arrow column to be non-editable
	 */
	public boolean isCellEditable(int row, int col)
	{
		int iArrowCol  = 0;
		int iAttribCol = 1;

		if (col == iAttribCol)
			return false;
		else
			return true;
	}

	public void setValueAt(Object value, int row, int col)
	{
		/*
		 * Note that setValue() gets called when we do a editCellAt()
		 * to transfer cell focus - so update the value only if
		 * a value is being changed
		 */

		Object oldValue = getValueAt(row, col);

		if (oldValue.equals(value))
			return;

		else
			super.setValueAt(value, row, col);
	}

}

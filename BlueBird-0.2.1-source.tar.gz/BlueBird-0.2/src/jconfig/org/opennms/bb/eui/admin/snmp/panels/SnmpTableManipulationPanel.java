//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.admin.snmp.panels;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;

import java.util.*;

import org.opennms.bb.eui.common.panels.TableManipulationPanel;
import org.opennms.bb.eui.admin.snmp.components.*;

/**
 * SnmpTableManipulationPanel creates a SnmpManipTable
 *
 * @author Sowmya
 *
 */

class SnmpTableManipulationPanel extends TableManipulationPanel 
{

	protected SnmpTableManipulationPanel(Vector colNames)
	{
		super(colNames);
	}

	protected SnmpTableManipulationPanel(Vector rowData, Vector colNames)
	{
		super(rowData, colNames);
	}

	/**
	 * Creates a SnmpManipTable with the data 'rowData' and 
	 * column names 'colNames'
	 */
	protected void createTable(Vector rowData, Vector colNames)
	{
		//Create the table
		infoTable = new  SnmpManipTable(rowData, colNames);

		infoTableModel = ((SnmpManipTable)infoTable).getTableModel();

		setViewportView(infoTable);
	}

	/**
	 * Creates an empty SnmpManipTable with column names 'colNames'
	 */
	protected void createTable(Vector colNames)
	{
		//Create the table
		infoTable = new  SnmpManipTable(colNames);

		infoTableModel = ((SnmpManipTable)infoTable).getTableModel();

		setViewportView(infoTable);

	}

}

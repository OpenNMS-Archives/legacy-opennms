//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.operator.components;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.event.*;
import java.util.*;
import java.lang.*;

/**
 * <pre>BBActionEditor is the table cell editor that provides the
 * file browse editor.
 * 
 * It extends the DefaultCellEditor and executes the command.
 *
 *</pre>
 *
 * @author Jacinta
 *
 */

import java.util.Observer;
import javax.swing.table.*;

public class BBActionEditor extends DefaultCellEditor implements Observer
{
	EventsPerformAction performAction = new EventsPerformAction();
	BBActionRenderer 	renderer = new BBActionRenderer();
	String 		tasktoPerform = "";
	protected Object 	value;
	String 		buttonLabel = "";
	boolean 		buttonEnabled = true;

	JTable		editTable;
	int			editRow=-1;
	int			editCol=-1;

	/**
	 * Starts the process - the renderer button's action
	 * listener 
	 */
	public BBActionEditor()
	{
		super(new JTextField());

		setClickCountToStart(1);
		performAction.observable().addObserver(this);

		renderer.getButton().addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				renderer.getValue();
				performAction.setCommand(tasktoPerform);
				performAction.actionObs.row = editRow;
				performAction.actionObs.col = editCol;
				buttonLabel = "Running";
				renderer.getButton().setText(buttonLabel);
				buttonEnabled = false;
				renderer.getButton().setEnabled(buttonEnabled);
				new Thread(performAction).start();
				stopCellEditing();
			}
		});
	}

	public void update(Observable evp, Object o)
	{
		int exitVal = ((EventsPerformAction)o).getExitCode();
		if(exitVal >= 0)
		{
			buttonLabel = "Done";
			int row, col ;
			row = ((EventsPerformAction)o).actionObs.row;
			col = ((EventsPerformAction)o).actionObs.col;

			buttonEnabled = false;
			stopCellEditing();
//			renderer.getButton().setEnabled(buttonEnabled);
//			renderer.getButton().setText(buttonLabel);
		}
		else
		{
			buttonLabel = "Failed";
			buttonEnabled = false;
			editTable.setValueAt(buttonLabel, editRow, editCol);
			//renderer.getButton().setEnabled(buttonEnabled);
			//renderer.getButton().setText(buttonLabel);
		}
		
	}


	/**
	 * Overrides the method in the the parent class and returns the
	 * editor component
	 */
	public Component getTableCellEditorComponent(  JTable table,
						Object value,
						boolean isSelected,
						int row, int col)
	{
		editTable = table;
		editRow   = row;
		editCol   = col;

		String val = (String)value;

		val = (String)table.getValueAt(row, col);
		int index = val.indexOf("\\");
		if(index != -1)
			val = val.substring(0, index - 1);

		tasktoPerform = val;
		return renderer.getTableCellRendererComponent(table, value, true, true, row, col);
	}

	/**
 	 * This cell editor is different because it sets the value of the 
	 * revious cell
 	 */
	public boolean stopCellEditing()
	{
		SwingUtilities.invokeLater(new Runnable()
		{
			public void run()
			{
				getComponent().requestFocus();
			}
		});

		/*
		 * This is an unusual editor component in the sense that
		 * it sets the value of its previous column!
		 */
		if (!(buttonLabel.equals(""))  )
		{
			editTable.setValueAt(buttonLabel, editRow, editCol);
			
			buttonLabel = "";

		}
		
		boolean bRet = super.stopCellEditing();
		return bRet;
	}

}


//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.common.components;

import javax.swing.*;
import javax.swing.text.*;

import java.awt.*;
import java.awt.event.*;

import java.util.*;

/**
 * <pre>TimeoutTextField creates its own document that allows only digits, dot
 * and some restricted letters to be entered
 *
 * The validity methods allow only values 
 * of the format '\<number\>s' where number can be a decimal
 * or the string '\<default\>' to be entered </pre>
 *
 * @author Sowmya
 *
 */
public class TimeOutTextField extends BBTextField
{
	public TimeOutTextField(int columns)
	{
		super(columns);
	}

	public TimeOutTextField()
	{
		super();
	}

	public Object getValue()
	{
		return getText();
	}

	public void setValue(String value)
	{
		setText(value);
	}

	protected Document createDefaultModel()
	{
		return new TimeOutTextFieldDocument();
	}

	protected class TimeOutTextFieldDocument extends PlainDocument
	{
		public void insertString(int offs, String str, AttributeSet a) throws BadLocationException
		{
			char[] source = str.toCharArray();
			char[] result = new char[source.length];
	
			int iResIndex=0;
	
			for(int iSrcIndex=0; iSrcIndex < result.length; iSrcIndex++)
			{
				char curChar = source[iSrcIndex];

				if(Character.isDigit(curChar)  || curChar == 's' ||
					curChar == 'd' || curChar == 'e' || curChar == 'f' ||
					curChar == 'a' || curChar == 'u' || curChar == 'l' ||
					curChar == 't' || curChar == '.' || curChar == '<' || 
					curChar == '>')
				{
					result[iResIndex++] = source[iSrcIndex];
				}
			}
			
			super.insertString(offs, new String(result, 0, iResIndex), a);

		}
	}

	public boolean isValid()
	{
		String  value  = getText();

		return checkFormat(value);
	}

	public static boolean checkFormat(String value)
	{
		if (value.equals("<default>"))
			return true;

		/* no alphabets except 's' are allowed once u reach here */
		int iNumDots=0;
		int len = value.length();
		for (int iIndex=0; iIndex<len; iIndex++)
		{
			char inpChar = value.charAt(iIndex);
			if (Character.isDigit(inpChar) || inpChar == '.' || inpChar == 's')
			{
				if (inpChar == '.')
					iNumDots++;
			}
			else
				return false;
		}

		if (iNumDots > 1)
			return false;

		StringTokenizer tokens = new StringTokenizer(value, "sS");

		if (tokens.countTokens() != 1 )
		{
			// cannot have more than one time specifier
			return false;
		}
		else
		{
			String	time = tokens.nextToken();

			int		iTimeLen = time.length();
			int		iValueLen = value.length();

			if(iTimeLen == (iValueLen - 1) && value.endsWith("s"))

										// only last char can be 's'
			{
				return true;
			}
			else
				return false;
		}
	}
}

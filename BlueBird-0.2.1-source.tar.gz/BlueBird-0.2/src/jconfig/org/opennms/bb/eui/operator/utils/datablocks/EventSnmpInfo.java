//
// Copyright (C) 2000 N*Manage Company, Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
// $Id: EventSnmpInfo.java,v 1.2 2000/11/01 18:05:06 jacinta Exp $

package org.opennms.bb.eui.operator.utils.datablocks;

/**
 * EventSnmpInfo holds data from each <snmp>..</snmp> block in either the 
 * incoming event or the event in 'event.conf'
 *
 * @author Sowmya
 * @author <A HREF="http://www.opennms.org">OpenNMS.org</A>
 */
public class EventSnmpInfo extends Object
{
	/**
	 * the enterprise ID - corresponds to the EID of a SNMP trap
	 */
	public String		m_eid;

	/**
	 * the EID text
	 */
	public String		m_eidText;

	/**
	 * the specific type for the trap
	 */
	public String		m_specific;

	/**
	 * the general type for the trap
	 */
	public String		m_generic;

	/**
	 * Constructs a 'EventSnmpInfo' object with the parms
	 *
	 */
	public EventSnmpInfo(String eid, String eidText, String specific, String generic)
	{
		m_eid		= eid;
		m_eidText	= eidText;
		m_specific	= specific;
		m_generic	= generic;
	}
	
	/**
	 * Constructs a 'EventSnmpInfo' object from another EventSnmpInfo object
	 *
	 */
	public EventSnmpInfo(EventSnmpInfo snmpInfo)
	{
		m_eid		= new String(snmpInfo.m_eid);

		if (snmpInfo.m_eidText != null)
			m_eidText = new String(snmpInfo.m_eidText);
		else
			m_eidText = null;

		m_specific	= new String(snmpInfo.m_specific);
		m_generic	= new String(snmpInfo.m_generic);
	}
	
	public String toString()
	{
		StringBuffer str = new StringBuffer();

		str.append("UEI : " + m_eid);
		str.append("EIDTEXT : " + m_eidText);
		str.append("SPECIFIC : " + m_specific);
		str.append("GENERIC : " + m_generic);
		return str.toString();
	}
}

//-------------------------------------------------------------------------------------------
//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

//--------------------------------------------------------------------------------------------

package org.opennms.bb.eui.admin.distpoller.configure.dpconf;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;


public class ModifyDistPoller extends JDialog
{
	private boolean	m_bNew	= false;
	private String	sOldId	= new String("");
	public final static Border emptyBorder10 = new EmptyBorder(10,10,10,10);
	
	public ModifyDistPoller(JFrame parent, boolean modal, String packageName)
	{

		super(parent, modal);

		JLabel oPollerNameLabel	= new JLabel();
		JLabel oFullNameLabel = new JLabel();
		JLabel oIPAddressLabel = new JLabel();
		JLabel oCommentsLabel	= new JLabel();
		JLabel  oDiscLimitLabel = new JLabel();

		GridBagLayout gridBag = new GridBagLayout();
		JPanel groupPanel = new JPanel(gridBag);

		oPollerNameLabel = new JLabel("Poller Name:");
		m_oPollerNameInput = new JTextField(20);
		
		oFullNameLabel = new JLabel("Poller Full Name:");
		m_oFullNameInput = new JTextField(20);

		oIPAddressLabel = new JLabel("Poller IP Address:");
		m_oIPAddressInput= new JTextField(20);

		oDiscLimitLabel = new JLabel("Disc Limit:");
		m_oDiscLimitInput= new JTextField(20);

	
		oCommentsLabel = new JLabel("Comments:");
		m_oCommentsInput = new JTextArea(5, 20);
      		JScrollPane scrollPane = new JScrollPane(m_oCommentsInput,
                	   JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
                 		  JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);

	     	GridBagConstraints c = new GridBagConstraints();
	     	c.fill = GridBagConstraints.HORIZONTAL;

		c.weightx = 1;
		c.gridx = 0;
		c.gridy = 2;
      		gridBag.setConstraints(oPollerNameLabel, c);
      		groupPanel.add(oPollerNameLabel);

		c.gridwidth = GridBagConstraints.REMAINDER;
		c.gridx = 2;
		c.gridy = 2;
		gridBag.setConstraints(m_oPollerNameInput, c);
		groupPanel.add(m_oPollerNameInput);
		m_oPollerNameInput.setText(packageName);
		sOldId = packageName;

		c.fill = GridBagConstraints.HORIZONTAL;

		c.gridwidth = 4;
		c.gridx = 0;
		c.gridy = 3;
     	 	gridBag.setConstraints(oFullNameLabel, c);
      		groupPanel.add(oFullNameLabel);

		c.gridwidth = GridBagConstraints.REMAINDER;
		c.gridx = 3;
		c.gridy = 3;
		gridBag.setConstraints(m_oFullNameInput, c);
		groupPanel.add(m_oFullNameInput);
		

		c.fill = GridBagConstraints.HORIZONTAL;

		c.gridwidth = 4;

		c.gridx = 0;
		c.gridy = 4;
      		gridBag.setConstraints(oIPAddressLabel, c);
      		groupPanel.add(oIPAddressLabel);

		c.gridwidth = GridBagConstraints.REMAINDER;
		c.gridx = 4;
		c.gridy = 4;
		gridBag.setConstraints(m_oIPAddressInput, c);
		groupPanel.add(m_oIPAddressInput);


		c.fill = GridBagConstraints.HORIZONTAL;

		c.gridwidth = 4;

		c.gridx = 0;
		c.gridy = 5;
      		gridBag.setConstraints(oDiscLimitLabel, c);
      		groupPanel.add(oDiscLimitLabel);

		c.gridwidth = GridBagConstraints.REMAINDER;
		c.gridx = 5;
		c.gridy = 5;
		gridBag.setConstraints(m_oDiscLimitInput, c);
		groupPanel.add(m_oDiscLimitInput);


		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridwidth = 4;
		c.gridx = 0;
		c.gridy = 6;
		gridBag.setConstraints(oCommentsLabel, c);
      		groupPanel.add(oCommentsLabel);		

		c.gridwidth = GridBagConstraints.REMAINDER;
		c.ipady = 30;      
		c.gridx = 6;
		c.gridy = 6;
       		gridBag.setConstraints(scrollPane, c);
       		groupPanel.add(scrollPane);
	
		
		groupPanel.setBorder(emptyBorder10);
		
		m_oOkButton.setText("  OK  ");
		JPanel buttonPane = new JPanel();
		buttonPane.add(m_oOkButton);
		
		if(!m_bNew)
		{
			String sBuffer = (String)UserManager.m_oDP.get(packageName);
			if(sBuffer != null)
			{
				StringTokenizer oTokenizer = new StringTokenizer(sBuffer,":");

				String sTok = "";

				try
				{
					sTok = oTokenizer.nextToken();
				} catch(NoSuchElementException  e) { sTok = ""; }
				m_oFullNameInput.setText(sTok);
		
				try
				{
					sTok = oTokenizer.nextToken();
				} catch(NoSuchElementException  e) { sTok = ""; }
				m_oIPAddressInput.setText(sTok);
		
				try
				{
					sTok = oTokenizer.nextToken();
				} catch(NoSuchElementException  e) { sTok = ""; }
				m_oDiscLimitInput.setText(sTok);
	
				try
				{
					sTok = oTokenizer.nextToken();
				} catch(NoSuchElementException  e) { sTok = ""; }
				m_oCommentsInput.setText(sTok);

			}
		}
				        	
		SymWindow aSymWindow = new SymWindow();
		this.addWindowListener(aSymWindow);
		SymAction lSymAction = new SymAction();
		m_oOkButton.addActionListener(lSymAction);

		m_oPollerNameInput.addMouseListener(new java.awt.event.MouseAdapter()
									  {
										public void mousePressed(java.awt.event.MouseEvent e)
										{
											m_oPollerNameInput.setBackground(java.awt.Color.white);
										}
										public void mouseClicked(java.awt.event.MouseEvent e)
										{
											m_oPollerNameInput.setBackground(java.awt.Color.white);
										}
									  }
									 );
		m_oPollerNameInput.addKeyListener(new java.awt.event.KeyAdapter()
									  {
										public void keyTyped(java.awt.event.KeyEvent e)
										{
											m_oPollerNameInput.setBackground(java.awt.Color.white);
										}
										public void keyPressed(java.awt.event.KeyEvent e)
										{
											m_oPollerNameInput.setBackground(java.awt.Color.white);
										}
									  }
									 );
		Container contentPane = getContentPane();
		
		contentPane.add(groupPanel, BorderLayout.NORTH);
		contentPane.add(buttonPane, BorderLayout.SOUTH);


		setSize(400,300);
		setLocationRelativeTo(parent);

		
		
	}

    	public ModifyDistPoller(JFrame parent, String title, boolean modal, String groupName)
	{
		this(parent, modal, groupName);
		setTitle(title);
	}
	public ModifyDistPoller(JFrame parent, String title, boolean modal, String groupName, boolean isNew)
	{
		this(parent, title, modal, groupName);
		m_bNew = isNew;
	}
	
	
	JButton		m_oOkButton		= new JButton();
	JTextField	m_oPollerNameInput	= new JTextField();
	JTextField	m_oIPAddressInput	= new JTextField();
	JTextField	m_oFullNameInput	= new JTextField();
	JTextField	m_oDiscLimitInput	= new JTextField();

	JTextArea	m_oCommentsInput	= new JTextArea();

   

	class SymAction implements java.awt.event.ActionListener
	{
		public void actionPerformed(java.awt.event.ActionEvent event)
		{
			Object object = event.getSource();
			if (object == m_oOkButton)
			{
				String commentID = m_oCommentsInput.getText();
				if ( (commentID == null) || commentID.trim().equals("") )
					m_oCommentsInput.setText("Type your comment here:");

				String sId = m_oPollerNameInput.getText();
				if( (sId == null) || sId.trim().equals(""))
				{
					Toolkit.getDefaultToolkit().beep();
				        m_oPollerNameInput.setBackground(java.awt.Color.red);
					return;
				}
				try
				{
					if(m_bNew)
					{
						if(UserManager.m_oDP.containsKey(sId))
						{
							Toolkit.getDefaultToolkit().beep();
							m_oPollerNameInput.setBackground(java.awt.Color.red);
							return;
						}
						
						UserManager.add(UserManager.DP, m_oPollerNameInput.getText().trim());
						UserManager.m_sBuffer = m_oFullNameInput.getText();
						UserManager.m_sBuffer += ":" + m_oIPAddressInput.getText();
						UserManager.m_sBuffer+= ":" + m_oDiscLimitInput.getText();
						UserManager.m_sBuffer += ":"+ m_oCommentsInput.getText();
					
					}
					else
					{
						if((!sOldId.equals(sId)) && UserManager.m_oDP.containsKey(sId))
						{
							Toolkit.getDefaultToolkit().beep();
						      m_oPollerNameInput.setBackground(java.awt.Color.red);
							return;
						}
						UserManager.modify(UserManager.DP, sOldId);
						UserManager.m_sNewId = m_oPollerNameInput.getText().trim();
						UserManager.m_sBuffer= m_oFullNameInput.getText();
						UserManager.m_sBuffer+= ":" + m_oIPAddressInput.getText();
						UserManager.m_sBuffer+= ":" + m_oDiscLimitInput.getText();
						UserManager.m_sBuffer+= ":" + m_oCommentsInput.getText();
					
					}
				    setVisible(false);
					dispose();
				}
				catch (Exception e)
				{
					UserManager.cancel();
				}
			}
		}
	}

	class SymWindow extends java.awt.event.WindowAdapter
	{
		public void windowClosing(java.awt.event.WindowEvent event)
		{
			Object object = event.getSource();
			if (object == ModifyDistPoller.this)
			{
				try
				{
					setVisible(false);
					UserManager.cancel();
					dispose();
				}
				catch (Exception e)
				{
				}
			}
		}
	}

	public static void main(String[] args)
	{
				
		try
		{
			(new ModifyDistPoller(new JFrame(), true, "Name")).setVisible(true);
		}
		catch (Exception e)
		{
		}
	}
}
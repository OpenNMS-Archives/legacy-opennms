//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
package org.opennms.bb.eui.common;

/**
* This interface defines all the constants to be shared among
* all the submodules.
* <p>
*
* Example usage:
* <pre>
*	....
*	String str1 = IConstants.EMPTY_STRING;
*	String str2 = IConstants.EMPTY_STRING;
*	....
* </pre>
* When executed, both 'str1' and 'str2' will be "",
* but two unnecessary initializations of empty strings
* can be avoided, unlike in the following code:
* <pre>
*	....
*	String str1 = new String("");
*	String str2 = new String("");
*	....
* </pre>
* Or even in this code:
* <pre>
*	....
*	String str1 = "";
*	String str2 = "";
*	....
* </pre>
*
* @author	chitta
* @version	1.0
*/
public interface IConstants
{
	/** Constant: 
	* Defines an empty string, eliminates the creation of empty initialization strings
	*/
	public final static String	EMPTY_STRING		= "";

	/**
	* Constant: The performed operation failed
	*/
	public final static int		FAILED				= 0;

	/**
	* Constant: The performed operation succeeded
	*/
	public final static int		SUCCESS				= 1;

	/**
	* Constant: Defines an invalid value
	*/
	public final static int		INVALID_VALUE		= -1;

	/**
	* Constant: Junk values
	*/
	public final static int		JUNK				= -999;



	/**
	* Constant: Name of the TESS properties file
	*/
	public final static String	PROPERTIES_FILENAME	= "Ms.properties";
}

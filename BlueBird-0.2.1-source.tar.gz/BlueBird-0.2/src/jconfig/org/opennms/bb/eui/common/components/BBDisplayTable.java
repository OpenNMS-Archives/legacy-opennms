//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//

package org.opennms.bb.eui.common.components;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.text.*;
import javax.swing.table.*;
import javax.swing.event.*;

import java.util.Vector;

/**
 * BBDisplayTable extends JTable and has an attribute column and a value column 
 * It is used to display values only - values cannot be edited
 *
 * @author Sowmya
 *
 */
public class BBDisplayTable extends JTable 
{
	protected DefaultTableModel infoTableModel;

	int TABLE_WIDTH   = 350;
	int TABLE_HEIGHT  = 75;

	/**
	 * Initialize and set required table features
	 */
	protected void BBDisplayTableInit()
	{
		// set single selection
		setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

		// Do not allow reordering of columns
		getTableHeader().setReorderingAllowed(false);

		// Set selection colors
		setSelectionForeground(Color.black);
		setSelectionBackground(Color.white);

		// set column widths
		setTableDimension();

		// everytime data is changed, set table width
		// setDataVector() causes table column widths to change
		getModel().addTableModelListener(new TableModelListener()
		{
			public void tableChanged(TableModelEvent e)
			{
				if (e.getColumn() == e.ALL_COLUMNS && e.getType() == e.INSERT)
				{
					// set column widths
					Dimension curSize = getSize();
					setTableDimension(curSize.width, curSize.height);
				}
			}
		});
	}

	/**
	 * Creates the table
	 */
	public BBDisplayTable(Vector inpRowData, Vector inpColNames)
	{
		infoTableModel = new DefaultTableModel(inpRowData, inpColNames);
		setModel(infoTableModel);

		BBDisplayTableInit();
	}

	/**
	 * Sets the table column widths to the defaults
	 */
	public void setTableDimension()
	{
		setTableDimension(TABLE_WIDTH, TABLE_HEIGHT);
	}

	/**
	 * Sets the table column widths and the table height to the values
	 * passed in
	 */
	public void setTableDimension(int width, int height)
	{
		TableColumn column=null;

		int iAttribColWidth= width/2;
		int iValueColWidth = iAttribColWidth;

		int colWidths[] = {iAttribColWidth, iValueColWidth};

		for(int index=0; index < colWidths.length; index++)
		{
			column = getColumnModel().getColumn(index);

			column.setPreferredWidth(colWidths[index]);
			column.setMinWidth(colWidths[index]);
		}

		// store
		TABLE_WIDTH = width;
		TABLE_HEIGHT = height;

		int viewWidth = width + ((colWidths.length) * 
					(int)getIntercellSpacing().getWidth());

		// set a default viewport size
		setPreferredScrollableViewportSize(new Dimension(viewWidth, height));
	}

	/**
	 * Override the method in the parent class to set table column
	 * widths
	 */
	public void paintComponent(Graphics g)
	{
		// set column widths
		Dimension curSize = getSize();
		setTableDimension(curSize.width, curSize.height);

		super.paintComponent(g);
	}


	/**
	 * ignore key events
	 */
	protected void processKeyEvent(KeyEvent e)
	{
		return;
	}

	/**
	 * Consume and ignore mouse events
	 */
	protected void processMouseEvent(MouseEvent e)
	{
		e.consume();
		return;
	}

	/**
	 * Return the attached table model 
	 */
	public DefaultTableModel getTableModel()
	{
		return infoTableModel;
	}

}

//-------------------------------------------------------------------------------------------
//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

//--------------------------------------------------------------------------------------------

package org.opennms.bb.eui.admin.distpoller.configure.cals;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import javax.swing.table.*;
import javax.swing.event.*;

/**
 * The calendar table extends JTable and has the check box renderer and editor 
 * and for the status column
 */
class CalendarTable extends JTable
{
	CalendarTable(TableModel tm)
	{
		super(tm);

		setCellSelectionEnabled(true);
	}

	public TableCellRenderer getCellRenderer(int row, int col)
	{
		if (col == 1)
		{
			return new CalendarStatusCellRenderer();
		}

		else
			return super.getCellRenderer(row, col);

	}

	public TableCellEditor getCellEditor(int row, int col)
	{
		if (col == 1)
		{
			Component comp = (Component)getCellRenderer(row, 1);
			JCheckBox cb = ((CalendarStatusCellRenderer)comp).getCheckBox();
			return new DefaultCellEditor(cb);
		}

		else
			return super.getCellEditor(row, col);

	}
	
	class CalendarStatusCellRenderer extends DefaultTableCellRenderer
	{  
		JCheckBox cb;

		CalendarStatusCellRenderer()
		{
			cb = new JCheckBox();
			cb.setBackground(Color.white);
			cb.setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 5));
		}

		public Component getTableCellRendererComponent(
								JTable table, Object value,
								boolean isSelected,
								boolean hasFocus,
								int row, int col) 
		{
			boolean b = ((Boolean)value).booleanValue();
			cb.setSelected(b);

			return cb;
		}

		JCheckBox getCheckBox()
		{
			return cb;
		}
	}
}


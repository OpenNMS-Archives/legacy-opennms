//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
// Modification History:
// Oct 2000 - Changed the 'installKeyboardActions()' method of the
//            BBFileManipTableUI class  to account for the change to the
//            infrastructure for creating keyboard bindings in JDK 1.3 - Sowmya
//
//

package org.opennms.bb.eui.common.components;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.table.*;
import javax.swing.event.*;

import javax.swing.plaf.basic.BasicTableUI;
import javax.swing.plaf.ActionMapUIResource;

import java.util.Vector;

/**
 * BBFileManipTable is a table that visually indicates the row selected
 * <p>It allows the user to change the values in all the text columns and
 * provides a browse column for browsing the directories for the value
 * of the first column
 *
 * @author Sowmya
 *
 */
public class BBFileManipTable extends JTable
{
	protected BBManipTableModel infoTableModel;

	final static int TABLE_WIDTH   = 450;
	final static int TABLE_HEIGHT  = 300;

	public static int ARROW_COL    = 0;
	public static int BROWSE_COL   = 2;

	static int iLastEditingRow  = -1;
	static int iLastEditingCol  = -1;

	/**
	 * Creates the table - the input data is added with values
	 * for the first arrow column
	 */
	public void createTable(Vector inpRowData, Vector inpColNames)
	{
		// create the extra first column
		int iNumRows = inpRowData.size();
		int iNumCols = inpColNames.size();

		Vector rowData = new Vector(iNumRows);

		for (int iIndex=0; iIndex<iNumRows; iIndex++)
		{
			Vector rowVal = new Vector(iNumCols+2);
			
			rowVal.addElement(Boolean.FALSE);
			Vector temp = (Vector)inpRowData.elementAt(iIndex);
			rowVal.addElement(temp.elementAt(0));
			rowVal.addElement(Boolean.FALSE);

			int iSize = inpColNames.size();
			for (int iColIndex=1; iColIndex < iSize; iColIndex++)
			{
				Vector temp2 = (Vector)inpRowData.elementAt(iIndex);
				rowVal.addElement(temp2.elementAt(iColIndex));
			}

			rowData.addElement(rowVal);
		}

		Vector colNames = new Vector(iNumCols + 1);
		colNames.addElement(" ");
		colNames.addElement(inpColNames.elementAt(0));
		colNames.addElement(" ");

		for (int iIndex=1; iIndex < iNumCols; iIndex++)
		{
			colNames.addElement(inpColNames.elementAt(iIndex));
		}

		infoTableModel = new BBManipTableModel(rowData, colNames);
		setModel(infoTableModel);
	}

	/**
	 * Initialize the table features/elements
	 */
	void BBFileManipTableInit()
	{
		setUI(new BBFileManipTableUI());

		// set single selection
		setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

		setCellSelectionEnabled(true);

		// Do not allow reordering of columns
		getTableHeader().setReorderingAllowed(false);

		// Set selection colors
		setSelectionForeground(Color.black);
		setSelectionBackground(Color.white);

		// Do not show grid
		setShowHorizontalLines(true);
		setShowVerticalLines(false);

		// Attach a textfield cell editor to the 'Value' columns
		int iNumCols = getColumnCount();

		for (int iIndex=1; iIndex < iNumCols; iIndex++)
		{
			if (iIndex != BROWSE_COL)
			{
				BBTextField colText = new BBTextField();
				getColumnModel().getColumn(iIndex).setCellEditor(new BBColumnEditor(colText));
			}
		}

		// Attach a cell renderer for the first(arrow) column
		getColumnModel().getColumn(ARROW_COL).setCellRenderer(new BBArrowRenderer());

		// Attach a cell renderer for the browse column
		getColumnModel().getColumn(BROWSE_COL).setCellRenderer(new BBBrowseRenderer());

		// Attach a cell editor for the browse column
		getColumnModel().getColumn(BROWSE_COL).setCellEditor(new BBBrowseEditor());

		// Track the list selection to set focus to the editor component
		getSelectionModel().addListSelectionListener(new ListSelectionListener()
		{
			public void valueChanged(ListSelectionEvent e)
			{
				int iSelectedRow = getSelectedRow();
				int iSelectedCol = getSelectedColumn();
				int iRowCount    = getRowCount();

				for (int iIndex=0; iIndex < iRowCount; iIndex++)
				{
					setValueAt(new Boolean(iIndex == iSelectedRow), iIndex, ARROW_COL);
					setValueAt(new Boolean(iIndex == iSelectedRow), iIndex, BROWSE_COL);
				}
				repaint();

				ListSelectionModel lsm = (ListSelectionModel)e.getSource();

				if(!(lsm.isSelectionEmpty()))
				{
					if (iSelectedCol > 0)
					{
						editCellAt(iSelectedRow, iSelectedCol);
						getEditorComponent().requestFocus();
					}
				}
				else // selection empty
				{
					for (int iIndex=0; iIndex < iRowCount; iIndex++)
					{
						setValueAt(Boolean.FALSE, iIndex, ARROW_COL);
						setValueAt(Boolean.FALSE, iIndex, BROWSE_COL);
					}

					iLastEditingRow = -1;
					iLastEditingCol = -1;

					repaint();
				}
			}
		});

		getColumnModel().addColumnModelListener(new TableColumnModelListener()
		{
			public void columnSelectionChanged(ListSelectionEvent e)
			{
				ListSelectionModel lsm = (ListSelectionModel)e.getSource();

				if(!(lsm.isSelectionEmpty()))
				{
					int iSelectedRow = getSelectedRow();
					int iSelectedCol = getSelectedColumn();


					if (iSelectedCol > 0 && iSelectedRow > -1)
					{
						editCellAt(iSelectedRow, iSelectedCol);
						getEditorComponent().requestFocus();
					}
				}
			}

			public void columnAdded(TableColumnModelEvent e) { }

			public void columnMoved(TableColumnModelEvent e) { }

			public void columnRemoved(TableColumnModelEvent e) { }

			public void columnMarginChanged(ChangeEvent e) { }

		});

		setTableColumnWidths();
	}

	/**
	 * Create the table with just the columns(with no data rows) -
	 * the input data is added with value for the first arrow column
	 */
	public BBFileManipTable(Vector inpColNames)
	{
		int iNumCols = inpColNames.size();

		Vector colNames = new Vector(iNumCols + 1);
		colNames.addElement(" ");
		colNames.addElement(inpColNames.elementAt(0));
		colNames.addElement(" ");

		for (int iIndex=1; iIndex < iNumCols; iIndex++)
		{
			colNames.addElement(inpColNames.elementAt(iIndex));
		}

		infoTableModel = new BBManipTableModel(colNames);
		setModel(infoTableModel);

		BBFileManipTableInit();
	}

	/**
	 * Creates the table
	 */
	public BBFileManipTable(Vector inpRowData, Vector inpColNames)
	{
		createTable(inpRowData, inpColNames);
		BBFileManipTableInit();
	}

	/**
 	 * Updates UI to set it back to BBFileManipTableUI
 	 */
	public void updateUI()
	{
		setUI(new BBFileManipTableUI());
	}

	/**
	 * Clear all the selections in the table
	 */
	public void clearSelection()
	{
		super.clearSelection();
		repaint();
	}

	/**
	 * Sets the column widths of the columns in the table to the 
	 * the viewport width / number of columns or length of the column name 
	 * whichever is greater
	 *
	 * <p>Also sets the table scrollpane viewport accordingly
	 */
	public void setTableColumnWidths()
	{
		setTableColumnWidths(getPreferredScrollableViewportSize().width, TABLE_HEIGHT);
	}


	/**
	 * Sets the column widths of the columns in the table to the 
	 * the passed width / number of columns or length of the column name 
	 * whichever is greater
	 *
	 * <p>Also sets the table scrollpane viewport accordingly
	 */
	public void setTableColumnWidths(int iWidth, int iHeight)
	{
		int	iTableWidth     = 0;
		int	iTabCols        = getColumnCount();
		int	DEF_WIDTH	= iWidth/iTabCols;

		int iIntercellWidth = (int) getIntercellSpacing().getWidth();

		TableColumn column=null;

		column = getColumnModel().getColumn(ARROW_COL);
		column.setPreferredWidth(20);
		column.setMinWidth(20);
		column.setMaxWidth(20);
		iTableWidth += 20;

		column = getColumnModel().getColumn(BROWSE_COL);
		column.setPreferredWidth(20);
		column.setMinWidth(20);
		column.setMaxWidth(20);
		iTableWidth += 20;

		for(int iIndex=0; iIndex < iTabCols; iIndex++)
		{
			if (iIndex == ARROW_COL || iIndex == BROWSE_COL)
				continue;

			column = getColumnModel().getColumn(iIndex);

			TableCellRenderer renderer = column.getHeaderRenderer();
			if (renderer == null)
			{
				renderer = new BBDefaultTableHeaderRenderer();
				column.setHeaderRenderer(renderer);
				
				setHeaderToolTips();
			}

			Component comp = renderer.getTableCellRendererComponent( this, column.getHeaderValue(), false, false, 0, 0);

			int headerWidth = comp.getPreferredSize().width;

			if (headerWidth < DEF_WIDTH)
				headerWidth = DEF_WIDTH;

			if (iIndex == 1) // File name column
				headerWidth = 100;

			column.setPreferredWidth(headerWidth);
			column.setMinWidth(headerWidth);

			iTableWidth += headerWidth;
		}

		iTableWidth += (iIntercellWidth * (iTabCols+2));

		if (iTableWidth > 600)
			iTableWidth = 600;

		setPreferredScrollableViewportSize(
				new Dimension(iTableWidth, iHeight));
	}

	/**
	 * Does nothing - sub-classes will need  to override this method to
	 * set tooltips if desired
	 */
	protected void setHeaderToolTips()
	{
	}

	/**
	 * Selects the first column of the first row
	 */
	public boolean setInitialFocus()
	{
		if (getRowCount() <= 0)
			return false;

		iLastEditingRow = 0;
		iLastEditingCol = 1;

		selectCellAt(iLastEditingRow, iLastEditingCol);
		return true;
	}

	/**
 	 * Selects the cell (row, col)
 	 */
	public void selectCellAt(int row, int col)
	{
		setRowSelectionInterval(row, row);
		setColumnSelectionInterval(col, col);
	}

	/** 
	 * Adds the vector as the last row of the table
	 */
	public void addRow(Vector data)
	{
		pasteRow(data);
	}

	/** 
	 * Inserts the vector next to the currently selected row
	 */
	public void pasteRow(Vector data)
	{
		int iRowLoc;

		int iCurSelectedRow = getSelectedRow();
		if (iCurSelectedRow <= -1)
			iRowLoc = getRowCount();
		else
			iRowLoc = iCurSelectedRow + 1;

		int iSize    = data.size();
		int	iIndex	 = 0;

		Vector newData = new Vector(iSize+2);

		// arrow
		newData.add(Boolean.FALSE);

		//
		newData.add(data.elementAt(iIndex++));

		// browse
		newData.add(Boolean.FALSE);

		for(; iIndex < iSize; iIndex++)
		{
			newData.add(data.elementAt(iIndex));
		}

		// Insert
		infoTableModel.insertRow(iRowLoc, newData);

		// Select new row
		setRowSelectionInterval(iRowLoc, iRowLoc);

		// Select first column
		setColumnSelectionInterval(1, 1);
		
		//
		iLastEditingRow = iRowLoc;
		iLastEditingCol = 1;
	}

	/**
	 * Removes the row# iRow
	 */
	public void removeRow(int iRow)
	{
		int iSelRow;
		int iNumRows = getRowCount();

		// set row to be selected next
		if (iRow == (iNumRows-1)) // last row
			iSelRow = iRow - 1;
		else
			iSelRow = iRow;

		// Remove
		infoTableModel.removeRow(iRow);

		// Select next row
		setRowSelectionInterval(iSelRow, iSelRow);

		// Select first column
		setColumnSelectionInterval(1, 1);
		
		//
		iLastEditingRow = iSelRow;
		iLastEditingCol = 1;
	}


	/**
	 * Handles the key events and action for the tab key
	 */
	protected void processKeyEvent(KeyEvent e)
	{
		final int	MOVE_UP = 1;
		final int	MOVE_DOWN = -1;

		int			iInternalCode=0;
		int			code = e.getKeyCode();

		if (code == KeyEvent.VK_TAB)
		{
			String mode = e.getKeyModifiersText(e.getModifiers());

			if(mode.equals("Shift"))
				shiftTabToNextCell();
			else
				tabToNextCell();
		}
		else
			super.processKeyEvent(e);

	}

	/**
	 * Move to the next cell on tab
	 */
	private void tabToNextCell()
	{
		if (iLastEditingRow < 0) // Ignore the header
		{
			if (getRowCount() <= 0 || getColumnCount() <= 0)
				return;

			iLastEditingRow = 0;
			iLastEditingCol = 1;

			selectCellAt(iLastEditingRow, iLastEditingCol);
			return;
		}

		if (iLastEditingCol < getColumnCount()-1)
		{
			iLastEditingCol++;

			selectCellAt(iLastEditingRow, iLastEditingCol);
		}
		else //last column
		{
			if (iLastEditingRow < getRowCount()-1)
			{
				iLastEditingRow++;
				iLastEditingCol = 1;

				selectCellAt(iLastEditingRow, iLastEditingCol);
			}
			else  //last column and last row
			{
				iLastEditingRow = 0;
				iLastEditingCol = 1;

				selectCellAt(iLastEditingRow, iLastEditingCol);
			}
		}
	}

	/**
	 * Move to the previous cell on a shift+tab
	 */
	private void shiftTabToNextCell()
	{
		if (iLastEditingCol > 1)
		{
			iLastEditingCol--;
			selectCellAt(iLastEditingRow, iLastEditingCol);
		}
		else //first value column
		{
			if (iLastEditingRow > 0)
			{
				iLastEditingRow--;
				iLastEditingCol = 1;
				selectCellAt(iLastEditingRow, iLastEditingCol);
			}
			else
			{
				clearSelection();

				iLastEditingRow = -1;
				iLastEditingCol = -1;
			}
		}
	}

	/**
	 * Returns the attached table model
	 */
	public BBManipTableModel getTableModel()
	{
		return infoTableModel;
	}

	/**
 	 * <pre>Returns the column names 
	 * Note: The actual table data has an extra column for the 
	 *       arrow. This is not returned in the result
	 * </pre>
 	 */
	public Vector getColumns()
	{
		Vector outCols = new Vector();

		int iColCount = getColumnCount();

		for (int iIndex=0; iIndex<iColCount; iIndex++)
		{
			if (iIndex != ARROW_COL && iIndex != BROWSE_COL)
				outCols.add(getColumnName(iIndex));
		}

		return outCols;
	}
		

	/**
 	 * <pre>Returns the data  
	 * Note: The actual table data has an extra column for the 
	 *       arrow. This is not returned in the result
	 * </pre>
 	 */
	public Vector getData()
	{
		Vector actualData = getTableModel().getDataVector();

		Vector outData = new Vector();

		int iRowCount = getRowCount();
		int iColCount = getColumnCount();

		for (int iIndex=0; iIndex<iRowCount; iIndex++)
		{
			Vector temp = new Vector();

			Vector actualTemp = (Vector)actualData.elementAt(iIndex);

			for (int iColIndex=0; iColIndex < iColCount; iColIndex++)
			{
				if (iColIndex != ARROW_COL && iColIndex != BROWSE_COL)
					temp.add(actualTemp.elementAt(iColIndex));
			}

			outData.add(temp);
		}
		
		return outData;
	}

	/**
	 * Returns true by default. Sub-classes override this method if
	 * additional validation is required (for example before a save)
	 */
	public boolean validateValues(String panelName)
	{
		return true;
	}
}


/**
 * The BBFileManipTableUI extends the BasicTableUI to handle up/down/escape
 * key actions and the mouse actions so as to dictate move between cells and
 * also validate the cell values on move from a cell 
 */
class BBFileManipTableUI extends BasicTableUI
{
	private class BBFileManipKeyAction extends AbstractAction
	{
		protected BBFileManipKeyAction(String name)
		{
			super(name);
		}

		public void actionPerformed(ActionEvent e)
		{
			BBFileManipTable infoTable = (BBFileManipTable)e.getSource();
			String command		 = (String)getValue(Action.NAME);
			ListSelectionModel rsm = infoTable.getSelectionModel();

			boolean bPerformAction = false;

			if (command.equals("Escape"))
			{
            			final CellEditor editor = infoTable.getCellEditor(); 

            			if (editor != null && editor instanceof BBColumnEditor)
				{
					((BBColumnEditor)editor).bEditingCancelled=true;
					editor.cancelCellEditing();
				}
			}
			else
			{
				boolean bPrevCellOK=false;

           			CellEditor editor = infoTable.getCellEditor();
				Component editorComp=null;

           			if (editor != null && editor instanceof BBColumnEditor)
				{
					editorComp = ((BBColumnEditor)editor).getComponent();

					if (editorComp instanceof BBTextField)
					{
						if (!((BBTextField)editorComp).isValid())
							infoTable.requestFocus();
						else
							bPrevCellOK = true;
					}
					else
						bPrevCellOK = true; // if not textfield, don't bother
				}

            			if ((infoTable.iLastEditingRow != -1) && (infoTable.iLastEditingCol != -1)) 
				{
					if (bPrevCellOK  || editorComp == null)
					{
						bPerformAction = true;
					}
				}

            			else if (infoTable.iLastEditingRow == -1 || infoTable.iLastEditingCol == -1) 
				{
					if (infoTable.getRowCount() <= 0 || 
										infoTable.getColumnCount() <= 0)
						return;

					bPerformAction = true;
				}
			
			}

			// If previous cell not ok, do not perform action
			if (!bPerformAction)
				return;
			
			if (command.equals("NextRow"))
			{
				if (infoTable.iLastEditingRow < infoTable.getRowCount()-1)
				{
					infoTable.iLastEditingRow++;
					infoTable.iLastEditingCol = 1;
					infoTable.selectCellAt(infoTable.iLastEditingRow, 1);
				}
	
			}

			else if (command.equals("PrevRow"))
			{
				if (infoTable.iLastEditingRow > 0)
				{
					infoTable.iLastEditingRow--;
					infoTable.iLastEditingCol = 1;
					infoTable.selectCellAt(infoTable.iLastEditingRow, 1);
				}
			}
	
			else if (command.equals("NextCol"))
			{
				if (infoTable.iLastEditingCol < infoTable.getColumnCount()-1)
				{
					infoTable.iLastEditingCol++;
					infoTable.selectCellAt(infoTable.iLastEditingRow, infoTable.iLastEditingCol);
				}
			}

			else if (command.equals("PrevCol"))
			{
				if (infoTable.iLastEditingCol > 1)
				{
					infoTable.iLastEditingCol--;
					infoTable.selectCellAt(infoTable.iLastEditingRow, infoTable.iLastEditingCol);
				}
			}

			else if (command.equals("PageUp"))
			{
				Dimension delta = infoTable.getParent().getSize(); 

				int start = rsm.getAnchorSelectionIndex(); 
				Rectangle r = infoTable.getCellRect(start, 0, true); 
				r.y +=  -delta.height; 
				int newRow = infoTable.rowAtPoint(r.getLocation()); 
				if(newRow == -1 && infoTable.getRowCount() > 0)
				{
					newRow = 0;
				}

				infoTable.iLastEditingRow = newRow;
				infoTable.iLastEditingCol = 1;
				infoTable.selectCellAt(infoTable.iLastEditingRow, infoTable.iLastEditingCol);

			}

			else if (command.equals("PageDown"))
			{
				Dimension delta = infoTable.getParent().getSize(); 

				int start = rsm.getAnchorSelectionIndex(); 
				Rectangle r = infoTable.getCellRect(start, 0, true); 
				r.y += delta.height; 
				int newRow = infoTable.rowAtPoint(r.getLocation()); 
				if(newRow == -1 && infoTable.getRowCount() > 0)
				{ 
					newRow = infoTable.getRowCount() - 1; 
				}

				infoTable.iLastEditingRow = newRow;
				infoTable.iLastEditingCol = 1;
				infoTable.selectCellAt(infoTable.iLastEditingRow, infoTable.iLastEditingCol);

			}
		}
	}

	protected void installKeyboardActions()
	{
		ActionMap map = getActionMap();

		SwingUtilities.replaceUIActionMap(table, map);
		InputMap inputMap = getInputMap(JComponent.
				  WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
		SwingUtilities.replaceUIInputMap(table, JComponent.
					   WHEN_ANCESTOR_OF_FOCUSED_COMPONENT,
					   inputMap);
	}

	private InputMap getInputMap(int condition)
	{
		if (condition == JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT)
		{
			return (InputMap)UIManager.get("Table.ancestorInputMap");
		}
		return null;
	}

	private ActionMap getActionMap()
	{
		ActionMap map = (ActionMap)UIManager.get("Table.actionMap");

		map = changeActionMap(map);

		return map;
	}

	private ActionMap changeActionMap(ActionMap map)
	{
		if (map == null)
			map = new ActionMapUIResource();

		map.put("selectNextColumn", new BBFileManipKeyAction("NextCol"));
		map.put("selectPreviousColumn", new BBFileManipKeyAction("PrevCol"));
		map.put("selectNextRow", new BBFileManipKeyAction("NextRow"));
		map.put("selectPreviousRow", new BBFileManipKeyAction("PrevRow"));
		map.put("cancel", new BBFileManipKeyAction("Escape"));

		map.put("scrollUpChangeSelection", new BBFileManipKeyAction("PageUp"));
		map.put("scrollDownChangeSelection", new BBFileManipKeyAction("PageDown"));
		return map;
	}

	protected MouseInputListener createMouseInputListener()
	{
		return new BBFMouseInputHandler();
	}

	private class BBFMouseInputHandler implements MouseInputListener 
	{
        	// Component recieving mouse events during editing. 
		// May not be editorComponent.
        	private Component dispatchComponent;

        	private void setDispatchComponent(MouseEvent e) 
		{ 
			BBFileManipTable table = (BBFileManipTable)e.getSource();
            		Component editorComponent = table.getEditorComponent();
            		Point p = e.getPoint();
            		Point p2 = SwingUtilities.convertPoint(table, p, editorComponent);
            		dispatchComponent = 
				SwingUtilities.getDeepestComponentAt(editorComponent, p2.x, p2.y);
        	}

        	private boolean repostEvent(MouseEvent e) 
		{ 
            		if (dispatchComponent == null) 
                		return false; 
			
			BBFileManipTable table = (BBFileManipTable)e.getSource();
            		MouseEvent e2 = 
				SwingUtilities.convertMouseEvent(table, e, dispatchComponent);
            		dispatchComponent.dispatchEvent(e2); 
        	    	return true; 
        	}

        	public void mouseClicked(MouseEvent e) {}

        	public void mousePressed(MouseEvent e) 
		{
	    		if (!SwingUtilities.isLeftMouseButton(e)) 
			{
	        		return;
	    		}

			BBFileManipTable table = (BBFileManipTable)e.getSource();

            		Point p = e.getPoint();
            		int row = table.rowAtPoint(p);
            		int column = table.columnAtPoint(p);
			boolean bPrevCellOK=false;

           		CellEditor editor = table.getCellEditor();
			Component editorComp=null;

           		if (editor != null && editor instanceof BBColumnEditor)
			{
				editorComp = ((BBColumnEditor)editor).getComponent();

				if (editorComp instanceof BBTextField)
				{
					if (!((BBTextField)editorComp).isValid())
						table.requestFocus();
					else
						bPrevCellOK = true;
				}
				else
					bPrevCellOK = true; // if not textfield, don't bother
			}

            		if ((column != -1) && (row != -1)) 
			{
				if (bPrevCellOK  || editorComp == null)
				{
					table.iLastEditingRow = row;
					table.iLastEditingCol = column;

					table.selectCellAt(table.iLastEditingRow, table.iLastEditingCol);
					if (table.iLastEditingCol == table.BROWSE_COL)
					{
						table.clearSelection();
						try
						{
               						setDispatchComponent(e); 
               						repostEvent(e); 
						}
						catch(Exception ex) {}

					}
				}
			}
            		else if (column == -1 || row == -1) 
			{
				if (table.getRowCount() <= 0 || table.getColumnCount() <= 0)
					return;

				table.iLastEditingRow = 0;
				table.iLastEditingCol = 1;

				table.selectCellAt(table.iLastEditingRow, table.iLastEditingCol);
			}

			e.consume();
        	}

        	public void mouseReleased(MouseEvent e) { }

        	public void mouseEntered(MouseEvent e) {}

        	public void mouseExited(MouseEvent e) {}

        	public void mouseMoved(MouseEvent e) {}

        	public void mouseDragged(MouseEvent e) {}

	}
}

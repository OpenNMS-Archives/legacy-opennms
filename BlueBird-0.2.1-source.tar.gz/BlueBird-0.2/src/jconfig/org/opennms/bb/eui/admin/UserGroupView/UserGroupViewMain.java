//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
package org.opennms.bb.eui.admin.UserGroupView;

import java.awt.*;
import java.util.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.tree.*;
import javax.swing.event.*;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import org.opennms.bb.eui.common.components.AboutDialog;
import org.opennms.bb.eui.admin.interfaces.AdminTool;
import org.opennms.bb.eui.admin.UserGroupView.Main.*;
import org.opennms.bb.eui.admin.UserGroupView.Wizard.*;
import org.opennms.bb.eui.admin.UserGroupView.RuleBuilder.*;

/**
 *
 * @author Chitta
 * 
 * Modifications:
 * Changed the deprecated 'getComponentAtIndex(int i)' method in 'JPopupMenu;
 * to 'getComponent(int i)' for the move to JDK 1.3 - Sowmya
 */
public class UserGroupViewMain extends JFrame implements AdminTool
{
	public JTextField			m_oStatusText		= new JTextField();
	public DragTree			m_oUsersTree		= null;
	public static DragDropTree	m_oGroupsTree		= null;
	public static DropTree		m_oViewsTree		= null;

	DefaultTreeModel	m_oTreeModel		= null;
	TreeSelectionModel	m_oSelectionModel	= null;
	JPopupMenu			m_oPopup			= null;
	MouseListener		m_oPopupListener	= new PopupListener();
	TreeModelListener	m_oTreeModelListener= new UITreeModelListener();
/*****************************************************************
	boolean				m_bIsExpansionEvent = false;
*****************************************************************/

	GridBagLayout		m_oGridBag			= new GridBagLayout();
	GridBagConstraints	m_oGridBagConstraints= new GridBagConstraints();

	/*
	 * Used for addNotify check:
	 */
	boolean		m_bComponentsAdjusted	= false;


	public UserGroupViewMain()
	{
	}

	public void start(String sUserId)
	{
		getContentPane().setLayout(m_oGridBag);
		setVisible(false);
		setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);

		UserManager.init();

		loadUsers();
		loadGroups();
		loadViews();

		m_oTreeModel		= (DefaultTreeModel)m_oUsersTree.getModel();
		m_oSelectionModel	= m_oUsersTree.getSelectionModel();
		m_oUsersTree.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
		m_oGroupsTree.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
		m_oViewsTree.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);

		m_oUsersTree.addTreeSelectionListener(
									new TreeSelectionListener()
									{
										public void valueChanged(TreeSelectionEvent e)
										{
											if(e.getNewLeadSelectionPath()!=null)
											{
												UserManager.m_sOldId = e.getNewLeadSelectionPath().getLastPathComponent().toString();
											}
											if( m_oSelectionModel != m_oUsersTree.getSelectionModel())
											{
												m_oSelectionModel.clearSelection();
												m_oSelectionModel	= m_oUsersTree.getSelectionModel();
												m_oTreeModel		= (DefaultTreeModel)m_oUsersTree.getModel();
											}
										}
									});
		m_oGroupsTree.addTreeSelectionListener(
									new TreeSelectionListener()
									{
										public void valueChanged(TreeSelectionEvent e)
										{
											if(e.getNewLeadSelectionPath()!=null)
											{
												UserManager.m_sOldId = e.getNewLeadSelectionPath().getLastPathComponent().toString();
											}
											if( m_oSelectionModel != m_oGroupsTree.getSelectionModel())
											{
												m_oSelectionModel.clearSelection();
												m_oSelectionModel	= m_oGroupsTree.getSelectionModel();
												m_oTreeModel		= (DefaultTreeModel)m_oGroupsTree.getModel();
											}
										}
									});
		m_oViewsTree.addTreeSelectionListener(
									new TreeSelectionListener()
									{
										public void valueChanged(TreeSelectionEvent e)
										{
											if(e.getNewLeadSelectionPath()!=null)
											{
												UserManager.m_sOldId = e.getNewLeadSelectionPath().getLastPathComponent().toString();
											}
											if( m_oSelectionModel != m_oViewsTree.getSelectionModel())
											{
												m_oSelectionModel.clearSelection();
												m_oSelectionModel	= m_oViewsTree.getSelectionModel();
												m_oTreeModel		= (DefaultTreeModel)m_oViewsTree.getModel();
											}
										}
									});

/*****************************************************************
		m_oGroupsTree.addTreeWillExpandListener(
									new TreeWillExpandListener ()
									{
										public void treeWillExpand(TreeExpansionEvent e)
													throws ExpandVetoException
										{
											if(!m_bIsExpansionEvent)
											{
												throw new ExpandVetoException(e);
											}
										}

										public void treeWillCollapse(TreeExpansionEvent e)
													throws ExpandVetoException
										{
											if(!m_bIsExpansionEvent)
											{
												throw new ExpandVetoException(e);
											}
										}
									});
		m_oViewsTree.addTreeWillExpandListener(
									new TreeWillExpandListener ()
									{
										public void treeWillExpand(TreeExpansionEvent e)
													throws ExpandVetoException
										{
											if(!m_bIsExpansionEvent)
											{
												throw new ExpandVetoException(e);
											}
										}

										public void treeWillCollapse(TreeExpansionEvent e)
													throws ExpandVetoException
										{
											if(!m_bIsExpansionEvent)
											{
												throw new ExpandVetoException(e);
											}
										}
									});
*****************************************************************/

		addWindowListener(new WindowAdapter()
						  { 
							public void windowClosing(WindowEvent e)
							{
								if(UserManager.m_bUpdated)
								{
									String sSlash = System.getProperty("file.separator");
									String sMsg = "Configurations have not been saved. Save now?";
									int optVal = JOptionPane.showConfirmDialog(UserGroupViewMain.this.getContentPane(),
																			   sMsg,
																			   "Save Configuration...",
																			   JOptionPane.YES_NO_OPTION,
																			   JOptionPane.WARNING_MESSAGE,
																			   new ImageIcon("data/images/lightbulb.gif"));
									if(optVal==JOptionPane.YES_OPTION)
									{
										UserManager.save();
										dispose();
									}
									else if(optVal==JOptionPane.NO_OPTION)
									{
										UserManager.m_bUpdated = false;
										dispose();
									}
								}
								else
								{
									dispose();
								}
							}
						  }
						 );
		addMenuBar();
		addToolBar();
		addStatusBar();
		addPopupMenu();

		setTitle("Users, User Groups and Views Configuration");
		setResizable(true);
		setVisible(true);
		pack();
	}
	
	class PopupListener extends MouseAdapter implements ActionListener
	{
		private int		x			= -1,
						y			= -1;
		private Object	m_oSource	= null;

		public void actionPerformed(ActionEvent e)
		{
			/*************************************
			if(e.getActionCommand().equals("Expand"))
			{
				expand();
			}
			*************************************/
			if(e.getActionCommand().equals("Cut"))
			{
				cut();
			}
			else if(e.getActionCommand().equals("Copy"))
			{
				copy();
			}
			else if(e.getActionCommand().equals("Paste"))
			{
				paste();
			}
			else if(e.getActionCommand().equals("Rename"))
			{
				TreePath oPath =  m_oSelectionModel.getSelectionPath();
				if(oPath.getPathCount() < 1)
				{
					return;
				}
				if(m_oSelectionModel == m_oUsersTree.getSelectionModel())
				{
					m_oUsersTree.setEditable(true);
					m_oUsersTree.startEditingAtPath(oPath);
				}
				else if(m_oSelectionModel == m_oGroupsTree.getSelectionModel())
				{
					m_oGroupsTree.setEditable(true);
					m_oGroupsTree.startEditingAtPath(oPath);
				}
				else if(m_oSelectionModel == m_oViewsTree.getSelectionModel())
				{
					m_oViewsTree.setEditable(true);
					m_oViewsTree.startEditingAtPath(oPath);
				}
			}
			else if(e.getActionCommand().equals("Property"))
			{
				clickAction(new MouseEvent((Component)m_oSource,0,0,0,x,y,2,false));
			}
		}

		public void mouseClicked(MouseEvent e)
		{
			//clickAction(e);
		}

		public void mousePressed(MouseEvent e)
		{
			if(m_oUsersTree.isEditable())
			{
				if(m_oUsersTree.isEditing())
				{
					m_oUsersTree.stopEditing();
				}
				m_oUsersTree.setEditable(false);
			}
			else if(m_oGroupsTree.isEditable())
			{
				if(m_oGroupsTree.isEditing())
				{
					m_oGroupsTree.stopEditing();
				}
				m_oGroupsTree.setEditable(false);
			}
			else if(m_oViewsTree.isEditable())
			{
				if(m_oViewsTree.isEditing())
				{
					m_oViewsTree.stopEditing();
				}
				m_oViewsTree.setEditable(false);
			}
			popupAction(e);
		}

		public void mouseReleased(MouseEvent e)
		{
			popupAction(e);
		}

		void clickAction(MouseEvent e)
		{
			if (e.getClickCount()>1)
			{
				Point					pLocation	= new Point(e.getX(),e.getY());

				if(e.getSource() == m_oUsersTree)
				{
					DefaultMutableTreeNode	oTreeNode = m_oUsersTree.getTreeNode(pLocation);
					if(oTreeNode != null)
					{
						try
						{
							(new ModifyUser(UserGroupViewMain.this, true, oTreeNode.toString())).setVisible(true);
							if(!UserManager.m_sNewId.equals(""))
							{
								oTreeNode.setUserObject(UserManager.m_sNewId);
								//((DefaultTreeModel)m_oUsersTree.getModel()).reload(oTreeNode);
								((DefaultTreeModel)m_oUsersTree.getModel()).nodeChanged(oTreeNode);
							}
						}
						catch (Exception exc)
						{
						}
					}
				}
				else if(e.getSource() == m_oGroupsTree)
				{
					DefaultMutableTreeNode	oTreeNode = m_oGroupsTree.getTreeNode(pLocation);
					if(oTreeNode != null)
					{
						try
						{
							if(((DefaultMutableTreeNode)oTreeNode.getParent()).isRoot())
							{
								(new ModifyGroup(UserGroupViewMain.this, true, oTreeNode.toString())).setVisible(true);
								if(!UserManager.m_sNewId.equals(""))
								{
									oTreeNode.setUserObject(UserManager.m_sNewId);
									((DefaultTreeModel)m_oGroupsTree.getModel()).nodeChanged(oTreeNode);
								}
							}
							else
							{
								(new ModifyUser(UserGroupViewMain.this, true, oTreeNode.toString())).setVisible(true);
								if(!UserManager.m_sNewId.equals(""))
								{
									DefaultMutableTreeNode oUsers	= (DefaultMutableTreeNode)m_oUsersTree.getModel().getRoot();
									for(Enumeration en=oUsers.children(); en.hasMoreElements(); )
									{
										DefaultMutableTreeNode temp = (DefaultMutableTreeNode)en.nextElement();
										if(temp.toString().equals(oTreeNode.toString()))
										{
											oTreeNode = temp;
											oTreeNode.setUserObject(UserManager.m_sNewId);
											((DefaultTreeModel)m_oUsersTree.getModel()).reload(oTreeNode);
											((DefaultTreeModel)m_oUsersTree.getModel()).nodeChanged(oTreeNode);
											break;
										}
									}
								}
							}
						}
						catch (Exception exc)
						{
						}
					}
				}
				else if(e.getSource() == m_oViewsTree)
				{
					DefaultMutableTreeNode	oTreeNode = m_oViewsTree.getTreeNode(pLocation);
					if(oTreeNode != null)
					{
						try
						{
							if(((DefaultMutableTreeNode)oTreeNode.getParent()).isRoot())
							{
								(new ModifyView(UserGroupViewMain.this, true, oTreeNode.toString())).setVisible(true);
								if(!UserManager.m_sNewId.equals(""))
								{
									oTreeNode.setUserObject(UserManager.m_sNewId);
									((DefaultTreeModel)m_oViewsTree.getModel()).nodeChanged(oTreeNode);
								}
							}
							else if(UserManager.m_oUsers.containsKey(oTreeNode.toString())) // that means User node
							{
								(new ModifyUser(UserGroupViewMain.this, true, oTreeNode.toString())).setVisible(true);
								if(!UserManager.m_sNewId.equals(""))
								{
									DefaultMutableTreeNode oUsers	= (DefaultMutableTreeNode)m_oUsersTree.getModel().getRoot();
									for(Enumeration en=oUsers.children(); en.hasMoreElements(); )
									{
										DefaultMutableTreeNode temp = (DefaultMutableTreeNode)en.nextElement();
										if(temp.toString().equals(oTreeNode.toString()))
										{
											oTreeNode = temp;
											oTreeNode.setUserObject(UserManager.m_sNewId);
											((DefaultTreeModel)m_oUsersTree.getModel()).reload(oTreeNode);
											((DefaultTreeModel)m_oUsersTree.getModel()).nodeChanged(oTreeNode);
											break;
										}
									}
								}
							}
							else
							{
								(new ModifyGroup(UserGroupViewMain.this, true, oTreeNode.toString())).setVisible(true);
								if(!UserManager.m_sNewId.equals(""))
								{
									DefaultMutableTreeNode oGroups	= (DefaultMutableTreeNode)m_oGroupsTree.getModel().getRoot();
									for(Enumeration en=oGroups.children(); en.hasMoreElements(); )
									{
										DefaultMutableTreeNode temp = (DefaultMutableTreeNode)en.nextElement();
										if(temp.toString().equals(oTreeNode.toString()))
										{
											oTreeNode = temp;
											oTreeNode.setUserObject(UserManager.m_sNewId);
											((DefaultTreeModel)m_oGroupsTree.getModel()).nodeChanged(oTreeNode);
											break;
										}
									}
								}
							}
						}
						catch (Exception exc)
						{
						}
					}
				}
			}
		}

		void popupAction(MouseEvent e)
		{
			if (e.isPopupTrigger())
			{
				Point					pLocation	= new Point(e.getX(),e.getY());
				boolean					bPopup = false;

				if(e.getSource() == m_oUsersTree)
				{
					DefaultMutableTreeNode	oTreeNode = m_oUsersTree.getTreeNode(pLocation);
					if(oTreeNode != null)
					{
						bPopup = true;
						((DefaultTreeSelectionModel)m_oUsersTree.getSelectionModel()).clearSelection();
						((DefaultTreeSelectionModel)m_oUsersTree.getSelectionModel()).setSelectionPath(new TreePath(oTreeNode.getPath()));
					}
				}
				else if(e.getSource() == m_oGroupsTree)
				{
					DefaultMutableTreeNode	oTreeNode = m_oGroupsTree.getTreeNode(pLocation);
					if(oTreeNode != null)
					{
						bPopup = true;
						((DefaultTreeSelectionModel)m_oGroupsTree.getSelectionModel()).clearSelection();
						TreePath oPath = new TreePath(oTreeNode.getPath());
						((DefaultTreeSelectionModel)m_oGroupsTree.getSelectionModel()).setSelectionPath(oPath);
						/***************************************************
						if(oTreeNode.isLeaf())
						{
							((JMenuItem)m_oPopup.getComponent(0)).setText("Expand/Collapse..");
							m_oPopup.getComponent(0).setEnabled(false);
						}
						else
						{
							m_oPopup.getComponent(0).setEnabled(true);
							if(m_oGroupsTree.isExpanded(oPath))
							{
								((JMenuItem)m_oPopup.getComponent(0)).setText("Collapse..");
							}
							else
							{
								((JMenuItem)m_oPopup.getComponent(0)).setText("Expand..");
							}
						}
						***************************************************/
					}
				}
				else if(e.getSource() == m_oViewsTree)
				{
					DefaultMutableTreeNode	oTreeNode = m_oViewsTree.getTreeNode(pLocation);
					if(oTreeNode != null)
					{
						bPopup = true;
						((DefaultTreeSelectionModel)m_oViewsTree.getSelectionModel()).clearSelection();
						TreePath oPath = new TreePath(oTreeNode.getPath());
						((DefaultTreeSelectionModel)m_oViewsTree.getSelectionModel()).setSelectionPath(oPath);
						/***************************************************
						if(oTreeNode.isLeaf())
						{
							((JMenuItem)m_oPopup.getComponent(0)).setText("Expand/Collapse..");
							m_oPopup.getComponent(0).setEnabled(false);
						}
						else
						{
							m_oPopup.getComponent(0).setEnabled(true);
							if(m_oViewsTree.isExpanded(oPath))
							{
								((JMenuItem)m_oPopup.getComponentAtIndex(0)).setText("Collapse..");
							}
							else
							{
								((JMenuItem)m_oPopup.getComponentAtIndex(0)).setText("Expand..");
							}
						}
						***************************************************/
					}
				}

				if(bPopup)
				{
					x = e.getX();
					y = e.getY();
					m_oSource = e.getSource();
					if(UserManager.m_sEditBuffer == null)
					{
						m_oPopup.getComponent(1).setEnabled(false);
					}
					else
					{
						m_oPopup.getComponent(1).setEnabled(true);
					}
					m_oPopup.show((Component)e.getSource(),
								  e.getX(),
								  e.getY());
				}
			}
		}
	}

	public UserGroupViewMain(String title)
	{
		this();
		setTitle(title);
	}
	
    public void setVisible(boolean b)
	{
		if(b)
		{
			setLocation(50, 50);
		}	
		super.setVisible(b);
	}
	
	public static void main(String args[])
	{
		try
		{
			UserGroupViewMain oFrame = new UserGroupViewMain();
			oFrame.pack();
		}
		catch (Throwable t)
		{
			System.err.println(t);
			t.printStackTrace();
			//Ensure the application exits with an error condition.
			//oFrame.dispose();
			System.exit(0);
		}
	}
	
	public void addNotify()
	{
		Dimension d = getSize();
		
		super.addNotify();
	
		if (m_bComponentsAdjusted)
		{
			return;
		}
	
		setSize(getInsets().left + getInsets().right + d.width, getInsets().top + getInsets().bottom + d.height);
		Component components[] = getComponents();
		for (int i = 0; i < components.length; i++)
		{
			Point p = components[i].getLocation();
			p.translate(getInsets().left, getInsets().top);
			components[i].setLocation(p);
		}
		m_bComponentsAdjusted = true;
	}

	void addMenuBar()
	{
		JMenuBar	oMainMenuBar		= new JMenuBar();
		JMenu		oFileMenu			= new JMenu();
		JMenu		oEditMenu			= new JMenu();
		JMenu		oHelpMenu			= new JMenu();
		JMenu		oViewMenu			= new JMenu();
		JMenu		oLnFMenu			= new JMenu();
		JMenuItem	oSaveMenuItem		= new JMenuItem();
		JMenuItem	oExitMenuItem		= new JMenuItem();
		JMenuItem	oCutMenuItem		= new JMenuItem();
		JMenuItem	oCopyMenuItem		= new JMenuItem();
		JMenuItem	oPasteMenuItem		= new JMenuItem();
		JMenuItem	oLnFSubMenu1		= new JMenuItem();
		JMenuItem	oLnFSubMenu2		= new JMenuItem();
		JMenuItem	oLnFSubMenu3		= new JMenuItem();
		JMenuItem	oAboutMenuItem		= new JMenuItem();

		oFileMenu.setText("File");
		oFileMenu.setMnemonic('F');
		oMainMenuBar.add(oFileMenu);
		oSaveMenuItem.addActionListener(new MenuBarListener());
		oSaveMenuItem.setText("Save");
		oSaveMenuItem.setActionCommand("Save");
		oSaveMenuItem.setMnemonic('S');
		oFileMenu.add(oSaveMenuItem);
		oExitMenuItem.addActionListener(new MenuBarListener());
		oExitMenuItem.setText("Exit");
		oExitMenuItem.setActionCommand("Exit");
		oExitMenuItem.setMnemonic('x');
		oFileMenu.add(oExitMenuItem);
		oExitMenuItem.addActionListener(new MenuBarListener());
		oEditMenu.setText("Edit");
		oEditMenu.setMnemonic('E');
		oMainMenuBar.add(oEditMenu);
		oCutMenuItem.setText("Delete");
		oCutMenuItem.setActionCommand("Cut");
		oCutMenuItem.setMnemonic('D');
		//oCutMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X,Event.CTRL_MASK ));
		oCutMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_DELETE,0));
		oEditMenu.add(oCutMenuItem);
		oCutMenuItem.addActionListener(new MenuBarListener());
		oCopyMenuItem.setText("Copy");
		oCopyMenuItem.setActionCommand("Copy");
		oCopyMenuItem.setMnemonic('C');
		oCopyMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C,Event.CTRL_MASK ));
		oEditMenu.add(oCopyMenuItem);
		oCopyMenuItem.addActionListener(new MenuBarListener());
		oPasteMenuItem.setText("Paste");
		oPasteMenuItem.setActionCommand("Paste");
		oPasteMenuItem.setMnemonic('P');
		oPasteMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_V,Event.CTRL_MASK ));
		oEditMenu.add(oPasteMenuItem);
		oPasteMenuItem.addActionListener(new MenuBarListener());

		oViewMenu.setText("View");
		oViewMenu.setActionCommand("View");
		oViewMenu.setMnemonic('V');
/*********************************
		oEditMenu.add(oViewMenu);
**********************************/
		oMainMenuBar.add(oViewMenu);

		oLnFMenu.setText("Look and Feel");
		oLnFMenu.setActionCommand("LnF");
		oLnFMenu.setMnemonic('L');
		oViewMenu.add(oLnFMenu);

		oLnFSubMenu1.setText("Metal");
		oLnFSubMenu1.setActionCommand("Metal");
		oLnFSubMenu1.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_J,Event.CTRL_MASK ));
		oLnFMenu.add(oLnFSubMenu1);
		oLnFSubMenu1.addActionListener(new MenuBarListener());

		oLnFSubMenu2.setText("Motif");
		oLnFSubMenu2.setActionCommand("Motif");
		oLnFSubMenu2.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_M,Event.CTRL_MASK ));
		oLnFMenu.add(oLnFSubMenu2);
		oLnFSubMenu2.addActionListener(new MenuBarListener());

		oLnFSubMenu3.setText("Windows");
		oLnFSubMenu3.setActionCommand("Windows");
		oLnFSubMenu3.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_W,Event.CTRL_MASK ));
		oLnFMenu.add(oLnFSubMenu3);
		oLnFSubMenu3.addActionListener(new MenuBarListener());

		oHelpMenu.setText("Help");
		oHelpMenu.setMnemonic('H');
		oMainMenuBar.add(oHelpMenu);
		oHelpMenu.add(oAboutMenuItem);
		oAboutMenuItem.addActionListener(new MenuBarListener());
		oAboutMenuItem.setText("About..");
		oAboutMenuItem.setActionCommand("About");
		oAboutMenuItem.setMnemonic('A');
		oMainMenuBar.setBorder(BorderFactory.createEtchedBorder());

		setJMenuBar(oMainMenuBar);
	}

	class MenuBarListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e)
		{
			if(e.getActionCommand().equals("Save"))
			{
				UserManager.save();
			}
			else if(e.getActionCommand().equals("Exit"))
			{
				if(UserManager.m_bUpdated)
				{
					String sMsg = "Configurations have not been saved. Save now?";
					int optVal = JOptionPane.showConfirmDialog(UserGroupViewMain.this.getContentPane(),
													   sMsg,
													   "Save Configuration...",
													   JOptionPane.YES_NO_OPTION,
													   JOptionPane.WARNING_MESSAGE,
													   new ImageIcon("data/images/lightbulb.gif"));
					if(optVal==JOptionPane.YES_OPTION)
					{
						UserManager.save();
					}
					else if(optVal==JOptionPane.NO_OPTION)
					{
						UserManager.m_bUpdated = false;
						dispose();
					}
				}
				else
				{
					dispose();
				}
			}
			else if(e.getActionCommand().equals("Cut"))
			{
				cut();
			}
			else if(e.getActionCommand().equals("Copy"))
			{
				copy();
			}
			else if(e.getActionCommand().equals("Paste"))
			{
				paste();
			}
			else if(e.getActionCommand().equals("About"))
			{
				new AboutDialog(UserGroupViewMain.this, "Help About..");
				/********************************
				String sMsg = "\"Help About..\" yet to be implemented.";
				JOptionPane.showMessageDialog(UserGroupViewMain.this.getContentPane(),
											  sMsg,
											  "Help About..",
											  JOptionPane.INFORMATION_MESSAGE);
				********************************/
			}
			else
			{
				org.opennms.bb.eui.admin.utils.LnF.setLookAndFeel(e.getActionCommand());
				SwingUtilities.updateComponentTreeUI(UserGroupViewMain.this);
			}
		}
	}

	void addToolBar()
	{
		JPanel	oToolPanel	= new JPanel();
		String	sTools[]	= { "close",
								"SPACER",
								"copy", "paste", "delete",
								"SPACER",
								"pluses", "plus", "minuses", "minus",
								"SPACER",
								"user", "usrgrp", "views",
								"SPACER",
								"newWizard" };
		String	sToolTips[]	= { "Save",
								"SPACER",
								"Copy", "Paste", "Delete",
								"SPACER",
								"Expand All", "Expand Selected", "Collapse All", "Collapse Selected",
								"SPACER",
								"Add a new user", "Add a new user group", "Add a new view",
								"SPACER",
								"New user wizard" };

		JToolBar oToolBar	= new JToolBar();
		//oToolBar.setLayout(new GridLayout(0,sTools.length,9,3));
		//oToolBar.setLayout(new FlowLayout(FlowLayout.LEFT));

		for(int i=0; i<sTools.length; i++)
		{
			//if(sTools[i].equals("SPACER"))
			if(i==1 || i==5 || i==10 || i==14)
			{
				oToolBar.addSeparator( new Dimension(6, 6) );
			}
			else
			{
				String sSlash = System.getProperty("file.separator");
				JButton theButton = new JButton(new ImageIcon("data/images/"+sTools[i]+".gif"));
				oToolBar.add(theButton);
				theButton.setToolTipText(sToolTips[i]);
				theButton.setActionCommand(sTools[i]);
				theButton.setMargin(new Insets(0,0,0,0));
				theButton.addActionListener( new ToolBarListener() );
				//if(sTools[i].equals("delete");
				if(i==5)
				{
					//theButton.setMnemonic(KeyEvent.VK_DELETE);
					addKeyListener( new KeyAdapter()
									{
										public void keyPressed(KeyEvent e)
										{
											if(e.getKeyCode() == KeyEvent.VK_DELETE)
											{
												delete();
											}
										}
									 }
									);
				}
				//oToolBar.addSeparator( new Dimension(3, 3) );
			}
		}

		oToolPanel.setFont(new Font("Dialog", Font.PLAIN, 10));
		oToolPanel.setBorder(BorderFactory.createRaisedBevelBorder());

		oToolPanel.setAlignmentX(LEFT_ALIGNMENT);
		oToolPanel.setAlignmentY(TOP_ALIGNMENT);

		oToolPanel.setLayout(new BorderLayout());
		oToolPanel.add(oToolBar, BorderLayout.CENTER);

		m_oGridBagConstraints.fill = GridBagConstraints.HORIZONTAL;
		m_oGridBagConstraints.weightx = 0.5;
		m_oGridBagConstraints.weighty = 0;
		m_oGridBagConstraints.gridx = 0;
		m_oGridBagConstraints.gridy = 0;
		m_oGridBagConstraints.gridwidth = 3;
		m_oGridBagConstraints.ipadx = 0;
		m_oGridBagConstraints.ipady = 0;
		m_oGridBagConstraints.insets = new Insets(8,0,0,0);
		m_oGridBag.setConstraints(oToolPanel, m_oGridBagConstraints);
		getContentPane().add(oToolPanel);
		m_oGridBagConstraints.insets = new Insets(0,0,0,0);
	}

	class ToolBarListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e)
		{
			if(e.getActionCommand().equals("close"))
			{
				UserManager.save();
			}
			else if(e.getActionCommand().equals("cut"))
			{
				cut();
			}
			else if(e.getActionCommand().equals("copy"))
			{
				copy();
			}
			else if(e.getActionCommand().equals("paste"))
			{
				paste();
			}
			else if(e.getActionCommand().equals("delete"))
			{
				delete();
			}
			else if(e.getActionCommand().equals("pluses"))
			{
				//m_bIsExpansionEvent = true;
				DefaultMutableTreeNode	oRoot;
				TreePath oPath;
				{
					oRoot		= (DefaultMutableTreeNode)m_oGroupsTree.getModel().getRoot();
					int	nChild	= oRoot.getChildCount();
					for(int i=0;i<nChild;i++)
					{
						oPath = m_oGroupsTree.getPathForRow(i);
						DefaultMutableTreeNode oNode = (DefaultMutableTreeNode)oPath.getLastPathComponent();
						if(!oNode.isLeaf())
						{
							m_oGroupsTree.expandPath(oPath);
							nChild+= oNode.getChildCount();
						}
					}
				}
				{
					oRoot		= (DefaultMutableTreeNode)m_oViewsTree.getModel().getRoot();
					int	nChild	= oRoot.getChildCount();
					for(int i=0;i<nChild;i++)
					{
						oPath = m_oViewsTree.getPathForRow(i);
						DefaultMutableTreeNode oNode = (DefaultMutableTreeNode)oPath.getLastPathComponent();
						if(!oNode.isLeaf())
						{
							m_oViewsTree.expandPath(oPath);
							nChild+= oNode.getChildCount();
						}
					}
				}
				//m_bIsExpansionEvent = false;
			} 
			else if(e.getActionCommand().equals("plus"))
			{
				//m_bIsExpansionEvent = true;
				try
				{
					TreePath oPath =  m_oSelectionModel.getSelectionPath();
					if( m_oSelectionModel == m_oGroupsTree.getSelectionModel())
					{
						m_oGroupsTree.expandPath(oPath);
					}
					else if( m_oSelectionModel == m_oViewsTree.getSelectionModel())
					{
						m_oViewsTree.expandPath(oPath);
					}
				}
				catch (Exception ex)
				{
					setStatus("Must select the node to be expanded.");
				}
				//m_bIsExpansionEvent = false;
			} 
			else if(e.getActionCommand().equals("minuses"))
			{
				//m_bIsExpansionEvent = true;
				DefaultMutableTreeNode	oRoot;
				TreePath oPath;
				{
					oRoot		= (DefaultMutableTreeNode)m_oGroupsTree.getModel().getRoot();
					int	nChild	= oRoot.getChildCount();
					for(int i=0;i<nChild;i++)
					{
						oPath = m_oGroupsTree.getPathForRow(i);
						m_oGroupsTree.collapsePath(oPath);
					}
				}
				{
					oRoot		= (DefaultMutableTreeNode)m_oViewsTree.getModel().getRoot();
					int	nChild	= oRoot.getChildCount();
					for(int i=0;i<nChild;i++)
					{
						oPath = m_oViewsTree.getPathForRow(i);
						m_oViewsTree.collapsePath(oPath);
					}
				}
				//m_bIsExpansionEvent = false;
			} 
			else if(e.getActionCommand().equals("minus"))
			{
				//m_bIsExpansionEvent = true;
				try
				{
					TreePath oPath =  m_oSelectionModel.getSelectionPath();
					if( m_oSelectionModel == m_oGroupsTree.getSelectionModel())
					{
						m_oGroupsTree.collapsePath(oPath);
					}
					else if( m_oSelectionModel == m_oViewsTree.getSelectionModel())
					{
						m_oViewsTree.collapsePath(oPath);
					}
				}
				catch (Exception ex)
				{
					setStatus("Must select the node to be collapsed.");
				}
				//m_bIsExpansionEvent = false;
			} 
			else if(e.getActionCommand().equals("user"))
			{
				DefaultTreeModel oTreeModel	= (DefaultTreeModel)m_oUsersTree.getModel();
				MutableTreeNode oRoot		= (MutableTreeNode)oTreeModel.getRoot();
				String	sName				= "USER"+(oRoot.getChildCount()+1);
				(new ModifyUser(UserGroupViewMain.this, "Add User", true, sName, true)).setVisible(true);
				sName = UserManager.m_sNewId;
				if(UserManager.m_iEditWhat == UserManager.USER)
				{
					UserManager.ok();
					oTreeModel.insertNodeInto(new DefaultMutableTreeNode(sName),
											  oRoot,
											  oRoot.getChildCount());
					if(oRoot.getChildCount()<=1)
					{
						oTreeModel.reload(oRoot);
					}

					setStatus("New user "+sName+" added. Double click to modify.");
				}
			}
			else if(e.getActionCommand().equals("usrgrp"))
			{
				DefaultTreeModel oTreeModel	= (DefaultTreeModel)m_oGroupsTree.getModel();
				MutableTreeNode oRoot		= (MutableTreeNode)oTreeModel.getRoot();
				String	sName				= "USERGROUP"+(oRoot.getChildCount()+1);
				(new ModifyGroup(UserGroupViewMain.this, "Add Group", true, sName)).setVisible(true);
				sName = UserManager.m_sNewId;
				if(UserManager.m_iEditWhat == UserManager.GROUP)
				{
					UserManager.ok();
					oTreeModel.insertNodeInto(new DefaultMutableTreeNode(sName),
											  oRoot,
											  oRoot.getChildCount());
					if(oRoot.getChildCount()<=1)
					{
						oTreeModel.reload(oRoot);
					}
					setStatus("New user group "+sName+" added.");
				}
			}
			else if(e.getActionCommand().equals("views"))
			{
				DefaultTreeModel oTreeModel	= (DefaultTreeModel)m_oViewsTree.getModel();
				MutableTreeNode oRoot		= (MutableTreeNode)oTreeModel.getRoot();
				String	sName				= "VIEW"+(oRoot.getChildCount()+1);
				(new ModifyView(UserGroupViewMain.this, "Add View", true, sName)).setVisible(true);
				sName = UserManager.m_sNewId;
				if(UserManager.m_iEditWhat == UserManager.VIEW)
				{
					UserManager.ok();
					oTreeModel.insertNodeInto(new DefaultMutableTreeNode(sName),
											  oRoot,
											  oRoot.getChildCount());
					if(oRoot.getChildCount()<=1)
					{
						oTreeModel.reload(oRoot);
					}
					setStatus("New view "+sName+" added.");
				}
			}
			else if(e.getActionCommand().equals("newWizard"))
			{
				DefaultTreeModel oTreeModel	= (DefaultTreeModel)m_oUsersTree.getModel();
				MutableTreeNode oRoot		= (MutableTreeNode)oTreeModel.getRoot();
				(new AddUserWizard1(UserGroupViewMain.this, true)).setVisible(true);
				String sName = UserManager.m_sNewId;
				if(UserManager.m_iEditWhat == UserManager.USER)
				{
					UserManager.ok();
					oTreeModel.insertNodeInto(new DefaultMutableTreeNode(sName),
											  oRoot,
											  oRoot.getChildCount());
					if(oRoot.getChildCount()<=1)
					{
						oTreeModel.reload(oRoot);
					}

					/*
					 * Add this user to the requested groups:
					 */
					{
						oTreeModel	= (DefaultTreeModel)m_oGroupsTree.getModel();
						oRoot= (DefaultMutableTreeNode)oTreeModel.getRoot();
						oRoot.children();
						for(int i=0;i<AddUserWizard3.m_oGroups.size();i++)
						{
							String temp = (String)AddUserWizard3.m_oGroups.get(i);
							for(Enumeration en=oRoot.children(); en.hasMoreElements(); )
							{
								DefaultMutableTreeNode tNode = (DefaultMutableTreeNode)en.nextElement();
								if(temp.equals(tNode.toString()))
								{
									oTreeModel.insertNodeInto(new DefaultMutableTreeNode(sName),
															  tNode,
															  tNode.getChildCount());
									if(oRoot.getChildCount()<=1)
									{
										oTreeModel.reload(tNode);
									}
									break;
								}
							}
						}
					}
					/*
					 * Add this user to the requested views:
					 */
					{
						oTreeModel	= (DefaultTreeModel)m_oViewsTree.getModel();
						oRoot= (DefaultMutableTreeNode)oTreeModel.getRoot();
						oRoot.children();
						for(int i=0;i<AddUserWizard4.m_oViews.size();i++)
						{
							String temp = (String)AddUserWizard4.m_oViews.get(i);
							for(Enumeration en=oRoot.children(); en.hasMoreElements(); )
							{
								DefaultMutableTreeNode tNode = (DefaultMutableTreeNode)en.nextElement();
								if(temp.equals(tNode.toString()))
								{
									oTreeModel.insertNodeInto(new DefaultMutableTreeNode(sName),
															  tNode,
															  tNode.getChildCount());
									if(oRoot.getChildCount()<=1)
									{
										oTreeModel.reload(tNode);
									}
									break;
								}
							}
						}
					}

					setStatus("New user "+sName+" added. Double click to modify.");
				}
			}
		}
	}

	void loadUsers()
	{
		JTextField	oUsersLabel		= new JTextField();

		m_oGridBagConstraints.fill = GridBagConstraints.HORIZONTAL;
		m_oGridBagConstraints.weightx = 0.5;
		m_oGridBagConstraints.weighty = 0;
		m_oGridBagConstraints.gridx = 0;
		m_oGridBagConstraints.gridy = 1;
		m_oGridBagConstraints.gridwidth = 1;
		m_oGridBagConstraints.ipadx = 10;
		m_oGridBagConstraints.ipady = 0;
		m_oGridBagConstraints.anchor = GridBagConstraints.WEST;
		m_oGridBagConstraints.insets = new Insets(8,0,0,4);
		m_oGridBag.setConstraints(oUsersLabel, m_oGridBagConstraints);
		getContentPane().add(oUsersLabel);

		oUsersLabel.setText("Users");
		oUsersLabel.setEditable(false);
		oUsersLabel.setHorizontalAlignment(JTextField.CENTER);
		oUsersLabel.setBackground(new java.awt.Color(128,0,0));
		oUsersLabel.setForeground(java.awt.Color.white);
		oUsersLabel.setSelectionColor(new java.awt.Color(128,0,0));
		oUsersLabel.setSelectedTextColor(java.awt.Color.white);
		oUsersLabel.setFont(new Font("Dialog", Font.BOLD, 12));

		DefaultMutableTreeNode	oRoot = new DefaultMutableTreeNode("USERS");
		for(Enumeration e=UserManager.m_oUsers.keys(); e.hasMoreElements();)
		{
			oRoot.add(new DefaultMutableTreeNode(e.nextElement()));
		}

		m_oUsersTree = new DragTree(oRoot);
		m_oUsersTree.setRootVisible(false);
		m_oUsersTree.setEditable(false);

		JScrollPane	oUsersScrollPane	= new JScrollPane(m_oUsersTree,
														  JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
														  JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED );
		m_oGridBagConstraints.fill = GridBagConstraints.BOTH;
		m_oGridBagConstraints.weightx = 0.5;
		m_oGridBagConstraints.weighty = 1.0;
		m_oGridBagConstraints.gridx = 0;
		m_oGridBagConstraints.gridy = 2;
		m_oGridBagConstraints.gridwidth = 1;
		m_oGridBagConstraints.ipady = 0;
		m_oGridBagConstraints.insets = new Insets(0,0,0,4);
		m_oGridBag.setConstraints(oUsersScrollPane, m_oGridBagConstraints);
		getContentPane().add(oUsersScrollPane);
		m_oGridBagConstraints.insets = new Insets(0,0,0,0);

		m_oUsersTree.getModel().addTreeModelListener(m_oTreeModelListener);
	}

	void loadGroups()
	{
		JTextField	oGroupsLabel		= new JTextField();

		m_oGridBagConstraints.fill = GridBagConstraints.HORIZONTAL;
		m_oGridBagConstraints.weightx = 0.5;
		m_oGridBagConstraints.weighty = 0;
		m_oGridBagConstraints.gridx = 1;
		m_oGridBagConstraints.gridy = 1;
		m_oGridBagConstraints.gridwidth = 1;
		m_oGridBagConstraints.ipadx = 0;
		m_oGridBagConstraints.ipady = 0;
		m_oGridBagConstraints.anchor = GridBagConstraints.CENTER;
		m_oGridBagConstraints.insets = new Insets(8,4,0,4);
		m_oGridBag.setConstraints(oGroupsLabel, m_oGridBagConstraints);
		getContentPane().add(oGroupsLabel);

		oGroupsLabel.setText("User Groups");
		oGroupsLabel.setEditable(false);
		oGroupsLabel.setHorizontalAlignment(JTextField.CENTER);
		oGroupsLabel.setBackground(new java.awt.Color(128,0,0));
		oGroupsLabel.setForeground(java.awt.Color.white);
		oGroupsLabel.setSelectionColor(new java.awt.Color(128,0,0));
		oGroupsLabel.setSelectedTextColor(java.awt.Color.white);
		oGroupsLabel.setFont(new Font("Dialog", Font.BOLD, 12));

		DefaultMutableTreeNode	oRoot = new DefaultMutableTreeNode("GROUPS");
		for(Enumeration e=UserManager.m_oGroups.keys(); e.hasMoreElements();)
		{
			String sName = (String)e.nextElement();
			DefaultMutableTreeNode oNode = new DefaultMutableTreeNode(sName);
			oRoot.add(oNode);

			String sBuffer = (String)UserManager.m_oGroups.get(sName);
			if(sBuffer != null)
			{
				StringTokenizer oTokenizer = new StringTokenizer(sBuffer,":");
				String sTok = null;
				try	{oTokenizer.nextToken();} catch(NoSuchElementException  exc) {}
				while(oTokenizer.hasMoreTokens())
				{
					try
					{
						sTok = oTokenizer.nextToken();
						if((sTok!=null) && !(sTok.trim().equals("")) )
						{
							oNode.add(new DefaultMutableTreeNode(sTok));
						}
					} catch(NoSuchElementException  exc) {}
				}
			}

		}

		m_oGroupsTree = new DragDropTree(oRoot);
		m_oGroupsTree.setRootVisible(false);
		m_oGroupsTree.setEditable(false);

		JScrollPane	oGroupsScrollPane	= new JScrollPane(m_oGroupsTree,
														  JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
														  JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED );
		m_oGridBagConstraints.fill = GridBagConstraints.BOTH;
		m_oGridBagConstraints.weightx = 0.5;
		m_oGridBagConstraints.weighty = 1.0;
		m_oGridBagConstraints.gridx = 1;
		m_oGridBagConstraints.gridy = 2;
		m_oGridBagConstraints.gridwidth = 1;
		m_oGridBagConstraints.ipady = 0;
		m_oGridBagConstraints.insets = new Insets(0,4,0,4);
		m_oGridBag.setConstraints(oGroupsScrollPane, m_oGridBagConstraints);
		getContentPane().add(oGroupsScrollPane);
		m_oGridBagConstraints.insets = new Insets(0,0,0,0);


		m_oGroupsTree.getModel().addTreeModelListener(m_oTreeModelListener);
	}

	void loadViews()
	{
		JTextField	oViewsLabel		= new JTextField();

		m_oGridBagConstraints.fill = GridBagConstraints.HORIZONTAL;
		m_oGridBagConstraints.weightx = 0.5;
		m_oGridBagConstraints.weighty = 0;
		m_oGridBagConstraints.gridx = 2;
		m_oGridBagConstraints.gridy = 1;
		m_oGridBagConstraints.gridwidth = 1;
		m_oGridBagConstraints.ipadx = 10;
		m_oGridBagConstraints.ipady = 0;
		m_oGridBagConstraints.anchor = GridBagConstraints.EAST;
		m_oGridBagConstraints.insets = new Insets(8,4,0,0);
		m_oGridBag.setConstraints(oViewsLabel, m_oGridBagConstraints);
		getContentPane().add(oViewsLabel);

		oViewsLabel.setText("Views");
		oViewsLabel.setEditable(false);
		oViewsLabel.setHorizontalAlignment(JTextField.CENTER);
		oViewsLabel.setBackground(new java.awt.Color(128,0,0));
		oViewsLabel.setForeground(java.awt.Color.white);
		oViewsLabel.setSelectionColor(new java.awt.Color(128,0,0));
		oViewsLabel.setSelectedTextColor(java.awt.Color.white);
		oViewsLabel.setFont(new Font("Dialog", Font.BOLD, 12));

		DefaultMutableTreeNode	oRoot = new DefaultMutableTreeNode("VIEWS");
		for(Enumeration e=UserManager.m_oViews.keys(); e.hasMoreElements();)
		{
			String sName = (String)e.nextElement();
			DefaultMutableTreeNode oNode = new DefaultMutableTreeNode(sName);
			oRoot.add(oNode);

			String sBuffer = (String)UserManager.m_oViews.get(sName);
			if(sBuffer != null)
			{
				StringTokenizer oTokenizer = new StringTokenizer(sBuffer,":");
				String sTok = null;
				try	{oTokenizer.nextToken();oTokenizer.nextToken();} catch(NoSuchElementException  exc) {}
				while(oTokenizer.hasMoreTokens())
				{
					try
					{
						sTok = oTokenizer.nextToken();
						if((sTok!=null) && !(sTok.trim().equals("")) )
						{
							oNode.add(new DefaultMutableTreeNode(sTok));
						}
					} catch(NoSuchElementException  exc) {}
				}
			}
		}

		m_oViewsTree = new DropTree(oRoot);
		m_oViewsTree.setRootVisible(false);
		m_oViewsTree.setEditable(false);

		JScrollPane	oViewsScrollPane	= new JScrollPane(m_oViewsTree,
														  JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
														  JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED );
		m_oGridBagConstraints.fill = GridBagConstraints.BOTH;
		m_oGridBagConstraints.weightx = 0.5;
		m_oGridBagConstraints.weighty = 1.0;
		m_oGridBagConstraints.gridx = 2;
		m_oGridBagConstraints.gridy = 2;
		m_oGridBagConstraints.gridwidth = 1;
		m_oGridBagConstraints.ipady = 0;
		m_oGridBagConstraints.insets = new Insets(0,4,0,0);
		m_oGridBag.setConstraints(oViewsScrollPane, m_oGridBagConstraints);
		getContentPane().add(oViewsScrollPane);
		m_oGridBagConstraints.insets = new Insets(0,0,0,0);

		m_oViewsTree.getModel().addTreeModelListener(m_oTreeModelListener);
	}

	class UITreeModelListener implements TreeModelListener
	{
		public void treeNodesChanged(TreeModelEvent e)
		{
			DefaultMutableTreeNode oNode;
			oNode = (DefaultMutableTreeNode)(e.getTreePath().getLastPathComponent());

			/*
			 * If the event lists children, then the changed
			 * node is the child of the node we've already
			 * gotten.  Otherwise, the changed node and the
			 * specified node are the same.
			 */
			try
			{
				int iIndex = e.getChildIndices()[0];
				oNode = (DefaultMutableTreeNode)(oNode.getChildAt(iIndex));
			}
			catch (NullPointerException exc)
			{
				/*
				 * This means the changed node and the
				 * specified nodes are the same.
				 */
			}
			
			if(e.getSource() == m_oUsersTree.getModel())
			{
				if(UserManager.m_iEditWhat == UserManager.USER) // from ModifyUser dialog
				{
					UserManager.ok();
				}
				else if(!UserManager.m_sNewId.equals((String)oNode.getUserObject())) // from UI
				{
					if((!UserManager.m_sOldId.equals((String)oNode.getUserObject())) && UserManager.m_oUsers.containsKey((String)oNode.getUserObject()))
					{
						setStatus("Can't rename "+UserManager.m_sOldId+" to "+(String)oNode.getUserObject()+" <-- User exists.");
						Toolkit.getDefaultToolkit().beep();
						oNode.setUserObject(UserManager.m_sOldId);
						m_oUsersTree.setEditable(false);
						UserManager.cancel();
						return;
					}
					m_oUsersTree.setEditable(false);
					UserManager.modify(UserManager.USER, UserManager.m_sOldId);
					UserManager.m_sBuffer= (String)UserManager.m_oUsers.get(UserManager.m_sOldId);
					UserManager.m_sNewId = (String)oNode.getUserObject();
					UserManager.ok();
				}

				updateTree(UserManager.GROUP, UserManager.m_sOldId, UserManager.m_sNewId);
				//UserManager.m_sOldId = m_oUsersTree.getSelectionModel().getSelectionPath().getLastPathComponent().toString();
				UserManager.m_sOldId = UserManager.m_sNewId;
			}
			else if(e.getSource() == m_oGroupsTree.getModel())
			{
				if(UserManager.m_iEditWhat == UserManager.USER) // from ModifyUser dialog
				{
					// find 1 node n Users tree and notify to change:
					DefaultMutableTreeNode oUsersRoot = (DefaultMutableTreeNode)m_oUsersTree.getModel().getRoot();
					for(Enumeration en=oUsersRoot.children(); en.hasMoreElements(); )
					{
						DefaultMutableTreeNode temp = (DefaultMutableTreeNode)en.nextElement();
						if(temp.toString().equals(UserManager.m_sOldId))
						{
							temp.setUserObject(UserManager.m_sNewId);
							((DefaultTreeModel)m_oUsersTree.getModel()).nodeChanged(temp);
							return;
						}
					}
				}
				else if(UserManager.m_iEditWhat == UserManager.GROUP) // from ModifyGroup dialog
				{
					UserManager.ok();
				}
				else if(!UserManager.m_sNewId.equals((String)oNode.getUserObject())) // from UI
				{
					m_oGroupsTree.setEditable(false);
					// if it is group node, update group.
					if(((DefaultMutableTreeNode)oNode.getParent()).isRoot())
					{
						if((!UserManager.m_sOldId.equals((String)oNode.getUserObject())) && UserManager.m_oGroups.containsKey((String)oNode.getUserObject()))
						{
							setStatus("Can't rename "+UserManager.m_sOldId+" to "+(String)oNode.getUserObject()+" <-- Group exists.");
							Toolkit.getDefaultToolkit().beep();
							oNode.setUserObject(UserManager.m_sOldId);
							UserManager.cancel();
							return;
						}
						UserManager.modify(UserManager.GROUP, UserManager.m_sOldId);
						UserManager.m_sBuffer= (String)UserManager.m_oGroups.get(UserManager.m_sOldId);
						UserManager.m_sNewId = (String)oNode.getUserObject();
						UserManager.ok();
					}
					else // if it is user, update user.
					{
						if((!UserManager.m_sOldId.equals((String)oNode.getUserObject())) && UserManager.m_oUsers.containsKey((String)oNode.getUserObject()))
						{
							setStatus("Can't rename "+UserManager.m_sOldId+" to "+(String)oNode.getUserObject()+" <-- User exists.");
							Toolkit.getDefaultToolkit().beep();
							oNode.setUserObject(UserManager.m_sOldId);
							UserManager.cancel();
							return;
						}
						UserManager.modify(UserManager.USER, UserManager.m_sOldId);
						UserManager.m_sBuffer= (String)UserManager.m_oUsers.get(UserManager.m_sOldId);
						UserManager.m_sNewId = (String)oNode.getUserObject();
						// find an appropriate node in Users tree and notify to change:
						DefaultMutableTreeNode oUsersRoot = (DefaultMutableTreeNode)m_oUsersTree.getModel().getRoot();
						for(Enumeration en=oUsersRoot.children(); en.hasMoreElements(); )
						{
							DefaultMutableTreeNode temp = (DefaultMutableTreeNode)en.nextElement();
							if(temp.toString().equals(UserManager.m_sOldId))
							{
								temp.setUserObject(UserManager.m_sNewId);
								((DefaultTreeModel)m_oUsersTree.getModel()).reload(temp);
								((DefaultTreeModel)m_oUsersTree.getModel()).nodeChanged(temp);
								return;
							}
						}
					}
				}
				updateTree(UserManager.VIEW, UserManager.m_sOldId, UserManager.m_sNewId);
				//UserManager.m_sOldId = m_oGroupsTree.getSelectionModel().getSelectionPath().getLastPathComponent().toString();
				UserManager.m_sOldId = UserManager.m_sNewId;
			}
			else if(e.getSource() == m_oViewsTree.getModel())
			{
				if(UserManager.m_iEditWhat == UserManager.USER) // from ModifyUser dialog
				{
					// find 1 node in Users tree and notify to change:
					DefaultMutableTreeNode oUsersRoot = (DefaultMutableTreeNode)m_oUsersTree.getModel().getRoot();
					for(Enumeration en=oUsersRoot.children(); en.hasMoreElements(); )
					{
						DefaultMutableTreeNode temp = (DefaultMutableTreeNode)en.nextElement();
						if(temp.toString().equals(UserManager.m_sOldId))
						{
							temp.setUserObject(UserManager.m_sNewId);
							((DefaultTreeModel)m_oUsersTree.getModel()).nodeChanged(temp);
							return;
						}
					}
				}
				else if(UserManager.m_iEditWhat == UserManager.GROUP) // from ModifyGroup dialog
				{
					// find 1 node n Groups tree and notify to change:
					DefaultMutableTreeNode oGroupsRoot = (DefaultMutableTreeNode)m_oGroupsTree.getModel().getRoot();
					for(Enumeration en=oGroupsRoot.children(); en.hasMoreElements(); )
					{
						DefaultMutableTreeNode temp = (DefaultMutableTreeNode)en.nextElement();
						if(temp.toString().equals(UserManager.m_sOldId))
						{
							temp.setUserObject(UserManager.m_sNewId);
							((DefaultTreeModel)m_oGroupsTree.getModel()).nodeChanged(temp);
							return;
						}
					}
				}
				else if(UserManager.m_iEditWhat == UserManager.VIEW) // from ModifyView dialog
				{
					UserManager.ok();
				}
				else if(!UserManager.m_sNewId.equals((String)oNode.getUserObject())) // from UI
				{
					m_oViewsTree.setEditable(false);
					// if it is view node, update view.
					if(((DefaultMutableTreeNode)oNode.getParent()).isRoot())
					{
						if((!UserManager.m_sOldId.equals((String)oNode.getUserObject())) && UserManager.m_oViews.containsKey((String)oNode.getUserObject()))
						{
							setStatus("Can't rename "+UserManager.m_sOldId+" to "+(String)oNode.getUserObject()+" <-- View exists.");
							Toolkit.getDefaultToolkit().beep();
							oNode.setUserObject(UserManager.m_sOldId);
							UserManager.cancel();
							return;
						}
						UserManager.modify(UserManager.VIEW, UserManager.m_sOldId);
						UserManager.m_sBuffer= (String)UserManager.m_oViews.get(UserManager.m_sOldId);
						UserManager.m_sNewId = (String)oNode.getUserObject();
						UserManager.ok();
					}
					else if(UserManager.m_oUsers.containsKey(UserManager.m_sOldId)) // if it is user, update user.
					{
						if((!UserManager.m_sOldId.equals((String)oNode.getUserObject())) && UserManager.m_oUsers.containsKey((String)oNode.getUserObject()))
						{
							setStatus("Can't rename "+UserManager.m_sOldId+" to "+(String)oNode.getUserObject()+" <-- User exists.");
							Toolkit.getDefaultToolkit().beep();
							oNode.setUserObject(UserManager.m_sOldId);
							UserManager.cancel();
							return;
						}
						UserManager.modify(UserManager.USER, UserManager.m_sOldId);
						UserManager.m_sBuffer= (String)UserManager.m_oUsers.get(UserManager.m_sOldId);
						UserManager.m_sNewId = (String)oNode.getUserObject();
						// find 1 node n Users tree and notify to change:
						DefaultMutableTreeNode oUsersRoot = (DefaultMutableTreeNode)m_oUsersTree.getModel().getRoot();
						for(Enumeration en=oUsersRoot.children(); en.hasMoreElements(); )
						{
							DefaultMutableTreeNode temp = (DefaultMutableTreeNode)en.nextElement();
							if(temp.toString().equals(UserManager.m_sOldId))
							{
								temp.setUserObject(UserManager.m_sNewId);
								((DefaultTreeModel)m_oUsersTree.getModel()).nodeChanged(temp);

								return;
							}
						}
					}
					else // if it is group, update group.
					{
						if((!UserManager.m_sOldId.equals((String)oNode.getUserObject())) && UserManager.m_oGroups.containsKey((String)oNode.getUserObject()))
						{
							setStatus("Can't rename "+UserManager.m_sOldId+" to "+(String)oNode.getUserObject()+" <-- Group exists.");
							Toolkit.getDefaultToolkit().beep();
							oNode.setUserObject(UserManager.m_sOldId);
							UserManager.cancel();
							return;
						}
						UserManager.modify(UserManager.GROUP, UserManager.m_sOldId);
						UserManager.m_sBuffer= (String)UserManager.m_oGroups.get(UserManager.m_sOldId);
						UserManager.m_sNewId = (String)oNode.getUserObject();
						// find 1 node n Groups tree and notify to change:
						DefaultMutableTreeNode oGroupsRoot = (DefaultMutableTreeNode)m_oGroupsTree.getModel().getRoot();
						for(Enumeration en=oGroupsRoot.children(); en.hasMoreElements(); )
						{
							DefaultMutableTreeNode temp = (DefaultMutableTreeNode)en.nextElement();
							if(temp.toString().equals(UserManager.m_sOldId))
							{
								temp.setUserObject(UserManager.m_sNewId);
								((DefaultTreeModel)m_oGroupsTree.getModel()).nodeChanged(temp);
								return;
							}
						}
					}
				}
				//updateTree(UserManager.VIEW, UserManager.m_sOldId, UserManager.m_sNewId);
				//UserManager.m_sOldId = m_oViewsTree.getSelectionModel().getSelectionPath().getLastPathComponent().toString();
				UserManager.m_sOldId = UserManager.m_sNewId;
			}
        }

		public void treeNodesInserted(TreeModelEvent e)
		{
		}

		public void treeNodesRemoved(TreeModelEvent e)
		{
		}

		public void treeStructureChanged(TreeModelEvent e)
		{
		}

		private void updateTree(int whichTree, String oldNode, String newNode)
		{
			if(whichTree<0 || whichTree>2)
			{
				return;
			}

			DefaultMutableTreeNode oRoot = null;
			if(whichTree == UserManager.GROUP)
			{
				oRoot	= (DefaultMutableTreeNode)m_oGroupsTree.getModel().getRoot();
			}
			else if(whichTree == UserManager.VIEW)
			{
				oRoot	= (DefaultMutableTreeNode)m_oViewsTree.getModel().getRoot();
			}
			for(Enumeration e1=oRoot.children(); e1.hasMoreElements(); )
			{
				DefaultMutableTreeNode oParent = (DefaultMutableTreeNode)e1.nextElement();
				if(!oParent.isLeaf())
				{
					for(Enumeration e2=oParent.children(); e2.hasMoreElements(); )
					{
						DefaultMutableTreeNode temp = (DefaultMutableTreeNode)e2.nextElement();
						if(temp.toString().equals(oldNode))
						{
							temp.setUserObject(newNode);
							if(whichTree == UserManager.GROUP)
							{
								((DefaultTreeModel)m_oGroupsTree.getModel()).reload(temp);
							}
							else if(whichTree == UserManager.VIEW)
							{
								((DefaultTreeModel)m_oViewsTree.getModel()).reload(temp);
							}
						}
					}
				}
			}

			if(whichTree == UserManager.GROUP)
			{
				updateTree(UserManager.VIEW, oldNode, newNode);
			}
		}
    }

	void addStatusBar()
	{
		m_oGridBagConstraints.fill = GridBagConstraints.HORIZONTAL;
		//m_oGridBagConstraints.weightx = 0.5;
		m_oGridBagConstraints.weighty = 0;
		m_oGridBagConstraints.gridx = 0;
		m_oGridBagConstraints.gridy = 3;
		m_oGridBagConstraints.gridwidth = 3;
		m_oGridBagConstraints.anchor = GridBagConstraints.SOUTH;
		m_oGridBagConstraints.insets = new Insets(8,0,0,0);
		m_oGridBagConstraints.ipadx = 0;
		m_oGridBagConstraints.ipady = 0;
		m_oGridBag.setConstraints(m_oStatusText, m_oGridBagConstraints);
		getContentPane().add(m_oStatusText);
		m_oGridBagConstraints.insets = new Insets(0,0,0,0);

		m_oStatusText.setBorder(BorderFactory.createLoweredBevelBorder());

		m_oStatusText.setEditable(false);
		m_oStatusText.setHorizontalAlignment(JTextField.LEFT);
		m_oStatusText.setFont(new Font("Courier", Font.BOLD, 11));

		setStatus("Ready");
	}

	void setStatus(String msg)
	{
		m_oStatusText.setBackground(java.awt.Color.lightGray);
		m_oStatusText.setForeground(java.awt.Color.black);
		m_oStatusText.setText(msg);
	}

	void addPopupMenu()
	{
		/*
		 * Create the popup menu.
		 */
		JMenuItem oMenuItem;
		m_oPopup = new JPopupMenu();

		//oMenuItem = new JMenuItem("Expand/Collapse..");
		//oMenuItem.setActionCommand("Expand");
		//oMenuItem.addActionListener((ActionListener)m_oPopupListener);
		//m_oPopup.add(oMenuItem);
		//m_oPopup.addSeparator();
		oMenuItem = new JMenuItem("Copy");
		oMenuItem.setActionCommand("Copy");
		oMenuItem.addActionListener((ActionListener)m_oPopupListener);
		m_oPopup.add(oMenuItem);
		oMenuItem = new JMenuItem("Paste");
		oMenuItem.setActionCommand("Paste");
		oMenuItem.addActionListener((ActionListener)m_oPopupListener);
		m_oPopup.add(oMenuItem);
		oMenuItem = new JMenuItem("Rename");
		oMenuItem.setActionCommand("Rename");
		oMenuItem.addActionListener((ActionListener)m_oPopupListener);
		m_oPopup.add(oMenuItem);
		oMenuItem = new JMenuItem("Delete");
		oMenuItem.setActionCommand("Cut");
		oMenuItem.addActionListener((ActionListener)m_oPopupListener);
		m_oPopup.add(oMenuItem);
		m_oPopup.addSeparator();
		oMenuItem = new JMenuItem("Properties..");
		oMenuItem.setActionCommand("Property");
		oMenuItem.addActionListener((ActionListener)m_oPopupListener);
		m_oPopup.add(oMenuItem);

		/*
		 * Add listener to components that can bring up popup menus.
		 */
		m_oUsersTree.addMouseListener(m_oPopupListener);
		m_oGroupsTree.addMouseListener(m_oPopupListener);
		m_oViewsTree.addMouseListener(m_oPopupListener);
	}

	void expand()
	{
		//m_bIsExpansionEvent = true;
		try
		{
			TreePath oPath =  m_oSelectionModel.getSelectionPath();
			if( m_oSelectionModel == m_oGroupsTree.getSelectionModel())
			{
				if(m_oGroupsTree.isExpanded(oPath))
				{
					m_oGroupsTree.collapsePath(oPath);
				}
				else
				{
					m_oGroupsTree.expandPath(oPath);
				}
			}
			else if( m_oSelectionModel == m_oViewsTree.getSelectionModel())
			{
				if(m_oViewsTree.isExpanded(oPath))
				{
					m_oViewsTree.collapsePath(oPath);
				}
				else
				{
					m_oViewsTree.expandPath(oPath);
				}
			}
		}
		catch (Exception ex)
		{
			setStatus(ex.toString());
		}
		//m_bIsExpansionEvent = false;
	}

	void cut()
	{
		try
		{
			TreePath oPath =  m_oSelectionModel.getSelectionPath();
			if(oPath.getPathCount() < 1)
			{
				return;
			}
			DefaultMutableTreeNode oNode	= (DefaultMutableTreeNode)oPath.getLastPathComponent();
			DefaultMutableTreeNode oParent	= (DefaultMutableTreeNode)oNode.getParent();
			if(oParent.isRoot())
			{
				delete();
			}
			else
			{
				//UserManager.m_sEditBuffer = oNode.toString();
				m_oTreeModel.removeNodeFromParent(oNode);
				m_oTreeModel.reload(oParent);
				UserManager.m_bUpdated = true;
			}
		}
		catch(Exception e)
		{
			setStatus("Must select a node first.");
			Toolkit.getDefaultToolkit().beep();
		}
	}

	void copy()
	{
		try
		{
			TreePath oPath =  m_oSelectionModel.getSelectionPath();
			if(oPath.getPathCount() < 1)
			{
				return;
			}
			DefaultMutableTreeNode oNode	= (DefaultMutableTreeNode)oPath.getLastPathComponent();
			UserManager.m_sEditBuffer = oNode.toString();
		}
		catch(Exception e)
		{
			setStatus("Must select a node first.");
			Toolkit.getDefaultToolkit().beep();
		}
	}

	void paste()
	{
		if(UserManager.m_sEditBuffer != null)
		{
			TreePath oPath =  m_oSelectionModel.getSelectionPath();
			if(oPath == null || oPath.getPathCount() < 1)
			{
				setStatus("Must select a node first.");
				Toolkit.getDefaultToolkit().beep();
				return;
			}
			DefaultMutableTreeNode oNode	= (DefaultMutableTreeNode)oPath.getLastPathComponent();
			if(!((DefaultMutableTreeNode)oNode.getParent()).isRoot())
			{
				setStatus("Can't paste "+UserManager.m_sEditBuffer+" onto "+oNode.toString());
				Toolkit.getDefaultToolkit().beep();
				return;
			}
			Enumeration en=oNode.children();
			for(; en.hasMoreElements();)
			{
				if(en.nextElement().toString().equals(UserManager.m_sEditBuffer))
				{
					setStatus("Node "+UserManager.m_sEditBuffer+" is already assigned to "+oNode.toString());
					Toolkit.getDefaultToolkit().beep();
					return;
				}
			}
			en=oNode.getParent().children();
			for(; en.hasMoreElements();)
			{
				if(en.nextElement().toString().equals(UserManager.m_sEditBuffer))
				{
					setStatus("Can't paste "+UserManager.m_sEditBuffer+" onto "+oNode.toString());
					Toolkit.getDefaultToolkit().beep();
					return;
				}
			}
			m_oTreeModel.insertNodeInto(new DefaultMutableTreeNode(UserManager.m_sEditBuffer),
									  oNode,
									  oNode.getChildCount());
			if(oNode.getChildCount()<=1)
			{
				m_oTreeModel.reload(oNode);
			}
			UserManager.m_sEditBuffer = null;
			UserManager.m_bUpdated = true;
		}
		else
		{
			setStatus("Can't paste: Clip board empty");
			Toolkit.getDefaultToolkit().beep();
		}
	}

	void delete()
	{
		int		optVal= -1;
		boolean	bUser = false,
				bGroup= false;
		try
		{
			TreePath oPath =  m_oSelectionModel.getSelectionPath();
			if(oPath.getPathCount() < 1)
			{
				return;
			}
			DefaultMutableTreeNode oNode= (DefaultMutableTreeNode)oPath.getLastPathComponent();
			MutableTreeNode oParent		= (MutableTreeNode)oNode.getParent();
			String sMsg = "";
			if( m_oSelectionModel == m_oUsersTree.getSelectionModel())
			{
				sMsg += "If you delete this user,  all memberships\n";
				sMsg += "in usergroups and all its assignments to\n";
				sMsg += "views will be removed.\n\n";
				bUser = true;
			}
			else if( m_oSelectionModel == m_oGroupsTree.getSelectionModel())
			{
				if(((DefaultMutableTreeNode)oParent).isRoot())
				{
					sMsg += "If you delete this usergroup, all its assignments\n";
					sMsg += "to views will be removed.\n\n";
					bGroup = true;
				}
				else
				{
					optVal = 0;
					/*
					 * DON'T DO THE FOLLOWING:
					 * bUser  = true;
					 */
				}
			}
			else if( m_oSelectionModel == m_oViewsTree.getSelectionModel())
			{
				if(!((DefaultMutableTreeNode)oParent).isRoot())
				{
					optVal = 0;
				}
			}
			if(optVal != 0)
			{
				String sSlash = System.getProperty("file.separator");
				sMsg += "Are you sure you want to delete ";
				sMsg += oNode.toString();
				sMsg += "?";
				optVal = JOptionPane.showConfirmDialog(UserGroupViewMain.this.getContentPane(),
													   sMsg,
													   "Confirm delete",
													   JOptionPane.YES_NO_OPTION,
													   JOptionPane.WARNING_MESSAGE,
													   new ImageIcon("data/images/lightbulb.gif"));
			}
			if(optVal == 0)
			{
				UserManager.m_bUpdated = true;
				m_oTreeModel.removeNodeFromParent(oNode);
				m_oTreeModel.reload(oParent);
				setStatus("Node "+oNode.toString()+" has been deleted.");
				if(bUser)
				{
					UserManager.delete(UserManager.USER, oNode.toString());
					deleteAllMatch(UserManager.GROUP, oNode.toString());
					deleteAllMatch(UserManager.VIEW, oNode.toString());
				}
				else if(bGroup)
				{
					UserManager.delete(UserManager.GROUP, oNode.toString());
					deleteAllMatch(UserManager.VIEW, oNode.toString());
				}
				else
				{
					UserManager.delete(UserManager.VIEW, oNode.toString());
				}
			}
		}
		catch (Exception ex)
		{
			setStatus("Must select the node to be deleted.");
			Toolkit.getDefaultToolkit().beep();
		}
	}
	
	private void deleteAllMatch(int whichTree, String nodeName)
	{
		DefaultTreeModel oModel			= null;
		switch(whichTree)
		{
			case UserManager.GROUP:
				oModel	= (DefaultTreeModel)m_oGroupsTree.getModel();
				break;
			case UserManager.VIEW:
				oModel	= (DefaultTreeModel)m_oViewsTree.getModel();
				break;
			default:
				break;
		}
		DefaultMutableTreeNode oRoot	= (DefaultMutableTreeNode)oModel.getRoot();
		for(Enumeration en=oRoot.children(); en.hasMoreElements(); )
		{
			DefaultMutableTreeNode temp = (DefaultMutableTreeNode)en.nextElement();
			for(Enumeration en2=temp.children(); en2.hasMoreElements(); )
			{
				DefaultMutableTreeNode temp2 = (DefaultMutableTreeNode)en2.nextElement();
				if(temp2.toString().equals(nodeName))
				{
					oModel.removeNodeFromParent(temp2);
					oModel.reload(temp);
				}
			}
		}
	}

}

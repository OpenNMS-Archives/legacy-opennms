//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.operator.components;

import javax.swing.*;
import javax.swing.table.*;
import javax.swing.event.*;
import javax.swing.plaf.basic.*;
import javax.swing.plaf.ActionMapUIResource;

import java.awt.*;
import java.awt.event.*;

import java.util.Vector;

import org.opennms.bb.eui.common.components.BBColumnEditor;
import org.opennms.bb.eui.common.components.BBTextField;
import org.opennms.bb.eui.common.components.TableSorter;

/**
 * OperatorEventsTable is table that has the ability to be sorted
 * by column
 *
 * @author Sowmya
 */
public class OperatorEventsTable extends JTable
{
	static final int ACTION_COL = 5;
	static int iLastEditingRow  = -1;
	static int iLastEditingCol  = -1;

	TableSorter eventsSorter;
	
	public OperatorEventsTable(Vector data, Vector colNames, Vector tasks)
	{
		OperatorEventsTableModel infoTableModel =  
							new OperatorEventsTableModel(data, colNames);


		// set single selection
		setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

		// background
		setSelectionBackground(Color.gray);

		// Do not allow reordering of columns
		getTableHeader().setResizingAllowed(false);
		getTableHeader().setReorderingAllowed(false);
		eventsSorter = new TableSorter(infoTableModel);
		eventsSorter.addMouseListenerToHeaderInTable(this);

		setModel(eventsSorter);

		// Do not show grid
		setShowHorizontalLines(true);
		setShowVerticalLines(false);

		/***********************************************************************/
		//setAutoResizeMode(AUTO_RESIZE_OFF);

		TableColumn severityColumn = getColumnModel().getColumn(0);
		TableColumn timeColumn = getColumnModel().getColumn(1);
		TableColumn dpnameColumn = getColumnModel().getColumn(2);
		TableColumn hostColumn = getColumnModel().getColumn(3);
		TableColumn eventColumn = getColumnModel().getColumn(4);
		TableColumn actionColumn = getColumnModel().getColumn(ACTION_COL);
		TableColumn autoColumn = getColumnModel().getColumn(6);

		severityColumn.setMinWidth(70);
		severityColumn.setMaxWidth(70);
		timeColumn.setMinWidth(80);
		timeColumn.setMaxWidth(80);
		dpnameColumn.setMinWidth(65);
		dpnameColumn.setMaxWidth(65);
		hostColumn.setMinWidth(65);
		hostColumn.setMaxWidth(65);
		eventColumn.setMinWidth(150);
		actionColumn.setMinWidth(150);
		actionColumn.setMaxWidth(150);
		autoColumn.setMinWidth(65);
		autoColumn.setMaxWidth(65);

		//sizeColumnsToFit(0);

		final BBActionRenderer renderer = new BBActionRenderer();
		
		actionColumn.setCellRenderer(renderer);

		BBActionEditor bbedit = new BBActionEditor();
		getColumnModel().getColumn(ACTION_COL).setCellEditor(bbedit);

		// Track the list selection to set focus to the editor component
		getSelectionModel().addListSelectionListener(new ListSelectionListener()
		{
			public void valueChanged(ListSelectionEvent e)
			{
				int iLastEditingRow  = -1;
				int iLastEditingCol  = -1;
	
				int iSelectedRow = getSelectedRow();
				int iSelectedCol = getSelectedColumn();
				int iRowCount    = getRowCount();
			
				for (int iIndex=0; iIndex < iRowCount; iIndex++)
				{
					
					//setValueAt(new Boolean(iIndex == iSelectedRow) ,iIndex, ACTION_COL);
					//setValueAt(  ,iIndex, ACTION_COL);
					
				}
			
				repaint();
				
				ListSelectionModel lsm = (ListSelectionModel)e.getSource();
				if(!(lsm.isSelectionEmpty()))
				{
					if (iSelectedCol > 0)
					{
						editCellAt(iSelectedRow, iSelectedCol);
						//getEditorComponent().requestFocus();
						setValueAt("Running" ,iSelectedRow, iSelectedCol);
					}
				}
				else // selection empty
				{
					for (int iIndex=0; iIndex < iRowCount; iIndex++)
					{
					//	setValueAt(Boolean.FALSE, iIndex, ACTION_COL);
					}

					iLastEditingRow = -1;
					iLastEditingCol = -1;

					repaint();
				}
			}
		});

		getColumnModel().addColumnModelListener(new TableColumnModelListener()
		{
			public void columnSelectionChanged(ListSelectionEvent e)
			{
				ListSelectionModel lsm = (ListSelectionModel)e.getSource();

				if(!(lsm.isSelectionEmpty()))
				{
					int iSelectedRow = getSelectedRow();
					int iSelectedCol = getSelectedColumn();

					if (iSelectedCol == ACTION_COL && iSelectedRow > -1)
					{
						editCellAt(iSelectedRow, iSelectedCol);
						//getEditorComponent().requestFocus();
					}
				}
			}

			public void columnAdded(TableColumnModelEvent e) { }

			public void columnMoved(TableColumnModelEvent e) { }

			public void columnRemoved(TableColumnModelEvent e) { }

			public void columnMarginChanged(ChangeEvent e) { }

		});
		/***********************************************************************/
	}

	/**
 	 * Selects the cell (row, col)
 	 */
	public void selectCellAt(int row, int col)
	{
		setRowSelectionInterval(row, row);
		setColumnSelectionInterval(col, col);
	}


	/**
	 * The table sorter maintains the original table row indices in the 
	 * order they are currently sorted in - return the original row index
	 * of the row currently selected.
	 */
	public int getOriginalRowIndex(int iSelRow)
	{
		int[] indexes =  eventsSorter.getIndexes();
		
		return indexes[iSelRow];
	}
	
	/**
	 * Returns the special color renderer for the 'severity' column
	 */
	public TableCellRenderer getCellRenderer(int row, int col)
	{
		String value = ((String)getColumnName(col)).toLowerCase();

		if (value.indexOf("severity") != -1)
		{
			return new EventsSeverityCellRenderer();
		}
/*		if (value.indexOf("action") != -1)
		{
			return new EventsActionCellRenderer();
		}
*/		else
			return super.getCellRenderer(row, col);
	}

	public void setValueAt(String value, int row, int col)
	{
		
		super.setValueAt(value, row, col);
	}

	public int columnHeaderWidth(TableColumn col)
	{
		TableCellRenderer renderer = col.getHeaderRenderer();
		Component comp = renderer.getTableCellRendererComponent(this, col.getHeaderValue(), false, false, 0, 0);
		return comp.getPreferredSize().width;
	}

}


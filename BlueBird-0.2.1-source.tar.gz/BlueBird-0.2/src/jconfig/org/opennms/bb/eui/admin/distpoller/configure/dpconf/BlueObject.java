//-------------------------------------------------------------------------------------------
//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

//--------------------------------------------------------------------------------------------

package org.opennms.bb.eui.admin.distpoller.configure.dpconf;

import java.awt.*;
import javax.swing.*;

/**
* This class enebles the developer to get/set 'look&feel' for 
* the user interface. <p>
*
* Example usage:
* <pre>
*	JFrame frame = new JFrame("The Frame");
*	....
*	....
* 	String sName = "Motif";
*	BlueObject.setLookAndFeel(sName);
*	SwingUtilities.updateComponentTreeUI(frame);
*	frame.pack();
* </pre>
* When executed, all the ui components pertained to "The Frame"
* will adopt to Motif look&feel.
*
* @author	chitta
* @version	1.0
*/
public class BlueObject
{
	/**
	* Static members first:
	*/
	static final String sMetal= "Metal";
	static final String sMetalClassName = "javax.swing.plaf.metal.MetalLookAndFeel";

	static final String sMotif = "Motif";
	static final String sMotifClassName = "com.sun.java.swing.plaf.motif.MotifLookAndFeel";

	static final String sWindows = "Windows";
	static final String sWindowsClassName ="com.sun.java.swing.plaf.windows.WindowsLookAndFeel";

	/**
	* Constructor
	*/
	public BlueObject()
	{
	}

	/**
	* Method getLookAndFeel():
	* This method returns a string indicating the current look&feel.
	*
	* @return	String "Metal"/"Motif" or "Windows"
	* @see	javax.swing.UIManager
	*/
	public static String getLookAndFeel()
	{
		String sName = UIManager.getLookAndFeel().getClass().getName();
		if(sName.indexOf(BlueObject.sMetalClassName) >= 0)
		{
			sName = sMetal;
		}
		else if(sName.indexOf(BlueObject.sMotifClassName) >= 0)
		{
			sName = sMotif;
		}
		else if(sName.indexOf(BlueObject.sWindowsClassName) >= 0)
		{
			sName = sWindows;
		}
		return sName;
	}

	/**
	* Method setLookAndFeel():
	* This method resets the current look&feel to the one requested.
	*
	* @param	nName String "Metal"/"Motif" or "Windows" indicating the desired l&f
	* @see	javax.swing.UIManager
	*/
	public static void setLookAndFeel(String sName)
	{
		if(sName.indexOf(BlueObject.sMetal) >= 0)
		{
			sName = sMetalClassName;
		}
		else if(sName.indexOf(BlueObject.sMotif) >= 0)
		{
			sName = sMotifClassName;
		}
		else if(sName.indexOf(BlueObject.sWindows) >= 0)
		{
			sName = sWindowsClassName;
		}
		try
		{
			UIManager.setLookAndFeel(sName);
		}
		catch (Exception ex)
		{
			System.err.println("Could not load LookAndFeel: " + sName);
		}
	}

}

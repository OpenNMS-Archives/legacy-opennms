//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.admin.snmp.components;

import java.awt.*;

import javax.swing.*;
import javax.swing.table.*;

import java.util.Vector;

import org.opennms.bb.eui.common.components.*;

/**
 * SnmpDefaultsEntryTable sets appropriate cell editors and also
 * provides a method to validate cell values
 *
 * @author Sowmya
 *
 */
public class SnmpDefaultsEntryTable extends BBEntryTable
{

	public SnmpDefaultsEntryTable(Vector rowData, Vector colNames)
	{
		super(rowData, colNames);

	}

	public TableCellEditor getCellEditor(int row, int col)
	{
		String value = ((String)getValueAt(row, ATTRIB_COLUMN)).toLowerCase();

		if (value.indexOf("timeout") != -1)
		{
			SnmpDefaultsTimeoutTextField colText = new SnmpDefaultsTimeoutTextField();
			return new SnmpColumnEditor(colText);
		}

		else if (value.indexOf("retries") != -1)
		{
			WholeNumberTextField colText = new WholeNumberTextField();
			return new SnmpColumnEditor(colText);
		}

		else
			return super.getCellEditor(row, col);
	}

	public boolean validateValues()
	{
		// check default values
		Vector defaultData = (Vector)getData();

		int iRowCount = getRowCount();
		for (int iRowIndex=0; iRowIndex < iRowCount ; iRowIndex++)
		{
			Vector row  = (Vector)defaultData.elementAt(iRowIndex);
			Object temp = row.elementAt(1);

			// Check formats for known fields
			String rowID = ((String)row.elementAt(0)).toLowerCase();

			if (rowID.indexOf("timeout") != -1)
			{
				String  timeOutVal = (String)temp;
				boolean bRet = SnmpDefaultsTimeoutTextField.checkTimeOutFormat(timeOutVal);
				if (timeOutVal.equals("") || bRet == false)
				{
	 				JOptionPane.showMessageDialog(null, 
					"Default Timeout field is blank or the format is incorrect", 
					"Default Timeout value", JOptionPane.ERROR_MESSAGE);
	
					return false;
				}
			}

		}
		
		return true;
	}
}

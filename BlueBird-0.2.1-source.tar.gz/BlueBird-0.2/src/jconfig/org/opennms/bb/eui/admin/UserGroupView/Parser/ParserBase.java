//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
package org.opennms.bb.eui.admin.UserGroupView.Parser;

import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.JOptionPane;
import org.w3c.dom.*;

import org.opennms.bb.common.utils.BBParser;

/**
 * @author Chitta Basu
 *
 * Modifications:
 * 04/18/00 - Changed the parser to extend BBParser - Sowmya
 *
 */
class ParserBase extends BBParser
{
	public ParserBase()
	{
		super();
	}

	protected boolean processNode(Node node)   
	{
	  boolean bRet = true;

      switch(node.getNodeType())      
	  {         
	     case Node.ATTRIBUTE_NODE:
            processAttribute((Attr)node);            
			break;
         case Node.CDATA_SECTION_NODE:
            processCDATASection((CDATASection)node);            
			break;
         case Node.COMMENT_NODE:            
		    processComment((Comment)node);
            break;         
		 case Node.DOCUMENT_NODE:
            processDocument((Document)node);            
			break;
         case Node.DOCUMENT_FRAGMENT_NODE:
            processDocumentFragment((DocumentFragment)node);
            break;
		 case Node.DOCUMENT_TYPE_NODE:
            processDocumentType((DocumentType)node);            
			break;
         case Node.ELEMENT_NODE:
            processElement((Element)node);
			break;
         case Node.ENTITY_NODE:            
		    processEntity((Entity)node);
            break;         
		 case Node.ENTITY_REFERENCE_NODE:
            processEntityReference((EntityReference)node);
            break;         
		 case Node.NOTATION_NODE:
            processNotation((Notation)node);            
			break;
         case Node.PROCESSING_INSTRUCTION_NODE:
            processProcessingInstruction((ProcessingInstruction)node);
            break;         
		 case Node.TEXT_NODE:
            processText((Text)node);            
			break;         
		 default:
            JOptionPane.showMessageDialog(null,
                                          "Found a node of unknow type.\n" + 
                                          "You should upgrade to the latest version!",
                                          "ParserBase",
                                          JOptionPane.ERROR_MESSAGE);      
	  		bRet = false;

	  	    break;
	  }   

	  return bRet;

	}

	protected void processAttribute(Attr attr)   
	{
	}
	protected void processCDATASection(CDATASection sec)
	{      
      System.out.println("[CDATA[" + sec.getData() + "]]");
	}
	protected void processComment(Comment comm)   
	{
	}
	protected boolean processDocument(Document doc)   
	{
      Element root = doc.getDocumentElement();
	  if(null != root)
	  {
         return processElement(root);
	  }
	  else
	  	return false;
	}
   protected void processDocumentFragment(DocumentFragment df)
   {      
     NodeList nl = df.getChildNodes();      
	 int size = nl.getLength();
     for(int i = 0;i < size;i++)
	 {
	   processNode(nl.item(i));
	 }
	}
	protected void processDocumentType(DocumentType dtd)
	{ 
	  // does nothing as we don't bother with DTD   
	}
	protected boolean processElement(Element el)
	{
      NamedNodeMap attrMap = el.getAttributes();
      int size = attrMap.getLength();      
	  for(int i = 0;i < size;i++)
         processAttribute((Attr)attrMap.item(i));
      NodeList nl = el.getChildNodes();      
	  size = nl.getLength();
      for(int i = 0;i < size;i++)
	  {
	     processNode(nl.item(i));
	  }
	  return true;
	}
	protected void processEntity(Entity ent)
	{
	}
	protected void processEntityReference(EntityReference er)
	{      
	}
	protected void processNotation(Notation not)   
	{
	}
	protected void processProcessingInstruction(ProcessingInstruction pi)
	{      
	}
	protected void processText(Text text)   
	{
      String st = text.getData();
      // no need to display the newlines between elements!
      if(st.trim().length() != 0)      
	  {
	  }   
	}

}

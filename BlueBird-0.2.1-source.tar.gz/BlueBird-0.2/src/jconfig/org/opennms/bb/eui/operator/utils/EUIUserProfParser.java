//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.operator.utils;

import org.w3c.dom.*;

import java.io.*;
import java.util.Vector;
import java.util.Hashtable;

import org.opennms.bb.common.utils.BBParser;

/**
 * <pre>EUIUserProfileParser reads the user preferences for the real time
 * console from the user profile file
 *
 * It throws an IOException if the xml file is not found or if it does not
 * conform to its DTD </pre>
 *
 * @author Sowmya
 *
 * Modifications:
 * 04/18/00 - Changed the parser to extend BBParser - Sowmya
 *
 */
public class EUIUserProfParser extends BBParser
{
	Hashtable	userHash;

	/*
	 * XML TAGS that are relevant
	 */
	final String APPL		="appl";
	final String APPLNAME	="name";
	final String PARM		="parm";
	final String PARM_NAME	="parmName";
	final String PARM_VALUE	="value";

	/*
	 * Looking for
	 */
	final String RTC		="OperatorInterface";
	final String XPOS		="xPos";
	final String YPOS		="yPos";
	final String WIDTH		="Width";
	final String HEIGHT		="Height";
	final String TAB_PLACE	="tabPlacement";
	final String LOOKNFEEL	="lookAndFeel";
	final String VIEWTAB	="viewTab";
	final String MENU		="ExternalMenu";
	final String ICONBAR	="ExternalTools";

	final String VIEWS		="views";

	/**
 	 * Creates the DOM parser
 	 */
	public EUIUserProfParser()
	{
		super();
	}

	protected boolean processElement(Element el,boolean isRoot)
	{
		boolean bRet = false;

		String tag = el.getTagName();

		if (tag.equals(APPL))
		{
			m_curElement.replace(0, m_curElement.length(), APPL);

			// get 'name' atribute
			String applName = el.getAttribute(APPLNAME);

			if (applName.equals(RTC))
			{
				bRet = processOperatorElement(el);
			}
			else
				bRet = true;
		}

		else
		{
			boolean bNodeRet=true;

			NodeList nl = el.getChildNodes();
			int size = nl.getLength();

			for(int i = 0;i < size && bNodeRet ;i++)
				bNodeRet = processNode(nl.item(i));
			
			bRet = bNodeRet;
		}


		return bRet;
	}

	protected boolean processOperatorElement(Node opNode)
	{
		boolean bRet = true;

		m_curElement.replace(0, m_curElement.length(), APPL + ": " + RTC);

		userHash  = new Hashtable();
		Vector	  viewsVector = new Vector();

		NodeList nl = opNode.getChildNodes();
		int size = nl.getLength();
		for(int i = 0;i < size && bRet;i++)
		{
			Node curNode = nl.item(i);
			int  nodeType= curNode.getNodeType();

			if ( nodeType == Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();

				if(curTag.equals(PARM))
					bRet = processOperatorParmNode(curNode, viewsVector);
			}
			
		}

		if (viewsVector.size() > 0)
			userHash.put(VIEWS, viewsVector);

		return bRet;
	}

	protected boolean processOperatorParmNode(Node opNode, Vector viewsVector)
	{
		boolean bRet = true;

		m_curElement.replace(0, m_curElement.length(), PARM);

		String	  parmName=null;

		NodeList nl = opNode.getChildNodes();
		int size = nl.getLength();

		for(int i = 0;i < size && bRet;i++)
		{
			Node curNode = nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();

				m_curElement.replace(0, m_curElement.length(), curTag);

				if(curTag.equals(PARM_NAME))
				{
					parmName = processParmName(curNode);
					if (null != parmName)
						parmName.toLowerCase();
					else
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}

				}
				else if(curTag.equals(PARM_VALUE))
				{
					String parmValue = processParmValue(curNode);
					if (null == parmValue)
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
						
						continue;
					}

					else if(parmName.equalsIgnoreCase(XPOS))
					{
						// if number format exception, ignore
						try
						{
							Integer xpos = new Integer(parmValue);
							userHash.put(XPOS, xpos);
						}
						catch(Exception e) {}
					}

					else if(parmName.equalsIgnoreCase(YPOS))
					{
						// if number format exception, ignore
						try
						{
							Integer ypos = new Integer(parmValue);
							userHash.put(YPOS, ypos);
						}
						catch(Exception e) {}
					}

					else if(parmName.equalsIgnoreCase(WIDTH))
					{
						// if number format exception, ignore
						try
						{
							Integer width = new Integer(parmValue);
							userHash.put(WIDTH, width);
						}
						catch(Exception e) {}
					}

					else if(parmName.equalsIgnoreCase(HEIGHT))
					{
						// if number format exception, ignore
						try
						{
							Integer height = new Integer(parmValue);
							userHash.put(HEIGHT, height);
						}
						catch(Exception e) {}
					}

					else if(parmName.equals(TAB_PLACE))
					{
						userHash.put(TAB_PLACE, parmValue);
					}

					else if(parmName.equals(LOOKNFEEL))
					{
						userHash.put(LOOKNFEEL, parmValue);
					}

					else if(parmName.equals(MENU))
					{
						userHash.put(MENU, parmValue);
					}

					else if(parmName.equals(ICONBAR))
					{
						userHash.put(ICONBAR, parmValue);
					}

					else
					{
						// check if view tab
						if (parmName.startsWith(VIEWTAB))
						{
							viewsVector.add(parmValue);
						}
					}
				}
			}
		}

		return bRet;
	}

	protected String processParmName(Node parmNameNode)
	{
		String parmName=null;

		Node temp = parmNameNode.getChildNodes().item(0);
		if (temp.getNodeType() == Node.TEXT_NODE)
			parmName = ((Text)temp).getData();
		
		return parmName;
	}

	/**
	 */
	public Hashtable getUserProfile()
	{
		return userHash;
	}

}

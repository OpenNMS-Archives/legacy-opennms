//-------------------------------------------------------------------------------------------
//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

//--------------------------------------------------------------------------------------------

package org.opennms.bb.eui.admin.distpoller.configure.parsers;
import org.opennms.bb.eui.admin.distpoller.configure.dpconf.UserManager;

import org.w3c.dom.*;

import java.io.*;
import java.util.Vector;
import java.util.Enumeration;

import org.opennms.bb.common.utils.BBParser;

/**
 * @author Jaya Krishna Chakravarthula
 *
 * Modifications:
 * 04/18/00 - Changed the parser to extend BBParser - Sowmya
 */
public class packageXmlParser extends BBParser
{
	
	Vector 	packagesData		=	new Vector();
	Vector	m_rangedefData		=	new Vector();
	Vector	myRangeVector;

	Vector  packageDetailsVector;

	Vector rangedefCols, defCols, erangeCols, irangeCols,specificCols, urlCols;

	Vector rangedefData, irangeData, erangeData, specificData, urlData;


	String packName = "";
	boolean calendarExists 		=	false;

	// Number of default parameters
	int 	iNumDefParms=0;

	/*
	 * XML TAGS
	 */
	final String PARMS		= "parms";
	final String PARM 		= "parm";
	final String PARM_NAME		= "parmName";
	final String PARM_VALUE		= "value";

	final String PACKAGES		= "packages";
	final String PACKAGE 		= "package";
	final String PACKAGENAME 	= "packageName";
	final String PACKAGECOMMENTS 	= "packageComments";
	final String FILTER 		= "filter";
	final String FILTERCOMMENT 	= "filterComment";
	final String FILTEREXPR 	= "filterExpr";

	final String RANGES		= "ranges";

	final String RANGEDEF 		= "rangeDef";
	final String IRANGE		= "irange";
	final String ERANGE		= "erange";

	final String SPECIFIC		= "specific";
	final String URL			= "url";

	final String SERVICE 		= "service";
	final String SERVICENAME 	= "serviceName";
	final String MODELS 		= "models";
	final String MODELNAME 		= "modelName";
	final String CALENDARS 		= "calendars";
	final String REPEATINGCAL 	= "repeatingCal";
	final String ONETIMECAL 	= "onetimeCal";
	
	
	public packageXmlParser()
	{
		super();
	}

	protected boolean processElement(Element el, boolean isRoot)
	{
		boolean bRet	=	false;
		String tag	 	= 	el.getTagName();

		if (tag.equals(PACKAGES))
		{
			bRet = processPackageElement(el);

		}
		else
		{
			boolean bNodeRet	=	true;
			NodeList nl 	= 	el.getChildNodes();
			int size 		=	nl.getLength();

			for(int i = 0;i < size && bNodeRet ;i++)
				bNodeRet = processNode(nl.item(i));
			
			bRet 			=	 bNodeRet;
		}
		return bRet;
	}

	protected boolean processPackageElement(Node defNode)
	{
		boolean bRet	=	 true;
		NodeList nl 	=	 defNode.getChildNodes();
		int size 		=	 nl.getLength();

		for(int i = 0;i < size && bRet ;i++)
		{
			Node curNode = nl.item(i);
			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
			
				if(curTag.equals(PACKAGE))
					bRet = processPackageParms(curNode);
			}
			
		}
		return bRet;

	}

	protected boolean processPackageParms(Node parmsNode)
	{
		boolean bRet 		= 	true;
		String tempElement 	= 	null;
		packageDetailsVector	=	new Vector();
		NodeList nl 		=	parmsNode.getChildNodes();
		int size 			=	nl.getLength();
		myRangeVector		= 	new Vector();

		for(int i = 0;i < size && bRet;i++)
		{
			Node curNode 	=	nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag 	=	 ((Element)curNode).getTagName();
			
				if (curTag.equals(PACKAGENAME))
				{
					packName 	= 	"";
					tempElement		=	 processPollerValue(curNode);
					if (null != tempElement)
					{
						packName = tempElement;
						packName = packName.trim();
						packageDetailsVector.addElement(curTag + " : " +tempElement);
					}
					else
					{
						bRet 		=	 false;
						m_errNum 	=	 NULL_VALUE_ERR;
					}
					
				}
				else if (curTag.equals(PACKAGECOMMENTS))
				{
					tempElement 	=	 processPollerValue(curNode);
					UserManager.m_oPP.put(packName, tempElement.trim());

					if (null != tempElement)
					{
						packageDetailsVector.addElement(curTag + " : " +tempElement);
					}
					else
					{
						bRet 		=	 false;
						m_errNum 	=	 NULL_VALUE_ERR;
					}
				}
				else if (curTag.equals(FILTER))
				{
						
					boolean packageRet 	=	  processFilterParms(curNode);
					bRet 	=	 packageRet;
									
				}
				else if (curTag.equals(RANGES))
				{
				
					boolean calRet 		=	 processRangesParms(curNode);
					bRet 	=	 calRet;
	
					m_rangedefData.add(packName);
					m_rangedefData.add(rangedefData);
					
					myRangeVector.add(rangedefData);
					myRangeVector.add(irangeData);
					myRangeVector.add(erangeData);
					myRangeVector.add(specificData);
					myRangeVector.add(urlData);
				}

				else if (curTag.equals(SERVICE))
				{
					boolean calRet 		=	 processServiceParms(curNode);
					bRet 	=	 calRet;
					
				}
				else if (curTag.equals(CALENDARS))
				{
					calendarExists		= 	 true;
					boolean calRet 		=	 processCalendarsParms(curNode);
					bRet 				=	 calRet;
				}
			
			}
		}

		if (calendarExists == false)
		{
			packagesData.addElement(packageDetailsVector);
			calendarExists   =  true;
		}

		UserManager.m_oRangeTable.put(packName.trim(), myRangeVector);

		return bRet;
	}

	protected boolean processServiceParms(Node parmsNode)
	{

		boolean bRet 			= 	true;
		String tempElement 		= 	null;
		Vector serviceParmsVector 	= 	new Vector();
		NodeList nl 			= 	parmsNode.getChildNodes();
		int size 				= 	nl.getLength();
		String sName 			=	new String();

		for(int i = 0;i < size && bRet;i++)
		{
			Node curNode 		= 	nl.item(i);

			if(curNode.getNodeType()== 	Node.ELEMENT_NODE)
			{
				String curTag	= 	((Element)curNode).getTagName();
					
				if (curTag.equals(SERVICENAME))
				{
					tempElement	= 	processPollerValue(curNode);
					if (null 	!= tempElement)
					{
						packageDetailsVector.addElement(curTag + " : " +tempElement);
						sName 	=	packName.trim() + " : " + tempElement;
					}
					else
					{
						bRet 		= 	false;
						m_errNum 	=	NULL_VALUE_ERR;
					}
				}

				else if (curTag.equals(PARMS))
				{
				 	processParms(curNode, serviceParmsVector);
					UserManager.m_oServiceTable.put(sName, serviceParmsVector);
				}

			}
		}
		return bRet;
	
	}

	protected boolean processCalendarsParms(Node parmsNode)
	{
		boolean bRet 		= 	true;
		NodeList nl 		= 	parmsNode.getChildNodes();
		int size			=	nl.getLength();
		String tempElement 	= 	null;
		Vector sVector		= 	new Vector();
	
		for(int i = 0;i < size && bRet;i++)
		{
			Node curNode 	=	nl.item(i);

			if(curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag 	=	 ((Element)curNode).getTagName();
		
				if (curTag.equals(ONETIMECAL))
				{
					tempElement		= 	processPollerValue(curNode);
					if (null != tempElement)
					{
						packageDetailsVector.addElement(curTag + " : " +tempElement);
						//UserManager.m_oOCAL.put(packName.trim() + " : " + tempElement.trim(), curTag);
						UserManager.m_oCalendarsTable.put(packName.trim() + " : " + tempElement.trim() + " : " + "O", "O");

					}
					else
					{
						bRet 		= 	false;
						m_errNum 	= 	NULL_VALUE_ERR;
					}
				}
				else if (curTag.equals(REPEATINGCAL))
				{
					tempElement 	= 	processPollerValue(curNode);
					if (null != tempElement)
					{
						packageDetailsVector.addElement(curTag + " : " +tempElement);
						UserManager.m_oCalendarsTable.put(packName.trim() + " : " + tempElement.trim() + " : " + "R",  "R");
					}
					else
					{
						bRet 		=	 false;
						m_errNum 	=	 NULL_VALUE_ERR;
					}
				
				}
				
			}
		}

		packagesData.addElement(packageDetailsVector);
		return bRet;
	}
	
			
	protected String processPollerValue(Node parmValueNode)
	{
		String value	=	null;

		Node temp		=	parmValueNode.getChildNodes().item(0);
	
		if (temp.getNodeType() == Node.TEXT_NODE)	
		{
			value = ((Text)temp).getData();
		}
		else if (temp.getNodeType() == Node.CDATA_SECTION_NODE)
		{
			value = ((CDATASection)temp).getData();
		}
		return value;
	}

	
	protected boolean processFilterParms(Node parmsNode)
	{
		boolean bRet 		=	 true;
		String tempElement  	=	 null;
		NodeList nl 		=	 parmsNode.getChildNodes();
		int size 			=	 nl.getLength();
		String fString		=	new String();

		for(int i = 0;i < size && bRet;i++)
		{
			Node curNode 	=	 nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = 	((Element)curNode).getTagName();

				if(curTag.equals(FILTERCOMMENT))
				{
					tempElement		=	 processPollerValue(curNode);
					if (null != tempElement)
					{
						fString = tempElement;
					}
					else
					{
						bRet 		=	 false;
						m_errNum	=	 NULL_VALUE_ERR;
					}
				}
				else if (curTag.equals(FILTEREXPR)) 
				{
					tempElement		=	 processPollerValue(curNode);
					if (null != tempElement)
					{
						fString += " : " + tempElement;
						UserManager.m_oViews.put(packName, fString);
					}
					else
					{
						bRet 		=	 false;
						m_errNum 	=	 NULL_VALUE_ERR;
					}
				}
			}
		}
		return bRet;
	}
	
	protected boolean processRangesParms(Node parmsNode)
	{
		boolean bRet 	=	 true;
		NodeList nl		=	 parmsNode.getChildNodes();
		int size 		=	 nl.getLength();
		erangeData 		= 	 new Vector();
		specificData	=	 new Vector();
		rangedefData 	=	 new Vector();
		irangeData 		= 	 new Vector();
		urlData 		=	 new Vector();

		for(int i = 0;i < size && bRet;i++)
		{
			Node curNode 	= 	nl.item(i);
			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag	 =	 ((Element)curNode).getTagName();
			
				if(curTag.equals(RANGEDEF))
				{
					m_curElement.replace(0, m_curElement.length(), "default");

					rangedefCols = new Vector(2);
					rangedefCols.add("Attribute");
					rangedefCols.add("Value");
				
					
					bRet 		=	 processRangeDefRangeDef(curNode);

					// Create column names vector
					int iNumCols = rangedefData.size();
					defCols = new Vector(iNumCols);
					for (int iIndex=0; iIndex < iNumCols; iIndex++)
					{
						Vector temp = (Vector)rangedefData.elementAt(iIndex);
						defCols.add(temp.elementAt(0)); // attribute
					}
				}

				else if (curTag.equals(ERANGE)) 
				{
				
					m_curElement.replace(0, m_curElement.length(), "eranges");

					// column names
					erangeCols = new Vector(2);
					erangeCols.add(0, "From IP Address");
					erangeCols.add(1, "To IP Address");

					bRet 		=	 processRangesERange(curNode);
					
				}

				else if (curTag.equals(IRANGE)) 
				{
					m_curElement.replace(0, m_curElement.length(), "iranges");

					// column names
					irangeCols = new Vector(iNumDefParms+2);
					irangeCols = (Vector)defCols.clone();
					irangeCols.add(0, "From IP Address");
					irangeCols.add(1, "To IP Address");

					bRet 		=	 processRangesIRange(curNode);
					
					
				}

				else if (curTag.equals(SPECIFIC))
				{
					m_curElement.replace(0, m_curElement.length(), "specific");

					// column names
					specificCols = new Vector(iNumDefParms+2);
					specificCols = (Vector)defCols.clone();
					specificCols.add(0, "IP Address");

					bRet 		=	 processSpecificsSpecific(curNode);

				}
				else if (curTag.equals(URL))
				{
					m_curElement.replace(0, m_curElement.length(), "urls");

					// column names
					urlCols = new Vector(iNumDefParms+2);
					urlCols = (Vector)defCols.clone();
					urlCols.add(0, "File Name");

					bRet 		=	 processUrlsUrl(curNode);
				}

			}
		}

		return bRet;
	}
	
	protected boolean processRangeDefRangeDef(Node rangeDefNode)
	{
		boolean bRet 		= 	true;
		NodeList nl 		= 	rangeDefNode.getChildNodes();
		int size 			= 	nl.getLength();
	
		for(int i = 0;i < size; i++)
		{
			Node curNode	 = 	nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = 	((Element)curNode).getTagName();
		
				if(curTag.equals(PARMS))
				{
					bRet 	= 	processRangeDefParms(curNode);
				}
			}
		}
		
		return bRet;
	}

	protected boolean processRangeDefParms(Node parmsNode)
	{
		boolean bRet = true;
		NodeList nl = parmsNode.getChildNodes();
		int size = nl.getLength();

		for(int i = 0;i < size && bRet;i++)
		{
			Node curNode = nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
				if(curTag.equals(PARM))
				{
					Vector parm = processParm(curNode);

					if (parm.isEmpty() || parm.size() != 2)
					{
						bRet = false;
						m_errNum = ATTRIB_VALUE_PAIR_ERR;
					}
					else
					{
						rangedefData.add(parm);
						iNumDefParms++;
					}
				}
			}
		}
		return bRet;
	}


	protected boolean processRangesIRange(Node rangesNode)
	{
		boolean bRet	 =	 true;
		Vector rangeVector = 	new Vector();
		NodeList nl 	 =	 rangesNode.getChildNodes();
		int size		 = 	nl.getLength();

		for(int i = 0;i < size; i++)
		{
			Node curNode = 	nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = 	((Element)curNode).getTagName();
				if(curTag.equals(PARMS))
				{
					int iNumParms 	=	 processParmsTwo(curNode, rangeVector);
					irangeData.add(rangeVector);
				}
			}
		}
		return bRet;
	}

	protected boolean processRangesERange(Node rangesNode)
	{
		boolean bRet	 =	 true;
		Vector rangeVector = 	new Vector();
		NodeList nl 	 =	 rangesNode.getChildNodes();
		int size		 = 	nl.getLength();

		for(int i = 0;i < size; i++)
		{
			Node curNode = 	nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = 	((Element)curNode).getTagName();
				if(curTag.equals(PARMS))
				{
					int iNumParms 	=	 processParmsTwo(curNode, rangeVector);
					erangeData.add(rangeVector);
				}
			}
		}
		return bRet;
	}

	protected boolean processSpecificsSpecific(Node specificsNode)
	{
		boolean bRet		= 	true;
		Vector specificVector 	=	new Vector();
		NodeList nl 		=	specificsNode.getChildNodes();
		int size 			=	nl.getLength();

		for(int i = 0;i < size && bRet;i++)
		{
			Node curNode 	=	nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
				if(curTag.equals(PARMS))
				{
					int iNumParms = processParmsTwo(curNode, specificVector);
					specificData.add(specificVector);

				}
			}
		}
		return bRet;
	}

	protected boolean processUrlsUrl(Node urlsNode)
	{
		boolean bRet	=	 true;
		Vector urlVector 	=	 new Vector(iNumDefParms+1);
		NodeList nl 	=	 urlsNode.getChildNodes();
		int size 		=	 nl.getLength();

		for(int i = 0;i < size && bRet;i++)
		{
			Node curNode = 	nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag 	=	 ((Element)curNode).getTagName();

				if(curTag.equals(PARMS))
				{
					int iNumParms 	=	 processParmsTwo(curNode, urlVector);
					urlData.add(urlVector);
				}

			}
		}
		return bRet;

	}

	protected void processParms(Node tabNode, Vector tabVector)
	{
		NodeList nl 	=	tabNode.getChildNodes();
		int size 		= 	nl.getLength();

		for(int i = 0;i < size;i++)
		{
			Node curNode 	= 	nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
				
				if(curTag.equals(PARM))
				{
					Vector parm		=	 processParm(curNode);
					tabVector.add(parm);
				}

			}
		}
		
	}

	protected int processParmsTwo(Node tabNode, Vector tabVector)
	{
		int iNumParms=0;

		NodeList nl = tabNode.getChildNodes();
		int size = nl.getLength();

		for(int i = 0;i < size;i++)
		{
			Node curNode = nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
				if(curTag.equals(PARM))
				{
					Vector parm = processParm(curNode);

					if ( (!parm.isEmpty()) && (parm.size() == 2))
					{
						String parmValue = (String)parm.elementAt(1);

						tabVector.add(parmValue); // get the value alone
					
						iNumParms++;
					}
				}

			}
		}

		return iNumParms;
	}

	
	protected Vector processParm(Node parmsNode)
	{
		Vector parm		=	new Vector(2);

		NodeList nl		= 	parmsNode.getChildNodes();
		int size 		=	nl.getLength();

		for(int i = 0;i < size;i++)
		{

			Node curNode = nl.item(i);
			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
				if(curTag.equals(PARM_NAME))
				{
					String name = processParmName(curNode);
					if (null != name)
						parm.add(name);
				}
				else if(curTag.equals(PARM_VALUE))
				{
					String value = processParmValue(curNode);
					if (null != value)
						parm.add(value);
				}

			}
		}
		
		return parm;
	}

	protected String processParmName(Node parmNameNode)
	{
		String parmName	=	null;
		Node temp 		=	parmNameNode.getChildNodes().item(0);

		if (temp.getNodeType() == Node.TEXT_NODE)
			parmName = ((Text)temp).getData();
		
		return parmName;
	}

	//returns packages details data
	public Vector getPackageData()
	{
		return packagesData;
	}
	

	public Vector getRangedefCols() 
	{
		return (Vector)rangedefCols;
	}

	public Vector getErangeCols() 
	{	
		return (Vector)erangeCols;
	}
	
	public Vector getIrangeCols() 
	{	
		return (Vector)irangeCols;
	}
	
	public Vector getSpecificCols() 
	{	
		return (Vector)specificCols;
	}

	public Vector getUrlCols() 
	{
		return (Vector)urlCols;
	}

	public Vector getRangeDefData() 
	{
		return (Vector)m_rangedefData;
	
	}

}

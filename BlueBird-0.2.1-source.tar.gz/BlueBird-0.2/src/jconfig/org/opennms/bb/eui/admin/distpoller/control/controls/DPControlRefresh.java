//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.admin.distpoller.control.controls;

import javax.swing.*;
import java.io.*;
import java.util.Vector;

import org.opennms.bb.eui.admin.distpoller.control.utils.DPPollerPerfParser;

/**
 * <pre>DPControlRefresh is the refresh controller.
 *
 * It queries the poller for its performance data and returns this data
 * to the DpControl when asked for it.
 *
 * It also stores the xml stream received from the poller in a 'temp' 
 * directory for use by the DPControl </pre>
 */
public class DPControlRefresh extends DistPollerController
{
	DPPollerPerfParser		perfParser;

	public boolean process(String curPollerID)
	{
		if (null == curPollerID) // do not proceed
			return false;

		// this is where we'd query the poller to get the xml
		// For now just use the id to get to the filename
		String fileName = "data/common/conf/"
							+ curPollerID + "perfXML.xml";
		
		try
		{
			perfParser=new DPPollerPerfParser();
			perfParser.parse(fileName);

		} catch (Exception e)
		{
	 		JOptionPane.showMessageDialog(new JFrame(), 
					e.getMessage(),
					"Error! Unable to parse perf xml file", 
					JOptionPane.ERROR_MESSAGE);

			return false;
		}

		// store in temporary directory
		storeData(curPollerID, fileName);

		return true;
	}

	public Vector getPollerServices()
	{
		return perfParser.getModules();
	}

	public String getOpDataTimeStamp()
	{
		return perfParser.getCreationDate();
	}

	/**
	 * Store into the 'temp' sub-directory
	 */
	void storeData(String pollerID, String fileName)
	{
		FileReader	fileReader;
		FileWriter	fileWriter;

		File		tempFile=null;
		File		tempDir=null;

		final String  TEMP_DIR	="data/temp/";

		// create the temp directory if it does not already exist
		try
		{
			tempDir = new File(TEMP_DIR);
			if(!tempDir.exists())
				tempDir.mkdir();
		}
		catch (SecurityException secEx)
		{
			// cannot really proceed 
			return;
		}

		try
		{
			fileReader = new FileReader(fileName);

			// copy into the temp directory also
			String tempFileName = tempDir.getPath() + "/" + pollerID + ".perfXML.xml";

			tempFile = new File(tempFileName);
			tempFile.deleteOnExit();

			fileWriter = new FileWriter(tempFile.getPath());

			int curInt = fileReader.read();
			while ( curInt != -1)
			{
				fileWriter.write((char)curInt);
				curInt = fileReader.read();
			}

			fileWriter.flush();

		} catch (IOException e)
		{
			if (null != tempFile)
				tempFile.delete();
		}
			
	}
}

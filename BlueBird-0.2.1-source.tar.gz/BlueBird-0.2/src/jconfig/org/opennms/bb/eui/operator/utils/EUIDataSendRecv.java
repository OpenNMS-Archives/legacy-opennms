//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.operator.utils;

import java.util.Random;

import org.opennms.bb.eui.operator.components.OperatorBar;

/**
 * <pre>EUIDataSendRecv sends the request to the server and receives the
 * the data response
 *
 * @author Sowmya
 *
 */
public class EUIDataSendRecv 
{
	// eventually will be a xml data stream instead of a filename
	String dataFileName=null;

	// eventually will only use the other constructor -
	// will send the request to the servlet and get back the data
	public EUIDataSendRecv(String reqLevel, String qty, String severity, String ID)
	{
		if (reqLevel.equals(OperatorBar.VIEWS_LEVEL))
		{
			dataFileName = new String(
							"data/temp/euiViews.xml");
		}

		else if (reqLevel.equals(OperatorBar.CATEGORY_LEVEL))
		{
			dataFileName = new String(
							"data/temp/" +  ID + ".cat");
		}

		else if (reqLevel.equals(OperatorBar.DEVICES_LEVEL))
		{
			if (qty.equals("5"))
			{
				dataFileName = new String(
							"data/temp/nodes.5");
			}
			else if (qty.equals("10"))
			{
				dataFileName = new String(
							"data/temp/nodes.10");
			}
			else
			{
				int i = (new Random()).nextInt();
				if (i % 2 == 0)
				{
					dataFileName = new String(
									"data/temp/nodes.1");

				}
				else
				{
					dataFileName = new String(
									"temp/nodes.2");
				}
			}
		}

		else if (reqLevel.equals(OperatorBar.DAILY_LEVEL))
		{
			if (qty.equals("5d")) 
			{
				dataFileName = new String(
							"data/temp/daily.5");
			}
			else if (qty.equals("10d"))
			{
				dataFileName = new String(
							"data/temp/daily.10");
			}
			else 
			{
				int i = (new Random()).nextInt();
				if (i % 2 == 0)
				{
					dataFileName = new String(
							"data/temp/daily.1");
				}
				else
				{
					dataFileName = new String(
							"data/temp/daily.2");
				}
			}
		}

		else if (reqLevel.equals(OperatorBar.HOURLY_LEVEL))
		{
			if (qty.equals("12h"))
			{
				dataFileName = new String(
							"data/temp/hourly.12");
			}
			else if (qty.equals("24h"))
			{
				dataFileName = new String(
							"data/temp/hourly.24");
			}

			else 
			{
				int i = (new Random()).nextInt();
				if (i % 2 == 0)
				{
					dataFileName = new String(
							"data/temp/hourly.1");
				}
				else
				{
					dataFileName = new String(
							"data/temp/hourly.2");
				}
			}
		}
		
		else if (reqLevel.equals(OperatorBar.SERVICES_LEVEL))
		{
			if (qty.equals("30m"))
			{
				dataFileName = new String(
							"data/temp/services.30");
			}
			else if (qty.equals("60m"))
			{
				dataFileName = new String(
							"data/temp/services.60");
			}

			else
			{
				dataFileName = new String(
							"data/temp/services.all");
			}
		}

		else if (reqLevel.equals(OperatorBar.EVENTS_LEVEL))
		{
			if (severity.equalsIgnoreCase("Critical"))
			{
				dataFileName = new String(
							"data/temp/events.critical");
			}
			else if (severity.equalsIgnoreCase("Warning"))
			{
				dataFileName = new String(
							"data/temp/events.warning");
			}
			else if (severity.equalsIgnoreCase("Informational"))
			{
				dataFileName = new String(
						"data/temp/events.informational");
			}
			else
			{
				dataFileName = new String(
							"data/temp/events.all");
			}
		}

	}

	public EUIDataSendRecv(String dataRequest)
	{
	}
	
	public String getDataStream()
	{
		return dataFileName;
	}


	private String stripWhiteSpaces(String s1)
	{
		int iLen = s1.length();
		StringBuffer s2 = new StringBuffer(iLen);

		for (int iInd=0; iInd < iLen; iInd++)
		{
			char c = s1.charAt(iInd);
			if (c != ' ')
			{
				s2.append(c);
			}
		}

		return s2.toString();
	}

}

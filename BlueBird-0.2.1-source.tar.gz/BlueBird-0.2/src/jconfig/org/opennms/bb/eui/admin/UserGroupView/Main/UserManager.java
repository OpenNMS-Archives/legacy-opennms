//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
package org.opennms.bb.eui.admin.UserGroupView.Main;

import java.util.*;
import org.opennms.bb.eui.admin.UserGroupView.Parser.*;

public class UserManager
{
	public static final int USER	= 0;
	public static final int GROUP	= 1;
	public static final int VIEW	= 2;

	public static Hashtable	m_oUsers	= null;
	public static Hashtable	m_oGroups	= null;
	public static Hashtable	m_oViews	= null;
	public static Hashtable	m_oRules	= null;

	public static String		m_sOldId	= "";
	public static String		m_sNewId	= "";
	public static String		m_sBuffer	= "";
	public static String		m_sEditBuffer= null;
	public static int			m_iEditWhat	= -1; // Should be one of USER/GROUP/VIEW

	public static String		m_sVersion	= "0.0";
	public static String		m_sMsStation= "";

	public static boolean		m_bUpdated	= false;
	public static boolean		m_bRuleUpdated= false;
	public static boolean		m_bFigureUpdated= false;

	/**
	* Load user/group/views info' at startup from the xml files:
	*/
	public static boolean init()
	{
		m_oUsers	= new Hashtable();
		m_oGroups	= new Hashtable();
		m_oViews	= new Hashtable();
		m_oRules	= new Hashtable();

		String sSlash = System.getProperty("file.separator");
    String xmlDir = "data" + sSlash + "common" + sSlash + "conf" + sSlash;

		UserParser.load(xmlDir + "users.xml");
		GroupParser.load(xmlDir + "groups.xml");
		ViewParser.load(xmlDir + "views.xml");

		for(Enumeration e = m_oViews.keys(); e.hasMoreElements(); )
		{
			String sKey = (String)e.nextElement();
			String sVal = (String)m_oViews.get(sKey);

			int iCutOff = sVal.indexOf("!@#");
			String sRulePart = sVal.substring(0, iCutOff);
			String sCfgPart = sVal.substring(iCutOff+3, sVal.length());

			m_oViews.remove(sKey);
			m_oViews.put(sKey, sCfgPart);
			m_oRules.put(sKey, sRulePart);
		}

		return true;
	}

	/**
	* Save user/group/views info' to file:
	*/
	public static boolean save()
	{
		try
		{
			String sSlash = System.getProperty("file.separator");
      String xmlDir = "data" + sSlash + "common" + sSlash + "conf" + sSlash;
			UserParser.save(xmlDir + "users.xml");
			GroupParser.save(xmlDir + "groups.xml");
			ViewParser.save(xmlDir + "views.xml");
		}
		catch(java.io.IOException e)
		{
			System.err.println("IOException opening file for writing.");
		}
		m_bUpdated	= false;
		return true;
	}

	/**
	* Initiate "add" sequence:
	*/
	public static boolean add(int what, String id)
	{
		if(what <0 || what >2)
		{
			return false;
		}
		if(exists(what, id))
		{
			return false;
		}
		else
		{
			m_iEditWhat	= what;
			m_sOldId	= id;
			m_sNewId	= id;
		}
		return true;
	}

	/**
	* Delete rightaway:
	*/
	public static void delete(int what, String id)
	{
		if(what <0 || what >2)
		{
			return;
		}
		switch(what)
		{
			case USER:
				m_oUsers.remove(id);
				break;
			case GROUP:
				m_oGroups.remove(id);
				break;
			case VIEW:
				m_oViews.remove(id);
				m_oRules.remove(id);
				break;
			default:
				break;
		}
		m_sOldId	= "";
		m_sNewId	= "";
		m_sBuffer	= "";
		m_iEditWhat	= -1;

		m_bUpdated	= true;
		return;
	}

	/**
	* Initiate "modify" sequence:
	*/
	public static boolean modify(int what, String id)
	{
		if(what <0 || what >2)
		{
			return false;
		}
		else
		{
			m_iEditWhat	= what;
			m_sOldId	= id;
			m_sNewId	= id;
		}
		return true;
	}

	/**
	* Commit the current sequence of modifications:
	*/
	public static void ok()
	{
		String sRuleBuffer = null;
		if(m_iEditWhat <0 || m_iEditWhat >2)
		{
			return;
		}
		switch(m_iEditWhat)
		{
			case USER:
				if(m_oUsers.containsKey(m_sOldId))
				{
					m_oUsers.remove(m_sOldId);
				}
				m_oUsers.put(m_sNewId, m_sBuffer);
				break;

			case GROUP:
				if(m_oGroups.containsKey(m_sOldId))
				{
					m_oGroups.remove(m_sOldId);
				}
				m_oGroups.put(m_sNewId, m_sBuffer);
				break;

			case VIEW:
				if(m_oViews.containsKey(m_sOldId))
				{
					m_oViews.remove(m_sOldId);
				}
				if(m_oRules.containsKey(m_sOldId))
				{
					sRuleBuffer = (String)m_oRules.get(m_sOldId);
					m_oRules.remove(m_sOldId);
				}
				m_oViews.put(m_sNewId, m_sBuffer);
				if(sRuleBuffer==null)
				{
					sRuleBuffer = "Common$Type your text rule here..%";
				}
				m_oRules.put(m_sNewId, sRuleBuffer);
				break;

			default:
				break;
		}
		m_sBuffer	= "";
		m_iEditWhat	= -1;
		m_bUpdated	= true;
		return;
	}

	/**
	* Abort the current sequence of modifications:
	*/
	public static void cancel()
	{
		m_sBuffer	= "";
		m_iEditWhat	= -1;
		m_sNewId	= "";
		return;
	}

	/**
	* Check if this id is already in known id list:
	*/
	public static boolean exists(int what, String id)
	{
		if(what <0 || what >2)
		{
			return false;
		}
		switch(what)
		{
			case USER:
				return m_oUsers.containsKey(id);
			case GROUP:
				return m_oGroups.containsKey(id);
			case VIEW:
				return m_oViews.containsKey(id);
			default:
				break;
		}
		return false;
	}

}

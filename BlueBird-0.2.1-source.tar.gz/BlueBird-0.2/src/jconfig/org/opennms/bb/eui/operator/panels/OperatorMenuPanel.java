//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.operator.panels;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import java.util.*;

import org.opennms.bb.eui.operator.utils.EUIMenuParser;

/**
 * <pre> OperatorMenuPanel creates the standard operator menu and also
 * creates the external menu if available for the user from the
 * 'ExternalMenu' filename specified in the user's user profile file
 *
 * @author Sowmya
 */
class OperatorMenuPanel extends JPanel implements ActionListener
{
	OperatorInterfacePanel operatorParent;

	/*
 	 * Relevant XML TAGS for the external menu
	 */
 	String MENUS		="menus";
	String TOPMENU		="topmenu";
	String MENU			="menu";
	String CLASSNAME	="classname";
	String LABEL		="label";
	String HOTKEY		="hotkey";

	String SUBMENUS		="submenus";

	protected OperatorMenuPanel(OperatorInterfacePanel panel)
	{
		operatorParent = panel;

		setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
		
		// system toolbar
		JMenuBar sysMenuBar = createMenuBar();

		// border
		sysMenuBar.setBorder(BorderFactory.createRaisedBevelBorder());

	 	add(sysMenuBar);

		// user toolbar
		JMenuBar userMenuBar = createExternalMenuBar();
		if (null != userMenuBar)
		{
			// border
			userMenuBar.setBorder(BorderFactory.createRaisedBevelBorder());

			add(Box.createHorizontalStrut(5));
	 		add(userMenuBar);

			Dimension sysPrefSize = sysMenuBar.getPreferredSize();
			Dimension newSysPrefSize = new Dimension(250, sysPrefSize.height);
			
			sysMenuBar.setPreferredSize(newSysPrefSize);
			sysMenuBar.setMinimumSize(newSysPrefSize);
			sysMenuBar.setMaximumSize(newSysPrefSize);
		}
	}

	/*
	 * Create the standard menu actions
	 */
	protected JMenuBar createMenuBar()
	{
		JMenu		opMenu;
		JMenuItem 	menuItem;

		JRadioButtonMenuItem radioMenuItem;

		JMenuItem  	upMenuItem, topLevelMenuItem;
		JMenuItem	nameSortMenuItem, severityMenuItem;
		JMenuItem	alertMenuItem, configureMenuItem;

		JMenuBar 	opMenuBar = new JMenuBar();

		// The file menu
		opMenu = new JMenu("File");
		opMenu.setMnemonic('F');
		opMenuBar.add(opMenu);

		menuItem = new JMenuItem ("Exit",  KeyEvent.VK_X);
		menuItem.addActionListener(this);
		opMenu.add(menuItem);

		// The Action menu
		opMenu = new JMenu("Action");
		opMenu.setMnemonic('A');
		opMenuBar.add(opMenu);

		// up
		upMenuItem = new JMenuItem ("Move Up", KeyEvent.VK_U);
		upMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_U,
														ActionEvent.CTRL_MASK));
		upMenuItem.addActionListener(this);
		opMenu.add(upMenuItem);

		// top level
		topLevelMenuItem = new JMenuItem ("Go Top Level",  KeyEvent.VK_T);
		topLevelMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_T,
														ActionEvent.CTRL_MASK));
		topLevelMenuItem.addActionListener(this);
		opMenu.add(topLevelMenuItem);

		// alert browser
		alertMenuItem = new JMenuItem ("Alert Browser",  KeyEvent.VK_B);
		alertMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_B,
														ActionEvent.CTRL_MASK));
		alertMenuItem.addActionListener(this);
		opMenu.add(alertMenuItem);

		opMenu.addSeparator();

		// sort by name
		nameSortMenuItem = new JMenuItem ("Name Sort",  KeyEvent.VK_N);
		nameSortMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N,
														ActionEvent.CTRL_MASK));
		nameSortMenuItem.addActionListener(this);
		opMenu.add(nameSortMenuItem);

		// sort by severity
		severityMenuItem = new JMenuItem ("Severity Sort",  KeyEvent.VK_S);
		severityMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S,
														ActionEvent.CTRL_MASK));
		severityMenuItem.addActionListener(this);
		opMenu.add(severityMenuItem);

		opMenu.addSeparator();

		// Configure folder tabs
		configureMenuItem = new JMenuItem ("Configure Folders",  
															KeyEvent.VK_C);
		configureMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C,
														ActionEvent.CTRL_MASK));
		configureMenuItem.addActionListener(this);
		opMenu.add(configureMenuItem);

		// The Options  menu
		opMenu = new JMenu("Options");
		opMenu.setMnemonic('O');
		opMenuBar.add(opMenu);

		// Change tab placement
		JMenu tabPlaceMenu = new JMenu("Tab Placement");
		tabPlaceMenu.setMnemonic(KeyEvent.VK_T);
		tabPlaceMenu.addActionListener(this);
		opMenu.add(tabPlaceMenu);

        // Tab placement Radio control
		ButtonGroup tabGroup = new ButtonGroup();

	    radioMenuItem = new JRadioButtonMenuItem("Top");
		radioMenuItem.setSelected(
						operatorParent.opTabbedPane.getTabPlacement() 
						== SwingConstants.TOP);
				
		tabPlaceMenu.add(radioMenuItem);
		tabGroup.add(radioMenuItem);
		radioMenuItem.addActionListener(this);

	    radioMenuItem = new JRadioButtonMenuItem("Left");
		radioMenuItem.setSelected(
						operatorParent.opTabbedPane.getTabPlacement() 
						== SwingConstants.LEFT);
				
		tabPlaceMenu.add(radioMenuItem);
		tabGroup.add(radioMenuItem);
		radioMenuItem.addActionListener(this);

	    radioMenuItem = new JRadioButtonMenuItem("Bottom");
		radioMenuItem.setSelected(
						operatorParent.opTabbedPane.getTabPlacement() 
						== SwingConstants.BOTTOM);
				
		tabPlaceMenu.add(radioMenuItem);
		tabGroup.add(radioMenuItem);
		radioMenuItem.addActionListener(this);

	    radioMenuItem = new JRadioButtonMenuItem("Right");
		radioMenuItem.setSelected(
						operatorParent.opTabbedPane.getTabPlacement() 
						== SwingConstants.RIGHT);
				
		tabPlaceMenu.add(radioMenuItem);
		tabGroup.add(radioMenuItem);
		radioMenuItem.addActionListener(this);

		// Look and Feel
		JMenu lfMenu = new JMenu("Look And Feel");
		lfMenu.setMnemonic(KeyEvent.VK_L);
		lfMenu.addActionListener(this);
		opMenu.add(lfMenu);

        // Look and Feel Radio control
		ButtonGroup group = new ButtonGroup();

	    radioMenuItem = new JRadioButtonMenuItem("Metal");
		radioMenuItem.setSelected(
				UIManager.getLookAndFeel().getName().equals("Metal"));
		lfMenu.add(radioMenuItem);
		group.add(radioMenuItem);
		radioMenuItem.addActionListener(this);

        radioMenuItem = new JRadioButtonMenuItem("CDE/Motif");
		radioMenuItem.setSelected(
				UIManager.getLookAndFeel().getName().equals("CDE/Motif"));
		lfMenu.add(radioMenuItem);
		group.add(radioMenuItem);
		radioMenuItem.addActionListener(this);

        radioMenuItem = new JRadioButtonMenuItem("Windows");
		radioMenuItem.setSelected(
				UIManager.getLookAndFeel().getName().equals("Windows"));
		lfMenu.add(radioMenuItem);
		group.add(radioMenuItem);
		radioMenuItem.addActionListener(this);

		opMenuBar.add(Box.createHorizontalGlue());

		// The Help  menu
		opMenu = new JMenu("Help");
		opMenu.setMnemonic('H');
		opMenuBar.add(opMenu);

		menuItem = new JMenuItem("About",  KeyEvent.VK_A);
		menuItem.addActionListener(this);
		opMenu.add(menuItem);

		// set the appropriate menuitems in the operatorParent
		operatorParent.upMenuItem = upMenuItem;
		operatorParent.topLevelMenuItem = topLevelMenuItem;
		operatorParent.nameSortMenuItem = nameSortMenuItem;
		operatorParent.severityMenuItem = severityMenuItem;
		operatorParent.alertMenuItem = alertMenuItem;
		operatorParent.configureMenuItem = configureMenuItem;

		return opMenuBar;
	}

	/**
	 * Create external menu for the user
	 */
	protected JMenuBar createExternalMenuBar()
	{
		final String MENU="ExternalMenu";

		// get external menu filename from user profile
		Hashtable userProfile = operatorParent.getUserProfile();
		String filename= String.valueOf(userProfile.get(MENU));

		EUIMenuParser	menuParser;
		try
		{
			menuParser = new EUIMenuParser();
			menuParser.parse(filename);
		}
		catch (Exception e)
		{
			return null;
		}

		JMenuBar		opMenuBar = new JMenuBar();

		JMenu			opMenu;
		JMenuItem		opMenuItem;

		Vector menuVector = menuParser.getMenuData();
		int iNumTopLevelMenus = menuVector.size();

		for (int iTopIndex=0; iTopIndex<iNumTopLevelMenus; iTopIndex++)
		{
			Hashtable topLevelHash = (Hashtable)menuVector.elementAt(iTopIndex);

			String	topLabel = String.valueOf(topLevelHash.get(LABEL));
			char    mnemonicChar = 
							String.valueOf(topLevelHash.get(HOTKEY)).charAt(0);
			
			opMenu = new JMenu(topLabel);
			opMenu.setMnemonic(mnemonicChar);
			opMenuBar.add(opMenu);
			
			Vector subMenus = (Vector)topLevelHash.get(SUBMENUS);
			
			int iNumSubMenus = subMenus.size();
			for (int iSubIndex=0; iSubIndex < iNumSubMenus; iSubIndex++)
			{
				Hashtable subHash = (Hashtable)subMenus.elementAt(iSubIndex);
				handleSubMenu(opMenu, subHash);
			}
		}

		opMenuBar.add(Box.createHorizontalGlue());
		return opMenuBar;
	}

	protected void handleSubMenu(JMenu opMenu, Hashtable subHash)
	{
		JMenu			subMenu;
		JMenuItem		opMenuItem;

		String	subLabel = String.valueOf(subHash.get(LABEL));
		char    mnemonicChar = 
					String.valueOf(subHash.get(HOTKEY)).charAt(0);
			
		final Object command = subHash.get(CLASSNAME);
		if (command != null)
		{
			// Means it has no sub menus 
			// Create a menu item and add action
			opMenuItem = new JMenuItem (subLabel, mnemonicChar);
			opMenu.add(opMenuItem);

			opMenuItem.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent event)
				{
					String usrCommand=null;

					// Parse to see if command requires user input
					String var = parseCommand(command.toString());
					if (var == null)
					{
						usrCommand = command.toString();
					}
					else
					{
						VarInputPanel vPanel = new VarInputPanel(var);

						final JOptionPane pane = new JOptionPane(
												vPanel, 
												JOptionPane.PLAIN_MESSAGE,
												JOptionPane.OK_CANCEL_OPTION);
						JDialog dialog = pane.createDialog(null, "Command Variable");

						dialog.show();

						String value=null;
						Integer option = (Integer)pane.getValue(); 

						if (option.intValue() == JOptionPane.OK_OPTION)
							value = vPanel.getText();

						if (value != null)
							usrCommand = replaceVarInCommand(command.toString(), value);
					}

					if (usrCommand == null)
						return;

					try
					{
						Runtime.getRuntime().exec(usrCommand.toString());
					}
					catch (Exception e)
					{
							JOptionPane.showMessageDialog(new JFrame(), 
							"Unable to start external operator control \'" + 
				 			usrCommand.toString()+"\'\nException: " + e.getMessage(),
							"Error!", 
							JOptionPane.ERROR_MESSAGE);
					}
				}
			});
		}
		else
		{
			// has more sub menus
			// so create a menu

			subMenu = new JMenu(subLabel);
			subMenu.setMnemonic(mnemonicChar);
			opMenu.add(subMenu);

			Vector nextLevelMenus = (Vector)subHash.get(SUBMENUS);
			
			int iNumSubMenus = nextLevelMenus.size();
			for (int iSubIndex=0; iSubIndex < iNumSubMenus; iSubIndex++)
			{
				Hashtable nextLevelHash 
						= (Hashtable)nextLevelMenus.elementAt(iSubIndex);

				handleSubMenu(subMenu, nextLevelHash);
			}
		}
	}


	String parseCommand(String command)
	{
		int startInd = command.indexOf('%');
		if (startInd == -1)
			return null;

		int endInd   = command.indexOf('%', startInd+1);
		if (endInd == -1)
			return null;

		String var = command.substring(startInd+1, endInd);
		return var;
	}

	String replaceVarInCommand(String command, String value)
	{
		StringBuffer buf = new StringBuffer(command);
		
		int startInd = command.indexOf('%');
		int endInd   = command.indexOf('%', startInd+1);

		buf.replace(startInd, endInd+1, value);

		return buf.toString();
	}


	/**
	 * Allow the operatorParent to handle all the actions
	 */
	public void actionPerformed(ActionEvent e)
	{
		String actionStr = e.getActionCommand();

		operatorParent.handleMenuToolBarActions(actionStr);
	}

}

//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.admin.snmp.utils;

import org.w3c.dom.*;

import java.io.*;
import java.util.Vector;

import org.opennms.bb.common.utils.BBParser;

/**
 * <pre>SnmpXmlParser parses a 'Snmp' xml and stores the data read in vectors
 * This can then be queried for the data using the 'get..' functions
 *
 * It throws an IOException if the xml file is not found or if it does not
 * conform to its DTD </pre>
 *
 * @author Sowmya
 *
 * Modifications:
 * 04/18/00 - Changed the parser to extend BBParser - Sowmya
 * 05/10/00 - Removed extraneous memory allocations for the range etc. 
 *            column vectors
 */
public class SnmpXmlParser extends BBParser
{
	Vector	defaultColumns;
	Vector	defaultData;

	Vector	defCols;

	Vector	rangesColumns;
	Vector	rangesData;

	Vector	specificsColumns;
	Vector	specificsData;

	Vector  urlsColumns;
	Vector	urlsData;

	/*
	 * XML TAGS
	 */
	final String PARMS		="parms";
	final String PARM 		="parm";
	final String PARM_NAME	="parmName";
	final String PARM_VALUE	="value";

	final String DEFAULT	="default";

	final String RANGES		="ranges";
	final String RANGE		="range";
	final String FROM		="from";
	final String TO			="to";

	final String SPECIFICS	="specifics";
	final String SPECIFIC	="specific";
	final String SPECIP		="specIP";

	final String URLS		="urls";
	final String URL		="url";
	final String URLNAME	="urlName";

	final int NUM_PARM_NOT_EQUAL_TO_NUM_DEFS_ERR=-1002;

	final String NUM_PARM_NOT_EQUAL_TO_NUM_DEFS_ERR_STR =	
						"The Ranges/Specifics/Urls should have the same " +
						"parameters as the Default";


	// Number of default parameters
	int 	iNumDefParms=0;

	/**
 	 * Creates the DOM parser
 	 */
	public SnmpXmlParser() 
	{
		super();
	}

	protected boolean processElement(Element el,boolean isRoot)
	{
		boolean bRet = false;

		String tag = el.getTagName();

		if (tag.equals(DEFAULT))
		{
			m_curElement.replace(0, m_curElement.length(), "default");

			defaultColumns = new Vector(2);
			defaultColumns.add("Attribute");
			defaultColumns.add("Value");

			defaultData = new Vector();
			bRet = processDefaultElement(el);

			// Create column names vector
			int iNumCols = defaultData.size();
			defCols = new Vector(iNumCols);
			for (int iIndex=0; iIndex < iNumCols; iIndex++)
			{
				Vector temp = (Vector)defaultData.elementAt(iIndex);
				defCols.add(temp.elementAt(0)); // attribute
			}
		}

		else if (tag.equals(RANGES))
		{
			m_curElement.replace(0, m_curElement.length(), "ranges");

			// column names
			rangesColumns = (Vector)defCols.clone();
			rangesColumns.add(0, "From IP Address");
			rangesColumns.add(1, "To IP Address");

			// data
			rangesData = new Vector();
			bRet = processTabElement(el);

		}

		else if (tag.equals(SPECIFICS))
		{
			m_curElement.replace(0, m_curElement.length(), "specifics");

			// column names
			specificsColumns = (Vector)defCols.clone();
			specificsColumns.add(0, "IP Address");

			// data
			specificsData = new Vector();
			bRet = processTabElement(el);

		}

		else if (tag.equals(URLS))
		{
			m_curElement.replace(0, m_curElement.length(), "urls");

			// column names
			urlsColumns = (Vector)defCols.clone();
			urlsColumns.add(0, "File Name");

			// data
			urlsData = new Vector();
			bRet = processTabElement(el);

		}
		else
		{
			boolean bNodeRet=true;

			NodeList nl = el.getChildNodes();
			int size = nl.getLength();

			for(int i = 0;i < size && bNodeRet ;i++)
				bNodeRet = processNode(nl.item(i));
			
			bRet = bNodeRet;
		}
		
		return bRet;
	}

	protected boolean processDefaultElement(Node defNode)
	{
		boolean bRet = true;

		NodeList nl = defNode.getChildNodes();
		int size = nl.getLength();
		for(int i = 0;i < size && bRet ;i++)
		{
			Node curNode = nl.item(i);
			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
				if(curTag.equals(PARMS))
					bRet = processDefaultParms(curNode);
			}
			
		}

		return bRet;

	}

	protected boolean processDefaultParms(Node parmsNode)
	{
		boolean bRet = true;

		NodeList nl = parmsNode.getChildNodes();
		int size = nl.getLength();

		for(int i = 0;i < size && bRet;i++)
		{
			Node curNode = nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
				if(curTag.equals(PARM))
				{
					Vector parm = processParm(curNode);

					if (parm.isEmpty() || parm.size() != 2)
					{
						bRet = false;
						m_errNum = ATTRIB_VALUE_PAIR_ERR;
					}
					else
					{
						defaultData.add(parm);

						iNumDefParms++;
					}
				}

			}
		}

		return bRet;
	}

	protected boolean processTabElement(Node tabNode)
	{
		boolean bRet = true;

		NodeList nl = tabNode.getChildNodes();
		int size = nl.getLength();
		for(int i = 0;i < size && bRet;i++)
		{
			Node curNode = nl.item(i);
			int  nodeType= curNode.getNodeType();

			if ( nodeType == Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();

				if(curTag.equals(RANGE))
					bRet = processRangesRange(curNode);

				else if(curTag.equals(SPECIFIC))
					bRet = processSpecificsSpecific(curNode);

				else if(curTag.equals(URL))
					bRet = processUrlsUrl(curNode);
			}
			
		}

		return bRet;

	}

	protected boolean processRangesRange(Node rangesNode)
	{
		boolean bRet = true;

		Vector rangeVector = new Vector(iNumDefParms+2);

		NodeList nl = rangesNode.getChildNodes();
		int size = nl.getLength();

		for(int i = 0;i < size && bRet;i++)
		{
			Node curNode = nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
				if(curTag.equals(FROM))
				{
					String fromValue = processParmValue(curNode); 

					if (null != fromValue)
						rangeVector.add(fromValue);
					else
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}
				}
				else if(curTag.equals(TO))
				{
					String toValue = processParmValue(curNode); 

					if (null != toValue)
						rangeVector.add(toValue);
					else
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}
				}
				else if(curTag.equals(PARMS))
				{
					int iNumParms = processParms(curNode, rangeVector);
					if (iNumParms != iNumDefParms)
					{
						bRet = false;
						m_errNum = NUM_PARM_NOT_EQUAL_TO_NUM_DEFS_ERR;
					}
					else
						rangesData.add(rangeVector);
				}

			}
		}
		
		return bRet;
	}

	protected boolean processSpecificsSpecific(Node specificsNode)
	{
		boolean bRet = true;

		Vector specificVector = new Vector(iNumDefParms+1);

		NodeList nl = specificsNode.getChildNodes();
		int size = nl.getLength();

		for(int i = 0;i < size && bRet;i++)
		{
			Node curNode = nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
				if(curTag.equals(SPECIP))
				{
					String specValue = processParmValue(curNode); 

					if (null != specValue)
						specificVector.add(specValue);
					else
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}
				}
				else if(curTag.equals(PARMS))
				{
					int iNumParms = processParms(curNode, specificVector);
					if (iNumParms != iNumDefParms)
					{
						bRet = false;
						m_errNum = NUM_PARM_NOT_EQUAL_TO_NUM_DEFS_ERR;
					}
					else
						specificsData.add(specificVector);
				}

			}
		}
		
		return bRet;
	}

	protected boolean processUrlsUrl(Node urlsNode)
	{
		boolean bRet = true;

		Vector urlVector = new Vector(iNumDefParms+1);

		NodeList nl = urlsNode.getChildNodes();
		int size = nl.getLength();

		for(int i = 0;i < size && bRet;i++)
		{
			Node curNode = nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
				if(curTag.equals(URLNAME))
				{
					String urlValue = processParmValue(curNode); 

					if (null != urlValue)
						urlVector.add(urlValue);
					else
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}
				}
				else if(curTag.equals(PARMS))
				{
					int iNumParms = processParms(curNode, urlVector);
					if (iNumParms != iNumDefParms)
					{
						bRet = false;
						m_errNum = NUM_PARM_NOT_EQUAL_TO_NUM_DEFS_ERR;
					}
					else
						urlsData.add(urlVector);
				}

			}
		}

		return bRet;

	}

	protected int processParms(Node tabNode, Vector tabVector)
	{
		int iNumParms=0;

		NodeList nl = tabNode.getChildNodes();
		int size = nl.getLength();

		for(int i = 0;i < size;i++)
		{
			Node curNode = nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
				if(curTag.equals(PARM))
				{
					Vector parm = processParm(curNode);

					if ( (!parm.isEmpty()) && (parm.size() == 2))
					{
						String parmValue = (String)parm.elementAt(1);

						tabVector.add(parmValue); // get the value alone
					
						iNumParms++;
					}
				}

			}
		}

		return iNumParms;
	}


	protected Vector processParm(Node parmsNode)
	{
		Vector parm = new Vector(2);

		NodeList nl = parmsNode.getChildNodes();
		int size = nl.getLength();
		for(int i = 0;i < size;i++)
		{
			Node curNode = nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
				if(curTag.equals(PARM_NAME))
				{
					String name = processParmName(curNode);

					if (null != name)
						parm.add(name);
				}
				else if(curTag.equals(PARM_VALUE))
				{
					String value = processParmValue(curNode);

					if (null != value)
						parm.add(value);
				}

			}
		}
		
		return parm;
	}

	protected String processParmName(Node parmNameNode)
	{
		String parmName=null;

		Node temp = parmNameNode.getChildNodes().item(0);
		if (temp.getNodeType() == Node.TEXT_NODE)
			parmName = ((Text)temp).getData();
		
		return parmName;
	}


	/**
	 * Returns the error message for the parse
	 *
 	 * @returns the error message if any error occurred during parse
	 */
	public String getErrorMessage()
	{
		if (m_errNum == NUM_PARM_NOT_EQUAL_TO_NUM_DEFS_ERR)
			return NUM_PARM_NOT_EQUAL_TO_NUM_DEFS_ERR_STR;
		
		else
			return super.getErrorMessage();
	}

	/**
 	 * Returns the 'Default' tab column names
	 *
	 * @return The vector containing the 'default' columns
	 */
	public Vector getDefaultColumns()
	{
		return defaultColumns;
	}

	/**
 	 * Returns the 'Default' tab data
	 *
	 * @return The vector containing the 'default' data
	 */
	public Vector getDefaultData()
	{
		return defaultData;
	}

	/**
 	 * Returns the 'Ranges' tab column names
	 * @return The vector containing the 'Ranges' columns
	 */
	public Vector getRangesColumns()
	{
		return rangesColumns;
	}

	/**
 	 * Returns the 'Ranges' tab data
	 *
	 * @return The vector containing the 'Ranges' data
	 */
	public Vector getRangesData()
	{
		return rangesData;
	}

	/**
 	 * Returns the 'Specific Devices' tab column names
	 *
	 * @return The vector containing the 'Specific Devices' columns
	 */
	public Vector getSpecificsColumns()
	{
		return specificsColumns;
	}

	/**
 	 * Returns the 'Specific Devices' tab data
	 *
	 * @return The vector containing the 'Specific Devices' data
	 */
	public Vector getSpecificsData()
	{
		return specificsData;
	}

	/**
 	 * Returns the 'Url Configuration' tab column names
	 *
	 * @return The vector containing the 'Url Configuration' columns
	 */
	public Vector getUrlsColumns()
	{
		return urlsColumns;
	}

	/**
 	 * Returns the 'Url Configuration' tab data
	 *
	 * @return The vector containing the 'Url Configuration' data
	 */
	public Vector getUrlsData()
	{
		return urlsData;
	}

	/**
 	 * Print the 'Default' tab data - used primarily for debugging
	 */
	public void printDefaultData()
	{
		System.out.println("---------------DEFAULTS------------");

		int size = defaultData.size();
		for (int iIndex=0; iIndex<size; iIndex++)
		{
			Vector temp = (Vector)defaultData.elementAt(iIndex);
			System.out.println("attrib: " + temp.elementAt(0));
			System.out.println("value: " + temp.elementAt(1));
		}

		System.out.println("---------------END DEFAULTS------------");
	}

	/**
 	 * Print the vector passed in - used primarily for debugging
	 */
	public void printTabCols(Vector v, String id)
	{
		System.out.println("---------------" + id + "------------");

		int size = v.size();
		for (int iIndex=0; iIndex<size; iIndex++)
		{
			System.out.println(v.elementAt(iIndex));
		}

		System.out.println("---------------END " + id + "------------");
	}

	/**
 	 * Print the vector passed in - used primarily for debugging
	 */
	public void printTabData(Vector v, String id)
	{
		System.out.println("---------------" + id + "------------");

		int size = v.size();
		for (int iIndex=0; iIndex<size; iIndex++)
		{
			System.out.println("---START---");

			Vector temp = (Vector)v.elementAt(iIndex);
			int tempSize = temp.size();
			for (int iIndex2=0; iIndex2<tempSize; iIndex2++)
			{
				System.out.println(temp.elementAt(iIndex2));
			}

			System.out.println("---END---");
		}

		System.out.println("---------------END " + id + "------------");
	}
}

//-------------------------------------------------------------------------------------------
//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

//--------------------------------------------------------------------------------------------


package org.opennms.bb.eui.admin.distpoller.configure.parsers;

import org.opennms.bb.eui.admin.distpoller.configure.dpconf.UserManager;

import org.w3c.dom.*;

import java.io.*;
import java.util.Vector;
import java.util.Enumeration;

import org.opennms.bb.common.utils.BBParser;

/**
 * @author Jaya Krishna Chakravarthula
 *
 * Modifications:
 * 04/18/00 - Changed the parser to extend BBParser - Sowmya
 */
public class pollerXmlParser extends BBParser
{
	Vector	pollerData 		= 	new Vector();
	Vector pollerDetailsVector;
	
	String dpName = "";
	String dpValue = "";


	/*
	 * XML TAGS
	 */
	final String PARMS		=	"parms";
	final String PARM 		=	"parm";
	final String PARM_NAME		=	"parmName";
	final String PARM_VALUE		=	"value";


	final String POLLERS 		= 	"pollers";
	final String POLLER 		= 	"poller";
	final String POLLERID		=	"pollerID";
	final String POLLERNAME		= 	"pollerName";
	final String POLLERIP 		= 	"pollerIP";
	final String DISCLIMIT 		= 	"discLimit";
	final String POLLERHOST		= 	"pollerHost";
	final String POLLERCOMMENTS 	= 	"pollerComments";
	final String PACKAGE 		= 	"package";
	
	// Number of default parameters
	int 	iNumDefParms=0;

	public pollerXmlParser()
	{
		super();
	}

	protected boolean processElement(Element el, boolean isRoot)
	{
		boolean bRet	=	false;
		String tag	 	= 	el.getTagName();

		if (tag.equals(POLLERS))
		{
			bRet = processPollerElement(el);

		}
		else
		{
			boolean bNodeRet	=	true;
			NodeList nl 	= 	el.getChildNodes();
			int size 		=	nl.getLength();

			for(int i = 0;i < size && bNodeRet ;i++)
				bNodeRet = processNode(nl.item(i));
			
			bRet 			=	 bNodeRet;
		}
		return bRet;
	}

	protected boolean processPollerElement(Node defNode)
	{
		boolean bRet	=	 true;
		NodeList nl 	=	 defNode.getChildNodes();
		int size 		=	 nl.getLength();

		for(int i = 0;i < size && bRet ;i++)
		{
			Node curNode = nl.item(i);
			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
			
				if(curTag.equals(POLLER))
					bRet = processPollerParms(curNode);
			}
			
		}
		return bRet;
	}

	protected boolean processPollerParms(Node parmsNode)
	{
		boolean bRet		=	 true;
		String tempElement 	=	 null;
		pollerDetailsVector 	=	 new Vector();
		NodeList nl 		=	 parmsNode.getChildNodes();
		int size 			=	 nl.getLength();

		for(int i = 0;i < size && bRet;i++)
		{
			Node curNode 	=	 nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();

				if (curTag.equals(POLLERID))
				{
					dpName = "";

					tempElement		=	 processPollerValue(curNode);
					if (null != tempElement)
					{
						dpName = tempElement;
						dpName = dpName.trim();
						pollerDetailsVector.addElement(curTag + " : " + tempElement);
					}
					else
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}
					
				}
				else if (curTag.equals(POLLERNAME))
				{
					tempElement 	=	 processPollerValue(curNode);

					if (null != tempElement)
					{
						dpValue = tempElement.trim();
						pollerDetailsVector.addElement(curTag + " : " +tempElement);
					}
					else
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}

				}
				else if (curTag.equals(POLLERIP))
				{
					tempElement		=	 processPollerValue(curNode);
					if (null != tempElement)
					{
						dpValue += " : " + tempElement.trim();
						pollerDetailsVector.addElement(curTag + " : " +tempElement);
					}
					else
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}
				}
				else if (curTag.equals(DISCLIMIT))
				{
					tempElement		=	 processPollerValue(curNode);
					if (null != tempElement)
					{
						dpValue += " : " + tempElement.trim();
						pollerDetailsVector.addElement(curTag + " : " +tempElement);
					}
					else
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}
				}
				else if (curTag.equals(POLLERCOMMENTS))
				{
					tempElement 	=	 processPollerValue(curNode);

					if (null != tempElement)
					{
						dpValue += " : " + tempElement.trim();

						if (UserManager.m_oDP.containsKey(dpName))
						{
							UserManager.m_oDP.remove(dpName);
						}	
						UserManager.m_oDP.put(dpName, dpValue);

						pollerDetailsVector.addElement(curTag + " : " +tempElement);
					}
					else
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}
				}
				else if (curTag.equals(PACKAGE))
				{
					tempElement 	=	 processPollerValue(curNode);
					if (null != tempElement)
					{
						UserManager.m_oDPP.put(dpName + " : " +  tempElement.trim(), curTag);
						pollerDetailsVector.addElement(curTag + " : " +tempElement);
					}
					else
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}
				}
			}
		}

		if ( pollerData.isEmpty() || !pollerData.contains(pollerDetailsVector) )
		{
			pollerData.addElement(pollerDetailsVector);
		}

		return bRet;

	}

	protected String processPollerValue(Node parmValueNode)
	{
		String value	=	null;

		Node temp		=	parmValueNode.getChildNodes().item(0);
	
		if (temp.getNodeType() == Node.TEXT_NODE)
			value = ((Text)temp).getData();
		else if (temp.getNodeType() == Node.CDATA_SECTION_NODE)
			value = ((CDATASection)temp).getData();
			
		return value;
	}


	/**
 	 * Returns the 'Default' tab data
	 *
	 * @return The vector containing the 'default' data
	 */
	public Vector getPollerData()
	{
		return pollerData;
	}

	/**
 	 * Print the 'poller data' - used primarily for debugging
	 */
	public void printpollerData()
	{
		System.out.println("---------------POLLER------------");

		Enumeration enum = pollerData.elements();
		while (enum.hasMoreElements())
		{
			Vector temp = (Vector)enum.nextElement();	
			Enumeration en = temp.elements();
			while (en.hasMoreElements())
				System.out.println(en.nextElement());
			System.out.println("");
			
		}
		System.out.println("---------------END POLLER------------");
	}

	
}

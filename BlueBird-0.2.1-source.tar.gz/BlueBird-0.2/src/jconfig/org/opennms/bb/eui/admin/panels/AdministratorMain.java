//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.admin.panels;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.event.*;

import java.util.Hashtable;
import java.util.Vector;
import java.util.Enumeration;
import java.io.*;

import org.opennms.bb.eui.common.components.*;

import org.opennms.bb.eui.admin.utils.*;
import org.opennms.bb.eui.admin.interfaces.AdminTool;


/**
 * <pre>AdministratorMain is the administrator main panel that takes as
 * input the 'xml' file for the administrator. The xml file
 * decides the options available to the adminstrator </pre>
 *
 * @author Sowmya
 *
 */
public class AdministratorMain extends JFrame implements ActionListener
{
	PitXmlParser		parser;
	JScrollPane			scrPane;

	String				userID;

	// user profile values
	final String XPOS		="xPos";
	final String YPOS		="yPos";
	final String WIDTH		="Width";
	final String HEIGHT		="Height";
	final String LOOKNFEEL	="lookAndFeel";
	final String ROWCOL		="rowCol";
	final String LAYOUT		="layout";

	// user profile related
	boolean		bLandFAtStartUp=true;
	Hashtable	userProfile;

	String		layout;
	int			rowcol;

	/**
	 * Creates the administrator main panel from xml
	 */
	public AdministratorMain(String userID)
	{
		super();

		this.userID = userID;

		// we're not allowing for multiple administrators at the moment
		// String filename = new String("data/common/conf/" + userID + ".pitXML.xml");
		String filename = new String("data/common/conf/pitXML.xml");

		// Parse xml first
		try
		{
			parser=new PitXmlParser();
			parser.parse(filename);

		} catch (Exception e)
		{
	 		JOptionPane.showMessageDialog(new JFrame(), 
					"Unable to start Administrator main Panel for user \'" +
					userID + "\'\n" + e.getMessage(),
					"Error! Unable to parse input xml file", 
					JOptionPane.ERROR_MESSAGE);

			System.exit(1);
		}

		// get user profile
		readUserProfile();

		// set look and feel
		String landf = String.valueOf(userProfile.get(LOOKNFEEL));
		if (landf != null)
			handleMenuToolBarActions(landf);

		bLandFAtStartUp = false;

		buildFrame(); // build the outline

		addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
				handleExit();
			}
		});

		// Set user position preferences
		setUserPosPreferences();

		// if prev and current 'rowcol' and 'layout' are same then restore
		// to previous size
		Object profLayout = userProfile.get(LAYOUT);
		Object rc = userProfile.get(ROWCOL);
		if (profLayout != null && rc != null)
		{
		    int profRowCol = ((Integer)rc).intValue();

			if (profLayout.toString().equals(layout) && rowcol == profRowCol)
			{
				setUserDimPreferences();
			}
		}

		pack();
		setVisible(true);

		setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);

	}

	void buildFrame()
	{
		Hashtable			panelData;
		Hashtable			iconLayoutData;
		Hashtable			titleData;
		Vector				tools;

		final String BGCOLOR	="bgColor";
		final String TITLE		="title";
		final String FONT_TYPE	="fontType";
		final String FONT_STYLE	="fontStyle";
		final String FONT_SIZE	="fontSize";
		final String ROWCOL		="rowCol";
		final String LAYOUT		="layout";
		final String POSITION	="position";

		final String ICONLAYOUT	="iconLayout";
		final String LABELPOS	="labelPos";

		final String LABEL		="label";
		final String LABELTEXT	="text";
		final String HOTKEY		="hotkey";
		final String ICON		="icon";
		final String HINT		="hint";
		final String CLASSNAME	="classname";

		int			iGridRows=0;
		int			iGridCols=0;

		panelData = parser.getPanelData();
		iconLayoutData = parser.getIconLayoutData();

		// rowcol
		Integer rowColInt = new Integer(String.valueOf(panelData.get(ROWCOL)));
		rowcol = rowColInt.intValue();

		// layout info
		layout = String.valueOf(panelData.get(LAYOUT)).toLowerCase();
		if (layout.equals("horizontal"))
		{
			iGridRows = rowcol;
		}
		else
		{
			iGridCols = rowcol;
		}

		GridLayout grid = new GridLayout(iGridRows, iGridCols, 5, 5);

		// background
		String background = String.valueOf(panelData.get(BGCOLOR)).toLowerCase();
		final Color backColor = getColor(background);

		JPanel adminPanel = new JPanel()
		{
			public void paintComponent(Graphics g)
			{
				if (null != backColor)
				{
					g.setColor(backColor);
					g.fillRect(0, 0, getSize().width, getSize().height);
				}
				super.paintComponent(g);
			}
		};
		adminPanel.setOpaque(false);

		// set layout
		adminPanel.setLayout(grid);

		// title
		titleData = parser.getTitleData();
		String adminName = String.valueOf(titleData.get(TITLE));
		String adminPos  = String.valueOf(titleData.get(POSITION)).toLowerCase();

		Integer fontSize = new Integer(String.valueOf(titleData.get(FONT_SIZE)));
		
		int iFontStyle = getFontStyle(String.valueOf(titleData.get(FONT_STYLE))); 
		Font titleFont = new Font( String.valueOf(titleData.get(FONT_TYPE)), 
										iFontStyle, 
										fontSize.intValue());

		// border
		TitledBorder border = new TitledBorder(adminName);
		border.setTitleJustification(TitledBorder.CENTER);
		if (adminPos.equals("bottom"))
			border.setTitlePosition(TitledBorder.BOTTOM);
		border.setTitleFont(titleFont);

		// set border
		adminPanel.setBorder(border);

		// icon layout data
		Integer fSize = new Integer(String.valueOf(iconLayoutData.get(FONT_SIZE)));
		iFontStyle = getFontStyle(String.valueOf(iconLayoutData.get(FONT_STYLE))); 

		Font labelFont = new Font( 
								String.valueOf(iconLayoutData.get(FONT_TYPE)), 
								iFontStyle,
								fSize.intValue());
	
		String textPos = String.valueOf(iconLayoutData.get(LABELPOS)).toLowerCase();

		// tools
		Dimension buttonDim = new Dimension(50, 50);

		tools = parser.getToolsData();
		int numOptions = tools.size();
		
		StringBuffer mnemonicsSet = new StringBuffer(numOptions);

		for(int iIndex=0; iIndex< numOptions; iIndex++)
		{
			JPanel panel = new JPanel();
			panel.setOpaque(false);
			panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

			Hashtable tool = (Hashtable)tools.elementAt(iIndex);
			
			// create button
			String icon = String.valueOf(tool.get(ICON));
			ImageIcon buttonIcon =new ImageIcon(icon);

			JButton button	  = new JButton(buttonIcon);
			button.setBorderPainted(true);

			button.setPreferredSize(buttonDim);
			button.setMinimumSize(buttonDim);
			button.setMaximumSize(buttonDim);
			button.setAlignmentX(Component.CENTER_ALIGNMENT);
			
			// set tooltip
			button.setToolTipText(String.valueOf(tool.get(HINT)));
			
			// get classname
			final String className=String.valueOf(tool.get(CLASSNAME)).trim();

			// scroll to become visible when activated by the label
			button.addFocusListener(new FocusAdapter()
			{
				public void focusGained(FocusEvent e)
				{
					JButton source = (JButton)e.getSource();
					Dimension size = source.getSize();
					source.scrollRectToVisible(new Rectangle(0, 0, size.width, size.height));

					JPanel 	parent = (JPanel)source.getParent();
					Dimension parentSize = parent.getPreferredSize();
					parent.scrollRectToVisible(new Rectangle(0, 0, parentSize.width, parentSize.height));
				}
			});

			// set action
			button.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent event)
				{
					String exceptionMsg="";
					boolean bException=false;

					AdminTool	adminTool = null;

					try 
					{
						adminTool = (AdminTool)Class.forName(className).newInstance();
					}
					catch (ClassNotFoundException e)
					{
						exceptionMsg = new String("ClassNotFoundException");
						bException=true;
					}
					catch (IllegalAccessException e)
					{
						exceptionMsg = new String("IllegalAccessException");
						bException=true;
					}
					catch (InstantiationException e)
					{
						exceptionMsg = new String("InstantiationException");
						bException=true;
					}

					if (bException)
					{
	 					JOptionPane.showMessageDialog(new JFrame(), 
								"Unable to start application \'" + className + 
								"\'\nException: " + exceptionMsg,
								"Error!", 
								JOptionPane.ERROR_MESSAGE);
					}
					else
					{
						adminTool.start(userID);
					}
				}
			});

			// format the label
			String[]	labelNames;

			if (null != tool.get(LABELTEXT))
			{
				labelNames = formatButtonLabel(tool);
			}
			else
			{
				labelNames = new String[1];
			}


			char mnemonicChar = '\0';
			if (null != tool.get(HOTKEY))
				mnemonicChar = String.valueOf(tool.get(HOTKEY)).trim().charAt(0);
			// check if duplicate mnemonic
			if(mnemonicChar != '\0')
			{
				if (mnemonicsSet.toString().indexOf(mnemonicChar) != -1) // duplicate
				{
	 				JOptionPane.showMessageDialog(new JFrame(), 
						"Hotkey \'" + mnemonicChar + "\' specified for more than one tool" +
						"\nOnly the first tool can be reached!",

						"Duplicate hotkey!",
						JOptionPane.WARNING_MESSAGE);
				}
				else
					mnemonicsSet.append(mnemonicChar);
			}

			if (textPos.equals("top"))
			{
				panel.add(Box.createVerticalGlue());
				createButtonLabel(labelNames, labelFont, mnemonicChar, button, panel);
				panel.add(button);
			}
			else
			{
				panel.add(button);
				createButtonLabel(labelNames, labelFont, mnemonicChar, button, panel);
			}
			panel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
			adminPanel.add(panel);
		}

		Container cont = getContentPane();
		cont.setLayout(new BorderLayout());
		
		// menu panel
		JPanel menuPanel = new JPanel();
		menuPanel.setOpaque(false);
		menuPanel.setLayout(new BorderLayout());

		// Create the menu
		JMenuBar adminMenu = createMenu();
		menuPanel.add(adminMenu, BorderLayout.NORTH);
		
		// set title
		setTitle("BlueBird Administrator " + adminName);

		// add to scrollpane
		scrPane = new JScrollPane(adminPanel);
		setScrollPanePreferredSize();

		cont.add(menuPanel, BorderLayout.NORTH);
		cont.add(scrPane, BorderLayout.CENTER);
	}

	void setScrollPanePreferredSize()
	{
		// set size of scrollpane
		Dimension scrSize = scrPane.getPreferredSize();

		if (rowcol == 1)
		{
			// limit width at 450
			if (scrSize.width > 450)
				scrSize.setSize(450, scrSize.height+30);
	
			//limit height at 300
			if (scrSize.height > 300)
				scrSize.setSize(scrSize.width+30, 300);

		}
		else
			scrSize.setSize(450, 300);

		scrPane.setPreferredSize(scrSize);

	}

	Color getColor(String colorText)
	{
		//wish there were a better way
		Color color;

		if (colorText.equals("black"))
			color = Color.black;
		else if (colorText.equals("blue"))
			color = Color.blue;
		else if (colorText.equals("cyan"))
			color = Color.cyan;
		else if (colorText.equals("green"))
			color = Color.green;
		else if (colorText.equals("magenta"))
			color = Color.magenta;
		else if (colorText.equals("orange"))
			color = Color.orange;
		else if (colorText.equals("pink"))
			color = Color.pink;
		else if (colorText.equals("red"))
			color = Color.red;
		else if (colorText.equals("white"))
			color = Color.white;
		else if (colorText.equals("yellow"))
			color = Color.yellow;
		else if (colorText.indexOf("gray") != -1)
			color = Color.lightGray;
		else
			color = null;
		
		return color;
	}

	int getFontStyle(String style)
	{
		int iFontStyle=Font.BOLD;

		if (style.equals("plain"))
			iFontStyle = Font.PLAIN;
		else if (style.equals("BOLD"))
			iFontStyle = Font.BOLD;
		else if (style.equals("italic"))
			iFontStyle = Font.ITALIC;
		else if (style.equals("boldItalic"))
			iFontStyle = Font.BOLD | Font.ITALIC;
		
		return iFontStyle;
	}

	/*
	 * Break the labels into multiple strings
	 */
	private String[] formatButtonLabel(Hashtable control)
	{
		final String LABELTEXT		="text";

		// get button label 
		String inpLabel = String.valueOf(control.get(LABELTEXT)).trim();

		StringBuffer label = new StringBuffer();

		int LINE_LEN =10;
		int iLen     =inpLabel.length();
		int iLastLine=0;
		
		for(int iIndex=0; iIndex<iLen; iIndex++)
		{
			if (inpLabel.charAt(iIndex) == ' ')
			{
				int iIndex2=0;

				for(iIndex2=iIndex+1; iIndex2<iLen; iIndex2++)
				{
					if (inpLabel.charAt(iIndex2) == ' ')
					{
						break;
					}
				}

				// break  if the current line already has required characters
				// or if the next line will be too long
				if ((iIndex - iLastLine >=LINE_LEN ) || 
				    (iIndex2 - iIndex >= LINE_LEN) ||
					(iLastLine == 0 && (iIndex2 - iLastLine >= LINE_LEN))
				   )
				{
					label.append("\n");

					iLastLine=iIndex;
				}
				else
					label.append(inpLabel.charAt(iIndex));
			}
			else
				label.append(inpLabel.charAt(iIndex));
		}

		return splitStringByLines(label.toString());
	}

	private String[] splitStringByLines( String str )	
	{		
		String[] strs;	

		int lines = 1;		
		int i, c;
        for(i=0, c=str.length() ; i < c ; i++) 
		{
            if( str.charAt(i) == '\n' )            	
				lines++;        
		}
		strs = new String[lines];
		java.util.StringTokenizer st = new java.util.StringTokenizer( str, "\n" );				
		
		int line = 0;
		while( st.hasMoreTokens() )			
			strs[line++] = st.nextToken();					
		return strs;
	}

	/*
	 * Create multiple labels each if which are center justified
	 */
	private void createButtonLabel(String[] labelNames, Font labelFont, 
								   char mnemonicChar, JButton button, 
								   JPanel panel)
	{
		JLabel buttonLabel;
		boolean bMnemonicSet=false;

		if (mnemonicChar == '\0')
			bMnemonicSet = true;

		int iLen = labelNames.length;	
		for(int iIndex=0; iIndex<iLen; iIndex++)
		{
			if (null != labelNames[iIndex])
				buttonLabel = new JLabel(labelNames[iIndex], JLabel.CENTER);
			else
			{
				buttonLabel = new JLabel();
			}
			buttonLabel.setFont(labelFont);
			buttonLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
			buttonLabel.setLabelFor(button);

			if (labelNames[iIndex].indexOf(mnemonicChar) != -1 && !bMnemonicSet)
			{
				buttonLabel.setDisplayedMnemonic(mnemonicChar);
				bMnemonicSet = true;
			}
			panel.add(buttonLabel);
		}

		if (!bMnemonicSet)
		{
			String error;
			if (iLen > 1)
				error = new String("\n\'" + labelNames[0] + "\'..");
			else
				error = new String("\n\'" + labelNames[0] + "\'");

	 		JOptionPane.showMessageDialog(new JFrame(), 
				"Hotkey \'" + mnemonicChar + "\' specified not found in label" +
				error,
				"HotKey not found!",
				JOptionPane.WARNING_MESSAGE);
		}
	}

	
	/**
	 *  Creates the menu
	 */
	protected JMenuBar createMenu()
	{
		JMenuBar	adminMenuBar;
		JMenu		adminMenu;
		JMenuItem	menuItem;

		adminMenuBar = new JMenuBar();

		// The file menu
		adminMenu = new JMenu("File");
		adminMenu.setMnemonic('F');
		adminMenuBar.add(adminMenu);

		menuItem = new JMenuItem("Exit",  KeyEvent.VK_X);
		menuItem.addActionListener(this);
		adminMenu.add(menuItem);

		// The Options  menu
		adminMenu = new JMenu("Options");
		adminMenu.setMnemonic('O');
		adminMenuBar.add(adminMenu);

		// Look and Feel
		JMenu lfMenu = new JMenu("Look And Feel");
		lfMenu.setMnemonic(KeyEvent.VK_L);
		lfMenu.addActionListener(this);
		adminMenu.add(lfMenu);

        // Look and Feel Radio control
		ButtonGroup group = new ButtonGroup();
		JRadioButtonMenuItem radioMenuItem;

	    radioMenuItem = new JRadioButtonMenuItem("Metal");
		radioMenuItem.setSelected(
				UIManager.getLookAndFeel().getName().equals("Metal"));
		lfMenu.add(radioMenuItem);
		group.add(radioMenuItem);
		radioMenuItem.addActionListener(this);

        radioMenuItem = new JRadioButtonMenuItem("CDE/Motif");
		radioMenuItem.setSelected(
				UIManager.getLookAndFeel().getName().equals("CDE/Motif"));
		lfMenu.add(radioMenuItem);
		group.add(radioMenuItem);
		radioMenuItem.addActionListener(this);

        radioMenuItem = new JRadioButtonMenuItem("Windows");
		radioMenuItem.setSelected(
				UIManager.getLookAndFeel().getName().equals("Windows"));
		lfMenu.add(radioMenuItem);
		group.add(radioMenuItem);
		radioMenuItem.addActionListener(this);

		adminMenuBar.add(Box.createHorizontalGlue());

		adminMenu = new JMenu("Help");
		adminMenu.setMnemonic('H');
		adminMenuBar.add(adminMenu);

		menuItem = new JMenuItem("About",  KeyEvent.VK_A);
		menuItem.addActionListener(this);
		adminMenu.add(menuItem);
		
		return adminMenuBar;
	}

	/**
	 * Reads the user preferences from the user profile file
	 */
	protected void readUserProfile()
	{
		AdminMainUserProfParser userProfParser=null;
		boolean	bUserProfileRead=true;

		String userxml = "data/users/" + userID + ".xml";

		// if file does not exist, just take defaults
		File userFile = new File(userxml);
		if (userFile.exists() && userFile.canRead())
		{
			// get user profile
			try
			{
				userProfParser = new AdminMainUserProfParser();
				userProfParser.parse(userxml);
			}
			catch (Exception e)
			{
				// if the profile has an error, just prompt and continue
	 			JOptionPane.showMessageDialog(new JFrame(), 
					e.getMessage(),
					"Error! Unable to parse user profile file", 
					JOptionPane.ERROR_MESSAGE);

				bUserProfileRead = false;
			}
		}
		else
				bUserProfileRead = false;
		
		// 
		if (bUserProfileRead)
		{
			userProfile = userProfParser.getUserProfile();

			if (userProfile == null)
				userProfile = new Hashtable(5);
		}

		else
			userProfile = new Hashtable(5);
	}

	/**
	 * Sets the (x,y) preferences of the user
	 */
	protected void setUserPosPreferences()
	{
		// set the location of the frame
		Object xPos = userProfile.get(XPOS);
		Object yPos = userProfile.get(YPOS);
		if (xPos != null && yPos != null)
		{
			setLocation(((Integer)xPos).intValue(), 
								((Integer)yPos).intValue());
		}
		else
			setLocation(100, 100);
	}

	/**
	 * Sets size preferences of the user
	 */
	protected void setUserDimPreferences()
	{
		// set the size
		Object width = userProfile.get(WIDTH);
		Object height = userProfile.get(HEIGHT);
		if (width != null && height != null)
		{
			scrPane.setPreferredSize(new Dimension(((Integer)width).intValue(),
										  ((Integer)height).intValue()));
		}
		else
			scrPane.setPreferredSize(new Dimension(500, 400));
	}

	/**
	 * Handles the menu actions
	 */
	public void actionPerformed(ActionEvent e)
	{
		String actionStr = e.getActionCommand();
		
		handleMenuToolBarActions(actionStr);
	}

	void handleMenuToolBarActions(String actionStr)
	{
		// exit
		if (actionStr.equals("Exit"))
		{
			handleExit();
		}

		// options
		else if (actionStr.equals("Metal"))
		{
        	setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");
		}

		else if (actionStr.equals("CDE/Motif"))
		{
			setLookAndFeel("com.sun.java.swing.plaf.motif.MotifLookAndFeel");
		}

		else if (actionStr.equals("Windows"))
		{
			setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		}
		else if (actionStr.equals("About"))
		{
			new AboutDialog(new JFrame(), "About BlueBird");
		}
	}

	void setLookAndFeel(String str)
	{
	    setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));

		try 
		{

        	UIManager.setLookAndFeel(str);

	   		if (!bLandFAtStartUp)
			{
				SwingUtilities.updateComponentTreeUI(this);
			}

		} catch (Exception exc) 
		{
			System.err.println("can't get to the " + str + " look and feel");

			// try and go back to default
			try
			{
				UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
	   			SwingUtilities.updateComponentTreeUI(this);
			}
			catch (Exception e)
			{
				// Don't really do anything?
			}
		}

	   	setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
	}

	void handleExit()
	{
		// Save User Profile
		saveUserProfile();

		System.exit(0);
	}

	/**
	 * <pre>Handles the storing of user preferences to the user profile 
	 * file. If the write into the profile file fails, the step is retried 
	 * thrice as a minimum mechanism to offset the possiblity of a different
	 * application currently writing into the profile
	 */
	protected void saveUserProfile()
	{
		// Update the userProfile Hashtable

		// position
		Integer xpos = new Integer(getX());
		Integer ypos = new Integer(getY());

		// dimension
		Dimension frameSize = getSize();
		Integer width = new Integer(frameSize.width);
		Integer height = new Integer(frameSize.height);

		userProfile.put(XPOS, xpos);
		userProfile.put(YPOS, ypos);
		userProfile.put(WIDTH, width);
		userProfile.put(HEIGHT, height);

		// look and feel
		String landf = UIManager.getLookAndFeel().getName();
		userProfile.put(LOOKNFEEL, landf);

		// layout
		userProfile.put(LAYOUT, layout);
		userProfile.put(ROWCOL, new Integer(rowcol));
		
		boolean bNotWritten = true;
		int		iNumTries=0;

		while(bNotWritten && iNumTries < 3)
		{
			try
			{
				new AdminMainUserProfWriter(userProfile, userID);
				bNotWritten = false;
			}
			catch (Exception e)
			{
				bNotWritten = true;
			}
			
			if (bNotWritten)
			{
				iNumTries++;

				try
				{
					Thread.sleep(300);
				}
				catch (InterruptedException ex) { }

			}
		}
	}
}

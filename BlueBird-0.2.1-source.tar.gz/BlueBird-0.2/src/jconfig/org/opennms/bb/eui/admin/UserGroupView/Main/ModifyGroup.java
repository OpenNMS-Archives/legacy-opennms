//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
package org.opennms.bb.eui.admin.UserGroupView.Main;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class ModifyGroup extends JDialog
{
	private boolean	m_bNew	= false;
	private String	sOldId	= "";

	public ModifyGroup(JFrame parent, boolean modal, String groupName)
	{
		super(parent, modal);

		JLabel oGroupNameLabel	= new JLabel();
		JLabel oCommentsLabel	= new JLabel();

		getContentPane().setLayout(null);

		setBackground(java.awt.Color.lightGray);
		setSize(383,200);
		setVisible(false);

		getContentPane().add(m_oGroupNameInput);
		getContentPane().add(m_oCommentsInput);

		if(!m_bNew)
		{
			String sBuffer = (String)UserManager.m_oGroups.get(groupName);
			if(sBuffer != null)
			{
				StringTokenizer oTokenizer = new StringTokenizer(sBuffer,":");

				String sTok = "";

				try
				{
					sTok = oTokenizer.nextToken();
				} catch(NoSuchElementException  e) { sTok = ""; }
				m_oCommentsInput.setText(sTok);
			}
		}

		oGroupNameLabel.setText("User Group Name:");
		oGroupNameLabel.setHorizontalAlignment(JLabel.LEFT);
		getContentPane().add(oGroupNameLabel);
		oGroupNameLabel.setBounds(24,12,106,24);

		m_oOkButton.setText("OK");
		getContentPane().add(m_oOkButton);
		m_oOkButton.setBounds(156,148,66,27);
		Dimension oButtonSize = new Dimension(85, 25);
		m_oOkButton.setPreferredSize(oButtonSize);
		m_oOkButton.setMinimumSize(oButtonSize);
		m_oOkButton.setMaximumSize(oButtonSize);
		m_oOkButton.setBorderPainted(true);

		m_oGroupNameInput.setText(groupName);
		m_oGroupNameInput.selectAll();
		sOldId = groupName;
		
		m_oGroupNameInput.setBounds(132,12,240,24);
		oCommentsLabel.setText("Comments:");
		oCommentsLabel.setHorizontalAlignment(JLabel.LEFT);
		getContentPane().add(oCommentsLabel);
		oCommentsLabel.setBounds(24,48,82,24);
		m_oCommentsInput.setBounds(132,48,240,78);

		JScrollPane	oTextAreaScrollPane	= new JScrollPane(m_oCommentsInput,
														  JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
														  JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED );
		oTextAreaScrollPane.setBounds(132,48,240,78);
		getContentPane().add(oTextAreaScrollPane);

		setTitle("Modify User Group");
        
		SymWindow aSymWindow = new SymWindow();
		this.addWindowListener(aSymWindow);
		SymAction lSymAction = new SymAction();
		m_oOkButton.addActionListener(lSymAction);

		m_oGroupNameInput.addMouseListener(new java.awt.event.MouseAdapter()
									  {
										public void mousePressed(java.awt.event.MouseEvent e)
										{
											m_oGroupNameInput.setBackground(java.awt.Color.white);
										}
										public void mouseClicked(java.awt.event.MouseEvent e)
										{
											m_oGroupNameInput.setBackground(java.awt.Color.white);
										}
									  }
									 );
		m_oGroupNameInput.addKeyListener(new java.awt.event.KeyAdapter()
									  {
										public void keyTyped(java.awt.event.KeyEvent e)
										{
											m_oGroupNameInput.setBackground(java.awt.Color.white);
										}
										public void keyPressed(java.awt.event.KeyEvent e)
										{
											m_oGroupNameInput.setBackground(java.awt.Color.white);
										}
									  }
									 );

		setResizable(false);

	}
    
	public ModifyGroup(JFrame parent, String title, boolean modal, String groupName)
	{
		this(parent, modal, groupName);
		setTitle(title);
	}

	public ModifyGroup(JFrame parent, String title, boolean modal, String groupName, boolean isNew)
	{
		this(parent, title, modal, groupName);
		m_bNew = isNew;
	}

	public void addNotify()
	{
		Dimension d = getSize();
		super.addNotify();

		if (m_bComponentsAdjusted)
			return;

		Insets insets = getInsets();
		setSize(insets.left + insets.right + d.width, insets.top + insets.bottom + d.height);
		Component components[] = getComponents();
		for (int i = 0; i < components.length; i++)
		{
			Point p = components[i].getLocation();
			p.translate(insets.left, insets.top);
			components[i].setLocation(p);
		}

		m_bComponentsAdjusted = true;
	}

	public void setVisible(boolean b)
	{
	    if (b)
	    {
    		Rectangle bounds = getParent().getBounds();
    		Rectangle abounds = getBounds();

    		setLocation(bounds.x + (bounds.width - abounds.width)/ 2,
    			 bounds.y + (bounds.height - abounds.height)/2);
	    }

		super.setVisible(b);
	}

	JButton		m_oOkButton			= new JButton();
	JTextField	m_oGroupNameInput	= new JTextField();
	JTextArea	m_oCommentsInput	= new JTextArea();
    
    // Used for addNotify check.
	boolean m_bComponentsAdjusted = false;

	class SymAction implements java.awt.event.ActionListener
	{
		public void actionPerformed(java.awt.event.ActionEvent event)
		{
			Object object = event.getSource();
			if (object == m_oOkButton)
			{
				String sId = m_oGroupNameInput.getText();
				if( (sId == null) || sId.trim().equals(""))
				{
					Toolkit.getDefaultToolkit().beep();
				    m_oGroupNameInput.setBackground(java.awt.Color.red);
					return;
				}
				try
				{
					if(m_bNew)
					{
						if(UserManager.m_oGroups.containsKey(sId))
						{
							Toolkit.getDefaultToolkit().beep();
						    m_oGroupNameInput.setBackground(java.awt.Color.red);
							return;
						}
						UserManager.add(UserManager.GROUP, m_oGroupNameInput.getText());
						UserManager.m_sBuffer= m_oCommentsInput.getText();
						if(UserManager.m_sBuffer==null || (UserManager.m_sBuffer.trim().equals("")))
						{
							UserManager.m_sBuffer = "(none)";
						}
						UserManager.m_sBuffer+= ":";
						//UserManager.ok();
					}
					else
					{
						if((!sOldId.equals(sId)) && UserManager.m_oGroups.containsKey(sId))
						{
							Toolkit.getDefaultToolkit().beep();
						    m_oGroupNameInput.setBackground(java.awt.Color.red);
							return;
						}
						UserManager.modify(UserManager.GROUP, sOldId);
						UserManager.m_sNewId = m_oGroupNameInput.getText();
						UserManager.m_sBuffer= m_oCommentsInput.getText();
						if(UserManager.m_sBuffer==null || (UserManager.m_sBuffer.trim().equals("")))
						{
							UserManager.m_sBuffer = "(none)";
						}
						UserManager.m_sBuffer+= ":";
						//UserManager.ok();
					}
				    setVisible(false);
					dispose();
				}
				catch (Exception e)
				{
				}
			}
		}
	}

	class SymWindow extends java.awt.event.WindowAdapter
	{
		public void windowClosing(java.awt.event.WindowEvent event)
		{
			Object object = event.getSource();
			if (object == ModifyGroup.this)
			{
				try
				{
					setVisible(false);
					UserManager.cancel();
					dispose();
				}
				catch (Exception e)
				{
				}
			}
		}
	}

	public static void main(String[] args)
	{
		JFrame frame = new JFrame();
		frame.setSize(383,240);
		try
		{
			(new ModifyGroup(frame, true, "Name")).setVisible(true);
		}
		catch (Exception e)
		{
		}
	}

}

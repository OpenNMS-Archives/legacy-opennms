//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
package org.opennms.bb.eui.admin.UserGroupView.RuleBuilder;

import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.Toolkit;
import java.awt.dnd.*;
import java.awt.datatransfer.*;
import java.awt.Point;
import java.util.Vector;
import java.util.StringTokenizer;
import java.util.Enumeration;
import javax.swing.*;

import org.opennms.bb.eui.admin.UserGroupView.Main.UserManager;
import org.opennms.bb.eui.admin.UserGroupView.RuleBuilder.RuleResultsDialog;
import org.opennms.bb.common.filter.BBFilter;

class Node
{  
    double m_dX;
    double m_dY;
    String m_sDescLbl;
    String m_sLbl;
    
    boolean m_bFixed;
    
    Vector m_vNodes = new Vector();
}

class Edge
{
    int m_iFrom;
    int m_iTo;
    double m_dLen;
    
    boolean isPointInBetween(RuleCategoryPanel oGraph, Point oPoint)
    {
	double x1 = oGraph.m_oNodes[m_iFrom].m_dX,
	    x2 = oGraph.m_oNodes[m_iTo].m_dX,
	    y1 = oGraph.m_oNodes[m_iFrom].m_dY,
	    y2 = oGraph.m_oNodes[m_iTo].m_dY;
	
	int    X  = oPoint.x,
	    Y  = oPoint.y;
	
	double m  = (y2-y1)/(x2-x1);
	double m1 = (Y -y1)/(X -x1);
	double m2 = (Y -y2)/(X -x2);
	
	if(Math.atan((m1-m)/(1+m1*m))*Math.atan((m2-m)/(1+m2*m)) <0)
	{
	    return true;
	}
	return false;
    }
}


/**
 *
 * @author Chitta
 * Modifications:
 * changed the recognise method to not put an or operator at the end of a rule, line 1061
 * 10/10/2000, Jason 
 *
 *
 * Changed the deprecated 'getComponentAtIndex(int i)' method of 'JPopupMenu'
 * to 'getComponent(int i)' for the move to JDK 1.3
 * 
 * Added addThresholdLowHighValues method to display threshold values
 * 11/14/2000, Vishwa
 *
 */
class RuleCategoryPanel extends Container implements MouseListener, 
						     MouseMotionListener,
						     ActionListener, 
						     DropTargetListener
{
    private static boolean _bLoaded = false;
    static void loadLibraries()
    {
	if (!_bLoaded)
	{
	    java.security.AccessController.doPrivileged(new sun.security.action.LoadLibraryAction("awt") );
	    _bLoaded = true;
	}
    }
    private static native void initIDs();
    
    static
    {
	/* ensure that the proper libraries are loaded */
	loadLibraries();
    }
    
    int		       m_nNodes, m_nEdges;
    public Node	       m_oNodes[] = new Node[20];
    public Edge	       m_oEdges[] = new Edge[20];
    StringBuffer       m_sRuleBuffer = null;
    
    Node	       m_oPick;
    boolean	       m_bPickfixed;
    Image	       m_oOffscreen;
    Dimension	       m_oOffscreensize;
    Graphics	       m_oOffgraphics;
    boolean	       m_bDrawMode=false;
    boolean	       m_bRuleMade = false;
    String	       m_sDrawSource = null;
    JPopupMenu	       m_oPopupNode = null;
    JPopupMenu	       m_oPopupEdge = null;
    JPopupMenu	       m_oPopupEdit = null;
    
    JTextField	       m_oRule = null;
    JTextField	       m_oLowThreshold = null;
    JTextField	       m_oHighThreshold = null;
    
    final Color	       FIXED_COLOR = Color.black;
    final Color	       SELECT_COLOR = Color.pink;
    final Color	       NODE_COLOR = Color.lightGray;
    final Color	       ARC_COLOR = Color.black;
    final Color	       RULE_COLOR = Color.white;
    JScrollBar	       m_oVerticalScrollBar = null;
    JScrollBar	       m_oHorizontalScrollBar = null;
    int		       m_iVerticalScrollVal = 0;
    int		       m_iHorizontalScrollVal = 0;
    
    GridBagLayout      m_oGridBag = new GridBagLayout();
    GridBagConstraints m_oGridBagConstraints = new GridBagConstraints();

    String m_sNormal;
    String m_sWarning;
    
    public RuleCategoryPanel(String sRule)
    {
	super();

	String spRule = addThresholdLowHighValues(sRule);
	m_sRuleBuffer = new StringBuffer(spRule);

	setLayout(m_oGridBag);
	
	addScrollBars();

	addTextRuleBox();
	addThresholdBox();
	addServicesBox();
	addRedoButton();

	add(addTestButton());
	
	addNode("source",26,145);
	addNode("sink",384,145);
	
	try
	{
	    init(spRule);
	}
	catch(Exception e)
	{
	}
	
	UserManager.m_bFigureUpdated = false;
	setVisible(true);
	repaint();
    }
    
    class RuleTemplate
    {
	Vector _start = null;
	Vector _end   = null;
	
	RuleTemplate()
	{
	    _start = new Vector();
	    _end   = new Vector();
	}
	
	RuleTemplate(int iNode)
	{
	    this();
	    
	    Integer iInt = new Integer(iNode);
	    _start.add(iInt);
	    _end.add(iInt);
	}
	
	RuleTemplate and(RuleTemplate r2)
	{
	    RuleTemplate r = new RuleTemplate();
	    
	    for(Enumeration e=this._end.elements(); e.hasMoreElements(); )
	    {
		int iFrom = ((Integer)e.nextElement()).intValue();
		for(Enumeration e2=r2._start.elements(); e2.hasMoreElements(); )
		{
		    addEdge(m_oNodes[iFrom].m_sDescLbl,
			    m_oNodes[((Integer)e2.nextElement()).intValue()].m_sDescLbl);
		}
	    }
	    r._start = this._start;
	    r._end = r2._end;
	    
	    return r;
	}
	
	RuleTemplate or(RuleTemplate r2)
	{
	    RuleTemplate r = new RuleTemplate();
	    
	    r._start = this._start;
	    r._end = this._end;
	    int i=0;
	    for(;i<r2._start.size();i++)
	    {
		r._start.add(r2._start.get(i));
	    }
	    i=0;
	    for(;i<r2._end.size();i++)
	    {
		r._end.add(r2._end.get(i));
	    }
	    
	    return r;
	}
    }
    
    void init(String sRule)
    {
	StringBuffer sMappedRule = new StringBuffer(sRule);
	Vector vResource = new Vector();
	int iCount = 0;
	
	StringTokenizer oTkz = new StringTokenizer(sRule, "()&|");
	for( ;oTkz.hasMoreTokens(); )
	{
	    String sTmp = oTkz.nextToken();
	    if(sTmp!= null && (!(sTmp=sTmp.trim()).equals("")))
	    {
		vResource.add(new RuleTemplate(findNode(sTmp)));
		int i = sMappedRule.toString().indexOf(sTmp);
		int j = i + sTmp.length();
		sMappedRule = sMappedRule.replace(i,j, ""+(iCount++));
	    }
	}
	
	int i=0;
	while((i=sMappedRule.toString().indexOf(")"))>0)
	{
	    int j=sMappedRule.toString().lastIndexOf("(",i);
	    String sTmp = null;
	    try
	    {
		sTmp = sMappedRule.toString().substring(j+1,i);
	    }
	    catch(Exception e)
	    {
		sTmp = "";
	    }
	    StringTokenizer oStk = new StringTokenizer(sTmp,"&|");
	    if(oStk.countTokens()<1)
	    {
		sMappedRule.deleteCharAt(i);
		sMappedRule.deleteCharAt(j);
	    }
	    else
	    {
		String sTok = oStk.nextToken();
		RuleTemplate r = (RuleTemplate)vResource.get(Integer.parseInt(sTok.trim()));
		int iOffset = 0;
		while(oStk.hasMoreTokens())
		{
		    iOffset += sTok.length();
		    sTok = oStk.nextToken();
		    RuleTemplate r2 = (RuleTemplate)vResource.get(Integer.parseInt(sTok.trim()));
		    if(sTmp.charAt(iOffset)=='&')
		    {
			r = r.and(r2);
		    }
		    else
		    {
			r = r.or(r2);
		    }
		    iOffset+=1;
		}
		vResource.add(r);
		sMappedRule.replace(j,i+1, ""+(iCount++));
	    }
	}
	
	String sTmp = sMappedRule.toString();
	
	RuleTemplate r=null;
	StringTokenizer oStk = new StringTokenizer(sTmp,"&|");
	//if(oStk.countTokens()>1)
	{
	    String sTok = oStk.nextToken();
	    r = (RuleTemplate)vResource.get(Integer.parseInt(sTok.trim()));
	    int iOffset = 0;
	    while(oStk.hasMoreTokens())
	    {
		iOffset += sTok.length();
		sTok = oStk.nextToken();
		RuleTemplate r2 = (RuleTemplate)vResource.get(Integer.parseInt(sTok.trim()));
		if(sTmp.charAt(iOffset)=='&')
		{
		    r = r.and(r2);
		}
		else
		{
		    r = r.or(r2);
		}
		iOffset+=1;
	    }
	}
	
	if(r==null)
	{
	    return;
	}
	
	while(r._start.size()>0)
	{
	    addEdge("source",
		    m_oNodes[((Integer)r._start.remove(r._start.size()-1)).intValue()].m_sDescLbl);
	}
	while(r._end.size()>0)
	{
	    addEdge(m_oNodes[((Integer)r._end.remove(r._end.size()-1)).intValue()].m_sDescLbl,
		    "sink");
	}
	
	try
	{
	    m_iLevel = -1;
	    m_iSinkX = -1;
	    recognise(0);
	    int nCount = 0;
	    int iNode = 0;
	    for(int j=0; j<m_nNodes; j++)
	    {
		if(m_oNodes[j].m_vNodes.contains(new Integer(1)))
		{
		    iNode = j;
		    if(++nCount > 1)
		    {
			break;
		    }
		}
	    }
	    if(nCount == 1)
	    {
		m_oNodes[iNode].m_dY = m_oNodes[1].m_dY;
	    }
	}
	catch(Exception e)
	{
	}
    }
    
    
    
    void addScrollBars()
    {
	addVerticalScrollBar();
	addHorizontalScrollBar();
    }
    
    void addTextRuleBox()
    {
	JLabel oRuleLabel = new JLabel();
	oRuleLabel.setText("Text Rule:");
	oRuleLabel.setFont(new Font("Courier", Font.PLAIN, 9));
	
	m_oGridBagConstraints.fill = GridBagConstraints.HORIZONTAL;
	m_oGridBagConstraints.weightx = 0;
	m_oGridBagConstraints.weighty = 0;
	m_oGridBagConstraints.gridx = 0;
	m_oGridBagConstraints.gridy = 4;
	m_oGridBagConstraints.gridwidth = 1;
	//m_oGridBagConstraints.ipadx = 10;
	m_oGridBagConstraints.ipadx = 0;
	m_oGridBagConstraints.ipady = 0;
	m_oGridBagConstraints.anchor = GridBagConstraints.WEST;
	m_oGridBagConstraints.insets = new Insets(8,0,0,0);
	m_oGridBag.setConstraints(oRuleLabel, m_oGridBagConstraints);
	add(oRuleLabel);

	m_oRule = new JTextField();
	m_oRule.setBorder(BorderFactory.createLoweredBevelBorder());
	m_oRule.setText(m_sRuleBuffer.toString());
	
	m_oGridBagConstraints.fill = GridBagConstraints.HORIZONTAL;
	m_oGridBagConstraints.weightx = 1.0;
	m_oGridBagConstraints.weighty = 0;
	m_oGridBagConstraints.gridx = 1;
	m_oGridBagConstraints.gridy = 4;
	m_oGridBagConstraints.gridwidth = 2;
	//m_oGridBagConstraints.ipadx = 10;
	m_oGridBagConstraints.ipadx = 0;
	m_oGridBagConstraints.ipady = 0;
	m_oGridBagConstraints.anchor = GridBagConstraints.WEST;
	m_oGridBagConstraints.insets = new Insets(8,0,0,0);
	m_oGridBag.setConstraints(m_oRule, m_oGridBagConstraints);
	
	add(m_oRule);
	m_oGridBagConstraints.gridwidth = 1;
    }
    
    void addThresholdBox()
    {
	JPanel oThresholdPanel= new JPanel();
	
        oThresholdPanel.setBorder(BorderFactory.createCompoundBorder
				  (
				   BorderFactory.createTitledBorder
				   (
				    BorderFactory.createLoweredBevelBorder(),
				    "Thresholds",
				    javax.swing.border.TitledBorder.CENTER,
				    javax.swing.border.TitledBorder.TOP
				    ),
				   //BorderFactory.createEmptyBorder(5,5,5,5)
				   BorderFactory.createEmptyBorder(1,1,1,1)
				   )
				  );
	
	m_oGridBagConstraints.fill = GridBagConstraints.VERTICAL;
	m_oGridBagConstraints.weightx = 0;
	m_oGridBagConstraints.weighty = 0.45;
	m_oGridBagConstraints.gridx = 3;
	m_oGridBagConstraints.gridy = 0;
	m_oGridBagConstraints.gridwidth = 1;
	m_oGridBagConstraints.gridheight = 1;
	//m_oGridBagConstraints.ipadx = 10;
	m_oGridBagConstraints.ipadx = 0;
	m_oGridBagConstraints.ipady = 0;
	m_oGridBagConstraints.anchor = GridBagConstraints.EAST;
	m_oGridBagConstraints.insets = new Insets(0,4,0,0);
	m_oGridBag.setConstraints(oThresholdPanel, m_oGridBagConstraints);
	add(oThresholdPanel);
	
	//oThresholdPanel.setLayout(null);
	oThresholdPanel.setLayout(new GridLayout(5, 1));
	
	JTextField oHigherLabel = new JTextField(">99.7%");
	//oHigherLabel.setBounds(2,15,95,15);
	oHigherLabel.setBorder(BorderFactory.createEmptyBorder());
	oHigherLabel.setBackground(java.awt.Color.green);
	oHigherLabel.setEditable(false);
	oThresholdPanel.add(oHigherLabel);

	JPanel oInputPanel = new JPanel();
	oInputPanel.setLayout(new BoxLayout(oInputPanel, BoxLayout.X_AXIS));
	{
	    m_oLowThreshold = new JTextField(m_sNormal);
	    m_oLowThreshold.setBackground(java.awt.Color.white);
	    m_oLowThreshold.addKeyListener( new KeyAdapter()
		{
		    public void keyPressed(KeyEvent e)
		    {
			UserManager.m_bRuleUpdated = true;
		    }
		});
	    
	    oInputPanel.add(m_oLowThreshold);
	    
	    JLabel oDashLabel = new JLabel("-");
	    oInputPanel.add(oDashLabel);
	    
	    m_oHighThreshold = new JTextField(m_sWarning);
	    m_oHighThreshold.setBackground(java.awt.Color.white);
	    m_oLowThreshold.addKeyListener( new KeyAdapter()
		{
		    public void keyPressed(KeyEvent e)
		    {
			UserManager.m_bRuleUpdated = true;
		    }
		});
	    oInputPanel.add(m_oHighThreshold);
	}
	oThresholdPanel.add(oInputPanel);
	
	JTextField oLowerLabel = new JTextField("<99.5%");
	oLowerLabel.setBorder(BorderFactory.createEmptyBorder());
	oLowerLabel.setBackground(java.awt.Color.red);
	oLowerLabel.setEditable(false);
	oThresholdPanel.add(oLowerLabel);
	
	JRadioButton oRadioButton = null;
	ButtonGroup oGroup = new ButtonGroup();
	{
	    oRadioButton = new JRadioButton("Propagate Avg.");
	    oRadioButton.setFont(new Font("Dialog", Font.PLAIN, 9));
	    oRadioButton.setMnemonic(KeyEvent.VK_A);
	    oRadioButton.setSelected(true);
	    oThresholdPanel.add(oRadioButton);
	    
	    oGroup.add(oRadioButton);
	}
	{
	    oRadioButton = new JRadioButton("Propagate Worst");
	    oRadioButton.setFont(new Font("Dialog", Font.PLAIN, 9));
	    oRadioButton.setMnemonic(KeyEvent.VK_W);
	    oThresholdPanel.add(oRadioButton);
	    
	    oGroup.add(oRadioButton);
	}
    }
    
    void addServicesBox()
    {
	JPanel oServicePanel= new JPanel();
        oServicePanel.setBorder(BorderFactory.createCompoundBorder
				(
				 BorderFactory.createTitledBorder
				 (
				  BorderFactory.createLoweredBevelBorder(),
				  "Services",
				  javax.swing.border.TitledBorder.CENTER,
				  javax.swing.border.TitledBorder.TOP
				  ),
				 BorderFactory.createEmptyBorder(5,5,5,5)
				 )
				);
	
	m_oGridBagConstraints.fill = GridBagConstraints.VERTICAL;
	m_oGridBagConstraints.weightx = 0;
	m_oGridBagConstraints.weighty = 0.45;
	m_oGridBagConstraints.gridx = 3;
	m_oGridBagConstraints.gridy = 1;
	m_oGridBagConstraints.gridwidth = 1;
	//m_oGridBagConstraints.ipadx = 10;
	m_oGridBagConstraints.ipadx = 0;
	m_oGridBagConstraints.ipady = 90;
	m_oGridBagConstraints.anchor = GridBagConstraints.EAST;
	m_oGridBagConstraints.insets = new Insets(0,4,0,0);
	m_oGridBag.setConstraints(oServicePanel, m_oGridBagConstraints);
	add(oServicePanel);
	
	oServicePanel.setLayout(new GridLayout(5, 1));
	
	JCheckBox oCheckBox = null;
	{
	    oCheckBox = new JCheckBox("icmp (ping)"); 
	    oCheckBox.setFont(new Font("Dialog", Font.PLAIN, 9));
	    oCheckBox.setMnemonic(KeyEvent.VK_I); 
	    oCheckBox.setSelected(true);
	    oServicePanel.add(oCheckBox);
	}
	{
	    oCheckBox = new JCheckBox("http (web)");
	    oCheckBox.setFont(new Font("Dialog", Font.PLAIN, 9));
	    oCheckBox.setMnemonic(KeyEvent.VK_H);
	    oCheckBox.setSelected(true);
	    oServicePanel.add(oCheckBox);
	}
	{
	    oCheckBox = new JCheckBox("SAP (mfg app)");
	    oCheckBox.setFont(new Font("Dialog", Font.PLAIN, 9));
	    oCheckBox.setMnemonic(KeyEvent.VK_S);
	    oCheckBox.setSelected(true);
	    oServicePanel.add(oCheckBox);
	}
	{
	    oCheckBox = new JCheckBox("ftp (file xfer)"); 
	    oCheckBox.setFont(new Font("Dialog", Font.PLAIN, 9));
	    oCheckBox.setMnemonic(KeyEvent.VK_F); 
	    oCheckBox.setSelected(true);
	    oServicePanel.add(oCheckBox);
	}
	{
	    oCheckBox = new JCheckBox("NFS (disc)"); 
	    oCheckBox.setFont(new Font("Dialog", Font.PLAIN, 9));
	    oCheckBox.setMnemonic(KeyEvent.VK_N); 
	    oCheckBox.setSelected(true);
	    oServicePanel.add(oCheckBox);
	}
    }


    public String addThresholdLowHighValues(String sRule)
    {
	String sTextRule = null;
	StringTokenizer oTokenizer = new StringTokenizer(sRule,"$");
	m_sNormal = oTokenizer.nextToken();
	m_sWarning = oTokenizer.nextToken();
	sTextRule = oTokenizer.nextToken();
	return sTextRule;
    }
    
    void addRedoButton()
    {
	JButton oRedoButton = new JButton();
	oRedoButton.setText("Redo Layout");
	oRedoButton.setFont(new Font("Dialog", Font.BOLD, 10));
	
	m_oGridBagConstraints.fill = GridBagConstraints.BOTH;
	m_oGridBagConstraints.weightx = 0;
	m_oGridBagConstraints.weighty = 0;
	m_oGridBagConstraints.gridx = 3;
	m_oGridBagConstraints.gridy = 2;
	m_oGridBagConstraints.gridwidth = 1;
	m_oGridBagConstraints.gridheight = 2;
	m_oGridBagConstraints.ipadx = 0;
	m_oGridBagConstraints.ipady = 0;
	m_oGridBagConstraints.anchor = GridBagConstraints.EAST;
	//m_oGridBagConstraints.insets = new Insets(8,6,0,1);
	m_oGridBagConstraints.insets = new Insets(2,6,0,1);
	m_oGridBag.setConstraints(oRedoButton, m_oGridBagConstraints);
	add(oRedoButton);
	
	oRedoButton.addActionListener(new ActionListener()
	    {
		public void actionPerformed(ActionEvent e)
		{
		    readGraph();
		}
	    });
    }

    /**This method adds a button directly beneath the Redo Layout and 
       next to the Text Rule field. The button is used to open a dialog
       box displaying the result of the rule in the Text Rule field.
       @return JButton, the newly constructed button.
     */ 
    private JButton addTestButton()
    {
	JButton testButton = new JButton();
	testButton.setText("Test Rule");
	testButton.setFont(new Font("Dialog", Font.BOLD, 10));
	
	m_oGridBagConstraints.fill = GridBagConstraints.BOTH;
	m_oGridBagConstraints.weightx = 0;
	m_oGridBagConstraints.weighty = 0.1;
	m_oGridBagConstraints.gridx = 3;
	m_oGridBagConstraints.gridy = 4;
	m_oGridBagConstraints.gridwidth = 1;
	m_oGridBagConstraints.gridheight = 1;
	m_oGridBagConstraints.ipadx = 0;
	m_oGridBagConstraints.ipady = 0;
	m_oGridBagConstraints.anchor = GridBagConstraints.EAST;
	//m_oGridBagConstraints.insets = new Insets(8,6,0,1);
	m_oGridBagConstraints.insets = new Insets(2,6,0,1);
	m_oGridBag.setConstraints(testButton, m_oGridBagConstraints);
	
	testButton.addActionListener(new ActionListener()
	    {
		/**This method calls the dialog box responsible for displaying the results
		   of an expression rule. The rule is taken from the m_oRule text field.
		   The RuleResutlsDialog is opened to be non modal so several rules can
		   be compared.
		*/
		public void actionPerformed(ActionEvent e)
		{
		    //need semi colon to terminat a rule
		    (new RuleResultsDialog(true, "Results", m_oRule.getText() + ";")).setVisible(true);
		}
	    });

	return testButton;
    }

    void addVerticalScrollBar()
    {
	m_oVerticalScrollBar = new JScrollBar();
	m_iVerticalScrollVal = 0;
	
	m_oGridBagConstraints.fill = GridBagConstraints.VERTICAL;
	m_oGridBagConstraints.weightx = 0;
	m_oGridBagConstraints.weighty = 1.0;
	m_oGridBagConstraints.gridx = 2;
	m_oGridBagConstraints.gridy = 0;
	m_oGridBagConstraints.gridwidth = 1;
	m_oGridBagConstraints.gridheight = 4;
	//m_oGridBagConstraints.ipadx = 10;
	m_oGridBagConstraints.ipadx = 0;
	m_oGridBagConstraints.ipady = 0;
	m_oGridBagConstraints.anchor = GridBagConstraints.EAST;
	//m_oGridBagConstraints.insets = new Insets(8,0,0,4);
	m_oGridBag.setConstraints(m_oVerticalScrollBar, m_oGridBagConstraints);
	add(m_oVerticalScrollBar);
	m_oGridBagConstraints.gridheight = 1;
	
	m_oVerticalScrollBar.setBorder(BorderFactory.createEtchedBorder());
	
	m_oVerticalScrollBar.setVisible(true);
	m_oVerticalScrollBar.setEnabled(true);
	m_oVerticalScrollBar.addAdjustmentListener(new AdjustmentListener()
	    {
		public void adjustmentValueChanged(AdjustmentEvent e)
		{
		    int iIncrement = e.getValue() - m_iVerticalScrollVal;
		    m_iVerticalScrollVal = e.getValue();
		    for(int i=0;i<m_nNodes;i++)
			{
			    m_oNodes[i].m_dY -= 3*iIncrement;
			}
		    repaint();
		}
	    });
    }
    
    void addHorizontalScrollBar()
    {
	m_oHorizontalScrollBar = new JScrollBar(JScrollBar.HORIZONTAL);
	m_iHorizontalScrollVal = 0;
	
	m_oGridBagConstraints.fill = GridBagConstraints.HORIZONTAL;
	m_oGridBagConstraints.weightx = 1.0;
	m_oGridBagConstraints.weighty = 0;
	m_oGridBagConstraints.gridx = 0;
	m_oGridBagConstraints.gridy = 3;
	m_oGridBagConstraints.gridwidth = 2;
	m_oGridBagConstraints.gridheight = 1;
	//m_oGridBagConstraints.ipadx = 10;
	m_oGridBagConstraints.ipadx = 0;
	m_oGridBagConstraints.ipady = 0;
	m_oGridBagConstraints.anchor = GridBagConstraints.SOUTH;
	//m_oGridBagConstraints.insets = new Insets(8,0,0,4);
	m_oGridBag.setConstraints(m_oHorizontalScrollBar, m_oGridBagConstraints);
	add(m_oHorizontalScrollBar);
	
	m_oHorizontalScrollBar.setBorder(BorderFactory.createEtchedBorder());
	
	m_oHorizontalScrollBar.setVisible(true);
	m_oHorizontalScrollBar.setEnabled(true);
	m_oHorizontalScrollBar.addAdjustmentListener(new AdjustmentListener()
	    {
		public void adjustmentValueChanged(AdjustmentEvent e)
		{
		    int iIncrement = e.getValue() - m_iHorizontalScrollVal;
		    m_iHorizontalScrollVal = e.getValue();
		    for(int i=0;i<m_nNodes;i++)
		    {
			m_oNodes[i].m_dX -= 3*iIncrement;
		    }
		    repaint();
		}
	    });
    }
    
    public void init()
    {
	addMouseListener(this);
	addMouseMotionListener(this);
	addPopupMenu();
	
	setDropTarget(new DropTarget((Component)RuleCategoryPanel.this, DnDConstants.ACTION_COPY_OR_MOVE, this, true));
    }
    
    int findNode(String sLbl)
    {
	for(int i = 0 ; i < m_nNodes ; i++)
	{
	    if(m_oNodes[i].m_sDescLbl.equals(sLbl))
	    {
		return i;
	    }
	}
	return addNode(sLbl);
    }
    
    int addNode(String sLbl)
    {
	return addNode(sLbl,20,20);
    }
    
    int addNode(String sLbl, double x, double y)
    {
	Node oNode = new Node();
	oNode.m_dX = x;
	oNode.m_dY = y;
	oNode.m_sDescLbl = sLbl;
	int len = sLbl.length();
	if(len>6)
	{
	    len = 6;
	}
	oNode.m_sLbl = sLbl.substring(0,len);
	m_oNodes[m_nNodes] = oNode;
	
	return m_nNodes++;
    }
    
    void delNode(String sLbl)
    {
	delAllEdge(sLbl);
	int i=0;
	int nThis=-1;
	while(i < m_nNodes)
	{
	    if(m_oNodes[i].m_sDescLbl.equals(sLbl))
	    {
		nThis = i;
		for(int j = i ; j < m_nNodes-1 ; j++)
		{
		    Integer nTemp = new Integer(i);
		    if(m_oNodes[j].m_vNodes.contains(nTemp))
		    {
			m_oNodes[j].m_vNodes.remove(nTemp);
		    }
		    m_oNodes[j] = m_oNodes[j+1];
		}
		for(int k=0 ; k < m_nEdges ; k++)
		{
		    if(m_oEdges[k].m_iFrom > i)
		    {
			--m_oEdges[k].m_iFrom;
		    }
		    if(m_oEdges[k].m_iTo > i)
		    {
			--m_oEdges[k].m_iTo;
		    }
		}
		m_nNodes--;
	    }
	    else
	    {
		++i;
	    }
	}
	for(i = 0 ; i < m_nNodes ; i++)
	{
	    Integer nTemp = new Integer(nThis);
	    if(m_oNodes[i].m_vNodes.contains(nTemp))
	    {
		m_oNodes[i].m_vNodes.remove(nTemp);
	    }
	    //also, if the vector  contains anything greater than nTemp,
	    //reduce the same by 1
	    if(nThis > 1)for(int jj=nThis+1;jj<m_nNodes+1;jj++)
	    {
		nTemp = new Integer(jj);
		if(m_oNodes[i].m_vNodes.contains(nTemp))
		{
		    m_oNodes[i].m_vNodes.remove(nTemp);
		    m_oNodes[i].m_vNodes.add(new Integer(jj-1));
		}
	    }
	}
	repaint();
    }
    
    void addEdge(String sFrom, String sTo, int nLen)
    {
	Edge oEdge = new Edge();
	oEdge.m_iFrom = findNode(sFrom);
	oEdge.m_iTo = findNode(sTo);
	oEdge.m_dLen = nLen;
	m_oEdges[m_nEdges++] = oEdge;
	m_oNodes[oEdge.m_iFrom].m_vNodes.add(new Integer(oEdge.m_iTo));
    }
    
    void addEdge(String sFrom, String sTo)
    {
	Edge oEdge = new Edge();
	oEdge.m_iFrom = findNode(sFrom);
	oEdge.m_iTo = findNode(sTo);
	int x1 = (int)m_oNodes[oEdge.m_iFrom].m_dX;
	int y1 = (int)m_oNodes[oEdge.m_iFrom].m_dY;
	int x2 = (int)m_oNodes[oEdge.m_iTo].m_dX;
	int y2 = (int)m_oNodes[oEdge.m_iTo].m_dY;
	oEdge.m_dLen = (int)Math.abs(Math.sqrt((x1-x2)*(x1-x2) + (y1-y2)*(y1-y2)) - oEdge.m_dLen);
	m_oEdges[m_nEdges++] = oEdge;
	m_oNodes[oEdge.m_iFrom].m_vNodes.add(new Integer(oEdge.m_iTo));
    }
    
    void delEdge(Edge oEdge)
    {
	int i;
	for(i = 0 ; i < m_nEdges ; i++)
	{
	    if(m_oEdges[i] == oEdge)
	    {
		m_oNodes[oEdge.m_iFrom].m_vNodes.remove(new Integer(oEdge.m_iTo));
		for(int j = i ; j < m_nEdges-1 ; j++)
		{
		    m_oEdges[j] = m_oEdges[j+1];
		}
		m_nEdges--;
		break;
	    }
	}
	repaint();
    }
    
    void delAllEdge(String sLbl)
    {
	int i=0;
	//for(i = 0 ; i < m_nEdges ; i++)
	while(i < m_nEdges)
	{
	    if(m_oNodes[m_oEdges[i].m_iFrom].m_sDescLbl.equals(sLbl) || m_oNodes[m_oEdges[i].m_iTo].m_sDescLbl.equals(sLbl))
	    {
		m_oNodes[m_oEdges[i].m_iFrom].m_vNodes.remove(new Integer(m_oEdges[i].m_iTo));
		for(int j = i ; j < m_nEdges-1 ; j++)
		{
		    m_oEdges[j] = m_oEdges[j+1];
		}
		m_nEdges--;
	    }
	    else
	    {
		++i;
	    }
	}
	repaint();
    }
    
    void readGraph()
    {
	m_oNodes[0].m_dX = 26;  m_oNodes[0].m_dY = 145;
	m_oNodes[1].m_dX = 384; m_oNodes[1].m_dY = 145;
	recognise();
	repaint();
    }
    
    int m_iLevel = -1;
    double m_iSinkX = 0;
    void recognise(int iNode) throws Exception
    {
	int n = 0;
	int nBraces = 0;
	if(m_iLevel>=50)
	{
	    String sMsg = "Unable to recognise incomplete or erroneous layout.";
	    JOptionPane.showMessageDialog(getParent(),
					  sMsg,
					  "Rule Builder Error..",
					  JOptionPane.ERROR_MESSAGE);
	    m_sRuleBuffer = null;
	    throw new Exception();
	}
	if(m_nNodes<iNode || (n=m_oNodes[iNode].m_vNodes.size())<=0 || (iNode==1) || (m_sRuleBuffer == null))
	{
	    String sMsg = "Unable to recognise incomplete or erroneous layout.";
	    JOptionPane.showMessageDialog(getParent(),
					  sMsg,
					  "Rule Builder Error..",
					  JOptionPane.ERROR_MESSAGE);
	    m_sRuleBuffer = null;
	    throw new Exception();
	    //return;
	}
	if(!m_oNodes[iNode].m_sDescLbl.equals("source"))
	{
	    //m_sRuleBuffer.append("(");
	    m_sRuleBuffer.append(m_oNodes[iNode].m_sDescLbl);
	    m_sRuleBuffer.append(" & ");
	    if(n>1)
	    {
		m_sRuleBuffer.append("(");
		++nBraces;
	    }
	}
	int i = 0;
	++m_iLevel;
	Node oNode = new Node();
	if((n%2)!=0)
	{
	    oNode = m_oNodes[((Integer)m_oNodes[iNode].m_vNodes.get(n-1)).intValue()];
	    if(oNode.m_sDescLbl.equals("sink"))
	    {
		oNode.m_dX = m_oNodes[iNode].m_dX + 60;
		if(oNode.m_dX<=m_iSinkX)
		{
		    oNode.m_dX = m_iSinkX + 60;
		}
		m_sRuleBuffer.append(oNode.m_sDescLbl);
		if(nBraces>0)
		{
		    m_sRuleBuffer.append(")");
		    --nBraces;
		}
		--m_iLevel;
		return;
	    }
	    oNode.m_dX = m_oNodes[iNode].m_dX + 60;
	    oNode.m_dY = m_oNodes[iNode].m_dY;
	    if(m_iSinkX<oNode.m_dX)
	    {
		m_iSinkX = oNode.m_dX;
	    }
	    if(n>1)
	    {
		m_sRuleBuffer.append("(");
		++nBraces;
	    }
	    
	    recognise(((Integer)m_oNodes[iNode].m_vNodes.get(n-1)).intValue());
	    if(n>1)
	    {
		m_sRuleBuffer.append(")");
		m_sRuleBuffer.append(" | ");
		--nBraces;
	    }
	    //++i;
	    --n;
	}
	while(i<(n/2))
	{
	    oNode = m_oNodes[((Integer)m_oNodes[iNode].m_vNodes.get(i)).intValue()];
	    if(oNode.m_sDescLbl.equals("sink"))
	    {
		oNode.m_dX = m_oNodes[iNode].m_dX + 60;
		if(oNode.m_dX<=m_iSinkX)
		{
		    oNode.m_dX = m_iSinkX+60;
		}
		return;
	    }
	    oNode.m_dX = m_oNodes[iNode].m_dX + 60;
	    //oNode.m_dY = m_oNodes[iNode].m_dY + (240/n)*(i+1);
	    oNode.m_dY = m_oNodes[iNode].m_dY + (85)*(i+1) - m_iLevel*15;
	    if(m_iSinkX<oNode.m_dX)
	    {
		m_iSinkX = oNode.m_dX;
	    }
	    if(n>1)
	    {
		m_sRuleBuffer.append("(");
		++nBraces;
	    }
	    recognise(((Integer)m_oNodes[iNode].m_vNodes.get(i)).intValue());
	    if(n>1)
	    {
		m_sRuleBuffer.append(")");
		m_sRuleBuffer.append(" | ");
		--nBraces;
	    }
	    ++i;
	}
	while(i<n)
	{
	    oNode = m_oNodes[((Integer)m_oNodes[iNode].m_vNodes.get(i)).intValue()];
	    if(oNode.m_sDescLbl.equals("sink"))
	    {
		oNode.m_dX = m_oNodes[iNode].m_dX + 60;
		if(oNode.m_dX<=m_iSinkX)
		{
		    oNode.m_dX = m_iSinkX + 60;
		}
		return;
	    }
	    oNode.m_dX = m_oNodes[iNode].m_dX + 60;
	    //oNode.m_dY = m_oNodes[iNode].m_dY - (240/n)*(n-i);
	    oNode.m_dY = m_oNodes[iNode].m_dY - (85)*(n-i) + m_iLevel*15;
	    if(m_iSinkX<oNode.m_dX)
	    {
		m_iSinkX = oNode.m_dX;
	    }
	    if(n>1)
	    {
		m_sRuleBuffer.append("(");
		++nBraces;
	    }
	    recognise(((Integer)m_oNodes[iNode].m_vNodes.get(i)).intValue());
	    if(n>1)
	    {
		m_sRuleBuffer.append(")");
		
		//shouldn't put an 'or' operator at the end of a rule
		//m_sRuleBuffer.append(" | ");
		
		--nBraces;
	    }
	    ++i;
	}
	if(nBraces>0)
	{
	    m_sRuleBuffer.append(")");
	    --nBraces;
	}
	--m_iLevel;
    }
    
    void recognise()
    {
	m_sRuleBuffer = new StringBuffer("");
	try
	{
	    m_iLevel = -1;
	    m_iSinkX = -1;
	    recognise(0);
	    int nCount = 0;
	    int iNode = 0;
	    for(int i=0; i<m_nNodes; i++)
	    {
		if(m_oNodes[i].m_vNodes.contains(new Integer(1)))
		{
		    iNode = i;
		    if(++nCount > 1)
		    {
			break;
		    }
		}
	    }
	    if(nCount == 1)
	    {
		m_oNodes[iNode].m_dY = m_oNodes[1].m_dY;
	    }
	}
	catch(Exception e)
	{
	    //System.out.println("User Exception caught.");
	}
	
	int nIdx = -1;
	if(m_sRuleBuffer == null)
	{
	    m_oRule.setText("Type your text rule here..");
	    return;
	}
	while((nIdx=m_sRuleBuffer.toString().indexOf(" & sink"))!= -1)
	{
	    m_sRuleBuffer = m_sRuleBuffer.delete(nIdx, nIdx+7);
	}
	while((nIdx=m_sRuleBuffer.toString().indexOf("sink"))!= -1)
	{
	    m_sRuleBuffer = m_sRuleBuffer.delete(nIdx, nIdx+4);
	}
	while((nIdx=m_sRuleBuffer.toString().indexOf(" | )"))!= -1)
	{
	    m_sRuleBuffer = m_sRuleBuffer.delete(nIdx, nIdx+3);
	}
	while((nIdx=m_sRuleBuffer.toString().indexOf("& ()"))!= -1)
	{
	    m_sRuleBuffer = m_sRuleBuffer.delete(nIdx, nIdx+3);
	}
	while((nIdx=m_sRuleBuffer.toString().indexOf("| ()"))!= -1)
	{
	    m_sRuleBuffer = m_sRuleBuffer.delete(nIdx, nIdx+3);
	}
	while((nIdx=m_sRuleBuffer.toString().indexOf("()"))!= -1)
	{
	    m_sRuleBuffer = m_sRuleBuffer.delete(nIdx, nIdx+2);
	}

	m_oRule.setText(m_sRuleBuffer.toString());
	UserManager.m_bRuleUpdated = true;
	UserManager.m_bFigureUpdated = false;
    }
    
    double distance(Point oPoint, Edge oEdge)
    {
        double x1 = m_oNodes[oEdge.m_iFrom].m_dX,
	    x2 = m_oNodes[oEdge.m_iTo].m_dX,
	    y1 = m_oNodes[oEdge.m_iFrom].m_dY,
	    y2 = m_oNodes[oEdge.m_iTo].m_dY;
        
	double dDist  = 0.0;
        
	int    X  = oPoint.x,
	    Y  = oPoint.y;
        
        if(Math.abs(x2-x1) < 0.01)
	{
	    dDist = Math.abs(X-x1);
	}
        if(Math.abs(y2-y1) < 0.01)
        {
            dDist = Math.abs(Y-y1);
        }
        else
        {
            double m = (y2-y1)/(x2-x1);
            dDist = Math.abs(Y-y1-m*(X-x1));
            dDist/= Math.sqrt(1+m*m);
        }
        return dDist;
    }
    
    public void paintNode(Graphics oGraphics, Node oNode, FontMetrics oFm)
    {
	if(!oNode.m_sDescLbl.equals("RULE"))
	{
	    int x = (int)oNode.m_dX;
	    int y = (int)oNode.m_dY;
	    oGraphics.setColor((oNode == m_oPick) ? SELECT_COLOR : (oNode.m_bFixed ? FIXED_COLOR : NODE_COLOR));
	    int w = oFm.stringWidth(oNode.m_sLbl) + 10;
	    int h = oFm.getHeight() + 4;
	    //oGraphics.fillRect(x - w/2, y - h/2, w, h);
	    //oGraphics.setColor(Color.black);
	    
	    String sSlash = System.getProperty("file.separator");
	    if(oNode.m_sDescLbl.equals("source"))
	    {
		Image oImage = Toolkit.getDefaultToolkit().getImage("data/images/source28.gif");
		oGraphics.setColor(Color.black);
		oGraphics.drawImage(oImage, x - 8, y - 8, 28, 28, this);
	    }
	    else if(oNode.m_sDescLbl.equals("sink"))
	    {
		Image oImage = Toolkit.getDefaultToolkit().getImage("data/images/sink28.gif");
		oGraphics.setColor(Color.black);
		oGraphics.drawImage(oImage, x - 8, y - 8, 28, 28, this);
	    }
	    else
	    {
		Image oImage = null;
		if(oNode.m_sDescLbl.startsWith("IF"))
		{
		    oImage = Toolkit.getDefaultToolkit().getImage("data/images/if28.gif");
		}
		else if(oNode.m_sDescLbl.startsWith("IP"))
		{
		    oImage = Toolkit.getDefaultToolkit().getImage("data/images/ip28.gif");
		}
		else
		{
		    oImage = Toolkit.getDefaultToolkit().getImage("data/images/sys28.gif");
		}
		oGraphics.setColor(Color.black);
		oGraphics.drawImage(oImage, x-8, y-8, 28, 28, this);
	
		/*
		  oGraphics.fill3DRect(x - w/2, y - h/2, w, h, true);
		  oGraphics.setColor(Color.black);
		  oGraphics.draw3DRect(x - w/2, y - h/2, w-1, h-1, true);
		*/
	    }
	    //oGraphics.drawString(oNode.m_sLbl, x - (w-10)/2, (y - (h-4)/2) + oFm.getAscent());
	    //oGraphics.drawString(oNode.m_sLbl, x - (w)/2, y - (h-56)/2 + oFm.getAscent());
	    oGraphics.drawString(oNode.m_sLbl, x-8, y - (h-56)/2 + oFm.getAscent());
	}
    }
    
    public synchronized void paint(Graphics oGraphics)
    {
	super.paint(oGraphics);
	Dimension d = getSize();
	d = new Dimension(d.width - 132,d.height - 50);
	if((m_oOffscreen == null) || (d.width != m_oOffscreensize.width) || (d.height != m_oOffscreensize.height))
	{
	    m_oOffscreen = createImage(d.width, d.height);
	    m_oOffscreensize = d;
	    m_oOffgraphics = m_oOffscreen.getGraphics();
	    m_oOffgraphics.setFont(new Font("Dialog", Font.ITALIC, 9));
	}
	
	//m_oOffgraphics.setColor(getBackground());
	m_oOffgraphics.setColor(java.awt.Color.white);
	m_oOffgraphics.fillRect(0, 0, d.width, d.height);
	for(int i = 0 ; i < m_nEdges ; i++)
	{
	    Edge oEdge = m_oEdges[i];
	    double x1 = m_oNodes[oEdge.m_iFrom].m_dX;
	    double y1 = m_oNodes[oEdge.m_iFrom].m_dY;
	    double x2 = m_oNodes[oEdge.m_iTo].m_dX;
	    double y2 = m_oNodes[oEdge.m_iTo].m_dY;
	    double len = Math.abs(Math.sqrt((x1-x2)*(x1-x2) + (y1-y2)*(y1-y2)) - oEdge.m_dLen);
	    m_oOffgraphics.setColor(ARC_COLOR);
	    m_oOffgraphics.drawLine((int)x1, (int)y1, (int)x2, (int)y2);
	    
	    double midX = (x1+x2)/2;
	    double midY = (y1+y2)/2;
	    
	    if(Math.abs(x2-x1) < 0.01)
	    {
		continue;
	    }
	    double m = (y1-y2)/(x1-x2);
	    double dDirection = (m-(midY+6*Math.sin(Math.PI/4 - Math.atan(m))-y1)/(midX-6*Math.cos(Math.PI/4 - Math.atan(m))-x1));
	    
	    if(dDirection<0)
	    {
		m_oOffgraphics.drawLine((int)midX,
					(int)midY,
					(int)(midX-6*Math.cos(Math.PI/4 - Math.atan(m))),
					(int)(midY+6*Math.sin(Math.PI/4 - Math.atan(m))) );
		m_oOffgraphics.drawLine((int)midX,
					(int)midY,
					(int)(midX-6*Math.sin(Math.PI/4 - Math.atan(m))),
					(int)(midY-6*Math.cos(Math.PI/4 - Math.atan(m))) );
	    }
	    else
	    {
		m_oOffgraphics.drawLine((int)midX,
					(int)midY,
					(int)(midX+6*Math.cos(Math.PI/4 - Math.atan(m))),
					(int)(midY-6*Math.sin(Math.PI/4 - Math.atan(m))) );
		m_oOffgraphics.drawLine((int)midX,
					(int)midY,
					(int)(midX+6*Math.sin(Math.PI/4 - Math.atan(m))),
					(int)(midY+6*Math.cos(Math.PI/4 - Math.atan(m))) );
	    }
	}
	
	FontMetrics oFm = m_oOffgraphics.getFontMetrics();
	for(int i = 0 ; i < m_nNodes ; i++)
	{
	    paintNode(m_oOffgraphics, m_oNodes[i], oFm);
	}
	oGraphics.drawImage(m_oOffscreen, 0, 0, null);
    }
    
    public void mouseClicked(MouseEvent e)
    {
	if(e.getClickCount()>1)
	{
	    int x = e.getX();
	    int y = e.getY();
	    e.consume();
	    m_bDrawMode = true;
	    double bestdist = 1000;
	    for(int i = 0 ; i < m_nNodes ; i++)
	    {
		Node oNode = m_oNodes[i];
		double dist = (oNode.m_dX - x) * (oNode.m_dX - x) + (oNode.m_dY - y) * (oNode.m_dY - y);
		if(dist < bestdist)
		{
		    m_sDrawSource = oNode.m_sDescLbl;
		    break;
		}
	    }
	    if(m_sDrawSource != null)
	    {
		if(!m_bRuleMade)
		{
		    addNode("RULE", x, y);
		    m_bRuleMade = true;
		}
		addEdge(m_sDrawSource,"RULE");
		repaint();
		e.consume();
	    }
	    repaint();
	    return;
	}
    }
    
    public void mousePressed(MouseEvent e) 
    {
	if(e.isPopupTrigger())
	{
	    popupAction(e);
	    e.consume();
	    return;
	}
	addMouseMotionListener(this);
	
	int x = e.getX();
	int y = e.getY();
	if(m_bDrawMode)
	{
	    m_oPick = m_oNodes[findNode("RULE")];
	    m_bPickfixed = m_oPick.m_bFixed;
	    m_oPick.m_bFixed = true;
	    m_oPick.m_dX = x;
	    m_oPick.m_dY = y;
	    repaint();
	    e.consume();
	    return;
	}
	double bestdist = Double.MAX_VALUE;
	for(int i = 0 ; i < m_nNodes ; i++)
	{
	    Node oNode = m_oNodes[i];
	    double dist = (oNode.m_dX - x)*(oNode.m_dX - x) + (oNode.m_dY - y)*(oNode.m_dY - y);
	    if (dist < 400)
	    {
		m_oPick = oNode;
		bestdist = dist;
		break;
	    }
	}
	if(m_oPick !=null)
	{
	    m_bPickfixed = m_oPick.m_bFixed;
	    m_oPick.m_bFixed = true;
	    m_oPick.m_dX = x;
	    m_oPick.m_dY = y;
	    if(m_oPick.m_dX<5)
	    {
		m_oPick.m_dX=5;
	    }
	    if(m_oPick.m_dY<5)
	    {
		m_oPick.m_dY=5;
	    }
	    if(m_oPick.m_dX>980)
	    {
		m_oPick.m_dX=980;
	    }
	    if(m_oPick.m_dY>970)
	    {
		m_oPick.m_dY=970;
	    }
	}
	repaint();
	e.consume();
    }
    
    public void mouseDragged(MouseEvent e)
    {
	if(m_oPick != null)
	{
	    m_oPick.m_dX = e.getX();
	    m_oPick.m_dY = e.getY();
	    
	    if(m_oPick.m_dX<5)
	    {
		m_oPick.m_dX=5;
	    }
	    if(m_oPick.m_dY<5)
	    {
		m_oPick.m_dY=5;
	    }
	    if(m_oPick.m_dX>980)
	    {
		m_oPick.m_dX=980;
	    }
	    if(m_oPick.m_dY>970)
	    {
		m_oPick.m_dY=970;
	    }
	    
	}
	repaint();
	e.consume();
    }
    
    public void mouseReleased(MouseEvent e)
    {
	if(e.isPopupTrigger())
	{
	    popupAction(e);
	    e.consume();
	    /*
	     * DO NOT RETURN FROM HERE.
	     */
	}
	removeMouseMotionListener(this);
	int x = e.getX();
	int y = e.getY();
	
	if(m_bDrawMode)
	{
	    m_bDrawMode = false;
	    m_bRuleMade = false;
	    setCursor(Cursor.getDefaultCursor());
	    for(int i = 0 ; i < m_nNodes ; i++)
	    {
		Node oNode = m_oNodes[i];
		double dist = (oNode.m_dX - x)*(oNode.m_dX - x) + (oNode.m_dY - y)*(oNode.m_dY - y);
		if(dist < 3000) 
		{
		    if((m_sDrawSource!=null) && !(m_sDrawSource.equals(oNode.m_sDescLbl)))
		    {
			addEdge(m_sDrawSource, oNode.m_sDescLbl);
			UserManager.m_bFigureUpdated = true;
		    }
		    m_sDrawSource = null;
		}
	    }
	}
	delAllEdge("RULE");
	delNode("RULE");
	m_sDrawSource = null;
	if(m_oPick != null)
	{
	    m_oPick.m_dX = x;
	    m_oPick.m_dY = y;
	    if(m_oPick.m_dX<5)
	    {
		m_oPick.m_dX=5;
	    }
	    if(m_oPick.m_dY<5)
	    {
		m_oPick.m_dY=5;
	    }
	    if(m_oPick.m_dX>980)
	    {
		m_oPick.m_dX=980;
	    }
	    if(m_oPick.m_dY>970)
	    {
		m_oPick.m_dY=970;
	    }
	    
	    m_oPick.m_bFixed = m_bPickfixed;
	    m_oPick = null;
	}
	repaint();
	e.consume();
    }
    
    public void mouseEntered(MouseEvent e) 
    {
    }
    
    public void mouseExited(MouseEvent e)
    {
    }

    public void mouseMoved(MouseEvent e)
    {
	int x = e.getX(),
	    y = e.getY();
	
	for(int i = 0 ; i < m_nNodes ; i++)
	{
	    Node oNode = m_oNodes[i];
	    double dist = (oNode.m_dX - x)*(oNode.m_dX - x) + (oNode.m_dY - y)*(oNode.m_dY - y);
	    if (dist < 400)
	    {
		m_oNodes[i].m_sLbl = m_oNodes[i].m_sDescLbl;
		for(int jj=0;jj<m_oNodes[i].m_vNodes.size();jj++)
		{
		    Node adjNode = m_oNodes[((Integer)m_oNodes[i].m_vNodes.get(jj)).intValue()];
		    if(Math.abs(adjNode.m_dY-oNode.m_dY)<2)
		    {
			int iGap = (int)(adjNode.m_dX-oNode.m_dX);
			iGap -= getGraphics().getFontMetrics().stringWidth(oNode.m_sDescLbl);
			if(iGap<-18)
			{
			    adjNode.m_sLbl = "";
			}
			break;
		    }
		}
		repaint();
		break;
	    }
	    else
	    {
		int len = m_oNodes[i].m_sDescLbl.length();
		if(len>6)
		{
		    len = 6;
		}
		m_oNodes[i].m_sLbl = m_oNodes[i].m_sDescLbl.substring(0,len);
		repaint();
	    }
	}
	if(m_oPick != null)
	{
	    m_oPick.m_dX = e.getX();
	    m_oPick.m_dY = e.getY();
	    if(m_oPick.m_dX<5)
	    {
		m_oPick.m_dX=5;
	    }
	    if(m_oPick.m_dY<5)
	    {
		m_oPick.m_dY=5;
	    }
	    if(m_oPick.m_dX>980)
	    {
		m_oPick.m_dX=980;
	    }
	    if(m_oPick.m_dY>970)
	    {
		m_oPick.m_dY=970;
	    }
	}
	repaint();
	e.consume();
    }
    
    public void drop(DropTargetDropEvent e)
    {
	try
	{
	    Point	 pDropLocation = e.getLocation();
	    DataFlavor 	 oStringFlavor = DataFlavor.stringFlavor;
	    Transferable oData         = e.getTransferable();
	    
	    if(e.isDataFlavorSupported(oStringFlavor))
	    {
		String oText = (String)oData.getTransferData(oStringFlavor);
		
		e.acceptDrop(DnDConstants.ACTION_COPY_OR_MOVE);
		addNode(oText, pDropLocation.getX(), pDropLocation.getY());
		repaint();
		e.dropComplete(true);
	    }
	    else
	    {
		Toolkit.getDefaultToolkit().beep();
		e.rejectDrop();
	    }
	}
	catch(IOException ex)
	{
	    ex.printStackTrace();
	}
	catch(UnsupportedFlavorException exp)
	{
	    exp.printStackTrace();
	}
    }
    
    public void dragEnter(DropTargetDragEvent e)
    {
	if(isDragOk(e) == false)
	{
	    e.rejectDrag();
	    return;
	}
	e.acceptDrag(DnDConstants.ACTION_COPY_OR_MOVE);
    }
    
    public void dragExit(DropTargetEvent e)
    {
    }
    
    public void dragOver(DropTargetDragEvent e)
    {
	Point	oDragLocation	= e.getLocation();
	if(isDragOk(e) == false)
	{
	    e.rejectDrag();
	    return;
	}
	e.acceptDrag(DnDConstants.ACTION_COPY_OR_MOVE);
    }
    
    public void dropActionChanged(DropTargetDragEvent e)
    {
	if(isDragOk(e) == false)
	{
	    e.rejectDrag();
	    return;
	}
	e.acceptDrag(DnDConstants.ACTION_COPY_OR_MOVE);
    }
    
    boolean isDragOk(DropTargetDragEvent e)
    {
	return true;
    }
    
    int m_nSelectedIndex = -1;
    int m_x=0, m_y=0;
    void popupAction(MouseEvent e)
    {
	int x = e.getX();
	int y = e.getY();
	for(int i = 0 ; i < m_nNodes ; i++)
	{
	    Node oNode = m_oNodes[i];
	    double dist = (oNode.m_dX - x)*(oNode.m_dX - x) + (oNode.m_dY - y)*(oNode.m_dY - y);
	    if (dist < 400)
	    {
		m_nSelectedIndex = i;
		if(oNode.m_sDescLbl.equals("source") || oNode.m_sDescLbl.equals("sink"))
		{
		    m_oPopupNode.getComponent(2).setEnabled(false);
		    m_oPopupNode.getComponent(3).setEnabled(false);
		    m_oPopupNode.getComponent(5).setEnabled(false);
		}
		else
		{
		    m_oPopupNode.getComponent(2).setEnabled(true);
		    m_oPopupNode.getComponent(3).setEnabled(true);
		    m_oPopupNode.getComponent(5).setEnabled(true);
		}
		if(!oNode.m_sDescLbl.equals("RULE"))
		{
		    m_oPopupNode.show((Component)e.getSource(),
				      (m_x=e.getX()),
				      (m_y=e.getY()));
		}
		e.consume();
		return;
	    }
	}
	
	Point oPoint = new Point(x,y);
	for(int i = 0 ; i < m_nEdges ; i++)
	{
	    Edge oEdge = m_oEdges[i];
	    double dist = distance(oPoint, oEdge);
	    if (dist < 2.5)
	    {
		if(oEdge.isPointInBetween(this,oPoint))
		{
		    m_nSelectedIndex = i;
		    m_oPopupEdge.show((Component)e.getSource(),
				      (m_x=e.getX()),
				      (m_y=e.getY()));
		    e.consume();
		    return;
		}
	    }
	}
	if(UserManager.m_sEditBuffer != null)
	{
	    m_oPopupEdit.getComponent(3).setEnabled(true);
	}
	else
	{
	    m_oPopupEdit.getComponent(3).setEnabled(false);
	}
	m_oPopupEdit.show((Component)e.getSource(),
			  (m_x=e.getX()),
			  (m_y=e.getY()));
	e.consume();
	return;
    }
    
    public void actionPerformed(ActionEvent e)
    {
	if(e.getActionCommand().equals("Join"))
	{
	    m_bDrawMode = true;
	    if(m_nSelectedIndex != -1)
	    {
		m_sDrawSource = m_oNodes[m_nSelectedIndex].m_sDescLbl;
		if(!m_bRuleMade)
		{
		    //addNode("RULE", m_oNodes[m_nSelectedIndex].m_dX, m_oNodes[m_nSelectedIndex].m_dY);
		    addNode("RULE", m_x, m_y);
		    m_bRuleMade = true;
		}
		addEdge(m_sDrawSource,"RULE");
		m_oPick = m_oNodes[findNode("RULE")];
		m_bPickfixed = m_oPick.m_bFixed;
		m_oPick.m_bFixed = true;
		addMouseMotionListener(this);
				
		/*
		 * TBD: Change the cursor:
		 */
		setCursor(new Cursor(Cursor.HAND_CURSOR));
		repaint();
	    }
	    repaint();
	    return;
	}
	else if(e.getActionCommand().equals("DeleteEdge"))
	{
	    delEdge(m_oEdges[m_nSelectedIndex]);
	    UserManager.m_bFigureUpdated = true;
	    repaint();
	    m_nSelectedIndex = -1;
	}
	else if(e.getActionCommand().equals("AddNode"))
	{
	    //inputRule will do validation on this clause
	    String sTemp = inputRule("Rule:", "Add Rule..", null);

	    if((sTemp!=null) && (!(sTemp=sTemp.trim()).equals("")))
	    {
		addNode(sTemp,m_x,m_y);
		UserManager.m_bFigureUpdated = true;
		repaint();
	    }
	}
	else if(e.getActionCommand().equals("ReadRule"))
	{
	    readGraph();
	}
	else if(e.getActionCommand().equals("CutNode"))
	{
	    delAllEdge(m_oNodes[m_nSelectedIndex].m_sDescLbl);
	    delNode(m_oNodes[m_nSelectedIndex].m_sDescLbl);
	    UserManager.m_bFigureUpdated = true;
	    
	    repaint();
	    m_nSelectedIndex = -1;
	}
	else if(e.getActionCommand().equals("CopyNode"))
	{
	    UserManager.m_sEditBuffer = m_oNodes[m_nSelectedIndex].m_sDescLbl;
	}
	else if(e.getActionCommand().equals("Paste"))
	{
	    addNode(UserManager.m_sEditBuffer,m_x,m_y);
	    UserManager.m_bFigureUpdated = true;
	    UserManager.m_sEditBuffer = null;
	    repaint();
	}
	else if(e.getActionCommand().equals("Modify"))
	{
	    //inputRule will do validation on this clause
	    String sTemp = inputRule("Changed rule:", "Rename..", m_oNodes[m_nSelectedIndex].m_sDescLbl);
	    
	    if((sTemp!=null) && (!(sTemp=sTemp.trim()).equals("")))
	    {
		m_oNodes[m_nSelectedIndex].m_sDescLbl = sTemp;
		UserManager.m_bFigureUpdated = true;
		repaint();
	    }
	}
    }
    
    /**This method was added to take the place of just a simple input dialog.
       In addition to getting user input this method will check the syntax of
       the new clause against the filter parser to ensure that the clause is
       syntactically valid. If it is not the user will be warned but will enable
       the user to use the invalid clause.
       @return String, the new rule clause
       @param String label, the label of the input text field
       @param String title, the title of the input dialog
       @param String text, the text to initially display in the text field
     */
    private String inputRule(String label, String title, String text)
    {
	String sTemp = (String)JOptionPane.showInputDialog(this,
							   label,
							   title,
							   JOptionPane.QUESTION_MESSAGE,
							   null,
							   null,
							   text);
	/*Validation should not take place here

	//rules must end with a semi colon
	String result = BBFilter.validateRule(sTemp + ";");

	if (!result.equals(BBFilter.VALID_RULE))
	{
	    int reply = JOptionPane.showConfirmDialog(this, 
						      result + "\nWould you like to fix it?", 
						      "Invalid Rule", 
						      JOptionPane.YES_NO_OPTION);
	    
	    if (reply == JOptionPane.YES_OPTION)
	    {
		sTemp = inputRule(label, title, sTemp);
	    }
	}
	*/
	
	return sTemp;
    } 

    void addPopupMenu()
    {
	/*
	 * Create the popup menu.
	 */
	JMenuItem oMenuItem;
	m_oPopupNode = new JPopupMenu();
	
	oMenuItem = new JMenuItem("Join");
	oMenuItem.setActionCommand("Join");
	oMenuItem.addActionListener((ActionListener)this);
	m_oPopupNode.add(oMenuItem);
	m_oPopupNode.addSeparator();
	oMenuItem = new JMenuItem("Cut");
	oMenuItem.setActionCommand("CutNode");
	oMenuItem.addActionListener((ActionListener)this);
	m_oPopupNode.add(oMenuItem);
	oMenuItem = new JMenuItem("Copy");
	oMenuItem.setActionCommand("CopyNode");
	oMenuItem.addActionListener((ActionListener)this);
	m_oPopupNode.add(oMenuItem);
	m_oPopupNode.addSeparator();
	oMenuItem = new JMenuItem("Modify..");
	oMenuItem.setActionCommand("Modify");
	oMenuItem.addActionListener((ActionListener)this);
	m_oPopupNode.add(oMenuItem);
	
	m_oPopupEdge = new JPopupMenu();
	oMenuItem = new JMenuItem("Delete");
	oMenuItem.setActionCommand("DeleteEdge");
	oMenuItem.addActionListener((ActionListener)this);
	m_oPopupEdge.add(oMenuItem);
	
	m_oPopupEdit = new JPopupMenu();
	oMenuItem = new JMenuItem("Add");
	oMenuItem.setActionCommand("AddNode");
	oMenuItem.addActionListener((ActionListener)this);
	m_oPopupEdit.add(oMenuItem);
	oMenuItem = new JMenuItem("Recognise..");
	oMenuItem.setActionCommand("ReadRule");
	oMenuItem.addActionListener((ActionListener)this);
	m_oPopupEdit.add(oMenuItem);
	m_oPopupEdit.addSeparator();
	oMenuItem = new JMenuItem("Paste");
	oMenuItem.setActionCommand("Paste");
	oMenuItem.addActionListener((ActionListener)this);
	m_oPopupEdit.add(oMenuItem);
    }
}

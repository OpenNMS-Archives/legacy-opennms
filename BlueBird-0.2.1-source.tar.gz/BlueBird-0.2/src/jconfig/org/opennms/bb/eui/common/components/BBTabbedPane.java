//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.common.components;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.event.*;

import javax.swing.plaf.basic.*;

import java.util.Hashtable;

/**
 * <pre>BBTabbedPane 
 *
 * - allows mnemonics to be set for the tabs
 * 
 * - Maintains a hashtable of dirty flags - each instance of this
 *   has its own dirty flag and its own 'id'. Other UI components that 
 *   want to check if a particular tabbedpane instance is clean/dirty
 *   can do so if they know the 'id' of the tabbed pane they are 
 *   interested in </pre>
 *
 * @author Sowmya
 *
 */
public class BBTabbedPane extends JTabbedPane 
{
	// Dirty identification
	static Hashtable dirtyFlags = new Hashtable();
	String identifier;

  	Hashtable mnemonics = null;
  	int condition;
  
	public BBTabbedPane(String str)
	{
		super();

		// Add a flag for this instance
		identifier = new String(str);
		dirtyFlags.put(identifier, Boolean.FALSE);

    		setUI(new MnemonicTabbedPaneUI());
    		mnemonics = new Hashtable();
    
    		setMnemonicCondition(WHEN_IN_FOCUSED_WINDOW);
	}

	/**
	 * Updates the UI and sets it back to MnemonicTabbedPaneUI
	 */
	public void updateUI()
	{
    		setUI(new MnemonicTabbedPaneUI());
	}

	protected class ModelListener implements ChangeListener
	{
        	public void stateChanged(ChangeEvent e) 
		{
			if (!isDirty(identifier))
           			fireStateChanged();            
    		}       
    	}

    	protected ChangeListener createChangeListener() 
	{
        	return new ModelListener();
    	}

    	protected void fireStateChanged() 
	{
		super.fireStateChanged();
	}

	protected void processMouseEvent(MouseEvent e)
	{
		if (e.getID() == e.MOUSE_PRESSED)
		{
			requestFocus(); 
				// force this so that the cell editors get a focusLost()

			if (!isDirty(identifier))
				super.processMouseEvent(e);
		}
		else
			super.processMouseEvent(e);
	}
	
	protected void processKeyEvent(KeyEvent e)
	{
			if (!isDirty(identifier))
			super.processKeyEvent(e);
	}

	/**
	 * Checks if the tabbedpane whose ID is 'id' is dirty
	 */
	public static boolean isDirty(String id)
	{
		boolean bRet=false;
		Object obj  =  dirtyFlags.get(id);

		if (null != obj)
			bRet = ((Boolean)dirtyFlags.get(id)).booleanValue();
		
		return bRet;
	}

	/**
	 * Sets the dirty flag of the tabbed pane 'id' to 'b'
	 */
	public static void setDirty(String id, boolean b)
	{
		dirtyFlags.put(id, new Boolean(b));
	}


	/**
	 * Sets mnemonic of the tab at index 'index' to 'c'
	 */
	public void setMnemonicAt(int index, char c) 
	{
		int key = (int)c;
		if ('a' <= key && key <='z') 
		{
			key -= ('a' - 'A');
		}
		setMnemonicAt(index, key);
	}
  
	/**
	 * Sets mnemonic of the tab at index 'index' to 'keyCode'
	 */
	public void setMnemonicAt(int index, int keyCode) 
	{
		ActionListener action = new MnemonicAction(index);
		KeyStroke stroke = KeyStroke.getKeyStroke(keyCode, ActionEvent.ALT_MASK);
		registerKeyboardAction(action, stroke, condition);
		mnemonics.put(new Integer(index), new Integer(keyCode));
	}
  
	public int getMnemonicAt(int index) 
	{
		int keyCode = 0;
		Integer m = (Integer)mnemonics.get(new Integer(index));
		if (m != null) 
		  keyCode = m.intValue();

		return keyCode;
 	}
  
	public void setMnemonicCondition(int condition) 
	{
		this.condition = condition;
	}
  
	public int getMnemonicCondition() 
	{
    		return condition;
	}
  
	private class MnemonicAction implements ActionListener 
	{
		int index;
    
		public MnemonicAction(int index) 
		{
			this.index = index;
		}
    
		public void actionPerformed(ActionEvent e) 
		{
			requestFocus();
			if (!isDirty(identifier))
			{
				BBTabbedPane tabbedPane = (BBTabbedPane)e.getSource();
				tabbedPane.setSelectedIndex(index);
			}
		}
	}
  
	private class MnemonicTabbedPaneUI extends BasicTabbedPaneUI 
	{
		protected void paintText(Graphics g, int tabPlacement,
                             Font font, FontMetrics metrics, int tabIndex,
                             String title, Rectangle textRect, 
                             boolean isSelected) 
		{
			g.setFont(font);
			BBTabbedPane mtabPane = (BBTabbedPane)tabPane;      
			if (tabPane.isEnabled() && tabPane.isEnabledAt(tabIndex)) 
			{
				g.setColor(tabPane.getForegroundAt(tabIndex));
				BasicGraphicsUtils.drawString(g,title, 
								mtabPane.getMnemonicAt(tabIndex), 
								textRect.x,
			  					textRect.y + metrics.getAscent());
			} 
			else 
			{
				g.setColor(tabPane.getBackgroundAt(tabIndex).brighter());
				BasicGraphicsUtils.drawString(g,title, 
								mtabPane.getMnemonicAt(tabIndex), 
								textRect.x, 
								textRect.y + metrics.getAscent());

				g.setColor(tabPane.getBackgroundAt(tabIndex).darker());
				BasicGraphicsUtils.drawString(g,title, 
								mtabPane.getMnemonicAt(tabIndex),
			  					textRect.x - 1,
			  					textRect.y + metrics.getAscent() - 1);
			}
		}
	} 
}

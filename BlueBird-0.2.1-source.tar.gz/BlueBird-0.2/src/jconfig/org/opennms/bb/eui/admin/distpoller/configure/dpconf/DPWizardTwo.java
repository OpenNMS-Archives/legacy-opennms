//-------------------------------------------------------------------------------------------
//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

//--------------------------------------------------------------------------------------------

package org.opennms.bb.eui.admin.distpoller.configure.dpconf;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.event.*;
import java.util.Vector;


/**
 * @author Jayakrishna Chakravarthula
 *
 * Modifications:
 *
 * 10/18/00 - Changed AWT 'List's to Swing 'JList's
 *          - The '>>' and '<<' buttons are now selected/deselected according
 *            to the list that is currently selected
 *          - Sowmya
 *
 */
public class DPWizardTwo extends JPanel
{

	public JButton b1,b2;
	public JList listBox, listBox1;

	DefaultListModel listBoxModel, listBox1Model;

	//public int first, last, first1, last1;
	//public String swap1[] = null;	


	public DPWizardTwo(String packlist[]) {

		setLayout(new BorderLayout());

		String[] items = packlist;
			
		b1 = new JButton(">>");
		b2 = new JButton("<<");

		listBoxModel = new DefaultListModel();
		listBox = new JList(listBoxModel);

		for (int i = 0; i < items.length; ++i)  {
			listBoxModel.addElement(items[i]);
		}

		JScrollPane listScroller = new JScrollPane(listBox);
		listScroller.setPreferredSize(new Dimension(150, 100));
		listScroller.setMinimumSize(new Dimension(150, 100));
		listScroller.setAlignmentX(LEFT_ALIGNMENT);


		listBox1Model = new DefaultListModel();
		listBox1 = new JList(listBox1Model);

		JScrollPane listScroller1 = new JScrollPane(listBox1);
		listScroller1.setPreferredSize(new Dimension(150, 100));
		listScroller1.setMinimumSize(new Dimension(150, 100));
		listScroller1.setAlignmentX(LEFT_ALIGNMENT);


		//Lay out the label and scroll pane from top to bottom.
		JPanel listPane = new JPanel();
		listPane.setLayout(new BoxLayout(listPane, BoxLayout.Y_AXIS));
		JLabel label = new JLabel("Available Packages");
		listPane.add(label);
		listPane.add(Box.createRigidArea(new Dimension(0,5)));
		listPane.add(listScroller);
		listPane.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));

		//Lay out the buttons from top to bottom
		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.Y_AXIS));
		buttonPanel.add(b1);
		buttonPanel.add(Box.createRigidArea(new Dimension(0,10)));
		buttonPanel.add(b2);
		buttonPanel.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));

		//Lay out the label1 and scroll pane1 from top to bottom.
		JPanel listPane1 = new JPanel();
		listPane1.setLayout(new BoxLayout(listPane1, BoxLayout.Y_AXIS));
		JLabel label1 = new JLabel("Package(s) Assigned to the MidWest Region");
		listPane1.add(label1);
		listPane1.add(Box.createRigidArea(new Dimension(0,5)));
		listPane1.add(listScroller1);
		listPane1.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));


		//Lay out the above panels from left to right.
		JPanel groupPane = new JPanel();
		groupPane.setLayout(new BoxLayout(groupPane, BoxLayout.X_AXIS));
		groupPane.setBorder(BorderFactory.createEmptyBorder(0, 10, 10, 10));
		//groupPane.add(Box.createHorizontalGlue());
		groupPane.add(listPane);
		groupPane.add(Box.createRigidArea(new Dimension(20, 0)));
		groupPane.add(buttonPanel);
		groupPane.add(Box.createRigidArea(new Dimension(20, 0)));
		groupPane.add(listPane1);

		
		add(new JLabel("Choose the Poller Package(s) for Midwest Region"), BorderLayout.NORTH);
		add(groupPane, BorderLayout.SOUTH);
	
		b1.addActionListener( new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{
					Object[] swap = listBox.getSelectedValues();
					for (int i = 0; i < swap.length; i++ )  {
						Object sItem = swap[i];
						listBox1Model.addElement(sItem);
						listBoxModel.removeElement(sItem);
					}

					if (listBoxModel.getSize() == 0)
					{
						listBox1.setSelectedIndex(0);

						b1.setEnabled(false);
						b2.setEnabled(true);
					}
					else
					{
						listBox.setSelectedIndex(0);
					}
				}
				catch (Exception e1){
					System.out.println("insertion problem");
				}
			}
		});

	
		b2.addActionListener( new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{
					Object[] swap1 = listBox1.getSelectedValues();
					for (int j = 0; j < swap1.length; j++ )  {
						Object sItem = swap1[j];
						listBoxModel.addElement(sItem);
						listBox1Model.removeElement(sItem);
					}

					if (listBox1Model.getSize() == 0)
					{
						listBox.setSelectedIndex(0);

						b2.setEnabled(false);
						b1.setEnabled(true);
					}
					else
					{
						listBox1.setSelectedIndex(0);
					}

				}
				catch (Exception e1){
					System.out.println("removal problems");
				}
			}
		});

		// list listeners
		listBox.addListSelectionListener(new ListSelectionListener()
		{
			public void valueChanged(ListSelectionEvent lbEvent)
			{
				JList lsm = (JList)lbEvent.getSource();
	
				if(lsm.isSelectionEmpty())
					return;
	
				b1.setEnabled(true);
				b2.setEnabled(false);
				
				listBox1.clearSelection();
			}
		});

		listBox1.addListSelectionListener(new ListSelectionListener()
		{
			public void valueChanged(ListSelectionEvent lb1Event)
			{
				JList lsm = (JList)lb1Event.getSource();

				if(lsm.isSelectionEmpty())
					return;

				b2.setEnabled(true);
				b1.setEnabled(false);
			
				listBox.clearSelection();
			}
		});

		// Initialize
		if (listBoxModel.getSize() != 0)
			listBox.setSelectedIndex(0);

	}

	public Object[] getSelectedValues() {

		return listBox1Model.toArray();
	}

}


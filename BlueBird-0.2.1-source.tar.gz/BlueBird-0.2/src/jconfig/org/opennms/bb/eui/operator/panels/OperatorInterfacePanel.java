//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.operator.panels;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import java.awt.*;
import java.awt.event.*;

import java.io.File;
import java.io.IOException;
import java.util.*;

import org.opennms.bb.eui.common.components.*;
import org.opennms.bb.eui.admin.utils.*;

import org.opennms.bb.eui.operator.components.*;
import org.opennms.bb.eui.operator.utils.*;

/**
 * <pre> OperatorInterfacePanel is the realtime console panel
 *
 * It contains the standard menu/tool bar options and also adds
 * - external menu options from the 'ExternalMenu' file specified 
 *   in the user profile file
 * - external tool options from the 'ExternalTools' file specified 
 *   in the user profile file
 *
 * The operator standard options allows the operator to 
 * - sort on name or severity
 * - configure the folder tabs. i.e add/remove to/from the configured
 *   views from the list of views available to the user
 * - bring up the event browser
 *
 * The operator can drill down to the various levels by double-click
 * on a bar or jump to different levels by using the right-click
 * popup menu on the bars
 *
 * The OperatorInterfacePanel automatically reads from the user profile
 * file to restore user's last used configured views, tab placement, 
 * look and feel, size etc. and stores these on exit
 *
 * @author Sowmya
 *
 */

public class OperatorInterfacePanel extends JPanel 
{ 
	boolean				bParseException=false;

	protected JTabbedPane 	opTabbedPane;

	// menu
	protected JMenuItem  	upMenuItem, topLevelMenuItem;
	protected JMenuItem		nameSortMenuItem, severityMenuItem;
	protected JMenuItem		alertMenuItem, configureMenuItem;

	// Toolbar
	protected BBTBButton 	upButton, topLevelButton;
	protected BBTBButton 	nameSortButton, severityButton;
	protected BBTBButton 	alertButton, configureButton;

	// status bar
	protected JLabel	navigationLabel;

	// zoom
	JRadioButton		zoomRadio;
	JRadioButton		persRadio;

	// status hints
	final int	STATUS_DOWN  =1;
	final int	STATUS_UP    =-1;
	final int	STATUS_CHANGE=0;

	// prev panels
	protected Hashtable	prevPanel;
	
	// current panel
	protected  OperatorPanel	curPanel=null;

	// current tab
	protected StringBuffer	curTab;

	// levels
	public final String		VIEWS_LEVEL		="Views Level";
	public final String		CATEGORY_LEVEL	="Category Level";
	public final String		EVENTS_LEVEL 	="Events Level";

	// available views
	protected Vector		availableViewsVector;

	// configured views
	protected Vector		configViewsVector;

	// user profile
	Hashtable				userProfile=null;

	// user id
	String					userID;

	// user profile values
	final String XPOS		="xPos";
	final String YPOS		="yPos";
	final String WIDTH		="Width";
	final String HEIGHT		="Height";
	final String TAB_PLACE	="tabPlacement";
	final String LOOKNFEEL	="lookAndFeel";
	final String VIEWS		="views";

	// views level xml tags
	final String LABEL		="label";
	final String ENAME		="ename";
	final String EDESCR		="edescr";

	boolean					bLandFAtStartUp=true;

	boolean					bLookAndFeelChanged=false;

	protected JFrame		opFrame; 

	public OperatorInterfacePanel(JFrame frame, String inpUserID)
	{
		userID = inpUserID;

		// get user profile
		readUserProfile();

		// set look and feel
		String landf = String.valueOf(userProfile.get(LOOKNFEEL));
		if (landf != null)
			handleMenuToolBarActions(landf);

		bLandFAtStartUp = false;

		// store the frame
		opFrame = frame;

		// cur Tab
		curTab = new StringBuffer();

		// prev panels
		prevPanel = new Hashtable();

		// tabbed pane panel
		JPanel tabPanel = new JPanel();
		tabPanel.setLayout(new BorderLayout());

		// Create the tabbed panes
		opTabbedPane = createTabbedPanes();
		if (bParseException)
		{
			handleWindowClose();
			return;
		}

		tabPanel.add(opTabbedPane, BorderLayout.SOUTH);

		// menu toolbar  panel
		JPanel menuToolbarPanel = new JPanel();
		menuToolbarPanel.setLayout(new BorderLayout());

		// Create the menu
		OperatorMenuPanel opMenuPanel = new OperatorMenuPanel(this);
		menuToolbarPanel.add(opMenuPanel, BorderLayout.NORTH);
		
		// create the toolbar
		JPanel toolPanel = new OperatorToolPanel(this);
		menuToolbarPanel.add(toolPanel);

		// Create the status bar and zoom buttons
		JPanel downPanel = createStatusBarAndZoom();

		// actual panel
		setLayout(new BorderLayout());
		add(menuToolbarPanel, BorderLayout.NORTH);
		add(opTabbedPane, BorderLayout.CENTER);
		add(downPanel, BorderLayout.SOUTH);

		// listen to see which is the current tab
		opTabbedPane.addChangeListener(new ChangeListener()
		{
			public void stateChanged(ChangeEvent e)
			{
				JTabbedPane source = (JTabbedPane)e.getSource();

				// check one item to see if all items were disabled
				// on 'remove all'
				if (!alertButton.isEnabled())
					setAllOptions(true);

				int iSelIndex = source.getSelectedIndex(); 
				if (iSelIndex != -1)
				{
					curTab.replace(0, curTab.length(),
											source.getTitleAt(iSelIndex));
				
					curPanel = (OperatorPanel)opTabbedPane.getSelectedComponent();

					setStatus(STATUS_CHANGE);

				}
				else // if nothing selected
				{
					setAllOptions(false);

					curTab.replace(0, curTab.length(), "Ready");
					
					curPanel = null;

				}
			}
		});

		// Set user position/dimension preferences
		setUserPosDimPreferences();

		// If we got here display frame
		opFrame.setVisible(true);
		
		// initialize
		if (opTabbedPane.getTabCount() > 0)
		{
			curTab.replace(0, curTab.length(), opTabbedPane.getTitleAt(0));
			curPanel = (OperatorPanel)opTabbedPane.getComponentAt(0);

			setStatus(STATUS_CHANGE);
		}
	}
	
	/**
	 */
	public void handleWindowOpen()
	{
	}

	/**
	 * Store user preferences on exit
	 */
	public void handleWindowClose()
	{
		handleExit();
	}

	/**
	 * Creates the status bar and the zoom radio buttons
	 */
	protected JPanel createStatusBarAndZoom()
	{
		// create the status bar
		JPanel statPanel = createStatusPanel();

		// create the zoom buttons
		JPanel zoomPanel = createZoomPanel();

		JPanel downPanel = new JPanel();
		downPanel.setLayout(new BoxLayout(downPanel, BoxLayout.X_AXIS));

		downPanel.add(statPanel);
		downPanel.add(zoomPanel);

		// sizes
		Dimension prefSize = statPanel.getPreferredSize();
		statPanel.setPreferredSize(new Dimension(prefSize.width, 22));

		prefSize = zoomPanel.getPreferredSize();
		zoomPanel.setPreferredSize(new Dimension(prefSize.width, 22));

		prefSize = downPanel.getPreferredSize();
		downPanel.setPreferredSize(new Dimension(prefSize.width, 22));

		return downPanel;
	}

	/**
	 * Creates the statusbar
	 */
	protected JPanel createStatusPanel()
	{
		JPanel statPanel = new JPanel();
		statPanel.setLayout(new FlowLayout(FlowLayout.LEFT, 0, 0));
		statPanel.setBorder(BorderFactory.createLoweredBevelBorder());

		navigationLabel  = new JLabel("Ready");
		navigationLabel.setFont(new Font("Helvetica",Font.BOLD, 10));

		statPanel.add(navigationLabel);

		return statPanel;
	}

	/**
	 * Creates the zoom panel
	 */
	protected JPanel createZoomPanel()
	{
		Font radioFont = new Font("Helvetica",Font.BOLD, 10);
		JPanel zoomPanel = new JPanel();
		zoomPanel.setLayout(new BoxLayout(zoomPanel, BoxLayout.X_AXIS));
		zoomPanel.setBorder(BorderFactory.createLoweredBevelBorder());

		ButtonGroup group = new ButtonGroup();

		zoomRadio = new JRadioButton("Zoom");
		zoomRadio.setFont(radioFont);
		zoomRadio.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e)
			{
				if (zoomRadio.isSelected())
				{
					if (curPanel != null)
						curPanel.zoomIn();
				}
			}
		});

		persRadio = new JRadioButton("Perspective");
		persRadio.setFont(radioFont);
		persRadio.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e)
			{
				if (persRadio.isSelected())
				{
					if (curPanel != null)
						curPanel.zoomOut();
				}
			}
		});


		zoomPanel.add(persRadio);
		group.add(persRadio);

		zoomPanel.add(zoomRadio);
		group.add(zoomRadio);

		persRadio.setSelected(true);
		return zoomPanel;
	}

	/**
	 * Sets status from the ID depending on the level
	 */
	private void setStatus(int statusHint)
	{
		// set zoom
		if (!curPanel.getLevel().equals(EVENTS_LEVEL))
		{
			zoomRadio.setEnabled(true);
			persRadio.setEnabled(true);

			if (curPanel.isZoomOn())
				zoomRadio.setSelected(true);
			else
				persRadio.setSelected(true);

			setSortOptions(true);
		}
		else
		{
			zoomRadio.setEnabled(false);
			persRadio.setEnabled(false);
			
			setSortOptions(false);
		}

		// set status label
		// current level
		String		curID=new String(curPanel.getID());
		String		curLevel=new String(curPanel.getLevel());

		if (statusHint == STATUS_CHANGE)
		{
			if (curLevel.equals(CATEGORY_LEVEL))
			{
				navigationLabel.setText(curTab.toString());
				setUp(false);
			}
			else
			{
				navigationLabel.setText(curLevel + "->" + curID);
				setUp(true);
			}
		}
		else if (statusHint == STATUS_DOWN)
		{
			setUp(true);

			// add currrent id
			navigationLabel.setText(curLevel + "->" + curID);
											 
		}

		else if (statusHint == STATUS_UP)
		{
			String level = curPanel.getLevel();

			if (level.equals(CATEGORY_LEVEL))
			{
				navigationLabel.setText(curTab.toString());
				setUp(false);
			}
			else
			{
				navigationLabel.setText(curLevel + "->" + curID);
			}
		}
	}


	/**
	 * Handles actions for all the menu items and the toolbar buttons
	 */
	protected void handleMenuToolBarActions(String actionStr)
	{
		if (actionStr.equals("Exit"))
		{
			handleExit();
		}
		else if (actionStr.equals("Move Up"))
		{
			Stack temp = (Stack)prevPanel.get(curTab.toString());
			int index = temp.indexOf(curPanel);

			if (index <= 0)
				return;

			temp.pop();

			OperatorPanel panel = (OperatorPanel)temp.elementAt(index-1);
			opTabbedPane.setComponentAt(opTabbedPane.getSelectedIndex(), panel);
			panel.repaint();

			if (bLookAndFeelChanged)
	   			SwingUtilities.updateComponentTreeUI(panel);

			curPanel = panel;

			// set status
			setStatus(STATUS_UP);

		}
		else if (actionStr.equals("Go Top Level"))
		{
			Stack temp = (Stack)prevPanel.get(curTab.toString());

			OperatorPanel  panel = (OperatorPanel)temp.elementAt(0);
			temp.removeAllElements();
			temp.push(panel);
			
			opTabbedPane.setComponentAt(opTabbedPane.getSelectedIndex(), panel);
			panel.repaint();

			curPanel = panel;

			// set status
			setStatus(STATUS_UP);

		}
		else if (actionStr.equals("Alert Browser"))
		{
			boolean bException = false;
			OperatorPanel panel=null;

		 	EUIDataRequest euiDataReq = new EUIDataRequest(
		 		getUser(), EVENTS_LEVEL, "All", "All", curPanel.getSysID());

			String dataRequest = euiDataReq.getDataRequestBuffer();

			/****
		 	 * Eventually will send the created request and recv. data back
		 	 * from the servlet
		 	 * For now however, use the other constructor
		 	 */
			String dataFileName = null;

			EUIDataSendRecv dataSendRecv = 
			new EUIDataSendRecv(EVENTS_LEVEL, "All", "All",curPanel.getSysID());

			dataFileName = dataSendRecv.getDataStream();

			try
			{
				panel = new OperatorPanel(
					this,
					curTab.toString(), 
					EVENTS_LEVEL,
					dataFileName);

			}
			catch (Exception e)
			{
				bException=true;
			}	

			if (!bException)
				setCurrentActiveComponent(panel);
		}
		else if (actionStr.equals("Name Sort"))
		{
			curPanel.nameSort();
		}
		else if (actionStr.equals("Severity Sort"))
		{
			curPanel.severitySort();

		}
		else if (actionStr.equals("Configure Folders"))
		{
			OperatorViewConfigDlg viewConfig = new OperatorViewConfigDlg(opFrame, this);
		}
		else if (actionStr.equals("About"))
		{
			new AboutDialog(new JFrame(), "About BlueBird");
		}

		// options
		else if (actionStr.equals("Top"))
		{
			opTabbedPane.setTabPlacement(SwingConstants.TOP);
		}
		else if (actionStr.equals("Left"))
		{
			opTabbedPane.setTabPlacement(SwingConstants.LEFT);
		}
		else if (actionStr.equals("Bottom"))
		{
			opTabbedPane.setTabPlacement(SwingConstants.BOTTOM);
		}
		else if (actionStr.equals("Right"))
		{
			opTabbedPane.setTabPlacement(SwingConstants.RIGHT);
		}

		else if (actionStr.equalsIgnoreCase("Metal"))
		{
        	setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");
		}

		else if (actionStr.equalsIgnoreCase("CDE/Motif"))
		{
			setLookAndFeel("com.sun.java.swing.plaf.motif.MotifLookAndFeel");
		}

		else if (actionStr.equalsIgnoreCase("Windows"))
		{
			setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		}
	}

	private void setLookAndFeel(String str)
	{
	    setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));

		try 
		{

        	UIManager.setLookAndFeel(str);

			if (!bLandFAtStartUp)
			{
	   			SwingUtilities.updateComponentTreeUI(opFrame);
			}

			bLookAndFeelChanged = true;

		} catch (Exception exc) 
		{
			System.err.println(
						"Cannot get to the \'" + str + "\' look and feel" );

			// try and go back to default
			try
			{
				UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
	   			SwingUtilities.updateComponentTreeUI(opFrame);
			}
			catch (Exception e)
			{
				// Don't really do anything?
			}
		}

	   	setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
	}

	private void handleExit()
	{  
		// Save User Profile
		saveUserProfile();

		//opFrame.dispose();
		System.exit(0);
	}

	/**
	 * <pre>Handles the storing of user preferences to the user profile 
	 * file. If the write into the profile file fails, the step is retried 
	 * thrice as a minimum mechanism to offset the possiblity of a different
	 * application currently writing into the profile
	 */
	protected void saveUserProfile()
	{
		// Update the userProfile Hashtable

		// position
		Integer xpos = new Integer(opFrame.getX());
		Integer ypos = new Integer(opFrame.getY());

		// dimension
		Dimension frameSize = opFrame.getSize();
		Integer width = new Integer(frameSize.width);
		Integer height = new Integer(frameSize.height);

		userProfile.put(XPOS, xpos);
		userProfile.put(YPOS, ypos);
		userProfile.put(WIDTH, width);
		userProfile.put(HEIGHT, height);

		// tab placement
		String tabPlace = "Top";
		int tabPlacement  = opTabbedPane.getTabPlacement();

		if (tabPlacement == JTabbedPane.TOP)
			tabPlace = new String("Top");
		else if (tabPlacement == JTabbedPane.LEFT)
			tabPlace = new String("Left");
		else if (tabPlacement == JTabbedPane.BOTTOM)
			tabPlace = new String("Bottom");
		else if (tabPlacement == JTabbedPane.RIGHT)
			tabPlace = new String("Right");

		userProfile.put(TAB_PLACE, tabPlace);

		// look and feel
		String landf = UIManager.getLookAndFeel().getName();
		userProfile.put(LOOKNFEEL, landf);
		
		// configured views
		Vector curConfigVector = new Vector();
		int iNumTabs=opTabbedPane.getTabCount();
		for (int iIndex=0; iIndex<iNumTabs; iIndex++)
		{
			curConfigVector.add(opTabbedPane.getTitleAt(iIndex));
		}

		userProfile.put(VIEWS, curConfigVector);
		
		boolean bNotWritten = true;
		int		iNumTries=0;

		while(bNotWritten && iNumTries < 3)
		{
			try
			{
				new EUIUserProfWriter(userProfile, userID);
				bNotWritten = false;
			}
			catch (Exception e)
			{
				bNotWritten = true;
			}
			
			if (bNotWritten)
			{
				iNumTries++;

				try
				{
					Thread.sleep(300);
				}
				catch (InterruptedException ex) { }

			}
		}
	}

	/**
	 * Reads the user preferences from the user profile file
	 */
	protected void readUserProfile()
	{
		EUIUserProfParser userProfParser=null;
		boolean	bUserProfileRead=true;

		String userxml = "data/users/" + userID + ".xml";

		// if file does not exist, just take defaults
		File userFile = new File(userxml);
		if (userFile.exists() && userFile.canRead())
		{
			// get user profile
			try
			{
				userProfParser = new EUIUserProfParser();
				userProfParser.parse(userxml);
			}
			catch (Exception e)
			{
				// if the profile has an error, just prompt and continue
	 			JOptionPane.showMessageDialog(new JFrame(), 
					e.getMessage(),
					"Error! Unable to parse user profile file", 
					JOptionPane.ERROR_MESSAGE);

				bUserProfileRead = false;
			}
		}
		else
				bUserProfileRead = false;
		
		// 
		if (bUserProfileRead)
		{
			userProfile = userProfParser.getUserProfile();
			if (userProfile == null)
				userProfile = new Hashtable(12);
		}

		else
			userProfile = new Hashtable(12);
	}

	/**
	 * Sets the (x,y) and size preferences of the user
	 */
	protected void setUserPosDimPreferences()
	{
		// set the location of the frame
		Object xPos = userProfile.get(XPOS);
		Object yPos = userProfile.get(YPOS);
		if (xPos != null && yPos != null)
		{
			opFrame.setLocation(((Integer)xPos).intValue(), 
								((Integer)yPos).intValue());
		}
		else
			opFrame.setLocation(100, 100);

		// set the size
		Object width = userProfile.get(WIDTH);
		Object height = userProfile.get(HEIGHT);
		if (width != null && height != null)
		{
			setPreferredSize(new Dimension(((Integer)width).intValue(),
										  ((Integer)height).intValue()));
		}
		else
			setPreferredSize(new Dimension(500, 400));
	}

	/**
	 * Creates the tabbed pane 
	 */
	protected JTabbedPane createTabbedPanes()
	{
		int tabPlacement = JTabbedPane.TOP;

		// get preferred tab placement
		String tabPlace = String.valueOf(userProfile.get(TAB_PLACE));
		if (tabPlace.equalsIgnoreCase("top"))
		{
			tabPlacement = JTabbedPane.TOP;
		}
		else if (tabPlace.equalsIgnoreCase("left"))
		{
			tabPlacement = JTabbedPane.LEFT;
		}
		else if (tabPlace.equalsIgnoreCase("bottom"))
		{
			tabPlacement = JTabbedPane.BOTTOM;
		}
		else if (tabPlace.equalsIgnoreCase("right"))
		{
			tabPlacement = JTabbedPane.RIGHT;
		}

		// now create
		JTabbedPane opPane = new JTabbedPane(tabPlacement);

		// get available views
		availableViewsVector = createAvailableViews();
		if (bParseException)
			return opPane;

		// get views to configure
		setUpViewsToConfigure();

		int iSize = configViewsVector.size();
		for (int iIndex=0; iIndex < iSize; iIndex++)
		{
			boolean bException=false;

			Hashtable view = (Hashtable)configViewsVector.elementAt(iIndex);

			String tabID = String.valueOf(view.get(ENAME));
			String tabTitle = String.valueOf(view.get(LABEL));
			String tabComm = String.valueOf(view.get(EDESCR));

			OperatorPanel panel=null;

		 	EUIDataRequest euiDataReq = new EUIDataRequest(
		 		getUser(), CATEGORY_LEVEL, "All", "All", tabID);

			String dataRequest = euiDataReq.getDataRequestBuffer();

			/****
		 	 * Eventually will send the created request and recv. data back
		 	 * from the servlet
		 	 * For now however, use the other constructor
		 	 */
			String dataFileName = null;

			EUIDataSendRecv dataSendRecv = 
				new EUIDataSendRecv(CATEGORY_LEVEL, "All", "All", tabID);

			dataFileName = dataSendRecv.getDataStream();

			try
			{
				panel = new OperatorPanel(
					this,
					tabTitle, 
					CATEGORY_LEVEL,
					dataFileName);
			}
			catch (Exception e)
			{
				bException=true;
			}	

			if (!bException)
			{
				opPane.addTab(tabTitle, null, panel, tabComm);

				// record in prevPanel
				Stack tempP = new Stack();
				tempP.push(panel);

				prevPanel.put(tabTitle.toString(), tempP);
			}
		}

		return opPane;
	}

	/**
	 * <pre>Creates a list of views to configure from the list of  
	 * configured views the user was using the last time he ran.
	 * The list is checked against the available views to check the view
	 * is still available to the user
	 *
	 * If the last used list is unavailable, all available views are 
	 * configured
	 */
	protected void setUpViewsToConfigure()
	{
		configViewsVector = new Vector();
	
		Vector lastConfigViews = (Vector)userProfile.get(VIEWS);

		if (lastConfigViews == null) // if user profile nonexistent
		{
			// create all available views
			for (int iIndex=0; iIndex < availableViewsVector.size(); iIndex++)
			{
				Hashtable view = (Hashtable)availableViewsVector.elementAt(iIndex);

				configViewsVector.add(view);
				availableViewsVector.remove(view);
				iIndex--;
			}
		}

		else  // build list from user profile
		{
			int iNumTabs = lastConfigViews.size();

			for (int iIndex=0; iIndex < availableViewsVector.size(); iIndex++)
			{
				Hashtable view = (Hashtable)availableViewsVector.elementAt(iIndex);

				String curIdentifier = String.valueOf(view.get(LABEL));

				for (int iTabInd=0; iTabInd < iNumTabs; iTabInd++)
				{
					String tabTitle = String.valueOf(lastConfigViews.elementAt(iTabInd));

					if (curIdentifier.equals(tabTitle))
					{
						configViewsVector.add(view);
						availableViewsVector.remove(view);
						iIndex--;
					}
				}
			}

		}
	}

	/**
	 * Creates the available view vector from the xml file
	 */
	protected Vector createAvailableViews()
	{
		EUIDataParser operatorViewsParser;

		EUIDataRequest euiDataReq = new EUIDataRequest(userID, VIEWS_LEVEL);

		String dataRequest = euiDataReq.getDataRequestBuffer();

		/****
	 	 * Eventually will send the created request and recv. data back
	 	 * from the servlet
	 	 * For now however, use the other constructor
	 	 */
		String dataFileName = null;

		EUIDataSendRecv dataSendRecv = 
		new EUIDataSendRecv(VIEWS_LEVEL, "All", "All", null);

		dataFileName = dataSendRecv.getDataStream();

		try
		{
			operatorViewsParser = new EUIDataParser();
			operatorViewsParser.parse(dataFileName);

		} catch (Exception e)
		{
	 		JOptionPane.showMessageDialog(new JFrame(), 
					e.getMessage(),
					"Error! Unable to parse input xml file", 
					JOptionPane.ERROR_MESSAGE);

			bParseException=true;
			return null;
		}

		// assuming this will have only one level
		Vector levels = operatorViewsParser.getLevelsVector();
		
		Hashtable hash = (Hashtable)levels.elementAt(0);

		return (Vector)hash.get(operatorViewsParser.ENTITIES);
	}

	public String getCurTab()
	{
		return curTab.toString();
	}

	/**
	 * Sets the currently selected tab to hold the new component - used by 
	 * the bars to set the next component
	 *
	 * Also updates the stack of components for this tab
	 */
	public void setCurrentActiveComponent(OperatorPanel newPanel)
	{
		// set new component
		int iSelIndex = opTabbedPane.getSelectedIndex();
		opTabbedPane.setComponentAt(iSelIndex, newPanel);

		// add to prev panel
		Stack tempP = (Stack)prevPanel.get(curTab.toString());
		tempP.push(newPanel);
		
		// update current
		curPanel = newPanel;

		// set status
		setStatus(STATUS_DOWN);
	}

	/**
	 * Reconfigure the tabbed panes after user changes the views he want
	 * configured
	 */
	public void configureTabbedPanes(Vector toConfigureList)
	{
		boolean bPositionNotRight=false;

		opTabbedPane.setVisible(false);

		// if 'remove all', delete all tabs
		if (toConfigureList.size() == 0)
		{
			opTabbedPane.removeAll();

			// sync up the 'available' and 'config' vectors
			int iSize = configViewsVector.size();
			for(int iIndex=0; iIndex < iSize; iIndex++)
			{
				Hashtable view = (Hashtable)configViewsVector.elementAt(iIndex);
				availableViewsVector.add(view);
			}
			configViewsVector.removeAllElements();

			opTabbedPane.setVisible(true);

			return;

		}

		// get currently configured tabs
		Vector curConList = new Vector();
		int	  iNumTabs = opTabbedPane.getTabCount();

		for(int iTabInd=0; iTabInd<iNumTabs; iTabInd++)
		{
			curConList.add(opTabbedPane.getTitleAt(iTabInd));
		}

		// remove ones that are already configured but are not required now
		int iCurConSize = curConList.size();
		int[] indexesToRemove = new int[iCurConSize];
		int iRemIndex=0;
		for(int iIndex=0; iIndex<iCurConSize; iIndex++)
		{
			// get element
			Object curConfElem = curConList.elementAt(iIndex);
			
		 	int iElem = toConfigureList.indexOf(curConfElem);
			if (iElem == -1) // currently configured but not required
			{
				indexesToRemove[iRemIndex++] = iIndex;

				// get the view and update both lists
				Hashtable view = translateConfigViewTitleToView(curConfElem);

				availableViewsVector.add(view);
				configViewsVector.remove(view);
			}
			
		}
		for(int iIndex=0; iIndex<iRemIndex; iIndex++)
		{
			// each time we remove a tab, indexes to remove shift
			opTabbedPane.removeTabAt(indexesToRemove[iIndex]-iIndex);

			curConList.removeElementAt(indexesToRemove[iIndex]-iIndex);
		}

		// for each item in the required configured list,
		// check if its already configured, if not, create it
		int iConSize = toConfigureList.size();
		for(int iIndex=0; iIndex<iConSize; iIndex++)
		{
			// get element
			Object temp = toConfigureList.elementAt(iIndex);

			// check if present in list already created
		 	int iElem = curConList.indexOf(temp);
			if (iElem != -1) // already present
			{
				if (iIndex != iElem) // if not at right position
				{
					bPositionNotRight=true;
				}
			}
			else
			{
				boolean bException=false;

				String tabTitle = String.valueOf(toConfigureList.elementAt(iIndex));
				Hashtable view = translateAvailableViewTitleToView(tabTitle);
				String tabID = String.valueOf(view.get(ENAME));
				String tabComm = String.valueOf(view.get(EDESCR));

				OperatorPanel panel = null;

		 		EUIDataRequest euiDataReq = new EUIDataRequest(
		 			getUser(), CATEGORY_LEVEL, "All", "All", tabID);

				String dataRequest = euiDataReq.getDataRequestBuffer();

				/****
		 	 	 * Eventually will send the created request and recv. data back
		 	 	 * from the servlet
		 	 	 * For now however, use the other constructor
		 	 	 */
				String dataFileName = null;

				EUIDataSendRecv dataSendRecv = new EUIDataSendRecv(
						CATEGORY_LEVEL, "All", "All", tabID);

				dataFileName = dataSendRecv.getDataStream();

				try
				{
					panel = new OperatorPanel(
								this,
								tabTitle, 
								CATEGORY_LEVEL,
								dataFileName);
				}
				catch (Exception e)
				{
					bException=true;
				}	
	
				if (!bException)
				{
					// new tab
					opTabbedPane.insertTab(tabTitle, null, panel, tabComm, iIndex);

					// record in prevPanel
					Stack tempP = new Stack();
					tempP.push(panel);

					prevPanel.put(tabTitle.toString(), tempP);

					// add to configured views and remove from available
					configViewsVector.add(view);
					availableViewsVector.remove(view);
				}
			}
		}

		// check to see of tabs are in right order
		if (bPositionNotRight)
		{
			iNumTabs = opTabbedPane.getTabCount();

			// At this point number of elements in the 'toConfigure' vector
			// is equal to the number of tabs

			for(int iIndex=0; iIndex<(iNumTabs-1); iIndex++)
			{
				// get element
				String confElem = String.valueOf(toConfigureList.elementAt(iIndex));
				
				String tabTitleAtInd = opTabbedPane.getTitleAt(iIndex);

				if (!confElem.equals(tabTitleAtInd))
				{
					for(int iTabInd=iIndex+1; iTabInd < iNumTabs; iTabInd++)
					{
						String tempTabTitle = opTabbedPane.getTitleAt(iTabInd);
						if (confElem.equals(tempTabTitle))
						{
							// swap for now
							Component indComp = opTabbedPane.getComponentAt(iIndex);
							Component tabComp = opTabbedPane.getComponentAt(iTabInd);
							
							// get view info
							Hashtable indexView = 
									translateConfigViewTitleToView(confElem);

							Hashtable tabView = 
								translateConfigViewTitleToView(tabTitleAtInd);

							// get tooltip
							String tabComm = String.valueOf(tabView.get(EDESCR));
							String indComm = String.valueOf(indexView.get(EDESCR));
							// set
							opTabbedPane.insertTab(tempTabTitle, null, 
													tabComp, tabComm, iIndex);

							opTabbedPane.insertTab(tabTitleAtInd, null, 
													indComp, indComm, iTabInd);
							

							// swap in configured views vector
							int indexViewInd = configViewsVector.indexOf(indexView);
							int tabViewInd = configViewsVector.indexOf(tabView);

							configViewsVector.setElementAt(tabView, indexViewInd);
							configViewsVector.setElementAt(indexView, tabViewInd);

							break;
						}
					}
				}
			}
		}

		opTabbedPane.setVisible(true);

		if (opTabbedPane.getTabCount() > 0)
		{
			opTabbedPane.setSelectedIndex(0);

			curTab.replace(0, curTab.length(), opTabbedPane.getTitleAt(0));
			curPanel = (OperatorPanel)opTabbedPane.getComponentAt(0);

			setStatus(STATUS_CHANGE);
		}
	}

	/**
	 * Enable/Disable the 'move up' and 'Go top' options
	 */
	protected void setUp(boolean b)
	{
		// toolbar
		upButton.setEnabled(b);
		topLevelButton.setEnabled(b);

		// menu
		upMenuItem.setEnabled(b);
		topLevelMenuItem.setEnabled(b);

	}

	/**
	 * Enable/Disable the sort options
	 */
	protected void setSortOptions(boolean b)
	{
		// toolbar
		nameSortButton.setEnabled(b);
		severityButton.setEnabled(b);

		// menu
		nameSortMenuItem.setEnabled(b);
		severityMenuItem.setEnabled(b);

	}

	/**
	 * Enable/Disable all options
	 */
	protected void setAllOptions(boolean b)
	{
		// toolbar
		upButton.setEnabled(b);
		topLevelButton.setEnabled(b);
		alertButton.setEnabled(b);
		nameSortButton.setEnabled(b);
		severityButton.setEnabled(b);

		// menu
		upMenuItem.setEnabled(b);
		topLevelMenuItem.setEnabled(b);
		alertMenuItem.setEnabled(b);
		nameSortMenuItem.setEnabled(b);
		severityMenuItem.setEnabled(b);

	}


	public Hashtable translateAvailableViewTitleToView(Object title)
	{
		return translateViewTitleToView(availableViewsVector, title);
	}

	public Hashtable translateConfigViewTitleToView(Object title)
	{
		return translateViewTitleToView(configViewsVector, title);
	}

	protected Hashtable translateViewTitleToView(Vector views, Object title)
	{
		int iSize = views.size();

		for (int iIndex=0; iIndex<iSize; iIndex++)
		{
			Hashtable view = (Hashtable)views.elementAt(iIndex);

			Object viewTitle = view.get(LABEL);

			if (title.toString().equals(viewTitle.toString()))
			{
				return view;
			}
		}

		return null;
	}

	protected Vector getAvailableViews()
	{
		return availableViewsVector;
	}

	protected Vector getConfiguredViews()
	{
		return configViewsVector;
	}

	protected Hashtable getUserProfile()
	{
		return userProfile;
	}

	public String getUser()
	{
		return userID;
	}
}

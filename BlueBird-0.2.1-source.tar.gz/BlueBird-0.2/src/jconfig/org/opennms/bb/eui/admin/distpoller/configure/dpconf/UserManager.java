//-------------------------------------------------------------------------------------------
//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

//--------------------------------------------------------------------------------------------

package org.opennms.bb.eui.admin.distpoller.configure.dpconf;

import java.util.*;

public class UserManager
{
	
	public static final int VIEW	= 0;
	public static final int PP	= 1;
	public static final int DP	= 2;
	public static final int OCAL 	= 3;
	public static final int RCAL 	= 4;
	
	public static Vector m_ICOLS = new Vector();
	public static Vector m_ECOLS = new Vector();
	public static Vector m_SCOLS = new Vector();
	public static Vector m_UCOLS = new Vector();
	public static Vector m_DCOLS = new Vector();


	public static Hashtable	m_oViews	= new Hashtable();
	public static Hashtable	m_oPP		= new Hashtable();
	public static Hashtable	m_oDP		= new Hashtable();
	public static Hashtable	m_oDPP		= new Hashtable();
	public static Hashtable	m_oOCAL		= new Hashtable();
	public static Hashtable	m_oRCAL		= new Hashtable();
	public static Hashtable m_oRangeTable	= new Hashtable();
	public static Hashtable m_oServiceTable	= new Hashtable();
	public static Hashtable m_oFilterTable	= new Hashtable();
	public static Hashtable m_oCalendarsTable	= new Hashtable();



	public static String		m_sOldId	= "";
	public static String		m_sNewId	= "";
	public static String		m_sBuffer	= "";
	public static String		m_sEditBuffer= null;
	public static int			m_iEditWhat	= -1; // Should be one of USER/GROUP/VIEW
	public static String 		m_CalendarType = "";
	public static String		m_textRule 	= "";

	
	
	/**
	* Save user/group/views info' to file:
	*/
	public static boolean save()
	{
		return true;
	}

	/**
	* Initiate "add" sequence:
	*/
	public static boolean add(int what, String id)
	{
		if(what <0 || what >4)
		{
			return false;
		}
		if(exists(what, id))
		{
			return false;
		}
		else
		{
			m_iEditWhat	= what;
			m_sOldId	= id;
			m_sNewId	= id;
		}
		return true;
	}

	/**
	* Delete rightaway:
	*/
	public static void delete(int what, String id)
	{
		if(what <0 || what >4)
		{
			return;
		}
		switch(what)
		{
		
			case VIEW:
				m_oViews.remove(id);
				break;
			case DP :
				m_oDP.remove(id);
				break;
			case PP :
				m_oPP.remove(id);
				break;
			case OCAL :
				m_oOCAL.remove(id);
				break;
			case RCAL :
				m_oRCAL.remove(id);
				break;
			default:
				break;
		}
		m_sOldId	= "";
		m_sNewId	= "";
		m_sBuffer	= "";
		m_iEditWhat	= -1;
		return;
	}

	/**
	* Initiate "modify" sequence:
	*/
	public static boolean modify(int what, String id)
	{
		if(what <0 || what >4)
		{
			return false;
		}
		else
		{
			m_iEditWhat	= what;
			m_sOldId	= id;
			m_sNewId	= id;
		}
		return true;
	}

	/**
	* Commit the current sequence of modifications:
	*/
	public static void ok()
	{
		if(m_iEditWhat <0 || m_iEditWhat >4)
		{
			return;
		}
		switch(m_iEditWhat)
		{
		
			case VIEW:
				if(m_oViews.containsKey(m_sOldId))
				{
					m_oViews.remove(m_sOldId);
				}
				m_oViews.put(m_sNewId, m_sBuffer);
				break;

			case PP:
				if(m_oPP.containsKey(m_sOldId))
				{
					m_oPP.remove(m_sOldId);
				}
				m_oPP.put(m_sNewId, m_sBuffer);
				break;

			case DP:
				if(m_oDP.containsKey(m_sOldId))
				{
					m_oDP.remove(m_sOldId);
				}
				m_oDP.put(m_sNewId, m_sBuffer);
				break;
			
			case OCAL:
				if(m_oOCAL.containsKey(m_sOldId))
				{
					m_oOCAL.remove(m_sOldId);
				}
				m_oOCAL.put(m_sNewId, m_sBuffer);
				break;

			case RCAL:
				if(m_oRCAL.containsKey(m_sOldId))
				{
					m_oRCAL.remove(m_sOldId);
				}
				m_oRCAL.put(m_sNewId, m_sBuffer);
				break;

			default:
				break;
		}
		m_sBuffer	= "";
		m_iEditWhat	= -1;
		return;
	}

	/**
	* Abort the current sequence of modifications:
	*/
	public static void cancel()
	{
		m_sBuffer	= "";
		m_iEditWhat	= -1;
		m_sNewId	= "";
		return;
	}

	/**
	* Check if this id is already in known id list:
	*/
	public static boolean exists(int what, String id)
	{
		if(what <0 || what >4)
		{
			return false;
		}
		switch(what)
		{
		
			case VIEW:
				return m_oViews.containsKey(id);
			case DP:		
				return m_oDP.containsKey(id);
			case PP:
				return m_oPP.containsKey(id);
			case OCAL:
				return m_oOCAL.containsKey(id);
			case RCAL:
				return m_oRCAL.containsKey(id);
			default:
				break;
		}
		return false;
	}

}

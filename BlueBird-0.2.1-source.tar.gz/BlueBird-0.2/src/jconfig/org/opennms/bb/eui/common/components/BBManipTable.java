// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
// Modification History:
// Oct 2000 - Changed the 'installKeyboardActions()' method of the
//            BBManipTableUI class  to account for the change to the
//            infrastructure for creating keyboard bindings in JDK 1.3 - Sowmya
//
//

package org.opennms.bb.eui.common.components;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.table.*;
import javax.swing.text.*;
import javax.swing.event.*;

import javax.swing.plaf.basic.BasicTableUI;
import javax.swing.plaf.ActionMapUIResource;

import java.util.Vector;

/**
 * BBManipTable extends the JTable and visually indicates the row selected
 * It allows the user to change the values in all the text columns 
 *
 * @author Sowmya
 *
 */
public class BBManipTable extends JTable
{
	protected BBManipTableModel infoTableModel;

	final static int TABLE_WIDTH   = 450;
	final static int TABLE_HEIGHT  = 300;

	public int iLastEditingRow  = -1;
	public int iLastEditingCol  = -1;

	/**
	 * Creates the table - the input data is added with values
	 * for the first arrow column
	 */
	protected void createTable(Vector inpRowData, Vector inpColNames)
	{
		//create the extra first column
		int iNumRows = inpRowData.size();
		int iNumCols = inpColNames.size();

		Vector rowData = new Vector(iNumRows);

		for (int iIndex=0; iIndex<iNumRows; iIndex++)
		{
			Vector rowVal = new Vector(iNumCols+1);
			
			rowVal.addElement(Boolean.FALSE);

			int iSize = inpColNames.size();
			for (int iColIndex=0; iColIndex < iSize; iColIndex++)
			{
				Vector temp = (Vector)inpRowData.elementAt(iIndex);
				rowVal.addElement(temp.elementAt(iColIndex));
			}

			rowData.addElement(rowVal);
		}

		Vector colNames = new Vector(iNumCols + 1);
		colNames.addElement(" ");

		for (int iIndex=0; iIndex < iNumCols; iIndex++)
		{
			colNames.addElement(inpColNames.elementAt(iIndex));
		}

		infoTableModel = new BBManipTableModel(rowData, colNames);
		setModel(infoTableModel);

	}

	/**
	 * Initialize the table features as wanted
	 */
	protected void BBManipTableInit()
	{
		setUI(new BBManipTableUI());

		// set single selection
		setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

		setCellSelectionEnabled(true);

		// Do not allow reordering of columns
		getTableHeader().setReorderingAllowed(false);

		// Set selection colors
		setSelectionForeground(Color.black);
		setSelectionBackground(Color.white);

		// Do not show grid
		setShowHorizontalLines(true);
		setShowVerticalLines(false);

		// Attach a textfield cell editor to the 'Value' columns
		int iNumCols = getColumnCount();

		for (int iIndex=1; iIndex < iNumCols; iIndex++)
		{
			BBTextField colText = new BBTextField();
			getColumnModel().getColumn(iIndex).setCellEditor(new BBColumnEditor(colText));
		}

		// Attach a cell renderer for the first(arrow) column
		getColumnModel().getColumn(0).setCellRenderer(new BBArrowRenderer());

		// Track the list selection to set focus to the editor component
		getSelectionModel().addListSelectionListener(new ListSelectionListener()
		{
			public void valueChanged(ListSelectionEvent e)
			{
				int iSelectedRow = getSelectedRow();
				int iSelectedCol = getSelectedColumn();
				int iRowCount	= getRowCount();

				for (int iIndex=0; iIndex < iRowCount; iIndex++)
				{
					setValueAt(new Boolean(iIndex == iSelectedRow), iIndex, 0);
				}
				repaint();


				ListSelectionModel lsm = (ListSelectionModel)e.getSource();

				if(!(lsm.isSelectionEmpty()))
				{
					if (iSelectedCol > 0)
					{
						editCellAt(iSelectedRow, iSelectedCol);
						getEditorComponent().requestFocus();
					}
				}
				else // selection empty
				{
					for (int iIndex=0; iIndex < iRowCount; iIndex++)
					{
						setValueAt(Boolean.FALSE, iIndex, 0);
					}

					iLastEditingRow = -1;
					iLastEditingCol = -1;

					repaint();
				}
			}
		});

		getColumnModel().addColumnModelListener(new TableColumnModelListener()
		{
			public void columnSelectionChanged(ListSelectionEvent e)
			{
				ListSelectionModel lsm = (ListSelectionModel)e.getSource();

				if(!(lsm.isSelectionEmpty()))
				{
					int iSelectedRow = getSelectedRow();
					int iSelectedCol = getSelectedColumn();

					if (iSelectedCol > 0 && iSelectedRow > -1)
					{
						editCellAt(iSelectedRow, iSelectedCol);
						getEditorComponent().requestFocus();
					}
				}
			}

			public void columnAdded(TableColumnModelEvent e) { }

			public void columnMoved(TableColumnModelEvent e) { }

			public void columnRemoved(TableColumnModelEvent e) { }

			public void columnMarginChanged(ChangeEvent e) { }

		});

		setTableColumnWidths();
	}


	/**
	 * Creates the table with just the columns(and no rows) - the input
	 * data is added with values for the first arrow column
	 *
	 */
	public BBManipTable(Vector inpColNames)
	{
		int iNumCols = inpColNames.size();

		Vector colNames = new Vector(iNumCols + 1);
		colNames.addElement(" ");

		for (int iIndex=0; iIndex < iNumCols; iIndex++)
		{
			colNames.addElement(inpColNames.elementAt(iIndex));
		}

		infoTableModel = new BBManipTableModel(colNames);
		setModel(infoTableModel);

		BBManipTableInit();
	}

	/**
	 * Creates the table
	 */
	public BBManipTable(Vector inpRowData, Vector inpColNames)
	{
		createTable(inpRowData, inpColNames);
		BBManipTableInit();
	}

	/**
 	 * Updates UI to set it back to BBManipTableUI
 	 */
	public void updateUI()
	{
		setUI(new BBManipTableUI());
	}

	/**
	 * Clear all selections in the table
	 */
	public void clearSelection()
	{
		super.clearSelection();
		repaint();
	}

	/**
	 * Sets the column widths of the columns in the table to the 
	 * the viewport width / number of columns or length of the column name 
	 * whichever is greater
	 *
	 * <p>Also sets the table scrollpane viewport accordingly
	 */
	public void setTableColumnWidths()
	{
		setTableColumnWidths(getPreferredScrollableViewportSize().width, TABLE_HEIGHT);
	}


	/**
	 * Sets the column widths of the columns in the table to the 
	 * the passed width / number of columns or length of the column name 
	 * whichever is greater
	 *
	 * <p>Also sets the table scrollpane viewport accordingly
	 */
	public void setTableColumnWidths(int iWidth, int iHeight)
	{
		TableColumn column=null;

		int		iNumCols 	= getColumnCount();
		int		DEF_WIDTH	= iWidth/iNumCols-1;
		int		iTableWidth 	= 0;

		int		iIntercellWidth = (int) getIntercellSpacing().getWidth();

		// arrow column
		column = getColumnModel().getColumn(0);
		column.setPreferredWidth(20);
		column.setMinWidth(20);
		column.setMaxWidth(20);

		iTableWidth += 20;

		for(int iIndex=1; iIndex < iNumCols; iIndex++)
		{
			column = getColumnModel().getColumn(iIndex);

			TableCellRenderer hdrRenderer = column.getHeaderRenderer();
			if(hdrRenderer == null)
			{
				hdrRenderer = new BBDefaultTableHeaderRenderer();
				column.setHeaderRenderer(hdrRenderer);
				
				setHeaderToolTips();
			}

			Component comp = hdrRenderer.getTableCellRendererComponent( this, column.getHeaderValue(), false, false, 0, 0);

			int headerWidth = comp.getPreferredSize().width;

			if (headerWidth < DEF_WIDTH)
				headerWidth = DEF_WIDTH;

			column.setPreferredWidth(headerWidth);
			column.setMinWidth(headerWidth);

			iTableWidth += headerWidth;
		}

		iTableWidth += ((iNumCols+2) * iIntercellWidth);

		if (iTableWidth > 600)
			iTableWidth = 600;

		setPreferredScrollableViewportSize(new Dimension(iTableWidth, iHeight));
	}

	/**
	 * Does nothing - sub-classes will need  to override this method to
	 * set tooltips if desired
	 */
	protected void setHeaderToolTips()
	{
	}

	/**
	 * Selects the first column of the first row
	 */
	public boolean setInitialFocus()
	{
		if (getRowCount() <= 0)
			return false;

		selectCellAt(0, 1);
		return true;
	}

	/**
 	 * Selects the cell (row, col)
 	 */
	public void selectCellAt(int row, int col)
	{
		setRowSelectionInterval(row, row);
		setColumnSelectionInterval(col, col);
		
		if (row != iLastEditingRow) 
		{
			iLastEditingRow = row;
			iLastEditingCol = col;
		}
	}

	/** 
	 * Adds the vector as the last row of the table
	 */
	public void addRow(Vector data)
	{
		pasteRow(data);
	}

	/** 
	 * Inserts the vector next to the currently selected row
	 */
	public void pasteRow(Vector data)
	{
		int iRowLoc;

		int iCurSelectedRow = getSelectedRow();
		if (iCurSelectedRow <= -1)
			iRowLoc = getRowCount();
		else
			iRowLoc = iCurSelectedRow + 1;

		Vector newData = new Vector(data);

		// arrow
		newData.add(0, Boolean.FALSE);

		// Insert
		infoTableModel.insertRow(iRowLoc, newData);

		// Select new row/first column
		selectCellAt(iRowLoc, 1);
	}

	/**
	 * Removes the row# iRow
	 */
	public void removeRow(int iRow)
	{
		int iSelRow;
		int iNumRows = getRowCount();

		// set row to be selected next
		if (iRow == (iNumRows-1)) // last row
			iSelRow = iRow - 1;
		else
			iSelRow = iRow;

		// Remove
		infoTableModel.removeRow(iRow);

		// Select next row/first column
		selectCellAt(iSelRow, 1);
	}


	/**
	 *
	 */
	protected void processKeyEvent(KeyEvent e)
	{
		final int	MOVE_UP = 1;
		final int	MOVE_DOWN = -1;

		int		iInternalCode=0;
		int		code = e.getKeyCode();

		if (code == KeyEvent.VK_TAB )
		{
			String mode = e.getKeyModifiersText(e.getModifiers());

			if(mode.equals("Shift"))
				shiftTabToNextCell();

			else
				tabToNextCell();
		}
		else
			super.processKeyEvent(e);

	}

	/** 
	 * tab to the next cell
	 */
	private void tabToNextCell()
	{
		if (iLastEditingRow < 0) // Ignore the header
		{
			if (getRowCount() <= 0 || getColumnCount() <= 0)
				return;

			iLastEditingRow = 0;
			iLastEditingCol = 1;

			selectCellAt(iLastEditingRow, iLastEditingCol);
			return;
		}

		if (iLastEditingCol < getColumnCount()-1)
		{
			iLastEditingCol++;

			selectCellAt(iLastEditingRow, iLastEditingCol);
		}
		else //last column
		{
			if (iLastEditingRow < getRowCount()-1)
			{
				iLastEditingRow++;
				iLastEditingCol = 1;

				selectCellAt(iLastEditingRow, iLastEditingCol);
			}
			else  //last column and last row
			{
				iLastEditingRow = 0;
				iLastEditingCol = 1;

				selectCellAt(iLastEditingRow, iLastEditingCol);
			}
		}
	}

	/**
	 * shift+tab to the previous cell
	 */
	private void shiftTabToNextCell()
	{

		if (iLastEditingCol > 1)
		{
			iLastEditingCol--;
			selectCellAt(iLastEditingRow, iLastEditingCol);
		}
		else //first value column
		{
			if (iLastEditingRow > 0)
			{
				iLastEditingRow--;
				iLastEditingCol = 1;

				selectCellAt(iLastEditingRow, iLastEditingCol);
			}
			else
			{
				clearSelection();

				iLastEditingRow = -1;
				iLastEditingCol = -1;
			}
		}
	}

	/**
	 * Returns the attached table model
	 */
	public BBManipTableModel getTableModel()
	{
		return infoTableModel;
	}

	/**
 	 * <pre>Returns the column names 
	 * Note: The actual table data has an extra column for the 
	 *	   arrow. This is not returned in the result
	 * </pre>
 	 */
	public Vector getColumns()
	{
		Vector outCols = new Vector();

		int iColCount = getColumnCount();

		for (int iIndex=1; iIndex<iColCount; iIndex++)
		{
			outCols.add(getColumnName(iIndex));
		}

		return outCols;
	}

	/**
 	 * <pre>Returns the data
	 * Note: The actual table data has an extra column for the 
	 *	   arrow. This is not returned in the result
	 * </pre>
 	 */
	public Vector getData()
	{
		Vector actualData = getTableModel().getDataVector();

		Vector outData = new Vector();

		int iRowCount = getRowCount();
		int iColCount = getColumnCount();

		for (int iIndex=0; iIndex<iRowCount; iIndex++)
		{
			Vector temp = new Vector();

			Vector actualTemp = (Vector)actualData.elementAt(iIndex);

			for (int iColIndex=1; iColIndex < iColCount; iColIndex++)
			{
				temp.add(actualTemp.elementAt(iColIndex));
			}

			outData.add(temp);
		}
		
		return outData;
	}

	public boolean validateValues(String panelName)
	{
		return true;
	}
}


/**
 * The BBManipTableUI extends the BasicTableUI to handle up/down/escape
 * key actions and the mouse actions so as to dictate move between cells and
 * also validate the cell values on move from a cell 
 */
class BBManipTableUI extends BasicTableUI
{
	private class BBManipKeyAction extends AbstractAction
	{
		protected BBManipKeyAction(String name)
		{
			super(name);
		}

		public void actionPerformed(ActionEvent e)
		{
			BBManipTable infoTable = (BBManipTable)e.getSource();
			String command	= (String)getValue(Action.NAME);

			boolean bPerformAction = false;

			if (command.equals("Escape"))
			{
				final CellEditor editor = infoTable.getCellEditor(); 

				if (editor != null && editor instanceof BBColumnEditor)
				{
					((BBColumnEditor)editor).bEditingCancelled=true;
					editor.cancelCellEditing();
				}
				
				return;
			}

			else
			{
				boolean bPrevCellOK=false;

		   		CellEditor editor = infoTable.getCellEditor();
				Component editorComp=null;

		   		if (editor != null && editor instanceof BBColumnEditor)
				{
					editorComp = ((BBColumnEditor)editor).getComponent();

					if (editorComp instanceof BBTextField)
					{
						if (!((BBTextField)editorComp).isValid())
							infoTable.requestFocus();
						else
							bPrevCellOK = true;
					}
					else
						bPrevCellOK = true; // if not textfield, don't bother
				}

				if ((infoTable.iLastEditingRow != -1) && (infoTable.iLastEditingCol != -1)) 
				{
					if (bPrevCellOK  || editorComp == null)
					{
						bPerformAction = true;
					}
				}

				else if (infoTable.iLastEditingRow == -1 || infoTable.iLastEditingCol == -1) 
				{
					if (infoTable.getRowCount() <= 0 || infoTable.getColumnCount() <= 0)
						return;

					bPerformAction = true;
				}
			
			}

			// If previous cell not ok, do not perform action
			if (!bPerformAction)
				return;
			
			if (command.equals("NextRow"))
			{
				if (infoTable.iLastEditingRow < infoTable.getRowCount()-1)
				{
					infoTable.iLastEditingRow++;
					infoTable.iLastEditingCol = 1;
					infoTable.selectCellAt(infoTable.iLastEditingRow, 1);
				}
	
			}
			else if (command.equals("PrevRow"))
			{
				if (infoTable.iLastEditingRow > 0)
				{
					infoTable.iLastEditingRow--;
					infoTable.iLastEditingCol = 1;
					infoTable.selectCellAt(infoTable.iLastEditingRow, 1);
				}
			}
	
			else if (command.equals("NextCol"))
			{
				if (infoTable.iLastEditingCol < infoTable.getColumnCount()-1)
				{
					infoTable.iLastEditingCol++;
					infoTable.selectCellAt(infoTable.iLastEditingRow, infoTable.iLastEditingCol);

				}
			}
	
			else if (command.equals("PrevCol"))
			{
				if (infoTable.iLastEditingCol > 1)
				{
					infoTable.iLastEditingCol--;
					infoTable.selectCellAt(infoTable.iLastEditingRow, infoTable.iLastEditingCol);

				}
			}

			else if (command.equals("PageUp"))
			{
				Dimension delta = infoTable.getParent().getSize(); 

				ListSelectionModel rsm = infoTable.getSelectionModel();

				int start = rsm.getAnchorSelectionIndex(); 
				Rectangle r = infoTable.getCellRect(start, 0, true); 
				r.y +=  -delta.height; 
				int newRow = infoTable.rowAtPoint(r.getLocation()); 
				if(newRow == -1 )
				{
					if (infoTable.getRowCount() > 0)
					{
						newRow = 0;
					}
					else
						return;
				}

				infoTable.iLastEditingRow = newRow;
				infoTable.iLastEditingCol = 1;
				infoTable.selectCellAt(infoTable.iLastEditingRow, infoTable.iLastEditingCol);

			}

			else if (command.equals("PageDown"))
			{
				Dimension delta = infoTable.getParent().getSize(); 

				ListSelectionModel rsm = infoTable.getSelectionModel();

				int start = rsm.getAnchorSelectionIndex(); 
				Rectangle r = infoTable.getCellRect(start, 0, true); 
				r.y += delta.height; 
				int newRow = infoTable.rowAtPoint(r.getLocation()); 
				if (newRow == -1 )
				{
					if (infoTable.getRowCount() > 0)
					{ 
						newRow = infoTable.getRowCount() - 1; 
					}
					else
						return;
				}

				infoTable.iLastEditingRow = newRow;
				infoTable.iLastEditingCol = 1;
				infoTable.selectCellAt(infoTable.iLastEditingRow, infoTable.iLastEditingCol);

			}

		}
	}

	protected void installKeyboardActions()
	{
		ActionMap map = getActionMap();

		SwingUtilities.replaceUIActionMap(table, map);
		InputMap inputMap = getInputMap(JComponent.
				  WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
		SwingUtilities.replaceUIInputMap(table, JComponent.
					   WHEN_ANCESTOR_OF_FOCUSED_COMPONENT,
					   inputMap);
	}

	private InputMap getInputMap(int condition)
	{
		if (condition == JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT)
		{
			return (InputMap)UIManager.get("Table.ancestorInputMap");
		}
		return null;
	}

	private ActionMap getActionMap()
	{
		ActionMap map = (ActionMap)UIManager.get("Table.actionMap");

		map = changeActionMap(map);

		return map;
	}

	private ActionMap changeActionMap(ActionMap map)
	{
		if (map == null)
			map = new ActionMapUIResource();

		map.put("selectNextColumn", new BBManipKeyAction("NextCol"));
		map.put("selectPreviousColumn", new BBManipKeyAction("PrevCol"));
		map.put("selectNextRow", new BBManipKeyAction("NextRow"));
		map.put("selectPreviousRow", new BBManipKeyAction("PrevRow"));
		map.put("cancel", new BBManipKeyAction("Escape"));

		map.put("scrollUpChangeSelection", new BBManipKeyAction("PageUp"));
		map.put("scrollDownChangeSelection", new BBManipKeyAction("PageDown"));


		return map;
	}

	protected MouseInputListener createMouseInputListener()
	{
		return new BBMMouseInputHandler();
	}

	private class BBMMouseInputHandler implements MouseInputListener 
	{
		public void mouseClicked(MouseEvent e) {}

		public void mousePressed(MouseEvent e) 
		{
			if (!SwingUtilities.isLeftMouseButton(e)) 
			{
				return;
			}

			BBManipTable table = (BBManipTable)e.getSource();

			Point p = e.getPoint();
			int row = table.rowAtPoint(p);
			int column = table.columnAtPoint(p);
			boolean bPrevCellOK=false;

	   		CellEditor editor = table.getCellEditor();
			Component editorComp=null;

	   		if (editor != null && editor instanceof BBColumnEditor)
			{
				editorComp = ((BBColumnEditor)editor).getComponent();

				if (editorComp instanceof BBTextField)
				{
					if (!((BBTextField)editorComp).isValid())
						table.requestFocus();
					else
						bPrevCellOK = true;
				}
				else
					bPrevCellOK = true; // if not textfield, don't bother
			}

			if ((column != -1) && (row != -1)) 
			{
				if (bPrevCellOK  || editorComp == null)
				{
					table.iLastEditingRow = row;
					table.iLastEditingCol = column;

					table.selectCellAt(table.iLastEditingRow, table.iLastEditingCol);
				}
			}
			else if (column == -1 || row == -1) 
			{
				if (table.getRowCount() <= 0 || table.getColumnCount() <= 0)
					return;

				table.iLastEditingRow = 0;
				table.iLastEditingCol = 1;

				table.selectCellAt(table.iLastEditingRow, table.iLastEditingCol);
			}
			
			e.consume();
		}

		public void mouseReleased(MouseEvent e) { }

		public void mouseEntered(MouseEvent e) {}

		public void mouseExited(MouseEvent e) {}

		public void mouseMoved(MouseEvent e) {}

		public void mouseDragged(MouseEvent e) {}

	}
}

//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.operator.panels;

import javax.swing.*;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeEvent;
import java.awt.event.*;

/**
 * OperatorInterface is the realtime console
 *
 * @author Sowmya
 *
 */

public class OperatorInterface extends JFrame
{
	String					userID;

	public OperatorInterface(String inpUserID)
	{
		super("BlueBird Operator Interface");
		userID = inpUserID;

		final OperatorInterfacePanel  operatorPanel = 
						new OperatorInterfacePanel(this, userID);
		getContentPane().add(operatorPanel);

		// listen for close
		addWindowListener(new WindowAdapter()
		{
			public void windowOpened(WindowEvent e)
			{
				operatorPanel.handleWindowOpen();
			}

			public void windowClosing(WindowEvent e)
			{
				operatorPanel.handleWindowClose();
			}
		});

		pack();
		setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);

	}

}

//-------------------------------------------------------------------------------------------
//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

//--------------------------------------------------------------------------------------------

package org.opennms.bb.eui.admin.distpoller.configure.dpconf;
import org.opennms.bb.eui.admin.distpoller.configure.fbuilder.*;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class ModifyFilter extends JDialog
{
	private boolean	m_bNew			= 	false;

	private String sOldId 			=	 new String("");

	String oDescLabel			= 	"Filter Description";
	String oRuleLabel			= 	"Filter Rule";

	JTextField	m_oFilterRuleInput	= 	new JTextField(40);
	JTextArea	m_oFilterDescInput	= 	new JTextArea();

	JButton		m_oOkButton		= 	new JButton("  Ok  ");
	JButton		m_oRuleBuilderButton	= 	new JButton("Rule Builder..");
	JButton		m_oCancelButton		= 	new JButton("Cancel");
	String viewName = new String();


	public ModifyFilter(JFrame parent, boolean modal, String viewName)
	{
		super(parent, modal);
		this.viewName = viewName;

		setBackground(java.awt.Color.lightGray);
		setForeground(java.awt.Color.black);
		setSize(550,300);
		setTitle(viewName);
		//setVisible(false);
		setLocationRelativeTo(parent);

		//Lay out the buttons from left to right.
		JPanel buttonPane1 = new JPanel();
		buttonPane1.setLayout(new BoxLayout(buttonPane1, BoxLayout.X_AXIS));
		buttonPane1.setBorder(BorderFactory.createEmptyBorder(0, 10, 10, 10));
		buttonPane1.add(m_oFilterRuleInput);
		buttonPane1.add(Box.createRigidArea(new Dimension(10, 0)));
		buttonPane1.add(m_oRuleBuilderButton);
		

		//Lay out the buttons from left to right.
		JPanel buttonPane = new JPanel();
		buttonPane.setLayout(new BoxLayout(buttonPane, BoxLayout.X_AXIS));
		buttonPane.setBorder(BorderFactory.createEmptyBorder(0, 10, 10, 10));
		buttonPane.add(Box.createHorizontalGlue());
		buttonPane.add(m_oOkButton);
		buttonPane.add(Box.createRigidArea(new Dimension(10, 0)));
		buttonPane.add(m_oCancelButton);
		buttonPane.add(Box.createHorizontalGlue());

		JScrollPane textScroller = new JScrollPane(m_oFilterDescInput);
		textScroller.setPreferredSize(new Dimension(250, 80));
		textScroller.setMinimumSize(new Dimension(250, 80));
		textScroller.setAlignmentX(LEFT_ALIGNMENT);
		
		JPanel textPane = new JPanel();
		textPane.setLayout(new BoxLayout(textPane, BoxLayout.Y_AXIS));
		JLabel label = new JLabel(oDescLabel);
		textPane.add(label);
		textPane.add(Box.createRigidArea(new Dimension(0,5)));
		textPane.add(textScroller);
		textPane.add(Box.createRigidArea(new Dimension(0,5)));
		textPane.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
		JLabel label1 = new JLabel(oRuleLabel);
		textPane.add(label1);
				

		if(!m_bNew)
		{
			String sBuffer = (String)UserManager.m_oViews.get(viewName);
			if(sBuffer != null)
			{
				StringTokenizer oTokenizer = new StringTokenizer(sBuffer,":");

				String sTok = "";
				try
				{
					sTok = oTokenizer.nextToken();
				} catch(NoSuchElementException  e) { sTok = ""; }
				m_oFilterDescInput.setText(sTok);

				try
				{
					sTok = oTokenizer.nextToken();
				} catch(NoSuchElementException  e) { sTok = ""; }
				m_oFilterRuleInput.setText(sTok);
			}
		}

		JPanel mainPane = new JPanel(new BorderLayout());
		mainPane.add(textPane, BorderLayout.NORTH);
		mainPane.add(buttonPane1, BorderLayout.SOUTH);

		sOldId = viewName;

		//Put everything together, using the content pane's BorderLayout.
		getContentPane().add(mainPane, BorderLayout.NORTH);
		getContentPane().add(buttonPane, BorderLayout.SOUTH);
		
		
		SymWindow oSymWindow = new SymWindow();
		this.addWindowListener(oSymWindow);
		SymAction oSymAction = new SymAction();
		m_oOkButton.addActionListener(oSymAction);
		m_oRuleBuilderButton.addActionListener(oSymAction);
		m_oCancelButton.addActionListener(oSymAction);

		m_oFilterDescInput.addMouseListener(new java.awt.event.MouseAdapter()
									  {
										public void mousePressed(java.awt.event.MouseEvent e)
										{
											m_oFilterDescInput.setBackground(java.awt.Color.white);
										}
										public void mouseClicked(java.awt.event.MouseEvent e)
										{
											m_oFilterDescInput.setBackground(java.awt.Color.white);
										}
									  }
									 );
		m_oFilterDescInput.addKeyListener(new java.awt.event.KeyAdapter()
									  {
										public void keyTyped(java.awt.event.KeyEvent e)
										{
											m_oFilterDescInput.setBackground(java.awt.Color.white);
										}
										public void keyPressed(java.awt.event.KeyEvent e)
										{
											m_oFilterDescInput.setBackground(java.awt.Color.white);
										}
									  }
									 );
		
	}
	public ModifyFilter(JFrame parent, String title, boolean modal, String viewName)
	{
		this(parent, modal, viewName);
		setTitle(title);
	}
	public ModifyFilter(JFrame parent, String title, boolean modal, String viewName, boolean isNew)
	{
		this(parent, title, modal, viewName);
		m_bNew = isNew;
	}

	class SymAction implements java.awt.event.ActionListener
	{
		public void actionPerformed(java.awt.event.ActionEvent event)
		{
			Object object = event.getSource();
			if(object == m_oOkButton)
			{

				String ruleID = m_oFilterRuleInput.getText();
				if ( (ruleID == null) || ruleID.trim().equals("") )
					m_oFilterRuleInput.setText("Type your rule here:");

				String sId = m_oFilterDescInput.getText();
				if( (sId == null) || sId.trim().equals("") )
				{
					Toolkit.getDefaultToolkit().beep();
				    	m_oFilterDescInput.setBackground(java.awt.Color.red);
					return;
				}
				try
				{
					if(m_bNew)
					{
						if(UserManager.m_oViews.containsKey(sId))
						{
							Toolkit.getDefaultToolkit().beep();
						    m_oFilterDescInput.setBackground(java.awt.Color.red);
							return;
						}
						UserManager.add(UserManager.VIEW, viewName);
						UserManager.m_sBuffer = m_oFilterDescInput.getText();
						UserManager.m_sBuffer+= ":" + m_oFilterRuleInput.getText();
						//UserManager.m_sBuffer+= ":";
						UserManager.ok();
					}
					else
					{
						if((!sOldId.equals(sId)) && UserManager.m_oViews.containsKey(sId))
						{
							Toolkit.getDefaultToolkit().beep();
						    m_oFilterDescInput.setBackground(java.awt.Color.red);
							return;
						}
						UserManager.modify(UserManager.VIEW, sOldId);
						UserManager.m_sNewId = viewName;
						UserManager.m_sBuffer = m_oFilterDescInput.getText();
						UserManager.m_sBuffer += ":"+  m_oFilterRuleInput.getText() ;
						//UserManager.m_sBuffer+= ":";
						UserManager.ok();
						
					}
				    setVisible(false);
					dispose();
				}
				catch (Exception e)
				{
					UserManager.cancel();
				}
			}
			else if (object == m_oRuleBuilderButton)
			{
				(new RuleBuilderMain(m_oFilterRuleInput.getText())).setVisible(true);

				if ( (UserManager.m_textRule == null) || UserManager.m_textRule.trim().equals("") )
					m_oFilterRuleInput.setText("Type your rule here:");
				else
					m_oFilterRuleInput.setText(UserManager.m_textRule);
			}
			else if (object == m_oCancelButton)
			{
			    setVisible(false);
				UserManager.cancel();
				dispose();
			}
				
		}
	}
	class SymWindow extends java.awt.event.WindowAdapter
	{
		public void windowClosing(java.awt.event.WindowEvent event)
		{
			Object object = event.getSource();
			if (object == ModifyFilter.this)
			{
				try
				{
					setVisible(false);
					UserManager.cancel();
					dispose();
				}
				catch (Exception e)
				{
				}
			}
		}
	}

	/*public static void main(String[] args)
	{
		JFrame frame = new JFrame();
		try
		{
			//(new ModifyFilter(frame, true, "Poller Package Filters")).setVisible(true);
			(new ModifyFilter("Poller Package Filters")).setVisible(true);
		}
		catch (Exception e)
		{
		}
	}*/
}
//-------------------------------------------------------------------------------------------
//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

//--------------------------------------------------------------------------------------------

package org.opennms.bb.eui.admin.distpoller.configure.cals;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import javax.swing.table.*;
import javax.swing.event.*;

public class TestTable extends JPanel {

	String[] columnNames = {
			"Time", "Status"};

	Object[][] dataAllOff = {
			{ "12.00am",  Boolean.FALSE },

			{ "12.15am",  Boolean.FALSE },

			{ "12.30am",  Boolean.FALSE },

			{ "12.45am",  Boolean.FALSE },
	
			{ "1.00am",  Boolean.FALSE },

			{ "1.15am",  Boolean.FALSE },

			{ "1.30am",  Boolean.FALSE },

			{ "1.45am",  Boolean.FALSE },

			{ "2.00am",  Boolean.FALSE },

			{ "2.15am",  Boolean.FALSE },

			{ "2.30am",  Boolean.FALSE },

			{ "2.45am",  Boolean.FALSE },
	
			{ "3.00am",  Boolean.FALSE },

			{ "3.15am",  Boolean.FALSE },

			{ "3.30am",  Boolean.FALSE },

			{ "3.45am",  Boolean.FALSE },
			
			{ "4.00am",  Boolean.FALSE },

			{ "4.15am",  Boolean.FALSE },

			{ "4.30am",  Boolean.FALSE },

			{ "4.45am",  Boolean.FALSE },
	
			{ "5.00am",  Boolean.FALSE },

			{ "5.15am",  Boolean.FALSE },

			{ "5.30am",  Boolean.FALSE },

			{ "5.45am",  Boolean.FALSE },
			
			{ "6.00am",  Boolean.FALSE },

			{ "6.15am",  Boolean.FALSE },

			{ "6.30am",  Boolean.FALSE },

			{ "6.45am",  Boolean.FALSE },
	
			{ "7.00am",  Boolean.FALSE },

			{ "7.15am",  Boolean.FALSE },

			{ "7.30am",  Boolean.FALSE },

			{ "7.45am",  Boolean.FALSE },
			
			{ "8.00am",  Boolean.FALSE },

			{ "8.15am",  Boolean.FALSE },

			{ "8.30am",  Boolean.FALSE },

			{ "8.45am",  Boolean.FALSE },
	
			{ "9.00am",  Boolean.FALSE },

			{ "9.15am",  Boolean.FALSE },

			{ "9.30am",  Boolean.FALSE },

			{ "9.45am",  Boolean.FALSE },

			{ "10.00am",  Boolean.FALSE },

			{ "10.15am",  Boolean.FALSE },

			{ "10.30am",  Boolean.FALSE },

			{ "10.45am",  Boolean.FALSE },
	
			{ "11.00am",  Boolean.FALSE },

			{ "11.15am",  Boolean.FALSE },

			{ "11.30am",  Boolean.FALSE },

			{ "11.45am",  Boolean.FALSE },
			
						
			};

	Object[][] dataAllOn = {
			{ "12.00am",  Boolean.TRUE },

			{ "12.15am",  Boolean.TRUE },

			{ "12.30am",  Boolean.TRUE },

			{ "12.45am",  Boolean.TRUE },
	
			{ "1.00am",  Boolean.TRUE },

			{ "1.15am",  Boolean.TRUE },

			{ "1.30am",  Boolean.TRUE },

			{ "1.45am",  Boolean.TRUE },

			{ "2.00am",  Boolean.TRUE },

			{ "2.15am",  Boolean.TRUE },

			{ "2.30am",  Boolean.TRUE },

			{ "2.45am",  Boolean.TRUE },
	
			{ "3.00am",  Boolean.TRUE },

			{ "3.15am",  Boolean.TRUE },

			{ "3.30am",  Boolean.TRUE },

			{ "3.45am",  Boolean.TRUE },
			
			{ "4.00am",  Boolean.TRUE },

			{ "4.15am",  Boolean.TRUE },

			{ "4.30am",  Boolean.TRUE },

			{ "4.45am",  Boolean.TRUE },
	
			{ "5.00am",  Boolean.TRUE },

			{ "5.15am",  Boolean.TRUE },

			{ "5.30am",  Boolean.TRUE },

			{ "5.45am",  Boolean.TRUE },
			
			{ "6.00am",  Boolean.TRUE },

			{ "6.15am",  Boolean.TRUE },

			{ "6.30am",  Boolean.TRUE },

			{ "6.45am",  Boolean.TRUE },
	
			{ "7.00am",  Boolean.TRUE },

			{ "7.15am",  Boolean.TRUE },

			{ "7.30am",  Boolean.TRUE },

			{ "7.45am",  Boolean.TRUE },
			
			{ "8.00am",  Boolean.TRUE },

			{ "8.15am",  Boolean.TRUE },

			{ "8.30am",  Boolean.TRUE },

			{ "8.45am",  Boolean.TRUE },
	
			{ "9.00am",  Boolean.TRUE },

			{ "9.15am",  Boolean.TRUE },

			{ "9.30am",  Boolean.TRUE },

			{ "9.45am",  Boolean.TRUE },

			{ "10.00am",  Boolean.TRUE },

			{ "10.15am",  Boolean.TRUE },

			{ "10.30am",  Boolean.TRUE },

			{ "10.45am",  Boolean.TRUE },
	
			{ "11.00am",  Boolean.TRUE },

			{ "11.15am",  Boolean.TRUE },

			{ "11.30am",  Boolean.TRUE },

			{ "11.45am",  Boolean.TRUE },
			
						
			};

	
	JTable table;
	
	TestTableModel tableModel = new TestTableModel(dataAllOff, columnNames);
	JCheckBox check;

	TestTable() 
	{
		
		table = new JTable(tableModel);
		table.setCellSelectionEnabled(true);
		table.setColumnSelectionAllowed(false);
		table.setRowSelectionAllowed(false);
		JScrollPane jsp = new JScrollPane(table);
		jsp.setPreferredSize(new Dimension(200,355));
		jsp.setMaximumSize(new Dimension(200,355));
		add(jsp, BorderLayout.CENTER);
		table.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
			public void valueChanged(ListSelectionEvent e) {
				if (!e.getValueIsAdjusting()) {
					table.repaint();
				}
			}
		});
	}

	public void setAllOn()
	{
		System.out.println("setAllOn");
		tableModel.setDataVector(dataAllOn, columnNames);
		table.sizeColumnsToFit(0);
	}

	public void setAllOff()
	{
		System.out.println("setAllOff");
		tableModel.setDataVector(dataAllOff, columnNames);
		table.sizeColumnsToFit(0);
	}

	
	
	
}

class TestTableModel extends DefaultTableModel {
	

	TestTableModel(Object[][] dataAllOff, Object[] columnNames) {
		super(dataAllOff, columnNames);
	}

	public int getRowCount() {
		return super.getRowCount();
	}

	public int getColumnCount() {
		return super.getColumnCount();
	}
	public String getColumnName(int col) {
		return super.getColumnName(col);
	}
	
	public Object getValueAt(int row, int col) {
		return super.getValueAt(row, col);
	}

	public void setValueAt(Object value, int row, int col) {

		super.setValueAt(value, row, col);

	}

	public boolean isCellEditable(int row, int col) {

		Class columnClass = getColumnClass(col);
		String name = getColumnName(col);
		return (!name.equals("Time"));
	
	}

}
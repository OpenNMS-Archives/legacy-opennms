//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
package org.opennms.bb.eui.admin.UserGroupView.Layout;

import java.awt.*;
import java.util.Hashtable;

public class GraphPaperLayout implements LayoutManager2
{
	int			_iHzGap;
	int			_iVtGap;
	Dimension	_dGridSize;
	Hashtable	_oConstraintsTable;

	public GraphPaperLayout()
	{
		this(new Dimension(1,1));
	}

	public GraphPaperLayout(Dimension gridSize)
	{
		this(gridSize, 0, 0);
	}
	
	public GraphPaperLayout(Dimension gridSize, int hGap, int vGap)
	{
		if((gridSize.width <= 0) || (gridSize.height <= 0))
		{
			throw new IllegalArgumentException(
				"Dimensions must be positive integers");
		}
		this._dGridSize = new Dimension(gridSize);
		this._iHzGap = hGap;
		this._iVtGap = vGap;
		_oConstraintsTable = new Hashtable();
	}
	
	public Dimension getGridSize()
	{
		return new Dimension( _dGridSize );
	}
	
	public void setGridSize( Dimension d )
	{
		setGridSize( d.width, d.height );
	}
	
	public void setGridSize( int width, int height )
	{
		_dGridSize = new Dimension( width, height );
	}
	
	public void setConstraints(Component comp, Rectangle constraints)
	{
		_oConstraintsTable.put(comp, new Rectangle(constraints));
	}
	
	public void addLayoutComponent(String name, Component comp)
	{
	}

	public void removeLayoutComponent(Component comp)
	{
		_oConstraintsTable.remove(comp);
	}

	public Dimension preferredLayoutSize(Container parent)
	{
		return getLayoutSize(parent, true);
	}

	public Dimension minimumLayoutSize(Container parent)
	{
		return getLayoutSize(parent, false);
	}
	
	protected Dimension getLayoutSize(Container parent, boolean isPreferred)
	{
		Dimension largestSize = getLargestCellSize(parent, isPreferred);

		Insets insets = parent.getInsets();
		largestSize.width = ( largestSize.width * _dGridSize.width ) +
			( _iHzGap * ( _dGridSize.width + 1 ) ) + insets.left + insets.right;
		largestSize.height = ( largestSize.height * _dGridSize.height ) +
			( _iVtGap * ( _dGridSize.height + 1 ) ) + insets.top + insets.bottom;

		return largestSize;
	}
	
	protected Dimension getLargestCellSize(Container parent,
										   boolean isPreferred)
	{
		int nComponents = parent.getComponentCount();
		Dimension maxCellSize = new Dimension(0,0);
		for( int i = 0; i < nComponents; i++ )
		{
			Component c = parent.getComponent(i);
			Rectangle rect = (Rectangle)_oConstraintsTable.get(c);
			if( c != null && rect != null )
			{
				Dimension componentSize;
				if( isPreferred )
				{
					componentSize = c.getPreferredSize();
				}
				else
				{
					componentSize = c.getMinimumSize();
				}
				// Note: rect dimensions are already asserted to be > 0 when the
				// component is added with constraints
				maxCellSize.width = Math.max(maxCellSize.width,
											 componentSize.width / rect.width);
				maxCellSize.height = Math.max(maxCellSize.height,
											  componentSize.height / rect.height);
			}
		}
		return maxCellSize;
	}

	public void layoutContainer(Container parent)
	{
		synchronized (parent.getTreeLock())
		{
			Insets insets = parent.getInsets();
			int nComponents = parent.getComponentCount();

			if(nComponents == 0)
			{
				return;
			}
			
			// Total parent dimensions
			Dimension size = parent.getSize();
			int totalW = size.width - (insets.left + insets.right);
			int totalH = size.height - (insets.top + insets.bottom);

			// Cell dimensions, including padding
			int totalCellW = totalW / _dGridSize.width;
			int totalCellH = totalH / _dGridSize.height;

			// Cell dimensions, without padding
			int cellW = (totalW - ( (_dGridSize.width + 1) * _iHzGap) )
					/ _dGridSize.width;
			int cellH = (totalH - ( (_dGridSize.height + 1) * _iVtGap) )
					/ _dGridSize.height;
				
			for( int i = 0; i < nComponents; i++ )
			{
				Component c = parent.getComponent(i);
				Rectangle rect = (Rectangle)_oConstraintsTable.get(c);
				if( rect != null )
				{
					int x = insets.left + ( totalCellW * rect.x ) + _iHzGap;
					int y = insets.top + ( totalCellH * rect.y ) + _iVtGap;
					int w = ( cellW * rect.width ) - _iHzGap;
					int h = ( cellH * rect.height ) - _iVtGap;
					c.setBounds(x, y, w, h);
				}
			}
		}
	}
	
	// LayoutManager2 /////////////////////////////////////////////////////////
	
	public void addLayoutComponent(Component comp, Object constraints)
	{
		if(constraints instanceof Rectangle)
		{
			Rectangle rect = (Rectangle)constraints;
			if( rect.width <= 0 || rect.height <= 0 )
			{
				throw new IllegalArgumentException(
					"Cannot add to layout: rectangle must have positive width and height");
			}
			if( rect.x < 0 || rect.y < 0 )
			{
				throw new IllegalArgumentException(
					"Cannot add to layout: rectangle x and y must be >= 0");
			}
			setConstraints(comp, rect);
		}
		else if(constraints != null)
		{
			throw new IllegalArgumentException(
				"Cannot add to layout: constraint must be a Rectangle");
		}
	}

	public Dimension maximumLayoutSize(Container target)
	{
		return new Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE);
	}

	public float getLayoutAlignmentX(Container target)
	{
		return 0.5f;
	}

	public float getLayoutAlignmentY(Container target)
	{
		return 0.5f;
	}

	public void invalidateLayout(Container target)
	{
		// Do nothing
	}
}

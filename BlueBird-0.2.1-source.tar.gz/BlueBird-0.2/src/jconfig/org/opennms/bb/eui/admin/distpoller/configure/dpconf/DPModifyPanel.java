//-------------------------------------------------------------------------------------------
//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

//--------------------------------------------------------------------------------------------

package org.opennms.bb.eui.admin.distpoller.configure.dpconf;

import java.awt.*;
import javax.swing.*;
import java.util.*;


public class DPModifyPanel extends JPanel
{
	private JLabel groupLabel, groupLabel1, groupLabel2, commentLabel;
	private JTextField groupText, groupText1, groupText2;
	private JTextArea commentText;	
	String temp = null;
	String[] props = new String[4];

	public DPModifyPanel(String temp) {

		this.temp = temp;
		StringTokenizer st = new StringTokenizer(temp, "*");
		int i = 0;
		while ( st.hasMoreTokens() ) {

			props[i] = st.nextToken();
			//System.out.println(props[i]);
			++i;
		}
			
	
		GridBagLayout gridBag = new GridBagLayout();
		JPanel groupPanel = new JPanel(gridBag);

		groupLabel = new JLabel("Poller Name:");
		groupText = new JTextField(20);
		
		groupLabel1 = new JLabel("Poller Full Name:");
		groupText1 = new JTextField(20);

		groupLabel2 = new JLabel("Poller IP Address:");
		groupText2 = new JTextField(20);

			
		commentLabel = new JLabel("Comments:");
		commentText = new JTextArea(5, 20);
      	JScrollPane scrollPane = new JScrollPane(commentText,
                   JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
                   JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);

	     	GridBagConstraints c = new GridBagConstraints();
	     	c.fill = GridBagConstraints.HORIZONTAL;

		c.weightx = 1;
		c.gridx = 0;
		c.gridy = 2;
      	gridBag.setConstraints(groupLabel, c);
      	groupPanel.add(groupLabel);

		c.gridwidth = GridBagConstraints.REMAINDER;
		c.gridx = 2;
		c.gridy = 2;
		gridBag.setConstraints(groupText, c);
		groupPanel.add(groupText);
		groupText.setText(props[0]);

		c.fill = GridBagConstraints.HORIZONTAL;

		//c.weightx = 1;
		c.gridwidth = 4;
		c.gridx = 0;
		c.gridy = 3;
      	gridBag.setConstraints(groupLabel1, c);
      	groupPanel.add(groupLabel1);

		c.gridwidth = GridBagConstraints.REMAINDER;
		c.gridx = 3;
		c.gridy = 3;
		gridBag.setConstraints(groupText1, c);
		groupPanel.add(groupText1);
		groupText1.setText(props[1]);


		c.fill = GridBagConstraints.HORIZONTAL;

		//c.weightx = 1;
		c.gridwidth = 4;

		c.gridx = 0;
		c.gridy = 4;
      	gridBag.setConstraints(groupLabel2, c);
      	groupPanel.add(groupLabel2);

		c.gridwidth = GridBagConstraints.REMAINDER;
		c.gridx = 4;
		c.gridy = 4;
		gridBag.setConstraints(groupText2, c);
		groupPanel.add(groupText2);
		groupText2.setText(props[2]);


		c.fill = GridBagConstraints.HORIZONTAL;
		//c.weightx = 1; 
		c.gridwidth = 4;
		c.gridx = 0;
		c.gridy = 5;
		gridBag.setConstraints(commentLabel, c);
      	groupPanel.add(commentLabel);		

		c.gridwidth = GridBagConstraints.REMAINDER;
		c.ipady = 30;      
		c.gridx = 5;
		c.gridy = 5;
       	gridBag.setConstraints(scrollPane, c);
       	groupPanel.add(scrollPane);
		commentText.setText(props[3]);


		add(groupPanel);
	}

	public String getSelectedValues() {

		String retValue = null;
		retValue = groupText.getText()+"*"+groupText1.getText()+"*"+groupText2.getText() + "*"+commentText.getText();
		return retValue;
	}

}



//-------------------------------------------------------------------------------------------
//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

//--------------------------------------------------------------------------------------------


package org.opennms.bb.eui.admin.distpoller.configure.dpconf;

import org.opennms.bb.eui.common.components.*;
import org.opennms.bb.eui.common.panels.TableManipulationPanel;
import org.opennms.bb.eui.admin.distpoller.configure.snmp.components.*;
import org.opennms.bb.eui.admin.distpoller.configure.snmp.panels.*;
import org.opennms.bb.eui.admin.distpoller.configure.cals.*;
import org.opennms.bb.eui.admin.distpoller.configure.parsers.*;
import org.opennms.bb.eui.admin.distpoller.configure.fbuilder.*;

import org.w3c.dom.*;

import javax.swing.*;
import javax.swing.text.*;
import javax.swing.tree.*;
import javax.swing.border.*;
import javax.swing.JTree; 
import javax.swing.event.*;
import javax.swing.table.DefaultTableModel;

import java.awt.*;
import java.awt.event.*;
import java.awt.dnd.*; 
import java.awt.datatransfer.*; 

import java.util.*;
import java.io.IOException; 

/*
 * 1.0 99/10/30
 * @author Jaya Krishna Chakravarthula
 *
 * Modifications:
 * Changed the deprecated 'getComponentAtIndex(int i)' method of 'JPopupMenu'
 * to 'getComponent(int i)' for the move to JDK 1.3 - Sowmya
 *
 * 10/18/00 - 'DPWizardTwo' changed to use Swing 'JList's instead of AWT 'Lists'
 *            Made corresponding changes here
 *          - Sowmya
 *
 * 10/27/00 - Deleted calendar stuff and disabed corresponding buttons, changed
 * 	      file paths according to new directory structure
 *	    - Vishwa
 */

public class DPConfigF extends JFrame {

   	public static JFrame frame;
	public static JFrame frame1;
	public static int WIDTH		=	650;
	public static int HEIGHT	=	750;
	
	JPopupMenu		m_oPopup		= null;
	MouseListener		m_oPopupListener	= new PopupListener();
	boolean			m_dpExists = false;	

	static DPConfigF instance;

	DefaultManipPanel dPanel;
	TreeSelectionModel	m_oSelectionModel	= null;
        public static DefaultTreeModel m_PollerPackageModel, m_ServicesModel, m_CalendarsModel, m_DistPollerModel;
	DefaultTreeModel	m_oTreeModel		= null;

	private static DefaultMutableTreeNode top, top1, top2, top3, root, cc1, cc2, oNode;

	public String nodeName = null;

	private TreePath selPath;
	
	String s1 = "Attribute";
	String s2 = "Value";

	String temp1 = "";
	String temp2 = "";

	packageXmlParser ice;
	pollerXmlParser pollerParser;
	repcalXmlParser	repeatingCalendar;
	onetimeXmlParser onetimeCalendar;
	ServiceXmlParser serviceParser;

	private Vector ppVector 		= 	new Vector();
	private Vector dpVector 		= 	new Vector();
	private Vector serviceProps 		= 	new Vector();
	private Vector tempRangeTable 		=	new Vector();

	private Vector defaultColumns		= 	new Vector();
	
	private int flag 			= 	1;
	private int found 			= 	1;
	private String selectedValue 		= 	null;
	private String dpNameString 		=	null;
	private Object[] retval 		= 	null;
	boolean serviceCheck			=	false;

	public JDialog propdialog, propdialog1, Wizard1, Wizard2, Wizard3;

	public JLabel stat 			= 	new JLabel();

	int bool = 0, bool1 = 0, bool2 = 0, bool3 = 0;
      	
	public DPWizard1 dpWizardOne;
	public DPWizardTwo dpWizardTwo;
	public DPWizardThree dpWizardThree;
	public PPModifyPanel ppModifyPanel;
	public DPModifyPanel dpModifyPanel;

	public final static Insets insets0 	= 	new Insets(0,0,0,0);
	public final static Dimension vpad5 	= 	new Dimension(1,5);
	public final static Dimension vpad40 	= 	new Dimension(1,40);
	public final static Border loweredBorder=	new BevelBorder(BevelBorder.RAISED);
	public final static Border emptyBorder5	=	new EmptyBorder(5,5,5,5);

	DragDropTree m_PollerPackageTree;
	DropTree  m_DistPollerTree;
	DragTree m_CalendarsTree, m_ServicesTree;
	myTreeListener myTree	 = 	new myTreeListener();

	//Added variables
	private DefaultMutableTreeNode copyNode	= 	null;	
	private int cNodeIndex			=	0;
	private int pNodeIndex			= 	0;


	//Constructor
	public DPConfigF() 
	{
		
		getContentPane().setLayout(new BorderLayout());
		instance = this;
		setTitle("Distributed Poller Configuration");

		callXmlParsers();
		defaultColumns.addElement(s1);
		defaultColumns.addElement(s2);

		DefaultMutableTreeNode c1,c2,c3,c4;
    	
		c2 = c3 = null;

	  //poller package
      	top = new DefaultMutableTreeNode("Poller Package");
		Enumeration enum1 = (ice.getPackageData()).elements();

	  try {
		
		while (enum1.hasMoreElements())
		{
			Vector pp1 = (Vector)enum1.nextElement();
			Enumeration enum2 = pp1.elements();
			while (enum2.hasMoreElements())
			{
				Object obj = (Object)enum2.nextElement();

				if (obj instanceof String)
				{
					String name = (String)obj;
					int index = name.indexOf(":");
					int len = name.length();
					if (name.startsWith("packageName"))
					{
						c1 = new DefaultMutableTreeNode(name.substring(index + 1, len));
						top.add(c1);
						c1.add(new DefaultMutableTreeNode("ranges"));
						c1.add(new DefaultMutableTreeNode("filters"));
						c1.add(c2 = new DefaultMutableTreeNode("services"));
						c1.add(c3 = new DefaultMutableTreeNode("calendars"));
					}
					if (name.startsWith("serviceName"))
					{
						DefaultMutableTreeNode services = new DefaultMutableTreeNode(name.substring(index + 1, len));
						c2.add(services);
					}
					if ( name.startsWith("onetimeCal") || name.startsWith("repeatingCal") )
					{
						c3.add(new DefaultMutableTreeNode(name.substring(index + 1, len)));
					}
				}
			}
		}
		}catch(Exception epp) 
		{
			System.out.println("prob in pp");
		}

		enum1 = 	null;
		c1 	=	null;

	  //distributed poller
		top1 = new DefaultMutableTreeNode("Distributed Poller");
	
		enum1 = (pollerParser.getPollerData()).elements();

		//counter variable
		int counter = 0;

		while (enum1.hasMoreElements())
		{
			Vector dp1 = (Vector)enum1.nextElement();

			//This counter variable and if statement are in corresponding to display one dist poller only.
			counter++;
			if (counter == 1)
			{
				Enumeration enum2 = dp1.elements();
				while (enum2.hasMoreElements())
				{
					String name = (String)enum2.nextElement();
					int index = name.indexOf(":");
					int len = name.length();
					if (name.startsWith("pollerID"))
					{
						c1 = new DefaultMutableTreeNode(name.substring(index + 1, len));
						top1.add(c1);
					}
					if (name.startsWith("package"))
					{
						c1.add(new DefaultMutableTreeNode(name.substring(index + 1, len)));
					}
				}
				m_dpExists = true;
			}	
			else
			{
				dp1 = null;
			}
		}
	
		enum1 = 	null;
		c1 	=	null;

	  //services
		top3 = new DefaultMutableTreeNode("Services");

		Vector sDetails = serviceParser.getServicesProp();
      		enum1 = sDetails.elements();
		while (enum1.hasMoreElements())
		{
			Vector s1 = (Vector)enum1.nextElement();
			Enumeration enum2 = s1.elements();
			while (enum2.hasMoreElements())
			{
				String name = (String)enum2.nextElement();
				int index = name.indexOf(":");
				int len = name.length();
				if (name.startsWith("name"))
				{
					c1 = new DefaultMutableTreeNode(name.substring(index + 1, len));
					top3.add(c1);
				}
			}
		}
		
	  //Calendars	
		top2 = new DefaultMutableTreeNode("Calendars");
      
		cc1 = new DefaultMutableTreeNode("Repeating");
		top2.add(cc1);

		enum1 = (repeatingCalendar.getCalendarData()).elements();

		while (enum1.hasMoreElements())
		{
			Vector rep1 = (Vector)enum1.nextElement();
			Enumeration enum2 = rep1.elements();
			while (enum2.hasMoreElements())
			{
				Object obj = (Object)enum2.nextElement();

				if (obj instanceof String)
				{
					String name = (String)obj;
					int index = name.indexOf(":");
					int len = name.length();
					if (name.startsWith("calName"))
					{
						cc1.add(new DefaultMutableTreeNode(name.substring(index + 1, len)));
					}
				}
			}
		}

		cc2 = new DefaultMutableTreeNode("One-time");
		top2.add(cc2);

		enum1 = (onetimeCalendar.getCalendarData()).elements();

		while (enum1.hasMoreElements())
		{
			Vector rep1 = (Vector)enum1.nextElement();
			Enumeration enum2 = rep1.elements();
			while (enum2.hasMoreElements())
			{
				Object obj = (Object)enum2.nextElement();

				if (obj instanceof String)
				{
					String name = (String)obj;
					int index = name.indexOf(":");
					int len = name.length();
					if (name.startsWith("calName"))
					{
						cc2.add(new DefaultMutableTreeNode(name.substring(index + 1, len)));
					}
				}
			}
		}

		m_PollerPackageTree 	= 	new DragDropTree(top);
		m_ServicesTree 		= 	new DragTree(top3);
		m_CalendarsTree		= 	new DragTree(top2);
		m_DistPollerTree 	= 	new DropTree(top1);
	
		m_PollerPackageTree.setRootVisible(false);
		m_ServicesTree.setRootVisible(false);
		m_CalendarsTree.setRootVisible(false);
		m_DistPollerTree.setRootVisible(false);

		addPopupMenu();

		m_oTreeModel		= 	(DefaultTreeModel)m_PollerPackageTree.getModel();

		m_PollerPackageModel 	= 	(DefaultTreeModel)m_PollerPackageTree.getModel();
		m_ServicesModel		=	(DefaultTreeModel)m_ServicesTree.getModel();
		m_CalendarsModel	= 	(DefaultTreeModel)m_CalendarsTree.getModel();
		m_DistPollerModel	= 	(DefaultTreeModel)m_DistPollerTree.getModel();

	
		m_PollerPackageModel.addTreeModelListener(myTree);
		m_CalendarsModel.addTreeModelListener(myTree);
		m_DistPollerModel.addTreeModelListener(myTree);

			
		m_PollerPackageTree.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
		m_ServicesTree.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
		m_CalendarsTree.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
		m_DistPollerTree.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);

		m_oSelectionModel		= 	m_PollerPackageTree.getSelectionModel();

		
		m_PollerPackageTree.addTreeSelectionListener(
			new TreeSelectionListener() {
				public void valueChanged(TreeSelectionEvent e) {
					if(e.getNewLeadSelectionPath()!=null)
					{
						stat.setText(" Poller Packages : "+ e.getNewLeadSelectionPath().getLastPathComponent().toString());
						UserManager.m_sOldId = e.getNewLeadSelectionPath().getLastPathComponent().toString();
						bool = 1; bool1 = bool2 = bool3 = 0;
					}
					if( m_oSelectionModel != m_PollerPackageTree.getSelectionModel())
					{
						m_oSelectionModel.clearSelection();
						m_oSelectionModel	= m_PollerPackageTree.getSelectionModel();
						m_oTreeModel		= 	(DefaultTreeModel)m_PollerPackageTree.getModel();

					}
				}
		});
		m_ServicesTree.addTreeSelectionListener(
			new TreeSelectionListener() {
				public void valueChanged(TreeSelectionEvent e) {
					if(e.getNewLeadSelectionPath()!=null)
					{
						stat.setText(" Services : " + e.getNewLeadSelectionPath().getLastPathComponent().toString());
						UserManager.m_sOldId = e.getNewLeadSelectionPath().getLastPathComponent().toString();
						bool1 = 1; bool = bool2 = bool3 = 0;

					}
					if( m_oSelectionModel != m_ServicesTree.getSelectionModel())
					{
						m_oSelectionModel.clearSelection();
						m_oSelectionModel	= m_ServicesTree.getSelectionModel();
						m_oTreeModel		= 	(DefaultTreeModel)m_ServicesTree.getModel();

					}
				}
		});
		m_CalendarsTree.addTreeSelectionListener(
			new TreeSelectionListener() {
				public void valueChanged(TreeSelectionEvent e) {
					if(e.getNewLeadSelectionPath()!=null)
					{
						stat.setText(" Calendars : "+ e.getNewLeadSelectionPath().getLastPathComponent().toString());
						UserManager.m_sOldId = e.getNewLeadSelectionPath().getLastPathComponent().toString();
						bool2 = 1; bool1 = bool = bool3 = 0;
					}
					if( m_oSelectionModel != m_CalendarsTree.getSelectionModel())
					{

						m_oSelectionModel.clearSelection();
						m_oSelectionModel	= m_CalendarsTree.getSelectionModel();
						m_oTreeModel		= 	(DefaultTreeModel)m_CalendarsTree.getModel();

					}
				}
		});
		m_DistPollerTree.addTreeSelectionListener(
			new TreeSelectionListener() {
				public void valueChanged(TreeSelectionEvent e) {
					if(e.getNewLeadSelectionPath()!=null)
					{
						stat.setText(" Distributed Pollers : "+ e.getNewLeadSelectionPath().getLastPathComponent().toString());
						UserManager.m_sOldId = e.getNewLeadSelectionPath().getLastPathComponent().toString();
						bool3 = 1; bool = bool2 = bool1 = 0;

					}
					if( m_oSelectionModel != m_DistPollerTree.getSelectionModel())
					{
						m_oSelectionModel.clearSelection();
						m_oSelectionModel	= m_DistPollerTree.getSelectionModel();
						m_oTreeModel		= 	(DefaultTreeModel)m_DistPollerTree.getModel();

					}
				}
		});

		Dimension d = new Dimension(300,20);

		JPanel jp = new JPanel();

	// Poller Packages 

		JPanel p1 = new JPanel(new BorderLayout());

		JTextField jl = new JTextField("Poller Packages");
		jl.setFont(new Font("Courier", 
                        		       Font.BOLD, 12));
		jl.setPreferredSize(d);
		jl.setEditable(false);
		jl.setRequestFocusEnabled(false);
		jl.setHorizontalAlignment(JTextField.CENTER);
		jl.setForeground(Color.white);
		jl.setBackground(new Color(0,100,100)); 

		JScrollPane js = new JScrollPane(m_PollerPackageTree);
		js.setPreferredSize(new Dimension(300, 595));

		p1.add(jl, BorderLayout.NORTH);
		p1.add(js, BorderLayout.CENTER);

	// Services

		JPanel p2 = new JPanel(new BorderLayout());
		JTextField jl1 = new JTextField("Services");
		jl1.setFont(new Font("Courier", 
                        		       Font.BOLD, 12));
		jl1.setPreferredSize(d);
		jl1.setEditable(false);
		jl1.setRequestFocusEnabled(false);
		jl1.setHorizontalAlignment(JTextField.CENTER);
		jl1.setForeground(Color.white);
		jl1.setBackground(new Color(0,100,100)); 

		JScrollPane js1 = new JScrollPane(m_ServicesTree);

		//This method is commented as removing Calendar pane. 
		//js1.setPreferredSize(new Dimension(300, 185));

		//This method is added as removing Calendar pane.
		js1.setPreferredSize(new Dimension(300, 290));

		p2.add(jl1, BorderLayout.NORTH);
		p2.add(js1, BorderLayout.SOUTH);

	// Calendars
/**
		JPanel p3 = new JPanel(new BorderLayout());
		JTextField jl2 = new JTextField("Scheduled Downtime Calendars");
		jl2.setFont(new Font("Courier", 
                        		       Font.BOLD, 12));
		jl2.setPreferredSize(d);
		jl2.setEditable(false);
		jl2.setRequestFocusEnabled(false);
		jl2.setHorizontalAlignment(JTextField.CENTER);
		jl2.setForeground(Color.white);
		jl2.setBackground(new Color(0,100,100)); 
		JScrollPane js2 = new JScrollPane(m_CalendarsTree);
		js2.setPreferredSize(new Dimension(300, 185));
		p3.add(jl2, BorderLayout.NORTH);
		p3.add(js2, BorderLayout.CENTER);	
*/

	// Distributed Pollers

		JPanel p4 = new JPanel(new BorderLayout());
		JTextField jl3 = new JTextField("Distributed Pollers");
		jl3.setFont(new Font("Courier", 
                        		       Font.BOLD, 12));
		jl3.setPreferredSize(d);
		jl3.setEditable(false);
		jl3.setRequestFocusEnabled(false);
		jl3.setHorizontalAlignment(JTextField.CENTER);
		jl3.setForeground(Color.white);
		jl3.setBackground(new Color(0,100,100)); 
 
		JScrollPane js3 = new JScrollPane(m_DistPollerTree);

		//This method is commented as removing Calendar pane. 
		//js3.setPreferredSize(new Dimension(300, 185));


		//This method is added as removing Calendar pane.
		js3.setPreferredSize(new Dimension(300, 285));

		p4.add(jl3, BorderLayout.NORTH);
		p4.add(js3, BorderLayout.SOUTH);	

		JPanel jp1 = new JPanel(new BorderLayout());
		jp1.add(p2, BorderLayout.NORTH);

		//These methods are commented as removing Calendar pane. 
		//jp1.add(p3, BorderLayout.CENTER);
		//jp1.add(p4, BorderLayout.SOUTH);

		//This method is added as removing Calendar pane.
		jp1.add(p4, BorderLayout.CENTER);
		
		jp.setLayout(new BoxLayout(jp, BoxLayout.X_AXIS));
		jp.setBorder(BorderFactory.createEmptyBorder(10, 2, 10, 2));
		jp.add(p1);
		jp.add(Box.createRigidArea(new Dimension(10, 0)));
		jp.add(jp1);
	

	  //Status bar label information
		stat.setPreferredSize(new Dimension(600,20));
		stat.setBorder(BorderFactory.createLoweredBevelBorder());
		stat.setHorizontalAlignment(JTextField.LEFT);
		stat.setFont(new Font("Courier",Font.BOLD, 11));
		stat.setForeground(new Color(0,100,100));
		stat.setText(" Ready");

	  
	  //Main panel
		getContentPane().add(createMenuBar(), BorderLayout.NORTH);
		getContentPane().add(jp, BorderLayout.CENTER);
		getContentPane().add(stat, BorderLayout.SOUTH);
		
		setSize(650, 750);
	
	}


	void addPopupMenu()
	{
		/*
		 * Create the popup menu.
		 */
		JMenuItem oMenuItem;
		m_oPopup = new JPopupMenu();

		oMenuItem = new JMenuItem("Copy");
		oMenuItem.setActionCommand("Copy");
		oMenuItem.addActionListener((ActionListener)m_oPopupListener);
		m_oPopup.add(oMenuItem);
		oMenuItem = new JMenuItem("Paste");
		oMenuItem.setActionCommand("Paste");
		oMenuItem.addActionListener((ActionListener)m_oPopupListener);
		m_oPopup.add(oMenuItem);
		oMenuItem = new JMenuItem("Rename..");
		oMenuItem.setActionCommand("Rename");
		oMenuItem.addActionListener((ActionListener)m_oPopupListener);
		m_oPopup.add(oMenuItem);
		oMenuItem = new JMenuItem("Delete");
		oMenuItem.setActionCommand("Delete");
		oMenuItem.addActionListener((ActionListener)m_oPopupListener);
		m_oPopup.add(oMenuItem);
		m_oPopup.addSeparator();

		oMenuItem = new JMenuItem("Properties..");
		oMenuItem.setActionCommand("Property");
		oMenuItem.addActionListener((ActionListener)m_oPopupListener);
		m_oPopup.add(oMenuItem);
	
		/*
		 * Add listener to components that can bring up popup menus.
		 */
		m_PollerPackageTree.addMouseListener(m_oPopupListener);
		m_DistPollerTree.addMouseListener(m_oPopupListener);
		//m_CalendarsTree.addMouseListener(m_oPopupListener);
		//m_ServicesTree.addMouseListener(m_oPopupListener);
		
	}

	class PopupListener extends MouseAdapter implements ActionListener
	{
		private int		x			= -1,
						y			= -1;
		private Object	m_oSource	= null;

		public void actionPerformed(ActionEvent e)
		{
			
			if(e.getActionCommand().equals("Copy"))
			{
				copy();
			}
			else if(e.getActionCommand().equals("Paste"))
			{
				paste();
			}
			else if(e.getActionCommand().equals("Delete"))
			{
				delete();
			}

			else if(e.getActionCommand().equals("Rename"))
			{
				TreePath oPath =  m_oSelectionModel.getSelectionPath();
				DefaultMutableTreeNode defaultNode = (DefaultMutableTreeNode)oPath.getLastPathComponent();

				if(oPath.getPathCount() < 1)
				{
					return;
				}
				if(m_oSelectionModel == m_PollerPackageTree.getSelectionModel())
				{
					/*if ( defaultNode.toString().equals("ranges") || defaultNode.toString().equals("services")
						|| defaultNode.toString().equals("filters") || defaultNode.toString().equals("calendars") )
					{
						m_PollerPackageTree.setEditable(false);
					}
					else*/ 
					{
						m_PollerPackageTree.setEditable(true);
						m_PollerPackageTree.startEditingAtPath(oPath);
					}
				}
				else if(m_oSelectionModel == m_CalendarsTree.getSelectionModel())
				{
					/*if ( defaultNode.toString().equals("Repeating") || defaultNode.toString().equals("One-time") )
					{
						m_PollerPackageTree.setEditable(false);
					}
					else*/
					{
						m_CalendarsTree.setEditable(true);
						m_CalendarsTree.startEditingAtPath(oPath);
					}
				}
				else if(m_oSelectionModel == m_DistPollerTree.getSelectionModel())
				{
					m_DistPollerTree.setEditable(true);
					m_DistPollerTree.startEditingAtPath(oPath);
				}

			}
			else if(e.getActionCommand().equals("Property"))
			{
				clickAction(new MouseEvent((Component)m_oSource,0,0,0,x,y,2,false));
			}
		}

	
		public void mousePressed(MouseEvent e)
		{
			if(m_PollerPackageTree.isEditable())
			{
				if(m_PollerPackageTree.isEditing())
				{
					m_PollerPackageTree.stopEditing();
				}
				m_PollerPackageTree.setEditable(false);
			}
			else if(m_CalendarsTree.isEditable())
			{
				if(m_CalendarsTree.isEditing())
				{
					m_CalendarsTree.stopEditing();
				}
				m_CalendarsTree.setEditable(false);
			}
			else if(m_DistPollerTree.isEditable())
			{
				if(m_DistPollerTree.isEditing())
				{
					m_DistPollerTree.stopEditing();
				}
				m_DistPollerTree.setEditable(false);
			}
					
			popupAction(e);
		}

		public void mouseReleased(MouseEvent e)
		{
			popupAction(e);
		}

		void clickAction(MouseEvent e)
		{
			if (e.getClickCount()>1)
			{
				if(e.getSource() == m_DistPollerTree)
				{
					selPath = m_DistPollerTree.getPathForLocation(e.getX(), e.getY());
					oNode  = (DefaultMutableTreeNode)selPath.getLastPathComponent();
					if(oNode != null)
					{
						if (getTreeLeaves(m_DistPollerModel).contains(oNode.toString().trim()))
						{
							try 
							{
								(new ModifyDistPoller(DPConfigF.this,
									 "Modify Distributed Poller ", true, oNode.toString().trim())).setVisible(true);
								if(!UserManager.m_sNewId.equals(""))
								{
									oNode.setUserObject(UserManager.m_sNewId);
									((DefaultTreeModel)m_DistPollerTree.getModel()).nodeChanged(oNode);
								}
							}catch(Exception e1) { }
						}
					}
				}
				else if (e.getSource() == m_CalendarsTree)
				{
					selPath = m_CalendarsTree.getPathForLocation(e.getX(), e.getY());
					oNode  = (DefaultMutableTreeNode)selPath.getLastPathComponent();

					MutableTreeNode root		= (MutableTreeNode)m_CalendarsModel.getRoot();
					int index = m_CalendarsModel.getChildCount(root);
				
					Object node[] = new Object[index];

					for (int i = 0; i < index; i++) {
						node[i] = m_CalendarsModel.getChild(root, i); 
					}
			
					int countnodes = m_CalendarsModel.getChildCount(node[1]);
					Vector onecal = new Vector(countnodes);
				
					for (int i = 0; i < countnodes; i++) {
						onecal.addElement(m_CalendarsModel.getChild(node[1], i).toString().trim()); 
					}
						
					countnodes = m_CalendarsModel.getChildCount(node[0]);
					Vector repcal = new Vector(countnodes);
					
					for (int i = 0; i < countnodes; i++) {
						repcal.addElement(m_CalendarsModel.getChild(node[0], i).toString().trim()); 
					}
						
					if(oNode != null)
					{
						if (onecal.contains(oNode.toString().trim()))
						{
							try
							{
								(new calendarMain(DPConfigF.this,
									 "Modify One-time Calendar", true, oNode.toString(), true)).setVisible(true);
								if(!UserManager.m_sNewId.equals(""))
								{
									oNode.setUserObject(UserManager.m_sNewId);
									((DefaultTreeModel)m_CalendarsTree.getModel()).nodeChanged(oNode);
								}
							} catch (Exception e1) { }
						}
						else 
						if (repcal.contains(oNode.toString().trim()))
						{
							try
							{
								(new repeatingMain(DPConfigF.this,
									 "Modify Periodic Calendar", true, oNode.toString(), true)).setVisible(true);
								if(!UserManager.m_sNewId.equals(""))
								{
									oNode.setUserObject(UserManager.m_sNewId);
									((DefaultTreeModel)m_CalendarsTree.getModel()).nodeChanged(oNode);
								}
							} catch (Exception e1) { }
						}
					} 
				}
				else	if(e.getSource() == m_PollerPackageTree)
				{
					selPath = m_PollerPackageTree.getPathForLocation(e.getX(), e.getY());
					oNode  = (DefaultMutableTreeNode)selPath.getLastPathComponent();

					if(oNode != null)
					{
						temp1		=	oNode.toString();
						temp1		=	temp1.trim();
						if (oNode.isLeaf() && !temp1.equals("ranges") && 
								!temp1.equals("filters") && !temp1.equals("calendars") &&
										!temp1.equals("services") )
						{
							temp2		=	(oNode.getParent()).getParent().toString();
						}
						temp2		= 	temp2 + " : " + temp1;
						temp2 	= 	temp2.trim();
				
						if ( temp1.equals("ranges") )
						{
							String m_packName = oNode.getParent().toString().trim();
							Vector rangeDetails = new Vector();
							if (! UserManager.m_oRangeTable.containsKey(m_packName))
							{
								rangeDetails = tempRangeTable;
							}
							else
							{
								rangeDetails = (Vector)UserManager.m_oRangeTable.get(m_packName);
							}
							SnmpDiscovery rframe = new SnmpDiscovery(rangeDetails, m_packName);
							rframe.setVisible(true);
						} 
						if (temp1.equals("filters") )
						{
							String m_packName = oNode.getParent().toString().trim();
							(new ModifyFilter(frame, "Poller Package Filters", true, m_packName)).setVisible(true);
						}

						if (getTreeLeaves(m_PollerPackageModel).contains(oNode.toString().trim()) )
						{	
							try 
							{		
								(new ModifyPollerPackage(new JFrame(),
									 "Modify Poller Package ", true, oNode.toString().trim())).setVisible(true);
								if(!UserManager.m_sNewId.equals(""))
								{
									oNode.setUserObject(UserManager.m_sNewId);
									((DefaultTreeModel)m_PollerPackageTree.getModel()).nodeChanged(oNode);
								}
							} catch(Exception e1) { }
					   	}		
					
						else 	if (getTreeLeaves(m_ServicesModel).contains(oNode.toString().trim()) )
						{
							Vector serviceDetails	=	(Vector)UserManager.m_oServiceTable.get(temp2);
							if (!UserManager.m_oServiceTable.containsKey(temp2))
							{
								serviceCheck 	= 	true;
								serviceDetails	=	checkServiceProperties(temp1, serviceProps);
							}
							propdialog = new JDialog(DPConfigF.getFrame(), "Modify Services Behavior:"  + temp1.toUpperCase(),false);
							dPanel = new DefaultManipPanel(serviceDetails, defaultColumns);  
																			
							JPanel gPanel = new JPanel(new BorderLayout()); 
 							gPanel.add(dPanel, BorderLayout.NORTH);
							JPanel buttonPanel = new JPanel(); 
                 					gPanel.add(buttonPanel, BorderLayout.SOUTH);

                 					JButton button = (JButton) buttonPanel.add(new JButton("  Ok  "));
							button.addActionListener(new ActionListener() {
								public void actionPerformed(ActionEvent e) {
									try 
									{
										if (serviceCheck)
										{
											UserManager.m_oServiceTable.put(temp2, dPanel.getTableData() );
											serviceCheck 	=	false;
										}
										else 
										{
											UserManager.m_oServiceTable.put(temp2, dPanel.getTableData() );
										} 

									}catch(Exception e2)
									{

									}
									propdialog.setVisible(false);
								}
							});

							JButton button1 = (JButton) buttonPanel.add(new JButton("Cancel"));
							button1.addActionListener(new ActionListener() {
								public void actionPerformed(ActionEvent e) {
									propdialog.setVisible(false);
								}
							});

							propdialog.getContentPane().add(gPanel, BorderLayout.CENTER); 
							propdialog.pack();
							propdialog.setLocationRelativeTo(frame);
							propdialog.setSize(400,350);
							propdialog.validate();
							propdialog.setResizable(false);
							propdialog.show();
						}
					}
				}
			}
		}
		
		void popupAction(MouseEvent e)
		{
			if (e.isPopupTrigger())
			{
				boolean	bPopup 	=	false;
				try {
					if(e.getSource() == m_PollerPackageTree)
					{
						TreePath selPath = m_PollerPackageTree.getPathForLocation(e.getX(), e.getY());
						DefaultMutableTreeNode oTreeNode   = (DefaultMutableTreeNode)selPath.getLastPathComponent();

						for (int i = 0; i < 6 ; i++ )
							m_oPopup.getComponent(i).setEnabled(true);


						if (nodeName == null) 
						{
							m_oPopup.getComponent(0).setEnabled(true);
						}
						else
						{
							m_oPopup.getComponent(0).setEnabled(false);
						}
				

						if(oTreeNode != null)
						{
							bPopup = true;
							((DefaultTreeSelectionModel)m_PollerPackageTree.getSelectionModel()).clearSelection();
							((DefaultTreeSelectionModel)m_PollerPackageTree.getSelectionModel()).setSelectionPath(selPath);

							if ( oTreeNode.toString().equals("ranges") )
							{
								m_oPopup.getComponent(0).setEnabled(true);
								m_oPopup.getComponent(1).setEnabled(true);
								m_oPopup.getComponent(2).setEnabled(false);
								m_oPopup.getComponent(3).setEnabled(true);
							}

							else if( oTreeNode.toString().equals("filters") )
							{
								m_oPopup.getComponent(0).setEnabled(false);
								m_oPopup.getComponent(1).setEnabled(false);
								m_oPopup.getComponent(2).setEnabled(false);
								m_oPopup.getComponent(3).setEnabled(false);

							}
							else
							//This statement is modified. See starting and ending comments. 
							//if ( 	oTreeNode.toString().equals("services") || oTreeNode.toString().equals("calendars") )
							//Added, start
							if ( 	oTreeNode.toString().equals("services") )
							{
								//this was existing.
								for (int i = 2; i < 6 ; i++ )
									m_oPopup.getComponent(i).setEnabled(false);
							}
							else
							if(	oTreeNode.toString().equals("calendars"))
							{
								//this is added
								for (int i = 0; i < 6 ; i++ )
									m_oPopup.getComponent(i).setEnabled(false);
							}
							//end of adding code		

							else 
							if ( 	getTreeLeaves(m_ServicesModel).contains(oTreeNode.toString().trim()) )
							{
								m_oPopup.getComponent(2).setEnabled(false);
							}
	
							else if (getTreeLeaves(m_PollerPackageModel).contains(oTreeNode.toString().trim()))
							{
								m_oPopup.getComponent(0).setEnabled(true);
								m_oPopup.getComponent(1).setEnabled(true);
								m_oPopup.getComponent(2).setEnabled(true);
								m_oPopup.getComponent(3).setEnabled(true);
							}
							else  
							{
								m_oPopup.getComponent(0).setEnabled(false);
								m_oPopup.getComponent(1).setEnabled(false);
								m_oPopup.getComponent(2).setEnabled(false);
								m_oPopup.getComponent(3).setEnabled(false);
								m_oPopup.getComponent(4).setEnabled(false);
								m_oPopup.getComponent(5).setEnabled(false);
							}
						}
					}
					else if(e.getSource() == m_CalendarsTree)
					{
						TreePath selPath = m_CalendarsTree.getPathForLocation(e.getX(), e.getY());
						DefaultMutableTreeNode oTreeNode   = (DefaultMutableTreeNode)selPath.getLastPathComponent();
						for (int i = 0; i < 6 ; i++ )
							m_oPopup.getComponent(i).setEnabled(true);

						if (nodeName == null) 
						{
							m_oPopup.getComponent(0).setEnabled(true);
						}
						else
						{
							m_oPopup.getComponent(0).setEnabled(false);
						}
				
						if(oTreeNode != null)
						{
							bPopup = true;
							((DefaultTreeSelectionModel)m_CalendarsTree.getSelectionModel()).clearSelection();
							((DefaultTreeSelectionModel)m_CalendarsTree.getSelectionModel()).setSelectionPath(selPath);
							if ( oTreeNode.toString().equals("Repeating") || oTreeNode.toString().equals("One-time") )
							{
								for (int i = 0; i < 6 ; i++ )
									m_oPopup.getComponent(i).setEnabled(false);
							}
							else 
							{
								for (int i = 0; i < 6 ; i++ )
									m_oPopup.getComponent(i).setEnabled(true);
							} 
						} 
					}
					else if(e.getSource() == m_DistPollerTree)
					{
							 
						TreePath selPath = m_DistPollerTree.getPathForLocation(e.getX(), e.getY());
						DefaultMutableTreeNode oTreeNode   = (DefaultMutableTreeNode)selPath.getLastPathComponent();
						for (int i = 0; i < 6 ; i++ )
							m_oPopup.getComponent(i).setEnabled(false);

						if (nodeName == null) 
						{
							//true to false, while changing Calendar
							m_oPopup.getComponent(0).setEnabled(false);
						}
						else
						{
							m_oPopup.getComponent(0).setEnabled(false);
						}
		
						if(oTreeNode != null)
						{
							bPopup = true;
							((DefaultTreeSelectionModel)m_DistPollerTree.getSelectionModel()).clearSelection();
							((DefaultTreeSelectionModel)m_DistPollerTree.getSelectionModel()).setSelectionPath(selPath);			

							if ( 	getTreeLeaves(m_PollerPackageModel).contains(oTreeNode.toString().trim()) )
							{
								m_oPopup.getComponent(2).setEnabled(false);
								m_oPopup.getComponent(5).setEnabled(false);
							}
							else
							{
								//true to false while changing Calendar code
								m_oPopup.getComponent(2).setEnabled(false);
								m_oPopup.getComponent(3).setEnabled(false);
								m_oPopup.getComponent(5).setEnabled(true);

							}
						}
				  
					}
				} catch(Exception e1) {
					bPopup = false;
				}

				if(bPopup)
				{
					x = e.getX();
					y = e.getY();
					m_oSource = e.getSource();
					try {
						m_oPopup.show((Component)e.getSource(),
								  e.getX(),
								  e.getY());
					} catch(Exception poe) {
					}
				}
			
			}
		}
	}

	void copy()
	{
		try
		{
			TreePath oPath =  m_oSelectionModel.getSelectionPath();
			if(oPath.getPathCount() < 1)
			{
				return;
			}

			copyNode	= (DefaultMutableTreeNode)oPath.getLastPathComponent();
			nodeName 	= copyNode.toString();
			cNodeIndex 	= top.getIndex(copyNode);
		}
		catch(Exception e)
		{
			stat.setText(" Must select a node first.");
			Toolkit.getDefaultToolkit().beep();
		}
	}

	void paste()
	{
		if(nodeName != null)
		{
			TreePath oPath =  m_oSelectionModel.getSelectionPath();
			if(oPath == null || oPath.getPathCount() < 1)
			{
				stat.setText(" Must select a node first.");
				Toolkit.getDefaultToolkit().beep();
				return;
			}
			DefaultMutableTreeNode oNode = (DefaultMutableTreeNode)oPath.getLastPathComponent();

			if(!((DefaultMutableTreeNode)oNode.getParent()).isRoot())
			{
				stat.setText(" Can't paste "+nodeName+" onto "+oNode.toString());
				Toolkit.getDefaultToolkit().beep();
				return;
			}

			if(nodeName.equals("ranges"))
			{
				DefaultMutableTreeNode clonePackage = new DefaultMutableTreeNode(nodeName);
				m_oTreeModel.insertNodeInto(clonePackage, oNode, oNode.getChildCount());
			}

			else
			{	
				pNodeIndex = top.getIndex(oNode);

				DefaultMutableTreeNode clonePackage = new DefaultMutableTreeNode(nodeName);
				int cloneSize =copyNode.getChildCount();

				//Added this code to display the full path of the copied tree.
				if(cNodeIndex == pNodeIndex)
				{
					for(int i=1; i <= cloneSize; i++)
					{
						clonePackage.add(copyNode.getNextNode());
					}
				}
	
				m_oTreeModel.insertNodeInto(clonePackage, top, cNodeIndex+1);
	
				if( cNodeIndex == pNodeIndex )
				{
					copyNode.add(copyNode.getNextNode());
				}

				clonePackage = null;
				copyNode = null;
				oNode = null;
				cNodeIndex = 0;
				pNodeIndex = 0;
				cloneSize = 0;
			}
		}

		else
		{
			stat.setText(" Can't paste: Clip board empty");
			Toolkit.getDefaultToolkit().beep();
		}
	}
	
	public Vector getTreeLeaves(DefaultTreeModel modelName) {

		MutableTreeNode root	=	(MutableTreeNode)modelName.getRoot();
		int index 			=	 modelName.getChildCount(root);
		Vector 	leaves	=	new Vector();

		for (int i = 0; i < index; i++) {
			Object node 	=	modelName.getChild(root, i);
			String st 		=	node.toString().trim();
			leaves.addElement(st);
		}

		return leaves;
	}

	public Vector checkServiceProperties(String parent, Vector properties)
	{
		Vector tempVector = new Vector();
		int i = 0;
		int size = properties.size();
		while ( i < size)
		{
			Vector temp = (Vector)properties.elementAt(i);
			int tempsize = temp.size();
			int j = 0;
			while( j < tempsize) 
			{
				Object str = temp.elementAt(j);
				if (str instanceof String)
				{
					String st = (String)str;
					if ((st.trim()).equals(parent))
					{
						tempVector = (Vector)temp.elementAt(++j);
					}
				}
				++j;
			}
			++i;
		}
		
		return tempVector;
	}

	public void callXmlParsers()
	{
		
		try
		{
			ice			=	new packageXmlParser();
			ice.parse("data/common/conf/packages.xml");

			pollerParser	=	new pollerXmlParser();
			pollerParser.parse("data/common/conf/pollersXML.xml");

			repeatingCalendar = 	new repcalXmlParser();
			repeatingCalendar.parse("data/common/conf/calendar.xml");


			onetimeCalendar	=	new onetimeXmlParser();
			onetimeCalendar.parse("data/common/conf/onetime.xml");

			serviceParser	=	new ServiceXmlParser();
			serviceParser.parse("data/common/conf/defaults.xml");



			UserManager.m_DCOLS =  defaultColumns;
			UserManager.m_ICOLS = (Vector)serviceParser.getIrangeCols();
			UserManager.m_ECOLS = (Vector)serviceParser.getErangeCols();
			UserManager.m_SCOLS = (Vector)serviceParser.getSpecificCols();
			UserManager.m_UCOLS = (Vector)serviceParser.getUrlCols();

			serviceProps	=	serviceParser.getServicesData();

			Vector temp 	= 	 serviceParser.getRangeDefData();

			tempRangeTable.add(temp);
			tempRangeTable.add(new Vector());
			tempRangeTable.add(new Vector());
			tempRangeTable.add(new Vector());
			tempRangeTable.add(new Vector());

		}
		catch(Exception ioe)
		{
			System.out.println(ioe);
		}
	}

	// Menu Bar + Tool Bar Panel

		
	JPanel createMenuBar() {

		
		JPanel p = new JPanel(new BorderLayout());
		JMenuBar menuBar = new JMenuBar();
		p.add( menuBar, BorderLayout.NORTH );
	
	  // File
		JMenu file = (JMenu) menuBar.add(new JMenu("File"));
		file.setMnemonic('i');
		JMenuItem save = (JMenuItem)
		file.add(new JMenuItem("Save"));
		save.setHorizontalTextPosition(JButton.RIGHT);
		save.setMnemonic('S');
		save.addActionListener(new ActionListener() {
    			public void actionPerformed(ActionEvent e) {
				save();
			}
		});

		file.addSeparator();
      	JMenuItem mi = (JMenuItem) file.add(new JMenuItem("Exit"));
     		mi.setMnemonic('x');
		mi.addActionListener(new ActionListener() {
    			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});

	  // Edit

		JMenu edit = (JMenu) menuBar.add(new JMenu("Edit"));
		edit.setMnemonic('E');

		JMenuItem delete = (JMenuItem)edit.add(new JMenuItem("Delete"));
		delete.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_D,
														ActionEvent.CTRL_MASK));
		delete.setHorizontalTextPosition(JButton.RIGHT);
		delete.setMnemonic('D');
		delete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					//delete code here
					delete();
				} catch(Exception e1) {
						
				}
			}
		});		
	
		JMenuItem copyItem = (JMenuItem)edit.add(new JMenuItem("Copy"));
		copyItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C,
														ActionEvent.CTRL_MASK));
		copyItem.setHorizontalTextPosition(JButton.RIGHT);
		copyItem.setMnemonic('C');
		copyItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					copy();
				} catch(Exception e1) {
						
				}
			}
		});		

		JMenuItem pasteItem = (JMenuItem)edit.add(new JMenuItem("Paste"));
		pasteItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_V,
														ActionEvent.CTRL_MASK));
		pasteItem.setHorizontalTextPosition(JButton.RIGHT);
		pasteItem.setMnemonic('P');
		pasteItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					paste();
				} catch(Exception e1) {
						
				}
			}
		});		

	 // Options Menu
		JMenu options = (JMenu) menuBar.add(new JMenu("View"));
	      	options.setMnemonic('V');
		
		JMenu lnf 	  =  (JMenu)options.add(new JMenu("Look and Feel"));
			lnf.setMnemonic('L');
			

       	JMenuItem metalMenuItem = (JMenuItem)lnf.add(new JMenuItem("Metal"));
		metalMenuItem.setActionCommand("Metal");
		metalMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_J,Event.CTRL_MASK ));
		metalMenuItem.addActionListener(new ActionListener() {
	  		public void actionPerformed(ActionEvent e) {
		           	BlueObject.setLookAndFeel(e.getActionCommand());
				SwingUtilities.updateComponentTreeUI(DPConfigF.this);
	    		}
		});

		
       	JMenuItem motifMenuItem = (JMenuItem) lnf.add(new JMenuItem("Motif"));
		motifMenuItem.setActionCommand("Motif");
		motifMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_M,Event.CTRL_MASK ));
		motifMenuItem.addActionListener(new ActionListener() {
	  		public void actionPerformed(ActionEvent e) {
		           	BlueObject.setLookAndFeel(e.getActionCommand());
				SwingUtilities.updateComponentTreeUI(DPConfigF.this);
	    		}
		});
		
        	JMenuItem windowsMenuItem = (JMenuItem) lnf.add(new JMenuItem("Windows"));
		windowsMenuItem.setActionCommand("Windows");
		windowsMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_W,Event.CTRL_MASK ));
		windowsMenuItem.addActionListener(new ActionListener() {
	  		public void actionPerformed(ActionEvent e) {
		           	BlueObject.setLookAndFeel(e.getActionCommand());
				SwingUtilities.updateComponentTreeUI(DPConfigF.this);
	    		}
		});
		
	  // Help
		JMenu help = (JMenu) menuBar.add(new JMenu("Help"));
		help.setMnemonic('H');
		JMenuItem about = (JMenuItem)
		help.add(new JMenuItem("About"));
		about.setHorizontalTextPosition(JButton.RIGHT);
		about.setMnemonic('t');
		about.addActionListener(new ActionListener() {
	  		public void actionPerformed(ActionEvent e) {
		           	new AboutDialog(new JFrame(), "About BlueBird");
	    		}
		});

	
		JToolBar toolBar = new JToolBar();
		addTool(toolBar, "save");
		toolBar.addSeparator( new Dimension(5, 5) );
		toolBar.addSeparator( new Dimension(5, 5) );
		addTool(toolBar, "copy");
		toolBar.addSeparator( new Dimension(3, 3) );
		addTool(toolBar, "paste");
		toolBar.addSeparator( new Dimension(3, 3) );
		addTool(toolBar, "delete");
		toolBar.addSeparator( new Dimension(5, 5) );
		toolBar.addSeparator( new Dimension(5, 5) );
		addTool(toolBar, "pluses");
		toolBar.addSeparator( new Dimension(3, 3) );
		addTool(toolBar, "plus");
		toolBar.addSeparator( new Dimension(3, 3) );
		addTool(toolBar, "minuses");
		toolBar.addSeparator( new Dimension(3, 3) );
		addTool(toolBar, "minus");
		toolBar.addSeparator( new Dimension(5, 5) );
		toolBar.addSeparator( new Dimension(5, 5) );
		addTool(toolBar, "newDP");
		toolBar.addSeparator( new Dimension(3, 3) );
		addTool(toolBar, "newTmpl");
		toolBar.addSeparator( new Dimension(3, 3) );
		addTool(toolBar, "newCal");
		toolBar.addSeparator( new Dimension(3, 3) );
		addTool(toolBar, "newCalPlus");
		toolBar.addSeparator( new Dimension(5, 5) );
		toolBar.addSeparator( new Dimension(5, 5) );
		addTool(toolBar, "newWizard");
		toolBar.addSeparator( new Dimension(5, 5) );

		p.setBorder(BorderFactory.createEtchedBorder());

		JPanel p1 = (JPanel)p.add(new JPanel());
		
		p1.setLayout(new BorderLayout());
		p1.add(toolBar, BorderLayout.SOUTH);
		
		return p;
	}
		
	public void addTool(JToolBar toolBar, String name) {
	
		String imageStr = "data" + System.getProperty("file.separator") + "images";
		JButton b = 
          	  (JButton) toolBar.add(
             	  new JButton(loadImageIcon(imageStr + System.getProperty("file.separator") + name + ".gif", name)));

		if ( name.equals("pluses") ) 	b.setToolTipText("expand all");
		else if ( name.equals("plus") ) b.setToolTipText("expand selected");
		else if ( name.equals("minuses") ) b.setToolTipText("collapse all");
		else if ( name.equals("minus") ) b.setToolTipText("collapse selected");
		//else if ( name.equals("newDP") ) b.setToolTipText("add a new dist poller");
		else if ( name.equals("newTmpl") ) b.setToolTipText("add a new poller package");
		//else if ( name.equals("newCal") ) b.setToolTipText("add a new Calendar service");
		//else if ( name.equals("newCalPlus") ) b.setToolTipText("add a new repeating Calendar");

		//These methods are added while changing to disable calendar in place of above method
		else if ( name.equals("newDP") ) 
		{
			b.setToolTipText("add a new poller wizard");
			if(m_dpExists)
			{
				b.setEnabled(false);
			}
		}
		else if ( name.equals("newCal") )  b.setEnabled(false);
		else if ( name.equals("newCalPlus") ) b.setEnabled(false);	

		else if ( name.equals("newWizard") ) 
		{
			b.setToolTipText("add a new poller wizard");
			if(m_dpExists)
			{
				b.setEnabled(false);
			}
		}

		else b.setToolTipText(name);

		b.setActionCommand(name);
		b.setMargin(insets0);
		b.addActionListener(new toolListener());
				
   	}

	class toolListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			if (e.getActionCommand().equals("newDP")) {
				try {
					MutableTreeNode root	= (MutableTreeNode)m_DistPollerModel.getRoot();
					int index = top1.getChildCount() + 1;
					String sName = "poller" + index;
					(new ModifyDistPoller(DPConfigF.this, "Add Distributed Poller", true, sName, true)).setVisible(true);
					sName = UserManager.m_sNewId;
					MutableTreeNode newNode = 
							new DefaultMutableTreeNode(sName);
					if(UserManager.m_iEditWhat == UserManager.DP)
					{
						UserManager.ok();
						m_DistPollerModel.insertNodeInto(newNode, top1, root.getChildCount());
						if(newNode.getChildCount()<=1)
						{
							m_DistPollerModel.reload(newNode);
						}

						stat.setText("New Distributed Poller "+sName+" added. click properties to modify.");
					}
				} catch (Exception e1) {
					Toolkit.getDefaultToolkit().beep();
				}
			}
			else if (e.getActionCommand().equals("delete")) {

				delete();

			} 
			if (e.getActionCommand().equals("newTmpl")) {

				stat.setText(" New PollerPackage..");
				try {
					MutableTreeNode root	= (MutableTreeNode)m_PollerPackageModel.getRoot();
					int index = top.getChildCount() + 1;

					String sName = "package" + index;
			
					(new ModifyPollerPackage(DPConfigF.this,
							 "Add Poller Package ", true, sName, true)).setVisible(true);

					sName = UserManager.m_sNewId;

					MutableTreeNode newNode = 
							new DefaultMutableTreeNode(sName);
					newNode.insert(new DefaultMutableTreeNode("calendars"), 0);
					newNode.insert(new DefaultMutableTreeNode("services"), 0);
					newNode.insert(new DefaultMutableTreeNode("filters"), 0);
					newNode.insert(new DefaultMutableTreeNode("ranges"), 0);

					if(UserManager.m_iEditWhat == UserManager.PP)
					{
						UserManager.ok();
						m_PollerPackageModel.insertNodeInto(newNode, top, root.getChildCount());
						if(newNode.getChildCount()<=1)
						{
							m_PollerPackageModel.reload(newNode);
						}
						stat.setText("New Pollerpackage "+sName+" added. click properties to modify.");
					}
				
				} catch (Exception e1) {
					Toolkit.getDefaultToolkit().beep();
				}
			}
			

			else if (e.getActionCommand().equals("plus")) {
				stat.setText(" Expand selected");
				try
				{
					TreePath oPath =  m_oSelectionModel.getSelectionPath();
					if( m_oSelectionModel == m_PollerPackageTree.getSelectionModel())
					{
						m_PollerPackageTree.expandPath(oPath);
					}
					else if( m_oSelectionModel == m_CalendarsTree.getSelectionModel())
					{
						m_CalendarsTree.expandPath(oPath);
					}
					else if( m_oSelectionModel == m_DistPollerTree.getSelectionModel())
					{
						m_DistPollerTree.expandPath(oPath);
					}
					
				}
				catch (Exception ex)
				{
					stat.setText(" Must select the node to be expanded.");
				}

			} 

			else if (e.getActionCommand().equals("minus")) {
				
				stat.setText(" Collapse selected");

				try
				{
					TreePath oPath =  m_oSelectionModel.getSelectionPath();
					if( m_oSelectionModel == m_PollerPackageTree.getSelectionModel())
					{
						m_PollerPackageTree.collapsePath(oPath);
					}
					else if( m_oSelectionModel == m_CalendarsTree.getSelectionModel())
					{
						m_CalendarsTree.collapsePath(oPath);
					}
					else if( m_oSelectionModel == m_DistPollerTree.getSelectionModel())
					{
						m_DistPollerTree.collapsePath(oPath);
					}
					
				}
				catch (Exception ex)
				{
					stat.setText(" Must select the node to be expanded.");
				}

			} 
			else if (e.getActionCommand().equals("pluses")) {
				
				stat.setText(" Expand all");
				DefaultMutableTreeNode	oRoot;
				TreePath oPath;
				{
					oRoot		= (DefaultMutableTreeNode)m_PollerPackageTree.getModel().getRoot();
					int	childCount	= oRoot.getChildCount();
					for(int i=0; i < childCount; i++)
					{
						oPath = m_PollerPackageTree.getPathForRow(i);
						DefaultMutableTreeNode oNode = (DefaultMutableTreeNode)oPath.getLastPathComponent();
						if(!oNode.isLeaf())
						{
							m_PollerPackageTree.expandPath(oPath);
							childCount+= oNode.getChildCount();
						}
					}
				}
				{
					oRoot		= (DefaultMutableTreeNode)m_CalendarsTree.getModel().getRoot();
					int	childCount	= oRoot.getChildCount();
					for(int i=0;i<childCount;i++)
					{
						oPath = m_CalendarsTree.getPathForRow(i);
						DefaultMutableTreeNode oNode = (DefaultMutableTreeNode)oPath.getLastPathComponent();
						if(!oNode.isLeaf())
						{
							m_CalendarsTree.expandPath(oPath);
							childCount += oNode.getChildCount();
						}
					}
				}
				{
					oRoot		= (DefaultMutableTreeNode)m_DistPollerTree.getModel().getRoot();
					int	childCount	= oRoot.getChildCount();
					for(int i=0; i < childCount; i++)
					{
						oPath = m_DistPollerTree.getPathForRow(i);
						DefaultMutableTreeNode oNode = (DefaultMutableTreeNode)oPath.getLastPathComponent();
						if(!oNode.isLeaf())
						{
							m_DistPollerTree.expandPath(oPath);
							childCount += oNode.getChildCount();
						}
					}
				}

			} 
			else if (e.getActionCommand().equals("minuses")) {
				
				stat.setText(" Collapse all");
				DefaultMutableTreeNode	oRoot;
				TreePath path1 = null;
				{
					oRoot = (DefaultMutableTreeNode)m_PollerPackageTree.getModel().getRoot();
					int count1 = oRoot.getChildCount();
					for (int i = 0; i < count1; i++) 
					{
						path1 = m_PollerPackageTree.getPathForRow(i);
						m_PollerPackageTree.collapsePath(path1);
					}
				}
				{
					oRoot = (DefaultMutableTreeNode)m_CalendarsTree.getModel().getRoot();
					int count1 = oRoot.getChildCount();
					for (int i = 0; i < count1; i++) 
					{
						path1 = m_CalendarsTree.getPathForRow(i);
						m_CalendarsTree.collapsePath(path1);
					}
				}
				{
					oRoot = (DefaultMutableTreeNode)m_DistPollerTree.getModel().getRoot();
					int count1 = oRoot.getChildCount();
					for (int i = 0; i < count1; i++) 
					{
						path1 = m_DistPollerTree.getPathForRow(i);
						m_DistPollerTree.collapsePath(path1);
					}
				}
			} 
			else if (e.getActionCommand().equals("save")) {
		
				save();
			}
			else if (e.getActionCommand().equals("newWizard")) {

				stat.setText(" Add a Poller Wizard");
			     		Wizard1 = new JDialog(DPConfigF.this, "New Distributed Poller Wizard Part 1", false);
           	        		JPanel groupPanel = new JPanel(new BorderLayout());

					dpWizardOne = new DPWizard1();
					groupPanel.add(dpWizardOne, BorderLayout.NORTH);
		
					JPanel buttonPanel = new JPanel(new FlowLayout());
                 			groupPanel.add(buttonPanel, BorderLayout.SOUTH);

                 			JButton button = (JButton) buttonPanel.add(new JButton("Next >"));
                 			button.addActionListener(new ActionListener() {
                  			public void actionPerformed(ActionEvent e) {
          		                		Wizard1.setVisible(false);
							
								dpNameString = dpWizardOne.getSelectedValues();
								callWizardTwo();
							
                 			}
					});

					JButton button1 = (JButton) buttonPanel.add(new JButton("Cancel"));
                 			button1.addActionListener(new ActionListener() {
                  			public void actionPerformed(ActionEvent e) {
          		                		Wizard1.setVisible(false);
                 			}

           				});
	    			
				Wizard1.getContentPane().add(groupPanel, BorderLayout.CENTER);
			
				Wizard1.setResizable(false);

			
				Wizard1.pack();
				Wizard1.setLocationRelativeTo(frame);
				Wizard1.setSize(450,200);
				Wizard1.show();
	    		}
			else if (e.getActionCommand().equals("newCal")) {

				try {
					MutableTreeNode root		= (MutableTreeNode)m_CalendarsModel.getRoot();
					int index = m_CalendarsModel.getChildCount(root);
					Object node[] = new Object[index];

					for (int i = 0; i < index; i++) {
						node[i] = m_CalendarsModel.getChild(root, i); 
					}
			
					int countnodes = m_CalendarsModel.getChildCount(node[1]);
					++countnodes;
					String sName ="one-time Calendar" + countnodes;

					(new calendarMain(DPConfigF.this, "Add One-time Calendar", true, sName, true)).setVisible(true);
					sName = UserManager.m_sNewId;
					MutableTreeNode newNode = 
							new DefaultMutableTreeNode(sName);
					if(UserManager.m_iEditWhat == UserManager.OCAL)
					{
						UserManager.ok();
						m_CalendarsModel.insertNodeInto(newNode, cc2, m_CalendarsModel.getChildCount(node[1]));
						if(newNode.getChildCount()<=1)
						{
							m_CalendarsModel.reload(cc2);
						}

						stat.setText("New One-time Calendar "+sName+" added. click properties to modify.");
					}
				} catch (Exception e1) {
					Toolkit.getDefaultToolkit().beep();
				}
				
			}
			else if (e.getActionCommand().equals("newCalPlus")) {

				try {
					MutableTreeNode root		= (MutableTreeNode)m_CalendarsModel.getRoot();
					int index = m_CalendarsModel.getChildCount(root);
					Object node[] = new Object[index];

					for (int i = 0; i < index; i++) {
						node[i] = m_CalendarsModel.getChild(root, i);
					}
			
					int countnodes = m_CalendarsModel.getChildCount(node[0]);
			
					++countnodes;
					String sName ="repeating Calendar" + countnodes;

					(new repeatingMain(DPConfigF.this, "Add Periodic Calendar", true, sName, true)).setVisible(true);
					sName = UserManager.m_sNewId;
					MutableTreeNode newNode = new DefaultMutableTreeNode(sName);
					if(UserManager.m_iEditWhat == UserManager.RCAL)
					{
						UserManager.ok();
						m_CalendarsModel.insertNodeInto(newNode, cc1, m_CalendarsModel.getChildCount(node[0]));
						if(newNode.getChildCount()<=1)
						{
							m_CalendarsModel.reload(cc1);
						}

						stat.setText("New Periodic Calendar "+sName+" added. click properties to modify.");
					}
				} catch (Exception e1) {
					Toolkit.getDefaultToolkit().beep();
				}

			}
			else if (e.getActionCommand().equals("copy")) {
				copy();
			}
			else if (e.getActionCommand().equals("paste")) {
				stat.setText(" Paste");
				paste();
			
			}
		}
	}

	public void save()
	{
	
		boolean flag = false;

		stat.setText(" Save");
		int ppsize = UserManager.m_oPP.size();

		Vector v_pack = new Vector();
		Enumeration enum1 = UserManager.m_oServiceTable.keys();

		while (enum1.hasMoreElements())
		{
			String psName = (String)enum1.nextElement();
			String st1 = psName.substring(0, psName.indexOf(":"));
			st1 = st1.trim();
			if ( v_pack.isEmpty() || !v_pack.contains(st1) )
			{
				v_pack.addElement(st1);
			}
			
		}

		MutableTreeNode root	=	(MutableTreeNode)m_DistPollerModel.getRoot();
		int index 			=	 m_DistPollerModel.getChildCount(root);
	
		for (int i = 0; i < index; i++) {
		
			TreeNode node 	=	root.getChildAt(i);
			if (node.isLeaf()) flag = true;
		}
		
			
		if ( UserManager.m_oViews.size() == ppsize && UserManager.m_oRangeTable.size() == ppsize 
					&& v_pack.size() == ppsize && flag == false ) 
		{	

			try 
			{
				new icebergXmlCreator();
			} 
			catch(Exception eoi) 
			{
				JOptionPane.showMessageDialog(DPConfigF.this, "Package file Exception" ,
					  "Problem with Package.XML file!!", JOptionPane.WARNING_MESSAGE);
			}
			
			try 
			{
				new pollerXmlCreator();
			} 
			catch(Exception eoi) 
			{
				JOptionPane.showMessageDialog(DPConfigF.this, "Poller file Exception" ,
					  "Problem with PollersXML.XML file!!", JOptionPane.WARNING_MESSAGE);
			}
		
		
		}
		else 
		{
			JOptionPane.showMessageDialog(DPConfigF.this, "You must enter values in Ranges, Filters & Services" 
						+ " \n branches of Poller Package and Distributed Pollers " 
					   + "\n must contain atleast one Poller Package " ,  "Reminder!!", JOptionPane.WARNING_MESSAGE);

		}
	}


	public void delete()
	{
		stat.setText(" Deleting...");
		try {
			TreePath path = null;
			if ( bool == 0 && bool1 == 0 && bool2 == 0 && bool3 == 0 ) 
			{
				Toolkit.getDefaultToolkit().beep();
				stat.setText(" select a node before deleting...");
				JOptionPane.showMessageDialog(DPConfigF.this, "select a node before deleting...",
				 		 "Reminder!!", JOptionPane.WARNING_MESSAGE);
			}
			if ( bool == 1 ) {
				try {
					temp2 = "";
					path = m_oSelectionModel.getSelectionPath();
					if(path.getPathCount() == 1) {
						JOptionPane.showMessageDialog(DPConfigF.this,
						"Can't remove root node!");
						return;
					}
					MutableTreeNode node = 
			 			(MutableTreeNode)path.getLastPathComponent();
				
					String nodeTitle = (node.toString()).trim();

					//Modified: ranges to be deleted - 11/14/2000 - vishwa			
					if ( nodeTitle.equals("services") ||
							nodeTitle.equals("filters") || nodeTitle.equals("calendars") )
					{
						stat.setText(" Cannot delete " + nodeTitle + ".");
						Toolkit.getDefaultToolkit().beep();
						JOptionPane.showMessageDialog(DPConfigF.this, "Cannot delete " + nodeTitle + ".",
							 	 "Reminder!!", JOptionPane.WARNING_MESSAGE);
					}
					else
					{
						int  result;
						String message = null;
						//modiefied this statement to allow to delete ranges. && !nodeTitle.equals("ranges")
						if (node.isLeaf() && 
							!nodeTitle.equals("filters") && !nodeTitle.equals("calendars") &&
								!nodeTitle.equals("services") )
						{
							temp2		=	((node.getParent()).getParent()).toString().trim();
						}
						if ( getTreeLeaves(m_PollerPackageModel).contains(nodeTitle) )
						{
							message = "If you delete this Poller Package, all \nDistributed Pollers using this" +
									" Package \nwill have this Package removed. \n\nAre you sure you want to delete? ";
						}
						else
						{
							message = "Are you sure you want to delete \n" +  " ' "  + nodeTitle + " ' " + " from the Poller Package";
						}
						result = JOptionPane.showConfirmDialog(DPConfigF.this, message , "Poller Package Delete Warn", JOptionPane.OK_CANCEL_OPTION);
				
						if(result == JOptionPane.OK_OPTION) {
	   						
							m_PollerPackageModel.removeNodeFromParent(node);

							//Here is the code to delete the poller package from distributed poller

							MutableTreeNode rootnode = (MutableTreeNode)m_DistPollerModel.getRoot();
							int index = m_DistPollerModel.getChildCount(rootnode);
							MutableTreeNode parentnode[] = new MutableTreeNode[index];
							for (int i = 0; i < index; i++) {
								parentnode[i] = (MutableTreeNode)m_DistPollerModel.getChild(rootnode, i);
							}
							//second level
							for (int count = 0; count < parentnode.length; count++ ) 
							{
								if (parentnode[count].isLeaf()) continue;
								int countnodes = m_DistPollerModel.getChildCount(parentnode[count]);
								MutableTreeNode childnode[] = new MutableTreeNode[countnodes];
								for (int j = 0; j < countnodes; j++ )
								{
									childnode[j] = (MutableTreeNode)m_DistPollerModel.getChild(parentnode[count],j);
									String childString = (childnode[j].toString()).trim();
									if ( childString.equals(nodeTitle) )
									{
										m_DistPollerModel.removeNodeFromParent(childnode[j]);
										break;
									}
								}  
							}// code ends here

							if ( getTreeLeaves(m_ServicesModel).contains(nodeTitle) )
							{
								if (UserManager.m_oServiceTable.containsKey(temp2 + " : " + nodeTitle))
								{
									UserManager.m_oServiceTable.remove(temp2 + " : " + nodeTitle);
								}
							}
							else
							{
								Enumeration en =  UserManager.m_oServiceTable.keys();
								while (en.hasMoreElements())
								{
									String str = (String)en.nextElement();
									if (str.startsWith(nodeTitle))
										UserManager.m_oServiceTable.remove(str);
										
								}
							} 
									
							// remove the data in ranges hashtable
							UserManager.m_oRangeTable.remove(nodeTitle);
						
							//remove the data in filters hashtable
							UserManager.delete(UserManager.VIEW, nodeTitle);
					
							// remove the data in pollerpackage hashtable
							UserManager.delete(UserManager.PP, nodeTitle);

							// remove the data in the calendars table
							if (UserManager.m_oCalendarsTable.containsKey(temp2 + " : " + nodeTitle + " : " + "O"))
							{
								UserManager.m_oCalendarsTable.remove(temp2 + " : " + nodeTitle+ " : " + "O");
							}
							else
							if (UserManager.m_oCalendarsTable.containsKey(temp2 + " : " + nodeTitle + " : " + "R"))
							{
								UserManager.m_oCalendarsTable.remove(temp2 + " : " + nodeTitle + " : " + "R");
							}

						}
						else if(result == JOptionPane.CANCEL_OPTION)
						{
    							stat.setText(" Delete Cancelled " );
						}
					}
				} catch(Exception e1) {
					Toolkit.getDefaultToolkit().beep();
					JOptionPane.showMessageDialog(DPConfigF.this, "select a service node before deleting ...",
					 	 "Reminder!!", JOptionPane.WARNING_MESSAGE);
					stat.setText(" select a node before deleting...");
				}
			}
			else if ( bool1 == 1) {
				Toolkit.getDefaultToolkit().beep();
				JOptionPane.showMessageDialog(DPConfigF.this, "Cannot delete services...",
					  "Reminder!!", JOptionPane.WARNING_MESSAGE);    
				stat.setText(" Cannot delete services...");
			}
			else if ( bool2 == 1 ) {
			   try
			   {
				path =  m_oSelectionModel.getSelectionPath();
				if(path.getPathCount() == 1) {
					JOptionPane.showMessageDialog(DPConfigF.this,
						"Can't remove root node!");
					return;
				}
				MutableTreeNode node = 
		 			(MutableTreeNode)path.getLastPathComponent();
				String nodeTitle = (node.toString()).trim();
				
				if ( node.isLeaf() && !node.toString().equals("Repeating") && !node.toString().equals("One-time") )
				{
                            int  result;
				    String message = "If you delete this Calendar, all \nPoller Packages using this" +
						" Calendar \nwill have this Calendar removed. \n\nAre you sure you want to delete? ";
				    result = JOptionPane.showConfirmDialog(DPConfigF.this, message , "Calendar Delete Warn", JOptionPane.OK_CANCEL_OPTION);
				    if(result == JOptionPane.OK_OPTION)
				    {
    						m_CalendarsModel.removeNodeFromParent(node);

					  	// here comes the code to remove the Calendar from poller package
						MutableTreeNode rootnode = (MutableTreeNode)m_PollerPackageModel.getRoot();
						int index = m_PollerPackageModel.getChildCount(rootnode);
						MutableTreeNode parentnode[] = new MutableTreeNode[index];

						for (int i = 0; i < index; i++) {
							parentnode[i] = (MutableTreeNode)m_PollerPackageModel.getChild(rootnode, i);
						}
	
						//second level
						for (int count = 0; count < parentnode.length; count++ ) 
						{
							if (parentnode[count].isLeaf()) continue;
							int countnodes = m_PollerPackageModel.getChildCount(parentnode[count]);
							MutableTreeNode childnode[] = new MutableTreeNode[countnodes];
								
							for (int j = 0; j < countnodes; j++ )
							{
								childnode[j] = (MutableTreeNode)m_PollerPackageModel.getChild(parentnode[count],j);
								if (childnode[j].isLeaf()) continue;
								String childString = (childnode[j].toString()).trim();
								if ( childString.equals("calendars") )
								{	
									int leafcount = m_PollerPackageModel.getChildCount(childnode[j]);
									MutableTreeNode leafnode[] = new MutableTreeNode[leafcount];
									for (int k = 0; k < leafcount;  k++ )
									{
										leafnode[k] = (MutableTreeNode)m_PollerPackageModel.getChild(childnode[j], k);
										String leafStr = (leafnode[k].toString()).trim();
										if ( leafStr.equals(nodeTitle) )
										{
											m_PollerPackageModel.removeNodeFromParent(leafnode[k]);
											break;											
										}
									}
								}
							}
							  
						}// code ends here
							
						if (UserManager.m_oOCAL.containsKey(node.toString().trim()) )
						{
							UserManager.delete(UserManager.OCAL, node.toString().trim());
						}
						else 	if (UserManager.m_oRCAL.containsKey(node.toString().trim()) )
						{
							UserManager.delete(UserManager.RCAL, node.toString().trim());
						}
						
						Enumeration cEnum = UserManager.m_oCalendarsTable.keys();
						while (cEnum.hasMoreElements())
						{
							String serviceStr = (String)cEnum.nextElement();
							serviceStr = serviceStr.trim();
							StringTokenizer stoken = new StringTokenizer(serviceStr, ":");
							String stok1 = stoken.nextToken();
							String stok2 = stoken.nextToken();
							String stok3 = stoken.nextToken();
							stok1 = stok1.trim();
							stok2 = stok2.trim();
							stok3 = stok3.trim();

							if ( stok2.equals(node.toString().trim()) )
							{
								UserManager.m_oCalendarsTable.remove(serviceStr);
							}
						}
				    }
				    else if(result == JOptionPane.CANCEL_OPTION) {
		    		      	stat.setText(" Delete Cancelled ");
				    }
				}
				else
				{
					stat.setText(" Cannot delete " + nodeTitle + "." );
				}
	              } catch(Exception e1) {
					Toolkit.getDefaultToolkit().beep();
			      	JOptionPane.showMessageDialog(DPConfigF.this, "select a node before deleting...",
			 	    		 "Reminder!!", JOptionPane.WARNING_MESSAGE);
					stat.setText(" select a node before deleting....");
			   }


			}
			else if ( bool3 == 1 ) {
				try {
					path =  m_oSelectionModel.getSelectionPath();
				
					if(path.getPathCount() == 1) {
						JOptionPane.showMessageDialog(DPConfigF.this,
							"Can't remove root node!");
						return;
					}
					MutableTreeNode oNode = 
						(MutableTreeNode)path.getLastPathComponent();
					int  result=0;
					String temp2 = "";
					String message = null;
						
					if (oNode.isLeaf() && !getTreeLeaves(m_DistPollerModel).contains(oNode.toString().trim()) )
					{
						temp2 = oNode.getParent().toString().trim();
						message = " Are you sure you want to delete \n " + " ' "+ oNode.toString() + " ' " + " from the Distributed Poller " ;
					}
					else	
					{
						temp2 = oNode.toString().trim();
					//This is commented to allow deletion of dp
					
						String nodeTitle = (oNode.toString()).trim();
						stat.setText(" Cannot delete " + nodeTitle + ".");
						Toolkit.getDefaultToolkit().beep();
						message = 	" Want to delete this Distributed Poller!! \n\n Are you sure? ";
						result = JOptionPane.showConfirmDialog(DPConfigF.this, message , "Distributed Poller Delete Warn", JOptionPane.OK_CANCEL_OPTION);
						JOptionPane.showMessageDialog(DPConfigF.this, "Cannot delete " + nodeTitle + ".",
							 	 "Reminder!!", JOptionPane.WARNING_MESSAGE);
						result = JOptionPane.CANCEL_OPTION;
					}

					if(result == JOptionPane.OK_OPTION)
					{
						m_DistPollerModel.removeNodeFromParent(oNode);
						UserManager.delete(UserManager.DP, oNode.toString().trim());
						Enumeration dpenum = UserManager.m_oDPP.keys();
						while (dpenum.hasMoreElements())
						{
							String dpstr = (String)dpenum.nextElement();
							StringTokenizer stok = new StringTokenizer(dpstr, ":");
							String stok1 = stok.nextToken();
							String stok2 = stok.nextToken();
							stok1 = stok1.trim(); stok2 = stok2.trim();
							if (temp2.equals(stok1))
							{
								UserManager.m_oDPP.remove(dpstr);	
							}
						}
					}
					else if(result == JOptionPane.CANCEL_OPTION)
					{
						stat.setText(" Delete Cancelled ");
					}
				} catch(Exception e1) {
					Toolkit.getDefaultToolkit().beep();
					JOptionPane.showMessageDialog(DPConfigF.this, "select a node before deleting...",
						  "Reminder!!", JOptionPane.WARNING_MESSAGE);
				}
			}
		}catch(Exception e3) {
			//System.out.println("problem with boolean values");
		}
	}

	public static void reloadModels() 
	{
		try 
	   	{
			m_CalendarsModel.reload(cc1);
			m_CalendarsModel.reload(cc2);
		//	m_DistPollerModel.reload();
		}
		catch(Exception e1) 
		{
			System.out.println("problem while reloading the models");
		}
	}	
	
	public void	callWizardTwo()	{
	
		MutableTreeNode root		= (MutableTreeNode)m_PollerPackageModel.getRoot();
		int index = m_PollerPackageModel.getChildCount(root);

		Object node[] = new Object[index];
		String packagelist[] = new String[index];

		for (int i = 0; i < index; i++) {
			node[i] = m_PollerPackageModel.getChild(root, i);
			packagelist[i] = node[i].toString();
		
		}
	
		Wizard2 = new JDialog(DPConfigF.this, "New Distributed Poller Wizard Part 2", false);
      	JPanel groupPanel = new JPanel(new BorderLayout());

		dpWizardTwo = new DPWizardTwo(packagelist);
		
		
		groupPanel.add(dpWizardTwo, BorderLayout.NORTH);

		JPanel buttonPanel = new JPanel(new FlowLayout());
      	groupPanel.add(buttonPanel, BorderLayout.SOUTH);

		JButton button = (JButton) buttonPanel.add(new JButton("< Back"));
      	button.addActionListener(new ActionListener() {
      		public void actionPerformed(ActionEvent e) {
				Wizard2.setVisible(false);
               		Wizard1.setVisible(true);
		     	}
		});

		JButton button1 = (JButton) buttonPanel.add(new JButton("Next >"));
      	button1.addActionListener(new ActionListener() {
      		public void actionPerformed(ActionEvent e) {
               		Wizard2.setVisible(false);
			      Object[] retvalue =  dpWizardTwo.getSelectedValues();
				callWizardThree(retvalue);
		     	}
		});

		JButton button2 = (JButton) buttonPanel.add(new JButton("Cancel"));
            button2.addActionListener(new ActionListener() {
            	public void actionPerformed(ActionEvent e) {
          	     		Wizard2.setVisible(false);
            	}
		});
		Wizard2.getContentPane().add(groupPanel, BorderLayout.CENTER);
		Wizard2.setResizable(false);

		Wizard2.pack();
		Wizard2.setLocationRelativeTo(frame);
		Wizard2.setSize(600,300);
		Wizard2.show();
	}
			

	public void  callWizardThree(Object[] temp) {
	
		retval = temp;
		Wizard3 = new JDialog(DPConfigF.this, "New Distributed Poller Wizard Part 3", false);
           	JPanel groupPanel = new JPanel(new BorderLayout());

		dpWizardThree = new DPWizardThree();
		groupPanel.add(dpWizardThree, BorderLayout.NORTH);
		
		JPanel buttonPanel = new JPanel(new FlowLayout());
            groupPanel.add(buttonPanel, BorderLayout.SOUTH);

            JButton button = (JButton) buttonPanel.add(new JButton("Finish"));
            button.addActionListener(new ActionListener() {
            	public void actionPerformed(ActionEvent e) {
          	     		Wizard3.setVisible(false);
				String returnValue = dpWizardThree.getSelectedValues();
			
				//poller addition code comes here
				stat.setText(" Distributed Poller");

				try {

					MutableTreeNode root		= (MutableTreeNode)m_DistPollerModel.getRoot();
					int index = top1.getChildCount() + 1;
				
					MutableTreeNode newNode = 
							new DefaultMutableTreeNode(dpNameString);
					for (int i = 0; i < retval.length && retval[i] != null; i++) 
						newNode.insert(new DefaultMutableTreeNode(retval[i]), 0 );
										
					m_DistPollerModel.insertNodeInto(newNode, top1, root.getChildCount());
					m_DistPollerModel.reload();

				} catch (Exception e1) {

					System.out.println("you must select a node before adding...");
				}

			}
		});

		JButton button1 = (JButton) buttonPanel.add(new JButton("Cancel"));
            button1.addActionListener(new ActionListener() {
            	public void actionPerformed(ActionEvent e) {
          	     		Wizard3.setVisible(false);
            	}
		});

		Wizard3.getContentPane().add(groupPanel, BorderLayout.CENTER);
		Wizard3.setResizable(true);
		Wizard3.pack();
		Wizard3.setLocationRelativeTo(frame);
		Wizard3.setSize(450,200);
		Wizard3.show();

	}

	public ImageIcon loadImageIcon(String filename, String description)
	{

		 return new ImageIcon(filename, description);
	}
		
	public static JFrame getFrame() 
	{

	     	return frame1;
  	}
	class myTreeListener implements TreeModelListener 
	{

		public void treeNodesInserted(TreeModelEvent e) {}

		public void treeNodesRemoved(TreeModelEvent e) {}

		private void showInsertionOrRemoval(TreeModelEvent e,	String s) {	}

		public void treeNodesChanged(TreeModelEvent e) 
		{
			UserManager.m_sOldId = UserManager.m_sOldId.trim();
			UserManager.m_sNewId = UserManager.m_sNewId.trim();

			 DefaultMutableTreeNode oNode;
       		 oNode = (DefaultMutableTreeNode)
            		(e.getTreePath().getLastPathComponent());
        				
     			 try {
           			 int index = e.getChildIndices()[0];
     	     			 oNode = (DefaultMutableTreeNode)(oNode.getChildAt(index));
       		 }
			 catch (NullPointerException exc) {}

			String nodeName = oNode.toString().trim();

			if(e.getSource() == m_PollerPackageTree.getModel())
			{
				if(UserManager.m_iEditWhat == UserManager.PP) 
				{
					UserManager.ok();
				}
				else if( !UserManager.m_sNewId.equals(nodeName) )
				{
					if( (!UserManager.m_sOldId.equals( nodeName) ) && UserManager.m_oPP.containsKey(nodeName) )
					{
						stat.setText("Can't rename "+ UserManager.m_sOldId +" to "+ nodeName +" <-- Poller Package already exists.");
						Toolkit.getDefaultToolkit().beep();
						oNode.setUserObject(UserManager.m_sOldId);
						m_PollerPackageTree.setEditable(false);
						UserManager.cancel();
						return;
					}
					m_PollerPackageTree.setEditable(false);
					UserManager.modify(UserManager.PP, UserManager.m_sOldId);
					UserManager.m_sBuffer= (String)UserManager.m_oPP.get(UserManager.m_sOldId);
					UserManager.m_sNewId = nodeName;
					UserManager.ok();
				}

				//update the filter hashtable keys
				if(UserManager.m_oViews.containsKey(UserManager.m_sOldId))
				{
					String filterStr = (String)UserManager.m_oViews.get(UserManager.m_sOldId);
					UserManager.m_oViews.remove(UserManager.m_sOldId);
					UserManager.m_oViews.put(UserManager.m_sNewId, filterStr);
				}
			
				
				
				//update the ranges hashtable keys
				if(UserManager.m_oRangeTable.containsKey(UserManager.m_sOldId))
				{
					Vector rangeVector1 = (Vector)UserManager.m_oRangeTable.get(UserManager.m_sOldId);
					UserManager.m_oRangeTable.remove(UserManager.m_sOldId);
					UserManager.m_oRangeTable.put(UserManager.m_sNewId, rangeVector1);
				}
							
	
				//update the services hashtable
				Enumeration sEnum = UserManager.m_oServiceTable.keys();
				while (sEnum.hasMoreElements())
				{
					String serviceStr = (String)sEnum.nextElement();
					serviceStr = serviceStr.trim();
					StringTokenizer stoken = new StringTokenizer(serviceStr, ":");
					String stok1 = stoken.nextToken();
					String stok2 = stoken.nextToken();
					stok1 = stok1.trim();
					stok2 = stok2.trim();
					if ( stok1.equals(UserManager.m_sOldId) )
					{
						Vector tempVect = (Vector)UserManager.m_oServiceTable.get(serviceStr);
						UserManager.m_oServiceTable.remove(serviceStr);
						UserManager.m_oServiceTable.put(UserManager.m_sNewId + " : " + stok2, tempVect);
					}
				}

				//update the calendars table
				Enumeration cEnum = UserManager.m_oCalendarsTable.keys();
				while (cEnum.hasMoreElements())
				{
					String serviceStr = (String)cEnum.nextElement();
					serviceStr = serviceStr.trim();
					StringTokenizer stoken = new StringTokenizer(serviceStr, ":");
					String stok1 = stoken.nextToken();
					String stok2 = stoken.nextToken();
					String stok3 = stoken.nextToken();
					stok1 = stok1.trim();
					stok2 = stok2.trim();
					stok3 = stok3.trim();

					if ( stok1.equals(UserManager.m_sOldId) )
					{
						String calType = (String)UserManager.m_oCalendarsTable.get(serviceStr);
						UserManager.m_oCalendarsTable.remove(serviceStr);
						UserManager.m_oCalendarsTable.put(UserManager.m_sNewId + " : " + stok2 + " : " + stok3, calType);
					}
				}

				//update the dpp hashtable keys
				Enumeration denum1 = UserManager.m_oDPP.keys();
				while (denum1.hasMoreElements())
				{
					String stName = (String)denum1.nextElement();
					StringTokenizer stok = new StringTokenizer(stName, ":");
			
					String stok1 = (String)stok.nextToken();
					String stok2 = (String)stok.nextToken();
					stok1 = stok1.trim();
					stok2 = stok2.trim();
							
					if ( stok2.equals(UserManager.m_sOldId) )
					{
						UserManager.m_oDPP.remove(stName);
						UserManager.m_oDPP.put(stok1 + " : " + UserManager.m_sNewId , "package");
					}
				}
			
				//update the nodes in distributed poller tree
				updateTree(UserManager.DP, UserManager.m_sOldId, UserManager.m_sNewId);
				UserManager.m_sOldId = UserManager.m_sNewId;
			
			}
		
			//starts updating distpolelr treee info
			else	if(e.getSource() == m_DistPollerTree.getModel())
			{
				if(UserManager.m_iEditWhat == UserManager.DP) 
				{
					UserManager.ok();
				}
				else if( !UserManager.m_sNewId.equals(nodeName) )
				{
					if( (!UserManager.m_sOldId.equals( nodeName) ) && UserManager.m_oDP.containsKey(nodeName) )
					{
						stat.setText("Can't rename "+ UserManager.m_sOldId +" to "+ nodeName +" <-- Dist Poller already exists.");
						Toolkit.getDefaultToolkit().beep();
						oNode.setUserObject(UserManager.m_sOldId);
						m_DistPollerTree.setEditable(false);
						UserManager.cancel();
						return;
					}
					m_DistPollerTree.setEditable(false);
					UserManager.modify(UserManager.DP, UserManager.m_sOldId);
					UserManager.m_sBuffer= (String)UserManager.m_oDP.get(UserManager.m_sOldId);
					UserManager.m_sNewId = nodeName;
					UserManager.ok();
				
				}

				Enumeration denum = UserManager.m_oDPP.keys();
				while (denum.hasMoreElements())
				{
					String stName = (String)denum.nextElement();
					StringTokenizer stok = new StringTokenizer(stName, ":");
			
					String stok1 = (String)stok.nextToken();
					String stok2 = (String)stok.nextToken();
					stok1 = stok1.trim();
					stok2 = stok2.trim();
							
					if ( stok1.equals(UserManager.m_sOldId) )
					{
						UserManager.m_oDPP.remove(stok1 + " : " + stok2);
						UserManager.m_oDPP.put(UserManager.m_sNewId + " : " + stok2, "package");
					}
				}

				UserManager.m_sOldId = UserManager.m_sNewId;

			}

			//ends here
		}
		public void treeStructureChanged(TreeModelEvent e) {	}
		
		private void updateTree(int whichTree, String oldNode, String newNode)
		{
			if(whichTree<0 || whichTree>6)
			{
				return;
			}

			DefaultMutableTreeNode oRoot = null;
			 if(whichTree == UserManager.DP)
			{
				oRoot = (DefaultMutableTreeNode)m_DistPollerTree.getModel().getRoot();
			}

			for(Enumeration e1=oRoot.children(); e1.hasMoreElements(); )
			{
				DefaultMutableTreeNode oParent = (DefaultMutableTreeNode)e1.nextElement();
				if(!oParent.isLeaf())
				{
					for(Enumeration e2=oParent.children(); e2.hasMoreElements(); )
					{
						DefaultMutableTreeNode temp = (DefaultMutableTreeNode)e2.nextElement();
						if(temp.toString().trim().equals(oldNode))
						{
							temp.setUserObject(newNode);
							if(whichTree == UserManager.DP)
							{
								((DefaultTreeModel)m_DistPollerTree.getModel()).reload(temp);
							}
						}
					}
				}
			}
		}

	}

	public static void main(String args[])	
	{
		WindowListener l = new WindowAdapter() 
		{
	    		public void windowClosing(WindowEvent e) 
			{
				//frame.dispose();
				System.exit(1);
			}
		};

		DPConfigF frames = new DPConfigF();
		frames.setTitle("Distributed Poller Configuration");
		frames.addWindowListener(l);
	
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		frames.setLocation(screenSize.width/2 - WIDTH/2,
			  screenSize.height/2 - HEIGHT/2);
		frames.setSize(WIDTH, HEIGHT);
		frames.setVisible(true);
	}
}

	

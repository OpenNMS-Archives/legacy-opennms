//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.common.components;

import javax.swing.*;
import javax.swing.text.*;

import java.awt.*;
import java.awt.event.*;

import java.util.*;

/**
 * <pre>BBTextField is the default editor component for all text fields in
 * tables
 *
 * - This does not accept 'enter' 
 * - provides a default implementation for checking validity of 
 *   its contents - these methods are overridden by its extensions to
 *   provide format checks </pre>
 *
 * @author Sowmya
 *
 */
public class BBTextField extends JTextField 
{
	public void BBTextFieldInit()
	{
		Keymap map = getKeymap();

		// Do not accept VK_ENTER
		KeyStroke enter = KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0);
		map.removeKeyStrokeBinding(enter);
	}

	public BBTextField()
	{
		super();

		BBTextFieldInit();
	}

	public BBTextField(int columns)
	{
		super(columns);

		BBTextFieldInit();
	}

	/**
	 * Returns true if not empty!
	 * subclasses that restrict values will need to override this function
	 * to provide appropriate validation
	 */
	public boolean isValid()
	{ 
		// subclasses that restrict values will need to
		// override this function

		if (!getText().equals(""))
			return true;
		else
			return false;
	}
		
	/**
	 * Static method to check if the value passed would pass validation
	 */
	public static boolean checkFormat(String value)
	{
		return true;
	}
}

//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.admin.servmodel.components;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.table.*;
import javax.swing.event.*;

import java.util.Vector;

import org.opennms.bb.eui.common.components.*;

/**
 * <pre>SMBManipTable extends BBManipTable  
 *
 * - Sets the table size each time the table data is changed
 * - Sets a text editr for the interval columns
 * - Checks values when 'setValue()' is called
 * - Provides a 'checkAutoFlow()' method to check if there are any holes in
 *   in the intervals
 *
 * @author Sowmya
 *
 */
public class SMBManipTable extends BBManipTable
{
	private boolean	bAutoFlowOn	=false;

	private final int FROM_COL 		= 1;
	private final int TO_COL 		= 2;
	private final int BEH_COL 		= 3;

	final String REMOVE_STR="<remove>";

	public SMBManipTable(Vector inpColNames)
	{
		super(inpColNames);
		SMBManipTableInit();
	}
	
	public SMBManipTable(Vector inpRowData, Vector inpColNames)
	{
		super(inpRowData, inpColNames);

		SMBManipTableInit();
	}

	void SMBManipTableInit()
	{
		getModel().addTableModelListener(new TableModelListener()
		{
			public void tableChanged(TableModelEvent e)
			{
				// everytime data is changed, set table width
				// setDataVector() causes table column widths to change
				if (e.getColumn() == e.ALL_COLUMNS && e.getType() == e.INSERT)
				{
					setTableColumnWidths(getSize().width, getSize().height);
					sizeColumnsToFit(-1);

					// Attach a cell renderer for the first(arrow) column
					getColumnModel().getColumn(0).setCellRenderer(new BBArrowRenderer());
				}
			}
		});
	}



	public TableCellEditor getCellEditor(int row, int col)
	{

		if (col == FROM_COL || col == TO_COL || col == BEH_COL)
		{
			TimeIntervalTextField colText = new TimeIntervalTextField();
			return new BBColumnEditor(colText);
		}

		else
			return super.getCellEditor(row, col);

	}

	public void setValueAt(Object value, int row, int col)
	{
		int iNumRows = getRowCount();

		String valueStr = value.toString();
		if (valueStr.equals(REMOVE_STR) && !(row == iNumRows-1 && col == BEH_COL))
		{
			JOptionPane.showMessageDialog(null, 
						"Invalid value in row \'" + (row+1) + "\'\n" + 
						"Value cannot be " + REMOVE_STR + " except at the end", 
						"Value Invalid", 
						JOptionPane.WARNING_MESSAGE);

			return;
		}

		// a '0' value is not permitted anywhere except at the start
		if (valueOf(valueStr).equals("0") && ((row != 0) || (col != FROM_COL)))
		{
			JOptionPane.showMessageDialog(null, 
						"Invalid value in row \'" + (row+1) + "\'\n" + 
						"Value cannot be '0' except at the start",
						"Value Invalid", 
						JOptionPane.WARNING_MESSAGE);


			return;
		}

		// a '-' value is not permitted anywhere except at the end
		if (valueStr.equals("-") && (row != iNumRows-1 ))
		{
			JOptionPane.showMessageDialog(null, 
						"Invalid value in row \'" + (row+1) + "\'\n" + 
						"Value cannot be '-' except at the end", 
						"Value Invalid", 
						JOptionPane.WARNING_MESSAGE);

			return;
		}


		super.setValueAt(value, row, col);

		if (bAutoFlowOn)
		{
			if (col == TO_COL)
			{
				int	nextRow  = row + 1;
				if (nextRow < iNumRows)
				{
					super.setValueAt(value, nextRow, FROM_COL);
				}
			}

			else if (col == FROM_COL)
			{
				int	prevRow  = row - 1;
				if (prevRow > -1 )
				{
					super.setValueAt(value, prevRow, TO_COL);
				}
			}

		}

	}

	public void setDataVector(Vector inpData)
	{
		Vector colNames = new Vector(4);
		colNames.add("");
		colNames.add("From");
		colNames.add("To");
		colNames.add("Behaviour");
		

		Vector data = new Vector();

		if (inpData != null)
		{
			int iNumRows = inpData.size();
			// Account for the arrow col
			for (int iIndex=0; iIndex<iNumRows; iIndex++)
			{
				Vector temp = (Vector)inpData.elementAt(iIndex);
				
				Vector temp1 = (Vector)temp.clone();
				temp1.add(0, Boolean.FALSE);
				data.add(temp1);
			}
		}

		infoTableModel.setDataVector(data, colNames);
	}

	public void setAutoFlowOn()
	{
		bAutoFlowOn=true;
	}

	public void setAutoFlowOff()
	{
		bAutoFlowOn=false;
	}
	
	public boolean checkAutoFlow()
	{
		requestFocus();

		int iNumRows = getRowCount();
		boolean bRet = true;

		String curFrom;
		String curTo;
		String curBeh;
		String nextFrom;
		String nextTo;

		for(int iIndex=0; iIndex<iNumRows-1; iIndex++)
		{
			curFrom = (String)getValueAt(iIndex, FROM_COL);
			curTo 	= (String)getValueAt(iIndex, TO_COL);
			curBeh	= (String)getValueAt(iIndex, BEH_COL);

			nextFrom = (String)getValueAt(iIndex+1, FROM_COL);
			nextTo   = (String)getValueAt(iIndex+1, TO_COL);

			// if first row, should start with a 0
			if ((iIndex == 0) && (!valueOf(curFrom).equals("0")))
			{
				JOptionPane.showMessageDialog(null, 
						"Intervals should start at 0", 
						"Check Flow", 
						JOptionPane.WARNING_MESSAGE);


				bRet = false;
				break;
			}

			// if first row, check out the units
			if ((iIndex == 0) && !checkUnits(curFrom, curTo))
			{
				JOptionPane.showMessageDialog(null, 
						"Values not correct in the range \'" + 
						curFrom + "\' - \'" + curTo +"\'",
						"Check Flow", 
						JOptionPane.WARNING_MESSAGE);


				bRet = false;
				break;
			}
			// if not last row, 'from' should be less than 'to'
			if ((iIndex < iNumRows-1) && !checkIfCorrect(curFrom, curTo))
			{
				JOptionPane.showMessageDialog(null, 
						"Values not correct in the range \'" + 
						curFrom + "\' - \'" + curTo +"\'",
						"Check Flow", 
						JOptionPane.WARNING_MESSAGE);


				bRet = false;
				break;
			}

			// if not last row, current 'to' should be equal to next 'from'
			if ((iIndex < iNumRows -1) && !curTo.equals(nextFrom))
			{
		 		JOptionPane.showMessageDialog(null, 
						"Values not contiguous in the range \'" + 
						curFrom + "\' - \'" + curTo +"\'",
						"Check Flow", 
						JOptionPane.WARNING_MESSAGE);

				bRet = false;
				break;
			}
		}

		// check that values end in a '-' and REMOVE_STR
		int iIndex  = iNumRows-1;
		curTo 	= (String)getValueAt(iIndex, TO_COL);
		curBeh	= (String)getValueAt(iIndex, BEH_COL);

		if (!(curTo.equals("-") && curBeh.equals(REMOVE_STR)))
		{
			JOptionPane.showMessageDialog(null, 
						"Values should end with a '-' and " + REMOVE_STR,
						"Check Flow", 
						JOptionPane.WARNING_MESSAGE);

				bRet = false;
		}

		return bRet;
	}

	String valueOf(String str)
	{
		return str.substring(0, str.length()-1);
	}

	boolean checkUnits(String from, String to)
	{
		boolean bRet=false;

		char fromID = from.charAt(from.length()-1);
		char toID   = to.charAt(to.length()-1);
		
		if (fromID == toID)
			bRet = true;

		else if (fromID == 'm')
		{
			if (toID == 's')
				bRet = false;
			else
				bRet = true;
		}

		else if (fromID == 'h')
		{
			if (toID == 's' || toID =='m')
				bRet = false;
			else
				bRet = true;
		}

		else if (fromID == 'd')
		{
			if (toID != 'd')
				bRet = false;
			else
				bRet = true;
		}
		
		return bRet;
	}

	boolean checkIfCorrect(String from, String to)
	{
		long fromL  = convertToSeconds(from);
		long toL	= convertToSeconds(to);
		
		if (fromL < toL)
			return true;
		else
			return false;

	}

	long convertToSeconds(String str)
	{
		long retValue=0;

		int len = str.length();
		char id = str.charAt(len-1);
		
		String valStr = str.substring(0, len-1);
		int value= (new Integer(valStr)).intValue();

		if (id == 's')
		{
			retValue = value;
		}

		else if (id == 'm')
		{
			retValue = value * 60;
		}

		else if (id == 'h')
		{
			retValue = value * 60 * 60;
		}

		else if (id == 'd')
		{
			retValue = value * 60 * 60 * 24;
		}

		return retValue;
	}

	public void addRow()
	{
		Vector data = new Vector();

		int iSelRow = getSelectedRow();

		if (bAutoFlowOn)
		{
			int	iNextRow;
			int	iRowCount = getRowCount();

			if (iSelRow == -1)
			{
				iSelRow  = iRowCount-2;
				iNextRow = iRowCount-1;
			}
			else if (iSelRow == iRowCount-1)
			{
				iSelRow  = iRowCount-1;
				iNextRow = iRowCount-2;
			}
			else
			{
				iNextRow = iSelRow + 1;
				if(iNextRow >= iRowCount)
					iNextRow = iRowCount - 1;
			}

			data.add(getValueAt(iSelRow, TO_COL));
			data.add(getValueAt(iNextRow, FROM_COL));
			data.add("0s");
		}
		else
		{
			data.add("0m");
			data.add("0m");
			data.add("0s");
		}

		if (iSelRow == -1)
		{
			// select last but one row if none is selected
			int iLBORow = getRowCount()-2;		
			setRowSelectionInterval(iLBORow, iLBORow);
		}
		pasteRow(data);
	}


	/** 
	 * Inserts the vector next to the currently selected row (if not last row)
	 */
	public void pasteRow(Vector data)
	{
		int iRowLoc=0;

		int iNumRows = getRowCount();

		int iCurSelectedRow = getSelectedRow();

		if (iCurSelectedRow <= -1 ) // if no rows
			iRowLoc = iNumRows;

		else if (iCurSelectedRow == (iNumRows-1)) // if last row
			iRowLoc = iCurSelectedRow;

		else
			iRowLoc = iCurSelectedRow + 1;
			
		Vector newData = new Vector(data);

		// arrow
		newData.add(0, Boolean.FALSE);

		// Insert
		infoTableModel.insertRow(iRowLoc, newData);

		// select 'from' col
		selectCellAt(iRowLoc, FROM_COL);
	}

	/**
	 * Removes the row# iRow
	 */
	public void removeRow(int iRow)
	{
		int iSelRow;
		int iNumRows = getRowCount();

		Vector row = (Vector)getTableModel().getDataVector().elementAt(iRow);
		
		// first and rows are not deletable
		if (iRow == 0 || iRow == (iNumRows-1))
			return;
		
		else // set row to be selected next
			iSelRow = iRow;

		// Remove
		infoTableModel.removeRow(iRow);

		// set previous value
		if (bAutoFlowOn)
		{
			int iPrevRow = iSelRow-1;
			if (iPrevRow >= 0 && iPrevRow < getRowCount())
			{
				Object prevVal = getValueAt(iPrevRow, TO_COL);
				setValueAt(prevVal, iSelRow, FROM_COL);
			}

			// if last row, set '-'
			if (iSelRow == iNumRows-1)
			{
				setValueAt(new String("-"), iSelRow, TO_COL);
			}
		}

		// Select next row
		setRowSelectionInterval(iSelRow, iSelRow);

		// Select first column
		setColumnSelectionInterval(FROM_COL, FROM_COL);

		//
		iLastEditingRow = iSelRow;
		iLastEditingCol = FROM_COL;
	}

	protected void setHeaderToolTips()
	{
		int iNumCols = getColumnCount();

		TableColumnModel colModel = getColumnModel();

		for (int iIndex=0; iIndex<iNumCols; iIndex++)
		{
			String value = ((String)getColumnName(iIndex)).toLowerCase();

			TableCellRenderer hdrRenderer = columnModel.getColumn(iIndex).getHeaderRenderer();
			if(hdrRenderer == null)
				continue;

			Component hdrComponent = hdrRenderer.getTableCellRendererComponent(this, value, false, false, 0, 0);

			//check if tooltip can be set
			if (!(hdrComponent instanceof JComponent))
				continue;

			JComponent comp = (JComponent)hdrComponent;
			if (comp.getToolTipText() != null)
				continue;

			if (iIndex == FROM_COL)
			{
				comp.setToolTipText("Start Time");
			}

			else if (iIndex == TO_COL)
			{
				comp.setToolTipText("End Time");
			}

			else if (iIndex == BEH_COL)
			{
				comp.setToolTipText("Retry Interval");
			}
		}
	}
	
}


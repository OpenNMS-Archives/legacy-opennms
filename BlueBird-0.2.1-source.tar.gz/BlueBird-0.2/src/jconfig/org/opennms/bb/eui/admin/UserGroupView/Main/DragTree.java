//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
package org.opennms.bb.eui.admin.UserGroupView.Main;

import java.io.*;
import java.awt.dnd.*;
import java.awt.datatransfer.*;
import java.awt.Point;
import javax.swing.tree.*;
import javax.swing.JTree;

public class DragTree extends JTree
{

	DragSource				m_oDragSource;

	TreeGestureListener		m_oGestureListener;
	TreeSourceListener		m_oSourceListener;

	DefaultMutableTreeNode	m_oDragNode = null;

	class TreeGestureListener implements DragGestureListener
	{
		public void dragGestureRecognized(DragGestureEvent e)
		{
			if(isEditing())
			{
				cancelEditing();
			}
			Point					pNodeLocation	= e.getDragOrigin();
			DefaultMutableTreeNode	oTreeNode		= getTreeNode(pNodeLocation);

			if (oTreeNode != null)
			{
				m_oDragNode = oTreeNode;
				m_oDragSource.startDrag(e,
									 DragSource.DefaultCopyDrop,
									 new StringSelection(oTreeNode.toString()),
									 m_oSourceListener);
			}
		}
	}

	class TreeSourceListener implements DragSourceListener
	{
		public void dragDropEnd(DragSourceDropEvent e)
		{
		}
		public void dragEnter(DragSourceDragEvent e)
		{
		}
		public void dragExit(DragSourceEvent e)
		{
		}
		public void dragOver(DragSourceDragEvent e)
		{
		}
		public void dropActionChanged(DragSourceDragEvent e)
		{
		}
	}
 
	public DragTree(TreeNode root)
	{
		super(root);

		m_oGestureListener		= new TreeGestureListener();
		m_oSourceListener		= new TreeSourceListener();

		/*
		 * This tree is gonna be the drag source:
		 */
		m_oDragSource = DragSource.getDefaultDragSource();
		m_oDragSource.createDefaultDragGestureRecognizer(
										this,
								 		DnDConstants.ACTION_COPY_OR_MOVE,
										m_oGestureListener);
	}

	public DefaultMutableTreeNode getTreeNode(Point location)
	{
		TreePath oTreePath = getPathForLocation(location.x, location.y);

		if (oTreePath != null)
		{
			return (DefaultMutableTreeNode)oTreePath.getLastPathComponent();
		}
		else
		{
			return null;
		}
	}
}

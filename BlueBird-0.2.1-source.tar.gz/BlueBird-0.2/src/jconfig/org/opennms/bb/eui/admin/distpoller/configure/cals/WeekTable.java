//-------------------------------------------------------------------------------------------
//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

//--------------------------------------------------------------------------------------------

package org.opennms.bb.eui.admin.distpoller.configure.cals;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import javax.swing.table.*;
import javax.swing.event.*;

public class WeekTable extends JPanel {
		
	public static JComboBox combo;
	
	JTable table = new JTable(new WeekCustomModel());
	JButton toolb1, toolb2;

	public WeekTable() 
	{
		//initializeStatusColumn();
		table.setSelectionMode(
						ListSelectionModel.SINGLE_SELECTION);

		//table.setCellSelectionEnabled(true);
		table.setColumnSelectionAllowed(false);
		table.setRowSelectionAllowed(true);

		JScrollPane jsp = new JScrollPane(table);
		jsp.setPreferredSize(new Dimension(250,140));
		jsp.setMaximumSize(new Dimension(250,140));

		add(addToolBar(), BorderLayout.NORTH);
		add(jsp, BorderLayout.CENTER);
	}

	public JButton getToolButton1()
	{
		return toolb1;
	}

	public JButton getToolButton2()
	{
		return toolb2;
	}

	public JPanel addToolBar() {
	
    String imageStr = "data" + System.getProperty("file.separator") + "images";

		JPanel toolPanel = new JPanel();
		JToolBar toolBar = new JToolBar();

		toolb1 = 
          	  (JButton) toolBar.add(
             	  new JButton(loadImageIcon(imageStr + System.getProperty("file.separator") + "oneDay.gif")));

		toolb2 = 
          	  (JButton) toolBar.add(
             	  new JButton(loadImageIcon(imageStr + System.getProperty("file.separator") + "oneDayOff.gif")));


		toolb1.setToolTipText("Reset selected day to On");
		toolb2.setToolTipText("Reset selected day to Off");
		
		
		toolPanel.add(toolBar);

		return toolPanel;
	}

	public ImageIcon loadImageIcon(String filename)
	{

		 return new ImageIcon(filename);
	}

	/*private void initializeStatusColumn() {

		TableColumn statusColumn = table.getColumn("Status");
		combo = new JComboBox();

		// Combo box items are Numbers ...
		combo.addItem(new String("All On"));
		combo.addItem(new String("All Off"));
		combo.addItem(new String("Mixed"));
		
		statusColumn.setCellEditor(new WeeklyStatusCellEditor(combo));
	}
	
	public static JComboBox getCombo()
	{
		return combo;
	}*/

	public JTable getTable()
	{
		return table;
	}
}

/*class WeeklyStatusCellEditor extends DefaultCellEditor {
	public WeeklyStatusCellEditor(JComboBox combo) {
		super(combo);
	}
	public boolean isCellEditable(EventObject e) {
		return true;
	}
}*/

class WeekCustomModel extends AbstractTableModel {

	String[] columnNames = {
			"Time", "Status"};


	Object[][] data = {
			{ "Sunday",  "All Off" },

			{ "Monday",  "All Off" },

			{ "Tuesday",  "All Off" },

			{ "Wednesday",  "All Off" },

			{ "Thursday",  "All Off" },

			{ "Friday", "All Off" },

			{ "Saturday", "All Off" },
						
					
			};

	
	public int getRowCount() {
		return data.length;
	}

	public int getColumnCount() {
		return columnNames.length;
	}
	public String getColumnName(int col) {
		return columnNames[col];
	}
	
	public Object getValueAt(int row, int col) {
		return data[row][col];
	}

	public Class getColumnClass(int col) {
		return data[0][col].getClass();
	}
	public void setValueAt(Object value, int row, int col) {

		data[row][col] = value;

		if (value.equals("Mixed"))
		{
			//System.out.println("mixed timings");

		}
		else if (value.equals("All Off") )
		{
			//System.out.println("All Off");
		}
		else if (value.equals("All On")) {
			//System.out.println("All On");

			/**
			TimeCustomModel tModel = tTable.getTableModel();
			tModel.updateCheckboxColumn();	
			**/
		}

	}

	public boolean isCellEditable(int row, int col) {
		Class columnClass = getColumnClass(col);
		String name = getColumnName(col);
		//return (columnClass  == String.class && !name.equals("Time"));
		return false;
	}

	
}

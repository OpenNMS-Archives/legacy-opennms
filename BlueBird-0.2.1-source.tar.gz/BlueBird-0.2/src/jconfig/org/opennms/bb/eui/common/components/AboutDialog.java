//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.common.components;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * <pre>AboutDialog allows the user to display a standard dialog 
 * with the following information
 *	- product logo
 *	- product name with revision
 *	- copyright info and company logo
 *	- user and user company
 * </pre> 
 * <p> all of which are configurable with 'set' methods
 *
 * @author Sowmya
 *
 */
public class AboutDialog extends JDialog
{
	JLabel productIcon;
	JLabel productLabel;
	JLabel copyrightLabel;
	JLabel websiteLabel;
	JLabel userLabel;
	JLabel companyLabel;

	/**
	 * Creates the standard bluebird about dialog
	 */
	public AboutDialog(JFrame frame, String title)
	{
		super(frame);
		setTitle(title);

		buildDialog(); // build the outline

		// set values
		ImageIcon productIcon = new ImageIcon("bb/data/images/bluebird.gif");
		ImageIcon companyIcon = new ImageIcon("bb/data/images/platformworks.gif");

		setProductIcon(productIcon);
		setProduct("BlueBird 0.6");
		setCopyright("Copyright @ 2000", companyIcon);
		setWebsite("www.opennms.org");
		setUser("user", "company");

		addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
				dispose();
			}
		});

		pack();
		setResizable(false);
		setLocationRelativeTo(frame);
		setVisible(true);
	}

	/**
	 * Creates a about dialog with the information passed in
	 */
	public AboutDialog(JFrame frame, String title, 
					 ImageIcon	productIcon,
					 String		product,
					 String		copyright,
					 ImageIcon	companyIcon,
					 String		website,
					 String		user,
					 String		userCompany)
	{
		super(frame);
		setTitle(title);

		buildDialog(); // build the outline

		// set values
		setProductIcon(productIcon);
		setProduct(product);
		setCopyright(copyright, companyIcon);
		setWebsite(website);
		setUser(user, userCompany);

		addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
				dispose();
			}
		});

		pack();
		setResizable(false);
		setLocationRelativeTo(frame);
		setVisible(true);
	}

	/**
	 * Layout the dialog components
	 */
	protected void buildDialog()
	{
		// product info
		GridBagLayout gridbag = new GridBagLayout();
		GridBagConstraints gbc = new GridBagConstraints();

		JPanel productIconPanel = new JPanel();
		productIconPanel.setLayout(gridbag);

		// icon
		productIcon = new JLabel(new ImageIcon(""));

		JPanel productPanel = new JPanel();
		productPanel.setLayout(new BoxLayout(productPanel, BoxLayout.Y_AXIS));

		// product info
		productLabel = new JLabel();

		// copyright info
		copyrightLabel = new JLabel("", new ImageIcon(""), JLabel.LEADING);

		// website info
		websiteLabel = new JLabel();
		websiteLabel.setFont(new Font("Helvetica",Font.BOLD|Font.ITALIC, 10));

		productPanel.add(productLabel);
		productPanel.add(copyrightLabel);
		productPanel.add(websiteLabel);

		// align product related info
		gbc.gridwidth = GridBagConstraints.RELATIVE;
		gbc.fill	= GridBagConstraints.NONE;
		gbc.anchor	= GridBagConstraints.WEST;
		gbc.insets  = new Insets(10, 5, 10, 15);
		
		gridbag.setConstraints(productIcon, gbc);
		productIconPanel.add(productIcon);

		gbc.gridwidth = GridBagConstraints.REMAINDER;
		gbc.fill	= GridBagConstraints.HORIZONTAL;
		gbc.anchor	= GridBagConstraints.EAST;
		gbc.insets  = new Insets(10, 10, 15, 5);

		gridbag.setConstraints(productPanel, gbc);
		productIconPanel.add(productPanel);

		// user info
		JLabel textLabel=new JLabel("This product is licensed to:");

		gbc.gridwidth = GridBagConstraints.REMAINDER;
		gbc.fill	= GridBagConstraints.HORIZONTAL;
		gbc.anchor	= GridBagConstraints.WEST;
		gbc.insets  = new Insets(10, 0, 5, 15);
		
		gridbag.setConstraints(textLabel, gbc);
		productIconPanel.add(textLabel);

		userLabel = new JLabel();
		userLabel.setFont(new Font("Helvetica",Font.BOLD, 10));

		companyLabel = new JLabel();
		companyLabel.setFont(new Font("Helvetica",Font.BOLD, 10));

		JPanel userPanel = new JPanel();
		userPanel.setBorder(BorderFactory.createLoweredBevelBorder());
		userPanel.setLayout(new BoxLayout(userPanel, BoxLayout.Y_AXIS));

		Dimension userDim = new Dimension( userPanel.getPreferredSize().width, 50);
		userPanel.setPreferredSize(userDim);
		userPanel.setMinimumSize(userDim);

		userPanel.add(userLabel);
		userPanel.add(companyLabel);

		JPanel okPanel=new JPanel();

		// ok button
		JButton okButton = new JButton("OK");
		okButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				dispose();
			}
		});

		Dimension dim = okButton.getPreferredSize();
		okButton.setPreferredSize(new Dimension(80, dim.height));
		
		okPanel.add(okButton);

		Container cont = getContentPane();
		cont.setLayout(new BorderLayout());

		cont.add(productIconPanel, BorderLayout.NORTH);
		cont.add(userPanel, BorderLayout.CENTER);
		cont.add(okPanel, BorderLayout.SOUTH);
	}

	/**
	 * Sets the product icon
	 */
	public void setProductIcon(Icon product)
	{
		productIcon.setIcon(product);
	}

	/**
	 * <pre>Sets the product 
	 * - Queries the system to find the OS and adds that to the
	 * product info
	 * Note: The input should contain both the product name and
	 * its revision </pre>
	 */
	public void setProduct(String product)
	{
		StringBuffer sysname = new StringBuffer(" for ");
		try
		{
			sysname.append(System.getProperty("os.name"));
		} catch (Exception e) { }

		if (sysname.equals(" for "))
			productLabel.setText(product);
		else
			productLabel.setText(product + sysname);
	}
	
	/**
	 * Sets the copyright to a string
	 */
	public void setCopyright(String copyright)
	{
		copyrightLabel.setText(copyright);
	}

	/**
	 * Sets the copyright string and company icon
	 */
	public void setCopyright(String copyright, ImageIcon companyIcon)
	{
		copyrightLabel.setIcon(companyIcon);
		copyrightLabel.setText(copyright);
		copyrightLabel.setHorizontalTextPosition(SwingConstants.LEADING);
	}
	
	/**
	 * Sets the website
	 */
	public void setWebsite(String website)
	{
		websiteLabel.setText(website);
	}
	
	/**
	 * Sets the user and user company 
	 */
	public void setUser(String user, String company)
	{
		userLabel.setText(user);
		companyLabel.setText(company);
	}
	
}

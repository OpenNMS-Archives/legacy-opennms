//
// Copyright (C) 2000 N*Manage Company, Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
// $Id: EventsParser.java,v 1.2 2000/11/01 18:05:58 jacinta Exp $

package org.opennms.bb.eui.operator.utils;

import java.io.*;
import java.util.*;

import org.w3c.dom.*;
import org.xml.sax.*;

import org.opennms.bb.common.utils.*;
//import org.opennms.bb.common.components.Log;
import org.opennms.bb.eui.operator.utils.datablocks.*;

/**
 * <pre>EventsParser extends the BBParser and parses an input stream 
 * to read/interpret an event 
 *
 * It throws an IOException if the xml stream does not conform to the event DTD 
 * </pre>
 *
 * @author Sowmya
 * @author <A HREF="http://www.opennms.org">OpenNMS.org</A>
 */
public class EventsParser extends BBParser
{
	/**
	 * The Vector of all events
	 */
	private Vector				m_eventsStore;
	
	/**
	 * Header (stored in each element.. )
	 */
	private EventHeader			m_eventHeader;

	/**
	 * The attribute delimiter. Elements like the 'operatoraction' that
	 * has an attribute 'menutext' are stored in a single string
	 * in the format <element><ATTRIB_DELIM><attribute>
	 */
	private final String ATTRIB_DELIM	="/\\";

	/**
	 * Relevant XML TAGS
	 */
	private final String HEADER		="header";
	private final String VER		="ver";
	private final String DPNAME		="dpName";
	private final String CREATED		="created";
	private final String MSTATION		="mstation";
	
	private final String EVENTS		="events";
	private final String EVENT		="event";

	private final String UEI		="uei";
	private final String SOURCE		="source";

	// time related
	private final String TIME		="time";
	private final String YEAR		="year";
	private final String MONTH		="month";
	private final String DAY		="day";
	private final String HOUR		="hour";
	private final String MIN		="min";
	private final String SEC		="sec";
	private final String TYPE		="type";

	private final String HOST		="host";
	private final String SNMPHOST		="snmphost";

	private final String SNMP		="snmp";
	private final String EID		="eid";
	private final String EIDTEXT		="eidtext";
	private final String SPECIFIC		="specific";
	private final String GENERIC		="generic";

	private final String PARMS		="parms";
	private final String PARM		="parm";
	private final String PARM_NAME		="parmName";
	private final String PARM_VALUE		="value";

	private final String DESCR		="descr";

	private final String LOGMSG		="logmsg";
	private final String LOGMSGDEST		="dest";

	private final String SEVERITY		="severity";
	private final String OPERINSTR		="operinstruct";
	private final String AUTOACTION		="autoaction";

	private final String OPERACTION		="operaction";
	private final String OPERACTIONMENU	="menutext";

	private final String LOGGROUP		="loggroup";
	private final String NOTIFICATION	="notification";

	private final String TTICKET		="tticket";
	private final String TTICKETSTATE	="state";

	private final String FORWARD		="forward";
	private final String FORWARDSTATE	="state";
	private final String FORWARDMECH	="mechanism";

	private final String MOUSEOVERTEXT	="mouseovertext";

	/**
	 * Constructs the DOMParser
 	 */
	public EventsParser()
	{
		super();
		
		m_eventsStore=null;
	}

	/**
	 * Overrides the method in the parent class to handle this XML 
	 */
	protected boolean processElement(Element el,boolean isRoot)
	{
		boolean bRet = false;

		String tag = el.getTagName();

		if (tag.equals(HEADER))
		{
			m_curElement.replace(0, m_curElement.length(), HEADER);

			bRet = processHeaderNode(el);
		}

		else if (tag.equals(EVENTS))
		{
			m_curElement.replace(0, m_curElement.length(), EVENTS);

			bRet = processEventsElement(el);
		}

		else
		{
			boolean bNodeRet=true;

			NodeList nl = el.getChildNodes();
			int size = nl.getLength();

			for(int i = 0;i < size && bNodeRet ;i++)
				bNodeRet = processNode(nl.item(i));
			
			bRet = bNodeRet;
		}
		
		return bRet;
	}

	/**
	 * Handles the 'header' element - this is added to each event
	 *
	 * @return true if parse is successful, false otherwise
	 */
	protected boolean processHeaderNode(Node headerNode)
	{
		boolean bRet = true;

		NodeList nl = headerNode.getChildNodes();
		int size = nl.getLength();


		String ver	= null;
		String dpName	= null;
		Date  created	= null;
		String mstation	= null;

		for(int i = 0;i < size && bRet;i++)
		{
			Node curNode = nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();

				if(curTag.equals(VER))
				{
					m_curElement.replace(0, m_curElement.length(), VER);

					ver = processParmValue(curNode); 
					if (null == ver)
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}
				}

				else if(curTag.equals(DPNAME))
				{
					m_curElement.replace(0, m_curElement.length(), DPNAME);

					dpName = processParmValue(curNode); 
					if (null == dpName)
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}
				}

				else if(curTag.equals(CREATED))
				{
					m_curElement.replace(0, m_curElement.length(), CREATED);

					Element	hElem = (Element)curNode;

					int year  =new Integer(hElem.getAttribute(YEAR)).intValue();
					int month=new Integer(hElem.getAttribute(MONTH)).intValue() - 1;
					int day   =new Integer(hElem.getAttribute(DAY)).intValue();
					int hour  =new Integer(hElem.getAttribute(HOUR)).intValue();
					int min   =new Integer(hElem.getAttribute(MIN)).intValue();
					int sec   =new Integer(hElem.getAttribute(SEC)).intValue();

					java.util.GregorianCalendar cal= new java.util.GregorianCalendar( year, month, day, hour, min, sec);


					created = cal.getTime();
				}
				
				else if(curTag.equals(MSTATION))
				{
					m_curElement.replace(0, m_curElement.length(), MSTATION);

					mstation = processParmValue(curNode); 
					if (null == mstation)
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}								
				}

			}
		}

		if (bRet)
			m_eventHeader = new EventHeader(ver, dpName, created, mstation);

		return bRet;
	}

	/**
	 * Handles the 'events' element
	 *
	 * @return true if parse is successful, false otherwise
	 */
	protected boolean processEventsElement(Node eventsNode)
	{
		boolean bRet = true;

		m_eventsStore = null;

		m_eventsStore = new Vector();

		NodeList nl = eventsNode.getChildNodes();
		int size = nl.getLength();
		for(int i = 0;i < size && bRet;i++)
		{
			Node curNode = nl.item(i);
			int  nodeType= curNode.getNodeType();

			if ( nodeType == Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();

				if(curTag.equals(EVENT))
					bRet = processEventNode(curNode);
			}
			
		}

		return bRet;
	}

	/**
	 * Handles the 'event' element - all the relevant information for
	 * each event is read, and an 'EventBlock' created - this is then
	 * added to the event store
	 *
	 * @return true if parse is successful, false otherwise
	 */
	protected boolean processEventNode(Node eventNode)
	{
		boolean bRet = true;

		NodeList nl = eventNode.getChildNodes();
		int size = nl.getLength();

		m_curElement.replace(0, m_curElement.length(), EVENT);

		// uei and source
		String uei	= null;
		String source	= null;
		Date   timeVal	= null;
		String host	= null;
		String snmpHost	= null;

		// snmp
		EventSnmpInfo snmpInfo=null;

		// parms
		//Vector eventParms=null;
		Hashtable eventParms=null;
		
		// descr
		String descr	= null;

		String logMsg	= null;

		String logType	= null;

		String severity	= null;

		String operInstr= null;

		// 'autoaction' can occur more than once - values are stored in a vector
		Vector autoAction=null;

		// 'operaction' can occur more than once - values are stored in a vector
		Vector operAction=null;

		// 'loggroup' can occur more than once - values are stored in a vector
		Vector logGroup	 =null;

		// 'notification' can occur more than once - values are stored in a vector
		Vector notification=null;

		String tticket	= null;

		// 'forward' can occur more than once - values are stored in a vector
		Vector forward	= null;

		String mouseText= null;
		
		for(int i = 0;i < size && bRet;i++)
		{
			Node curNode = nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();

				/**
				 * Make sure this is a tag we really require -
				 * i.e. if the event.conf has this tag to be 
				 * non-overridable, we'd always take the value
				 * present in 'event.conf' - so no point in
				 * storing the value for this tag/element
				 */
				//if (!EventConf.isOverridable(curTag))
				//	continue;

				if(curTag.equals(UEI))
				{
					m_curElement.replace(0, m_curElement.length(), UEI);

					uei = processParmValue(curNode); 
					if (null == uei)
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}
				}

				else if(curTag.equals(SOURCE))
				{
					m_curElement.replace(0, m_curElement.length(), SOURCE);

					source = processParmValue(curNode); 

					if (null == source)
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}
				}
				else if(curTag.equals(TIME))
				{
					m_curElement.replace(0, m_curElement.length(), TIME);

					Element	hElem = (Element)curNode;

					int year  =new Integer(hElem.getAttribute(YEAR)).intValue();
					int month=new Integer(hElem.getAttribute(MONTH)).intValue() - 1;
					int day   =new Integer(hElem.getAttribute(DAY)).intValue();
					int hour  =new Integer(hElem.getAttribute(HOUR)).intValue();
					int min   =new Integer(hElem.getAttribute(MIN)).intValue();
					int sec   =new Integer(hElem.getAttribute(SEC)).intValue();

					java.util.GregorianCalendar cal= new 
						java.util.GregorianCalendar(year, month, day, hour, min, sec);


					timeVal = cal.getTime();
				}
				
				else if(curTag.equals(HOST))
				{
					m_curElement.replace(0, m_curElement.length(), HOST);

					host = processHost(curNode); 
					if (null == host)					
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}								
				}

				else if(curTag.equals(SNMPHOST))
				{
					m_curElement.replace(0, m_curElement.length(), SNMPHOST);

					snmpHost = processHost(curNode); 
					if (null == snmpHost)					
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}								
				}

				else if(curTag.equals(SNMP))
				{
					m_curElement.replace(0, m_curElement.length(), SNMP);

					snmpInfo = processSnmp(curNode);

				}

				else if(curTag.equals(PARMS))
				{
					m_curElement.replace(0, m_curElement.length(), PARMS);
					Vector parms = processParms(curNode);
					/**************************************************/
					for(int index = 0;index < parms.size();index++)
					{
						Vector tmp = (Vector)parms.elementAt(index);
						if(eventParms == null)
							eventParms = new Hashtable();
						eventParms.put((String)tmp.elementAt(0), (String)tmp.elementAt(2));

					}					
					/**************************************************/
				}

				else if(curTag.equals(DESCR))
				{
					m_curElement.replace(0, m_curElement.length(), DESCR);

					descr = processParmValue(curNode); 
					if (null == descr)					
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}								
				}

				else if(curTag.equals(LOGMSG))
				{
					m_curElement.replace(0, m_curElement.length(), LOGMSG);

					Element	hElem = (Element)curNode;
					String 	logMsgDest;
					logType 	= new String(hElem.getAttribute(LOGMSGDEST)).toString();

					String logMsgStr = processParmValue(curNode); 
					if (null == logMsgStr)
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}								
					else
					{
						logMsgDest = ((Element)curNode).getAttribute(LOGMSGDEST);

						logMsg = new String(logMsgStr + ATTRIB_DELIM + logMsgDest);
					}
				}

				else if(curTag.equals(SEVERITY))
				{
					m_curElement.replace(0, m_curElement.length(), SEVERITY);

					severity = processParmValue(curNode).trim(); 
					if (null == severity)					
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}								
				}

				else if(curTag.equals(OPERINSTR))
				{
					m_curElement.replace(0, m_curElement.length(), OPERINSTR);

					operInstr = processParmValue(curNode); 
					if (null == operInstr)					
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}								
				}

				else if(curTag.equals(AUTOACTION))
				{
					m_curElement.replace(0, m_curElement.length(), AUTOACTION);

					String autoActionStr = processParmValue(curNode); 
					if (null == autoActionStr)
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}
					else
					{
						if (autoAction == null)
							autoAction = new Vector();

						autoAction.add(autoActionStr);
					}

				}

				else if(curTag.equals(OPERACTION))
				{
					m_curElement.replace(0, m_curElement.length(), OPERACTION);

					String operActionMenu=null;
					String operActionStr = processParmValue(curNode); 
					if (null == operActionStr)
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}								
					else
					{
						/**
						 * The DOMParser does not handle the case when the
						 * attribute is not enumerated and requires a value
						 * i.e. does not fail conformance to dtd test if an
						 * attribute requires a value and that value is not
						 * specified - so an explicit check is required
						 */
						operActionMenu = ((Element)curNode).getAttribute(OPERACTIONMENU);
						if(operActionMenu == null || operActionMenu.length() <=0 )
						{
							m_curElement.replace(0, m_curElement.length(), OPERACTIONMENU);
							bRet = false;
							m_errNum = NULL_VALUE_ERR;
							continue;
						}

						if (operAction == null)
							operAction = new Vector();
						operAction.add(new String(operActionStr + ATTRIB_DELIM + operActionMenu));
					}
				}

				else if(curTag.equals(LOGGROUP))
				{
					m_curElement.replace(0, m_curElement.length(), LOGGROUP);

					String logGroupStr = processParmValue(curNode); 

					// Read the attribute value for logtype

					if (null == logGroupStr)
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}
					else
					{
						if (logGroup == null)
							logGroup = new Vector();

						logGroup.add(logGroupStr);
					}
				}

				else if(curTag.equals(NOTIFICATION))
				{
					m_curElement.replace(0, m_curElement.length(), NOTIFICATION);

					String notificationStr = processParmValue(curNode); 
					if (null == notificationStr)
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}
					else
					{
						if (notification == null)
							notification = new Vector();
						notification.add(notificationStr);
					}
				}

				else if(curTag.equals(TTICKET))
				{
					m_curElement.replace(0, m_curElement.length(), TTICKET);

					String tticketState= null;
					String tticketStr = processParmValue(curNode); 
					if (null == tticketStr)
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}
					else
					{
						tticketState = ((Element)curNode).getAttribute(TTICKETSTATE);

						tticket = new String(tticketStr + ATTRIB_DELIM + tticketState);
					}
				}

				else if(curTag.equals(FORWARD))
				{
					m_curElement.replace(0, m_curElement.length(), FORWARD);

					String forwardState;
					String forwardMech;

					String forwardStr = processParmValue(curNode); 
					if (null == forwardStr)
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}
					else
					{
						forwardState = ((Element)curNode).getAttribute(FORWARDSTATE);
						forwardMech = ((Element)curNode).getAttribute(FORWARDMECH);

						if(forward == null)
							forward = new Vector();

						forward.add(new String(forwardStr + ATTRIB_DELIM + forwardState + ATTRIB_DELIM + forwardMech));
					}
				}

				else if(curTag.equals(MOUSEOVERTEXT))
				{
					m_curElement.replace(0, m_curElement.length(), MOUSEOVERTEXT);

					mouseText = processParmValue(curNode); 
					if (null == mouseText)					
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}								
				}


			}
		}

		// Once all the information for the event is read, add to the hashtable
		EventBlock eventBlock;
			
		eventBlock = new EventBlock(	uei,
						source,
						timeVal,
						host,
						snmpHost,
						snmpInfo,
						eventParms,
						descr,
						logMsg,
						severity,
						operInstr,
						autoAction,
						operAction,
						logGroup,
						logType,
						notification,
						tticket,
						forward,
						mouseText,
						m_eventHeader);

		/*****************************/
		
		/*************/								
		m_eventsStore.add(eventBlock);


		return bRet;
	}

	/**
	 * Returns the hostname from the node, the IP Address in the
	 * dotted decimal format
	 *
	 * @return the hostname as a dotted decimal
	 */
	protected String processHost(Node hostNode)
	{
		String host = processParmValue(hostNode); 
		Object type = ((Element)hostNode).getAttribute(TYPE);

		String hostName = host;

		if (type.toString().equals("string"))
		{
			hostName = host;
		}
		else if (type.toString().equals("int"))
		{
			long address=0;
			try
			{
				address = Long.parseLong(host);
			}
			catch (Exception e) 
			{ 
				address=0;
			}

			hostName = ((address >>> 24) & 0xFF) + "." + 
			       		((address >>> 16) & 0xFF) + "." + 
			       		((address >>>  8) & 0xFF) + "." + 
			       		((address >>>  0) & 0xFF);
		}
		else if (type.toString().equals("hex"))
		{
			long address=0;
			try
			{
				address = Long.parseLong(host, 16);
			}
			catch (Exception e) 
			{ 
				address=0;
			}

			hostName = ((address >>> 24) & 0xFF) + "." + 
			       		((address >>> 16) & 0xFF) + "." + 
			       		((address >>>  8) & 0xFF) + "." + 
			       		((address >>>  0) & 0xFF);
		}
		else
			hostName = host;
					

		return hostName;					
	}

	/**
	 * Handles the 'snmp' element and returns the
	 * eid/eidText/specific/generic for this element
	 *
	 * @return the SNMP info of the event
	 */
	protected EventSnmpInfo processSnmp(Node snmpNode)
	{
		boolean bRet = true;

		String eid	= null;
		String eidText	= null;
		String specific = null;
		String generic  = null;

		EventSnmpInfo snmpInfo;

		NodeList nl = snmpNode.getChildNodes();
		int size = nl.getLength();

		for(int i = 0;i < size && bRet;i++)
		{
			Node curNode = nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();

		
				if(curTag.equals(EID))
				{
					m_curElement.replace(0, m_curElement.length(), EID);

					eid = processParmValue(curNode); 
					if (null == eid)
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}

				}

				if(curTag.equals(EIDTEXT))
				{
					m_curElement.replace(0, m_curElement.length(), EIDTEXT);

					eidText = processParmValue(curNode); 

					if (null == eidText)
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}
				}

				else if(curTag.equals(SPECIFIC))
				{
					m_curElement.replace(0, m_curElement.length(), SPECIFIC);

					specific = processParmValue(curNode); 
					if (null == specific)
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}
				}

				else if(curTag.equals(GENERIC))
				{
					m_curElement.replace(0, m_curElement.length(), GENERIC);

					generic = processParmValue(curNode); 
					if (null == generic)
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}
				}

			}
		}

		if (bRet)
			snmpInfo = new EventSnmpInfo(eid, eidText, specific, generic);
		else
			snmpInfo = null;
		
		return snmpInfo;
	}

	/**
	 * Handles the 'parms' element for each event
	 *
	 * @return true if parse is successful, false otherwise
	 */
	protected Vector processParms(Node parmsNode)
	{
		NodeList nl = parmsNode.getChildNodes();
		int size = nl.getLength();

		Vector eventVector = new Vector();

		for(int i = 0;i < size ;i++)
		{
			Node curNode = nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
				if(curTag.equals(PARM))
				{
					Vector parm = processParm(curNode);

					if ( (!parm.isEmpty()) && (parm.size() == 3))
					{
						eventVector.add(parm);
						
					}

				}

			}
		}

		return eventVector;
	}
	
	/**
	 * Handles the 'parm' element in the list of parms
	 *
	 * @return  a vector containing the parm name and value
	 */
	protected Vector processParm(Node parmsNode)
	{
		boolean bRet=false;

		Vector parm = new Vector(3);

		NodeList nl = parmsNode.getChildNodes();
		int size = nl.getLength();
		for(int i = 0;i < size;i++)
		{
			Node curNode = nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
				if(curTag.equals(PARM_NAME))
				{
					String name = processParmName(curNode);

					if (null != name)
						parm.add(name);
					
				}
				else if(curTag.equals(PARM_VALUE))
				{
					bRet=processValue(curNode, parm);
					

				}

			}
		}

		if (bRet)
			return parm;
		else
			return null;
	}

	/**
	 * Handles the 'parmName' element
	 *
	 * @return the value for the parmName
	 */
	protected String processParmName(Node parmNameNode)
	{
		String parmName=null;

		Node temp = parmNameNode.getChildNodes().item(0);
		if (temp.getNodeType() == Node.TEXT_NODE)
			parmName = ((Text)temp).getData();
		
		return parmName;
	}

	/**
	 * process the '<value>' element of a 'parm' and returns both the
	 * parm value and its type
	 *
	 * @returns a vector containing the parm type and value
	 */
	protected boolean processValue(Node parmValNode, Vector parm)
	{
		String parmVal = null;

		Node temp = parmValNode.getChildNodes().item(0);
		if (temp.getNodeType() == Node.TEXT_NODE)
			parmVal = ((Text)temp).getData();
		
		String parmType = ((Element)parmValNode).getAttribute(TYPE);

		if (parmVal == null)
			return false;
		else
		{
			parm.add(parmType);
			parm.add(parmVal);
			
			return true;
		}
	}
	
	/**
	 * Returns a vector of events in the incoming event stram
	 *
	 * @return a vector of events in the incoming event stram
	 */
	public Vector getEvents()
	{
		return m_eventsStore;
	}
}


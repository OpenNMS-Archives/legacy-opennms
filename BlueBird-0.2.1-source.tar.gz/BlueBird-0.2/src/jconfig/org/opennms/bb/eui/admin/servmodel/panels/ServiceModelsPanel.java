//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.admin.servmodel.panels;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.event.*;
import javax.swing.table.*;

import java.util.Vector;

import org.opennms.bb.eui.common.components.*;

/**
 * <pre> ServiceModelsPanel is the service model panel
 * It handles all the editing related with the model
 *
 * @author Sowmya
 */
class ServiceModelsPanel extends JPanel implements ActionListener,
												   TableColumnModelListener
{
	ServiceModelConfigPanel		smParent;
	SModelManipPanel		tablePanel;

	BBTBButton 	copyButton, pasteButton, addButton, deleteButton;

	private Vector			clipBoardVector=null;

	protected ServiceModelsPanel(ServiceModelConfigPanel smcPanel, Vector serviceTableData)
	{
		smParent = smcPanel;

		JLabel label = new JLabel("Service Models");

		JPanel sPanel = new JPanel();
		sPanel.setLayout(new BoxLayout(sPanel, BoxLayout.X_AXIS));

		JPanel toolPanel = createToolPanel();
		toolPanel.setAlignmentY(Component.TOP_ALIGNMENT);

		tablePanel = createTablePanel(serviceTableData);
		tablePanel.setAlignmentY(Component.TOP_ALIGNMENT);

		sPanel.add(toolPanel);
		sPanel.add(Box.createHorizontalStrut(5));
		sPanel.add(tablePanel);

		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		Border inBorder = BorderFactory.createEmptyBorder(5, 5, 5, 5);
		Border outBorder= BorderFactory.createLoweredBevelBorder();
		setBorder(BorderFactory.createCompoundBorder(outBorder, inBorder));

		label.setAlignmentX(Component.LEFT_ALIGNMENT);
		sPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		add(label);
		add(sPanel);

		// size
		Dimension toolSize = toolPanel.getPreferredSize();
		toolPanel.setPreferredSize(toolSize);
		toolPanel.setMaximumSize(new Dimension(50, toolSize.height*2));

		Dimension dim = tablePanel.getPreferredSize();
		tablePanel.setPreferredSize(new Dimension(400, 200));

		// listen to changes in column values
		tablePanel.getTable().getColumnModel().addColumnModelListener(this);
	}

	SModelManipPanel  createTablePanel(Vector data)
	{
		Vector colNames = new Vector(2);
		colNames.add("Model Name");
		colNames.add("Description");
		
		SModelManipPanel panel = new SModelManipPanel(data, colNames);
		return panel;
	}

	JPanel createToolPanel()
	{
		JPanel panel = new JPanel();
		panel.setBorder(BorderFactory.createLoweredBevelBorder());

		JToolBar toolBar = new JToolBar(SwingConstants.VERTICAL);
		toolBar.setFloatable(false);

		// copy
		copyButton = new BBTBButton("data/images/copy.gif", "CopyM", "Copy current row");
		copyButton.addActionListener(this);
		toolBar.add(copyButton);

		// paste
		pasteButton = new BBTBButton("data/images/paste.gif", "PasteM", "Paste row from clipboard");
		pasteButton.setEnabled(false);
		pasteButton.addActionListener(this);
		toolBar.add(pasteButton);

		// add
		addButton = new BBTBButton("data/images/new.gif", "AddM", "Add new row");
		addButton.addActionListener(this);
		toolBar.add(addButton);

		// delete
		deleteButton = new BBTBButton("data/images/delete.gif", "DeleteM", "Delete current row");
		deleteButton.addActionListener(this);
		toolBar.add(deleteButton);

		panel.add(toolBar);
		return panel;
	}

	public void actionPerformed(ActionEvent e)
	{
		smParent.handleMenuToolBarActions(e.getActionCommand());
	}

	/**
	 * Handles all edits of the service model table
	 */
	public void handleAction(String actionStr)
	{
		if (actionStr.equals("CopyM"))
		{
			int iSelRow = tablePanel.getSelectedRow();
			if (iSelRow != -1)
			{
				// Get the selected row
				Vector selRow = (Vector)tablePanel.getTableData().elementAt(iSelRow);

				// Make a copy of this row in the clipboard
				int iSize = selRow.size();
				clipBoardVector = new Vector(iSize);
				for (int iIndex=0; iIndex < iSize; iIndex++)
					clipBoardVector.add(selRow.elementAt(iIndex));

				pasteButton.setEnabled(true);
			}
		}

		else if (actionStr.equals("PasteM"))
		{
			tablePanel.pasteRow(clipBoardVector);
		}

		else if (actionStr.equals("AddM"))
		{
			tablePanel.addEntryToTable();
		}

		else if (actionStr.equals("DeleteM"))
		{
			int iSelRow = tablePanel.getSelectedRow();
			if (iSelRow != -1)
			{
				tablePanel.removeRow(iSelRow);
			}
		}
	}

	/**
	 * Table(s) column selection listener 
	 */
	public void columnSelectionChanged(ListSelectionEvent e)
	{
		int iSelRow = tablePanel.getSelectedRow();
		int iSelCol = tablePanel.getTable().getSelectedColumn();

		if (iSelRow != -1 && iSelCol != -1)
		{
			smParent.setServiceName(tablePanel.getTable().getValueAt(iSelRow, 1).toString());
			
		}

		smParent.updateServiceModelName(
					tablePanel.getTable().getValueAt(iSelRow, iSelCol), 
					iSelRow, iSelCol);
	}

	public void columnAdded(TableColumnModelEvent e) { }
	public void columnMoved(TableColumnModelEvent e) { }
	public void columnRemoved(TableColumnModelEvent e) { }
	public void columnMarginChanged(ChangeEvent e) { }

	public void disableAll()
	{
		copyButton.setEnabled(false);
		pasteButton.setEnabled(false);
		deleteButton.setEnabled(false);
	}

	public void enableAll()
	{
		if (!copyButton.isEnabled())	// check if disabled
		{
			copyButton.setEnabled(true);
			pasteButton.setEnabled(true);
			deleteButton.setEnabled(true);
		}
	}
	
	public JTable getTable()
	{
		return tablePanel.getTable();
	}
	
	public int getRowCount()
	{
		return tablePanel.getTable().getRowCount();
	}

	public void selectService(int iService)
	{
		((BBManipTable)tablePanel.getTable()).selectCellAt(iService, 1);
	}

	public void setInitialFocus()
	{
		((BBManipTable)tablePanel.getTable()).setInitialFocus();
	}
	
	public int getSelectedService()
	{
		 ListSelectionModel lsm = getTable().getSelectionModel();

		 if (!lsm.isSelectionEmpty())
		 	return lsm.getLeadSelectionIndex();
		 else
		 	return -1;
	}
	
	public String getServiceName(int iSelService)
	{
		return tablePanel.getServiceName(iSelService);
	}

	public Vector getDataForService(int iService)
	{
		if (iService == -1)
			return null;

		else
		{
			Vector temp = tablePanel.getTableData();

			Vector row = (Vector)temp.elementAt(iService);
			return row;
		}
	}

	public boolean isTableChanged()
	{
		return tablePanel.isTableChanged();
	}

	public void setTableSaved()
	{
		tablePanel.setTableSaved();
	}
	
	public boolean validateValues()
	{
		return tablePanel.validateValues();
	}

	public Vector getTableData()
	{
		return tablePanel.getTableData();
	}
}

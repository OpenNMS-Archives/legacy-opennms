//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.admin.snmp.utils;

import org.w3c.dom.*;

import java.io.*;
import java.util.Vector;
import java.util.Hashtable;

import org.opennms.bb.common.utils.BBParser;

/**
 * <pre>SnmpUserProfileParser reads the user preferences for the SNMP
 * config from the user profile file
 *
 * It throws an IOException if the xml file is not found or if it does not
 * conform to its DTD </pre>
 *
 * @author Sowmya
 *
 */
public class SnmpUserProfParser extends BBParser
{
	Hashtable	userHash;

	/*
	 * XML TAGS that are relevant
	 */
	final String APPL		="appl";
	final String APPLNAME	="name";
	final String PARM		="parm";
	final String PARM_NAME	="parmName";
	final String PARM_VALUE	="value";

	/*
	 * Looking for
	 */
	final String SNMP_STR	="SnmpConfig";
	final String XPOS		="xPos";
	final String YPOS		="yPos";
	final String WIDTH		="Width";
	final String HEIGHT		="Height";
	final String LOOKNFEEL	="lookAndFeel";

	/**
 	 * Creates a DOM parser
 	 */
	public SnmpUserProfParser()
	{
		super();
	}

	protected boolean processElement(Element el,boolean isRoot)
	{
		boolean bRet = false;

		String tag = el.getTagName();

		if (tag.equals(APPL))
		{
			m_curElement.replace(0, m_curElement.length(), APPL);

			// get 'name' atribute
			String applName = el.getAttribute(APPLNAME);

			if (applName.equals(SNMP_STR))
			{
				bRet = processSnmpElement(el);
			}
			else
				bRet = true;
		}

		else
		{
			boolean bNodeRet=true;

			NodeList nl = el.getChildNodes();
			int size = nl.getLength();

			for(int i = 0;i < size && bNodeRet ;i++)
				bNodeRet = processNode(nl.item(i));
			
			bRet = bNodeRet;
		}


		return bRet;
	}

	protected boolean processSnmpElement(Node opNode)
	{
		boolean bRet = true;

		m_curElement.replace(0, m_curElement.length(), APPL + ": " + SNMP_STR);

		userHash  = new Hashtable();

		NodeList nl = opNode.getChildNodes();
		int size = nl.getLength();
		for(int i = 0;i < size && bRet;i++)
		{
			Node curNode = nl.item(i);
			int  nodeType= curNode.getNodeType();

			if ( nodeType == Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();

				if(curTag.equals(PARM))
					bRet = processSnmpParmNode(curNode);
			}
			
		}

		return bRet;
	}

	protected boolean processSnmpParmNode(Node opNode)
	{
		boolean bRet = true;

		m_curElement.replace(0, m_curElement.length(), PARM);

		String	  parmName=null;

		NodeList nl = opNode.getChildNodes();
		int size = nl.getLength();

		for(int i = 0;i < size && bRet;i++)
		{
			Node curNode = nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();

				m_curElement.replace(0, m_curElement.length(), curTag);

				if(curTag.equals(PARM_NAME))
				{
					parmName = processParmName(curNode);
					if (null != parmName)
						parmName.toLowerCase();
					else
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}

				}
				else if(curTag.equals(PARM_VALUE))
				{
					String parmValue = processParmValue(curNode);
					if (null == parmValue)
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
						
						continue;
					}

					else if(parmName.equalsIgnoreCase(XPOS))
					{
						// if number format exception, ignore
						try
						{
							Integer xpos = new Integer(parmValue);
							userHash.put(XPOS, xpos);
						}
						catch(Exception e) {}
					}

					else if(parmName.equalsIgnoreCase(YPOS))
					{
						// if number format exception, ignore
						try
						{
							Integer ypos = new Integer(parmValue);
							userHash.put(YPOS, ypos);
						}
						catch(Exception e) {}
					}

					else if(parmName.equalsIgnoreCase(WIDTH))
					{
						// if number format exception, ignore
						try
						{
							Integer width = new Integer(parmValue);
							userHash.put(WIDTH, width);
						}
						catch(Exception e) {}
					}

					else if(parmName.equalsIgnoreCase(HEIGHT))
					{
						// if number format exception, ignore
						try
						{
							Integer height = new Integer(parmValue);
							userHash.put(HEIGHT, height);
						}
						catch(Exception e) {}
					}

					else if(parmName.equals(LOOKNFEEL))
					{
						userHash.put(LOOKNFEEL, parmValue);
					}

				}
			}
		}

		return bRet;
	}

	protected String processParmName(Node parmNameNode)
	{
		String parmName=null;

		Node temp = parmNameNode.getChildNodes().item(0);
		if (temp.getNodeType() == Node.TEXT_NODE)
			parmName = ((Text)temp).getData();
		
		return parmName;
	}

	/**
	 */
	public Hashtable getUserProfile()
	{
		return userHash;
	}

}

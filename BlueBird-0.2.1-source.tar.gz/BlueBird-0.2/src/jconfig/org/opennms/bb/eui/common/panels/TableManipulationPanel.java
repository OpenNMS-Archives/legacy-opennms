//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.common.panels;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;

import javax.swing.plaf.ColorUIResource;

import java.util.*;

import org.opennms.bb.eui.common.components.*;

/**
 * <pre>TableManipulationPanel 
 * - creates/holds a BBManipTable
 * - keeps track of changes to the table model
 * - provides wrapper methods around the BBManipTable methods for ease
 *   of use </pre>
 *
 * @author Sowmya
 *
 */
public class TableManipulationPanel extends BBScrollPane 
{
	protected JTable				infoTable;
	protected DefaultTableModel	infoTableModel;

	protected boolean	bTableDataChanged=false;

	public void TableManipPanelInit()
	{
		Dimension preferredPanelSize = getPreferredSize();
		setPreferredSize(preferredPanelSize);

		// Keep track of changes to the table data model
		infoTableModel.addTableModelListener(new TableModelListener()
		{
			public void tableChanged(TableModelEvent e)
			{
				handleTableChanges(e.getColumn());
			}
		});

		// Listen for the delete key
		infoTable.addKeyListener(new KeyAdapter()
		{
			public void keyPressed(KeyEvent e)
			{
				if(e.getKeyCode() == KeyEvent.VK_DELETE)
				{
					int iSelectedRow = getSelectedRow();

					// Delete the row that was highlighted 
					if (iSelectedRow > -1)
						removeRow(iSelectedRow);
				}
			}

		});

	}

	public TableManipulationPanel(Vector colNames)
	{
		createTable(colNames);

		TableManipPanelInit();
	}

	public TableManipulationPanel(Vector rowData, Vector colNames)
	{
		createTable(rowData, colNames);

		TableManipPanelInit();
	}

	protected void createTable(Vector rowData, Vector colNames)
	{
		//Create the table
		infoTable = new  BBManipTable(rowData, colNames);

		infoTableModel = ((BBManipTable)infoTable).getTableModel();

		setViewportView(infoTable);
	}

	protected void createTable(Vector colNames)
	{
		//Create the table
		infoTable = new  BBManipTable(colNames);

		infoTableModel = ((BBManipTable)infoTable).getTableModel();

		setViewportView(infoTable);
	}

	/**
 	 * Sets focus to first column of the first row
 	 */
	public boolean initialFocus()
	{
		clearSelection();
		return ((BBManipTable)infoTable).setInitialFocus();
	}

	/**
 	 * Adds a new empty row  at the end of the table
 	 */
	protected void addEntryToTable()
	{
		int iColCount = infoTable.getColumnCount();
		Vector data = new Vector(iColCount);

		addRow(data);
	}
	
	protected void handleTableChanges(int column)
	{
		if (column != 0) // Don't consider the arrow row
			bTableDataChanged=true;
	}

	/**
 	 * Adds the new row passed in at the end of the table
 	 */
	public void addRow(Vector data)
	{
		((BBManipTable)infoTable).addRow(data);
		
	}

	/**
 	 * Pastes the new row passed in after the currently selected row
 	 */
	public void pasteRow(Vector data)
	{
		((BBManipTable)infoTable).pasteRow(data);
	}

	public JTable getTable()
	{
		return infoTable;
	}

	public DefaultTableModel getTableModel()
	{
		return ((BBManipTable)getTable()).getTableModel();
	}

	public boolean isTableChanged()
	{
		return bTableDataChanged;
	}

	public void setTableSaved()
	{
		bTableDataChanged=false;
	}

	public boolean validateValues(String panelName)
	{
		return ((BBManipTable)infoTable).validateValues(panelName);
	}

 	/*
	 * The methods below are just wrappers around the BBManipTableModel
	 * and BBManipTable methods - for convenience
	 */
	
	/**
 	 * Removes the row# iRow
 	 */
	public void removeRow(int iRow)
	{
		((BBManipTable)infoTable).removeRow(iRow);	

	}

	public Vector getTableColumns()
	{
		return ((BBManipTable)infoTable).getColumns();
	}
	
	public Vector getTableData()
	{
		return ((BBManipTable)infoTable).getData();
	}

	public int getRowCount()
	{
		return infoTableModel.getRowCount();
	}

	public int getColumnCount()
	{
		return infoTableModel.getColumnCount();
	}

	public void clearSelection()
	{
		// requestFocus();
		infoTable.requestFocus();
		infoTable.clearSelection();
	}

	public int getSelectedRow()
	{
		return infoTable.getSelectedRow();
	}
 	
	public void selectRow(int iRow)
	{
		infoTable.setRowSelectionInterval(iRow, iRow);
	}

 }

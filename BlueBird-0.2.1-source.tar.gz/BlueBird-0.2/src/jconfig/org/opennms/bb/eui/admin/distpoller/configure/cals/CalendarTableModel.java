//-------------------------------------------------------------------------------------------
//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

//--------------------------------------------------------------------------------------------

package org.opennms.bb.eui.admin.distpoller.configure.cals;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import javax.swing.table.*;
import javax.swing.event.*;

public class CalendarTableModel extends DefaultTableModel 
{
	schedulePanel	scPanel;
	
	CalendarTableModel(schedulePanel scPanel, Object[][] dataAllOff, Object[] columnNames) 
	{
		super(dataAllOff, columnNames);
		this.scPanel = scPanel;
	}

	/**
 	 * Sets the status column to be editable based on the return value
	 * of the On/Off status from the schedule panel
	 * If the user is in the 'Day of the Week', edit is only allowed if the
	 * status selected is 'MIXED'
	 * If the user is in 'Day of the Month', editing is allowed always 
 	 */
	public boolean isCellEditable(int row, int col) 
	{
		/*if (scPanel.getOnOffStatus() == scPanel.MIXED)
		{
			Class columnClass = getColumnClass(col);
			String name = getColumnName(col);
		
			boolean bRet = (name.equals("Status"));
			return bRet;
		}
		else
			return false;*/

		 return true;
	}
}

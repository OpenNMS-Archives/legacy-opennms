//-------------------------------------------------------------------------------------------
//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

//--------------------------------------------------------------------------------------------

package org.opennms.bb.eui.admin.distpoller.configure.cals;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;

import org.opennms.bb.eui.common.components.*;
import org.opennms.bb.eui.admin.distpoller.configure.dpconf.UserManager;


public class calendarMain extends JDialog {

	schedulePanel ep = new schedulePanel();
	JTextField nameField, descField;
	JLabel statusField = new JLabel();
	JTextField titleField = new JTextField();
	private boolean	m_bNew	= false;
	private String	sOldId	= "";

	public calendarMain(JFrame parent, boolean modal, String calName) {

		super(parent, modal);
		setTitle("Hours of Calendar Operation");
		
		 //Status bar label information
		statusField.setPreferredSize(new Dimension(600,20));
		statusField.setMinimumSize(new Dimension(600,20));
		statusField.setBorder(BorderFactory.createLoweredBevelBorder());
		statusField.setHorizontalAlignment(JTextField.LEFT);
		statusField.setFont(new Font("Helvetica",Font.BOLD, 11));
		statusField.setText(" Ready");


		titleField.setPreferredSize(new Dimension(600,20));
		titleField.setMinimumSize(new Dimension(600,20));
		titleField.setBackground(new Color(0,100,100)); 
		titleField.setForeground(Color.white);
		titleField.setBorder(BorderFactory.createRaisedBevelBorder());
		titleField.setHorizontalAlignment(JTextField.CENTER);
		titleField.setFont(new Font("Courier",Font.BOLD|Font.ITALIC, 20));
		titleField.setText(" One-time Calendar Builder ");
		titleField.setEnabled(false);
		

		nameField = new JTextField();
		nameField.setPreferredSize(new Dimension(150, 25));
		nameField.setMinimumSize(new Dimension(150, 25));
		nameField.setMaximumSize(new Dimension(150, 25));
		nameField.setText(calName);

		sOldId = calName;
		
		descField = new JTextField();
		descField.setPreferredSize(new Dimension(200, 25));
		descField.setMinimumSize(new Dimension(200, 25));
		descField.setMaximumSize(new Dimension(200, 25));

		if(!m_bNew)
		{
			String sBuffer = (String)UserManager.m_oOCAL.get(calName);
			if(sBuffer != null)
			{
				StringTokenizer oTokenizer = new StringTokenizer(sBuffer,":");

				String sTok = "";

				try
				{
					sTok = oTokenizer.nextToken();
				} catch(NoSuchElementException  e) { sTok = ""; }
				descField.setText(sTok);
			}
		}


		nameField.addMouseListener(new java.awt.event.MouseAdapter()
									  {
										public void mousePressed(java.awt.event.MouseEvent e)
										{
											nameField.setBackground(java.awt.Color.white);
										}
										public void mouseClicked(java.awt.event.MouseEvent e)
										{
											nameField.setBackground(java.awt.Color.white);
										}
									  }
									 );
		nameField.addKeyListener(new java.awt.event.KeyAdapter()
									  {
										public void keyTyped(java.awt.event.KeyEvent e)
										{
											nameField.setBackground(java.awt.Color.white);
										}
										public void keyPressed(java.awt.event.KeyEvent e)
										{
											nameField.setBackground(java.awt.Color.white);
										}
									  }
									 );

		SymWindow aSymWindow = new SymWindow();
		this.addWindowListener(aSymWindow);

		JPanel buttonPane = new JPanel();
		buttonPane.setLayout(new BoxLayout(buttonPane, BoxLayout.X_AXIS));
		buttonPane.setBorder(BorderFactory.createEmptyBorder(0, 10, 10, 10));
		buttonPane.add(new JLabel("Calendar Name:"));
		buttonPane.add(Box.createRigidArea(new Dimension(5, 0)));
		buttonPane.add(nameField);
		buttonPane.add(Box.createHorizontalGlue());
		buttonPane.add(Box.createRigidArea(new Dimension(5, 0)));
		buttonPane.add(new JLabel("Description:"));
		buttonPane.add(Box.createRigidArea(new Dimension(5, 0)));
		buttonPane.add(descField);
		
		addMenuBar();
		JPanel buttonPane1 = new JPanel();
		buttonPane1.setLayout(new BoxLayout(buttonPane1, BoxLayout.Y_AXIS));
		buttonPane1.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		buttonPane1.add(Box.createRigidArea(new Dimension(0, 5)));
		buttonPane1.add(buttonPane);
		buttonPane1.add(Box.createVerticalGlue());
		buttonPane1.add(Box.createRigidArea(new Dimension(0, 5)));
		buttonPane1.add(ep);
		buttonPane1.add(Box.createRigidArea(new Dimension(0, 5)));

		getContentPane().add(titleField, BorderLayout.NORTH);
		getContentPane().add(buttonPane1, BorderLayout.CENTER);
		getContentPane().add(statusField, BorderLayout.SOUTH);
		
		setSize(650,650);
		setLocationRelativeTo(parent);

		
	}

	public calendarMain(JFrame parent, String title, boolean modal, String groupName)
	{
		this(parent, modal, groupName);
		setTitle(title);
	}
	public calendarMain(JFrame parent, String title, boolean modal, String groupName, boolean isNew)
	{
		this(parent, title, modal, groupName);
		m_bNew = isNew;
	}


	void addMenuBar()
	{
		JMenuBar	oMainMenuBar		= new JMenuBar();
		JMenu		oFileMenu			= new JMenu();
		JMenu		oHelpMenu			= new JMenu();	
		JMenuItem	oSaveMenuItem		= new JMenuItem();
		JMenuItem	oExitMenuItem		= new JMenuItem();
		JMenuItem	oAboutMenuItem		= new JMenuItem();

		oFileMenu.setText("File");
		oFileMenu.setMnemonic('F');
		oMainMenuBar.add(oFileMenu);

		oSaveMenuItem.setText("Save");
		oSaveMenuItem.setActionCommand("Save");
		oSaveMenuItem.setMnemonic('s');
		oFileMenu.add(oSaveMenuItem);
		oSaveMenuItem.addActionListener(new MenuBarListener());

		oExitMenuItem.setText("Exit");
		oExitMenuItem.setActionCommand("Exit");
		oExitMenuItem.setMnemonic('x');
		oFileMenu.add(oExitMenuItem);
		oExitMenuItem.addActionListener(new MenuBarListener());
		
		
		
		oHelpMenu.setText("Help");
		oHelpMenu.setMnemonic('H');
		oMainMenuBar.add(oHelpMenu);
		oHelpMenu.add(oAboutMenuItem);
		oAboutMenuItem.addActionListener(new MenuBarListener());
		oAboutMenuItem.setText("About..");
		oAboutMenuItem.setActionCommand("About");
		oAboutMenuItem.setMnemonic('A');
		oMainMenuBar.setBorder(BorderFactory.createEtchedBorder());

		setJMenuBar(oMainMenuBar);
	}

	class SymWindow extends java.awt.event.WindowAdapter
	{
		public void windowClosing(java.awt.event.WindowEvent event)
		{
			Object object = event.getSource();
			if (object == calendarMain.this)
			{
				try
				{
					setVisible(false);
					UserManager.cancel();
					dispose();
				}
				catch (Exception e1)
				{
				}
			}
		}
	}
	public static void main(String args[]) 
	{

		try
		{
			(new calendarMain(new JFrame(), true, "Name")).setVisible(true);
		}
		catch (Exception e2)
		{
		}

	}
	class MenuBarListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e)
		{
			if(e.getActionCommand().equals("Exit"))
			{
				dispose();
			}
			else if(e.getActionCommand().equals("Save"))
			{
				statusField.setText(" Saved");
				
				String sId = nameField.getText();
				if( (sId == null) || sId.trim().equals(""))
				{
					Toolkit.getDefaultToolkit().beep();
				    nameField.setBackground(java.awt.Color.red);
					return;
				}
				try
				{
					if(m_bNew)
					{
						if(UserManager.m_oOCAL.containsKey(sId))
						{
							Toolkit.getDefaultToolkit().beep();
						    	nameField.setBackground(java.awt.Color.red);
							return;
						}
						UserManager.add(UserManager.OCAL, nameField.getText());
						UserManager.m_sBuffer= descField.getText();
						UserManager.m_sBuffer+= ":";
						
					}
					else
					{
						if((!sOldId.equals(sId)) && UserManager.m_oOCAL.containsKey(sId))
						{
							Toolkit.getDefaultToolkit().beep();
						    	nameField.setBackground(java.awt.Color.red);
							return;
						}
						UserManager.modify(UserManager.OCAL, sOldId);
						UserManager.m_sNewId = nameField.getText();
						UserManager.m_sBuffer= descField.getText();
						UserManager.m_sBuffer+= ":";
						
					}
				    	statusField.setText(" Saved");
				}
				catch (Exception e1)
				{
				}
				
			}
			else if(e.getActionCommand().equals("About"))
			{
		           	new AboutDialog(new JFrame(), "About BlueBird");
			}
		}
	}
}

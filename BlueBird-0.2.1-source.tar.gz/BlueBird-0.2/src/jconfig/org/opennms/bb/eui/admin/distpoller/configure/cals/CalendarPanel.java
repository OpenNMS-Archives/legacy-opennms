//-------------------------------------------------------------------------------------------
//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

//--------------------------------------------------------------------------------------------

package org.opennms.bb.eui.admin.distpoller.configure.cals;


import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import javax.swing.table.*;
import javax.swing.event.*;

public class CalendarPanel extends JPanel 
{
	/**
	 * Keep track of what status is currently selected
	 */
	int	  onOffStatus;

	String[] columnNames = { "Time", "Status"}; 

	Object[][] dataAllOff = {
			{ "12.00am",  new Boolean(false) },

			{ "12.15am",  new Boolean(false) },

			{ "12.30am",  new Boolean(false) },

			{ "12.45am",  new Boolean(false) },
	
			{ "1.00am",  new Boolean(false) },

			{ "1.15am",  new Boolean(false) },

			{ "1.30am",  new Boolean(false) },

			{ "1.45am",  new Boolean(false) },

			{ "2.00am",  new Boolean(false) },

			{ "2.15am",  new Boolean(false) },

			{ "2.30am",  new Boolean(false) },

			{ "2.45am",  new Boolean(false) },
	
			{ "3.00am",  new Boolean(false) },

			{ "3.15am",  new Boolean(false) },

			{ "3.30am",  new Boolean(false) },

			{ "3.45am",  new Boolean(false) },
			
			{ "4.00am",  new Boolean(false) },

			{ "4.15am",  new Boolean(false) },

			{ "4.30am",  new Boolean(false) },

			{ "4.45am",  new Boolean(false) },
	
			{ "5.00am",  new Boolean(false) },

			{ "5.15am",  new Boolean(false) },

			{ "5.30am",  new Boolean(false) },

			{ "5.45am",  new Boolean(false) },
			
			{ "6.00am",  new Boolean(false) },

			{ "6.15am",  new Boolean(false) },

			{ "6.30am",  new Boolean(false) },

			{ "6.45am",  new Boolean(false) },
	
			{ "7.00am",  new Boolean(false) },

			{ "7.15am",  new Boolean(false) },

			{ "7.30am",  new Boolean(false) },

			{ "7.45am",  new Boolean(false) },
			
			{ "8.00am",  new Boolean(false) },

			{ "8.15am",  new Boolean(false) },

			{ "8.30am",  new Boolean(false) },

			{ "8.45am",  new Boolean(false) },
	
			{ "9.00am",  new Boolean(false) },

			{ "9.15am",  new Boolean(false) },

			{ "9.30am",  new Boolean(false) },

			{ "9.45am",  new Boolean(false) },

			{ "10.00am",  new Boolean(false) },

			{ "10.15am",  new Boolean(false) },

			{ "10.30am",  new Boolean(false) },

			{ "10.45am",  new Boolean(false) },
	
			{ "11.00am",  new Boolean(false) },

			{ "11.15am",  new Boolean(false) },

			{ "11.30am",  new Boolean(false) },

			{ "11.45am",  new Boolean(false) },
			
						
			};

	Object[][] dataAllOn = {
			{ "12.00am",  new Boolean(true) },

			{ "12.15am",  new Boolean(true) },

			{ "12.30am",  new Boolean(true) },

			{ "12.45am",  new Boolean(true) },
	
			{ "1.00am",  new Boolean(true) },

			{ "1.15am",  new Boolean(true) },

			{ "1.30am",  new Boolean(true) },

			{ "1.45am",  new Boolean(true) },

			{ "2.00am",  new Boolean(true) },

			{ "2.15am",  new Boolean(true) },

			{ "2.30am",  new Boolean(true) },

			{ "2.45am",  new Boolean(true) },
	
			{ "3.00am",  new Boolean(true) },

			{ "3.15am",  new Boolean(true) },

			{ "3.30am",  new Boolean(true) },

			{ "3.45am",  new Boolean(true) },
			
			{ "4.00am",  new Boolean(true) },

			{ "4.15am",  new Boolean(true) },

			{ "4.30am",  new Boolean(true) },

			{ "4.45am",  new Boolean(true) },
	
			{ "5.00am",  new Boolean(true) },

			{ "5.15am",  new Boolean(true) },

			{ "5.30am",  new Boolean(true) },

			{ "5.45am",  new Boolean(true) },
			
			{ "6.00am",  new Boolean(true) },

			{ "6.15am",  new Boolean(true) },

			{ "6.30am",  new Boolean(true) },

			{ "6.45am",  new Boolean(true) },
	
			{ "7.00am",  new Boolean(true) },

			{ "7.15am",  new Boolean(true) },

			{ "7.30am",  new Boolean(true) },

			{ "7.45am",  new Boolean(true) },
			
			{ "8.00am",  new Boolean(true) },

			{ "8.15am",  new Boolean(true) },

			{ "8.30am",  new Boolean(true) },

			{ "8.45am",  new Boolean(true) },
	
			{ "9.00am",  new Boolean(true) },

			{ "9.15am",  new Boolean(true) },

			{ "9.30am",  new Boolean(true) },

			{ "9.45am",  new Boolean(true) },

			{ "10.00am",  new Boolean(true) },

			{ "10.15am",  new Boolean(true) },

			{ "10.30am",  new Boolean(true) },

			{ "10.45am",  new Boolean(true) },
	
			{ "11.00am",  new Boolean(true) },

			{ "11.15am",  new Boolean(true) },

			{ "11.30am",  new Boolean(true) },

			{ "11.45am",  new Boolean(true) },
			
						
			};

	
	CalendarTableModel tableModel;
	CalendarTable table;

	schedulePanel	scPanel;

	CalendarPanel(schedulePanel scPanel) 
	{
		this.scPanel = scPanel;
		
		tableModel = new CalendarTableModel(scPanel, dataAllOff, columnNames);
		table = new CalendarTable(tableModel);

		onOffStatus = scPanel.ALL_OFF;
		
		JScrollPane jsp = new JScrollPane(table);
		jsp.setPreferredSize(new Dimension(200,355));
		jsp.setMaximumSize(new Dimension(200,355));
		add(jsp, BorderLayout.CENTER);
	}

	public void setAllOn()
	{
		tableModel.setDataVector(dataAllOn, columnNames);
		table.sizeColumnsToFit(0);

		onOffStatus = scPanel.ALL_ON;
	}

	public void setAllOff()
	{
		tableModel.setDataVector(dataAllOff, columnNames);
		table.sizeColumnsToFit(0);

		onOffStatus = scPanel.ALL_OFF;
	}

	public void setMixed()
	{
		onOffStatus = scPanel.MIXED;
	}

	public int getOnOffStatus()
	{
		return onOffStatus;
	}
}


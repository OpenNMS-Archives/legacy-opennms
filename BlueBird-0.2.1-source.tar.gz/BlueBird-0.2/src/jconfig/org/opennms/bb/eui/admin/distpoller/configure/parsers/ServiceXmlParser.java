//-------------------------------------------------------------------------------------------
//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

//--------------------------------------------------------------------------------------------

package org.opennms.bb.eui.admin.distpoller.configure.parsers;

import org.opennms.bb.eui.admin.distpoller.configure.dpconf.*;

import org.w3c.dom.*;

import java.io.*;
import java.util.Vector;
import java.util.Enumeration;

import org.opennms.bb.common.utils.BBParser;

/**
 * @author: Jayakrishna Chakravarthula
 *
 * Modifications:
 * 04/18/200 - Changed the parser to extend BBParser - sk
 */
public class ServiceXmlParser extends BBParser
{
	
	Vector servicesData		= 	new Vector();
	Vector servicesProp		= 	new Vector();

	Vector serviceDetailsVector 	= 	new Vector();
	Vector servicePropVector 	= 	new Vector();
	Vector rangeDefDetailsVector  =	new Vector();

	Vector defCols, rangedefData, erangeCols, irangeCols, specificCols, urlCols;

	/*
	 * XML TAGS
	 */
	final String APPL			=	"appl";
	final String PARMS		=	"parms";
	final String PARM 		=	"parm";
	final String PARM_NAME		=	"parmName";
	final String PARM_VALUE		=	"value";

	final String SERVICE 		= 	"service";
	final String SERVICES 		= 	"services";
	final String NAME			=	"name";
	final String DESCR		= 	"descr";
	final String RANGEDEF		=	"rangeDef";


	// Number of default parameters
	int 	iNumDefParms=0;

	public ServiceXmlParser()
	{
		super();
	}

	protected boolean processElement(Element el, boolean isRoot)
	{
		boolean bRet	=	false;
		String tag	 	= 	el.getTagName();

		if (tag.equals(APPL))
		{
			bRet = processApplElement(el);	
		}
		else
		{
			boolean bNodeRet	=	true;
			NodeList nl 	= 	el.getChildNodes();
			int size 		=	nl.getLength();

			for(int i = 0;i < size && bNodeRet ;i++)
				bNodeRet = processNode(nl.item(i));
			
			bRet 			=	 bNodeRet;
		}
		return bRet;
	}


	protected boolean processApplElement(Node defNode)
	{
		boolean bRet	=	 true;
		NodeList nl 	=	 defNode.getChildNodes();
		int size 		=	 nl.getLength();
		rangedefData 	= 	new Vector();

		for(int i = 0;i < size && bRet ;i++)
		{
			Node curNode = nl.item(i);
			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
			
				if(curTag.equals(SERVICES))
				{
					bRet = processServiceElement(curNode);
				}
				else if (curTag.equals(RANGEDEF))
				{
					
					bRet 		=	 processRangeDefRangeDef(curNode);

					// Create column names vector
					int iNumCols = rangedefData.size();
					defCols = new Vector(iNumCols);
					for (int iIndex=0; iIndex < iNumCols; iIndex++)
					{
						Vector temp = (Vector)rangedefData.elementAt(iIndex);
						defCols.add(temp.elementAt(0)); // attribute
					}

					//exclude range columns
					erangeCols = new Vector(2);
					erangeCols.add(0, "From IP Address");
					erangeCols.add(1, "To IP Address");

					//include range columns
					irangeCols = (Vector)defCols.clone();
					irangeCols.add(0, "From IP Address");
					irangeCols.add(1, "To IP Address");

					//specific devices columns
					specificCols = (Vector)defCols.clone();
					specificCols.add(0, "IP Address");
					
					//url config columns
					urlCols = (Vector)defCols.clone();
					urlCols.add(0, "File Name");


					//bRet = processRangeDefParams(curNode);
				}
			}
			
		}
		return bRet;
	}


	protected boolean processRangeDefRangeDef(Node rangeDefNode)
	{
		boolean bRet 		= 	true;
		NodeList nl 		= 	rangeDefNode.getChildNodes();
		int size 			= 	nl.getLength();
	
		for(int i = 0;i < size; i++)
		{
			Node curNode	 = 	nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = 	((Element)curNode).getTagName();
		
				if(curTag.equals(PARMS))
				{
					bRet 	= 	processRangeDefParms(curNode);
				}
			}
		}
		
		return bRet;
	}

	protected boolean processRangeDefParms(Node parmsNode)
	{
		boolean bRet = true;
		NodeList nl = parmsNode.getChildNodes();
		int size = nl.getLength();

		for(int i = 0;i < size && bRet;i++)
		{
			Node curNode = nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
				if(curTag.equals(PARM))
				{
					Vector parm = processParm(curNode);

					if (parm.isEmpty() || parm.size() != 2)
					{
						bRet = false;
						m_errNum = ATTRIB_VALUE_PAIR_ERR;
					}
					else
					{
						rangedefData.add(parm);
						iNumDefParms++;
					}
				}
			}
		}
		return bRet;
	}



	/*protected boolean processRangeDefParams(Node parmsNode)
	{
		boolean bRet		=	 true;
		String tempElement 	=	 null;
		Vector rangeDefVector 	=	 new Vector();
		NodeList nl 		=	 parmsNode.getChildNodes();
		int size 			=	 nl.getLength();

		for(int i = 0;i < size && bRet;i++)
		{
			Node curNode 	=	 nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
						
				if (curTag.equals(PARMS))
				{
					int iNumParms 	= 	processParms(curNode, rangeDefVector);
					rangeDefDetailsVector.add(rangeDefVector);

				}
			
			}
		}
		return bRet;
	}



	*/

	protected boolean processServiceElement(Node defNode)
	{
		boolean bRet	=	 true;
		NodeList nl 	=	 defNode.getChildNodes();
		int size 		=	 nl.getLength();

		for(int i = 0;i < size && bRet ;i++)
		{
			Node curNode = nl.item(i);
			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
			
				if(curTag.equals(SERVICE))
					bRet = processServiceParms(curNode);
			}
			
		}
		return bRet;
	}

	protected boolean processServiceParms(Node parmsNode)
	{
		boolean bRet		=	 true;
		String tempElement 	=	 null;
		Vector serviceParmsVector 	=	 new Vector();
		NodeList nl 		=	 parmsNode.getChildNodes();
		int size 			=	 nl.getLength();

		for(int i = 0;i < size && bRet;i++)
		{
			Node curNode 	=	 nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
						
				if (curTag.equals(NAME))
				{
					tempElement		=	 processPollerValue(curNode);
					if (null != tempElement)
					{
						serviceDetailsVector.addElement(tempElement);
						servicePropVector.addElement(curTag + " : " + tempElement);
					}
					else
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}

					
				}
				else if (curTag.equals(DESCR))
				{
					tempElement 	=	 processPollerValue(curNode);
					if (null != tempElement)
						servicePropVector.addElement(tempElement);
					else
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}

				}
				else if (curTag.equals(PARMS))
				{
					int iNumParms 	= 	processParms(curNode, serviceParmsVector);
					serviceDetailsVector.addElement(serviceParmsVector);
				}
			
			}
		}

		if (servicesData.isEmpty()  || !servicesData.contains(serviceDetailsVector) )
			servicesData.add(serviceDetailsVector);

		if (servicesProp.isEmpty() || !servicesProp.contains(servicePropVector) )
			servicesProp.add(servicePropVector);

		return bRet;
	}

	protected String processPollerValue(Node parmValueNode)
	{
		String value	=	null;

		Node temp		=	parmValueNode.getChildNodes().item(0);
	
		if (temp.getNodeType() == Node.TEXT_NODE)
			value = ((Text)temp).getData();
		else if (temp.getNodeType() == Node.CDATA_SECTION_NODE)
			value = ((CDATASection)temp).getData();
			
		return value;
	}

	protected int processParms(Node tabNode, Vector tabVector)
	{
		int iNumParms	=	0;
		NodeList nl 	=	tabNode.getChildNodes();
		int size 		= 	nl.getLength();

		for(int i = 0;i < size;i++)
		{
			Node curNode 	= 	nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
				
				if(curTag.equals(PARM))
				{
					Vector parm		=	 processParm(curNode);
					tabVector.add(parm);
					iNumParms++;
				}
			}
		}

		return iNumParms;
	}


	protected Vector processParm(Node parmsNode)
	{
		Vector parm		=	new Vector(2);
		NodeList nl		= 	parmsNode.getChildNodes();
		int size 		=	nl.getLength();

		for(int i = 0;i < size;i++)
		{

			Node curNode = nl.item(i);
			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
				if(curTag.equals(PARM_NAME))
				{
					String name = processParmName(curNode);
					if (null != name)
						parm.add(name);
				}
				else if(curTag.equals(PARM_VALUE))
				{
					String value = processParmValue(curNode);
					if (null != value)
						parm.add(value);
				}
			}
		}
		
		return parm;
	}

	protected String processParmName(Node parmNameNode)
	{
		String parmName	=	null;
		Node temp 		=	parmNameNode.getChildNodes().item(0);

		if (temp.getNodeType() == Node.TEXT_NODE)
			parmName = ((Text)temp).getData();
		
		return parmName;
	}

	public Vector getErangeCols() 
	{	
		return (Vector)erangeCols;
	}
	
	public Vector getIrangeCols() 
	{	
		return (Vector)irangeCols;
	}
	
	public Vector getSpecificCols() 
	{	
		return (Vector)specificCols;
	}

	public Vector getUrlCols() 
	{
		return (Vector)urlCols;
	}


	//returns services details data
	public Vector getServicesData()
	{
		return servicesData;
	}

	public Vector getServicesProp()
	{
		return servicesProp;
	}
	
	public Vector getRangeDefData()
	{
		//return (Vector)rangeDefDetailsVector.elementAt(0);
		return (Vector)rangedefData;
	}

	public void printRangeDef()
	{
		System.out.println("---------------RangeDef------------");
	
		Enumeration enum = rangeDefDetailsVector.elements();
		Vector temp = (Vector)enum.nextElement();
		Enumeration enum1 = temp.elements();
		while (enum1.hasMoreElements())
		{
			System.out.println(enum1.nextElement());
		}
		System.out.println("---------------End RangeDef------------");

	}

	public void printservicesProp()
	{
		Enumeration enum = servicesProp.elements();
		while (enum.hasMoreElements())
		{
			Vector temp = (Vector)enum.nextElement();
			Enumeration enum1 = temp.elements();
			while (enum1.hasMoreElements())
			{
				System.out.println(enum1.nextElement());
			}
		}
	}

	public void printservicesData()
	{
		System.out.println("---------------SERVICE------------");

		Enumeration enum = servicesData.elements();
		while (enum.hasMoreElements())
		{
			Vector temp = (Vector)enum.nextElement();	
			Enumeration en = temp.elements();
			while (en.hasMoreElements())
			{
				Object dummy = en.nextElement();
				if (dummy instanceof String)
				{
					System.out.println(dummy);
					
				}
			    	else 	if (dummy instanceof Vector)
				{
					//System.out.println("Ajalias");
					Vector temp1 = (Vector)dummy;
					Enumeration en1 = temp1.elements();
					while (en1.hasMoreElements())
						System.out.println(en1.nextElement());
				}
				System.out.println(" ");

			}
			System.out.println(" ");
			
		}

		System.out.println("---------------END SERVICE------------");
	}
	public static void main(String args[]) throws Exception
	{
		ServiceXmlParser sx = new ServiceXmlParser();	
		//sx.printservicesProp();
		sx.printRangeDef();
	}

}

//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.admin.snmp.panels;

import javax.swing.JOptionPane;
import java.util.Vector;

/**
 * UrlConfigmanipPanel is the panel for the 'Url Configuration' tab
 *
 * @author Sowmya 
 *
 */

class UrlConfigManipPanel extends SnmpFileTableManipulationPanel
{
	protected UrlConfigManipPanel(Vector colNames)
	{
		super(colNames);
	}

	protected UrlConfigManipPanel(Vector data, Vector colNames)
	{
		super(data, colNames);

	}

	/**
	 * Adds a row with data '<filename>' '<default>' ...
	 */
	protected void addEntryToTable()
	{
		int iColCount = getColumnCount();
		Vector data = new Vector(iColCount);
		
		data.add("<filename>");
		data.add(Boolean.FALSE);  
		for(int iIndex = 3; iIndex < iColCount; iIndex++)
			data.add("<default>");

		addRow(data);
	}

	protected boolean validateValues()
	{
		if (checkForDuplicateEntries())
			return false;

		return super.validateValues("URL Configuration Panel");
	}

	/**
	 * Checks if rows contain duplicate values
	 *
	 * @return true if more than one row has the same filename
	 */
	protected boolean checkForDuplicateEntries()
	{
		Vector urlData = (Vector)getTableData();
		int    iNumUrlEntries = getRowCount();

		for(int iIndex1=0; iIndex1<(iNumUrlEntries-1); iIndex1++)
		{
			Vector	vector1=(Vector)urlData.elementAt(iIndex1);

			for(int iIndex2=iIndex1+1; iIndex2<iNumUrlEntries; iIndex2++)
			{
				Vector	vector2=(Vector)urlData.elementAt(iIndex2);

				// compare url entry
				String url1 = (String)vector1.elementAt(0);
				String url2 = (String)vector2.elementAt(0);

				if(url1.equals(url2))
				{
		 			JOptionPane.showMessageDialog(null, 
						"Duplicate entry found for " + vector1.elementAt(0), 
						"Duplicate Entries in URL Configuration!", 
						JOptionPane.WARNING_MESSAGE);

					// found duplicate!
					return true;
				}
			}
		}

		return false;
	}
}

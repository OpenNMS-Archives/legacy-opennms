//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.operator.panels;

import javax.swing.*;

import java.awt.*;
import java.awt.event.*;

import java.util.*;

import org.opennms.bb.eui.common.components.BBTBButton;
import org.opennms.bb.eui.admin.utils.PitXmlParser;

/**
 * <pre> OperatorToolPanel creates the standard operator menu and also
 * creates the external menu if available for the user from the
 * 'ExternalTools' filename specified in the user's user profile file
 *
 * @author Sowmya
 */
class OperatorToolPanel extends JPanel implements ActionListener
{
	OperatorInterfacePanel operatorParent;

	protected OperatorToolPanel(OperatorInterfacePanel panel)
	{
		operatorParent = panel;

		setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
		
		// system tools
		JPanel sysToolPanel = new JPanel();
		sysToolPanel.setLayout(new BorderLayout());

		// system toolbar
		JToolBar sysToolBar = createToolBar();
		sysToolPanel.add(sysToolBar, BorderLayout.SOUTH);

		// border
		sysToolPanel.setBorder(BorderFactory.createRaisedBevelBorder());
		
	 	add(sysToolPanel);

		// user toolbar
		JToolBar userToolBar = createExternalToolBar();
		if (null != userToolBar)
		{
			// user tools
			JPanel userToolPanel = new JPanel();
			userToolPanel.setLayout(new BorderLayout());

			// border
			userToolPanel.setBorder(BorderFactory.createRaisedBevelBorder());
		
			userToolPanel.add(userToolBar, BorderLayout.SOUTH);

			add(Box.createHorizontalStrut(5));
	 		add(userToolPanel);

			Dimension sysPrefSize = sysToolPanel.getPreferredSize();
			Dimension newSysPrefSize = new Dimension(250, sysPrefSize.height);
			sysToolPanel.setPreferredSize(newSysPrefSize);
			sysToolPanel.setMinimumSize(newSysPrefSize);
			sysToolPanel.setMaximumSize(newSysPrefSize);
		}
	}

	/**
	 * Creates the standard tool bar
	 */
	protected JToolBar createToolBar()
	{
		BBTBButton 	upButton, topLevelButton, alertButton;
	 	BBTBButton 	nameSortButton, severityButton, configureButton;

		JToolBar toolBar = new JToolBar();

		// up
		upButton = new BBTBButton("data/images/up.gif", 
									"Move Up", "Move Up one level");
		upButton.addActionListener(this);
		toolBar.add(upButton);

		// top level
		topLevelButton = new BBTBButton(
									"data/images/root.gif", 
									"Go Top Level", 
									"Move to the topmost level");
		topLevelButton.addActionListener(this);
		toolBar.add(topLevelButton);

		// alert browser
		alertButton = new BBTBButton("data/images/events.gif", 
									 "Alert Browser", 
									 "Bring up the alert browser");
		alertButton.addActionListener(this);
		toolBar.add(alertButton);

		toolBar.addSeparator(new Dimension(10, 10));

		// sort by name
		nameSortButton = new BBTBButton(
									"data/images/nsort.gif", 
									"Name Sort", 
									"Sort by name");
		nameSortButton.addActionListener(this);
		toolBar.add(nameSortButton);

		// sort by severity
		severityButton = new BBTBButton(
								"data/images/ssort.gif", 
								"Severity Sort", 
								"Sort by severity");
		severityButton.addActionListener(this);
		toolBar.add(severityButton);

		toolBar.addSeparator(new Dimension(10, 10));

		// configure folder tabs
		configureButton = new BBTBButton(
							"data/images/configurefolders.gif", 
							"Configure Folders", 
							"Configure folders from the available list");
		configureButton.addActionListener(this);
		toolBar.add(configureButton);

		// set the appropriate toolbar buttons in the operatorParent
		operatorParent.upButton = upButton;
		operatorParent.topLevelButton = topLevelButton;
		operatorParent.alertButton = alertButton;
		operatorParent.nameSortButton = nameSortButton;
		operatorParent.severityButton = severityButton;
		operatorParent.configureButton = configureButton;

		toolBar.setFloatable(false);
		return toolBar;
	}

	/**
	 * Creates the external toolbar
	 */
	protected JToolBar createExternalToolBar()
	{
		final String TOOL="ExternalTools";

		// get external menu filename from user profile
		Hashtable userProfile = operatorParent.getUserProfile();
		String filename= String.valueOf(userProfile.get(TOOL));

		// Toolbar parser
		PitXmlParser		operatorToolsParser;

		// Parse the xml file first
		try
		{
			operatorToolsParser=new PitXmlParser();
			operatorToolsParser.parse(filename);

		} catch (Exception e)
		{
			return null;
		}


		// tool bar
		JToolBar toolBar = new JToolBar();

		Vector				operatorControls;

		final String ICON		="icon";
		final String SEPARATOR	="separator.gif";

		final String HINT		="hint";
		final String CLASSNAME	="classname";
		final String CLASSTYPE	="type";
		final String INTERNAL	="internal";
		final String EXTERNAL	="external";

		// operator controls
		operatorControls = operatorToolsParser.getToolsData();
		int numOptions = operatorControls.size();

		if (numOptions != 0)
		{
			toolBar.addSeparator(new Dimension(10, 10));
		}

		for(int iIndex=0; iIndex< numOptions; iIndex++)
		{
			Hashtable control = (Hashtable)operatorControls.elementAt(iIndex);

			// create button
			String icon = String.valueOf(control.get(ICON));

			// check if separator
			if (icon.equals(SEPARATOR))
			{
				toolBar.addSeparator(new Dimension(10, 10));
				continue;
			}

			ImageIcon buttonIcon =new ImageIcon(icon);

			BBTBButton button = 
				new BBTBButton(buttonIcon, String.valueOf(control.get(HINT)));

			button.setAlignmentX(Component.CENTER_ALIGNMENT);
			
			// get classname
			final String command=String.valueOf(control.get(CLASSNAME)).trim();

			// set action
			button.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent event)
				{
					String usrCommand=null;

					// Parse to see if command requires user input
					String var = parseCommand(command.toString());
					if (var == null)
					{
						usrCommand = command.toString();
					}
					else
					{
						VarInputPanel vPanel = new VarInputPanel(var);

						final JOptionPane pane = new JOptionPane(
												vPanel, 
												JOptionPane.PLAIN_MESSAGE,
												JOptionPane.OK_CANCEL_OPTION);
						JDialog dialog = pane.createDialog(null, "Command Variable");

						dialog.show();

						String value=null;
						Integer option = (Integer)pane.getValue(); 

						if (option.intValue() == JOptionPane.OK_OPTION)
							value = vPanel.getText();

						if (value != null)
							usrCommand = replaceVarInCommand(command.toString(), value);
					}

					if (usrCommand == null)
						return;

					try
					{
						Runtime.getRuntime().exec(usrCommand.toString());
					}
					catch (Exception e)
					{
	 					JOptionPane.showMessageDialog(new JFrame(), 
							"Unable to start external operator control \'" + 
						 	usrCommand+"\'\nException: " + e.getMessage(),
							"Error!", 
							JOptionPane.ERROR_MESSAGE);
					}
				}
			});

			toolBar.add(button);
		}
		
		toolBar.setFloatable(false);
		return toolBar;
	}

	String parseCommand(String command)
	{
		int startInd = command.indexOf('%');
		if (startInd == -1)
			return null;

		int endInd   = command.indexOf('%', startInd+1);
		if (endInd == -1)
			return null;

		String var = command.substring(startInd+1, endInd);
		return var;
	}

	String replaceVarInCommand(String command, String value)
	{
		StringBuffer buf = new StringBuffer(command);
		
		int startInd = command.indexOf('%');
		int endInd   = command.indexOf('%', startInd+1);

		buf.replace(startInd, endInd+1, value);

		return buf.toString();
	}


	/**
	 * Allow the operatorParent to handle all the actions
	 */
	public void actionPerformed(ActionEvent e)
	{
		String actionStr = e.getActionCommand();

		operatorParent.handleMenuToolBarActions(actionStr);
	}
}

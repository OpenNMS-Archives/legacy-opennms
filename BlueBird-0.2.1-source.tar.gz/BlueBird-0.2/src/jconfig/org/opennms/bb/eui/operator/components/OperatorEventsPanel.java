//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.operator.components;

import javax.swing.*;
import javax.swing.table.*;

import java.awt.*;
import java.awt.event.*;

import java.io.IOException;
import java.util.Vector;
import java.util.Hashtable;
import java.util.Enumeration;
import java.util.StringTokenizer;

import org.opennms.bb.eui.operator.utils.*;
import org.opennms.bb.eui.operator.utils.datablocks.*;
import org.opennms.bb.eui.common.components.BBScrollPane;
import org.opennms.bb.eui.common.components.BBDisplayTable;

/**
 * <pre>OperatorEventsPanel is the event browser panel that brings up 
 * the table with event info.
 *
 * A right-click popup allows user to see more details about the event
 *
 * @author Sowmya
 *
 * Modifications:
 * 10/24/2000 - Changed the alert browser to add 2 new columns - Jacinta.
 */
public class OperatorEventsPanel extends BBScrollPane
{
	
	/*
	 * XML TAGS that are relevant
	 */
	final String SOURCE		="source";
	final String EID		="eid";
	final String TIME		="time";
	final String HOST		="host";
	final String PARMS		="parms";
	final String PARM		="parm";
	final String NAME		="name";
	final String VALUE		="value";

	final String SPECIFIC	="specific";
	final String GENERIC	="generic";
	final String SEVERITY	="Severity";
	final String DESCR		="Description";

	final String INSTRUCTIONS	="Operator Instructions";
	final String EVENT_OVERVIEW	="Event Overview";
	
	/***********************************************************************
		Changes made by Jacinta on 24th Oct 2000
	*/
	final String AUTO			="autoaction";
	final String ACTION			="operaction";
	final String SNMPHOST		="snmphost";
	final String OPERINSTRUCT	="operinstruct";
	final String AUTOACTION		="autoaction";
	final String OPERACTION		="operaction";
	final String LOGGROUP		="loggroup";
	final String NOTIFICATION	="notification";
	final String TTICKET		="tticket";
	final String FORWARD		="forward";
	final String MOUSEOVERTEXT	="mouseovertext";
	final String UEI			="uei";
	final String LOGMSG			="Log Msg";
	
	/***********************************************************************/

	// table
	OperatorEventsTable eventsTable;

	// events data
	Vector		eventsVector;
 
	public OperatorEventsPanel(String ID, String dataFileName)

						 throws IOException
	{
		//EUIEventsParser	parser;
		EventsParser	parser;

		try
		{
			//parser=new EUIEventsParser();
			parser=new EventsParser();
			parser.parse(dataFileName);
		}
		catch(IOException e)
		{
	 		JOptionPane.showMessageDialog(new JFrame(), 
					e.getMessage(), 
					"Data unavailable at the moment", 
					JOptionPane.ERROR_MESSAGE);

			throw(e);
		}
		catch(Exception e)
		{
	 		JOptionPane.showMessageDialog(new JFrame(), 
					e.getMessage(), 
					"Unknown Exception", 
					JOptionPane.ERROR_MESSAGE);

			return;
		}

		eventsVector = parser.getEvents();		// Returns a vector of event blocks

		Vector colNames = new Vector();
		colNames.add("Severity");
		colNames.add("Time");
		colNames.add("DP Name");
		colNames.add("Host");
		colNames.add("Event Overview");
	
		/*****************************************************************
			Changes made by Jacinta on Oct 24 '2000
		*/
		colNames.add("Action");
		colNames.add("Auto");
		
		/****************************************************************/
		
		Vector tableData = new Vector();
		Vector task = new Vector();

		int iSize = eventsVector.size();
		for (int iIndex=0; iIndex < iSize; iIndex ++)
		{
			/***********************************************************************
				Changes made by Jacinta
			*/
			
			EventBlock evBlk = (EventBlock)eventsVector.elementAt(iIndex);
			
			/************************************************************************/
			Vector rowVector = new Vector();

			Object severity = evBlk.m_severity;

			if (null == severity)
				rowVector.add("-");
			else
				rowVector.add(severity);
			
			/*****************************************************************
				Changes made by Jacinta on Oct 24 '2000
			*/

			if(null == evBlk.m_time)
				rowVector.add("-");
			else
				rowVector.add(evBlk.m_time);

			Object dpname = evBlk.m_eventHeader.m_dpName;
			if(null == dpname)
				rowVector.add("-");
			else
				rowVector.add(dpname);
			
			if(null == evBlk.m_host)
				rowVector.add("-");
			else
				rowVector.add(evBlk.m_host);

			if(null == (String)evBlk.m_eventParms.get(EVENT_OVERVIEW))
				rowVector.add("-");
			else
				rowVector.add((String)evBlk.m_eventParms.get(EVENT_OVERVIEW));	// Event Overview



			Vector operAction = (Vector)evBlk.m_operAction;
			
			if(null == operAction)
				rowVector.add("-");
			else
			{
				String tmp = (String) operAction.elementAt(0);
				if(tmp.indexOf("\\") > 0)
				{
				//	rowVector.add(tmp.substring(tmp.indexOf("\\")+1, tmp.length()));
				//	task.addElement( tmp.substring(0, tmp.indexOf("\\")));
				rowVector.add(tmp);
				}
			}

			Vector autoAction = (Vector)evBlk.m_autoAction;
			if(null == autoAction)
				rowVector.add("-");
			else
				rowVector.add((String)autoAction.elementAt(0));
			/****************************************************************/
			tableData.add(rowVector);
		}

		eventsTable = new OperatorEventsTable(tableData, colNames, task);

		setViewportView(eventsTable);

		// mouse listener
		eventsTable.addMouseListener(new MouseAdapter()
		{
			public void mouseClicked(MouseEvent e)
			{
				if (e.getClickCount() == 1  && 
										SwingUtilities.isRightMouseButton(e))
				{
					OperatorEventsTable table = (OperatorEventsTable)e.getSource();
					int iSelRow = table.getSelectedRow();
					if (iSelRow != -1)
					{
						JPopupMenu popup = new JPopupMenu();
						JMenuItem menuItem = new JMenuItem("Show Details");
						menuItem.addActionListener(new RowDetailActionListener());
						popup.add(menuItem);

						popup.show(table, e.getX(), e.getY());
					}
				}
			}
		});
	}

	/**
	 * Right-click popup action listener
	 */
	class RowDetailActionListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e)
		{
			displayDetails();
		}
	}

	/**
	 * Display all the details
	 */
	void displayDetails()
	{
		int iSelRow = eventsTable.getSelectedRow();
		if (iSelRow == -1) // cannot be but..
			return;

		/*
		 * Ask the table for the original index of the currently selected
		 * row so as to get data from the eventsVector
		 */
		int iOrigRow = eventsTable.getOriginalRowIndex(iSelRow);

		// point to new row
		//Vector event = (Vector)eventsVector.elementAt(iOrigRow);
		/***************************************************************/
		//Hashtable hash = (Hashtable)event.elementAt(0);
		EventBlock eventBlk = (EventBlock)eventsVector.elementAt(iOrigRow);
	
		// new table data
		Vector detailsData = new Vector();

		// get severity
		Object obj = eventBlk.m_severity;
		if (obj == null)
			obj = "-";
		Vector severity = new Vector();
		severity.add(SEVERITY);
		severity.add(obj);

		// uei
		obj = eventBlk.m_uei;
		if (obj == null)
			obj = "-";
		Vector evUei = new Vector();
		evUei.add(UEI);
		evUei.add(obj);

		// time
		obj = eventBlk.m_time;
		if (obj == null)
			obj = "-";
		Vector evTime = new Vector();
		evTime.add(TIME);
		evTime.add(obj);

		// m_logMsg
		obj = eventBlk.m_logMsg;
		if(obj != null)
		{
			String tmp = (String)obj;
			if(tmp != null && tmp.indexOf("/") > 0)
			{
				obj = tmp.substring(0, tmp.indexOf("/"));
			}
		}
		if (obj == null)
			obj = "-";
		Vector evLogmsg = new Vector();
		evLogmsg.add(LOGMSG);
		evLogmsg.add(obj);

		// host
		obj = eventBlk.m_host;
		if (obj == null)
			obj = "-";
		Vector host = new Vector();
		host.add(HOST);
		host.add(obj);

		// get source
		obj = eventBlk.m_source;
		if (obj == null)
			obj = "-";
		Vector source = new Vector();
		source.add(SOURCE);
		source.add(obj);

		// eid
		obj = eventBlk.m_snmpInfo.m_eid;	
		if (obj == null)
			obj = "-";
		Vector eid = new Vector();
		eid.add(EID);
		eid.add(obj);

		// generic
		obj = eventBlk.m_snmpInfo.m_generic;
		if (obj == null)
			obj = "-";
		Vector generic = new Vector();
		generic.add(GENERIC);
		generic.add(obj);

		// specific
		obj = eventBlk.m_snmpInfo.m_specific;
		if (obj == null)
			obj = "-";
		Vector specific = new Vector();
		specific.add(SPECIFIC);
		specific.add(obj);

		// add these
		detailsData.add(severity);
		detailsData.add(evTime);
		detailsData.add(host);
		detailsData.add(evLogmsg);
		detailsData.add(evUei);
		detailsData.add(source);
		detailsData.add(eid);
		detailsData.add(specific);
		detailsData.add(generic);
		
		// add the rest of the parameters
		Hashtable event = eventBlk.m_eventParms;
		Enumeration eventEnum = event.keys();
		while(eventEnum.hasMoreElements())
		{
			String key = (String)eventEnum.nextElement();
			Vector parms = new Vector();
			parms.add(key);
			parms.add(event.get(key));
			detailsData.add(parms);
		}
		
		//Object descr  = hash.get(DESCR);
		Object descr = eventBlk.m_descr;
		if (null == descr)
			descr = "none";
		
		Object opInst = eventBlk.m_operInstr;
		if (null == opInst)
			opInst = "none";

		// Logtype	
		Object logtype = eventBlk.m_logType;
		if (null == logtype)
			logtype = "none";
		
		Object logGroup = eventBlk.m_logGroup;
		if (null == logGroup)
			logGroup = null;
		
		Object notification = eventBlk.m_notification;
		if (null == notification)
			notification = null;

		Object forward = eventBlk.m_forward;
		if (null == forward)
			forward = null;
		
		Object autoaction = eventBlk.m_autoAction;
		if (null == autoaction)
			autoaction = null;
		
		Object operaction = eventBlk.m_operAction;
		if (null == operaction)
			operaction = null;

		Object tticket = eventBlk.m_tticket;
		if (null == tticket)
			tticket = "none";

		new EventDetails(detailsData, 
				String.valueOf(descr), 
				String.valueOf(opInst), 
				String.valueOf(logtype), 
				(Vector)logGroup, 
				(Vector)notification, 
				(Vector)forward, 
				(Vector)autoaction, 
				(Vector)operaction, 
				String.valueOf(tticket));
		/***************************************************************/

	}

	/**
	 * <pre>EventDetails dialog displays all the details of the event selected
	 * Displays the event description and operator instructions separately
	 *
	 */
	class EventDetails extends JDialog
	{
		EventDetails(Vector detailsData, String eventDescr, String opInst, String logtype, 
Vector loggrp, Vector notification, Vector forward, Vector autoaction, Vector operaction, String tticket )
		{
			setTitle("Event Detail");

			Vector colNames = new Vector();
			colNames.add("Attribute");
			colNames.add("Value");

			// details
			BBDisplayTable detailsTable = 
								new BBDisplayTable(detailsData, colNames);
			detailsTable.setTableDimension(400, 100);

			BBScrollPane tabScr = new BBScrollPane(detailsTable);
			tabScr.setAlignmentX(Component.LEFT_ALIGNMENT);

			tabScr.setPreferredSize(new Dimension(405, 200));

			// descr
			JTextArea desText = new JTextArea(eventDescr);
			desText.setLineWrap(true);
			desText.setWrapStyleWord(true);
			desText.setEditable(false);

			JScrollPane desScr = new JScrollPane(desText);
			desScr.setAlignmentX(Component.LEFT_ALIGNMENT);
			desScr.setPreferredSize(new Dimension(405, 60));
			
			// op instr
			JTextArea opText = new JTextArea(opInst);
			opText.setLineWrap(true);
			opText.setWrapStyleWord(true);
			opText.setEditable(false);
			
			JScrollPane opScr = new JScrollPane(opText);
			opScr.setAlignmentX(Component.LEFT_ALIGNMENT);
			opScr.setPreferredSize(new Dimension(405, 60));
			
			// labels
			JLabel tabLabel = new JLabel("Event Details");
			tabLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

			JLabel desLabel = new JLabel("Event Description");
			desLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

			JLabel opLabel  = new JLabel("Operator Instructions");
			opLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
			
			/************************************************************/

			JLabel logTypeLabel = new JLabel("Log Types");
			logTypeLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

			JLabel loggrpLabel  = new JLabel("Log groups");
			loggrpLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

			JLabel notifyLabel = new JLabel("Notification");
			notifyLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

			JLabel forwardLabel  = new JLabel("Forward");
			forwardLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

			JLabel autoLabel = new JLabel("Auto action");
			autoLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

			JLabel opActionLabel  = new JLabel("Operator Action");
			opActionLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

			JLabel tticketLabel = new JLabel("Trouble Ticket");
			tticketLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

			JTextArea logTypeText = new JTextArea(logtype);
			logTypeText.setEditable(false);
			logTypeText.setAlignmentX(Component.LEFT_ALIGNMENT);
			logTypeText.setPreferredSize(new Dimension(205, 20));

			StringBuffer loggrpTxt = new StringBuffer();
			if(loggrp != null)
				for(int index = 0;index < loggrp.size();index++)
					if(loggrpTxt.toString().equals(""))
						loggrpTxt.append((String)loggrp.elementAt(index));
					else
						loggrpTxt.append(", " + (String)loggrp.elementAt(index));

			JTextArea loggrpText = new JTextArea(loggrpTxt.toString());
			loggrpText.setEditable(false);
			loggrpText.setAlignmentX(Component.LEFT_ALIGNMENT);
			loggrpText.setPreferredSize(new Dimension(205, 20));

			StringBuffer notifyTxt = new StringBuffer();
			if(notification != null)
				for(int index = 0;index < notification.size();index++)
					if(notifyTxt.toString().equals(""))
						notifyTxt.append((String)notification.elementAt(index));
					else
						notifyTxt.append(", " + (String)notification.elementAt(index));

			JTextArea notificationText = new JTextArea(notifyTxt.toString());
			notificationText.setEditable(false);
			notificationText.setAlignmentX(Component.LEFT_ALIGNMENT);
			notificationText.setPreferredSize(new Dimension(205, 20));

			StringBuffer forwardTxt = new StringBuffer();
			if(forward != null)
				for(int index = 0;index < forward.size();index++)
				{
					StringTokenizer strForward = new StringTokenizer((String)forward.elementAt(index), "/\\");
					String forwd = "";
					while (strForward.hasMoreTokens()) {
						String value = strForward.nextToken();
						String state = strForward.nextToken();
						String mechanism= strForward.nextToken();
						forwd = mechanism+":"+value;
					}
				
					if(forwardTxt.toString().equals(""))
						forwardTxt.append(forwd);
					else
						forwardTxt.append(", " + forwd);
				}

			JTextArea forwardText = new JTextArea(forwardTxt.toString());
			forwardText.setEditable(false);
			forwardText.setAlignmentX(Component.LEFT_ALIGNMENT);
			forwardText.setPreferredSize(new Dimension(205, 20));

			StringBuffer autoactionTxt = new StringBuffer();
			if(autoaction != null)
				for(int index = 0;index < autoaction.size();index++)
					if(autoactionTxt.toString().equals(""))
						autoactionTxt.append((String)autoaction.elementAt(index));
					else
						autoactionTxt.append(", " + (String)autoaction.elementAt(index));

			JTextArea autoactionText = new JTextArea(autoactionTxt.toString());
			autoactionText.setEditable(false);
			autoactionText.setAlignmentX(Component.LEFT_ALIGNMENT);
			autoactionText.setPreferredSize(new Dimension(205, 20));

			StringBuffer oper = new StringBuffer();
			for(int i = 0 ;i < operaction.size();i++)
			{
				String str = (String)operaction.elementAt(i);
				if(str.indexOf("/") > 0)
				{
					if(oper.toString().equals(""))
						oper.append(str.substring(0, str.indexOf("/")));
					else
						oper.append(", "+ str.substring(0, str.indexOf("/")));
						//oper.append(", "+ str.substring(str.indexOf("\\"), str.length()));
				}	
			}
			JTextArea operactionText = new JTextArea(oper.toString());
			operactionText.setEditable(false);
			operactionText.setAlignmentX(Component.LEFT_ALIGNMENT);
			operactionText.setPreferredSize(new Dimension(205, 20));

			if(tticket != null)
				if(tticket.indexOf("/") > 0)
					tticket = tticket.substring(0, tticket.indexOf("/"));
			
			JTextArea tticketText = new JTextArea(tticket);
			tticketText.setEditable(false);
			tticketText.setAlignmentX(Component.LEFT_ALIGNMENT);
			tticketText.setPreferredSize(new Dimension(205, 20));

			/************************************************************/
			// OK
			JPanel okPanel = new JPanel();
			okPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
	
			Dimension dim;

			JButton okButton = new JButton("OK");

			dim = okButton.getPreferredSize();
			okButton.setPreferredSize(new Dimension(80, dim.height));
			okButton.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e)
				{
					dispose();
				}
			});
	
			okPanel.add(okButton);
			okPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));

			JPanel cont = new JPanel();
			cont.setLayout(new BoxLayout(cont, BoxLayout.Y_AXIS));
			cont.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
			
			// scroll pane
			cont.add(tabLabel);
			cont.add(tabScr);

			cont.add(Box.createVerticalStrut(10));
			
			// description
			cont.add(desLabel);
			cont.add(desScr);

			cont.add(Box.createVerticalStrut(10));

			// instructions
			cont.add(opLabel);
			cont.add(opScr);
			
			cont.add(Box.createVerticalStrut(10));

			cont.add(logTypeLabel);
			cont.add(logTypeText);

			cont.add(loggrpLabel);
			cont.add(loggrpText);

			cont.add(notifyLabel);
			cont.add(notificationText);

			cont.add(forwardLabel);
			cont.add(forwardText);

			cont.add(autoLabel);
			cont.add(autoactionText);

			cont.add(opActionLabel);
			cont.add(operactionText);

			cont.add(tticketLabel);
			cont.add(tticketText);

			// ok
			cont.add(okPanel);
			
			Container contentPane = getContentPane();
			contentPane.setLayout(new BorderLayout());
			contentPane.add(cont);

			getRootPane().setDefaultButton(okButton);

			pack();
			setLocationRelativeTo(new JFrame());
			setVisible(true);
		}
	}
}

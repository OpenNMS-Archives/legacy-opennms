//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.operator.components;

import javax.swing.*;

import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;

import java.io.IOException;
import java.util.*;

import org.opennms.bb.eui.operator.panels.OperatorInterfacePanel;
import org.opennms.bb.eui.operator.utils.EUIDataParser;
import org.opennms.bb.eui.common.components.BBPopupLabel;

/**
 * <pre>OperatorChartPanel is the chart that creates the labels
 * and the bars for each level
 *
 * The chart creates the bars in the appropriate color based on the
 * normal and warning levels. 
 *
 * The bars ask the chart for the size they ought to paint themselves to. 
 * The chart returns appropriate sizes based on the zoom level
 * (perspective/zoom)
 *
 * @author Sowmya
 */
public class OperatorChartPanel extends JPanel implements Scrollable
{
	// parent
	OperatorInterfacePanel		operatorParent;

	// scroll unit
    private int maxUnitIncrement= 20;

	// normal and warning levels
	double	normal     			= 66;
	double	warning	  			= 33;

	// smallest and largest bar lengths
	double	lowestLen 			= 0.0;
	double	highestLen			= 0.0;

	// first bar
	OperatorBar		firstBar;

	// chart info
	String			ID;
	String			LEVEL;

	// zoom flag
	boolean	bZoomIn = false;
	
	// colors
	Color greenColor = new Color(0, 128, 0);
	Color  yellowColor= Color.yellow;
	Color redColor   = new Color(128, 0, 0);

	//Color  greenColor = Color.green;
	//Color  yellowColor= Color.yellow;
	//Color  redColor   = Color.red;

	final String ID_SEPARATOR="!#";		// just for convenience

	OperatorChartPanel(OperatorInterfacePanel parentPanel, 
						  String id, 
						  String levelName,
						  String dataFileName)

						  throws IOException
	{
		EUIDataParser	parser;
		try
		{
			parser=new EUIDataParser();
			parser.parse(dataFileName);
		}
		catch(IOException e)
		{
	 		JOptionPane.showMessageDialog(new JFrame(), 
					e.getMessage(), 
					"Data unavailable at the moment", 
					JOptionPane.ERROR_MESSAGE);

			throw(e);
		}
		catch(Exception e)
		{
	 		JOptionPane.showMessageDialog(new JFrame(), 
					e.getMessage(), 
					"Unknown Exception", 
					JOptionPane.ERROR_MESSAGE);

			return;
		}


		Vector levelsVector = parser.getLevelsVector();
		int iSize = levelsVector.size();

		Hashtable  levelData = null;

		for(int iIndex=0; iIndex<iSize; iIndex++)
		{
			Hashtable level = (Hashtable)levelsVector.elementAt(iIndex);

			String name = (String)level.get(parser.NAME);
			if (name.equalsIgnoreCase(levelName))
			{
				levelData = level;
			}
		}

		if (null == levelData)
		{
			String msg = "Data file has no data!";

	 		JOptionPane.showMessageDialog(new JFrame(), 
					msg,
					"Data unavailable at the moment", 
					JOptionPane.ERROR_MESSAGE);

			throw(new IOException(msg));
		}


		operatorParent	= parentPanel;

		ID			= id;
		LEVEL		= levelName;

		setOpaque(false);

		Object obj = levelData.get(parser.NORMAL);
		if (obj != null)
			normal=(new Double(String.valueOf(obj))).doubleValue();

		obj = levelData.get(parser.WARNING);
		if (obj != null)
			warning=(new Double(String.valueOf(obj))).doubleValue();

		// create the bars 
		Vector data = (Vector)levelData.get(parser.ENTITIES);

		int iNumCat = data.size();

		GridBagLayout gridbag = new GridBagLayout();
		setLayout(gridbag);

		GridBagConstraints gbc = new GridBagConstraints();
		gbc.fill		= GridBagConstraints.HORIZONTAL;
		gbc.anchor		= GridBagConstraints.WEST;
		
		// separator
		gbc.weightx 	= 0.0;
		gbc.gridx		= 0;
		gbc.gridwidth	= GridBagConstraints.REMAINDER;

		add(Box.createVerticalStrut(5), gbc);

		for (int iBarInd=0; iBarInd < iNumCat; iBarInd++)
		{
			Hashtable temp = (Hashtable)data.elementAt(iBarInd);

			String barText = String.valueOf(temp.get(parser.LABEL));
			Double barLenD = new Double(String.valueOf(temp.get(parser.VALUE)));
			double barLen  = barLenD.doubleValue();

			Color  barColor= getColor(barLenD.doubleValue());

			// id
			String barID = ID + ID_SEPARATOR + barText;

			// label
			BBPopupLabel labelComp= new BBPopupLabel(barText);

			// size
			Dimension lDim = new Dimension(25, 20);
			labelComp.setPreferredSize(lDim);

			gbc.weightx 	= 0.1;
			gbc.gridwidth	= 1;
			gbc.gridx		= 0;

			add(labelComp, gbc);

			// bar
			OperatorBar bar = new OperatorBar(operatorParent,
												 LEVEL,
												 barID,
												 barText,
												 OperatorBar.HORIZONTAL, 
												 barLen,
												 barColor);

			gbc.gridwidth	= GridBagConstraints.REMAINDER;
			gbc.weightx 	= 1.0;
			gbc.gridx		= 1;

			add(bar, gbc);

			// store the first bar
			if (iBarInd == 0)
			{
				firstBar = bar;
			}

			// tooltip
			String tip=null;
			Object barSysName = temp.get(parser.ENAME);
			if (null == barSysName)
				tip = barText;
			else
			{
				Object barSysDescr = temp.get(parser.EDESCR);
				if (null != barSysDescr)
				{
					tip = createHtml(barSysName, barSysDescr);
				}
				else
					tip = String.valueOf(barSysName);
			}
			bar.setToolTipText(tip);

			// store lowest and highest
			if (lowestLen == 0.0)
			{
				lowestLen = barLen;
				highestLen= barLen;
			}
			else
			{
				if (barLen < lowestLen)
					lowestLen = barLen;

				if (barLen > highestLen)
					highestLen = barLen;
			}


			// separator
			gbc.weightx 	= 0.0;
			gbc.gridx		= 0;
			gbc.gridwidth	= GridBagConstraints.REMAINDER;

			add(Box.createVerticalStrut(5), gbc);
		}

		// separator
		gbc.weightx 	= 0.0;
		gbc.gridx		= 0;
		gbc.gridwidth	= GridBagConstraints.REMAINDER;

		add(Box.createVerticalStrut(5), gbc);

	}

	/**
	 * Name sort the bars
	 */
	public void nameSort()
	{
		Component[]  actComponents= getComponents();
		int iSize = actComponents.length;

		OperatorBar[] components= new OperatorBar[iSize];

		int iIndex1=0;
		int iIndex2=0;
		for (iIndex1=0; iIndex1 < iSize; iIndex1++)
		{
			 if (actComponents[iIndex1] instanceof OperatorBar)
			 	components[iIndex2++] = (OperatorBar)actComponents[iIndex1];
		}

		iSize = iIndex2;

		// sort 
		try
		{
			Arrays.sort(components, 0, iSize, new BarNameComparator());
		}
		catch (Exception ex)
		{
			return; // don't continue
		}

		relayComponents(components, iSize);
	}

	/**
	 * Name comparator for the bars
	 */
	protected class BarNameComparator implements Comparator
	{
		public int compare(Object aObj, Object bObj) throws ClassCastException
		{
			OperatorBar a = (OperatorBar)aObj;
			OperatorBar b = (OperatorBar)bObj;

			String aLabel = a.getLabel();
			String bLabel = b.getLabel();
			
			return aLabel.compareTo(bLabel);

		}

		public boolean equals(Object obj)
		{
			return super.equals(obj);
		}

	}

	/**
	 * Sort by severity
	 */
	public void severitySort()
	{
		Component[]  actComponents= getComponents();
		int iSize = actComponents.length;

		OperatorBar[] components= new OperatorBar[iSize];

		int iIndex1=0;
		int iIndex2=0;
		for (iIndex1=0; iIndex1 < iSize; iIndex1++)
		{
			 if (actComponents[iIndex1] instanceof OperatorBar)
			 	components[iIndex2++] = (OperatorBar)actComponents[iIndex1];
		}

		iSize = iIndex2;

		// sort 
		try
		{
			Arrays.sort(components, 0, iSize, new BarSeverityComparator());
		}
		catch (Exception ex)
		{
			return; // don't continue
		}

		relayComponents(components, iSize);
	}
	
	/**
	 * Bar severity comparator
	 */
	protected class BarSeverityComparator implements Comparator
	{
		public int compare(Object aObj, Object bObj) throws ClassCastException
		{
			OperatorBar a = (OperatorBar)aObj;
			OperatorBar b = (OperatorBar)bObj;

			double aLen = a.getLength();
			double bLen = b.getLength();
			
			if (aLen < bLen)
				return -2;
			else if (aLen == bLen)
				return 0;
			else
				return 2;
		}

		public boolean equals(Object obj)
		{
			return super.equals(obj);
		}

	}

	/**
	 * Relay the bars and their labels after sort
	 */
	protected void relayComponents(OperatorBar[] components, int iSize)
	{
		setVisible(false);
		removeAll();

		GridBagLayout gridbag = new GridBagLayout();
		setLayout(gridbag);

		GridBagConstraints gbc = new GridBagConstraints();
		gbc.fill		= GridBagConstraints.HORIZONTAL;
		gbc.anchor		= GridBagConstraints.WEST;
	
		// separator
		gbc.weightx 	= 0.0;
		gbc.gridx		= 0;
		gbc.gridwidth	= GridBagConstraints.REMAINDER;

		add(Box.createVerticalStrut(5), gbc);

		for (int iIndex=0; iIndex < iSize; iIndex++)
		{
			// label
			BBPopupLabel labelComp= new BBPopupLabel(components[iIndex].getLabel());
			// size
			Dimension lDim = new Dimension(25, 20);
			labelComp.setPreferredSize(lDim);

			gbc.weightx 	= 0.1;
			gbc.gridwidth	= 1;
			gbc.gridx		= 0;

			add(labelComp, gbc);

			// bar
			gbc.gridwidth	= GridBagConstraints.REMAINDER;
			gbc.weightx 	= 1.0;
			gbc.gridx		= 1;

			add(components[iIndex], gbc);

			// store the first bar
			if (iIndex == 0)
			{
				firstBar = components[iIndex];
			}

			// separator
			gbc.weightx 	= 0.0;
			gbc.gridx		= 0;
			gbc.gridwidth	= GridBagConstraints.REMAINDER;

			add(Box.createVerticalStrut(5), gbc);

		}

		// separator
		gbc.weightx 	= 0.0;
		gbc.gridx		= 0;
		gbc.gridwidth	= GridBagConstraints.REMAINDER;

		add(Box.createVerticalStrut(5), gbc);

		setVisible(true);
	}

	/**
	 * zoom in
	 */
	protected void zoomIn()
	{
		bZoomIn = true;
		repaint();
	}

	/**
	 * zoom out
	 */
	protected void zoomOut()
	{
		bZoomIn = false;
		repaint();
	}

	/**
	 * Return if zoom is on
	 */
	public boolean isZoomOn()
	{
		return bZoomIn;
	}

	/**
	 * Get bar labels
	 */
	public Vector getLabels()
	{
		Component[]  actComponents= getComponents();
		int iSize = actComponents.length;
		
		Vector labelIds = new Vector();

		int iIndex1=0;
		for (iIndex1=0; iIndex1 < iSize; iIndex1++)
		{
			if (actComponents[iIndex1] instanceof OperatorBar)
			{
			 	String id = ((OperatorBar)actComponents[iIndex1]).getLabel();
				labelIds.add(id);
			}
		}

		return labelIds;
		
	}

	/**
	 * Create an HTML string for the tooltip
	 */
	String createHtml(Object barSysName, Object barSysDescr)
	{
		StringBuffer tipBuf = new StringBuffer();
		tipBuf.append("<html> <pre>");
		tipBuf.append(barSysName + "\n" + barSysDescr);
		
		return tipBuf.toString();
	}

	/**
	 * 
	 */
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);

		/*
		 * NOTE: paintChildren() paints the components in reverse order
		 * i.e. last component first ..
		 * In the case of the OperatorPanel however we require that 
		 * the ruler get painted after the chart, so in the chart's
		 * paintComponent, force a repaint of the ruler 
		 */
		if (!LEVEL.equals(operatorParent.EVENTS_LEVEL))
		{
			Component parent = getParent();
			while(!(parent instanceof OperatorPanel))
				parent = parent.getParent();
		
			if (parent instanceof OperatorPanel)
			{
				((OperatorPanel)parent).getRuler().repaint();
			}
		}
	}

	/**
	 * Convert the bar length to the length it should draw itself to
	 * based on the zoom level
	 */
	public double translateLength(double barLen)
	{
		double iWidth  = getSize().getWidth()*4/5;

		double effectiveLen = 0.0;

		if (!bZoomIn) // normal
		{
			effectiveLen = barLen*iWidth/100;
		}
		else // zoom in
		{
			// lowest  scale
			double lowestScale = (highestLen-lowestLen);
			double curScale = (highestLen-barLen);

			effectiveLen = 
					(lowestScale-curScale)*iWidth/lowestScale;

			if (barLen == lowestLen)
			{
				effectiveLen = 0.1 * iWidth;
			}
		}

		return effectiveLen;
	}

	/**
	 * Decide on the bar color depending on the normal and warning levels
	 */
	public Color getColor(double length)
	{
		if (length <= warning)
			return	redColor;

		else if (length <= normal)
			return yellowColor;

		else
			return greenColor;
	}

	/**
	 * Return id
	 */
	public String getID()
	{
		return ID;
	}
	
	/**
	 * Return level
	 */
	public String getLevel()
	{
		return LEVEL;
	}

	/**
	 * Return length of the longest bar
	 */
	public double getHighestLen()
	{
		return highestLen;
	}

	/**
	 * Return length of the shortest bar
	 */
	public double getLowestLen()
	{
		return lowestLen;
	}

	/**
	 * Return width for the ruler to draw itself
	 */
	public double getChartWidth()
	{
		if (bZoomIn)
			return translateLength(highestLen);
		else
			return translateLength(100.0);
	}

	/**
	 * Return starting point for the ruler to draw itself from
	 */
	public int getChartX(Component comp)
	{
		Point pt = SwingUtilities.convertPoint(
							this, firstBar.getLocation(), comp);

		return pt.x;
	}

	/*
	 *  the Scrollable interface
	 */

    public Dimension getPreferredScrollableViewportSize() 
	{
        return getPreferredSize();
    }

    public int getScrollableUnitIncrement(Rectangle visibleRect,
                                          int orientation,
                                          int direction) 
	{
        //Get the current position.
        int currentPosition = 0;
        if (orientation == SwingConstants.HORIZONTAL)
            currentPosition = visibleRect.x;
        else
            currentPosition = visibleRect.y;

        if (direction < 0) 
		{
            int newPosition = currentPosition - 
                             (currentPosition / maxUnitIncrement) *
                              maxUnitIncrement;
            return (newPosition == 0) ? maxUnitIncrement : newPosition;
        } 
		else 
		{
            return ((currentPosition / maxUnitIncrement) + 1) *
                   maxUnitIncrement - currentPosition;
        }
    }

    public int getScrollableBlockIncrement(Rectangle visibleRect,
                                           int orientation,
                                           int direction) 
	{
        if (orientation == SwingConstants.HORIZONTAL)
            return visibleRect.width - maxUnitIncrement;
        else
            return visibleRect.height - maxUnitIncrement;
    }

    public boolean getScrollableTracksViewportWidth() 
	{
        return true;
    }

    public boolean getScrollableTracksViewportHeight() 
	{
        return false;
    }

}

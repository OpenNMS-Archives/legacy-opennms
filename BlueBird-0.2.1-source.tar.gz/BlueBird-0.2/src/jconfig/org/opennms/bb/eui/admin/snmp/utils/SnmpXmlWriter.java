//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.admin.snmp.utils;

import java.io.*;
import java.util.Vector;
import java.util.Calendar;

/**
 * <pre>SnmpXmlWriter creates a 'Snmp' xml file using the data in the
 * vectors passed in
 *
 * It throws an IOException if the xml file is not accesible or if there
 * are any errors while writing into the file <pre>
 *
 * @author Sowmya
 *
 */
public class SnmpXmlWriter 
{
	Vector	defaultData;

	Vector	rangesCols;
	Vector	rangesData;

	Vector	specificsCols;
	Vector	specificsData;

	Vector  urlsCols;
	Vector	urlsData;

	final String DEF_PARMS			="\t\t<parms>\n";
	final String DEF_PARMS_CLS		="\t\t</parms>\n";

	final String DEF_PARM 			="\t\t\t<parm>\n";
	final String DEF_PARM_CLS		="\t\t\t</parm>\n";

	final String DEF_PARM_NAME		="\t\t\t\t<parmName>";
	final String DEF_PARM_NAME_CLS	="</parmName>\n";

	final String DEF_PARM_VALUE		="\t\t\t\t<value>";
	final String DEF_PARM_VALUE_CLS	="</value>\n";

	final String DEFAULT		="\t<default>\n";
	final String DEFAULT_CLS	="\t</default>\n";

	final String PARMS			="\t\t\t<parms>\n";
	final String PARMS_CLS		="\t\t\t</parms>\n";

	final String PARM 			="\t\t\t\t<parm>\n";
	final String PARM_CLS		="\t\t\t\t</parm>\n";

	final String PARM_NAME		="\t\t\t\t\t<parmName>";
	final String PARM_NAME_CLS	="</parmName>\n";

	final String PARM_VALUE		="\t\t\t\t\t<value>";
	final String PARM_VALUE_CLS	="</value>\n";

	final String RANGES			="\t<ranges>\n";
	final String RANGES_CLS		="\t</ranges>\n";

	final String RANGE			="\t\t<range>\n";
	final String RANGE_CLS		="\t\t</range>\n";

	final String FROM			="\t\t\t<from>";
	final String FROM_CLS		="</from>\n";

	final String TO				="\t\t\t<to>";
	final String TO_CLS			="</to>\n";

	final String SPECIFICS		="\t<specifics>\n";
	final String SPECIFICS_CLS	="\t</specifics>\n";

	final String SPECIFIC		="\t\t<specific>\n";
	final String SPECIFIC_CLS	="\t\t</specific>\n";

	final String SPECIP			="\t\t\t<specIP>";
	final String SPECIP_CLS		="</specIP>\n";

	final String URLS			="\t<urls>\n";
	final String URLS_CLS		="\t</urls>\n";

	final String URL			="\t\t<url>\n";
	final String URL_CLS		="\t\t</url>\n";

	final String URLNAME		="\t\t\t<urlName>";
	final String URLNAME_CLS	="</urlName>\n";

	int 	iNumParms=0;

	/**
 	 * Writes into the standard file 'SnmpXML.xml'
 	 */
	public SnmpXmlWriter(Vector inpDefaultData, 
							Vector inpRangesCols, Vector inpRangesData, 
							Vector inpSpecificsCols, Vector inpSpecificsData, 
							Vector inpUrlsCols, Vector inpUrlsData)
							
							throws IOException
	{
		defaultData    = inpDefaultData;

		rangesCols     = inpRangesCols;
		rangesData     = inpRangesData;

		specificsCols  = inpSpecificsCols;
		specificsData  = inpSpecificsData;

		urlsCols       = inpUrlsCols;
		urlsData       = inpUrlsData;

		writeInto("data/common/conf/SnmpXML.xml");
	}

	/**
 	 * Writes into the filename passed in
 	 */
	public SnmpXmlWriter(String filename, Vector inpDefaultData, 
							Vector inpRangesCols, Vector inpRangesData, 
							Vector inpSpecificsCols, Vector inpSpecificsData, 
							Vector inpUrlsCols, Vector inpUrlsData)
							
							throws IOException
	{
		defaultData    = inpDefaultData;

		rangesCols     = inpRangesCols;
		rangesData     = inpRangesData;

		specificsCols  = inpSpecificsCols;
		specificsData  = inpSpecificsData;

		urlsCols       = inpUrlsCols;
		urlsData       = inpUrlsData;


		writeInto(filename);
	}

	private void writeInto(String fileName) throws IOException
	{
		FileReader fileReader;
		FileWriter fileWriter;

		boolean bReadDTD=true;
		StringBuffer DTDBuffer=new StringBuffer();

		try
		{
			fileReader = new FileReader(fileName);
			readDTD(fileReader, DTDBuffer);

		} catch (IOException e)
		{
			e.printStackTrace();

			bReadDTD = false;
		}

		fileWriter = new FileWriter(fileName);
			
		// write the DTD first
		if (!bReadDTD)
			writeDTD(fileWriter);
		else
			writeDTD(fileWriter, DTDBuffer);

		fileWriter.write("<snmp>\n");

		// now the header..
		writeHeader(fileWriter);

		// default
		writeDefault(fileWriter); 

		// ranges
		writeRanges(fileWriter);

		// specifics
		writeSpecifics(fileWriter);

		// urls
		writeUrls(fileWriter);

		fileWriter.write("</snmp>\n");

		fileWriter.flush();

	}

	void readDTD(FileReader fileReader, StringBuffer DTDBuffer) 
													throws IOException
	{
		int curInt = fileReader.read();
		char curChar = (char)curInt;
		char prevChar = curChar;

		while ( curInt != -1)
		{
			if (curChar == '>' && prevChar == ']')
			{
				DTDBuffer.append(curChar);
				DTDBuffer.append('\n');
				DTDBuffer.append('\n');
				break;
			}

			if (curChar != '\r')
				DTDBuffer.append(curChar);

			prevChar = curChar;
			curInt = fileReader.read();
			curChar = (char)curInt;
		}
	}

	void writeDTD(FileWriter fileWriter, StringBuffer DTDBuffer) 
													throws IOException
	{
		fileWriter.write(DTDBuffer.toString());
	}

	void writeHeader(FileWriter fileWriter) throws IOException
	{
		// get current date
		Calendar curCal = new java.util.GregorianCalendar();

		// milliseconds since Jan 1st 1970
		long ms = curCal.getTime().getTime();

		int year = curCal.get(Calendar.YEAR);
		int month = curCal.get(Calendar.MONTH) + 1;
		int day = curCal.get(Calendar.DAY_OF_MONTH);
		int hour = curCal.get(Calendar.HOUR_OF_DAY);
		int min = curCal.get(Calendar.MINUTE);
		int sec = curCal.get(Calendar.SECOND);

		StringBuffer createdDate = new StringBuffer("<created year=\""+ year +"\"");
		createdDate.append(" month=\"" +month+"\"");
		createdDate.append(" day=\"" + day + "\"");
		createdDate.append(" hour=\"" + hour +"\"");
		createdDate.append(" min=\"" + min + "\"");
		createdDate.append(" sec=\"" + sec + "\">");

		fileWriter.write("\t<header>\n");
		fileWriter.write("\t\t<ver>.9</ver>\n");

		fileWriter.write("\t\t" + createdDate + "\n");
		fileWriter.write("\t\t\t" + ms + "\n");
		fileWriter.write("\t\t</created>\n");
		fileWriter.write("\t\t<mstation>master.nmanage.com</mstation>\n");
		fileWriter.write("\t</header>\n");
	}


	void writeDefault(FileWriter fileWriter) throws IOException
	{
		fileWriter.write(DEFAULT);
		fileWriter.write(DEF_PARMS);

		int iRowCount = defaultData.size();

		for (int iIndex=0; iIndex < iRowCount; iIndex++)
		{
			Vector temp = (Vector)defaultData.elementAt(iIndex);

			String parmName = (String)temp.elementAt(0);
			String parmValue = (String)temp.elementAt(1);

			fileWriter.write(DEF_PARM);

			fileWriter.write(DEF_PARM_NAME);
			fileWriter.write(parmName);
			fileWriter.write(DEF_PARM_NAME_CLS);

			fileWriter.write(DEF_PARM_VALUE);
			fileWriter.write(parmValue);
			fileWriter.write(DEF_PARM_VALUE_CLS);

			fileWriter.write(DEF_PARM_CLS);
		}

		fileWriter.write(DEF_PARMS_CLS);
		fileWriter.write(DEFAULT_CLS);
	}

	void writeRanges(FileWriter fileWriter) throws IOException
	{
		fileWriter.write(RANGES);

		int iRowCount = rangesData.size();

		for (int iIndex=0; iIndex< iRowCount; iIndex++)
		{
			Vector temp = (Vector)rangesData.elementAt(iIndex);

			String fromParmValue = (String)temp.elementAt(0);
			String toParmValue = (String)temp.elementAt(1);

			if (fromParmValue.equals("255.255.255.255") && toParmValue.equals("255.255.255.255"))
			{
				// if it the default row added, ignore
				if (checkDefaultParms(rangesData, iIndex, 2))
					continue;
			}

			fileWriter.write(RANGE);

			fileWriter.write(FROM + fromParmValue + FROM_CLS);

			fileWriter.write(TO + toParmValue + TO_CLS);
			
			writeTabParms(fileWriter, rangesCols, rangesData, iIndex, 2);

			fileWriter.write(RANGE_CLS);
		}

		fileWriter.write(RANGES_CLS);
	}

	void writeSpecifics(FileWriter fileWriter) throws IOException
	{
		fileWriter.write(SPECIFICS);

		int iRowCount = specificsData.size();

		for (int iIndex=0; iIndex< iRowCount; iIndex++)
		{
			Vector temp = (Vector)specificsData.elementAt(iIndex);

			String parmValue = (String)temp.elementAt(0);
			if(parmValue.equals("255.255.255.255"))
			{
				if (checkDefaultParms(specificsData, iIndex, 1))
					continue;
			}

			fileWriter.write(SPECIFIC);

			fileWriter.write(SPECIP + parmValue + SPECIP_CLS);

			writeTabParms(fileWriter, specificsCols, specificsData, iIndex, 1);

			fileWriter.write(SPECIFIC_CLS);
		}

		fileWriter.write(SPECIFICS_CLS);
	}

	void writeUrls(FileWriter fileWriter) throws IOException
	{
		fileWriter.write(URLS);

		int iRowCount = urlsData.size();

		for (int iIndex=0; iIndex< iRowCount; iIndex++)
		{
			Vector temp = (Vector)urlsData.elementAt(iIndex);

			String parmValue = (String)temp.elementAt(0);
			if (parmValue.equals("<filename>"))
				continue;

			fileWriter.write(URL);

			fileWriter.write(URLNAME + parmValue + URLNAME_CLS);

			writeTabParms(fileWriter, urlsCols, urlsData, iIndex, 1);

			fileWriter.write(URL_CLS);
		}

		fileWriter.write(URLS_CLS);
	}

	void writeTabParms(FileWriter fileWriter, 
									Vector outCols, Vector outData, 
									int iRow, int iStartCol) 
														throws IOException
	{
		fileWriter.write(PARMS);

		int iRowCount = outData.size();
		int iColCount = outCols.size();

		Vector temp = (Vector)outData.elementAt(iRow);

		for (int iIndex2=iStartCol; iIndex2 < iColCount; iIndex2++)
		{
			String parmName = (String)outCols.elementAt(iIndex2);
			String parmValue = (String)temp.elementAt(iIndex2);

			fileWriter.write(PARM);

			fileWriter.write(PARM_NAME + parmName + PARM_NAME_CLS);

			fileWriter.write(PARM_VALUE);

			if (parmValue.equals("<default>"))
				fileWriter.write("<![CDATA[<default>]]>");
			else
				fileWriter.write(parmValue);

			fileWriter.write(PARM_VALUE_CLS);

			fileWriter.write(PARM_CLS);
		}

		fileWriter.write(PARMS_CLS);
	}

	boolean checkDefaultParms(Vector outData, int iRow, int iStartCol) 
	{
		int iRowCount = outData.size();
		Vector temp = (Vector)outData.elementAt(iRow);

		int iColCount = temp.size();

		for (int iIndex2=iStartCol; iIndex2 < iColCount; iIndex2++)
		{
			String parmValue = (String)temp.elementAt(iIndex2);

			if (!parmValue.equals("<default>"))
				return false;
		}

		return true;
	}

	void writeDTD(FileWriter fileWriter) throws IOException
	{
		fileWriter.write("<?xml version=\"1.0\"?>\n\n");
		fileWriter.write("<?XML-stylesheet type=\"text/xsl\" href=\"snmp.xsl\"?>\n");
		fileWriter.write("<!DOCTYPE snmp [\n");
		fileWriter.write("<!ELEMENT	snmp		(header, default, ranges, specifics, urls)		>\n");
		fileWriter.write("<!ELEMENT	header		(ver, created, mstation)	>\n");
		fileWriter.write("<!ELEMENT	ver		(#PCDATA)				>\n");
		fileWriter.write("<!ELEMENT	mstation	(#PCDATA)				>\n");
		fileWriter.write("<!ELEMENT	created 	(#PCDATA)				>\n");
		fileWriter.write("<!ATTLIST	created year	CDATA	#REQUIRED\n");
		fileWriter.write("			month	CDATA	#REQUIRED\n");
		fileWriter.write("			day	CDATA	#REQUIRED\n");
		fileWriter.write("			hour	CDATA	#REQUIRED\n");
		fileWriter.write("			min	CDATA	#REQUIRED\n");
		fileWriter.write("			sec	CDATA	#REQUIRED			>\n");
		fileWriter.write("<!ELEMENT	default		(parms+)				>\n");
		fileWriter.write("<!ELEMENT	ranges		(range*)				>\n");
		fileWriter.write("<!ELEMENT	range		(from,to,parms*)			>\n");
		fileWriter.write("<!ELEMENT	from		(#PCDATA)				>\n");
		fileWriter.write("<!ELEMENT	to		(#PCDATA)				>\n");
		fileWriter.write("<!ELEMENT	specifics	(specific*)				>\n");
		fileWriter.write("<!ELEMENT	specific	(specIP,parms+)				>\n");
		fileWriter.write("<!ELEMENT	specIP		(#PCDATA)				>\n");
		fileWriter.write("<!ELEMENT	urls		(url*)					>\n");
		fileWriter.write("<!ELEMENT	url		(urlName,parms*)			>\n");
		fileWriter.write("<!ELEMENT	parms		(parm+)					>\n");
		fileWriter.write("<!ELEMENT	parm		(parmName,value)			>\n");
		fileWriter.write("<!ELEMENT	parmName	(#PCDATA)				>\n");
		fileWriter.write("<!ELEMENT	value		(#PCDATA)				>\n");
		fileWriter.write("<!ATTLIST	value		type	(int|string) \"string\">\n");
		fileWriter.write("<!ELEMENT	urlName		(#PCDATA)				>\n");
		fileWriter.write("\n]>\n\n");

	}

}

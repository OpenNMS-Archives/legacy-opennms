//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.admin.snmp.panels;

import javax.swing.JOptionPane;
import java.util.Vector;

/**
 * IPRangesManipPanel is the panel for the 'Ranges' tab
 *
 * @author Sowmya 
 *
 */

class IPRangesManipPanel extends SnmpTableManipulationPanel 
{
	protected IPRangesManipPanel(Vector colNames)
	{
		super(colNames);
	}

	protected IPRangesManipPanel(Vector data, Vector colNames)
	{
		super(data, colNames);
	}

	/**
	 * Adds a new row with data '255\.255\.255\.255' '255\.255\.255\.255' '<default>' '<default>'  ...
	 */
	protected void addEntryToTable()
	{
		int iColCount = getColumnCount();
		Vector data = new Vector(iColCount);
		
		data.add("255.255.255.255"); // from
		data.add("255.255.255.255"); // to
		for(int iIndex = 3; iIndex < iColCount; iIndex++)
			data.add("<default>");

		addRow(data);
	}

	protected boolean validateValues()
	{
		if (checkForDuplicateEntries())
			return false;

		return super.validateValues("IP Ranges panel");
	}

	/**
	 * Checks if rows contain duplicate values
	 *
	 * @return true if more than one row has the same 'from' and 'to' IP Addresses
	 */
	protected boolean checkForDuplicateEntries()
	{
		Vector rangesData = getTableData();
		int    iNumRangesEntries = getRowCount();

		for(int iIndex1=0; iIndex1<(iNumRangesEntries-1); iIndex1++)
		{
			Vector vector1=(Vector)rangesData.elementAt(iIndex1);

			for(int iIndex2=iIndex1+1; iIndex2<iNumRangesEntries; iIndex2++)
			{
				Vector vector2=(Vector)rangesData.elementAt(iIndex2);

				// compare from address
				String from1 = (String)vector1.elementAt(0);
				String from2 = (String)vector2.elementAt(0);

				if(from1.equals(from2))
				{
					//compare to address
					String to1 = (String)vector1.elementAt(1);
					String to2 = (String)vector2.elementAt(1);
	
					if(to1.equals(to2))
					{
						String values = from1 + " - ";
						values = values + to1;

		 				JOptionPane.showMessageDialog(null, 
								"Duplicate entry found for " + values, 
								"Duplicate Entries in IP Ranges!", 
								JOptionPane.WARNING_MESSAGE);

						// found duplicate!
						return true;
					}
				}
			}
		}

		return false;

	}


}

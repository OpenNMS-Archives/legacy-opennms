//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.admin.snmp.panels;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;

import java.util.*;

import org.opennms.bb.eui.common.panels.FileTableManipulationPanel;
import org.opennms.bb.eui.admin.snmp.components.*;

/**
 * SnmpFileTableManipulationPanel creates a SnmpFileManipTable
 *
 * @author Sowmya
 *
 */

class SnmpFileTableManipulationPanel extends FileTableManipulationPanel 
{

	protected SnmpFileTableManipulationPanel(Vector colNames)
	{
		super(colNames);
	}

	protected SnmpFileTableManipulationPanel(Vector rowData, Vector colNames)
	{
		super(rowData, colNames);
	}


	/**
	 * Creates a SnmpFileManipTable with the data 'rowData' and 
	 * column names 'colNames'
	 */
	protected void createTable(Vector rowData, Vector colNames)
	{
		//Create the table
		infoTable = new  SnmpFileManipTable(rowData, colNames);

		infoTableModel = ((SnmpFileManipTable)infoTable).getTableModel();

		setViewportView(infoTable);
	}

	/**
	 * Creates an empty SnmpFileManipTable with column names 'colNames'
	 */
	protected void createTable(Vector colNames)
	{
		//Create the table
		infoTable = new  SnmpFileManipTable(colNames);

		infoTableModel = ((SnmpFileManipTable)infoTable).getTableModel();

		setViewportView(infoTable);
	}
	
}

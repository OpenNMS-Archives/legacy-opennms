//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;

import org.opennms.bb.common.components.Log;
import org.opennms.bb.eui.admin.panels.AdministratorMain;
import org.opennms.bb.eui.operator.panels.OperatorInterface;
import org.opennms.bb.eui.admin.UserGroupView.Parser.LoginParser;
/**
 * <pre>LoginFrame provides the standard Bluebird login.</pre> 
 *
 * @author Sowmya
 * @author Vishwa
 */
public class LoginFrame extends JFrame
{
	/**
	 * Login window variables.
	 */
	protected JTextField		userText;
	protected JPasswordField	passwdText;

	/**
	 * The parser to parse the user xml file.
	 */
	protected LoginParser 		loginParser = null;

	/**
	 * The table to store the parsed user and password values.
	 */
	protected Hashtable		m_users = null;	

	/**
	 * Counter to allow user to enter valid username and password five times
	 */
	protected short 		m_counter = 0;

	protected boolean 		m_userExists = false;
	protected String 		m_pass = null;
	protected String 		m_user = null;
	protected String 		m_password = null;

	/**
	 * <P>The login frame object to enter into bluebird.<P>
	 */
	public LoginFrame(String title)
	{
		super(title);

		loginParser = new LoginParser();
		m_users = new Hashtable();

		try
		{
			loginParser.parse("data/common/conf/users.xml");
			m_users = loginParser.getUsers();
		}
		catch(IOException ie)
		{
			Log.print(Log.WARNING, "No users xml file found, please check path of the file");
		}
		
		buildFrame(); // build the outline

		addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
				handleCancel();
			}
		});

		pack();
		setResizable(false);
		setLocation(200, 100);
		setVisible(true);
		setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
	}

	/**
	 * <P>Frame builder for this login window.<P>
	 */
	protected void buildFrame()
	{
		// icon
		ImageIcon productIcon = new ImageIcon("data/images/bluebird.gif");
		JLabel productIconLabel = new JLabel(productIcon);

		// user panel
		GridBagLayout gridbag = new GridBagLayout();
		GridBagConstraints gbc = new GridBagConstraints();

		JPanel userPanel = new JPanel();
		userPanel.setLayout(gridbag);

		// user label
		JLabel userLabel=new JLabel("User ID:");

		gbc.gridwidth = GridBagConstraints.RELATIVE;
		gbc.fill	= GridBagConstraints.NONE;
		gbc.anchor	= GridBagConstraints.EAST;
		gbc.insets  = new Insets(10, 10, 10, 5);
		
		gridbag.setConstraints(userLabel, gbc);
		userPanel.add(userLabel);

		// user text
		userText = new JTextField(20);

		gbc.gridwidth = GridBagConstraints.REMAINDER;
		gbc.fill	= GridBagConstraints.HORIZONTAL;
		gbc.anchor	= GridBagConstraints.EAST;
		gbc.insets  = new Insets(10, 5, 10, 10);

		gridbag.setConstraints(userText, gbc);
		userPanel.add(userText);

		// password label
		JLabel passwdLabel=new JLabel("Password:");

		gbc.gridwidth = GridBagConstraints.RELATIVE;
		gbc.fill	= GridBagConstraints.NONE;
		gbc.anchor	= GridBagConstraints.EAST;
		gbc.insets  = new Insets(10, 10, 10, 5);
		
		gridbag.setConstraints(passwdLabel, gbc);
		userPanel.add(passwdLabel);

		// user Text
		passwdText = new JPasswordField(20);

		gbc.gridwidth = GridBagConstraints.REMAINDER;
		gbc.fill	= GridBagConstraints.HORIZONTAL;
		gbc.anchor	= GridBagConstraints.EAST;
		gbc.insets  = new Insets(10, 5, 10, 10);

		gridbag.setConstraints(passwdText, gbc);
		userPanel.add(passwdText);

		JPanel okCancelPanel=new JPanel();
		okCancelPanel.setLayout(new BoxLayout(okCancelPanel, BoxLayout.X_AXIS));
		okCancelPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));

		// ok button
		final JButton okButton = new JButton("OK");
		okButton.setMnemonic('O');

		// cancel button
		final JButton cancelButton = new JButton("Cancel");
		cancelButton.setMnemonic('C');

		// size
		Dimension dim;

		dim = okButton.getPreferredSize();
		okButton.setPreferredSize(new Dimension(80, dim.height));

		dim = cancelButton.getPreferredSize();
		cancelButton.setPreferredSize(new Dimension(80, dim.height));


		okCancelPanel.add(Box.createHorizontalGlue());
		okCancelPanel.add(okButton);
		okCancelPanel.add(Box.createHorizontalGlue());
		okCancelPanel.add(cancelButton);
		okCancelPanel.add(Box.createHorizontalGlue());

		Container cont = getContentPane();

		JPanel panel = new JPanel();
		panel.setLayout(new BorderLayout());
		panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

		panel.add(productIconLabel, BorderLayout.NORTH);
		panel.add(userPanel, BorderLayout.CENTER);
		panel.add(okCancelPanel, BorderLayout.SOUTH);

		cont.add(panel);
		
		/* Action Listeners */
		userText.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				okButton.doClick();
			}
		});

		passwdText.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				okButton.doClick();
			}
		});
		
		okButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				handlePasswordValidation();
			}
		});
		
		cancelButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				handleCancel();
			}
		});
		
	}

	/**
	 * Handles the userid and password validations by checking from 'users.xml'
	 */
	protected void handlePasswordValidation()
	{
		m_pass = String.valueOf(passwdText.getPassword());
		m_user = userText.getText();

		m_password = null;
		m_userExists = false;

		if(!m_userExists)
		{
			m_password = getPassword(m_user);
		}
	}
	
	/**
	 * Close the login window
	 */
	protected void handleCancel()
	{
		System.exit(0);
	}
	
	/**
	 * <P>Get the user and password from UI and validate against the XML.<P>
	 */
	public String getPassword(String user)
	{
		String m_password = null;
		
		m_counter++;

		if(m_counter <= 5)
		{
			if(m_users.containsKey(m_user))
			{
				m_password = m_users.get(m_user).toString();
				m_userExists = true;

				if(m_userExists)
				{
					if (!m_pass.equals(m_password))
					{
						if(m_counter <= 5)
						{
							waitForValidation("Password");
						}
						else 
						{
							System.exit(-1);
						}
					}

					if(m_pass.equals(m_password))
					{
						if (m_user.equals("admin"))
						{
							AdministratorMain adminPanel=new AdministratorMain(user);
		
							dispose();
						}

						else
						{
							OperatorInterface operatorPanel=new OperatorInterface(user);
		
							dispose();
						}
					}
				}
			}
		
			else
			{
				waitForValidation("UserID");
			}
		}

		else
		{
			pack();
			//if user could not succeed for five times, close login window and exit Bluebird.
			System.exit(-1);
		}
		return m_password;
	}

	/**
	 * <P>Wait for user to enter correct userid and password. Allow only five times to enter in.<P>
	 */
	public void waitForValidation(String userPass)
	{
		 JOptionPane.showMessageDialog(new JFrame(), 
			userPass + " Incorrect! Please try again!",
			"BlueBird Login!", 
			JOptionPane.ERROR_MESSAGE);
	}

	/**
	 * Creates the Login  
	 * Sets the UI to be system dependant - this can be changed later
	 * by using the menu options
	 */
	public static void main(String[] args)
	{
		// Set look and feel
		try
		{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		}
		catch (Exception e)
		{
			// Don't really do anything?
		}

		LoginFrame login = new LoginFrame("BlueBird Login");
 	}
}

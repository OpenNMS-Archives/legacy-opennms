//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.operator.components;

import javax.swing.*;
import javax.swing.event.*;

import java.awt.*;
import java.awt.event.*;

import java.util.Calendar;
import java.util.Vector;

import org.opennms.bb.eui.operator.panels.OperatorInterfacePanel;
import org.opennms.bb.eui.operator.utils.EUIDataRequest;
import org.opennms.bb.eui.operator.utils.EUIDataSendRecv;

/**
 * <pre> OperatorBar is the 'bar' component in the real time chart
 * The bar knows/stores info. about the level it belongs to in order
 * - to send the request and create the next level and
 * - to bring up the appropriate right-click popup menu
 *
 * The bar paints itself by asking its parent, the chart panel for
 * the appropriate size it ought to be
 *
 *  @author Sowmya
 */
public class OperatorBar extends JComponent
{
	// bar orientation
	public final static int HORIZONTAL=1;
	public final static int VERTICAL  =2;
	
	// actual parent
	OperatorInterfacePanel	operatorParent;

	// Bar info
	String			LEVEL;
	String			ID;
	String			LABEL;
	int	  			orientation = HORIZONTAL;
		
	double  		length = 0;				// actual length
	double  		translatedLength= 0;	// length to which bar draws itself
											// based on the parent chart size
	Color			backColor;				// background color
		
	
	// levels
	public final static String	VIEWS_LEVEL		="Views Level";
	public final static String	CATEGORY_LEVEL	="Category Level";
	public final static String	DEVICES_LEVEL 	="Node Level";
	public final static String	DAILY_LEVEL 	="Daily Level";
	public final static String	HOURLY_LEVEL 	="Hourly Level";
	public final static String	SERVICES_LEVEL	="Services Level";
	public final static String	EVENTS_LEVEL 	="Events Level";

	// popup
	JPopupMenu		popup;

	final String ID_SEPARATOR="!#";		// just for convenience

	public OperatorBar(OperatorInterfacePanel parentPanel,
					  String level,
					  String id, 
					  String label, 
					  int orient, 
					  double len,
					  Color inpBackColor)
	{
		setOpaque(false);
		setBorder(BorderFactory.createLineBorder(Color.black, 1));

		operatorParent = parentPanel;

		LEVEL		 = level;
		ID			= id;
		LABEL		 = label;
		orientation = orient;
		length 		= len;
		backColor	= inpBackColor;
		
		addMouseListener(new OperatorBarListener());

		setBackground(backColor);
		
	 	popup = new JPopupMenu();
	}

	/**
	 * <pre>Asks the parent chart panel for the appropriate size and paints
	 * itself acordingly
	 *
	 * Paints the size as well - reduces the font size so the label will fit
	 */
	public void paintComponent(Graphics g)				 
	{
		Dimension	size;

		Container cont = getParent();
		if (cont instanceof OperatorChartPanel)
		{
			translatedLength = ((OperatorChartPanel)cont).translateLength(length);
		}

		if (orientation == VERTICAL)
		{
			size = new Dimension(20, (int)translatedLength);
		}
		else
		{ 
			size = new Dimension((int)translatedLength, 20);
		}

		// size
		setPreferredSize(size);
		setSize(size);

		// color
		g.setColor(backColor);
		g.fillRect(0, 0, size.width, size.height);

		// label
		g.setColor(Color.black);
		String labelText = String.valueOf(new Double(length))+"%";

		Font curFont = g.getFont();
		int labelLen = g.getFontMetrics(curFont).stringWidth(labelText);
		while (labelLen > size.width)
		{
			curFont = new Font("Dialog", Font.PLAIN, curFont.getSize()-2);
			labelLen = g.getFontMetrics(curFont).stringWidth(labelText);

		}
		g.setFont(curFont);

		g.drawString(labelText, size.width-labelLen, 14);

		super.paintComponent(g);				 
	} 

	/**
	 * <pre>This is the mouse listener for the bar. For a left double-click
	 * it send out a standard request based on the bar level while
	 * for a right click, it brings up a popup menu from which the user
	 * can choose the level he wants to go to
	 * 
	 */
	protected class OperatorBarListener extends MouseAdapter
	{
		public void mouseClicked(MouseEvent e)
		{
			if (e.getClickCount() == 2  && 
										SwingUtilities.isLeftMouseButton(e))
			{
				handleLeftMouseClick(e);
			}
			else if (e.getClickCount() == 1  && 
										SwingUtilities.isRightMouseButton(e))
			{
				handleRightMouseClick(e);
			}
			else
			{
				e.consume();
				return;
			}
		}

		protected void handleLeftMouseClick(MouseEvent e)
		{
			OperatorBar source = (OperatorBar)e.getSource();

			Component parent = source.getParent();
			if(!(parent instanceof OperatorChartPanel))
			{
				// insufficient info to do anything more
				e.consume();
				return;
			}

			String nextLevel = getNextLevel();

			String dataFileName = sendLeftRequestForData();

			createNextPanel(nextLevel, ID, dataFileName);
		}

		protected void handleRightMouseClick(MouseEvent e)
		{
			// show popup menu
			OperatorBar source = (OperatorBar)e.getSource();

			Component parent = source.getParent();
			if(!(parent instanceof OperatorChartPanel))
			{
				// insufficient info to do anything more
				e.consume();
				return;
			}

		  	// remove earlier pop
		  	popup.removeAll();

			// populate the popup
			source.populatePopup(popup);

			popup.show(source, e.getX(), e.getY());
		}
	}

	/**
	 * next level
	 */
	protected String getNextLevel()
	{
		String nextLevel=null;

		if (LEVEL.equals(CATEGORY_LEVEL))
			nextLevel = DEVICES_LEVEL;

		else if (LEVEL.equals(DEVICES_LEVEL))
			nextLevel = DAILY_LEVEL;

		else if (LEVEL.equals(DAILY_LEVEL))
			nextLevel = HOURLY_LEVEL;

		else if (LEVEL.equals(HOURLY_LEVEL))
			nextLevel = SERVICES_LEVEL;

		else if (LEVEL.equals(SERVICES_LEVEL))
			nextLevel = EVENTS_LEVEL;

		return nextLevel;
	}


	/**
	 * Send standard request based on level
	 */
	String sendLeftRequestForData()
	{
		// the call to get the xml stream will go here
		// will eventually return a xml stream instead of a filename
		String dataFileName = null;
				
		if (LEVEL.equals(CATEGORY_LEVEL))
		{
			dataFileName = sendRequestForData(DEVICES_LEVEL, "All");
		}

		else if (LEVEL.equals(DEVICES_LEVEL))
		{
			dataFileName = sendRequestForData(DAILY_LEVEL, "30d");
		}

		else if (LEVEL.equals(DAILY_LEVEL))
		{
			dataFileName = sendRequestForData(HOURLY_LEVEL, "48h");
		}
		
		else if (LEVEL.equals(HOURLY_LEVEL))
		{
			dataFileName = sendRequestForData(SERVICES_LEVEL, "1h");
		}

		else if (LEVEL.equals(SERVICES_LEVEL))
		{
			dataFileName = sendRequestForData(EVENTS_LEVEL, "All", "All"); // All events
														// all severity levels
		}
		
		return dataFileName;
	}

	/**
	 *
	 */
	String sendRequestForData(String nextReqLevel, String qty)
	{
		return sendRequestForData(nextReqLevel, qty, null);
	}

	/**
	 *  Create request for next level, send request and receive response
	 */
	String sendRequestForData(String nextReqLevel, String qty, String severity)
	{
		if (nextReqLevel == null)
			return null;

		 EUIDataRequest euiDataReq = new EUIDataRequest(
		 		operatorParent.getUser(), nextReqLevel, qty, severity, ID);

		 String dataRequest = euiDataReq.getDataRequestBuffer();

		/****
		 * Eventually will send the created request and recv. data back
		 * from the servlet
		 * For now however, use the other constructor
		 */
		String dataFileName = null;

		EUIDataSendRecv dataSendRecv = 
						new EUIDataSendRecv(nextReqLevel, qty, severity, ID);
		dataFileName = dataSendRecv.getDataStream();
				
		return dataFileName;
	}

	/**
	 * Create the next level panel and set the tabbedpane component
	 */
	protected void createNextPanel(	String nextLevel, 
									String id, 
									String dataFileName)
	{
		boolean bException=false;

		OperatorPanel	nextLevelPanel=null;

		try
		{
			nextLevelPanel = new OperatorPanel( operatorParent, 
												  id, 
												  nextLevel, 
												  dataFileName);
		}
		catch (Exception exc)
		{
			bException=true;
		}

		if (!bException)
			operatorParent.setCurrentActiveComponent(nextLevelPanel);
	}

	/**
	 * Create the popup menu based on the current level
	 */
	protected void populatePopup(JPopupMenu popup)
	{
		JMenu goTo = new JMenu("Get");
		popup.add(goTo);

		if (LEVEL.equals(CATEGORY_LEVEL)) 
		{
			goTo.add(createDevicesMenu());
		}
		else if (LEVEL.equals(DEVICES_LEVEL)) 
		{
			goTo.add(createDaysMenu());
			goTo.add(createHoursMenu());
			goTo.add(createServicesMenu());
			goTo.add(createEventsMenu());
		}
		else if (LEVEL.equals(DAILY_LEVEL)) 
		{
			goTo.add(createHoursMenu());
			goTo.add(createServicesMenu());
			goTo.add(createEventsMenu());
		}
		else if (LEVEL.equals(HOURLY_LEVEL)) 
		{
			goTo.add(createServicesMenu());
			goTo.add(createEventsMenu());
		}
		else if (LEVEL.equals(SERVICES_LEVEL)) 
		{
			goTo.add(createEventsMenu());
		}
	}

	protected JMenu createDevicesMenu()
	{
		JMenuItem	menuItem;

		// nodes
		JMenu nodeMenu = new JMenu("Nodes");

		menuItem = new JMenuItem("Top 5 Node Offenders");
		menuItem.addActionListener(new PopupMenuActionListener());
		nodeMenu.add(menuItem);
	
		menuItem = new JMenuItem("Top 10 Node Offenders");
		menuItem.addActionListener(new PopupMenuActionListener());
		nodeMenu.add(menuItem);
		
		return nodeMenu;
	}

	protected JMenu createDaysMenu()
	{
		JMenuItem	menuItem;
		
		// days
		JMenu daysMenu = new JMenu("Days");

		menuItem = new JMenuItem("Last 5 days");
		menuItem.addActionListener(new PopupMenuActionListener());
		daysMenu.add(menuItem);

		menuItem = new JMenuItem("Last 10 days");
		menuItem.addActionListener(new PopupMenuActionListener());
		daysMenu.add(menuItem);
		
		return daysMenu;
	}
	
	protected JMenu createHoursMenu()
	{
		JMenuItem	menuItem;

		// hourly
		JMenu hoursMenu = new JMenu("Hours");

		menuItem = new JMenuItem("Last 12 hours");
		menuItem.addActionListener(new PopupMenuActionListener());
		hoursMenu.add(menuItem);

		menuItem = new JMenuItem("Last 24 hours");
		menuItem.addActionListener(new PopupMenuActionListener());
		hoursMenu.add(menuItem);
		
		return hoursMenu;
	}
	
	protected JMenu createServicesMenu()
	{
		JMenuItem	menuItem;

		// services
		JMenu servicesMenu = new JMenu("Services");

		menuItem = new JMenuItem("Last 30 min services");
		menuItem.addActionListener(new PopupMenuActionListener());
		servicesMenu.add(menuItem);

		menuItem = new JMenuItem("Last 60 min services");
		menuItem.addActionListener(new PopupMenuActionListener());
		servicesMenu.add(menuItem);
		
		return servicesMenu;
	 }

	protected JMenu createEventsMenu()
	{
		JMenuItem	menuItem;

		// events
		JMenu eventsMenu = new JMenu("Events");


		// last 30 min
		JMenu menu = new JMenu("Last 30 min events");

		JMenu severityMenu = new JMenu("Severity");
		menu.add(severityMenu);

		menuItem = new JMenuItem("All");
		menuItem.setActionCommand("30:All");
		menuItem.addActionListener(new PopupMenuActionListener());
		severityMenu.add(menuItem);

		menuItem = new JMenuItem("Critical");
		menuItem.setActionCommand("30:Critical");
		menuItem.addActionListener(new PopupMenuActionListener());
		severityMenu.add(menuItem);

		menuItem = new JMenuItem("Warning");
		menuItem.setActionCommand("30:Warning");
		menuItem.addActionListener(new PopupMenuActionListener());
		severityMenu.add(menuItem);

		menuItem = new JMenuItem("Informational");
		menuItem.setActionCommand("30:Informational");
		menuItem.addActionListener(new PopupMenuActionListener());
		severityMenu.add(menuItem);

		eventsMenu.add(menu);


		// last 60 min
		menu = new JMenu("Last 60 min events");

		severityMenu = new JMenu("Severity");
		menu.add(severityMenu);

		menuItem = new JMenuItem("All");
		menuItem.setActionCommand("60:All");
		menuItem.addActionListener(new PopupMenuActionListener());
		severityMenu.add(menuItem);

		menuItem = new JMenuItem("Critical");
		menuItem.setActionCommand("60:Critical");
		menuItem.addActionListener(new PopupMenuActionListener());
		severityMenu.add(menuItem);

		menuItem = new JMenuItem("Warning");
		menuItem.setActionCommand("60:Warning");
		menuItem.addActionListener(new PopupMenuActionListener());
		severityMenu.add(menuItem);

		menuItem = new JMenuItem("Informational");
		menuItem.setActionCommand("60:Informational");
		menuItem.addActionListener(new PopupMenuActionListener());
		severityMenu.add(menuItem);

		eventsMenu.add(menu);


		// all events
		menu = new JMenu("All Events");

		severityMenu = new JMenu("Severity");
		menu.add(severityMenu);

		menuItem = new JMenuItem("All");
		menuItem.setActionCommand("All:All");
		menuItem.addActionListener(new PopupMenuActionListener());
		severityMenu.add(menuItem);

		menuItem = new JMenuItem("Critical");
		menuItem.setActionCommand("All:Critical");
		menuItem.addActionListener(new PopupMenuActionListener());
		severityMenu.add(menuItem);

		menuItem = new JMenuItem("Warning");
		menuItem.setActionCommand("All:Warning");
		menuItem.addActionListener(new PopupMenuActionListener());
		severityMenu.add(menuItem);

		menuItem = new JMenuItem("Informational");
		menuItem.setActionCommand("All:Informational");
		menuItem.addActionListener(new PopupMenuActionListener());
		severityMenu.add(menuItem);

		eventsMenu.add(menu);
		
		return eventsMenu;
	}


	/**
	 * The PopupMenu listener - depending on what option the user chooses,
	 * create the next level panel
	 */
	class PopupMenuActionListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e)
		{
			String	popQty =null;
			String	popLevel=null;
			String	popSeverity=null;

			String actionStr = e.getActionCommand();
			
			if (actionStr.equals("Top 5 Node Offenders"))
			{
				popQty = "5";
				popLevel = DEVICES_LEVEL;
			}

			else if (actionStr.equals("Top 10 Node Offenders"))
			{
				popQty = "10";
				popLevel = DEVICES_LEVEL;
			}

			else if (actionStr.equals("Last 5 days"))
			{
				popQty = "5d";
				popLevel = DAILY_LEVEL;
			}

			else if (actionStr.equals("Last 10 days"))
			{
				popQty = "10d";
				popLevel = DAILY_LEVEL;
			}

			else if (actionStr.equals("Last 12 hours"))
			{
				popQty = "12h";
				popLevel = HOURLY_LEVEL;
			}

			else if (actionStr.equals("Last 24 hours"))
			{
				popQty = "24h";
				popLevel = HOURLY_LEVEL;
			}

			else if (actionStr.equals("Last 30 min services"))
			{
				popQty = "30m";
				popLevel = SERVICES_LEVEL;
			}

			else if (actionStr.equals("Last 60 min services"))
			{
				popQty = "60m";
				popLevel = SERVICES_LEVEL;
			}

			else if (actionStr.equals("30:All"))
			{
				popQty = "30m";
				popLevel = EVENTS_LEVEL;
				
				popSeverity = "All";
			}

			else if (actionStr.equals("30:Critical"))
			{
				popQty = "30m";
				popLevel = EVENTS_LEVEL;
				
				popSeverity = "Critical";
			}

			else if (actionStr.equals("30:Warning"))
			{
				popQty = "30m";
				popLevel = EVENTS_LEVEL;
				
				popSeverity = "Warning";
			}

			else if (actionStr.equals("30:Informational"))
			{
				popQty = "30m";
				popLevel = EVENTS_LEVEL;
				
				popSeverity = "Informational";
			}


			else if (actionStr.equals("60:All"))
			{
				popQty = "60m";
				popLevel = EVENTS_LEVEL;

				popSeverity = "All";
			}

			else if (actionStr.equals("60:Critical"))
			{
				popQty = "60m";
				popLevel = EVENTS_LEVEL;

				popSeverity = "Critical";
			}

			else if (actionStr.equals("60:Warning"))
			{
				popQty = "60m";
				popLevel = EVENTS_LEVEL;

				popSeverity = "Warning";
			}

			else if (actionStr.equals("60:Informational"))
			{
				popQty = "60m";
				popLevel = EVENTS_LEVEL;

				popSeverity = "Informational";
			}


			else if (actionStr.equals("All:All"))
			{
				popQty = "All";
				popLevel = EVENTS_LEVEL;

				popSeverity = "All";
			}
			
			else if (actionStr.equals("All:Critical"))
			{
				popQty = "All";
				popLevel = EVENTS_LEVEL;

				popSeverity = "Critical";
			}
			
			else if (actionStr.equals("All:Warning"))
			{
				popQty = "All";
				popLevel = EVENTS_LEVEL;

				popSeverity = "Warning";
			}
			
			else if (actionStr.equals("All:Informational"))
			{
				popQty = "All";
				popLevel = EVENTS_LEVEL;

				popSeverity = "Informational";
			}
			
			String dataFileName = sendRequestForData(popLevel, popQty, popSeverity);
			String id = addRelevantInfo(popLevel, ID);
			createNextPanel(popLevel, id, dataFileName);
		}
	}

	/**
	 * When the user skips levels, add current date/time info. to the ID
	 * The ID has the info. about all levels of the bar separated by the
	 * ID_SEPARATOR
	 */
	String addRelevantInfo(String nextReqLevel, String curID)
	{
		StringBuffer id = new StringBuffer(curID);

		if (LEVEL.equals(DEVICES_LEVEL))
		{
			if (nextReqLevel.equals(HOURLY_LEVEL))
			{
				id.append(ID_SEPARATOR);
				id.append(getCurrentDateStr());
			}
			else if (nextReqLevel.equals(SERVICES_LEVEL))
			{
				id.append(ID_SEPARATOR);
				id.append(getCurrentDateStr());
				id.append(ID_SEPARATOR);
				id.append(getCurrentTimeStr());
			}
			else if (nextReqLevel.equals(EVENTS_LEVEL))
			{
				id.append(ID_SEPARATOR);
				id.append(getCurrentDateStr());
				id.append(ID_SEPARATOR);
				id.append(getCurrentTimeStr());
				id.append(ID_SEPARATOR);
				id.append("All");
			}
		}

		else if (LEVEL.equals(DAILY_LEVEL))
		{
			if (nextReqLevel.equals(SERVICES_LEVEL))
			{
				id.append(ID_SEPARATOR);
				id.append(getCurrentTimeStr());
			}
			else if (nextReqLevel.equals(EVENTS_LEVEL))
			{
				id.append(ID_SEPARATOR);
				id.append(getCurrentTimeStr());
				id.append(ID_SEPARATOR);
				id.append("All");
			}
		}

		else if (LEVEL.equals(HOURLY_LEVEL))
		{
			if (nextReqLevel.equals(EVENTS_LEVEL))
			{
				id.append(ID_SEPARATOR);
				id.append("All");
			}
		}

		return id.toString();
	}

	/**
	 * Get current date
	 */
	String getCurrentDateStr()
	{
		// get current date
		Calendar curCal = new java.util.GregorianCalendar();

		// while at it store the current date
		java.text.SimpleDateFormat formatter =  
					new java.text.SimpleDateFormat("MMM d, yyyy");

		String curDate = formatter.format(curCal.getTime());
		
		return curDate;
	}

	/**
	 * Get current time
	 */
	String getCurrentTimeStr()
	{
		// get current date
		Calendar curCal = new java.util.GregorianCalendar();

		// while at it store the current date
		java.text.SimpleDateFormat formatter =  
				new java.text.SimpleDateFormat("hh:mm aaa");

		String curTime = formatter.format(curCal.getTime());
		
		return curTime;
	}

	/**
	 * Return label
	 */
	protected String getLabel()
	{
		return LABEL;
	}

	/**
	 * Return id
	 */
	public String getID()
	{
		return ID;
	}

	/**
	 * Return level
	 */
	protected String getLevel()
	{
		return LEVEL;
	}

	/**
	 * Return translated length (length to which the bar should draw 
	 * itself based on the parent chart size)
	 */
	protected double getTranslatedLength()
	{
		return translatedLength;
	}
	
	/**
	 * Return actual bar size
	 */
	protected double getLength()
	{
		return length;
	}

	/**
	 * Get the operator parent panel
	 */
	public OperatorInterfacePanel getOpParent()
	{
		return operatorParent;
	}

}


//-------------------------------------------------------------------------------------------
//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

//--------------------------------------------------------------------------------------------

package org.opennms.bb.eui.admin.distpoller.configure.cals;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;

public class schedulePanel extends JPanel 
{
	/**
	 * Added status flags ALL_ON, ALL_OFF, MIXED
	 * If the user is in the 'Day of the Week' he cannot edit the
	 * 'Status' field in the the 'Hours of Operation' table if the
	 * current day has a status of 'ALL_ON' or 'All_OFF'
	 * The user can only edit the 'hours of Op' table when in
	 * 'Day of the Week' tab and 'Status' is MIXED or
	 * 'Day of Month' tab - Sowmya
	 */
	final int	ALL_ON	=1;
	final int	MIXED	=0;
	final int	ALL_OFF	=-1;

	internalPanel ip = new internalPanel();
	CalendarPanel testT;

	public schedulePanel() {

		testT = new CalendarPanel(this);

		JTabbedPane tp = new JTabbedPane();

		JPanel panelOne = new JPanel();
		
		
		ip.roc.getToolButton1().addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				setCalendarStatus("All On");
				testT.setAllOn();
			}
		});

		ip.roc.getToolButton2().addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				setCalendarStatus("All Off");
				testT.setAllOff();
			}
		});


		ip.weekT.getToolButton1().addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				testT.setAllOn();
			}
		});

		ip.weekT.getToolButton2().addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				testT.setAllOff();
			}
		});


		JPanel panel1 = new JPanel();
		panel1.setLayout(new BoxLayout(panel1, BoxLayout.Y_AXIS));
		panel1.add(Box.createVerticalGlue());
		panel1.add(Box.createRigidArea(new Dimension(0,5)));
		panel1.add(Box.createVerticalGlue());
		panel1.add(ip);
		

		JPanel panel2 = new JPanel();
		panel2.setLayout(new BoxLayout(panel2, BoxLayout.Y_AXIS));
		panel2.add(new JLabel("Hours of Operation"));
		panel2.add(Box.createRigidArea(new Dimension(0,5)));
		panel2.add(testT);

		panelOne.setLayout(new BoxLayout(panelOne, BoxLayout.X_AXIS));
		panelOne.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		panelOne.add(Box.createHorizontalGlue());
		panelOne.add(panel1);
		panelOne.add(Box.createRigidArea(new Dimension(10, 0)));
		panelOne.add(panel2);

		
		JPanel panelTwo = new JPanel();
		panelTwo.add(new NodesPanel());
		
		tp.add( "Nodes", panelTwo);
		tp.addTab( "Schedules", panelOne);

		add(tp, BorderLayout.CENTER);
		
	}

	void setCalendarStatus(String selText)
	{
		if(selText.equals("All Off"))
		{
				testT.setAllOff();
		}
		else if(selText.equals("All On"))
		{
				testT.setAllOn();
		}
		else 
		{
			testT.setMixed();
		}
	}

	public int getOnOffStatus()
	{
		if (ip.getSelectedTabIndex() == 0)
		{
			return testT.getOnOffStatus();
		}
		else
			return MIXED;
	}

}

//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.admin.servmodel.components;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.table.*;
import javax.swing.event.*;

import java.util.Vector;

import org.opennms.bb.eui.common.components.*;

/**
 * SMManipTable extends BBManipTable and provides header tooltips and
 * and a text editor for the model name/descr columns
 *
 * @author Sowmya
 *
 */
public class SMManipTable extends BBManipTable
{
	private final int NAME_COL	= 1;
	private final int DESCR_COL	= 2;

	public SMManipTable(Vector inpColNames)
	{
		super(inpColNames);
	}
	
	public SMManipTable(Vector inpRowData, Vector inpColNames)
	{
		super(inpRowData, inpColNames);
	}

	protected void setHeaderToolTips()
	{
		int iNumCols = getColumnCount();

		TableColumnModel colModel = getColumnModel();
		for (int iIndex=0; iIndex<iNumCols; iIndex++)
		{
			String value = ((String)getColumnName(iIndex)).toLowerCase();

			TableCellRenderer hdrRenderer = columnModel.getColumn(iIndex).getHeaderRenderer();
			if (hdrRenderer == null)
				continue;

			Component hdrComponent = hdrRenderer.getTableCellRendererComponent(this, value, false, false, 0, 0);

			//check if tooltip can be set
			if (!(hdrComponent instanceof JComponent))
				continue;

			JComponent comp = (JComponent)hdrComponent;
			if (comp.getToolTipText() != null)
				continue;

			if (iIndex == NAME_COL)
			{
				comp.setToolTipText("Name of the model");
			}

			else if (iIndex == DESCR_COL)
			{
				comp.setToolTipText("Brief description of the model");
			}
		}
	}
	
	public TableCellEditor getCellEditor(int row, int col)
	{

		if (col == NAME_COL || col == DESCR_COL)
		{
			ServiceModelNameTextField colText = new ServiceModelNameTextField();
			return new BBColumnEditor(colText);
		}

		else
			return super.getCellEditor(row, col);

	}

}


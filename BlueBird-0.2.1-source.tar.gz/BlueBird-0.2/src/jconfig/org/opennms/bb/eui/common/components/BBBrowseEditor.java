//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.common.components;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.event.*;

import java.io.File;

/**
 * <pre>BBBrowseEditor is the table cell editor that provides the
 * file browse editor.
 * 
 * It extends the DefaultCellEditor and brings up a JFileChooser and
 * once the user chooses a value, this value is set as the value of the
 * previous cell
 *
 *</pre>
 *
 * @author Sowmya
 *
 */
public class BBBrowseEditor extends DefaultCellEditor
{
	BBBrowseRenderer renderer = new BBBrowseRenderer();

	String 			fileName;
	JTable			editTable;
	int			editRow=-1;
	int			editCol=-1;

	/**
	 * Creates the browse editor - the renderer button's action
	 * listener is set to bring up the file chooser for the user to
	 * choose the file
	 */
	public BBBrowseEditor()
	{
		super(new JTextField());

		editorComponent = renderer.getButton();
		setClickCountToStart(1);

		renderer.getButton().addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				JFileChooser fileChooser=new JFileChooser();
		
				int iRetVal = fileChooser.showOpenDialog(null);
		
				if(iRetVal == JFileChooser.APPROVE_OPTION)
				{
					File fileChosen = fileChooser.getSelectedFile();
					fileName = fileChosen.getPath();

					stopCellEditing();
				}
				else if(iRetVal == JFileChooser.CANCEL_OPTION)
				{
					cancelCellEditing();
				}
			}
		});

	}

	/**
	 * Overrides the method in the the parent class and returns the
	 * editor component
	 */
	public Component getTableCellEditorComponent(JTable table,
						Object value,
						boolean isSelected,
						int row, int col)
	{
		editTable = table;
		editRow   = row;
		editCol   = col;

		return renderer.getTableCellRendererComponent(table, value, true, true, row, col);
	}

	/**
 	 * This cell editor is different because it sets the value of the 
	 * revious cell
 	 */
	public boolean stopCellEditing()
	{
		SwingUtilities.invokeLater(new Runnable()
		{
			public void run()
			{
				getComponent().requestFocus();
			}
		});

		/*
		 * This is an unusual editor component in the sense that
		 * it sets the value of its previous column!
		 */
		boolean   isValueNull = false;

		try
		{
			if (fileName.equals(null))
			{
			}

		} catch (NullPointerException e)
		{
			isValueNull = true;
		}

		if (!isValueNull && !(fileName.equals(""))  )
		{
			editTable.setValueAt(fileName, editRow, editCol-1);

			fileName="";

		}

		boolean bRet = super.stopCellEditing();
		return bRet;

	}
}


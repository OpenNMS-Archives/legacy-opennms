//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.common.components;

import javax.swing.*;
import javax.swing.text.*;

import java.awt.*;
import java.awt.event.*;

import java.util.*;

/**
 * <pre>IPAddressTextField creates its own document that allows only digits
 * dots and some restricted letters to be entered
 *
 * The validity methods allow only values 
 * of the format [0-255].[0-255].[0-255].[0-255] 
 *
 * @author Sowmya
 *
 */
public class IPAddressTextField extends BBTextField 
{
	private Toolkit toolkit;

	final static int IPADDR_OCTET_COUNT=7;	// includes the dots

	public IPAddressTextField(int columns)
	{
		super(columns);

		toolkit = Toolkit.getDefaultToolkit();
	}

	public IPAddressTextField()
	{
		super();

		toolkit = Toolkit.getDefaultToolkit();
	}

	public String getValue()
	{
		return getText();
	}

	public void setValue(String value)
	{
		setText(value);
	}

	protected Document createDefaultModel()
	{
		return new IPAddressTextFieldDocument();
	}

	protected class IPAddressTextFieldDocument extends PlainDocument
	{
		public void insertString(int offs, String str, AttributeSet a) throws BadLocationException
		{
			char[] source = str.toCharArray();
			char[] result = new char[source.length];
	
			int iResIndex=0;
	
			for(int iSrcIndex=0; iSrcIndex < result.length; iSrcIndex++)
			{
				if(Character.isDigit(source[iSrcIndex]) ||
				   source[iSrcIndex] == '.')
				{
					result[iResIndex++] = source[iSrcIndex];
				}
				//else
					//toolkit.beep();
			}
			
			super.insertString(offs, new String(result, 0, iResIndex), a);
		}
	}
	
	
	public boolean isValid()
	{
		String value = getText();
		
		return checkFormat(value);
	}

	public static boolean checkFormat(String value)
	{

		StringTokenizer tokens = new StringTokenizer(value, ".", true);
		if (tokens.countTokens() != IPADDR_OCTET_COUNT)
		{
			// oops! too many or too little octets
			return false;
		}
		else
		{
			// The dots are included in the octet count because 
			// StringTokenizer() considers a '..' equi to a single '.'

			while(tokens.hasMoreTokens())
			{
				String tokVal = tokens.nextToken();

				if (tokVal.equals(".") == false) // ignore the dots
				{
					int	 iOctetValue=Integer.parseInt(tokVal, 10);
					if (iOctetValue < 0 || iOctetValue > 255)
					{
						// octet values incorrect
						return false;
					}
				}
			}
			
			return true;
		}
	}
}

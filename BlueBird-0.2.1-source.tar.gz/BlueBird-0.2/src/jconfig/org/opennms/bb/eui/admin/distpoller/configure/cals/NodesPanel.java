//-------------------------------------------------------------------------------------------
//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

//--------------------------------------------------------------------------------------------

package org.opennms.bb.eui.admin.distpoller.configure.cals;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.event.*;
import java.util.Vector;


public class NodesPanel extends JPanel
{

	public JButton b1,b2;
	public List  listBox1;
	JTextField nodeField;
	boolean flag = false;
	Vector mVector = new Vector();

	public NodesPanel() {

		setLayout(new BorderLayout());

			
		b1 = new JButton("Add >>");
		b2 = new JButton("<< Remove");
		b2.setEnabled(false);

		nodeField = new JTextField(20);
		nodeField.setPreferredSize(new Dimension(150, 25));
		nodeField.setMinimumSize(new Dimension(150, 25));
		nodeField.setMaximumSize(new Dimension(150, 25));


		listBox1 = new List();
		listBox1.setMultipleMode(true);
		JScrollPane listScroller1 = new JScrollPane(listBox1);
		listScroller1.setPreferredSize(new Dimension(150, 350));
		listScroller1.setMinimumSize(new Dimension(150, 350));
		listScroller1.setAlignmentX(LEFT_ALIGNMENT);


		//Lay out the label and scroll pane from top to bottom.
		JPanel listPane = new JPanel();
		listPane.setLayout(new BoxLayout(listPane, BoxLayout.Y_AXIS));
		JLabel label = new JLabel("Node to Add:");
		listPane.add(label);
		listPane.add(Box.createRigidArea(new Dimension(0,5)));
		listPane.add(nodeField);
		listPane.add(Box.createVerticalGlue());
		listPane.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
		
		//Lay out the buttons from top to bottom
		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.Y_AXIS));
		buttonPanel.add(Box.createRigidArea(new Dimension(0,30)));
		buttonPanel.add(b1);
		buttonPanel.add(Box.createRigidArea(new Dimension(0,10)));
		buttonPanel.add(b2);
		buttonPanel.add(Box.createVerticalGlue());
		
		//Lay out the label1 and scroll pane1 from top to bottom.
		JPanel listPane1 = new JPanel();
		listPane1.setLayout(new BoxLayout(listPane1, BoxLayout.Y_AXIS));
		JLabel label1 = new JLabel("Nodes for the Calendar:");
		listPane1.add(label1);
		listPane1.add(Box.createRigidArea(new Dimension(0,5)));
		listPane1.add(listScroller1);
		listPane1.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));


		

		//Lay out the above panels from left to right.
		JPanel groupPane = new JPanel();
		groupPane.setLayout(new BoxLayout(groupPane, BoxLayout.X_AXIS));
		groupPane.setBorder(BorderFactory.createEmptyBorder(0, 10, 10, 10));
		groupPane.add(Box.createHorizontalGlue());
		groupPane.add(listPane);
		groupPane.add(Box.createRigidArea(new Dimension(20, 0)));
		groupPane.add(buttonPanel);
		groupPane.add(Box.createRigidArea(new Dimension(20, 0)));
		groupPane.add(listPane1);
		groupPane.add(Box.createHorizontalGlue());

		add(groupPane, BorderLayout.CENTER);

		b1.addActionListener( new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{
					if (nodeField.getText().trim().equals("")) 
				    	{
     						Toolkit.getDefaultToolkit().beep();
      						return;
	    			 	}
					
					String str[] = listBox1.getItems();
					for (int i = 0; i < str.length; i++)
					{
						mVector.addElement(str[i]); 
					}

				    	if (!mVector.contains(nodeField.getText().trim())) 
					{
						listBox1.add(nodeField.getText().trim());		    
					}
					else
					{
						Toolkit.getDefaultToolkit().beep();
					}

					int size = listBox1.getItemCount();

					//Nobody's left, disable firing
   					if (size != 0)
					{
      						b2.setEnabled(true);
					}
					else
					{
						b2.setEnabled(false);
					}
					mVector.removeAllElements();
				}
				catch (Exception e1){
					System.out.println("insertion problem");
				}
			}
		});

	
		b2.addActionListener( new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{
					//Nobody's left, disable firing
					String[] swap1 = listBox1.getSelectedItems();
					if (swap1.length == 0)
					{
						Toolkit.getDefaultToolkit().beep();
						return;
					}
					for (int j = 0; j < swap1.length; j++ )  {
						
						listBox1.remove(swap1[j]);
						int size = listBox1.getItemCount();
						
						if (size == 0)
						{
      							b2.setEnabled(false);
							return;
						}
					}

				}
				catch (Exception e1){
					System.out.println("removal problems");
				}
			}
		});
	}

	public String[] getSelectedValues() {

		String[] retvalue = listBox1.getItems();
		return retvalue;
	}

}


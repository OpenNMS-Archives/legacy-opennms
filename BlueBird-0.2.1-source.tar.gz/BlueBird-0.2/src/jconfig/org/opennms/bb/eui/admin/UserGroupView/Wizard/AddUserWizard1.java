//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
package org.opennms.bb.eui.admin.UserGroupView.Wizard;

import java.awt.*;
import javax.swing.*;

import org.opennms.bb.eui.admin.UserGroupView.Main.UserManager;

public class AddUserWizard1 extends JDialog
{

	public AddUserWizard1(JFrame parent, boolean modal)
	{
		super(parent, modal);

		JLabel oDescriptionLabel= new JLabel();
		JLabel oUserIdLabel		= new JLabel();

		getContentPane().setLayout(null);
		setBackground(java.awt.Color.lightGray);
		setSize(383,200);
		setVisible(false);

		getContentPane().add(m_oUserInput);
		oUserIdLabel.setText("Id of the new user:");
		getContentPane().add(oUserIdLabel);
		oUserIdLabel.setBounds(24,96,112,24);
		m_oNextButton.setText("Next >");
		getContentPane().add(m_oNextButton);
		m_oNextButton.setBounds(72,156,85,25);
		m_oUserInput.setBounds(140,96,192,24);
		m_oCancelButton.setText("Cancel");
		getContentPane().add(m_oCancelButton);
		m_oCancelButton.setBounds(208,156,85,25);
		oDescriptionLabel.setText(
			    "Welcome to the New user Wizard."
		);
		getContentPane().add(oDescriptionLabel);
		//oDescriptionLabel.setBounds(24,24,333,60);
		oDescriptionLabel.setBounds(24,4,333,60);
		oDescriptionLabel.setFont(new Font("Helvetica", Font.BOLD, 14));
		setTitle("New User Wizard Part 1");
		setResizable(false);

		SymWindow oSymWindow = new SymWindow();
		this.addWindowListener(oSymWindow);

		SymAction oSymAction = new SymAction();
		m_oNextButton.addActionListener(oSymAction);
		m_oCancelButton.addActionListener(oSymAction);

		m_oUserInput.addMouseListener(new java.awt.event.MouseAdapter()
									  {
										public void mousePressed(java.awt.event.MouseEvent e)
										{
											m_oUserInput.setBackground(java.awt.Color.white);
										}
										public void mouseClicked(java.awt.event.MouseEvent e)
										{
											m_oUserInput.setBackground(java.awt.Color.white);
										}
									  }
									 );
		m_oUserInput.addKeyListener(new java.awt.event.KeyAdapter()
									  {
										public void keyTyped(java.awt.event.KeyEvent e)
										{
											m_oUserInput.setBackground(java.awt.Color.white);
										}
										public void keyPressed(java.awt.event.KeyEvent e)
										{
											m_oUserInput.setBackground(java.awt.Color.white);
										}
									  }
									 );

	}
    
	public AddUserWizard1(JFrame parent, String title, boolean modal)
	{
		this(parent, modal);
		setTitle(title);
	}

	public void addNotify()
	{
		Dimension d = getSize();

		super.addNotify();

		if (m_bComponentsAdjusted)
		{
			return;
		}

		Insets insets = getInsets();
		setSize(insets.left + insets.right + d.width, insets.top + insets.bottom + d.height);
		Component components[] = getComponents();
		for (int i = 0; i < components.length; i++)
		{
			Point p = components[i].getLocation();
			p.translate(insets.left, insets.top);
			components[i].setLocation(p);
		}

		m_bComponentsAdjusted = true;
	}

	public void setVisible(boolean b)
	{
	    if (b)
	    {
    		Rectangle bounds = getParent().getBounds();
    		Rectangle abounds = getBounds();

    		setLocation(bounds.x + (bounds.width - abounds.width)/ 2,
    			 bounds.y + (bounds.height - abounds.height)/2);
	    }

		super.setVisible(b);
	}

	JTextField	m_oUserInput	= new JTextField();
	JButton		m_oNextButton	= new JButton();
	JButton		m_oCancelButton	= new JButton();
    
    // Used for addNotify check.
	boolean m_bComponentsAdjusted = false;

	class SymAction implements java.awt.event.ActionListener
	{
		public void actionPerformed(java.awt.event.ActionEvent event)
		{
			Object object = event.getSource();
			if (object == m_oNextButton)
			{
				String input = m_oUserInput.getText();
				if( (input == null) || (input.equals("")) || (input.equals("\0")) || (input.equals("\n")) || (input.equals("\r")) || (input.equals("0x00")) )
				{
				    m_oUserInput.setBackground(java.awt.Color.red);
				}
				else 
				{
				    try
					{
						if( (m_oUserInput.getText() != null) && (m_oUserInput.getText() != "") && (m_oUserInput.getText() != "\0") && (m_oUserInput.getText() != "\n"&& (m_oUserInput.getText() != "\r") ) )
						{
							UserManager.add(UserManager.USER, m_oUserInput.getText());
						}
						setVisible(false);
						dispose();
						// addUserPasswordWizard Create and show as modal
						(new AddUserWizard2(((JFrame)getParent()), true)).setVisible(true);

			
					}
					catch (Exception e)
					{
						UserManager.cancel();
					}
				}
			}
			else if (object == m_oCancelButton)
			{
			    try
				{
			        setVisible(false);
				    dispose();
			    }
				catch (Exception e)
				{
				}

			}
		}
	}

	class SymWindow extends java.awt.event.WindowAdapter
	{
		public void windowClosing(java.awt.event.WindowEvent event)
		{
			Object object = event.getSource();
			if (object == AddUserWizard1.this)
			{
		        setVisible(false);
				dispose();
			}
		}
	}

	public static void main(String args[])
	{
		JFrame frame = new JFrame();
		frame.setSize(550,400);
		try
		{
			(new AddUserWizard1(frame, true)).setVisible(true);
		}
		catch(Exception e)
		{
		}
	}

}

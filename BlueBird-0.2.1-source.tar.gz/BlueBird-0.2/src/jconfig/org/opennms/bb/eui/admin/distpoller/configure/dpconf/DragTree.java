//-------------------------------------------------------------------------------------------
//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

//--------------------------------------------------------------------------------------------

package org.opennms.bb.eui.admin.distpoller.configure.dpconf;

import javax.swing.*;
import javax.swing.text.*;
import javax.swing.tree.*;
import javax.swing.border.*;
import javax.swing.JTree; 
import javax.swing.event.*;

import java.awt.*;
import java.awt.event.*;
import java.awt.dnd.*; 
import java.awt.datatransfer.*; 
import java.awt.Point; 
//import java.util.*;

import java.io.IOException; 


public class DragTree extends JTree {

    private DragSource		    dragSource; 
    private DropTarget		    dropTarget; 
    DragDropTree ddt;

    private TreeGestureListener	    gestureListener; 
    private TreeSourceListener	    sourceListener; 
    private TreeTargetListener	    targetListener; 


    private DefaultMutableTreeNode  dragNode = null; 


    private class TreeGestureListener implements DragGestureListener { 
	public void dragGestureRecognized(DragGestureEvent e) { 
	    Point		    nodeLocation = e.getDragOrigin(); 
	    DefaultMutableTreeNode  treeNode = getTreeNode(nodeLocation); 


	    if (treeNode != null) { 
		dragNode = treeNode; 
		
		if (treeNode.isLeaf())
		{
			if ( (treeNode.getParent().toString().trim()).equals("One-time") )
			{
				UserManager.m_CalendarType = "O";
			}
			else if ( (treeNode.getParent().toString().trim()).equals("Repeating") )
			{
				UserManager.m_CalendarType = "R";
			}
		}

		// Start the drag. 
		dragSource.startDrag(e, DragSource.DefaultCopyDrop, 
				    new StringSelection(treeNode.toString()), 
				    sourceListener); 
	    } 
	} 
    } 


    private class TreeSourceListener implements DragSourceListener { 
	public void dragDropEnd(DragSourceDropEvent e) { 
	    // Do Nothing. 
	} 


	public void dragEnter(DragSourceDragEvent e) { 
	    // Do Nothing. 
	} 


	public void dragExit(DragSourceEvent e) { 
	    // Do Nothing. 
	} 


	public void dragOver(DragSourceDragEvent e) { 
	    // Do Nothing. 
	} 


	public void dropActionChanged(DragSourceDragEvent e) { 
	    // Do Nothing. 
	} 
    } 


    private class TreeTargetListener implements DropTargetListener { 
	public void drop(DropTargetDropEvent e) { 
		
	  try { 
		Point			dropLocation = e.getLocation(); 
		DefaultMutableTreeNode	treeNode = getTreeNode(dropLocation); 
		DataFlavor		stringFlavor = DataFlavor.stringFlavor; 
		Transferable		data = e.getTransferable(); 

		
		if (treeNode != null &&  e.isDataFlavorSupported(stringFlavor) ) { 
		    String text = (String) data.getTransferData(stringFlavor); 
			
			//System.out.println(text);

		   e.acceptDrop(DnDConstants.ACTION_COPY_OR_MOVE); 


		    // Creat a new Node with the text. 
		    DefaultMutableTreeNode newNode = new DefaultMutableTreeNode(text); 

			//System.out.println("pack name from drag tree= " + treeNode.getParent().toString());

		    // Add the new node to the current node. 
		    treeNode.add(newNode); 
			((DefaultTreeModel)getModel()).reload(treeNode);
		    e.dropComplete(true); 
		} 
		else { 
			Toolkit.getDefaultToolkit().beep();
		    e.rejectDrop(); 
		} 
	    } 
	    catch(IOException ioe) { 
		ioe.printStackTrace(); 
	    } 
	    catch(UnsupportedFlavorException ufe) { 
		ufe.printStackTrace(); 
	    } 
	} 


	public void dragEnter(DropTargetDragEvent e) { 
	    if (isDragOk(e) == false) { 
	//	Toolkit.getDefaultToolkit().beep();
		e.rejectDrag(); 
		return; 
	    } 


	    e.acceptDrag(DnDConstants.ACTION_COPY_OR_MOVE); 
	} 


	public void dragExit(DropTargetEvent e) { 
	    // Do Nothing. 
	} 


	public void dragOver(DropTargetDragEvent e) { 
	    Point	dragLocation = e.getLocation(); 
	    TreePath	treePath = getPathForLocation(dragLocation.x, dragLocation.y); 


	    if (isDragOk(e) == false || treePath == null) { 
	//	Toolkit.getDefaultToolkit().beep();
		e.rejectDrag(); 
		return; 
	    } 


	    // Make the node active. 
	    setSelectionPath(treePath); 


	    e.acceptDrag(DnDConstants.ACTION_COPY_OR_MOVE); 
	} 


	public void dropActionChanged(DropTargetDragEvent e) { 
	    if (isDragOk(e) == false) { 
	//	Toolkit.getDefaultToolkit().beep();
		e.rejectDrag(); 
		return; 
	    } 


	    e.acceptDrag(DnDConstants.ACTION_COPY_OR_MOVE); 
	} 


	private boolean isDragOk(DropTargetDragEvent e) { 
	    return(true); 
	} 
    } 


    
 
    public DragTree(TreeNode root) { 
	super(root); 

	ddt = new DragDropTree();
	gestureListener = new TreeGestureListener(); 
	sourceListener = new TreeSourceListener(); 
	targetListener = new TreeTargetListener(); 


	// Set up the tree to be a drop target. 
	dropTarget = new DropTarget(ddt, DnDConstants.ACTION_COPY_OR_MOVE, targetListener, true); 


	// Set up the tree to be a drag source. 
	dragSource = DragSource.getDefaultDragSource(); 
	dragSource.createDefaultDragGestureRecognizer(this, 
							DnDConstants.ACTION_COPY_OR_MOVE, 
							gestureListener); 
    } 


    private DefaultMutableTreeNode getTreeNode(Point location) { 
	TreePath treePath = getPathForLocation(location.x, location.y); 


	if (treePath != null) { 
	    return((DefaultMutableTreeNode) treePath.getLastPathComponent()); 
	} 
	else { 
	    return(null); 
	} 
    } 
}


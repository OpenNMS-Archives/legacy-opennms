// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.common.components;

import java.awt.*;

import javax.swing.*;
import javax.swing.table.*;

/**
 * <pre>BBDefaultTableHeaderRenderer  is the default header renderer used by the
 * tables in BlueBird
 *
 * Starting in JDK1.3, the TableColumn.getHeaderRenderer() returns null by
 * default. In order to set tooltips, column width etc., this default header
 * renderer is used
 *
 * </pre>
 * @author Sowmya
 */
public class BBDefaultTableHeaderRenderer implements TableCellRenderer
{
	JLabel		label;

	/**
	 * Creates the BBDefaultTableRenderer
	 */
	public BBDefaultTableHeaderRenderer()
	{
		label = new JLabel();
		label.setBorder(BorderFactory.createRaisedBevelBorder());
	}
	
	/**
	 * Returns the label renderer component
	 */
	public Component getTableCellRendererComponent( JTable table,
							Object value,
							boolean isSelected,
							boolean hasFocus,
							int row,
							int col) 
	{
		label.setText((String)value);
		return label;
	}
}

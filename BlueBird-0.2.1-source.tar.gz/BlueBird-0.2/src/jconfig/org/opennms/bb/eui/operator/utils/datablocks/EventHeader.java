//
// Copyright (C) 2000 N*Manage Company, Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
// $Id: EventHeader.java,v 1.2 2000/11/01 18:04:45 jacinta Exp $

package org.opennms.bb.eui.operator.utils.datablocks;

import java.util.Date;

/**
 * EventHeader holds data from the <header>..</header> block in the incoming
 * event stream
 *
 * @author Sowmya
 * @author <A HREF="http://www.opennms.org">OpenNMS.org</A>
 */
public class EventHeader extends Object
{
	/**
	 * the dtd version used
	 */
	public String		m_ver;

	/**
	 * the distributed poller sending the events
	 */
	public String		m_dpName;

	/**
	 * the creation date of this event stream
	 */
	public Date		m_createdTime;

	/**
	 * master station associated with the poller sending the event
	 */
	public String		m_mstation;

	/**
	 * Constructs a EventHeader object
	 *
	 */
	public EventHeader(String ver, String dpName, Date created, String mstation)
	{
		m_ver		= ver;
		m_dpName	= dpName;
		m_createdTime	= created;
		m_mstation	= mstation;
	}

	public String toString()
	{
		StringBuffer str = new StringBuffer();

		str.append("VER : " + m_ver);
		str.append("Dpname : " + m_dpName);
		str.append("Created time : " + m_createdTime);
		str.append("MStation : " + m_mstation);
		return str.toString();
	}

}

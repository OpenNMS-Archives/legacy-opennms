//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.admin.servmodel.utils;

import org.w3c.dom.*;

import java.io.*;
import java.util.Vector;
import java.util.Hashtable;

import org.opennms.bb.common.utils.BBParser;

/**
 * <pre>ServiceModelsParser parses a 'ServiceModel' xml and stores the data 
 * read in vectors. This can then be queried for the data using the 'get..' 
 * functions.
 *
 * It throws an IOException if the xml file is not found or if it does not
 * conform to its DTD </pre>
 *
 * @author Sowmya
 *
 * Modifications:
 * 04/18/00 - Changed the parser to extend BBParser - Sowmya
 *
 */
public class ServiceModelsParser extends BBParser
{
	Vector	servicesData;

	/*
	 * XML TAGS
	 */
	final String MODELS		="models";
	final String MODEL		="model";
	final String MODELNAME	="modelName";
	final String MODELDESCR	="modelDescr";

	final String INTERVALS	="intervals";
	final String INTERVAL	="interval";
	final String BEGIN		="begin";
	final String END		="end";
	final String VALUE		="value";

	/**
 	 * Creates the DOM parser
 	 */
	public ServiceModelsParser()
	{
		super();
	}

	protected boolean processElement(Element el,boolean isRoot)
	{
		boolean bRet = false;

		String tag = el.getTagName();

		if (tag.equals(MODELS))
		{
			m_curElement.replace(0, m_curElement.length(), MODELS);

			bRet = processModelsNode(el);

		}

		else
		{
			boolean bNodeRet=true;

			NodeList nl = el.getChildNodes();
			int size = nl.getLength();

			for(int i = 0;i < size && bNodeRet ;i++)
				bNodeRet = processNode(nl.item(i));
			
			bRet = bNodeRet;
		}
		
		return bRet;
	}

	protected boolean processModelsNode(Node modNode)
	{
		boolean bRet = true;

		servicesData = new Vector();

		NodeList nl = modNode.getChildNodes();
		int size = nl.getLength();
		for(int i = 0;i < size && bRet ;i++)
		{
			Node curNode = nl.item(i);
			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
				if(curTag.equals(MODEL))
					bRet = processModelNode(curNode);
			}
			
		}

		return bRet;

	}

	protected boolean processModelNode(Node modNode)
	{
		boolean bRet = true;

		Hashtable modelHash = new Hashtable(3);

		NodeList nl = modNode.getChildNodes();
		int size = nl.getLength();
		for(int i = 0;i < size && bRet ;i++)
		{
			Node curNode = nl.item(i);
			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();

				if(curTag.equals(MODELNAME))
				{
					m_curElement.replace(0, m_curElement.length(), MODELNAME);

					String modelName = processParmValue(curNode); 

					if (null != modelName)
						modelHash.put(MODELNAME, modelName);
					else
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}
				}

				else if(curTag.equals(MODELDESCR))
				{
					m_curElement.replace(0, m_curElement.length(), MODELDESCR);

					String modelDescr = processParmValue(curNode); 

					if (null != modelDescr)
						modelHash.put(MODELDESCR, modelDescr);
					else
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}
				}

				else if(curTag.equals(INTERVALS))
				{
					bRet = processIntervalsNode(curNode, modelHash);
				}
			}
			
		}

		if (bRet)
			servicesData.add(modelHash);

		return bRet;
	}

	protected boolean processIntervalsNode(Node intervalNode, Hashtable modelHash)
	{
		boolean bRet = true;

		m_curElement.replace(0, m_curElement.length(), INTERVALS);

		Vector intervalsVector = new Vector();

		NodeList nl = intervalNode.getChildNodes();
		int size = nl.getLength();
		for(int i = 0;i < size && bRet ;i++)
		{
			Node curNode = nl.item(i);
			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
				if(curTag.equals(INTERVAL))
					bRet = processIntervalNode(curNode, intervalsVector);
			}
			
		}

		if (bRet)
			modelHash.put(INTERVALS, intervalsVector);

		return bRet;

	}

	protected boolean processIntervalNode(Node intervalNode, Vector intervalsVector)
	{
		boolean bRet = true;

		Vector intervalVector = new Vector(3);

		NodeList nl = intervalNode.getChildNodes();
		int size = nl.getLength();

		for(int i = 0;i < size && bRet;i++)
		{
			Node curNode = nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
				m_curElement.replace(0, m_curElement.length(), curTag);
				
				if(curTag.equals(BEGIN))
				{
					String beginValue = processParmValue(curNode); 

					if (null != beginValue)
						intervalVector.add(beginValue);
					else
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}
				}
				else if(curTag.equals(END))
				{
					String endValue = processParmValue(curNode); 

					if (null != endValue)
						intervalVector.add(endValue);
					else
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}
				}
				else if(curTag.equals(VALUE))
				{
					String value = processParmValue(curNode); 

					if (null != value)
						intervalVector.add(value);
					else
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}
				}
			}
		}

		if (intervalVector.size() == 2)
		{
			// means END not present
			intervalVector.add(1, "-");
		}

		intervalsVector.add(intervalVector);
		
		return bRet;
	}

	/**
 	 * Returns the service models data
	 *
	 */
	public Vector getServicesData()
	{
		return servicesData;
	}
}

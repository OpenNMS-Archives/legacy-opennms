//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.operator.components;

import java.util.*;
import javax.swing.*;
import javax.swing.table.*;

import java.awt.*;
import java.awt.event.*;

/**
 * OperatorEventsTableModel creates a table model that is non-editable
 *
 * @author Sowmya
 */
public class OperatorEventsTableModel extends DefaultTableModel
{
	public OperatorEventsTableModel(Vector inpData, Vector inpColNames)
	{
		super(inpData, inpColNames);
	}

	public int getColumnCount()
	{
		return columnIdentifiers.size();
	}

	public int getRowCount()
	{
		return dataVector.size();
	}

	public String getColumnName(int col)
	{
		return (String)columnIdentifiers.elementAt(col);
	}


	/** Method:		getColumnClass(int)
	 *  Description : This method allows the determination of the default 
	 *					cell renderer/editor for each cell
	 */
	public Class getColumnClass(int c)
	{
		return getValueAt(0, c).getClass();
	}

	/** Method:		isCellEditable()
	 *  Description: 
	 *
	 */

	public boolean isCellEditable(int row, int col)
	{
		if(col == 5)
			return true;
		return false;
	}

	/** Method:		setValueAt()
	 *  Description: 
	 *
	 */
	public void setValueAt(Object value, int row, int col)
	{
		fireTableCellUpdated(row, col);
	}

}

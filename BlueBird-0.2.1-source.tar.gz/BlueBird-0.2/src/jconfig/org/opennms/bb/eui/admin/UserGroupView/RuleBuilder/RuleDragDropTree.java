//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
package org.opennms.bb.eui.admin.UserGroupView.RuleBuilder;

import java.io.*;
import java.util.Enumeration;
import java.awt.Toolkit;
import java.awt.dnd.*;
import java.awt.datatransfer.*;
import java.awt.Point;
import javax.swing.tree.*;
import javax.swing.JTree;

class RuleDragDropTree extends RuleDragTree
{
	DropTarget				m_oDropTarget;
	TreeTargetListener		m_oTargetListener;

	class TreeTargetListener implements DropTargetListener
	{
		public void drop(DropTargetDropEvent e)
		{
			try
			{
				Point					pDropLocation	= e.getLocation();
				DefaultMutableTreeNode	oTreeNode		= getTreeNode(pDropLocation);
				DataFlavor				oStringFlavor	= DataFlavor.stringFlavor;
				Transferable			oData			= e.getTransferable();

				if (oTreeNode != null && e.isDataFlavorSupported(oStringFlavor))
				{
					String oText = (String)oData.getTransferData(oStringFlavor);
					if(!((DefaultMutableTreeNode)oTreeNode.getParent()).isRoot())
					{
						Toolkit.getDefaultToolkit().beep();
						//UserManager.setStatus("Can't drop "+oText+" onto "+oTreeNode.toString());
						e.rejectDrop();
						return;
					}
					Enumeration en=oTreeNode.children();
					for(; en.hasMoreElements();)
					{
						if(en.nextElement().toString().equals(oText))
						{
							Toolkit.getDefaultToolkit().beep();
							e.rejectDrop();
							return;
						}
					}
					if((oText.indexOf("IP")==0) && (oTreeNode.toString().indexOf("IP")!=0))
					{
						Toolkit.getDefaultToolkit().beep();
						e.rejectDrop();
						return;
					}
					else if((oText.indexOf("IF")==0) && (oTreeNode.toString().indexOf("IF")!=0))
					{
						Toolkit.getDefaultToolkit().beep();
						e.rejectDrop();
						return;
					}
					else if((oText.indexOf("SN")==0) && (oTreeNode.toString().indexOf("SN")!=0))
					{
						Toolkit.getDefaultToolkit().beep();
						e.rejectDrop();
						return;
					}
					e.acceptDrop(DnDConstants.ACTION_COPY_OR_MOVE);

					/*
					 * Creat a new Node with the selected text:
					 */
					DefaultMutableTreeNode newNode = new DefaultMutableTreeNode(oText);

					/*
					 * And append it to the current tree:
					 */
					oTreeNode.add(newNode);
					((DefaultTreeModel)getModel()).reload(oTreeNode);
					e.dropComplete(true);
				}
				else
				{
					Toolkit.getDefaultToolkit().beep();
					e.rejectDrop();
				}
			}
			catch(IOException ex)
			{
				ex.printStackTrace();
			}
			catch(UnsupportedFlavorException exp)
			{
				exp.printStackTrace();
			}
		}

		public void dragEnter(DropTargetDragEvent e)
		{
			if (isDragOk(e) == false)
			{
				e.rejectDrag();
				return;
			}
			e.acceptDrag(DnDConstants.ACTION_COPY_OR_MOVE);
		}

		public void dragExit(DropTargetEvent e)
		{
		}

		public void dragOver(DropTargetDragEvent e)
		{
			Point	oDragLocation	= e.getLocation();
			TreePath	oTreePath	= getPathForLocation(oDragLocation.x,
													  oDragLocation.y);
			if (isDragOk(e) == false || oTreePath == null)
			{
				e.rejectDrag();
				return;
			}

			/*
			 * Select the node:
			 */
			setSelectionPath(oTreePath);
			e.acceptDrag(DnDConstants.ACTION_COPY_OR_MOVE);
		}

		public void dropActionChanged(DropTargetDragEvent e)
		{
			if (isDragOk(e) == false)
			{
				e.rejectDrag();
				return;
			}
			e.acceptDrag(DnDConstants.ACTION_COPY_OR_MOVE);
		}

		boolean isDragOk(DropTargetDragEvent e)
		{
			return true;
		}
	}
 
	public RuleDragDropTree(TreeNode root)
	{
		super(root);

		m_oTargetListener		= new TreeTargetListener();

		/*
		 * This tree is gonna be the drop target:
		 */
		m_oDropTarget = new DropTarget(this,
									   DnDConstants.ACTION_COPY_OR_MOVE,
									   m_oTargetListener,
									   true);
	}

	DefaultMutableTreeNode getTreeNode(Point location)
	{
		TreePath oTreePath = getPathForLocation(location.x, location.y);

		if (oTreePath != null)
		{
			return (DefaultMutableTreeNode)oTreePath.getLastPathComponent();
		}
		else
		{
			return null;
		}
	}
}

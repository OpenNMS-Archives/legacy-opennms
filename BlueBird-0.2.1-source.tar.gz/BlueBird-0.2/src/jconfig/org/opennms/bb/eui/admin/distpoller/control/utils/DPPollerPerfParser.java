//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.eui.admin.distpoller.control.utils;

import org.w3c.dom.*;

import java.io.*;
import java.util.Vector;

import org.opennms.bb.common.utils.BBParser;

/**
 * <pre> DPPollerPerfParser parses the xml stream received from the
 * poller when it is queried for the performance data
 *
 * The modules data and the creation date can be queried for using the 
 * 'get..' functions
 *
 * It throws an IOException if the xml file is not found or if it does not
 * conform to its DTD </pre>
 *
 * @author Sowmya
 *
 * Modifications:
 * 04/18/00 - Changed the parser to extend BBParser - Sowmya
 *
 */
public class DPPollerPerfParser extends BBParser
{
	Vector		modulesData;

	String		creationDate;

	/*
	 * XML TAGS that are relevant
	 */
	final String HEADER		="header";
	final String CREATED	="created";
	final String YEAR		="year";
	final String MONTH		="month";
	final String DAY		="day";
	final String HOUR		="hour";
	final String MIN		="min";
	final String SEC		="sec";

	final String MODULE		="module";
	final String MODULENAME	="moduleName";
	final String PARMS		="parms";
	final String PARM		="parm";
	final String PARM_NAME	="parmName";
	final String PARM_VALUE	="value";


	/**
	 * Constructs the DOM parser
 	 */
	public DPPollerPerfParser()
	{
		super();

		modulesData = new Vector();
	}

	protected boolean processElement(Element el,boolean isRoot)
	{
		boolean bRet = false;

		String tag = el.getTagName();

		if (tag.equals(HEADER))
		{
			m_curElement.replace(0, m_curElement.length(), HEADER);

			bRet = processHeaderElement(el);
		}

		else if (tag.equals(MODULE))
		{
			m_curElement.replace(0, m_curElement.length(), MODULE);

			bRet = processModuleElement(el);
		}

		else
		{
			boolean bNodeRet=true;

			NodeList nl = el.getChildNodes();
			int size = nl.getLength();

			for(int i = 0;i < size && bNodeRet ;i++)
				bNodeRet = processNode(nl.item(i));
			
			bRet = bNodeRet;
		}
		
		return bRet;
	}

	protected boolean processHeaderElement(Node headerNode)
	{
		boolean bRet = true;

		NodeList nl = headerNode.getChildNodes();
		int size = nl.getLength();
		for(int i = 0;i < size && bRet;i++)
		{
			Node curNode = nl.item(i);
			int  nodeType= curNode.getNodeType();

			if ( nodeType == Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();

				if(curTag.equals(CREATED))
				{
					m_curElement.replace(0, m_curElement.length(), CREATED);

					Element	hElem = (Element)curNode;

					int year  =new Integer(hElem.getAttribute(YEAR)).intValue();
					int month=new Integer(hElem.getAttribute(MONTH)).intValue() - 1;
					int day   =new Integer(hElem.getAttribute(DAY)).intValue();
					int hour  =new Integer(hElem.getAttribute(HOUR)).intValue();
					int min   =new Integer(hElem.getAttribute(MIN)).intValue();
					int sec   =new Integer(hElem.getAttribute(SEC)).intValue();

					java.util.GregorianCalendar cal= new 
								java.util.GregorianCalendar(year, month, day,
															 hour, min, sec);


					int dateStyle = java.text.DateFormat.FULL;
					int timeStyle = java.text.DateFormat.MEDIUM;

					creationDate = java.text.DateFormat.getDateTimeInstance(dateStyle, timeStyle).format(cal.getTime());

				}
			}
		}

		return bRet;
	}

	protected boolean processModuleElement(Node moduleNode)
	{
		boolean bRet = true;

		m_curElement.replace(0, m_curElement.length(), MODULE);

		Vector moduleData = new Vector();

		NodeList nl = moduleNode.getChildNodes();
		int size = nl.getLength();
		for(int i = 0;i < size && bRet;i++)
		{
			Node curNode = nl.item(i);
			int  nodeType= curNode.getNodeType();

			if ( nodeType == Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();

				if(curTag.equals(MODULENAME))
				{
					m_curElement.replace(0, m_curElement.length(), MODULENAME);

					String mname = processParmValue(curNode); 

					if (null != mname)
					{
						Vector temp=new Vector();
						temp.add(MODULENAME);
						temp.add(mname);

						moduleData.add(temp);
					}
					else
					{
						bRet = false;
						m_errNum = NULL_VALUE_ERR;
					}
				}

				else if(curTag.equals(PARMS))
				{
					m_curElement.replace(0, m_curElement.length(), PARMS);

					bRet = processModuleParms(curNode, moduleData);

					if(bRet)
					{
						modulesData.add(moduleData);
					}
				}

			}
		}

		return bRet;
	}

	protected boolean processModuleParms(Node parmsNode, Vector moduleData)
	{
		boolean bRet = true;

		NodeList nl = parmsNode.getChildNodes();
		int size = nl.getLength();

		for(int i = 0;i < size && bRet;i++)
		{
			Node curNode = nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
				if(curTag.equals(PARM))
				{
					Vector parm = processParm(curNode);
					moduleData.add(parm);
				}

			}
		}

		return bRet;
	}


	protected Vector processParm(Node parmsNode)
	{
		Vector parm = new Vector(2);

		NodeList nl = parmsNode.getChildNodes();
		int size = nl.getLength();
		for(int i = 0;i < size;i++)
		{
			Node curNode = nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
				if(curTag.equals(PARM_NAME))
				{
					String name = processParmName(curNode);

					if (null != name)
						parm.add(name);
				}
				else if(curTag.equals(PARM_VALUE))
				{
					String value = processParmValue(curNode);

					if (null != value)
						parm.add(value);
				}
			}
		}
		
		return parm;
	}

	protected String processParmName(Node parmNameNode)
	{
		String parmName=null;

		Node temp = parmNameNode.getChildNodes().item(0);
		if (temp.getNodeType() == Node.TEXT_NODE)
			parmName = ((Text)temp).getData();
		
		return parmName;
	}

	/**
	 * Returns the modules information - the data returned is a vector
	 * of vectors
	 */
	public Vector getModules()
	{
		return modulesData;
	}

	/**
	 * Returns creation date in the format <day> <month> <year> HH:MM:SS
	 */
	 public String getCreationDate()
	 {
	 	return creationDate;
	 }
}

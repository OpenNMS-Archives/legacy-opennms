//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.common.filter.validator;

import java_cup.runtime.Symbol;
import java.io.*;
import java.util.*;
import java.util.List;
import java.sql.*;

import javax.swing.*;
import javax.swing.table.*;
import javax.swing.tree.*;
import java.awt.*;
import java.awt.event.*;

import org.opennms.bb.common.filter.BBFilter;
import org.opennms.bb.common.BBConstants;
import org.opennms.bb.common.filter.xml.FilterSchemaParser;
import org.opennms.bb.common.filter.sql.FilterTable;
import org.opennms.bb.common.filter.util.BBIPAddress;
import org.opennms.bb.common.filter.exceptions.FailedParseException;
import org.opennms.bb.common.filter.exceptions.FailedSQLException;
import org.opennms.bb.common.db.DBOpenFailureException;

import org.opennms.bb.eui.admin.UserGroupView.RuleBuilder.RuleResultsDialog;
import org.opennms.bb.eui.admin.UserGroupView.RuleBuilder.RuleBuilderMain;

/**This class is used to validate a rule against the ip data
   in a database. The user can enter a rule and see the list
   of ip addresses that match that rule.

   @author <A HREF="mailto:jason@opennms.org">Jason Johns</A>
   @author <A HREF="http://www.opennms.org/">OpenNMS</A>
   @version $Revision: 1.2 $
*/
public class BBRulesValidator extends JFrame implements ActionListener
{
    /**
     */
    String operators[][] = {{";",        "Rule terminator"},
			    {" !",       "Not"},
			    {" == ",     "Equals"},
			    {" != ",     "Not equal to"},
			    {" < ",      "Less than"},
			    {" <= ",     "Less than or equal to"},
			    {" > ",      "Greater than"},
			    {" >= ",     "Greater than or equal to"},
			    {" LIKE ",   "String is like...(%_)"},
			    {" ~ ",      "String is like...(%_)"},
			    {" IPLIKE ", "IP address is like..."},
			    {"(",        "Left Paren"},
			    {")",        "Right Paren"} };
    
    /**
     */
    String logicals[][] = {{" & ", "AND"},
			   {" | ", "OR"} };

    /**
     */
    private FilterSchemaParser schema;

    /**
     */
    private JPanel rulePanel;
    private JPanel treePanel;

    /**
     */
    private JLabel label;

    /**
     */
    private JTextField text;

    /**
     */
    private JButton buttonRun;

    /**
     */
    private JButton buttonClear;

    private JButton ruleBuilderButton;

    /**
     */
    private JTable table;

    /**
     */
    private DefaultTableModel defaultModel;

    /**
     */
    private JTree columnTree;
    private JTree opTree;
    private JTextArea sqlText;

    private static String RUN_COMMAND = "Run rule";
    private static String CLEAR_COMMAND = "Clear rule";
    private static String RULE_BUILDER = "Rule builder";

    /**
     */
    public BBRulesValidator()
    {
	super("Bluebird Filter Rule Validator");

	schema = FilterSchemaParser.getInstance();
	
	//set up the upper pane containing the controls
	Container contentPane = getContentPane();
	contentPane.setLayout(new BorderLayout());

	//build the rulePane
	rulePanel = new JPanel();
	rulePanel.setLayout(new FlowLayout());
       
	label = new JLabel("Filter Rule: ");
	
	text = new JTextField(20);
	
	buttonRun = new JButton(RUN_COMMAND);
	buttonRun.addActionListener(this);

	buttonClear = new JButton(CLEAR_COMMAND);
	buttonClear.addActionListener(this);

	ruleBuilderButton = new JButton(RULE_BUILDER);
	ruleBuilderButton.addActionListener(this);

	columnTree = new JTree();

	rulePanel.add(label);
	rulePanel.add(text);
	rulePanel.add(buttonRun);
	rulePanel.add(buttonClear);
	rulePanel.add(ruleBuilderButton);
	
	contentPane.add("North", rulePanel);

	//build the treePanel
	treePanel = new JPanel();
	treePanel.setLayout(new GridLayout(1,3));

	columnTree = createColumnTree();
	opTree = createOpTree();
	sqlText = new JTextArea(50,10);
	sqlText.setLineWrap(true);
	sqlText.setEditable(false);
	
	treePanel.add(createPanel(new JLabel("Valid Columns"),columnTree));
	treePanel.add(createPanel(new JLabel("Valid Operators"),opTree));
	treePanel.add(createPanel(new JLabel("SQL Conversion"),sqlText));

	//add the result table display
	defaultModel = new DefaultTableModel();
	table = new JTable(defaultModel);
	
	defaultModel.addColumn("Numeric IP");
	defaultModel.addColumn("String IP");
	defaultModel.addColumn("Something else");

        JPanel centerPanel = new JPanel();
	centerPanel.setLayout(new GridLayout(2,1));

	centerPanel.add(treePanel);
	//centerPanel.add(new JScrollPane(table));

	contentPane.add("Center", centerPanel);
    }

    /**
     */
    private JPanel createPanel(JLabel label, JComponent component)
    {
	JPanel panel = new JPanel();
	panel.setLayout(new BorderLayout());
	
	panel.add("North", label);
	panel.add("Center", new JScrollPane(component));
	
	return panel;
    }

    /**
     */
    private JTree createColumnTree()
    {
	Hashtable tableList = new Hashtable();
	Hashtable tables = new Hashtable();
	
	tableList = schema.getTables();

	//get an iterator on the tableList hashtable
	//get an iterator over all of the keys, which are the column names
	Iterator i = tableList.keySet().iterator();

	//loop over all keys and put each into the tables hash along with
	//the column name hash
	while(i.hasNext())
	{
	    String tableName = (String)i.next();
	    tables.put(tableName, ((FilterTable)tableList.get(tableName)).getColumnsHash());
	}

	JTree tree = new JTree(tables);
	
	tree.addMouseListener(new ValidatorMouseListener());

	return tree;
    }

    /**
     */
    private class ValidatorMouseListener extends MouseAdapter
    {
	/**
	 */
	public void mousePressed(MouseEvent e)
	{
	    if(e.getClickCount() == 2)
	    {
		if (e.getSource() instanceof JTree)
	        {
		    handleTree(e);
		}
		else 
		{
		    handleList(e);
		}
	    }
	}
    

	/**
	 */
	private void handleTree(MouseEvent e)
	{
	    JTree jtree = (JTree)e.getSource();

	    int clickedRow = jtree.getRowForLocation(e.getX(), e.getY());
	    
	    if(clickedRow != -1)
	    {
		TreePath treepath = jtree.getPathForRow(clickedRow);
		TreeNode treenode = (TreeNode)treepath.getLastPathComponent();
		
		//if I've double clicked on a leaf node add it to the rule
		if (treenode.isLeaf())
		{
		    text.setText(text.getText() + treenode.toString() + " ");
		}
	    }
	}

	/**
	 */
	private void handleList(MouseEvent e)
	{
	    JList jlist = (JList)e.getSource();
	    
	    text.setText(text.getText() + jlist.getSelectedValue());
	}
    }

    /**
     */
    private JTree createOpTree()
    {
	Hashtable operations = new Hashtable();
	Hashtable compList = new Hashtable();
	Hashtable logList = new Hashtable();
	
	for(int i = 0; i < operators.length; i++)
	{
	    compList.put(operators[i][0], operators[i][1]);
	}

	operations.put("Comparisions", compList);

        for(int i = 0; i < logicals.length; i++)
	{
	    logList.put(logicals[i][0], logicals[i][1]);
	}

	operations.put("Logicals", logList);

	JTree tree = new JTree(operations);

	tree.addMouseListener(new ValidatorMouseListener());
	
	return tree;
    }
    
    /**
     */
    public void actionPerformed(ActionEvent e)
    {
	if (e.getActionCommand().equals(RUN_COMMAND))
	{
	    executeRunCommand();
	}
	else if (e.getActionCommand().equals(CLEAR_COMMAND))
	{
	    executeClearCommand();
	}
	else if (e.getActionCommand().equals(RULE_BUILDER))
	{
	    executeRuleBuilder();
	}
    }

    /**
     */
    private void executeRuleBuilder()
    {
	//(new RuleBuilderMain("")).setVisible(true);
    }

    /**
     */
    private void executeClearCommand()
    {
	text.setText("");
    }

    /**
     */
    private void executeRunCommand()
    {
	(new RuleResultsDialog(true, "Results", text.getText())).setVisible(true);

	/*
	try
	{
	    //delete any rows that were in the table prior
	    for(int oldRow = defaultModel.getRowCount()-1; oldRow >= 0; oldRow--)
	    {
		defaultModel.removeRow(oldRow);
	    }
	    
	    List list = null;
	
	    //run the rule
	    BBFilter filter = new BBFilter();
	    
	    //get the ip list
	    list = filter.getIPList(text.getText());
	    
	    //display sql statement on screen
	    sqlText.setText(filter.getSQLStatement());

	    Vector data = null;
	    
	    for (int row = 0; row < list.size(); row++)
	    {
		data = new Vector();
		
		data.add(0, list.get(row));
		data.add(1, BBIPAddress.getIpAsOctetString(Integer.parseInt((String)list.get(row))));
		
		defaultModel.addRow(data);
	    }
	}
	catch(DBOpenFailureException e)
	{
	    sqlText.setText("couldn't open database " + e);
	}
	catch(FailedParseException e)
	{
	    sqlText.setText(e.toString());
	    }*/
    }

    /**
     */
    public static void main(String args[])
    {
	try
	{
	    //load the property file for the rest of the module to use
	    FileInputStream propFile = new FileInputStream(BBConstants.PROPERTY_FILE);
	    Properties p = new Properties(System.getProperties());
	    p.load(propFile);        
	    
	    // set the system properties
	    System.setProperties(p);
	}
	catch(IOException e)
	{
	    System.out.println(e);
	}
	
	
	JFrame f = new BBRulesValidator();
	
	f.setBounds(100,100,800,700);
	f.setVisible(true);
    }
}

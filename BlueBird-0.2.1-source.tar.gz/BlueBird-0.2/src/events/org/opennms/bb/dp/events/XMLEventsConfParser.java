//
// Copyright (C) 2000 N*Manage Company, Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
// $Id: XMLEventsConfParser.java,v 1.3 2000/11/10 05:18:10 weave Exp $
//
//
package org.opennms.bb.dp.events;

import java.io.*;
import java.util.*;

import org.xml.sax.*;
import org.apache.xerces.parsers.SAXParser;
//import org.apache.soap.sax.SAXParser;

/**
 * <P>The XMLEventsConfParser is a SAX based parser used to decompose an
 * event configuration stream into the corresponding event base classes. The class provides
 * realitivly strong structure checking, but does not require and/or parse
 * an DTD that may proceed the data. This allows the parser to be used with
 * a SAX based SOAP parser, since SOAP prohibits the used of DTDs.</P>
 *
 *
 * @author 	<A HREF="mailto:sowmya@opennms.org">Sowmya Kumaraswamy</A>
 * @author	<A HREF="mailto:weave@opennms.org">Brian Weaver</A>
 * @author	<A HREF="http://www.opennms.org">OpenNMS.org</A>
 *
 * @version	$Revision: 1.3 $
 */
public class XMLEventsConfParser implements ContentHandler, ErrorHandler
{
	/*
	 * Relevant XML TAGS
	 */
	final static String TAG_EVENTS				= XMLEventsParser.TAG_EVENTS;
	final static String TAG_GLOBAL				= "global";
	final static String TAG_SECURITY			= "security";
	final static String TAG_DONOTOVERRIDE			= "doNotOverride";
	final static String TAG_EVENT				= XMLEventsParser.TAG_EVENT;
	final static String TAG_UEI				= XMLEventsParser.TAG_UEI;
	final static String TAG_SNMP				= XMLEventsParser.TAG_SNMP;
	final static String TAG_EID				= XMLEventsParser.TAG_EID;
	final static String TAG_EIDTEXT				= XMLEventsParser.TAG_EIDTEXT;
	final static String TAG_SPECIFIC			= XMLEventsParser.TAG_SPECIFIC;
	final static String TAG_GENERIC				= XMLEventsParser.TAG_GENERIC;
	final static String TAG_DESCR				= XMLEventsParser.TAG_DESCR;
	final static String TAG_LOGMSG				= XMLEventsParser.TAG_LOGMSG;
	final static String TAG_LOGMSGDEST			= XMLEventsParser.TAG_LOGMSGDEST;
	final static String TAG_LOGMSGDEST_ATTR_SUPPRESS	= XMLEventsParser.TAG_LOGMSGDEST_ATTR_SUPPRESS;
	final static String TAG_LOGMSGDEST_ATTR_LOGONLY		= XMLEventsParser.TAG_LOGMSGDEST_ATTR_LOGONLY;
	final static String TAG_LOGMSGDEST_ATTR_LOGNDISPLAY	= XMLEventsParser.TAG_LOGMSGDEST_ATTR_LOGNDISPLAY;
	final static String TAG_SEVERITY			= XMLEventsParser.TAG_SEVERITY;
	final static String TAG_OPERINSTR			= XMLEventsParser.TAG_OPERINSTR;
	final static String TAG_AUTOACTION			= XMLEventsParser.TAG_AUTOACTION;
	final static String TAG_OPERACTION			= XMLEventsParser.TAG_OPERACTION;
	final static String TAG_OPERACTIONMENU			= XMLEventsParser.TAG_OPERACTIONMENU;
	final static String TAG_LOGGROUP			= XMLEventsParser.TAG_LOGGROUP;
	final static String TAG_NOTIFICATION			= XMLEventsParser.TAG_NOTIFICATION;
	final static String TAG_TTICKET				= XMLEventsParser.TAG_TTICKET;
	final static String TAG_STATE				= XMLEventsParser.TAG_STATE;
	final static String TAG_STATE_ATTR_ON			= XMLEventsParser.TAG_STATE_ATTR_ON;
	final static String TAG_STATE_ATTR_OFF			= XMLEventsParser.TAG_STATE_ATTR_OFF;
	final static String TAG_FORWARD				= XMLEventsParser.TAG_FORWARD;
	final static String TAG_MECHANISM			= XMLEventsParser.TAG_MECHANISM;
	final static String TAG_MECHANISM_ATTR_SNMPUDP		= XMLEventsParser.TAG_MECHANISM_ATTR_SNMPUDP;
	final static String TAG_MECHANISM_ATTR_SNMPTCP		= XMLEventsParser.TAG_MECHANISM_ATTR_SNMPTCP;
	final static String TAG_MECHANISM_ATTR_XMLUDP		= XMLEventsParser.TAG_MECHANISM_ATTR_XMLUDP;
	final static String TAG_MECHANISM_ATTR_XMLTCP		= XMLEventsParser.TAG_MECHANISM_ATTR_XMLTCP;
	final static String TAG_MOUSEOVERTEXT			= XMLEventsParser.TAG_MOUSEOVERTEXT;
	
	/*
	 * Relavant save tags that contain depth
	 * and information processing. There should be 
	 * one tag per String tag from the above seection.
	 */
	private static final int SAVE_IGNORE 		= 0x00000080;
	private static final int SAVE_EVENTS		= 1 | SAVE_IGNORE;
	
	private static final int SAVE_GLOBAL		= (1 << 8) | 2 | SAVE_IGNORE;
	private static final int SAVE_SECURITY		= (2 << 8) | 3 | SAVE_IGNORE;
	private static final int SAVE_DONOTOVERRIDE	= (3 << 8) | 4;
	
	private static final int SAVE_EVENT		= (1 << 8) | 8 | SAVE_IGNORE;
	private static final int SAVE_UEI		= (2 << 8) | 9;
	private static final int SAVE_SNMP		= (2 << 8) | 14 | SAVE_IGNORE;
	private static final int SAVE_SNMP_EID		= (3 << 8) | 15;
	private static final int SAVE_SNMP_EIDTEXT	= (3 << 8) | 16;
	private static final int SAVE_SNMP_SPECIFIC	= (3 << 8) | 17;
	private static final int SAVE_SNMP_GENERIC	= (3 << 8) | 18;
	private static final int SAVE_DESCR		= (2 << 8) | 23;
	private static final int SAVE_LOGMSG		= (2 << 8) | 24;
	private static final int SAVE_SEVERITY		= (2 << 8) | 25;
	private static final int SAVE_OPERINSTRUCT	= (2 << 8) | 26;
	private static final int SAVE_AUTOACTION	= (2 << 8) | 27;
	private static final int SAVE_OPERACTION	= (2 << 8) | 28;
	private static final int SAVE_LOGGROUP		= (2 << 8) | 29;
	private static final int SAVE_NOTIFICATION	= (2 << 8) | 30;
	private static final int SAVE_TTICKET		= (2 << 8) | 31;
	private static final int SAVE_FORWARD		= (2 << 8) | 32;
	private static final int SAVE_MOUSEOVERTEXT	= (2 << 8) | 33;	

	/**
	 * The buffer where subsequent textual information from the
	 * character() method are appendedd. This is normally cleared
	 * after each call to endElement. If an element will contain
	 * both textual information and sub-elements then this should
	 * be modified to behave like a stack.
	 */
	private StringBuffer	m_data;
	
	/**
	 * The save buffer stack. The m_depth member is used to 
	 * as the TOS pointer for accesing the save states.
	 */
	private int[] 		m_save;
	
	/**
	 * The current depth of the elements in the document 
	 * and the TOS for the m_save member.
	 */
	private int 		m_depth;
	
	/**
	 * The header recovered from the event stream
	 */
	private List		m_overrides;
	
	/**
	 * The list of events from the stream, this is a
	 * list of EventBase objects!
	 */
	private List		m_events;
	
	/**
	 * The event being currently processes
	 */
	private EventBase	m_event;	// the last event created on startElement("event")
	
	/**
	 * An snmp information block. This is valid between &lt;snmp&gt;...&lt;/snmp&gt;
	 */
	private EventSnmpInfo	m_snmpInfo;	// snmp info created on startElement("snmp")
	
	/**
	 * The last attributes elements passed to the startElement()
	 * method. If Attributes are need for post processing, but the
	 * element to be post processed has subelements, then a stack based
	 * approach MUST be used!
	 */
	private Attributes	m_attributes;	// last attributes from startElement()
	
	/**
	 * Returns the depth of a particular SAVE_???
	 * tag.
	 *
	 * @param token		The tag to return depth information from.
	 *
	 * @return The depth of the tag.
	 */
	private int depthOf(int token)
	{
		return (token >> 8);
	}
	
	/** 
	 * <P>Used to validate the event before it is placed onto the 
	 * actual list of events. If the method returns true then
	 * the event is added to the list. If the method returns
	 * false then it is not added to the list.</P>
	 *
	 * <P>Additionally, the method is able to modify the values contained
	 * in the event if necessary, prior to the event being added to the
	 * list of events. Care should be used by all derived classes that
	 * implement this behavior.</P>
	 *
	 * @param e	The event to validate
	 *
	 * @return True if the event is valid, false if it should be discarded
	 * 	by the parser.
	 *
	 */
	protected boolean validate(EventBase e)
	{
		return true;
	}

	/**
	 * Constructs a new default instance of the parser
	 * that can be registered with a SAXParser.
	 */
	public XMLEventsConfParser()
	{
		m_data = new StringBuffer();
		m_save = new int[8];
		m_depth= 0;
		
		m_events     = null;
		m_event      = null;
		m_snmpInfo   = null;
		m_attributes = null;
		m_overrides  = null;
	}
	
	/**
	 * Sets the document locator.
	 *
	 * @param loc	The document locator.
	 */
	public void setDocumentLocator(Locator loc)
	{
		// do nothing;
	}
	
	/**
	 * Called when the document parsing is beginning.
	 *
	 * @exception org.xml.sax.SAXException Thrown if an error occurs
	 * 	processing the start of the document.
	 *
	 */
	public void startDocument() 
		throws SAXException
	{
		if(m_data.length() > 0)
			m_data.delete(0, m_data.length());
		
		m_depth = 0;
		m_save[0] = SAVE_IGNORE;
		
		m_overrides = null;
		m_events = null;
		m_event  = null;
		m_snmpInfo = null;
		m_attributes = null;
	}
	
	/**
	 * Called when the end of the document is reached.
	 *
	 * @throws org.xml.sax.SAXException Thrown if an error occurs
	 * 	validating the document semantics.
	 *
	 */
	public void endDocument() 
		throws SAXException
	{
		if(m_events.isEmpty())
			throw new SAXException("Invalid message, no events present");
	}
	
	/**
	 * Called when a new element is encountered in the document.
	 *
	 * @param uri		The namespace of the element.
	 * @param localName	The unqualified name of the element.
	 * @param qName		The qualified name of the element.
	 * @param attrs		The attributes for the element.
	 *
	 * @throws org.xml.sax.SAXException Thrown if an error occurs processing
	 * 	the element.
	 *
	 */
	public void startElement(String uri, String localName, String qName, Attributes attrs)
		throws SAXException
	{
		//
		// Save the current attributes
		//
		m_attributes = attrs;
		
		//
		// check the local name
		//
		if(localName.equals(TAG_EVENTS) && m_depth == depthOf(SAVE_EVENTS))
		{
			m_save[m_depth] = SAVE_EVENTS;
			m_events = new ArrayList();
		}
		else if(localName.equals(TAG_GLOBAL) && m_depth == depthOf(SAVE_GLOBAL))
		{
			m_save[m_depth] = SAVE_GLOBAL;
		}
		else if(localName.equals(TAG_SECURITY) && m_depth == depthOf(SAVE_SECURITY))
		{
			m_save[m_depth] = SAVE_SECURITY;
			m_overrides = new ArrayList();
		}
		else if(localName.equals(TAG_DONOTOVERRIDE) && m_depth == depthOf(SAVE_DONOTOVERRIDE))
		{
			m_save[m_depth] = SAVE_DONOTOVERRIDE;
		}
		else if(localName.equals(TAG_EVENT) && m_depth == depthOf(SAVE_EVENT))
		{
			m_save[m_depth] = SAVE_EVENT;
			m_event = new EventBase();
		}
		else if(localName.equals(TAG_UEI) && m_depth == depthOf(SAVE_UEI))
		{
			m_save[m_depth] = SAVE_UEI;
		}
		else if(localName.equals(TAG_SNMP) && m_depth == depthOf(SAVE_SNMP))
		{
			m_save[m_depth] = SAVE_SNMP;
			m_snmpInfo = new EventSnmpInfo();
		}
		else if(localName.equals(TAG_EID) && m_depth == depthOf(SAVE_SNMP_EID))
		{
			m_save[m_depth] = SAVE_SNMP_EID;
		}
		else if(localName.equals(TAG_EIDTEXT) && m_depth == depthOf(SAVE_SNMP_EIDTEXT))
		{
			m_save[m_depth] = SAVE_SNMP_EIDTEXT;
		}
		else if(localName.equals(TAG_SPECIFIC) && m_depth == depthOf(SAVE_SNMP_SPECIFIC))
		{
			m_save[m_depth] = SAVE_SNMP_SPECIFIC;
		}
		else if(localName.equals(TAG_GENERIC) && m_depth == depthOf(SAVE_SNMP_GENERIC))
		{
			m_save[m_depth] = SAVE_SNMP_GENERIC;
		}
		else if(localName.equals(TAG_DESCR) && m_depth == depthOf(SAVE_DESCR))
		{
			m_save[m_depth] = SAVE_DESCR;
		}
		else if(localName.equals(TAG_LOGMSG) && m_depth == depthOf(SAVE_LOGMSG))
		{
			m_save[m_depth] = SAVE_LOGMSG;
		}
		else if(localName.equals(TAG_SEVERITY) && m_depth == depthOf(SAVE_SEVERITY))
		{
			m_save[m_depth] = SAVE_SEVERITY;
		}
		else if(localName.equals(TAG_OPERINSTR) && m_depth == depthOf(SAVE_OPERINSTRUCT))
		{
			m_save[m_depth] = SAVE_OPERINSTRUCT;
		}
		else if(localName.equals(TAG_AUTOACTION) && m_depth == depthOf(SAVE_AUTOACTION))
		{
			m_save[m_depth] = SAVE_AUTOACTION;
		}
		else if(localName.equals(TAG_OPERACTION) && m_depth == depthOf(SAVE_OPERACTION))
		{
			m_save[m_depth] = SAVE_OPERACTION;
		}
		else if(localName.equals(TAG_LOGGROUP) && m_depth == depthOf(SAVE_LOGGROUP))
		{
			m_save[m_depth] = SAVE_LOGGROUP;
		}
		else if(localName.equals(TAG_NOTIFICATION) && m_depth == depthOf(SAVE_NOTIFICATION))
		{
			m_save[m_depth] = SAVE_NOTIFICATION;
		}
		else if(localName.equals(TAG_TTICKET) && m_depth == depthOf(SAVE_TTICKET))
		{
			m_save[m_depth] = SAVE_TTICKET;
		}
		else if(localName.equals(TAG_FORWARD) && m_depth == depthOf(SAVE_FORWARD))
		{
			m_save[m_depth] = SAVE_FORWARD;
		}
		else if(localName.equals(TAG_MOUSEOVERTEXT) && m_depth == depthOf(SAVE_MOUSEOVERTEXT))
		{
			m_save[m_depth] = SAVE_MOUSEOVERTEXT;
		}
		else
		{
			throw new SAXException("Invalid tag(" + localName + ") or document format");
		}
		
		m_depth++;
	}
		
	/**
	 * At the end of the element store the current element buffer value
	 * to the appropriate buffer.
	 *
	 * Reset all the buffers at the end of each event
	 *
	 * @exception org.xml.sax.SAXException Thrown if there is an error during parse
	 */
	public void endElement(String uri, String localName, String qName) 
		throws SAXException
	{
		--m_depth;	// pop one off the depth counter!
		switch(m_save[m_depth])
		{			
		case SAVE_EVENTS:
			if(!localName.equals(TAG_EVENTS))
				throw new SAXException("Invalid closing tag");
			break;
			
		case SAVE_GLOBAL:
			if(!localName.equals(TAG_GLOBAL))
				throw new SAXException("Invalid closing tag");
			break;

		case SAVE_SECURITY:
			if(!localName.equals(TAG_SECURITY))
				throw new SAXException("Invalid closing tag");
			if(m_overrides.isEmpty())
				throw new SAXException("Invalid document, security defined but there was no enclosed information");
			break;
			
		case SAVE_DONOTOVERRIDE:
			if(!localName.equals(TAG_DONOTOVERRIDE))
				throw new SAXException("Invalid closing tag");
			m_overrides.add(m_data.toString().trim());
			break;
			
		case SAVE_EVENT:
			if(!localName.equals(TAG_EVENT))
				throw new SAXException("Invalid closing tag");
			if(!m_event.hasUEI() || !m_event.hasDescription() || 
			   !m_event.hasLogMessage() || !m_event.hasSeverity())
			{
				throw new SAXException("The event configuration is not valid, missing required value");
			}
			
			if(validate(m_event))
				m_events.add(m_event);
			m_event = null;
			break;
			
		case SAVE_UEI:
			if(!localName.equals(TAG_UEI))
				throw new SAXException("Invalid closing tag");
			
			m_event.setUEI(m_data.toString().trim());
			break;
			
		case SAVE_SNMP:
			if(!localName.equals(TAG_SNMP))
				throw new SAXException("Invalid closing tag");
			
			m_event.setSnmpInfo(m_snmpInfo);
			m_snmpInfo = null;
			break;
			
		case SAVE_SNMP_EID:
			if(!localName.equals(TAG_EID))
				throw new SAXException("Invalid closing tag");
			
			m_snmpInfo.setEnterpriseID(m_data.toString().trim());
			break;
			
		case SAVE_SNMP_EIDTEXT:
			if(!localName.equals(TAG_EIDTEXT))
				throw new SAXException("Invalid closing tag");
			
			m_snmpInfo.setEnterpriseText(m_data.toString().trim());
			break;
			
		case SAVE_SNMP_SPECIFIC:
			if(!localName.equals(TAG_SPECIFIC))
				throw new SAXException("Invalid closing tag");
				
			try
			{
				m_snmpInfo.setSpecific(Integer.parseInt(m_data.toString().trim()));
			}
			catch(NumberFormatException ne)
			{
				throw new SAXException("Malformed data in document, NumberFormatException caught");
			}
			break;
			
		case SAVE_SNMP_GENERIC:
			if(!localName.equals(TAG_GENERIC))
				throw new SAXException("Invalid closing tag");
			
			try
			{
				m_snmpInfo.setGeneric(Integer.parseInt(m_data.toString().trim()));
			}
			catch(NumberFormatException ne)
			{
				throw new SAXException("Malformed data in document, NumberFormatException caught");
			}
			break;
			
		case SAVE_DESCR:
			if(!localName.equals(TAG_DESCR))
				throw new SAXException("Invalid closing tag");
			
			m_event.setDescription(m_data.toString().trim());
			break;
			
		case SAVE_LOGMSG:
			if(!localName.equals(TAG_LOGMSG))
				throw new SAXException("Invalid closing tag");
			
			EventLogMessage logmsg = new EventLogMessage(m_data.toString().trim());
			for(int i = 0; i < m_attributes.getLength(); i++)
			{
				if(m_attributes.getLocalName(i).equals(TAG_LOGMSGDEST))
				{
					if(m_attributes.getValue(i).equals(TAG_LOGMSGDEST_ATTR_SUPPRESS))
						logmsg.setLogOption(EventLogMessage.SUPPRESS);
					else if(m_attributes.getValue(i).equals(TAG_LOGMSGDEST_ATTR_LOGONLY))
						logmsg.setLogOption(EventLogMessage.LOGONLY);
					else if(m_attributes.getValue(i).equals(TAG_LOGMSGDEST_ATTR_LOGNDISPLAY))
						logmsg.setLogOption(EventLogMessage.LOGNDISPLAY);
					else
						throw new SAXException("Illegal attribute value");
				}
				else
				{
					throw new SAXException("Illegal attribute on element");
				}
			}
			m_event.setLogMessage(logmsg);
			break;
			
		case SAVE_SEVERITY:
			if(!localName.equals(TAG_SEVERITY))
				throw new SAXException("Invalid closing tag");
			
			m_event.setSeverity(m_data.toString().trim());
			break;
			
		case SAVE_OPERINSTRUCT:
			if(!localName.equals(TAG_OPERINSTR))
				throw new SAXException("Invalid closing tag");
			
			m_event.setOperatorInstruction(m_data.toString().trim());
			break;
			
		case SAVE_AUTOACTION:
			if(!localName.equals(TAG_AUTOACTION))
				throw new SAXException("Invalid closing tag");
			
			m_event.addAutoAction(m_data.toString().trim());
			break;
			
		case SAVE_OPERACTION:
			if(!localName.equals(TAG_OPERACTION))
				throw new SAXException("Invalid closing tag");
			
			EventOperatorAction operaction = new EventOperatorAction(m_data.toString().trim());
			boolean bFoundAttr = false;
			for(int i = 0; i < m_attributes.getLength(); i++)
			{
				if(m_attributes.getLocalName(i).equals(TAG_OPERACTIONMENU))
				{
					operaction.setMenuText(m_attributes.getValue(i).trim());
					bFoundAttr = true;
				}
				else
				{
					throw new SAXException("Illegal attribute on element");
				}
			}
			if(!bFoundAttr)
				throw new SAXException("Missing required attributed on element");
				
			m_event.addOperatorAction(operaction);
			break;
			
		case SAVE_LOGGROUP:
			if(!localName.equals(TAG_LOGGROUP))
				throw new SAXException("Invalid closing tag");
			
			m_event.addLogGroup(m_data.toString().trim());
			break;
			
		case SAVE_NOTIFICATION:
			if(!localName.equals(TAG_NOTIFICATION))
				throw new SAXException("Invalid closing tag");
			
			m_event.addNotification(m_data.toString().trim());
			break;
			
		case SAVE_TTICKET:
			if(!localName.equals(TAG_TTICKET))
				throw new SAXException("Invalid closing tag");
			
			EventTroubleTicket tticket = new EventTroubleTicket(m_data.toString().trim());
			for(int i = 0; i < m_attributes.getLength(); i++)
			{
				if(m_attributes.getLocalName(i).equals(TAG_STATE))
				{
					if(m_attributes.getValue(i).equals(TAG_STATE_ATTR_ON))
						tticket.setState(EventTroubleTicket.STATE_ON);
					else if(m_attributes.getValue(i).equals(TAG_STATE_ATTR_OFF))
						tticket.setState(EventTroubleTicket.STATE_OFF);
					else
						throw new SAXException("Illegal attribute value");
				}
				else
				{
					throw new SAXException("Illegal attribute on element");
				}
			}
			m_event.setTroubleTicket(tticket);
			break;
			
		case SAVE_FORWARD:
			if(!localName.equals(TAG_FORWARD))
				throw new SAXException("Invalid closing tag");
			
			EventForward fwd = new EventForward(m_data.toString().trim());
			for(int i = 0; i < m_attributes.getLength(); i++)
			{
				if(m_attributes.getLocalName(i).equals(TAG_STATE))
				{
					if(m_attributes.getValue(i).equals(TAG_STATE_ATTR_ON))
						fwd.setState(EventForward.STATE_ON);
					else if(m_attributes.getValue(i).equals(TAG_STATE_ATTR_OFF))
						fwd.setState(EventForward.STATE_OFF);
					else
						throw new SAXException("Illegal attribute value");
				}
				else if(m_attributes.getLocalName(i).equals(TAG_MECHANISM))
				{
					if(m_attributes.getValue(i).equals(TAG_MECHANISM_ATTR_SNMPUDP))
						fwd.setForwardType(EventForward.FWD_SNMP_UDP);
					else if(m_attributes.getValue(i).equals(TAG_MECHANISM_ATTR_SNMPTCP))
						fwd.setForwardType(EventForward.FWD_SNMP_TCP);
					else if(m_attributes.getValue(i).equals(TAG_MECHANISM_ATTR_XMLUDP))
						fwd.setForwardType(EventForward.FWD_XML_TCP);
					else if(m_attributes.getValue(i).equals(TAG_MECHANISM_ATTR_XMLTCP))
						fwd.setForwardType(EventForward.FWD_XML_UDP);
					else
						throw new SAXException("Illegal attribute value");
				}
				else
				{
					throw new SAXException("Illegal attribute on element");
				}
			}
			//
			// save to event
			//
			m_event.addForward(fwd);
			break;
			
		case SAVE_MOUSEOVERTEXT:
			if(!localName.equals(TAG_MOUSEOVERTEXT))
				throw new SAXException("Invalid closing tag");
			
			m_event.setMouseOverText(m_data.toString().trim());
			break;
		
		default:
			throw new SAXException("Unknown closing tag encountered");
		}
		
		//
		// clear out the buffer
		//
		if(m_data.length() > 0)
			m_data.delete(0, m_data.length());
	}

	/**
	 * Store the characters of the current element in the current element
	 * value buffer
	 *
	 * @exception org.xml.sax.SAXException if there is an error during parse
	 */
	public void characters(char[] data, int offset, int length)
		throws SAXException
	{
		if((m_save[m_depth-1] & SAVE_IGNORE) != SAVE_IGNORE)
			m_data.append(data, offset, length);
	}
	
	/**
	 * Ignore the whitespaces
	 *
	 * @exception org.xml.sax.SAXException if there is an error during parse
	 */
	public void ignorableWhitespace(char[] data, int offset, int length)
		throws SAXException
	{
		// do like the method says.... ignore!
	}
	
	/**
	 * Receives processing instructions
	 *
	 * @param target	The target of the processing instruction.
	 * @param data		The processing data.
	 *
	 * @exception org.xml.sax.SAXException	Thrown if an an error occurs
	 * 	during processing
	 */
	public void processingInstruction(String target, String data)
		throws SAXException
	{
		// do nothing
	}
	
	/**
	 * Recieves notification of a skipped entity.
	 *
	 * @param name		The name of the skipped entity.
	 *
	 * @exception org.xml.sax.SAXException	Thrown if an an error occurs
	 * 	during processing
	 */
	public void skippedEntity(String name)
		throws SAXException
	{
		// do nothing
	}
	
	/**
	 * Starts a prefix to URI mapping.
	 *
	 * @param prefix	The prefix.
	 * @param uri		The namespace mapping.
	 *
	 * @exception org.xml.sax.SAXException	Thrown if an an error occurs
	 * 	during processing
	 */
	public void startPrefixMapping(String prefix, String uri)
		throws SAXException
	{
		// do nothing
	}
	
	/**
	 * Ends a prefix to URI mapping.
	 *
	 * @param prefix 	The prefix that is ending
	 *
	 * @exception org.xml.sax.SAXException	Thrown if an an error occurs
	 * 	during processing
	 */
	public void endPrefixMapping(String prefix)
		throws SAXException
	{
		// do nothing
	}
	
	/**
	 * Throw an exception if there is a warning during parse
	 *
	 * @exception org.xml.sax.SAXException if there is an error during parse
	 */
	public void warning(SAXParseException ex)
		throws SAXException
	{
		throw ex;
	}

	/**
	 * Throw an exception if there is an error during parse
	 *
	 * @exception org.xml.sax.SAXException if there is an error during parse
	 */
	public void error(SAXParseException ex)
		throws SAXException
	{
		throw ex;
	}

	/**
	 * Throw an exception if there is a fatal error during parse
	 *
	 * @exception org.xml.sax.SAXException if there is an error during parse
	 */
	public void fatalError(SAXParseException ex)
		throws SAXException
	{
		throw ex;
	}

	/** 
	 * Returns the list of events that must be overridden
	 * by the event daemon. These fields are considered non
	 * modifiable by the local administrator.
	 *
	 * @return The list of non-modifiable tags. If there are
	 * 	no tags then a null is returned, or an empty list.
	 */
	public List getOverrides()
	{
		return m_overrides;
	}
	
	/**
	 * Return the events from the parsed stream. The
	 * events are instances of the EventBase object.
	 *
	 * @return the events in the stream
	 */
	public List getEvents()
	{
		return m_events;
	}
	
	/**
	 * Generates a document confomant to this parser from the 
	 * passed events.
	 *
	 * @param out		The output stream
	 * @param overrides	The list of overrides
	 * @param events	The list of events to be written.
	 */
	public static void serializeToXML(OutputStream out, List overrides, List events)
	{
		serializeToXML(new PrintStream(out), overrides, events);
	}
	
	/**
	 * Generates a document confomant to this parser from the 
	 * passed events.
	 *
	 * @param out		The output stream
	 * @param overrides	The list of overrides.
	 * @param events	The list of events to be written.
	 */
	public static void serializeToXML(PrintStream out, List overrides, List events)
	{
		if(overrides == null || overrides.isEmpty() || events == null || events.isEmpty())
			throw new IllegalArgumentException("The passed parameters will not generate a conformant document");
			
		XMLEventsParser.startElement(out, TAG_EVENTS, null);
		XMLEventsParser.startElement(out, TAG_GLOBAL, null);
		XMLEventsParser.startElement(out, TAG_SECURITY, null);
		Iterator iter = overrides.iterator();
		while(iter.hasNext())
			XMLEventsParser.dataElement(out, TAG_DONOTOVERRIDE, null, (String)(iter.next()));
		XMLEventsParser.endElement(out, TAG_SECURITY);
		XMLEventsParser.endElement(out, TAG_GLOBAL);
		
		iter = events.iterator();
		while(iter.hasNext())
		{
			((EventBase)iter.next()).serializeToXML(out);
		}
		XMLEventsParser.endElement(out, TAG_EVENTS);
	}
	
	/**
	 * Generates a document confomant to this parser from the 
	 * passed events.
	 *
	 * @param out		The output stream
	 * @param events	The list of events to be written.
	 */
	public static void serializeToXML(OutputStream out, List events)
	{
		serializeToXML(new PrintStream(out), events);
	}
	
	/**
	 * Generates a document confomant to this parser from the 
	 * passed events.
	 *
	 * @param out		The output stream
	 * @param events	The list of events to be written.
	 */
	public static void serializeToXML(PrintStream out, List events)
	{
		if(events == null || events.isEmpty())
			throw new IllegalArgumentException("The passed parameters will not generate a conformant document");
			
		XMLEventsParser.startElement(out, TAG_EVENTS, null);
		Iterator iter = events.iterator();
		while(iter.hasNext())
		{
			((EventBase)iter.next()).serializeToXML(out);
		}
		XMLEventsParser.endElement(out, TAG_EVENTS);
	}
	
	/**
	 * used for debugging
	 */
	public static void main(String[] args)
	{
		SAXParser		sp = new SAXParser();
		XMLEventsConfParser	xmlep = new XMLEventsConfParser();
		
		sp.setContentHandler(xmlep);
		sp.setErrorHandler(xmlep);
		
		for(int i = 0; i < args.length; i++)
		{
			try
			{
				sp.parse(new InputSource(new FileInputStream(args[i])));
				System.out.println("File " + args[i] + " parsed ok!");
				System.out.println(" There were " + xmlep.getEvents().size() + " events");
				System.out.println(" Serializing back to XML");
				
				List events = xmlep.getEvents();
				List overrides = xmlep.getOverrides();
				
				if(overrides != null && !overrides.isEmpty())
					XMLEventsConfParser.serializeToXML(System.out,overrides,events);
				else
					XMLEventsConfParser.serializeToXML(System.out,events);
			}
			catch(Exception e)
			{
				System.out.println("File " + args[i] + " encountered errors");
				System.out.println(e.getMessage());
				e.printStackTrace();
			}
		}
	}
}


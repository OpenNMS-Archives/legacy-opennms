//
// Copyright (C) 2000 N*Manage Company, Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
// $Id: EventAttributeStateOnOff.java,v 1.4 2000/11/10 05:18:10 weave Exp $
//
package org.opennms.bb.dp.events;

import java.lang.*;
import java.io.Serializable;

/**
 * This class is designed to be subclassed by both the EventTroubleTicket
 * and EventForward object, both of which have state on/off information.
 * The class is not designed to be instantiated by itself and thus its
 * constructors are all protected for use by the derived classes.
 *
 * @author <A HREF="mailto:weave@opennms.org">Brian Weaver</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version CVS $Revision: 1.4 $
 *
 */
public class EventAttributeStateOnOff implements Serializable
{
	/**
	 * The value that defines the state of the instance as on.
	 */
	public static final int		STATE_ON = 0;
	
	/**
	 * The value that defines the state of the instance as off.
	 */
	public static final int		STATE_OFF= 1;
	
	/**
	 * The state of the instance.
	 */
	protected int	m_state;
	
	/**
	 * Constructs a new instance with the default values.
	 * The default state is set to &quot;on&quot;.
	 *
	 */
	protected EventAttributeStateOnOff()
	{
		m_state = STATE_ON;
	}
	
	/**
	 * Constructs a new instance with the specified state.
	 * 
	 * @param state		The state for the new instance.
	 */
	protected EventAttributeStateOnOff(int state)
	{
		m_state = state;
	}
	
	/**
	 * Constructs a new instance by copying the appropriate
	 * values from the passed instance.
	 *
	 * @param second	The instance to copy values from.
	 */
	protected EventAttributeStateOnOff(EventAttributeStateOnOff second)
	{
		m_state = second.m_state;
	}
	
	/**
	 * Returns the current state of the object.
	 *
	 * @return The current state.
	 *
	 * @see #STATE_ON
	 * @see #STATE_OFF
	 */
	public int getState()
	{
		return m_state;
	}
	
	/**
	 * Sets the state for the object.
	 *
	 * @param state		The new state.
	 *
	 * @see #STATE_ON
	 * @see #STATE_OFF
	 */
	public void setState(int state)
	{
		m_state = state;
	}
}

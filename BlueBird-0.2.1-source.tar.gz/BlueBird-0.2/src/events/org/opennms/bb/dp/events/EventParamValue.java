//
// Copyright (C) 2000 N*Manage Company, Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
// $Id: EventParamValue.java,v 1.4 2000/11/10 05:18:10 weave Exp $
//
package org.opennms.bb.dp.events;

import java.lang.*;
import java.math.BigInteger;
import java.io.PrintStream;
import java.io.Serializable;
import org.xml.sax.helpers.AttributesImpl;
//
// for SNMP types
//
import org.opennms.protocols.snmp.*;

/**
 * <P>This class is built to encapsulate parameter value from the 
 * event stream. Each parameter value encapsulates a type, encoding,
 * and actual value. The value's class can be determined by the 
 * type. The encoding rules all for types, like SnmpOpaque, to be 
 * encoded as text even if they contain binary data.</P>
 *
 * @author <A HREF="mailto:weave@opennms.org">Brian Weaver</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version CVS $Revision: 1.4 $
 *
 */
public class EventParamValue implements Serializable
{
	/**
	 * <P>This is the default type for a parameter value from the
	 * Event DTD. The basic value is represented by a java.lang.String
	 * object.</P>
	 */
	public final static int		TYPE_STRING			= 0;
	
	/**
	 * <P>Defines the value as a 32-bit integer value. The type returned
	 * by the call to get value will be a java.lang.Integer object. </P>
	 */
	public final static int		TYPE_INT			= 1;
	
	/**
	 * <P>Defines a 32-bit SNMP integer value. A SnmpInt32 object
	 * is the instance encapsulated by the parameter instance. </P>
	 */
	public final static int		TYPE_SNMP_INT32 		= 2;
	
	/**
	 * <P>Defines the encapsulated value as an SnmpOctetString instance.</P>
	 */
	public final static int		TYPE_SNMP_OCTET_STRING		= 3;
	
	/**
	 * <P>Defines the encasulated value as an instance of an SnmpNull object.</P>
	 */
	public final static int		TYPE_SNMP_NULL			= 4;
	
	/**
	 * <P>Defines the encapsulated value as an instance of an SnmpObjectId object.</P>
	 */
	public final static int		TYPE_SNMP_OBJECT_IDENTIFIER	= 5;
	
	/**
	 * <P>Defines the encasulated value as an instance of an SnmpIpAddress object.</P>
	 */
	public final static int		TYPE_SNMP_IPADDRESS		= 6;
	
	/**
	 * <P>Defines the encasulated value as an instance of an SnmpCopunter32 object.</P>
	 */
	public final static int		TYPE_SNMP_COUNTER32		= 7;
	
	/**
	 * <P>Defines the encasulated value as an instance of an SnmpGauge32 object.</P>
	 */
	public final static int		TYPE_SNMP_GAUGE32		= 8;
	
	/**
	 * <P>Defines the encasulated value as an instance of an SnmpTimeTicks object.</P>
	 */
	public final static int		TYPE_SNMP_TIMETICKS		= 9;
	
	/**
	 * <P>Defines the encasulated value as an instance of an SnmpOpaque object.</P>
	 */
	public final static int		TYPE_SNMP_OPAQUE		= 10;
	
	/**
	 * <P>Defines the encasulated value as an instance of an SnmpCounter64 object.</P>
	 */
	public final static int		TYPE_SNMP_COUNTER64		= 11;
	
	/**
	 * <P>This member defines all the appropriate names for the 
	 * defined types. These string values match the names
	 * as they appear in the Event DTD for an encoded parameter
	 * value.</P>
	 */
	public final static String	TYPE_NAMES[] = { XMLEventsParser.TAG_TYPE_ATTR_STRING,
							 XMLEventsParser.TAG_TYPE_ATTR_INT,
							 XMLEventsParser.TAG_TYPE_ATTR_SNMP_INT32,
							 XMLEventsParser.TAG_TYPE_ATTR_SNMP_OCTETSTR,
							 XMLEventsParser.TAG_TYPE_ATTR_SNMP_NULL,
							 XMLEventsParser.TAG_TYPE_ATTR_SNMP_OBJECTID,
							 XMLEventsParser.TAG_TYPE_ATTR_SNMP_IPADDR,
							 XMLEventsParser.TAG_TYPE_ATTR_SNMP_COUNTER32,
							 XMLEventsParser.TAG_TYPE_ATTR_SNMP_GAUGE32,
							 XMLEventsParser.TAG_TYPE_ATTR_SNMP_TIMETICKS,
							 XMLEventsParser.TAG_TYPE_ATTR_SNMP_OPAQUE,
							 XMLEventsParser.TAG_TYPE_ATTR_SNMP_COUNTER64 };

	/**
	 * <P>The value should be encoded using a plain
	 * textual string in the XML Document.</P>
	 */
	public final static int		XML_ENCODING_TEXT		= 0;
	
	/**
	 * <P>The value should be encoded using a base64
	 * encoding method.</P>
	 */
	public final static int		XML_ENCODING_BASE64		= 1;
	
	/**
	 * <P>The attribute values for the encoding type as they appear
	 * in the Event DTD.</P>
	 */
	public final static String	XML_ENCODING_NAMES[] = { XMLEventsParser.TAG_ENCODING_ATTR_TEXT,
								 XMLEventsParser.TAG_ENCODING_ATTR_BASE64 };
	
	/**
	 * <P>The base64 encoding map. Using 6-bit values it is possible to map
	 * 24-bits into 4 characters. If there are not sufficent amount of bits
	 * to makeup six then it is padded with BASE64_PAD.</P>
	 */
	private static final char	BASE64_CHARS[] = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P',
							   'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f',
							   'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v',
							   'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '+', '-' 
							 };

							 //  0   1   2   3   4   5   6   7   8   9  10  11  12  13  14  15
	private static final byte	BASE64_VALUES[] = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
					/* 16 - 31 */	    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
					/* 32 - 47 */	    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 62, -1, 63, -1, -1,
					/* 48 - 63 */	    52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -1, -1, -1,  0, -1, -1,
					/* 64 - 79 */	    -1,  0,  1,  2,  3,  4,  5,  6,  7,  8,  9, 10, 11, 12, 13, 14,
					/* 80 - 95 */	    15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -1, -1, -1, -1, -1,
					/* 96 - 111 */	    -1, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40,
				        /* 112 - 127 */     41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, -1, -1, -1, -1, -1 
							  };
					
							    
	
	/**
	 * The base64 padding character
	 */
	private static final char	BASE64_PAD	= '=';
	
	/**
	 * The type of the encapsulated object.
	 */
	private int		m_type;
	
	/**
	 * The textual encoding that should be used with this
	 * encapsulated object.
	 */
	private int		m_encoding;
	
	/**
	 * The encapsulated object for this parameter.
	 */
	private Object		m_value;
	
	/**
	 * Writes self to event stream
	 */
	void serializeToXML(PrintStream ps)
	{
		AttributesImpl attr = new AttributesImpl();
		attr.addAttribute("",
				  XMLEventsParser.TAG_TYPE,
				  XMLEventsParser.TAG_TYPE,
				  "CDATA",
				  TYPE_NAMES[m_type]);
		
		attr.addAttribute("", 
				  XMLEventsParser.TAG_ENCODING, 
				  XMLEventsParser.TAG_ENCODING, 
				  "CDATA", 
				  XML_ENCODING_NAMES[m_encoding]);
				  

		XMLEventsParser.dataElement(ps, XMLEventsParser.TAG_PARM_VALUE, attr, toString());
	}
	
	/**
	 * <P>Builds a new instance of an encapsulated parameter from an
	 * event stream. The default instance contains an encapsulated
	 * empty string, type == TYPE_STRING, and encoding == XML_ENCODING_TEXT.</P>
	 *
	 */
	public EventParamValue()
	{
		m_type     = TYPE_STRING;
		m_encoding = XML_ENCODING_TEXT;
		m_value    = new String();
	}

	/**
	 * <P>Constructs a new parameter instance with the specified type and
	 * encapsulated object. The encoding type is infered from the passed
	 * type.</P>
	 *
	 * @param value	The value to encapsulate.
	 *
	 */
	public EventParamValue(Object value)
	{
		m_type = TYPE_STRING;
		m_encoding = XML_ENCODING_TEXT;
		m_value = value;
	}
	
	/**
	 * <P>Constructs a new parameter instance with the specified type and
	 * encapsulated object. The encoding type is infered from the passed
	 * type.</P>
	 *
	 * @param type	The type of the encapsulate value.
	 * @param value	The value to encapsulate.
	 *
	 */
	public EventParamValue(int type, Object value)
	{
		m_encoding = XML_ENCODING_TEXT;
		if(type == TYPE_SNMP_OPAQUE || type == TYPE_SNMP_OCTET_STRING)
			m_encoding = XML_ENCODING_BASE64;
		
		m_type  = type;
		m_value = value;
	}
	
	/**
	 * Constructs a new instance of an encapsulated value. The 
	 * passed parameters define the type, encoding, and value
	 * of the new instance.
	 *
	 * @param type		The type of the encapsulate object.
	 * @param encoding	The encoding to use with XML.
	 * @param value		The value to encapsulate.
	 *
	 */
	public EventParamValue(int type, int encoding, Object value)
	{
		m_type	   = type;
		m_encoding = encoding;
		m_value    = value;
	}
	
	/**
	 * Returns the type for the encapsulated object.
	 */
	public int getType()
	{
		return m_type;
	}
	
	/**
	 * Sets the encapsulated type.
	 *
	 * @param type	The new type for the instance.
	 */
	public void setType(int type)
	{
		m_type = type;
	}
	
	/**
	 * Returns the encoding to be used when written to
	 * an XML event stream.
	 */
	public int getEncoding()
	{
		return m_encoding;
	}
	
	/**
	 * Sets the encoding to be used when written to
	 * an XML event stream.
	 *
	 * @param encoding	The new encoding format.
	 */
	public void setEncoding(int encoding)
	{
		m_encoding = encoding;
	}
	
	/**
	 * Returns the encapsualted value.
	 */
	public Object getValue()
	{
		return m_value;
	}
	
	/**
	 * Sets the encapsulate value.
	 *
	 * @param value	The new value for the instance.
	 */
	public void setValue(Object value)
	{
		m_value = value;
	}

	/**
	 * <P>Sets the object instance to the specified type and
	 * encapsulated object. The encoding type is infered from the passed
	 * type.</P>
	 *
	 * @param type	The type of the encapsulate value.
	 * @param value	The value to encapsulate.
	 *
	 */
	public void set(int type, Object value)
	{
		m_encoding = XML_ENCODING_TEXT;
		if(type == TYPE_SNMP_OPAQUE || type == TYPE_SNMP_OCTET_STRING)
			m_encoding = XML_ENCODING_BASE64;
		
		m_type  = type;
		m_value = value;
	}
	
	/**
	 * Sets the object instance to an encapsulated value. The 
	 * passed parameters define the type, encoding, and value
	 * of the new instance.
	 *
	 * @param type		The type of the encapsulate object.
	 * @param encoding	The encoding to use with XML.
	 * @param value		The value to encapsulate.
	 *
	 */
	public void set(int type, int encoding, Object value)
	{
		m_type	   = type;
		m_encoding = encoding;
		m_value    = value;
	}
	
	/**
	 * <P>Encodes the passed byte array using the base64 rules.
	 * The base64 encoding schema is performed by grouping 
	 * the bytes in to 6-bit quantities and then encoding
	 * them.</P>
	 *
	 * <P>For more information see RFC1341 for the format
	 * used for base64 encoding.</P>
	 *
	 * @param data	The input byte array
	 *
	 * @return The converted data in a character stream.
	 *
	 */
	public static char[] encodeBase64(byte[] data)
	{
		int destlen = ((data.length / 3) + ((data.length % 3) != 0 ? 1 : 0)) * 4;
		char[] dest = new char[destlen];
		int destndx = 0;
		
		for(int i = 0; i < data.length; i += 3)
		{
			int	quantum = 0;
			int	pad     = 0;
			int	bytes   = data.length - i;
			
			if(bytes >= 1)
			{
				quantum = (data[i] > 0 ? (256 + (int)data[i]) : (int)data[i]);
				pad = 2;
			}
			
			quantum <<= 8;
			if(bytes >= 2)
			{
				quantum |= (data[i+1] > 0 ? (256 + (int)data[i+1]) : (int)data[i+1]);
				pad = 1;
			}
			
			quantum <<= 8;
			if(bytes > 2)
			{
				quantum |= (data[i+2] > 0 ? (256 + (int)data[i+2]) : (int)data[i+2]);
				pad = 0;
			}
			
			for(int j = (3 - pad); j >= pad; j--)
			{
				int ndx = (quantum >> (j*6)) & 0x3f;
				dest[destndx++] = BASE64_CHARS[ndx];
			}
			for(int j = pad; j > pad; j--)
			{
				dest[destndx++] = BASE64_PAD;
			}
		}
		return dest;
	}
	
	/**
	 * <P>Decodes a character array into the corresponding byte array. The buffer
	 * must be an intergral number of 4 character. I.E. size mod 4 is equal to zero
	 * or an exception will be thrown. Likewise, if there is an invalid character
	 * in the input array then an exception will be thrown.</P>
	 *
	 *
	 * @param data	The data stream to be filtered.
	 *
	 * @return The coverted array of bytes.
	 *
	 * @exception java.lang.IllegalArgumentException Thrown if an invalid
	 * 	buffer that cannot be decoded is passed.
	 *
	 */
	public static byte[] decodeBase64(char[] data)
	{
		//
		// check the length, it must be an integral number of 4 characters.
		//
		if((data.length % 4) != 0)
			throw new IllegalArgumentException("Invalid base64 encoding, improper length");
		
		//
		// get the raw length and check for
		// the appended padding characters 
		// if any.
		//
		int rawlen = (data.length / 4);
		for(int i = 1; i <= 2; i++)
		{
			if(data[data.length-i] == BASE64_PAD)
				--rawlen;
		}
		
		//
		// allocate the new buffer
		//
		byte[]	rawdata = new byte[rawlen];
		int	rawndx  = 0;
		
		//
		// convert the character array into
		// a byte array.
		//
		int quantum = 0;
		for(int i = 0; i < data.length; i++)
		{
			if((i % 4) == 0 && i > 0)
			{
				int c = ((quantum >> 16) & 0xff);
				rawdata[rawndx++] = (byte)(c > 127 ? c - 256 : c);
				
				c = ((quantum >> 8) & 0xff);
				rawdata[rawndx++] = (byte)(c > 127 ? c - 256 : c);
				
				c = quantum & 0xff;
				rawdata[rawndx++] = (byte)(c > 127 ? c - 256 : c);
				
				quantum = 0;
			}
			quantum <<= 6;
			
			char c = data[i];
			if((int)c >= BASE64_VALUES.length || BASE64_VALUES[(int)c] == -1)
				throw new IllegalArgumentException("Invalid character in decode stream");
			
			quantum |= BASE64_VALUES[(int)c];
		}			
		
		//
		// hand the last byte(s) of data
		//
		int c = ((quantum >> 16) & 0xff);
		rawdata[rawndx++] = (byte)(c > 127 ? c - 256 : c);
		
		if(rawndx < rawlen)
		{
			c = ((quantum >> 8) & 0xff);
			rawdata[rawndx++] = (byte)(c > 127 ? c - 256 : c);
		}
		if(rawndx < rawlen)
		{
			c = quantum & 0xff;
			rawdata[rawndx++] = (byte)(c > 127 ? c - 256 : c);
		}
				
		//
		// return the raw data
		//
		return rawdata;
	}
	
	/**
	 * <P>Filters an existing buffer that was encoded using base64 to only
	 * the appropriate characters. This is useful for removing whitespace,
	 * character returns, and other chaff if it is in the string before
	 * passing it to the decoding routine.</P>
	 *
	 * <P>If a correct buffer cannot be build <EM>(size % 4 != 0)</EM> then
	 * an exception will be thrown.</P>
	 *
	 * @param data	The data stream to be filtered.
	 *
	 * @return The filtered array of characters.
	 *
	 * @exception java.lang.IllegalArgumentException Thrown if an invalid
	 * 	buffer that cannot be filtered is passed.
	 *
	 */
	public static char[] filterBase64(char[] data)
	{
		//
		// prescan for length
		//
		int len = 0;
		for(int i = 0; i < data.length; i++)
		{
			if((int)(data[i]) < BASE64_VALUES.length && BASE64_VALUES[(int)(data[i])] != -1)
				len++;
		}
		
		if((len % 4) != 0)
			throw new IllegalArgumentException("Invalid buffer length after filtering!");
		
		char[] newbuf = new char[len];
		len = 0;
		for(int i = 0; i < data.length; i++)
		{
			if((int)(data[i]) < BASE64_VALUES.length && BASE64_VALUES[(int)(data[i])] != -1)
				newbuf[len++] = data[i];
		}
		
		return newbuf;
	}
	
	/**
	 * Converts the value of the instance to a string
	 * representation in the correct encoding system.
	 *
	 */
	public String toString()
	{
		String result = "";
		switch(m_encoding)
		{
		case XML_ENCODING_TEXT:
			if(m_value instanceof String)
				result = (String)m_value;
			else if(m_value instanceof Number)
				result = m_value.toString();
			else if(m_value instanceof SnmpInt32)
				result = Integer.toString(((SnmpInt32)m_value).getValue());
			else if(m_value instanceof SnmpUInt32)
				result = Long.toString(((SnmpUInt32)m_value).getValue());
			else if(m_value instanceof SnmpCounter64)
				result = ((SnmpCounter64)m_value).getValue().toString();
			else if(m_value instanceof SnmpIPAddress)
				result = m_value.toString();
			else if(m_value instanceof SnmpOctetString)
				result = new String(((SnmpOctetString)m_value).getString());
			else if(m_value instanceof SnmpObjectId)
				result = m_value.toString();
			break;
			
		case XML_ENCODING_BASE64:
			if(m_value instanceof String)
				result = new String(encodeBase64(((String)m_value).getBytes()));
			else if(m_value instanceof Number)
			{
				byte[] ibuf = null;
				if(m_value instanceof Short)
				{
					ibuf = new byte[2];
					ibuf[0] = (byte) ((((Number)m_value).shortValue() >> 8) & 0xff);
					ibuf[1] = (byte) (((Number)m_value).shortValue() & 0xff);
				}
				else if(m_value instanceof Integer)
				{
					ibuf = new byte[4];
					ibuf[0] = (byte) ((((Number)m_value).intValue() >> 24) & 0xff);
					ibuf[1] = (byte) ((((Number)m_value).intValue() >> 16) & 0xff);
					ibuf[2] = (byte) ((((Number)m_value).intValue() >> 8) & 0xff);
					ibuf[3] = (byte) (((Number)m_value).intValue() & 0xff);
				}
				else if(m_value instanceof Long)
				{
					ibuf = new byte[8];
					ibuf[0] = (byte) ((((Number)m_value).longValue() >> 56) & 0xffL);
					ibuf[1] = (byte) ((((Number)m_value).longValue() >> 48) & 0xffL);
					ibuf[2] = (byte) ((((Number)m_value).longValue() >> 40) & 0xffL);
					ibuf[3] = (byte) ((((Number)m_value).longValue() >> 32) & 0xffL);
					ibuf[4] = (byte) ((((Number)m_value).longValue() >> 24) & 0xffL);
					ibuf[5] = (byte) ((((Number)m_value).longValue() >> 16) & 0xffL);
					ibuf[6] = (byte) ((((Number)m_value).longValue() >> 8)  & 0xffL);
					ibuf[7] = (byte) (((Number)m_value).longValue() & 0xffL);
				}
				else if(m_value instanceof BigInteger)
				{
					ibuf = ((BigInteger)m_value).toByteArray();
				}
				result = new String(encodeBase64(ibuf));
			}
			else if(m_value instanceof SnmpInt32)
			{
				byte[] ibuf = new byte[4];
				ibuf[0] = (byte) ((((SnmpInt32)m_value).getValue() >> 24) & 0xff);
				ibuf[1] = (byte) ((((SnmpInt32)m_value).getValue() >> 16) & 0xff);
				ibuf[2] = (byte) ((((SnmpInt32)m_value).getValue() >> 8) & 0xff);
				ibuf[3] = (byte) (((SnmpInt32)m_value).getValue() & 0xff);
				
				result = new String(encodeBase64(ibuf));
			}
			else if(m_value instanceof SnmpUInt32)
			{
				byte[] ibuf = new byte[4];
				ibuf[0] = (byte) ((((SnmpUInt32)m_value).getValue() >> 24) & 0xffL);
				ibuf[1] = (byte) ((((SnmpUInt32)m_value).getValue() >> 16) & 0xffL);
				ibuf[2] = (byte) ((((SnmpUInt32)m_value).getValue() >> 8) & 0xffL);
				ibuf[3] = (byte) (((SnmpUInt32)m_value).getValue() & 0xffL);
				
				result = new String(encodeBase64(ibuf));
			}
			else if(m_value instanceof SnmpCounter64)
			{
				byte[] ibuf = ((SnmpCounter64)m_value).getValue().toByteArray();
				result = new String(encodeBase64(ibuf));
			}
			else if(m_value instanceof SnmpOctetString)
			{
				result = new String(encodeBase64(((SnmpOctetString)m_value).getString()));
			}
			else if(m_value instanceof SnmpObjectId)
			{
				result = new String(encodeBase64(m_value.toString().getBytes()));
			}
			break;
		} // end switch
		
		return result;
		
	} // end toString()		
}

//
// Copyright (C) 2000 N*Manage Company, Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
// $Id: EventForward.java,v 1.4 2000/11/10 05:18:10 weave Exp $
//
package org.opennms.bb.dp.events;

import java.lang.*;
import java.io.Serializable;
import java.io.PrintStream;
import org.xml.sax.helpers.AttributesImpl;

/**
 * <P>This class is designed to encapsulate all the relavant information
 * for the <EM>forward</EM> element of the Event DTD. The forward element
 * contains the forwarding destination as its data and two attributes:
 * state & mechanism. This class groups all the information about the
 * XML elemement into a single class.</P>
 *
 * @author <A HREF="mailto:weave@opennms.org">Brian Weaver</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version CVS $Revision: 1.4 $
 *
 */
public class EventForward extends EventAttributeStateOnOff implements Serializable
{
	/**
	 * Forward the event using UDP/IP protocol
	 * with the message encodied using SNMP/BER
	 */
	public static final int		FWD_SNMP_UDP	= 0;
	
	/**
	 * Forward the event using TCP/IP protocol
	 * with the message encoded using SNMP/BER
	 */
	public static final int		FWD_SNMP_TCP	= 1;
	
	/**
	 * Forward the event using TCP/IP protocol
	 * with the message encoded using XML.
	 */
	public static final int		FWD_XML_TCP	= 2;
	
	/**
	 * Forward the event using the UDP/IP protocol
	 * with the message encoded using XML.
	 */
	public static final int		FWD_XML_UDP	= 3;
	
	/**
	 * The protocol to use when forwarding
	 * the event.
	 */
	private int	m_fwdhow;
	
	/**
	 * The forwarding destination.
	 */
	private String	m_fwdto;
	
	/**
	 * Writes self to event stream
	 */
	void serializeToXML(PrintStream ps)
	{
		AttributesImpl attr = new AttributesImpl();
		attr.addAttribute("", 
				  XMLEventsParser.TAG_STATE, 
				  XMLEventsParser.TAG_STATE, 
				  "CDATA", 
				  m_state  == STATE_OFF ? XMLEventsParser.TAG_STATE_ATTR_OFF 
				  			: XMLEventsParser.TAG_STATE_ATTR_ON);
		switch(m_fwdhow)
		{
		case FWD_SNMP_UDP:
			attr.addAttribute("", 
					  XMLEventsParser.TAG_MECHANISM, 
					  XMLEventsParser.TAG_MECHANISM, 
					  "CDATA", 
					  XMLEventsParser.TAG_MECHANISM_ATTR_SNMPUDP);
			break;
		case FWD_SNMP_TCP:
			attr.addAttribute("", 
					  XMLEventsParser.TAG_MECHANISM, 
					  XMLEventsParser.TAG_MECHANISM, 
					  "CDATA", 
					  XMLEventsParser.TAG_MECHANISM_ATTR_SNMPTCP);
			break;
		case FWD_XML_TCP:
			attr.addAttribute("", 
					  XMLEventsParser.TAG_MECHANISM, 
					  XMLEventsParser.TAG_MECHANISM, 
					  "CDATA", 
					  XMLEventsParser.TAG_MECHANISM_ATTR_XMLTCP);
			break;
		case FWD_XML_UDP:
			attr.addAttribute("", 
					  XMLEventsParser.TAG_MECHANISM, 
					  XMLEventsParser.TAG_MECHANISM, 
					  "CDATA", 
					  XMLEventsParser.TAG_MECHANISM_ATTR_XMLUDP);
			break;
		}
		XMLEventsParser.dataElement(ps, XMLEventsParser.TAG_FORWARD, attr, m_fwdto);
	}
	
	/**
	 * Constructs a new instance of the class and
	 * sets all the fields to the default values.
	 *
	 */
	public EventForward()
	{
		super(STATE_OFF);
		m_fwdhow = FWD_SNMP_UDP;
		m_fwdto = null;
	}
	
	/**
	 * Constructs a new forwarding instance that
	 * is a duplicate copy of the passed instance.
	 * This allows for the passed copy to be modified
	 * without affecting the data in the new instance.
	 *
	 * @param second	The instance to copy.
	 *
	 */
	public EventForward(EventForward second)
	{
		super(second);
		m_fwdhow = second.m_fwdhow;
		m_fwdto  = second.m_fwdto;
	}
	
	/**
	 * Constructs a new forwarding instance with
	 * the specific destination. The forwarding 
	 * protocol and state are set to the default
	 * values as defined by the Event DTD.
	 *
	 * @param destination	The forwarding destination.
	 */
	public EventForward(String destination)
	{
		super(STATE_OFF);
		m_fwdhow = FWD_SNMP_UDP;
		m_fwdto = destination;
	}
	
	/**
	 * Constructs a new instance of this with
	 * the passed destination and protocol.
	 *
	 * @param destination	The forwarding destination.
	 * @param how		The forwarding protocol.
	 *
	 */
	public EventForward(String destination, int how)
	{
		super(STATE_OFF);
		m_fwdhow = how;
		m_fwdto  = destination;
	}
	
	/**
	 * Constructs a new instance of the class that
	 * contains the appropriate forwarding information.
	 *
	 * @param destination	The forwarding destination.
	 * @param how		The forwarding protocol.
	 * @param state		The forwarding state.
	 *
	 */
	public EventForward(String destination, int how, int state)
	{
		super(state);
		m_fwdhow = how;
		m_fwdto  = destination;
	}
	
	/**
	 * Sets the information contained in the forwarding
	 * instance. The destination information and forwarding
	 * protocol can be set using this method.
	 *
	 * @param destination	The forwarding destination.
	 * @param how		The forwarding protocol
	 *
	 */
	public void set(String destination, int how)
	{
		m_fwdhow = how;
		m_fwdto  = destination;
	}
	
	/**
	 * Sets the information contained in this instance. It
	 * allows the destination, protocol, and forwarding state
	 * to be set in a single call.
	 *
	 * @param destination	The forwarding destination.
	 * @param how		The forwarding protocol.
	 * @param state		The forwarding state.
	 *
	 */
	public void set(String destination, int how, int state)
	{
		m_state = state;
		m_fwdhow = how;
		m_fwdto  = destination;
	}
	
	/**
	 * Returns the forwarding destination that is currently set 
	 * for this instance.
	 *
	 * @return The forwarding destination.
	 *
	 */
	public String getDestination()
	{
		return m_fwdto;
	}
	
	/**
	 * Sets the forwarding destination for the instance.
	 *
	 * @param destination	The forwarding destination.
	 *
	 */
	public void setDestination(String destination)
	{
		m_fwdto = destination;
	}
	
	/**
	 * Returns the currently set forwarding mechinism.
	 *
	 * @return The forwarding protocol.
	 */
	public int getForwardType()
	{
		return m_fwdhow;
	}
	
	/**
	 * Sets the forwarding mechinism type
	 * for the instance.
	 *
	 * @param how	The protocol used to forward the event.
	 */
	public void setForwardType(int how)
	{
		m_fwdhow = how;
	}
}


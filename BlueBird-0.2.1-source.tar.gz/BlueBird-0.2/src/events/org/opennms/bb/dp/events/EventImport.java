// Copyright (C) 2000 N*Manage Company, Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//  Brian Weaver    <weave@opennms.org>
//  http://www.opennms.org/
//
// Tab Size = 8
//
package org.opennms.bb.dp.events;

import java.io.*;
import java.net.*;
import java.io.Serializable;

/**
 * EventImport sends events in the XML format to the specified remote host
 * via either TCP or UDP
 *
 * @author 	<A HREF="mailto:sowmya@opennms.org">Sowmya Kumaraswamy</A>
 * @author	<A HREF="http://www.opennms.org">OpenNMS.org</A>
 *
 * @version	$Revision: 1.9 $
 */
public class EventImport implements Serializable
{
	/**
	 * indicates if user has specified TCP
	 */
	private boolean		m_tcp;

	/**
	 * indicates if user has specified UDP
	 */
	private boolean		m_udp;

	/**
	 * filename which contains the event xml to be sent
	 */
	private String		m_fileName;

	/**
	 * the remote host to which the events are to be sent
	 */
	private String		m_host=null;

	/**
	 * the length to be read each time while reading the file
	 */
	private final int	READ_LEN=1024;

	/**
	 *  the port at which 'eventd' listens for events coming in thru' TCP
	 */
	private final int	EVENTD_TCP_PORT=5817;

	/**
	 *  the port at which 'eventd' listens for events coming in thru' UDP
	 */
	private final int	EVENTD_UDP_PORT=5818;


	/**
	 * Constructs the EventImport class - process the arguments, reads
	 * from the file and sends it to the remote host using the mode
	 * specified
	 *
	 * @param args[]	the argument list sent to the class
	 */
	public EventImport(String args[])  throws IOException
	{
		/**
		 * process the arguments and get relevant information
		 */
		boolean bRet = processArgs(args);
		if (!bRet)
			return;
		
		System.out.println("Event XML to be sent from file \'" + m_fileName + "\' to host \'" + m_host + "\' ...");

		/**
		 * get the xml to be sent from the filename
		 */
		byte[] xmlStr = getMessageToSend();
		if (xmlStr == null)
			return;

		/**
		 * Depending on the option, send via TCP/UDP
		 */
		if (m_tcp)
			tcpSend(xmlStr);

		if (m_udp)
			udpSend(xmlStr);

	}

	/**
	 * Process and extract the arguments to get the filename and the
	 * mode to be used to send the data
	 *
	 * @return false if error in arguments, true otherwise
	 */
	private boolean processArgs(String[] args)
	{
		boolean	bRet = true;

		/**
		 * Check the number of arguments
		 */
		if (args.length == 1 && args[0].equalsIgnoreCase("-h"))
		{
			printUsage();

			return false;
		}

		if (args.length < 4) 
		{
			bRet = false;
			throw new IllegalArgumentException("Wrong number of arguments");
		}

		int argsLen = args.length;

		for (int i=0; i < argsLen; i++)
		{
			if (args[i].equals("-t") || args[i].equals("-tcp"))
				m_tcp = true;
			else if (args[i].equals("-u") || args[i].equals("-udp"))
				m_udp = true;

			else if (args[i].equals("-host"))
			{
				if ((i+1) < argsLen)
				{
					m_host = args[i+1];
					i++;
				}
			}
		}
		
		/**
		 * Only one mode can be specified
		 */
		if (m_tcp && m_udp)
		{
			throw new IllegalArgumentException("Only one mode can be specified");
		}

		/**
		 * Atleast one of tcp/udp must be specified
		 */
		if (!m_tcp && !m_udp)
		{
			throw new IllegalArgumentException("mode not specified");
		}

		/**
		 * check that the host to be sent to has been specified
		 */
		if(m_host == null)
		{
			throw new IllegalArgumentException("Host to which XML is to be sent not known");
		}
		
		/**
		 * last argument assumed to be filename
		 */
		m_fileName = args[argsLen-1];

		return bRet;
	}

	
	/**
	 * Read the data to be sent from the filename specified
	 */
	private byte[] getMessageToSend() throws IOException
	{
		ByteArrayOutputStream xmlStr = new ByteArrayOutputStream();

		try 
		{
			
			/**
			 * Check if file exists, if not, throw an error
			 */
			File	fileDes    = new File(m_fileName);
			if (!fileDes.exists())
			{
				throw new IOException("File " + m_fileName + " does not exist");
			}

			int	fileLen	   = (int)fileDes.length();

			FileInputStream in = new FileInputStream(fileDes);

			int bytesInThisRead	= 0;

			// loop until we've read it all
			do 
			{
				byte[]  message = new byte[READ_LEN];

				bytesInThisRead = in.read(message);

				// append to xml string
				if (bytesInThisRead > 0)
				{
					xmlStr.write(message, 0, bytesInThisRead);
				}

			} while(bytesInThisRead != -1);

			System.out.println("fileLen/lenRead: " + fileLen + "/" + xmlStr.toByteArray().length);

		}
		catch (IOException e) 
		{
			xmlStr = null;
			throw e;
		}

		if (xmlStr == null)
			return null;
		else
			return xmlStr.toByteArray();
	}

	/**
	 * Send to the TCP port of eventd
	 */
	private void tcpSend(byte[] xmlStr) throws IOException
	{
		System.out.println("Sending to " + m_host + " via TCP");

      		// Get the internet address of the specified host
      		InetAddress address = InetAddress.getByName(m_host);

      		// Initialize a TCP packet with host and port.
      		Socket tsocket = new Socket(m_host, EVENTD_TCP_PORT);

	  	// Create an output stream.
	  	BufferedOutputStream os = new BufferedOutputStream(tsocket.getOutputStream());

      		// Send the message through the socket.
      		os.write(xmlStr, 0, xmlStr.length);
	  	os.flush();

      		tsocket.close();
	}

	/**
	 * Send to udp port of eventd
	 */
	private void udpSend(byte[] xmlStr) throws IOException
	{
		System.out.println("Sending to " + m_host + " via UDP");

		// Get the internet address of the specified host
		InetAddress address = InetAddress.getByName(m_host);

		// Initialize a datagram packet with data and address
		DatagramPacket packet = new DatagramPacket(xmlStr, xmlStr.length, address, EVENTD_UDP_PORT); 

		// Create a datagram socket, send the packet through it, close it.
		DatagramSocket dsocket = new DatagramSocket();
		dsocket.send(packet);
		dsocket.close();
	}

	/**
	 * print the usage instructions
	 */
	public static void printUsage()
	{
		System.out.println("\nUsage: EventImport <options> filename");
		System.out.println("where options are:");
		System.out.println("-t | -tcp" +"\t\t" + "Send file via TCP - only one of TCP/UDP can be specified");
		System.out.println("-u | -udp" +"\t\t" + "Send file via UDP - only one of TCP/UDP can be specified");
		System.out.println("-host <hostname>" + "\t" + "The remote system to send to");
		System.out.println("filename\t\tFile whose contents are to be sent\n");
		System.out.println("EventImport -h prints this message");

	}

	/**
	 * Start up EventImport
	 */
	public static void main(String[] args)
	{
		try
		{
			EventImport eventImport = new EventImport(args);
		}
		catch(IOException e)
		{
			System.out.println(e.getMessage() + "\n");
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage() + "\n");
			System.out.println("Use EventImport -h for usage");
		}
	}
}

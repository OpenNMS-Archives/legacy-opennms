//
// Copyright (C) 2000 N*Manage Company, Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
// $Id: XMLEventsParser.java,v 1.7 2000/11/10 05:18:10 weave Exp $
//
// This file orginally found under org/opennms/bb/dp/events/eventd/utils and
// was moved and renamed from the original class of EventsParser.java
//	- weave 11/02/00
//
package org.opennms.bb.dp.events;

import java.io.*;
import java.util.*;

import org.xml.sax.*;
import org.apache.xerces.parsers.SAXParser;
//import org.apache.soap.sax.SAXParser;

/**
 * <P>The XMLEventsParser is a SAX based parser used to decompose an
 * event stream into the corresponding event classes. The class provides
 * realitivly strong structure checking, but does not require and/or parse
 * an DTD that may proceed the data. This allows the parser to be used with
 * a SAX based SOAP parser, since SOAP prohibits the used of DTDs.</P>
 *
 *
 * @author 	<A HREF="mailto:sowmya@opennms.org">Sowmya Kumaraswamy</A>
 * @author	<A HREF="mailto:weave@opennms.org">Brian Weaver</A>
 * @author	<A HREF="http://www.opennms.org">OpenNMS.org</A>
 *
 * @version	$Revision: 1.7 $
 */
public class XMLEventsParser implements ContentHandler, ErrorHandler
{
	/*
	 * Relevant XML TAGS
	 */
	final static String TAG_LOG				= "log";
	final static String TAG_HEADER				= "header";
	final static String TAG_VER				= "ver";
	final static String TAG_DPNAME				= "dpName";
	final static String TAG_CREATED				= "created";
	final static String TAG_MSTATION			= "mstation";
	final static String TAG_EVENTS				= "events";
	final static String TAG_EVENT				= "event";
	final static String TAG_UEI				= "uei";
	final static String TAG_SOURCE				= "source";
	final static String TAG_TIME				= "time";
	final static String TAG_TIME_ATTR_YEAR			= "year";
	final static String TAG_TIME_ATTR_MONTH			= "month";
	final static String TAG_TIME_ATTR_DAY			= "day";
	final static String TAG_TIME_ATTR_HOUR			= "hour";
	final static String TAG_TIME_ATTR_MIN			= "min";
	final static String TAG_TIME_ATTR_SEC			= "sec";
	final static String TAG_TYPE				= "type";
	final static String TAG_TYPE_ATTR_INT			= "int";
	final static String TAG_TYPE_ATTR_STRING		= "string";
	final static String TAG_TYPE_ATTR_SNMP_INT32 		= "Int32";
	final static String TAG_TYPE_ATTR_SNMP_OCTETSTR 	= "OctetString";
	final static String TAG_TYPE_ATTR_SNMP_NULL		= "Null";
	final static String TAG_TYPE_ATTR_SNMP_OBJECTID 	= "ObjectIdentifier";
	final static String TAG_TYPE_ATTR_SNMP_IPADDR		= "IpAddress";
	final static String TAG_TYPE_ATTR_SNMP_COUNTER32	= "Counter32";
	final static String TAG_TYPE_ATTR_SNMP_GAUGE32  	= "Gauge32";
	final static String TAG_TYPE_ATTR_SNMP_TIMETICKS	= "TimeTicks";
	final static String TAG_TYPE_ATTR_SNMP_OPAQUE		= "Opaque";
	final static String TAG_TYPE_ATTR_SNMP_COUNTER64	= "Counter64";
	final static String TAG_HOST				= "host";
	final static String TAG_SNMPHOST			= "snmphost";
	final static String TAG_NODEID				= "nodeid";
	final static String TAG_SERVICE				= "service";
	final static String TAG_INTERFACE			= "interface";
	final static String TAG_SNMP				= "snmp";
	final static String TAG_EID				= "eid";
	final static String TAG_EIDTEXT				= "eidtext";
	final static String TAG_SPECIFIC			= "specific";
	final static String TAG_GENERIC				= "generic";
	final static String TAG_PARMS				= "parms";
	final static String TAG_PARM				= "parm";
	final static String TAG_PARM_NAME			= "parmName";
	final static String TAG_PARM_VALUE			= "value";
	final static String TAG_ENCODING			= "encoding";
	final static String TAG_ENCODING_ATTR_TEXT		= "text";
	final static String TAG_ENCODING_ATTR_BASE64		= "base64";
	final static String TAG_DESCR				= "descr";
	final static String TAG_LOGMSG				= "logmsg";
	final static String TAG_LOGMSGDEST			= "dest";
	final static String TAG_LOGMSGDEST_ATTR_SUPPRESS	= "suppress";
	final static String TAG_LOGMSGDEST_ATTR_LOGONLY		= "logonly";
	final static String TAG_LOGMSGDEST_ATTR_LOGNDISPLAY	= "logndisplay";
	final static String TAG_SEVERITY			= "severity";
	final static String TAG_OPERINSTR			= "operinstruct";
	final static String TAG_AUTOACTION			= "autoaction";
	final static String TAG_OPERACTION			= "operaction";
	final static String TAG_OPERACTIONMENU			= "menutext";
	final static String TAG_LOGGROUP			= "loggroup";
	final static String TAG_NOTIFICATION			= "notification";
	final static String TAG_TTICKET				= "tticket";
	final static String TAG_STATE				= "state";
	final static String TAG_STATE_ATTR_ON			= "on";
	final static String TAG_STATE_ATTR_OFF			= "off";
	final static String TAG_FORWARD				= "forward";
	final static String TAG_MECHANISM			= "mechanism";
	final static String TAG_MECHANISM_ATTR_SNMPUDP		= "snmpudp";
	final static String TAG_MECHANISM_ATTR_SNMPTCP		= "snmptcp";
	final static String TAG_MECHANISM_ATTR_XMLUDP		= "xmludp";
	final static String TAG_MECHANISM_ATTR_XMLTCP		= "xmltcp";
	final static String TAG_MOUSEOVERTEXT			= "mouseovertext";
	
	/*
	 * Relavant save tags that contain depth
	 * and information processing. There should be 
	 * one tag per String tag from the above seection.
	 */
	private static final int SAVE_IGNORE 		= 0x00000080;
	private static final int SAVE_LOG		= 1 | SAVE_IGNORE;
	
	private static final int SAVE_HEADER		= (1 << 8) | 2 | SAVE_IGNORE;
	private static final int SAVE_HDR_VERSION	= (2 << 8) | 3;
	private static final int SAVE_HDR_DPNAME	= (2 << 8) | 4;
	private static final int SAVE_HDR_CREATED	= (2 << 8) | 5;
	private static final int SAVE_HDR_MSTATION	= (2 << 8) | 6;
	
	private static final int SAVE_EVENTS		= (1 << 8) | 7 | SAVE_IGNORE;
	private static final int SAVE_EVENT		= (2 << 8) | 8 | SAVE_IGNORE;
	private static final int SAVE_UEI		= (3 << 8) | 9;
	private static final int SAVE_SOURCE		= (3 << 8) | 10;
	private static final int SAVE_TIME		= (3 << 8) | 11;
	private static final int SAVE_HOST		= (3 << 8) | 12;
	private static final int SAVE_SNMPHOST		= (3 << 8) | 13;
	private static final int SAVE_SNMP		= (3 << 8) | 14 | SAVE_IGNORE;
	private static final int SAVE_SNMP_EID		= (4 << 8) | 15;
	private static final int SAVE_SNMP_EIDTEXT	= (4 << 8) | 16;
	private static final int SAVE_SNMP_SPECIFIC	= (4 << 8) | 17;
	private static final int SAVE_SNMP_GENERIC	= (4 << 8) | 18;
	private static final int SAVE_PARMS		= (3 << 8) | 19 | SAVE_IGNORE;
	private static final int SAVE_PARM		= (4 << 8) | 20 | SAVE_IGNORE;
	private static final int SAVE_PARM_NAME		= (5 << 8) | 21;
	private static final int SAVE_PARM_VALUE	= (5 << 8) | 22;
	private static final int SAVE_DESCR		= (3 << 8) | 23;
	private static final int SAVE_LOGMSG		= (3 << 8) | 24;
	private static final int SAVE_SEVERITY		= (3 << 8) | 25;
	private static final int SAVE_OPERINSTRUCT	= (3 << 8) | 26;
	private static final int SAVE_AUTOACTION	= (3 << 8) | 27;
	private static final int SAVE_OPERACTION	= (3 << 8) | 28;
	private static final int SAVE_LOGGROUP		= (3 << 8) | 29;
	private static final int SAVE_NOTIFICATION	= (3 << 8) | 30;
	private static final int SAVE_TTICKET		= (3 << 8) | 31;
	private static final int SAVE_FORWARD		= (3 << 8) | 32;
	private static final int SAVE_MOUSEOVERTEXT	= (3 << 8) | 33;
	private static final int SAVE_NODEID		= (3 << 8) | 34;
	private static final int SAVE_SERVICE		= (3 << 8) | 35;
	private static final int SAVE_INTERFACE		= (3 << 8) | 36;
	

	/**
	 * The buffer where subsequent textual information from the
	 * character() method are appendedd. This is normally cleared
	 * after each call to endElement. If an element will contain
	 * both textual information and sub-elements then this should
	 * be modified to behave like a stack.
	 */
	private StringBuffer	m_data;
	
	/**
	 * The save buffer stack. The m_depth member is used to 
	 * as the TOS pointer for accesing the save states.
	 */
	private int[] 		m_save;
	
	/**
	 * The current depth of the elements in the document 
	 * and the TOS for the m_save member.
	 */
	private int 		m_depth;
	
	/**
	 * The header recovered from the event stream
	 */
	private EventHeader	m_header;
	
	/**
	 * The list of events from the stream
	 */
	private List		m_events;
	
	/**
	 * The event being currently processes
	 */
	private Event		m_event;	// the last event created on startElement("event")
	
	/**
	 * An event parameter, valid between &lt;parm&gt;...&lt;/parm&gt;
	 */
	private EventParameter	m_parm;		// event parameter created on startElement("parm")
	
	/**
	 * An snmp information block. This is valid between &lt;snmp&gt;...&lt;/snmp&gt;
	 */
	private EventSnmpInfo	m_snmpInfo;	// snmp info created on startElement("snmp")
	
	/**
	 * The last attributes elements passed to the startElement()
	 * method. If Attributes are need for post processing, but the
	 * element to be post processed has subelements, then a stack based
	 * approach MUST be used!
	 */
	private Attributes	m_attributes;	// last attributes from startElement()
	
	/**
	 * Returns the depth of a particular SAVE_???
	 * tag.
	 *
	 * @param token		The tag to return depth information from.
	 *
	 * @return The depth of the tag.
	 */
	private int depthOf(int token)
	{
		return (token >> 8);
	}
	
	/** 
	 * <P>Used to validate the event before it is placed onto the 
	 * actual list of events. If the method returns true then
	 * the event is added to the list. If the method returns
	 * false then it is not added to the list.</P>
	 *
	 * <P>Additionally, the method is able to modify the values contained
	 * in the event if necessary, prior to the event being added to the
	 * list of events. Care should be used by all derived classes that
	 * implement this behavior.</P>
	 *
	 * @param e	The event to validate
	 *
	 * @return True if the event is valid, false if it should be discarded
	 * 	by the parser.
	 *
	 */
	protected boolean validate(Event e)
	{
		return true;
	}
	
	/**
	 * Prints out a start xml tag with the passed attributes
	 *
	 * @param ps 	The output stream
	 * @param tag	The start tag.
	 * @param attrs	The attributes, if any.
	 */
	static void startElement(PrintStream ps, String tag, Attributes attrs)
	{
		ps.print("<" + tag);
		if(attrs != null)
		{
			for(int i = 0; i < attrs.getLength(); ++i)
			{
				ps.print(( i == 0 ? "\t" : "\n\t") + attrs.getLocalName(i) 
					 + "=\"" + attrs.getValue(i) + "\"");
			}
		}
		ps.println(">");
	}
	
	/**
	 * Prints out the closing element.
	 *
	 * @param ps	The output stream
	 * @param tag	The closing tag.
	 */
	static void endElement(PrintStream ps, String tag)
	{
		ps.println("</" + tag + ">");
	}
	
	/**
	 * Prints out a data element into the print stream.
	 *
	 * @param ps 	The output stream
	 * @param tag	The start tag.
	 * @param attrs	The attributes, if any.
	 * @param value The value string.
	 */
	static void dataElement(PrintStream ps, String tag, Attributes attrs, String value)
	{
		startElement(ps,tag,attrs);
		ps.println(value);
		endElement(ps,tag);
	}
	
	/**
	 * Constructs a new default instance of the parser
	 * that can be registered with a SAXParser.
	 */
	public XMLEventsParser()
	{
		m_data = new StringBuffer();
		m_save = new int[8];
		m_depth= 0;
		
		m_header     = null;
		m_events     = null;
		m_event      = null;
		m_parm       = null;
		m_snmpInfo   = null;
		m_attributes = null;
	}
	
	/**
	 * Sets the document locator.
	 *
	 * @param loc	The document locator.
	 */
	public void setDocumentLocator(Locator loc)
	{
		// do nothing;
	}
	
	/**
	 * Called when the document parsing is beginning.
	 *
	 * @exception org.xml.sax.SAXException Thrown if an error occurs
	 * 	processing the start of the document.
	 *
	 */
	public void startDocument() 
		throws SAXException
	{
		if(m_data.length() > 0)
			m_data.delete(0, m_data.length());
		
		m_depth = 0;
		m_save[0] = SAVE_IGNORE;
		
		m_header = null;
		m_events = null;
		m_event  = null;
		m_parm   = null;
		m_snmpInfo = null;
		m_attributes = null;
	}
	
	/**
	 * Called when the end of the document is reached.
	 *
	 * @throws org.xml.sax.SAXException Thrown if an error occurs
	 * 	validating the document semantics.
	 *
	 */
	public void endDocument() 
		throws SAXException
	{
		if(m_events.isEmpty())
			throw new SAXException("Invalid message, no events present");
	}
	
	/**
	 * Called when a new element is encountered in the document.
	 *
	 * @param uri		The namespace of the element.
	 * @param localName	The unqualified name of the element.
	 * @param qName		The qualified name of the element.
	 * @param attrs		The attributes for the element.
	 *
	 * @throws org.xml.sax.SAXException Thrown if an error occurs processing
	 * 	the element.
	 *
	 */
	public void startElement(String uri, String localName, String qName, Attributes attrs)
		throws SAXException
	{
		//
		// Save the current attributes
		//
		m_attributes = attrs;
		
		//
		// check the local name
		//
		if(localName.equals(TAG_LOG) && m_depth == depthOf(SAVE_LOG))
		{
			m_save[m_depth] = SAVE_LOG;
		}
		else if(localName.equals(TAG_HEADER) && m_depth == depthOf(SAVE_HEADER))
		{
			m_save[m_depth] = SAVE_HEADER;
			m_header = new EventHeader();
		}
		else if(localName.equals(TAG_VER) && m_depth == depthOf(SAVE_HDR_VERSION))
		{
			m_save[m_depth] = SAVE_HDR_VERSION;
		}
		else if(localName.equals(TAG_DPNAME) && m_depth == depthOf(SAVE_HDR_DPNAME))
		{
			m_save[m_depth] = SAVE_HDR_DPNAME;
		}
		else if(localName.equals(TAG_CREATED) && m_depth == depthOf(SAVE_HDR_CREATED))
		{
			m_save[m_depth] = SAVE_HDR_CREATED;
		}
		else if(localName.equals(TAG_MSTATION) && m_depth == depthOf(SAVE_HDR_MSTATION))
		{
			m_save[m_depth] = SAVE_HDR_MSTATION;
		}
		else if(localName.equals(TAG_EVENTS) && m_depth == depthOf(SAVE_EVENTS))
		{
			m_save[m_depth] = SAVE_EVENTS;
			m_events = new ArrayList();
		}
		else if(localName.equals(TAG_EVENT) && m_depth == depthOf(SAVE_EVENT))
		{
			m_save[m_depth] = SAVE_EVENT;
			m_event = new Event();
		}
		else if(localName.equals(TAG_UEI) && m_depth == depthOf(SAVE_UEI))
		{
			m_save[m_depth] = SAVE_UEI;
		}
		else if(localName.equals(TAG_SOURCE) && m_depth == depthOf(SAVE_SOURCE))
		{
			m_save[m_depth] = SAVE_SOURCE;
		}
		else if(localName.equals(TAG_TIME) && m_depth == depthOf(SAVE_TIME))
		{
			m_save[m_depth] = SAVE_TIME;
		}
		else if(localName.equals(TAG_HOST) && m_depth == depthOf(SAVE_HOST))
		{
			m_save[m_depth] = SAVE_HOST;
		}
		else if(localName.equals(TAG_SNMPHOST) && m_depth == depthOf(SAVE_SNMPHOST))
		{
			m_save[m_depth] = SAVE_SNMPHOST;
		}
		else if(localName.equals(TAG_NODEID) && m_depth == depthOf(SAVE_NODEID))
		{
			m_save[m_depth] = SAVE_NODEID;
		}
		else if(localName.equals(TAG_SERVICE) && m_depth == depthOf(SAVE_SERVICE))
		{
			m_save[m_depth] = SAVE_SERVICE;
		}
		else if(localName.equals(TAG_INTERFACE) && m_depth == depthOf(SAVE_INTERFACE))
		{
			m_save[m_depth] = SAVE_INTERFACE;
		}
		else if(localName.equals(TAG_SNMP) && m_depth == depthOf(SAVE_SNMP))
		{
			m_save[m_depth] = SAVE_SNMP;
			m_snmpInfo = new EventSnmpInfo();
		}
		else if(localName.equals(TAG_EID) && m_depth == depthOf(SAVE_SNMP_EID))
		{
			m_save[m_depth] = SAVE_SNMP_EID;
		}
		else if(localName.equals(TAG_EIDTEXT) && m_depth == depthOf(SAVE_SNMP_EIDTEXT))
		{
			m_save[m_depth] = SAVE_SNMP_EIDTEXT;
		}
		else if(localName.equals(TAG_SPECIFIC) && m_depth == depthOf(SAVE_SNMP_SPECIFIC))
		{
			m_save[m_depth] = SAVE_SNMP_SPECIFIC;
		}
		else if(localName.equals(TAG_GENERIC) && m_depth == depthOf(SAVE_SNMP_GENERIC))
		{
			m_save[m_depth] = SAVE_SNMP_GENERIC;
		}
		else if(localName.equals(TAG_PARMS) && m_depth == depthOf(SAVE_PARMS))
		{
			m_save[m_depth] = SAVE_PARMS;
		}
		else if(localName.equals(TAG_PARM) && m_depth == depthOf(SAVE_PARM))
		{
			m_save[m_depth] = SAVE_PARM;
			m_parm = new EventParameter();
		}
		else if(localName.equals(TAG_PARM_NAME) && m_depth == depthOf(SAVE_PARM_NAME))
		{
			m_save[m_depth] = SAVE_PARM_NAME;
		}
		else if(localName.equals(TAG_PARM_VALUE) && m_depth == depthOf(SAVE_PARM_VALUE))
		{
			m_save[m_depth] = SAVE_PARM_VALUE;
		}
		else if(localName.equals(TAG_DESCR) && m_depth == depthOf(SAVE_DESCR))
		{
			m_save[m_depth] = SAVE_DESCR;
		}
		else if(localName.equals(TAG_LOGMSG) && m_depth == depthOf(SAVE_LOGMSG))
		{
			m_save[m_depth] = SAVE_LOGMSG;
		}
		else if(localName.equals(TAG_SEVERITY) && m_depth == depthOf(SAVE_SEVERITY))
		{
			m_save[m_depth] = SAVE_SEVERITY;
		}
		else if(localName.equals(TAG_OPERINSTR) && m_depth == depthOf(SAVE_OPERINSTRUCT))
		{
			m_save[m_depth] = SAVE_OPERINSTRUCT;
		}
		else if(localName.equals(TAG_AUTOACTION) && m_depth == depthOf(SAVE_AUTOACTION))
		{
			m_save[m_depth] = SAVE_AUTOACTION;
		}
		else if(localName.equals(TAG_OPERACTION) && m_depth == depthOf(SAVE_OPERACTION))
		{
			m_save[m_depth] = SAVE_OPERACTION;
		}
		else if(localName.equals(TAG_LOGGROUP) && m_depth == depthOf(SAVE_LOGGROUP))
		{
			m_save[m_depth] = SAVE_LOGGROUP;
		}
		else if(localName.equals(TAG_NOTIFICATION) && m_depth == depthOf(SAVE_NOTIFICATION))
		{
			m_save[m_depth] = SAVE_NOTIFICATION;
		}
		else if(localName.equals(TAG_TTICKET) && m_depth == depthOf(SAVE_TTICKET))
		{
			m_save[m_depth] = SAVE_TTICKET;
		}
		else if(localName.equals(TAG_FORWARD) && m_depth == depthOf(SAVE_FORWARD))
		{
			m_save[m_depth] = SAVE_FORWARD;
		}
		else if(localName.equals(TAG_MOUSEOVERTEXT) && m_depth == depthOf(SAVE_MOUSEOVERTEXT))
		{
			m_save[m_depth] = SAVE_MOUSEOVERTEXT;
		}
		else
		{
			throw new SAXException("Invalid tag or document format");
		}
		
		m_depth++;
	}
		
	/**
	 * At the end of the element store the current element buffer value
	 * to the appropriate buffer.
	 *
	 * Reset all the buffers at the end of each event
	 *
	 * @exception org.xml.sax.SAXException Thrown if there is an error during parse
	 */
	public void endElement(String uri, String localName, String qName) 
		throws SAXException
	{
		--m_depth;	// pop one off the depth counter!
		switch(m_save[m_depth])
		{
		case SAVE_LOG:
			if(!localName.equals(TAG_LOG))
				throw new SAXException("Invalid closing tag");
			break;
			
		case SAVE_HEADER:
			if(!localName.equals(TAG_HEADER))
				throw new SAXException("Invalid closing tag");
			break;
			
		case SAVE_HDR_VERSION:
			if(!localName.equals(TAG_VER))
				throw new SAXException("Invalid closing tag");
			
			m_header.setVersion(m_data.toString().trim());
			break;
			
		case SAVE_HDR_DPNAME:
			if(!localName.equals(TAG_DPNAME))
				throw new SAXException("Invalid closing tag");
			
			m_header.setDPName(m_data.toString().trim());
			break;
			
		case SAVE_HDR_CREATED:
			if(!localName.equals(TAG_CREATED))
				throw new SAXException("Invalid closing tag");
			
			int[] tvals = new int[6];
			for(int i = 0; i < tvals.length; i++)
				tvals[i] = -1;
			try
			{
				for(int i = 0; i < m_attributes.getLength(); i++)
				{
					if(m_attributes.getLocalName(i).equals(TAG_TIME_ATTR_YEAR))
					{
						tvals[0] = Integer.parseInt(m_attributes.getValue(i));
					}
					else if(m_attributes.getLocalName(i).equals(TAG_TIME_ATTR_MONTH))
					{
						tvals[1] = Integer.parseInt(m_attributes.getValue(i));
					}
					else if(m_attributes.getLocalName(i).equals(TAG_TIME_ATTR_DAY))
					{
						tvals[2] = Integer.parseInt(m_attributes.getValue(i));
					}
					else if(m_attributes.getLocalName(i).equals(TAG_TIME_ATTR_HOUR))
					{
						tvals[3] = Integer.parseInt(m_attributes.getValue(i));
					}
					else if(m_attributes.getLocalName(i).equals(TAG_TIME_ATTR_MIN))
					{
						tvals[4] = Integer.parseInt(m_attributes.getValue(i));
					}
					else if(m_attributes.getLocalName(i).equals(TAG_TIME_ATTR_SEC))
					{
						tvals[5] = Integer.parseInt(m_attributes.getValue(i));
					}
					else
					{
						throw new SAXException("Illegal attribute on element");
					}
				} // end for
			}
			catch(NumberFormatException ne)
			{
				throw new SAXException("Illegal created attribute value, NumberFormatException");
			}
			
			for(int i = 0; i < tvals.length; i++)
			{
				if(tvals[i] == -1)
				{
					throw new SAXException("Missing required attribute value");
				}
			}
			
			m_header.setTimestamp(new GregorianCalendar(tvals[0], tvals[1], tvals[2], tvals[3], tvals[4], tvals[5]));
			break;
			
		case SAVE_HDR_MSTATION:
			if(!localName.equals(TAG_MSTATION))
				throw new SAXException("Invalid closing tag");
			
			m_header.setMStation(m_data.toString().trim());
			break;
			
		case SAVE_EVENTS:
			if(!localName.equals(TAG_EVENTS))
				throw new SAXException("Invalid closing tag");
			break;
			
		case SAVE_EVENT:
			if(!localName.equals(TAG_EVENT))
				throw new SAXException("Invalid closing tag");
			
			if(validate(m_event))
				m_events.add(m_event);
			m_event = null;
			break;
			
		case SAVE_UEI:
			if(!localName.equals(TAG_UEI))
				throw new SAXException("Invalid closing tag");
			
			m_event.setUEI(m_data.toString().trim());
			break;
			
		case SAVE_SOURCE:
			if(!localName.equals(TAG_SOURCE))
				throw new SAXException("Invalid closing tag");
			
			m_event.setSource(m_data.toString().trim());
			break;
			
		case SAVE_TIME:
			if(!localName.equals(TAG_TIME))
				throw new SAXException("Invalid closing tag");
			
			// defined in SAVE_HDR_CREATED field
			//int[] tvals = new int[6];
			tvals = new int[6];
			for(int i = 0; i < tvals.length; i++)
				tvals[i] = -1;
			try
			{
				for(int i = 0; i < m_attributes.getLength(); i++)
				{
					if(m_attributes.getLocalName(i).equals(TAG_TIME_ATTR_YEAR))
					{
						tvals[0] = Integer.parseInt(m_attributes.getValue(i));
					}
					else if(m_attributes.getLocalName(i).equals(TAG_TIME_ATTR_MONTH))
					{
						tvals[1] = Integer.parseInt(m_attributes.getValue(i));
					}
					else if(m_attributes.getLocalName(i).equals(TAG_TIME_ATTR_DAY))
					{
						tvals[2] = Integer.parseInt(m_attributes.getValue(i));
					}
					else if(m_attributes.getLocalName(i).equals(TAG_TIME_ATTR_HOUR))
					{
						tvals[3] = Integer.parseInt(m_attributes.getValue(i));
					}
					else if(m_attributes.getLocalName(i).equals(TAG_TIME_ATTR_MIN))
					{
						tvals[4] = Integer.parseInt(m_attributes.getValue(i));
					}
					else if(m_attributes.getLocalName(i).equals(TAG_TIME_ATTR_SEC))
					{
						tvals[5] = Integer.parseInt(m_attributes.getValue(i));
					}
					else
					{
						throw new SAXException("Illegal attribute on element");
					}
				} // end for
			}
			catch(NumberFormatException ne)
			{
				throw new SAXException("Illegal time attribute value, NumberFormatException");
			}
			
			for(int i = 0; i < tvals.length; i++)
			{
				if(tvals[i] == -1)
				{
					throw new SAXException("Missing required attribute value");
				}
			}
			
			m_event.setTime(new GregorianCalendar(tvals[0], tvals[1], tvals[2], tvals[3], tvals[4], tvals[5]));
			break;
			
		case SAVE_HOST:
			if(!localName.equals(TAG_HOST))
				throw new SAXException("Invalid closing tag");
			
			m_event.setHost(m_data.toString().trim());
			break;
			
		case SAVE_SNMPHOST:
			if(!localName.equals(TAG_SNMPHOST))
				throw new SAXException("Invalid closing tag");
			
			m_event.setSnmpHost(m_data.toString().trim());
			break;
		
		case SAVE_NODEID:
			if(!localName.equals(TAG_NODEID))
				throw new SAXException("Invalid closing tag");
			
			m_event.setNodeID(m_data.toString().trim());
			break;
			
		case SAVE_SERVICE:
			if(!localName.equals(TAG_SERVICE))
				throw new SAXException("Invalid closing tag");
			
			m_event.setService(m_data.toString().trim());
			break;
			
		case SAVE_INTERFACE:
			if(!localName.equals(TAG_INTERFACE))
				throw new SAXException("Invalid closing tag");
			
			m_event.setInterface(m_data.toString().trim());
			break;
			
		case SAVE_SNMP:
			if(!localName.equals(TAG_SNMP))
				throw new SAXException("Invalid closing tag");
			
			m_event.setSnmpInfo(m_snmpInfo);
			m_snmpInfo = null;
			break;
			
		case SAVE_SNMP_EID:
			if(!localName.equals(TAG_EID))
				throw new SAXException("Invalid closing tag");
			
			m_snmpInfo.setEnterpriseID(m_data.toString().trim());
			break;
			
		case SAVE_SNMP_EIDTEXT:
			if(!localName.equals(TAG_EIDTEXT))
				throw new SAXException("Invalid closing tag");
			
			m_snmpInfo.setEnterpriseText(m_data.toString().trim());
			break;
			
		case SAVE_SNMP_SPECIFIC:
			if(!localName.equals(TAG_SPECIFIC))
				throw new SAXException("Invalid closing tag");
				
			try
			{
				m_snmpInfo.setSpecific(Integer.parseInt(m_data.toString().trim()));
			}
			catch(NumberFormatException ne)
			{
				throw new SAXException("Malformed data in document, NumberFormatException caught");
			}
			break;
			
		case SAVE_SNMP_GENERIC:
			if(!localName.equals(TAG_GENERIC))
				throw new SAXException("Invalid closing tag");
			
			try
			{
				m_snmpInfo.setGeneric(Integer.parseInt(m_data.toString().trim()));
			}
			catch(NumberFormatException ne)
			{
				throw new SAXException("Malformed data in document, NumberFormatException caught");
			}
			break;
			
		case SAVE_PARMS:
			if(!localName.equals(TAG_PARMS))
				throw new SAXException("Invalid closing tag");
			break;

		case SAVE_PARM:
			if(!localName.equals(TAG_PARM))
				throw new SAXException("Invalid closing tag");
			
			m_event.addParm(m_parm);
			m_parm = null;
			break;
			
		case SAVE_PARM_NAME:
			if(!localName.equals(TAG_PARM_NAME))
				throw new SAXException("Invalid closing tag");
			
			m_parm.setName(m_data.toString().trim());
			break;
			
		case SAVE_PARM_VALUE:
			if(!localName.equals(TAG_PARM_VALUE))
				throw new SAXException("Invalid closing tag");
			
			EventParamValue epv = new EventParamValue(m_data.toString().trim());
			for(int i = 0; i < m_attributes.getLength(); i++)
			{
				if(m_attributes.getLocalName(i).equals(TAG_TYPE))
				{
					if(m_attributes.getValue(i).equals(TAG_TYPE_ATTR_INT))
						epv.setType(EventParamValue.TYPE_INT);
					else if(m_attributes.getValue(i).equals(TAG_TYPE_ATTR_STRING))
						epv.setType(EventParamValue.TYPE_STRING);
					else if(m_attributes.getValue(i).equals(TAG_TYPE_ATTR_SNMP_INT32))
						epv.setType(EventParamValue.TYPE_SNMP_INT32);
					else if(m_attributes.getValue(i).equals(TAG_TYPE_ATTR_SNMP_OCTETSTR))
						epv.setType(EventParamValue.TYPE_SNMP_OCTET_STRING);
					else if(m_attributes.getValue(i).equals(TAG_TYPE_ATTR_SNMP_NULL))
						epv.setType(EventParamValue.TYPE_SNMP_NULL);
					else if(m_attributes.getValue(i).equals(TAG_TYPE_ATTR_SNMP_OBJECTID))
						epv.setType(EventParamValue.TYPE_SNMP_OBJECT_IDENTIFIER);
					else if(m_attributes.getValue(i).equals(TAG_TYPE_ATTR_SNMP_IPADDR))
						epv.setType(EventParamValue.TYPE_SNMP_IPADDRESS);
					else if(m_attributes.getValue(i).equals(TAG_TYPE_ATTR_SNMP_COUNTER32))
						epv.setType(EventParamValue.TYPE_SNMP_COUNTER32);
					else if(m_attributes.getValue(i).equals(TAG_TYPE_ATTR_SNMP_GAUGE32))
						epv.setType(EventParamValue.TYPE_SNMP_GAUGE32);
					else if(m_attributes.getValue(i).equals(TAG_TYPE_ATTR_SNMP_TIMETICKS))
						epv.setType(EventParamValue.TYPE_SNMP_TIMETICKS);
					else if(m_attributes.getValue(i).equals(TAG_TYPE_ATTR_SNMP_OPAQUE))
						epv.setType(EventParamValue.TYPE_SNMP_OPAQUE);
					else if(m_attributes.getValue(i).equals(TAG_TYPE_ATTR_SNMP_COUNTER64))
						epv.setType(EventParamValue.TYPE_SNMP_COUNTER64);
					else
						throw new SAXException("Illegal attribute value");
				}
				else if(m_attributes.getLocalName(i).equals(TAG_ENCODING))
				{
					if(m_attributes.getValue(i).equals(TAG_ENCODING_ATTR_TEXT))
						epv.setEncoding(EventParamValue.XML_ENCODING_TEXT);
					else if(m_attributes.getValue(i).equals(TAG_ENCODING_ATTR_BASE64))
						epv.setEncoding(EventParamValue.XML_ENCODING_BASE64);
					else
						throw new SAXException("Illegal attribute value");
				}
				else
				{
					throw new SAXException("Illegal attribute on element");
				}
			}
			m_parm.setValue(epv);
			break;
			
		case SAVE_DESCR:
			if(!localName.equals(TAG_DESCR))
				throw new SAXException("Invalid closing tag");
			
			m_event.setDescription(m_data.toString().trim());
			break;
			
		case SAVE_LOGMSG:
			if(!localName.equals(TAG_LOGMSG))
				throw new SAXException("Invalid closing tag");
			
			EventLogMessage logmsg = new EventLogMessage(m_data.toString().trim());
			for(int i = 0; i < m_attributes.getLength(); i++)
			{
				if(m_attributes.getLocalName(i).equals(TAG_LOGMSGDEST))
				{
					if(m_attributes.getValue(i).equals(TAG_LOGMSGDEST_ATTR_SUPPRESS))
						logmsg.setLogOption(EventLogMessage.SUPPRESS);
					else if(m_attributes.getValue(i).equals(TAG_LOGMSGDEST_ATTR_LOGONLY))
						logmsg.setLogOption(EventLogMessage.LOGONLY);
					else if(m_attributes.getValue(i).equals(TAG_LOGMSGDEST_ATTR_LOGNDISPLAY))
						logmsg.setLogOption(EventLogMessage.LOGNDISPLAY);
					else
						throw new SAXException("Illegal attribute value");
				}
				else
				{
					throw new SAXException("Illegal attribute on element");
				}
			}
			m_event.setLogMessage(logmsg);
			break;
			
		case SAVE_SEVERITY:
			if(!localName.equals(TAG_SEVERITY))
				throw new SAXException("Invalid closing tag");
			
			m_event.setSeverity(m_data.toString().trim());
			break;
			
		case SAVE_OPERINSTRUCT:
			if(!localName.equals(TAG_OPERINSTR))
				throw new SAXException("Invalid closing tag");
			
			m_event.setOperatorInstruction(m_data.toString().trim());
			break;
			
		case SAVE_AUTOACTION:
			if(!localName.equals(TAG_AUTOACTION))
				throw new SAXException("Invalid closing tag");
			
			m_event.addAutoAction(m_data.toString().trim());
			break;
			
		case SAVE_OPERACTION:
			if(!localName.equals(TAG_OPERACTION))
				throw new SAXException("Invalid closing tag");
			
			EventOperatorAction operaction = new EventOperatorAction(m_data.toString().trim());
			boolean bFoundAttr = false;
			for(int i = 0; i < m_attributes.getLength(); i++)
			{
				if(m_attributes.getLocalName(i).equals(TAG_OPERACTIONMENU))
				{
					operaction.setMenuText(m_attributes.getValue(i).trim());
					bFoundAttr = true;
				}
				else
				{
					throw new SAXException("Illegal attribute on element");
				}
			}
			if(!bFoundAttr)
				throw new SAXException("Missing required attributed on element");
				
			m_event.addOperatorAction(operaction);
			break;
			
		case SAVE_LOGGROUP:
			if(!localName.equals(TAG_LOGGROUP))
				throw new SAXException("Invalid closing tag");
			
			m_event.addLogGroup(m_data.toString().trim());
			break;
			
		case SAVE_NOTIFICATION:
			if(!localName.equals(TAG_NOTIFICATION))
				throw new SAXException("Invalid closing tag");
			
			m_event.addNotification(m_data.toString().trim());
			break;
			
		case SAVE_TTICKET:
			if(!localName.equals(TAG_TTICKET))
				throw new SAXException("Invalid closing tag");
			
			EventTroubleTicket tticket = new EventTroubleTicket(m_data.toString().trim());
			for(int i = 0; i < m_attributes.getLength(); i++)
			{
				if(m_attributes.getLocalName(i).equals(TAG_STATE))
				{
					if(m_attributes.getValue(i).equals(TAG_STATE_ATTR_ON))
						tticket.setState(EventTroubleTicket.STATE_ON);
					else if(m_attributes.getValue(i).equals(TAG_STATE_ATTR_OFF))
						tticket.setState(EventTroubleTicket.STATE_OFF);
					else
						throw new SAXException("Illegal attribute value");
				}
				else
				{
					throw new SAXException("Illegal attribute on element");
				}
			}
			m_event.setTroubleTicket(tticket);
			break;
			
		case SAVE_FORWARD:
			if(!localName.equals(TAG_FORWARD))
				throw new SAXException("Invalid closing tag");
			
			EventForward fwd = new EventForward(m_data.toString().trim());
			for(int i = 0; i < m_attributes.getLength(); i++)
			{
				if(m_attributes.getLocalName(i).equals(TAG_STATE))
				{
					if(m_attributes.getValue(i).equals(TAG_STATE_ATTR_ON))
						fwd.setState(EventForward.STATE_ON);
					else if(m_attributes.getValue(i).equals(TAG_STATE_ATTR_OFF))
						fwd.setState(EventForward.STATE_OFF);
					else
						throw new SAXException("Illegal attribute value");
				}
				else if(m_attributes.getLocalName(i).equals(TAG_MECHANISM))
				{
					if(m_attributes.getValue(i).equals(TAG_MECHANISM_ATTR_SNMPUDP))
						fwd.setForwardType(EventForward.FWD_SNMP_UDP);
					else if(m_attributes.getValue(i).equals(TAG_MECHANISM_ATTR_SNMPTCP))
						fwd.setForwardType(EventForward.FWD_SNMP_TCP);
					else if(m_attributes.getValue(i).equals(TAG_MECHANISM_ATTR_XMLUDP))
						fwd.setForwardType(EventForward.FWD_XML_TCP);
					else if(m_attributes.getValue(i).equals(TAG_MECHANISM_ATTR_XMLTCP))
						fwd.setForwardType(EventForward.FWD_XML_UDP);
					else
						throw new SAXException("Illegal attribute value");
				}
				else
				{
					throw new SAXException("Illegal attribute on element");
				}
			}
			//
			// save to event
			//
			m_event.addForward(fwd);
			break;
			
		case SAVE_MOUSEOVERTEXT:
			if(!localName.equals(TAG_MOUSEOVERTEXT))
				throw new SAXException("Invalid closing tag");
			
			m_event.setMouseOverText(m_data.toString().trim());
			break;
		
		default:
			throw new SAXException("Unknown closing tag encountered");
		}
		
		//
		// clear out the buffer
		//
		if(m_data.length() > 0)
			m_data.delete(0, m_data.length());
	}

	/**
	 * Store the characters of the current element in the current element
	 * value buffer
	 *
	 * @exception org.xml.sax.SAXException if there is an error during parse
	 */
	public void characters(char[] data, int offset, int length)
		throws SAXException
	{
		if((m_save[m_depth-1] & SAVE_IGNORE) != SAVE_IGNORE)
			m_data.append(data, offset, length);
	}
	
	/**
	 * Ignore the whitespaces
	 *
	 * @exception org.xml.sax.SAXException if there is an error during parse
	 */
	public void ignorableWhitespace(char[] data, int offset, int length)
		throws SAXException
	{
		// do like the method says.... ignore!
	}
	
	/**
	 * Receives processing instructions
	 *
	 * @param target	The target of the processing instruction.
	 * @param data		The processing data.
	 *
	 * @exception org.xml.sax.SAXException	Thrown if an an error occurs
	 * 	during processing
	 */
	public void processingInstruction(String target, String data)
		throws SAXException
	{
		// do nothing
	}
	
	/**
	 * Recieves notification of a skipped entity.
	 *
	 * @param name		The name of the skipped entity.
	 *
	 * @exception org.xml.sax.SAXException	Thrown if an an error occurs
	 * 	during processing
	 */
	public void skippedEntity(String name)
		throws SAXException
	{
		// do nothing
	}
	
	/**
	 * Starts a prefix to URI mapping.
	 *
	 * @param prefix	The prefix.
	 * @param uri		The namespace mapping.
	 *
	 * @exception org.xml.sax.SAXException	Thrown if an an error occurs
	 * 	during processing
	 */
	public void startPrefixMapping(String prefix, String uri)
		throws SAXException
	{
		// do nothing
	}
	
	/**
	 * Ends a prefix to URI mapping.
	 *
	 * @param prefix 	The prefix that is ending
	 *
	 * @exception org.xml.sax.SAXException	Thrown if an an error occurs
	 * 	during processing
	 */
	public void endPrefixMapping(String prefix)
		throws SAXException
	{
		// do nothing
	}
	
	/**
	 * Throw an exception if there is a warning during parse
	 *
	 * @exception org.xml.sax.SAXException if there is an error during parse
	 */
	public void warning(SAXParseException ex)
		throws SAXException
	{
		throw ex;
	}

	/**
	 * Throw an exception if there is an error during parse
	 *
	 * @exception org.xml.sax.SAXException if there is an error during parse
	 */
	public void error(SAXParseException ex)
		throws SAXException
	{
		throw ex;
	}

	/**
	 * Throw an exception if there is a fatal error during parse
	 *
	 * @exception org.xml.sax.SAXException if there is an error during parse
	 */
	public void fatalError(SAXParseException ex)
		throws SAXException
	{
		throw ex;
	}

	/** 
	 * Returns the header from the event stream
	 *
	 * @return The event header.
	 */
	public EventHeader getHeader()
	{
		return m_header;
	}
	
	/**
	 * Return the events in the stream
	 *
	 * @return the events in the stream
	 */
	public List getEvents()
	{
		return m_events;
	}
	
	/**
	 * Generates a document confomant to this parser from the 
	 * passed events.
	 *
	 * @param out		The output stream
	 * @param hdr		The header for this document
	 * @param events	The list of events to be written.
	 */
	public static void serializeToXML(OutputStream out, EventHeader hdr, List events)
	{
		serializeToXML(new PrintStream(out), hdr, events);
	}
	
	/**
	 * Generates a document confomant to this parser from the 
	 * passed events.
	 *
	 * @param out		The output stream
	 * @param hdr		The header for the document
	 * @param events	The list of events to be written.
	 */
	public static void serializeToXML(PrintStream out, EventHeader hdr, List events)
	{
		if(hdr == null || events == null || events.isEmpty())
			throw new IllegalArgumentException("The passed parameters will not generate a conformant document");
			
		startElement(out, TAG_LOG, null);
		hdr.serializeToXML(out);
		startElement(out, TAG_EVENTS, null);
		Iterator iter = events.iterator();
		while(iter.hasNext())
		{
			((Event)iter.next()).serializeToXML(out);
		}
		endElement(out, TAG_EVENTS);
		endElement(out, TAG_LOG);
	}
	
	/**
	 * Generates a document confomant to this parser from the 
	 * passed events.
	 *
	 * @param out		The output stream
	 * @param events	The list of events to be written.
	 */
	public static void serializeToXML(OutputStream out, List events)
	{
		serializeToXML(new PrintStream(out), events);
	}
	
	/**
	 * Generates a document confomant to this parser from the 
	 * passed events.
	 *
	 * @param out		The output stream
	 * @param events	The list of events to be written.
	 */
	public static void serializeToXML(PrintStream out, List events)
	{
		if(events == null || events.isEmpty())
			throw new IllegalArgumentException("The passed parameters will not generate a conformant document");
			
		startElement(out, TAG_LOG, null);
		startElement(out, TAG_EVENTS, null);
		Iterator iter = events.iterator();
		while(iter.hasNext())
		{
			((Event)iter.next()).serializeToXML(out);
		}
		endElement(out, TAG_EVENTS);
		endElement(out, TAG_LOG);
	}
	
	/**
	 * used for debugging
	 */
	public static void main(String[] args)
	{
		SAXParser		sp = new SAXParser();
		XMLEventsParser		xmlep = new XMLEventsParser();
		
		sp.setContentHandler(xmlep);
		sp.setErrorHandler(xmlep);
		
		for(int i = 0; i < args.length; i++)
		{
			try
			{
				sp.parse(new InputSource(new FileInputStream(args[i])));
				System.out.println("File " + args[i] + " parsed ok!");
				System.out.println(" There were " + xmlep.getEvents().size() + " events");
			}
			catch(Exception e)
			{
				System.out.println("File " + args[i] + " encountered errors");
				System.out.println(e.getMessage());
				e.printStackTrace();
			}
		}
	}
}


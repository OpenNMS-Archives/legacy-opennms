//
// Copyright (C) 2000 N*Manage Company, Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
// $Id: EventBase.java,v 1.3 2000/11/10 05:18:10 weave Exp $
//
package org.opennms.bb.dp.events;

import java.lang.*;
import java.util.*;
import java.io.PrintStream;
import java.io.Serializable;
import java.io.IOException; 
import java.io.PrintStream;
import java.io.OutputStream;
import org.xml.sax.helpers.AttributesImpl;

/**
 *
 * @author <A HREF="mailto:weave@opennms.org">Brian Weaver</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version CVS $Revision: 1.3 $
 *
 */
public class EventBase implements Serializable
{
	/**
	 * The Universal Event Identifier
	 */
	protected String		m_uei;
	
	/**
	 * The snmp information
	 */
	protected EventSnmpInfo		m_snmp;
	
	/**
	 * A description of the event
	 */
	protected String		m_descr;
	
	/**
	 * A log message for the event
	 */
	protected EventLogMessage	m_logmsg;
	
	/**
	 * The severity of the event
	 */
	protected String		m_severity;
	
	/**
	 * Operator instructions
	 */
	protected String		m_operinstruct;
	
	/**
	 * Automatic actions to be performed. A list of
	 * java.lang.String objects.
	 */
	protected List			m_autoaction;
	
	/**
	 * Operator actions to be performed.
	 */
	protected List			m_operaction;
	
	/**
	 * The list of log group messages.
	 */
	protected List			m_loggroup;
	
	/**
	 * The list of notification events
	 */
	protected List			m_notification;
	
	/**
	 * The trouble ticket information
	 */
	protected EventTroubleTicket	m_tticket;
	
	/**
	 * The list of forwarding information
	 */
	protected List			m_forward;
	
	/**
	 * The mouse over text for the end user console.
	 */
	protected String		m_mouseovertext;
	
	/**
	 * <P>Writes self to event stream. This implementation
	 * is based upon the format of an event object in
	 * the eventcfg.dtd, and should be compatable with the
	 * format of the event.dtd.</P>
	 *
	 * <P>Should either format diverge then derived classes
	 * cannot depend on this serialization to work correctly!</P>
	 *
	 * @param ps	The print stream to serialize to.
	 * @param includeEventTag	If true then the &lt;event&gt;...&lt;/event;&gt;
	 *	tag should wrap the data in the event.
	 */
	protected void serializeToXML(PrintStream ps, boolean includeEventTag)
	{
		if(includeEventTag)	XMLEventsParser.startElement(ps, XMLEventsParser.TAG_EVENT,  null);
		if(m_uei != null) 	XMLEventsParser.dataElement(ps, XMLEventsParser.TAG_UEI, null, m_uei);
		if(m_snmp != null) 	m_snmp.serializeToXML(ps);
		if(m_descr != null)	XMLEventsParser.dataElement(ps, XMLEventsParser.TAG_DESCR, null, m_descr);
		if(m_logmsg != null)	m_logmsg.serializeToXML(ps);
		if(m_severity != null)	XMLEventsParser.dataElement(ps, XMLEventsParser.TAG_SEVERITY, null, m_severity);
		if(m_operinstruct != null) XMLEventsParser.dataElement(ps, XMLEventsParser.TAG_OPERINSTR, null, m_operinstruct);
		if(m_autoaction != null)
		{
			Iterator iter = m_autoaction.iterator();
			while(iter.hasNext())
				XMLEventsParser.dataElement(ps, XMLEventsParser.TAG_AUTOACTION, null, (String)iter.next());
		}
		if(m_operaction != null)
		{
			Iterator iter = m_operaction.iterator();
			while(iter.hasNext())
				((EventOperatorAction)iter.next()).serializeToXML(ps);
		}
		if(m_loggroup != null)
		{
			Iterator iter = m_loggroup.iterator();
			while(iter.hasNext())
				XMLEventsParser.dataElement(ps, XMLEventsParser.TAG_LOGGROUP, null, (String)iter.next());
		}
		if(m_notification != null)
		{
			Iterator iter = m_loggroup.iterator();
			while(iter.hasNext())
				XMLEventsParser.dataElement(ps, XMLEventsParser.TAG_NOTIFICATION, null, (String)iter.next());
		}
		if(m_tticket != null)	m_tticket.serializeToXML(ps);
		if(m_forward != null)
		{
			Iterator iter = m_forward.iterator();
			while(iter.hasNext())
				((EventForward)iter.next()).serializeToXML(ps);
		}
		if(m_mouseovertext != null)	XMLEventsParser.dataElement(ps, XMLEventsParser.TAG_MOUSEOVERTEXT, null, m_mouseovertext);
		if(includeEventTag)	XMLEventsParser.endElement(ps, XMLEventsParser.TAG_EVENT);
	}

	/**
	 * Constructs a new event object with all the default values.
	 */
	public EventBase()
	{
		m_uei		= null;
		m_snmp		= null;
		m_descr		= null;
		m_logmsg	= null;
		m_severity	= null;
		m_operinstruct	= null;
		m_autoaction	= null;
		m_operaction	= null;
		m_loggroup	= null;
		m_notification	= null;
		m_tticket	= null;
		m_forward	= null;
		m_mouseovertext = null;
	}
	
	/**
	 * Constucts a new event object that is a duplicate of 
	 * the current event. This is a shallow copy and if a 
	 * list in second event is modified, then that change will
	 * also appear in this copy.
	 *
	 * @param second	The event to copy into self.
	 */
	public EventBase(Event second)
	{
		m_uei		= second.m_uei;
		m_snmp		= second.m_snmp;
		m_descr		= second.m_descr;
		m_logmsg	= second.m_logmsg;
		m_severity	= second.m_severity;
		m_operinstruct	= second.m_operinstruct;
		m_autoaction	= second.m_autoaction;
		m_operaction	= second.m_operaction;
		m_loggroup	= second.m_loggroup;
		m_notification	= second.m_notification;
		m_tticket	= second.m_tticket;
		m_forward	= second.m_forward;
		m_mouseovertext = second.m_mouseovertext;
	}
		
	/**
	 * Returns true if the event has a Universal Event Identifier.
	 */
	public boolean hasUEI()
	{
		return (m_uei != null);
	}
	
	/**
	 * Returns the universal event identifier. If no identifier is
	 * currently set then a null pointer is returned.
	 */
	public String getUEI()
	{
		return m_uei;
	}
	
	/**
	 * Sets the universal event identifier for the event. If the 
	 * identifer was previously set then it is lost.
	 *
	 * @param uei	The new identifier for the event.
	 */
	public void setUEI(String uei)
	{
		m_uei = uei;
	}
	
	/**
	 * Returns true if there is any snmp information
	 * defined for the host.
	 */
	public boolean hasSnmpInfo()
	{
		return (m_snmp != null);
	}
	
	/**
	 * Returns the current snmp information if it
	 * is defined. If there is no currently registered
	 * snmp information for the event then a null is
	 * returned.
	 *
	 */
	public EventSnmpInfo getSnmpInfo()
	{
		return m_snmp;
	}
	
	/**
	 * Sets the snmp information for the event
	 * to the passed value.
	 *
	 * @param info	The snmp information.
	 */
	public void setSnmpInfo(EventSnmpInfo info)
	{
		m_snmp = info;
	}
	
	/**
	 * Returns true if the current event has a
	 * description associated with it.
	 */
	public boolean hasDescription()
	{
		return (m_descr != null);
	}
	
	/**
	 * Returns the currently defined desription for the
	 * event, if any. If no description is currently registered
	 * then a null value is returned.
	 */
	public String getDescription()
	{
		return m_descr;
	}
	
	/**
	 * Sets the current description for the event.
	 *
	 * @param descr	The new description for the event.
	 */
	public void setDescription(String descr)
	{
		m_descr = descr;
	}
	
	/**
	 * Returns true if there is a log message that is
	 * currently associated with the event.
	 */
	public boolean hasLogMessage()
	{
		return (m_logmsg != null);
	}
	
	/**
	 * Returns the current log message for the event.
	 * If there is no log message currently defined
	 * then a null is returned to the caller.
	 */
	public EventLogMessage getLogMessage()
	{
		return m_logmsg;
	}
	
	/**
	 * Sets the log message for the current event.
	 *
	 * @param msg	The current log message for the event.
	 */
	public void setLogMessage(EventLogMessage msg)
	{
		m_logmsg = msg;
	}
	
	/**
	 * Returns true if there is a severity associated
	 * with the current event.
	 */
	public boolean hasSeverity()
	{
		return (m_severity != null);
	}
	
	/**
	 * Returns the currently associated severity for the
	 * event. If there is no defined severity then a null
	 * will be returned to the caller.
	 */
	public String getSeverity()
	{
		return m_severity;
	}
	
	/**
	 * Sets the current severity for the event.
	 * 
	 * @param severity The new severity for the event.
	 */
	public void setSeverity(String severity)
	{
		m_severity = severity;
	}
	
	/**
	 * Returns true if there is an operator instruction
	 * currently associated with the event.
	 */
	public boolean hasOperatorInstruction()
	{
		return (m_operinstruct != null);
	}
	
	/**
	 * Returns the current operator instruction for the
	 * event. If this has not been defined then a null
	 * will be returned to the caller.
	 */
	public String getOperatorInstruction()
	{
		return m_operinstruct;
	}
	
	/**
	 * Sets the operating instruction for the current
	 * event.
	 *
	 * @param instruction The new instruction for the event.
	 */
	public void setOperatorInstruction(String instruction)
	{
		m_operinstruct = instruction;
	}
	
	/**
	 * Returns true if there is at least one automatic
	 * action defined for the event.
	 */
	public boolean hasAutoActions()
	{
		return (m_autoaction != null && m_autoaction.size() > 0);
	}
	
	/**
	 * Returns the list of automatic actions. If there
	 * are no actions defined for the current event, then
	 * a null or empty list will be returned to the caller.
	 */
	public List getAutoActions()
	{
		return m_autoaction;
	}
	
	/**
	 * Allows the setting of the auto actions by
	 * passing in the complete list
	 */
	public void setAutoActions(List actions)
	{
		m_autoaction = actions;
	}
	
	/**
	 * Return the size of the automatic actions.
	 */
	public int getAutoActionsSize()
	{
		if(m_autoaction == null)
			return 0;
			
		return m_autoaction.size();
	}
	
	/**
	 * Returns the automatic action located at the
	 * specific index.
	 *
	 * @param which	The request action.
	 *
	 * @exception java.lang.IndexOutOfBoundsException Thrown if the
	 * 	requested index is out of range.
	 */
	public String getAutoAction(int which)
	{
		if(m_autoaction == null)
			throw new IndexOutOfBoundsException("There are no actions in the list");
			
		return (String) m_autoaction.get(which);
	}
	
	/**
	 * Adds a new automatic action string to the event.
	 *
	 * @param action	The new automatic action to add.
	 */
	public void addAutoAction(String action)
	{
		if(m_autoaction == null)
			m_autoaction = new ArrayList();
		
		m_autoaction.add(action);
	}
	
	/**
	 * Returns true if the operator has at least one 
	 * operator action defined for the event.
	 */
	public boolean hasOperatorActions()
	{
		return (m_operaction != null && m_operaction.size() > 0);
	}
	
	/**
	 * Returns the list of operator actions for the event.
	 * If there are no operator actions defined for the
	 * event then either a null or empty list will be returned
	 * to the caller.
	 */
	public List getOperatorActions()
	{
		return m_operaction;
	}
	
	/**
	 * Sets the list of operator actions.
	 */
	public void setOperatorActions(List ops)
	{
		m_operaction = ops;
	}
	
	/**
	 * Returns the number of actions currently defined
	 * for the event.
	 */
	public int getOperatorActionsSize()
	{
		if(m_operaction == null)
			return 0;
		
		return m_operaction.size();
	}
	
	/**
	 * Returns the specific action that is defined 
	 * at the passed index. If there is no action at
	 * the index then an exception will be thrown.
	 *
	 * @param which The index of the operator action
	 *
	 * @return The operator action at the specific location.
	 *
	 * @exception java.lang.IndexOutOfBoundsException Thrown if 
	 * 	an illegal index is requested.
	 */
	public EventOperatorAction getOperatorAction(int which)
	{
		if(m_operaction == null)
			throw new IndexOutOfBoundsException("There are currently no operator actions defined for the event");

		return (EventOperatorAction) m_operaction.get(which);
	}
	
	/**
	 * Adds a new operator action to the list of 
	 * current operator actions. If this is the first
	 * event to be added then a new list will be 
	 * allocated for the event.
	 *
	 * @param eoa	The new event operator action
	 */
	public void addOperatorAction(EventOperatorAction eoa)
	{
		if(m_operaction == null)
			m_operaction = new ArrayList();
			
		m_operaction.add(eoa);
	}
	
	/**
	 * Returns true if the event has log group information
	 */
	public boolean hasLogGroups()
	{
		return (m_loggroup != null && m_loggroup.size() > 0);
	}
	
	/**
	 * Returns the current list of log groups for the
	 * event.
	 */
	public List getLogGroups()
	{
		return m_loggroup;
	}
	
	/**
	 * Sets the log groups for the event.
	 */
	public void setLogGroups(List lgrps)
	{
		m_loggroup = lgrps;
	}
	
	/**
	 * Returns the current number of log groups 
	 * for the event.
	 */
	public int getLogGroupsSize()
	{
		if(m_loggroup == null)
			return 0;
			
		return m_loggroup.size();
	}
	
	/**
	 * Returns the specific log group located at the defined 
	 * index. If there is currently no element defined at that
	 * index then an IndexOutOfBoundsException will be generated.
	 *
	 * @param which	The index of the desired element
	 *
	 * @return The log group information at the index.
	 */
	public String getLogGroup(int which)
	{
		
		return (String) m_loggroup.get(which);
	}
	
	/**
	 * Adds a new log group to the current list of log groups.
	 * If this is the first log group to be added then a new
	 * list will be allocated to contain all the log groups.
	 *
	 * @param loggrp	The log group to add to the list.
	 */
	public void addLogGroup(String loggrp)
	{
		if(m_loggroup == null)
			m_loggroup = new ArrayList();
		
		m_loggroup.add(loggrp);
	}

	/**
	 * Returns true if there is at least one notification
	 * for the event.
	 */
	public boolean hasNotifications()
	{
		return (m_notification != null && m_notification.size() > 0);
	}
	
	/**
	 * Returns the list of notifications for the event. If there
	 * are no notifications currently defined for the event then
	 * a null will be returned to the caller. Also, the list
	 * may be empty, so the size of the list should be checked by
	 * the caller.
	 */
	public List getNotifications()
	{
		return m_notification;
	}
	
	/**
	 * Sets the notifications for the list
	 */
	public void setNotifications(List notify)
	{
		m_notification = notify;
	}
	
	/**
	 * Returns the number of notifications currently defined
	 * in the list.
	 */
	public int getNotificationsSize()
	{
		if(m_notification == null)
			return 0;
			
		return m_notification.size();
	}
	
	/**
	 * Returns the notification at the specific index defined
	 * by the passed parameter.
	 *
	 * @param which	The index of the desireed notification
	 *
	 * @return The notification string
	 *
	 * @exception java.lang.IndexOutOfBoundsException Thrown if the
	 * 	index is out of bounds or the list is empty.
	 */
	public String getNotification(int which)
	{
		if(m_notification == null)
			throw new IndexOutOfBoundsException("There are currently no notifications in the event");
			
		return (String) m_notification.get(which);
	}
	
	/**
	 * Adds a new notification ot the current event. The notification
	 * is added at the end of the list of current notifications.
	 *
	 * @param notify	The new notification string.
	 *
	 */
	public void addNotification(String notify)
	{
		if(m_notification == null)
			m_notification = new ArrayList();
		
		m_notification.add(notify);
	}
	
	/**
	 * Returns true if there is a trouble ticket currently
	 * associated with the event.
	 */
	public boolean hasTroubleTicket()
	{
		return (m_tticket != null);
	}
	
	/**
	 * Returns the trouble ticket currently associated
	 * with the event.
	 */
	public EventTroubleTicket getTroubleTicket()
	{
		return m_tticket;
	}
	
	/**
	 * Sets the current trouble ticket for the event.
	 *
	 * @param tticket The trouble ticket information for the event.
	 */
	public void setTroubleTicket(EventTroubleTicket tticket)
	{
		m_tticket = tticket;
	}

	/**
	 * Returns true if the event has forwarding information
	 */
	public boolean hasForwards()
	{
		return (m_forward != null && m_forward.size() > 0);
	}
	
	/**
	 * Returns the list of forwarding elements.
	 */
	public List getForwards()
	{
		return m_forward;
	}
	
	/**
	 * Sets the list of forwards
	 */
	public void setForwards(List fwds)
	{
		m_forward = fwds;
	}
	
	/**
	 * Returns the current number of forwarding elements in
	 * the list
	 */
	public int getForwardsSize()
	{
		if(m_forward == null)
			return 0;
			
		return m_forward.size();
	}
	
	/**
	 * Returns the forwarding information in the event
	 * at the specific index. If there is no element
	 * at the index then an exception will be generated.
	 *
	 * @param which	The event desired from the list of events.
	 *
	 * @return The event forwarding information.
	 *
	 * @exception java.lang.IndexOutOfBoundsException Thrown if
	 * 	there is no element in the list at the specific index.
	 */
	public EventForward getForward(int which)
	{
		if(m_forward == null)
				throw new IndexOutOfBoundsException("There are currently no forwarding information in the event.");
				
		return (EventForward) m_forward.get(which);
	}
	
	/**
	 * Adds a new forwarding event to the list of
	 * forwarding events.
	 */
	public void addForward(EventForward fwd)
	{
		if(m_forward == null)
			m_forward = new ArrayList();
		
		m_forward.add(fwd);
	}
	
	/**
	 * Returns true if the event has mouse over textual 
	 * information.
	 */
	public boolean hasMouseOverText()
	{
		return (m_mouseovertext != null);
	}
	
	/**
	 * Returns the current mouse over text, if any. If
	 * there is currently no text information defined then
	 * a null will be returned.
	 */
	public String getMouseOverText()
	{
		return m_mouseovertext;
	}
	
	/**
	 * Sets the current mouse over text information.
	 *
	 * @param text	The mouse over text information.
	 */
	public void setMouseOverText(String text)
	{
		m_mouseovertext = text;
	}
	
	/**
	 * Serializes the event to an XML stream.
	 *
	 * @param ostream The output stream that will receive the xml data.
	 */
	public void serializeToXML(OutputStream ostream)
	{
		PrintStream out = new PrintStream(ostream);
		
	}
	
	/**
	 * <P>Writes self to event stream. This implementation
	 * is based upon the format of an event object in
	 * the eventcfg.dtd.</P>
	 *
	 * @param ps	The print stream to serialize to.
	 */
	void serializeToXML(PrintStream ps)
	{
		serializeToXML(ps, true);
	}
}


//
// Copyright (C) 2000 N*Manage Company, Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
// $Id: EventSnmpInfo.java,v 1.4 2000/11/10 05:18:10 weave Exp $
//
package org.opennms.bb.dp.events;

import java.lang.*;
import java.io.Serializable;
import java.io.PrintStream;
import org.xml.sax.helpers.AttributesImpl;
/**
 * This class is designed to encapsulate the SNMP related
 * parts of the Event DTD into a single class. The class
 * encapsulates all the values contained in the <EM>snmp<EM>
 * element of the Event DTD.
 *
 * @author <A HREF="mailto:weave@opennms.org">Brian Weaver</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version CVS $Revision: 1.4 $
 *
 */
public class EventSnmpInfo implements Serializable
{
	/**
	 * The SNMP agent is reinitialize itself and the agent's configuration
	 * may be altered. Additionally, this is normally due to an unexpected
	 * restart due to a crash or major fault.
	 */
	public final static int		COLD_START 		= 0;
	
	/**
	 * The agent is restarting self and the configuration has not been 
	 * altered. This is normally due to a routine restarting of the agent.
	 */
	public final static int		WARM_START 		= 1;
	
	/**
	 * Signals a failure in one of the communication links for the 
	 * agent. The first element of the variable bindings is the 
	 * name and value of the ifIndex of the referenced interface.
	 */
	public final static int		LINK_DOWN  		= 2;
	
	/**
	 * Signals that a failed communication link has come back online.
	 * The first element of the variable bindings is the name and
	 * value of the ifIndex for the communication link.
	 */
	public final static int		LINK_UP	  		= 3;
	
	/**
	 * Signals that the agent received a protocol message that 
	 * failed authentication.
	 */
	public final static int		AUTHENTICATION_FAILURE 	= 4;
	
	/**
	 * Signals that an EGP neighbor with whom the sender was an EGP peer
	 * is down and the relationship no longer exist.
	 */
	public final static int		EGP_NEIGHBOR_LOSS 	= 5;
	
	/**
	 * Signals that an enterprise specific event has occured and 
	 * that the specific number, along with the enterprise id denotes
	 * the trap.
	 */
	public final static int		ENTERPRISE_SPECIFIC	= 6;
	
	/**
	 * The enterprise identifier. This is represented an object identifier
	 * and should only be present when the generic is equal to ENTERPRISE_SPECIFIC
	 */
	private String	m_eid;
	
	/**
	 * Enterprise text information, if any.
	 */
	private String	m_eidText;
	
	/**
	 * <P>The generic trap number. This must be in the range
	 * of [0..6]. This corresponds to the values:</P>
	 * <UL>
	 *	<LI>COLD_START</LI>
	 *	<LI>WARM_START</LI>
	 *	<LI>LINK_DOWN</LI>
	 *	<LI>LINK_UP</LI>
	 *	<LI>AUTHENTICATION_FAILURE</LI>
	 *	<LI>EGP_NEIGHBOR_LOSS</LI>
	 *	<LI>ENTERPRISE_SPECIFIC</LI>
	 * </UL>
	 *
	 * @see #COLD_START
	 * @see #WARM_START
	 * @see #LINK_DOWN
	 * @see #LINK_UP
	 * @see #AUTHENTICATION_FAILURE
	 * @see #EGP_NEIGHBOR_LOSS
	 * @see #ENTERPRISE_SPECIFIC
	 */
	private int	m_generic;
	
	/**
	 * The specific trap number that is specified if
	 * the generic is set to <EM>ENTERPRISE_SPECIFIC</EM>.
	 *
	 * @see #ENTERPRISE_SPECIFIC
	 */
	private int	m_specific;
	
	
	/**
	 * Writes self to event stream
	 */
	void serializeToXML(PrintStream ps)
	{
		XMLEventsParser.startElement(ps, XMLEventsParser.TAG_SNMP, null);
		
		if(m_eid != null)
			XMLEventsParser.dataElement(ps, 
						    XMLEventsParser.TAG_EID, 
						    null, 
						    m_eid);
		if(m_eidText != null) 	
			XMLEventsParser.dataElement(ps, 
						    XMLEventsParser.TAG_EIDTEXT, 
						    null, 
						    m_eidText);
		XMLEventsParser.dataElement(ps, 
					    XMLEventsParser.TAG_SPECIFIC, 
					    null, 
					    Integer.toString(m_specific));
		XMLEventsParser.dataElement(ps, 
					    XMLEventsParser.TAG_GENERIC, 
					    null, 
					    Integer.toString(m_generic));
					    
		XMLEventsParser.endElement(ps, XMLEventsParser.TAG_SNMP);
	}

	/**
	 * <P>Constructs a new instance used to represent snmp information
	 * contained in the event stream. This is normally information
	 * gleaned from a SNMP trap. The default instance is created with
	 * a generic value of COLD_START, speicific of zero, and an 
	 * enterprise id of <EM>null</EM>.</P>
	 *
	 */
	public EventSnmpInfo()
	{
		m_eid      = null;
		m_eidText  = null;
		m_generic  = COLD_START;
		m_specific = 0;
	}
	
	/**
	 * <P>Constructs a new instance that is identical to the 
	 * initial instance that is passed to the constructor.</P>
	 *
	 * @param second	The instance to copy to self.
	 */
	public EventSnmpInfo(EventSnmpInfo second)
	{
		m_eid		= second.m_eid;
		m_eidText	= second.m_eidText;
		m_generic	= second.m_generic;
		m_specific	= second.m_specific;
	}
	
	/**
	 * <P>Constructs a new instance with the generic 
	 * value. If the inforamtion pertains to an 
	 * enterprise specific trap then an alternate
	 * constructor should be used.</P>
	 *
	 * @param generic	The generic value for the trap.
	 *
	 * @see EventSnmpInfo(int,java.lang.String)
	 *
	 */
	public EventSnmpInfo(int generic)
	{
		m_generic = generic;
		m_specific= 0;
		m_eidText = null;
		m_eid     = null;
	}
	
	/**
	 * <P>Constructs a new instance with the generic value
	 * equal to ENTERPRISE_SPECIFIC, plus the passed
	 * information. The specific and enterprise identifier
	 * are set appropriately.</P>
	 *
	 * @param specific	The specific enterprise id
	 * @param eid		The enterprise object identifier.
	 */
	public EventSnmpInfo(int specific, String eid)
	{
		m_generic = ENTERPRISE_SPECIFIC;
		m_specific= specific;
		m_eid     = eid;
		m_eidText = null;
	}
	
	/**
	 * <P>Constructs a new instance with the generic value
	 * equal to ENTERPRISE_SPECIFIC, plus the passed
	 * information. The specific and enterprise identifier
	 * are set appropriately.</P>
	 *
	 * @param specific	The specific enterprise id
	 * @param eid		The enterprise object identifier.
	 * @param text		The text associated with the enterprise identifer.
	 *
	 */
	public EventSnmpInfo(int specific, String eid, String text)
	{
		m_generic = ENTERPRISE_SPECIFIC;
		m_specific= specific;
		m_eid     = eid;
		m_eidText = text;
	}
	
	/**
	 * Gets the generic trap type for the instance.
	 *
	 * @return The generic trap number.
	 *
	 * @see #COLD_START
	 * @see #WARM_START
	 * @see #LINK_DOWN
	 * @see #LINK_UP
	 * @see #AUTHENTICATION_FAILURE
	 * @see #EGP_NEIGHBOR_LOSS
	 * @see #ENTERPRISE_SPECIFIC
	 *
	 */
	public int getGeneric()
	{
		return m_generic;
	}
	
	/**
	 * Sets the generic trap type for the instance.
	 *
	 * @param generic	The generic identifier for the instance.
	 *
	 * @see #COLD_START
	 * @see #WARM_START
	 * @see #LINK_DOWN
	 * @see #LINK_UP
	 * @see #AUTHENTICATION_FAILURE
	 * @see #EGP_NEIGHBOR_LOSS
	 * @see #ENTERPRISE_SPECIFIC
	 *
	 */
	public void setGeneric(int generic)
	{
		m_generic = generic;
	}
	
	/**
	 * Returns the specific trap number for this
	 * instance.
	 *
	 * @return The specific trap number.
	 */
	public int getSpecific()
	{
		return m_specific;
	}
	
	/**
	 * Sets the specific number for this trap information.
	 * This is not normally set unless it is an enterprise
	 * specific trap number.
	 * 
	 * @param specific	The specific number for the trap.
	 *
	 */
	public void setSpecific(int specific)
	{
		m_specific = specific;
	}
	
	/**
	 * Returns the enterprise identifier for the 
	 * current instance of the object.
	 *
	 * @return The enterprise identifier, null if it was not set.
	 */
	public String getEnterpriseID()
	{
		return m_eid;
	}
	
	/**
	 * Sets the enterprise identifier for the instance.
	 * No check is performed to ensure that the actual
	 * informaiton is correct.
	 *
	 * @param eid	The enterprise identifier
	 */
	public void setEnterpriseID(String eid)
	{
		m_eid = eid;
	}
	
	/**
	 * Returns the textual inforamation associated
	 * with the enterprise identifier.
	 *
	 * @return The textual information, null if not set.
	 */
	public String getEnterpriseText()
	{
		return m_eidText;
	}
	
	/**
	 * Sets the textual information associated with
	 * the enterprise identifier.
	 *
	 * @param text	The textual information.
	 */
	public void setEnterpriseText(String text)
	{
		m_eidText = text;
	}
}
		
	

//
// Copyright (C) 2000 N*Manage Company, Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
// $Id: EventParameter.java,v 1.4 2000/11/10 05:18:10 weave Exp $
//
package org.opennms.bb.dp.events;

import java.lang.*;
import java.io.Serializable;
import java.io.PrintStream;
import org.xml.sax.helpers.AttributesImpl;
/**
 * <P>This class is designed to replicate a name/value event parameter pair
 * from an event. The object is used to model the name/value pair that appears
 * in the Event DTD for the Bluebird project.</P>
 *
 * @author <A HREF="mailto:weave@opennms.org">Brian Weaver</A>
 * @author <A HREF="http://www.opennms.org">OpenNMS</A>
 *
 * @version CVS $Revision: 1.4 $
 *
 */
public class EventParameter implements Serializable
{
	/**
	 * The parameter name
	 */
	private String		m_name;
	
	/**
	 * The parameter value.
	 */
	private EventParamValue m_value;
	
	
	/**
	 * Writes self to event stream
	 */
	void serializeToXML(PrintStream ps)
	{
		XMLEventsParser.startElement(ps, XMLEventsParser.TAG_PARM, null);
		XMLEventsParser.dataElement(ps, XMLEventsParser.TAG_PARM_NAME, null, m_name);
		m_value.serializeToXML(ps);
		XMLEventsParser.endElement(ps, XMLEventsParser.TAG_PARM);
	}
	
	/**
	 * Constructs a new instance of the class with the
	 * default values of an empty string and empty value.
	 */
	public EventParameter()
	{
		m_name = "";
		m_value= new EventParamValue();
	}
	
	/**
	 * Constructs a new instance with the specific name and
	 * a default value.
	 *
	 * @param name	The name of the new name/value pair
	 */
	public EventParameter(String name)
	{
		m_name  = name;
		m_value = new EventParamValue();
	}
	
	/**
	 * Constructs a new instance with the specific name and 
	 * value.
	 *
	 * @param name	The name for the new name/value pair.
	 * @param value	The value for the new name/value pair.
	 *
	 */
	public EventParameter(String name, EventParamValue value)
	{
		m_name = name;
		m_value= value;
	}
	
	/**
	 * Returns the name of the parameter.
	 */
	public String getName()
	{
		return m_name;
	}
	
	/**
	 * Sets the name of the parameter.
	 *
	 * @param name	The new name for the parameter.
	 */
	public void setName(String name)
	{
		m_name = name;
	}
	
	/**
	 * Returns the value for the parameter.
	 */
	public EventParamValue getValue()
	{
		return m_value;
	}
	
	/**
	 * Sets the value for the parameter.
	 *
	 * @param value	The new value for the parameter.
	 */
	public void setValue(EventParamValue value)
	{
		m_value = value;
	}
	
	/**
	 * Sets the name/value pair for hte parameter.
	 *
	 * @param name		The new name for the instance.
	 * @param value		The new value for the instance.
	 */
	public void set(String name, EventParamValue value)
	{
		m_name = name;
		m_value = value;
	}
}


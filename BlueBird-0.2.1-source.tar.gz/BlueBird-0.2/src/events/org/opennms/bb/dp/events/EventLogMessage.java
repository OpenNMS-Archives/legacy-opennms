//
// Copyright (C) 2000 N*Manage Company, Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
// $Id: EventLogMessage.java,v 1.4 2000/11/10 05:18:10 weave Exp $
//
package org.opennms.bb.dp.events;

import java.lang.*;
import java.io.Serializable;
import java.io.PrintStream;
import org.xml.sax.helpers.AttributesImpl;
/**
 * This class is designed to encapsulate the <EM>logmsg</EM> element
 * contained in the Event DTD. It contains the textual log message
 * and the destination attribute value, as defined by the DTD.
 *
 * @author <A HREF="mailto:weave@opennms.org">Brian Weaver</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version CVS $Revision: 1.4 $
 *
 */
public class EventLogMessage implements Serializable
{
	/**
	 * The log option for Logging the message and displaying
	 * the message in the event browser.
	 */
	public static final int		LOGNDISPLAY	= 0;
	
	/**
	 * The log option for only writting the message to 
	 * permanent storage. No display of the message is
	 * performed.
	 */
	public static final int		LOGONLY		= 1;
	
	/**
	 * The log option for suppressing the event in both the
	 * permanent storage and the realtime console.
	 */
	public static final int		SUPPRESS 	= 2;
	
	/**
	 * The log options
	 */
	private int	m_how;
	
	/**
	 * The log message
	 */
	private String	m_message;
	
	/**
	 * Writes self to event stream
	 */
	void serializeToXML(PrintStream ps)
	{
		AttributesImpl attr = new AttributesImpl();
		switch(m_how)
		{
		case SUPPRESS:
			attr.addAttribute("", 
					  XMLEventsParser.TAG_LOGMSGDEST, 
					  XMLEventsParser.TAG_LOGMSGDEST, 
					  "CDATA", 
					  XMLEventsParser.TAG_LOGMSGDEST_ATTR_SUPPRESS);
			break;
		case LOGONLY:
			attr.addAttribute("", 
					  XMLEventsParser.TAG_LOGMSGDEST, 
					  XMLEventsParser.TAG_LOGMSGDEST, 
					  "CDATA", 
					  XMLEventsParser.TAG_LOGMSGDEST_ATTR_LOGONLY);
			break;
		case LOGNDISPLAY:
			attr.addAttribute("", 
					  XMLEventsParser.TAG_LOGMSGDEST, 
					  XMLEventsParser.TAG_LOGMSGDEST, 
					  "CDATA", 
					  XMLEventsParser.TAG_LOGMSGDEST_ATTR_LOGNDISPLAY);
			break;
		}
		XMLEventsParser.dataElement(ps, XMLEventsParser.TAG_LOGMSG, attr, m_message);
	}
	
	/**
	 * Constructs a new log message instance. This format is described
	 * in the Event DTD under the element <EM>logmsg</EM>.
	 */
	public EventLogMessage()
	{
		m_how = LOGNDISPLAY;
		m_message = "";
	}
	
	/**
	 * Constructs a new instance with the same 
	 * data as the passed instance. This is in essance 
	 * a copy constructor.
	 *
	 * @param second	The object to be copied into self.
	 */
	public EventLogMessage(EventLogMessage second)
	{
		m_how = second.m_how;
		m_message = second.m_message;
	}
	
	/** 
	 * Constructs a new instance with the log message
	 * equal to the passed value and the log option
	 * equal to <EM>LOGNDISPLAY</EM>.
	 *
	 * @param message	The message text
	 *
	 * @see #LOGNDISPLAY
	 */
	public EventLogMessage(String message)
	{
		m_how = LOGNDISPLAY;
		m_message = message;
	}
	
	/**
	 * Constructs a new instance with the specific message
	 * and log option. 
	 *
	 * @param message	The log message.
	 * @param logopt	The log option.
	 *
	 * @see #LOGNDISPLAY
	 * @see #LOGONLY
	 * @see #SUPPRESS
	 */
	public EventLogMessage(String message, int logopt)
	{
		m_how = logopt;
		m_message = message;
	}
	
	/**
	 * Returns the log option for this instance.
	 *
	 * @return The log option.
	 */
	public int getLogOption()
	{
		return m_how;
	}
	
	/**
	 * Sets the log option for this instance.
	 *
	 * @param logopt	The log option.
	 */
	public void setLogOption(int logopt)
	{
		m_how = logopt;
	}
	
	/**
	 * Returns the message text associated with
	 * this log message.
	 *
	 * @return The log message text.
	 */
	public String getMessage()
	{
		return m_message;
	}
	
	/**
	 * Sets the log message text.
	 *
	 * @param message	The new log message.
	 */
	public void setMessage(String message)
	{
		m_message = message;
	}
	
	/**
	 * Sets the message and log option for this
	 * object's instance. This allows both the
	 * message and option to be set in one call.
	 *
	 * @param message	The new message text.
	 * @param logopt	The log option for this instance.
	 */
	public void set(String message, int logopt)
	{
		m_message = message;
		m_how = logopt;
	}
}

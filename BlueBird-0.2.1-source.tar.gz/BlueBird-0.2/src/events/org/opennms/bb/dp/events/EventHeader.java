//
// Copyright (C) 2000 N*Manage Company, Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
// %Id$
//
package org.opennms.bb.dp.events;

import java.lang.*;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Date;
import java.io.Serializable;
import java.io.PrintStream;
import org.xml.sax.helpers.AttributesImpl;

/**
 * <P>EventHeader holds data from the <header>..</header> block in the incoming
 * event stream. This is usually the same information that is contained in
 * the headers from all the DTDs that describe documents that are sent between
 * two different processes.</P>
 *
 * @author 	<A HREF="mailto:sowmya@opennms.org">Sowmya Kumaraswamy</A>
 * @author	<A HREF="mailto:weave@opennsm.org">Brian Weaver</A>
 * @author	<A HREF="http://www.opennms.org/">OpenNMS.org</A>
 *
 * @version	$Revision: 1.4 $
 */
public class EventHeader implements Serializable
{
	/**
	 * the dtd version used
	 */
	private String		m_ver;

	/**
	 * the distributed poller sending the events
	 */
	private String		m_dpName;

	/**
	 * the creation date of this event stream
	 */
	private Calendar	m_created;

	/**
	 * master station associated with the poller sending the event
	 */
	private String		m_mstation;
	
	/**
	 * Writes self to event stream
	 */
	void serializeToXML(PrintStream ps)
	{
		XMLEventsParser.startElement(ps, XMLEventsParser.TAG_HEADER,  null);
		XMLEventsParser.dataElement(ps, XMLEventsParser.TAG_VER,      null, m_ver == null ? "" : m_ver);
		XMLEventsParser.dataElement(ps, XMLEventsParser.TAG_DPNAME,   null, m_dpName == null ? "" : m_dpName);
		
		AttributesImpl attr = new AttributesImpl();
		if(m_created != null)
		{
			attr.addAttribute("", XMLEventsParser.TAG_TIME_ATTR_YEAR, XMLEventsParser.TAG_TIME_ATTR_YEAR,  "CDATA", Integer.toString(m_created.get(Calendar.YEAR)));
			attr.addAttribute("", XMLEventsParser.TAG_TIME_ATTR_MONTH,XMLEventsParser.TAG_TIME_ATTR_MONTH, "CDATA", Integer.toString(m_created.get(Calendar.MONTH)));
			attr.addAttribute("", XMLEventsParser.TAG_TIME_ATTR_DAY,  XMLEventsParser.TAG_TIME_ATTR_DAY,   "CDATA", Integer.toString(m_created.get(Calendar.DAY_OF_MONTH)));
			attr.addAttribute("", XMLEventsParser.TAG_TIME_ATTR_HOUR, XMLEventsParser.TAG_TIME_ATTR_HOUR,  "CDATA", Integer.toString(m_created.get(Calendar.HOUR)));
			attr.addAttribute("", XMLEventsParser.TAG_TIME_ATTR_MIN,  XMLEventsParser.TAG_TIME_ATTR_MIN,   "CDATA", Integer.toString(m_created.get(Calendar.MINUTE)));
			attr.addAttribute("", XMLEventsParser.TAG_TIME_ATTR_SEC,  XMLEventsParser.TAG_TIME_ATTR_SEC,   "CDATA", Integer.toString(m_created.get(Calendar.SECOND)));
			XMLEventsParser.dataElement(ps, XMLEventsParser.TAG_CREATED,  attr, Long.toString(m_created.getTime().getTime()));
		}
		else
			XMLEventsParser.dataElement(ps, XMLEventsParser.TAG_CREATED,  attr, "");
			
		XMLEventsParser.dataElement(ps, XMLEventsParser.TAG_MSTATION, null, m_mstation == null ? "" : m_mstation);
		XMLEventsParser.endElement(ps, XMLEventsParser.TAG_HEADER);
	}
	
	/**
	 * <P>Constructs a new event header object with
	 * the default values. The default values are
	 * null for all string elements and the singular
	 * calendar element is initialized to the current 
	 * time.</P.
	 *
	 */
	public EventHeader()
	{
		m_ver     = null;
		m_dpName  = null;
		m_created = new GregorianCalendar();
		m_mstation = null;
	}
	
	/**
	 * <P>Construct a new event header object that is 
	 * a duplicate of the passed object. For all
	 * purposes the new instances is an <EM>exact</EM>
	 * copy of the passed value.</P>
	 *
	 * @param second	The instance to be copied.
	 *
	 */
	public EventHeader(EventHeader second)
	{
		m_ver 		= second.m_ver;
		m_dpName	= second.m_dpName;
		m_mstation	= second.m_mstation;
		m_created	= new GregorianCalendar();
		m_created.setTime(second.m_created.getTime());
	}

	/**
	 * Constructs a EventHeader object with all the specific value.
	 * 
	 * @param ver		The version of the header
	 * @param dpName	The distributed poller name from the header.
	 * @param mstation	The configured master station for the poller.
	 * @param created	The header's timestamp.
	 */
	public EventHeader(String ver, String dpName, String mstation, Calendar created)
	{
		m_ver		= ver;
		m_dpName	= dpName;
		m_mstation	= mstation;
		m_created	= new GregorianCalendar();
		m_created.setTime(created.getTime());
	}
	
	/**
	 * Returns the current version text.
	 */
	public String getVersion()
	{
		return m_ver;
	}
	
	/**
	  * Sets the version string for the header
	  *
	  * @param version 	The version information for the header.
	  */
	public void setVersion(String version)
	{
		m_ver = version;
	}
	
	/**
	 * Returns the distributed poller name
	 *
	 */
	public String getDPName()
	{
		return m_dpName;
	}
	
	/**
	 * Sets the distributed poller name
	 *
	 * @param dpName	The distributed poller name.
	 */
	public void setDPName(String dpName)
	{
		m_dpName = dpName;
	}
	
	/**
	 * Returns the master station address information
	 *
	 */
	public String getMStation()
	{
		return m_mstation;
	}
	
	/**
	 * Sets the master station field
	 *
	 * @param mstation	The new text for the master staion.
	 *
	 */
	public void setMStation(String mstation)
	{
		m_mstation = mstation;
	}
	
	/**
	 * Returns the time when the header was created.
	 *
	 */	
	public Calendar getTimestamp()
	{
		return m_created;
	}
	
	/**
	 * Sets the time that the header was created.
	 *
	 * @param d	The date the header was created.
	 */
	public void setTimestamp(Calendar c)
	{
		setTimestamp(c.getTime());
	}
	
	/**
	 * Sets the time that the header was created.
	 *
	 * @param d	The date the header was created.
	 */
	public void setTimestamp(Date d)
	{
		if(m_created == null)
			m_created = new GregorianCalendar();
		
		m_created.setTime(d);
	}	
}

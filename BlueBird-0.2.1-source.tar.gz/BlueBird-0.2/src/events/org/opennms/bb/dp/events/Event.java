//
// Copyright (C) 2000 N*Manage Company, Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
// $Id: Event.java,v 1.6 2000/11/13 21:21:34 mike Exp $
//
package org.opennms.bb.dp.events;

import java.lang.*;
import java.util.*;
import java.io.PrintStream;
import java.io.Serializable;
import java.io.IOException; 
import java.io.PrintStream;
import java.io.OutputStream;
import org.xml.sax.helpers.AttributesImpl;

/**
 *
 * @author <A HREF="mailto:weave@opennms.org">Brian Weaver</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version CVS $Revision: 1.6 $
 *
 */
public class Event extends EventBase
{
	/**
	 * The source of the event, this is a required field
	 */
	private String			m_source;
	
	/**
	 * The time of the event.
	 */
	private Calendar		m_time;
	
	/**
	 * The host that generated the event
	 */
	private String			m_host;
	
	/**
	 * The snmp host that generated the trap
	 */
	private String			m_snmphost;
	
	/**
	 * The node identifier.
	 */
	private String			m_nodeid;
	
	/**
	 * The service name
	 */
	private String			m_service;
	
	/**
	 * The interface name
	 */
	private String			m_interface;
	
	/**
	 * The EventParameter objects
	 */
	private List			m_parms;
	
	/**
	 * Constructs a new event object with all the default values.
	 */
	public Event()
	{
		super();
		m_source	= null;
		m_time  	= null;
		m_host  	= null;
		m_snmphost 	= null;
		m_service	= null;
		m_nodeid	= null;
		m_interface	= null;
		m_parms		= null;
	}
	
	/**
	 * Constucts a new event object that is a duplicate of 
	 * the current event. This is a shallow copy and if a 
	 * list in second event is modified, then that change will
	 * also appear in this copy.
	 *
	 * @param second	The event to copy into self.
	 */
	public Event(Event second)
	{
		super(second);
		m_source	= second.m_source;
		m_time  	= second.m_time;
		m_host  	= second.m_host;
		m_snmphost 	= second.m_snmphost;
		m_nodeid	= second.m_nodeid;
		m_service	= second.m_service;
		m_interface	= second.m_interface;
		m_parms		= second.m_parms;
	}
	
	/**
	 * Construct a new event from the specific source.
	 * 
	 * @param source	The source of the event.
	 */
	public Event(String source)
	{
		this();
		m_source = source;
	}
	
	/**
	 * Returns the source for the event. As defined in the DTD an
	 * event must have a source, but if one has not be defined
	 * for the event object then a null is returned.
	 */
	public String getSource()
	{
		return m_source;
	}
	
	/**
	 * Sets the current source string for the event. If a source
	 * was previously defined then it is lost. 
	 *
	 * @param source	The new source for the event.
	 */
	public void setSource(String source)
	{
		m_source = source;
	}
	
	/** 
	 * Returns true if the event has a time associated
	 * with the event.
	 */
	public boolean hasTime()
	{
		return (m_time != null);
	}
	
	/**
	 * Returns the current time associataed with the
	 * event. If the time was not set for this event
	 * then a null value is returned to the caller.
	 */
	public Calendar getTime()
	{
		return m_time;
	}
	
	/**
	 * Sets the time for the event to be equal to
	 * the passed time.
	 *
	 * @param time	The new time for the event.
	 */
	public void setTime(Calendar time)
	{
		m_time = time;
	}
	
	/**
	 * Sets the current time for the event.
	 *
	 * @param time	The time for the event.
	 */
	public void setTime(Date time)
	{
		m_time = new GregorianCalendar();
		m_time.setTime(time);
	}
	
	/**
	 * Sets the current time based on the epoch
	 * time passed to the call.
	 *
	 * @param time	The epoch time for the event.
	 */
	public void setTime(long time)
	{
		m_time = new GregorianCalendar();
		m_time.setTime(new Date(time));
	}
	
	/**
	 * Returns true if a host is currently defined
	 * for the event.
	 */
	public boolean hasHost()
	{
		return (m_host != null);
	}
	
	/**
	 * Returns the currently defined host for the event.
	 * If no host is defined for the event then a null
	 * is returned to the caller.
	 */
	public String getHost()
	{
		return m_host;
	}
	
	/**
	 * Sets the host for the event.
	 *
	 * @param host	The host for the event.
	 */
	public void setHost(String host)
	{
		m_host = host;
	}
	
	/**
	 * Returns true if the snmphost for the event
	 * is set.
	 */
	public boolean hasSnmpHost()
	{
		return (m_snmphost != null);
	}
	
	/**
	 * Returns the snmphost for the event, if any.
	 * If no snmphost is defined for the event then
	 * a null is returned.
	 */
	public String getSnmpHost()
	{
		return m_snmphost;
	}
	
	/**
	 * Sets the current snmp host for the event.
	 *
	 * @param host	The snmp host information
	 */
	public void setSnmpHost(String host)
	{
		m_snmphost = host;
	}
	
	/**
	 * Returns true if the node identification 
	 * is currently set for the event.
	 */
	public boolean hasNodeID()
	{
		return (m_nodeid != null);
	}
	
	/**
	 * Returns the current node identifier for
	 * the event.
	 */
	public String getNodeID()
	{
		return m_nodeid;
	}
	
	/**
	 * Sets the node identifier for the current
	 * service.
	 *
	 * @param id	The new node identification.
	 */
	public void setNodeID(String id)
	{
		m_nodeid = id;
	}
	
	/**
	 * Returns true if there is a service currently
	 * defined for the event.
	 */
	public boolean hasService()
	{
		return (m_service != null);
	}
	
	/**
	 * Returns the current service for the event. If
	 * no service is currently defined then a null
	 * is returned to the caller.
	 */
	public String getService()
	{
		return m_service;
	}
	
	/**
	 * Sets the current service for the event.
	 *
	 * @param service	The new service for the event.
	 */
	public void setService(String service)
	{
		m_service = service;
	}
	
	/**
	 * Returns true if the interface is currently set for
	 * the event.
	 */
	public boolean hasInterface()
	{
		return (m_interface != null);
	}
	
	/**
	 * Returns the currently defined interface for the event.
	 * If no interface has been defined then a null will
	 * be returned to the caller.
	 */
	public String getInterface()
	{
		return m_interface;
	}
	
	/**
	 * Sets the current interface for the  event
	 *
	 * @param iface The new interface for the event.
	 */
	public void setInterface(String iface)
	{
		m_interface = iface;
	}
	
	/**
	 * Returns true if the event has at least one
	 * parameter defined for the event.
	 */
	public boolean hasParms()
	{
		return (m_parms != null && m_parms.size() > 0);
	}
	
	/**
	 * returns the current list of parameters for
	 * the event. If there are no parameters defined
	 * then a null may be returned by this call.
	 *
	 */
	public List getParms()
	{
		return m_parms;
	}
	
	/**
	 * Returns the current number of parameters
	 * in the list.
	 */
	public int getParmsSize()
	{
		if(m_parms == null)
			return 0;
			
		return m_parms.size();
	}
	
	/**
	 * Returns the parameter at the specific index.
	 * If the index is out of range then an IndexOutOfBoundsException
	 * will be generated.
	 *
	 * @param which	The index of the desired parameter.
	 *
	 * @return The indexed parameter.
	 *
	 * @exception java.lang.IndexOutOfBoundsException Thrown if the index
	 * 	is greater than the size of the list.
	 */
	public EventParameter getParm(int which)
	{
		if(m_parms == null || which < 0)
			throw new IndexOutOfBoundsException("There are no elements or list");
			
		return (EventParameter) m_parms.get(which);
	}
	
	/**
	 * Adds a new parameter value to the currently 
	 * defined list. If this is the first parameter then
	 * a list will be allocated internally to store the
	 * new parameter, and any subsequent ones.
	 *
	 * @param parm	THe parameter to add to the list.
	 */
	public void addParm(EventParameter parm)
	{
		if(m_parms == null)
			m_parms = new ArrayList();
			
		m_parms.add(parm);
	}

	/**
	 * <P>Writes self to event stream. This implementation
	 * is based upon the format of an event object in
	 * the event.dtd.</P>
	 *
	 * @param ps	The print stream to serialize to.
	 */
	void serializeToXML(PrintStream ps)
	{
		XMLEventsParser.startElement(ps, XMLEventsParser.TAG_EVENT,  null);
		if(m_uei != null) 	XMLEventsParser.dataElement(ps, XMLEventsParser.TAG_UEI, null, m_uei);
					XMLEventsParser.dataElement(ps, XMLEventsParser.TAG_SOURCE, null, m_source == null ? "" : m_source);
		if(m_nodeid != null) 	XMLEventsParser.dataElement(ps, XMLEventsParser.TAG_NODEID, null, m_nodeid);
		if(m_time != null)
		{
			AttributesImpl attr = new AttributesImpl();
			attr.addAttribute("", XMLEventsParser.TAG_TIME_ATTR_YEAR, XMLEventsParser.TAG_TIME_ATTR_YEAR,  "CDATA", Integer.toString(m_time.get(Calendar.YEAR)));
			attr.addAttribute("", XMLEventsParser.TAG_TIME_ATTR_MONTH,XMLEventsParser.TAG_TIME_ATTR_MONTH, "CDATA", Integer.toString(m_time.get(Calendar.MONTH)));
			attr.addAttribute("", XMLEventsParser.TAG_TIME_ATTR_DAY,  XMLEventsParser.TAG_TIME_ATTR_DAY,   "CDATA", Integer.toString(m_time.get(Calendar.DAY_OF_MONTH)));
			attr.addAttribute("", XMLEventsParser.TAG_TIME_ATTR_HOUR, XMLEventsParser.TAG_TIME_ATTR_HOUR,  "CDATA", Integer.toString(m_time.get(Calendar.HOUR)));
			attr.addAttribute("", XMLEventsParser.TAG_TIME_ATTR_MIN,  XMLEventsParser.TAG_TIME_ATTR_MIN,   "CDATA", Integer.toString(m_time.get(Calendar.MINUTE)));
			attr.addAttribute("", XMLEventsParser.TAG_TIME_ATTR_SEC,  XMLEventsParser.TAG_TIME_ATTR_SEC,   "CDATA", Integer.toString(m_time.get(Calendar.SECOND)));
			XMLEventsParser.dataElement(ps, XMLEventsParser.TAG_TIME,  attr, Long.toString(m_time.getTime().getTime()));
		}
		if(m_host != null)	XMLEventsParser.dataElement(ps, XMLEventsParser.TAG_HOST, null, m_host);
		if(m_interface != null)	XMLEventsParser.dataElement(ps, XMLEventsParser.TAG_INTERFACE, null, m_interface);
		if(m_snmphost != null)  XMLEventsParser.dataElement(ps, XMLEventsParser.TAG_SNMPHOST, null, m_snmphost);
		if(m_service != null)	XMLEventsParser.dataElement(ps, XMLEventsParser.TAG_SERVICE, null, m_service);
		if(m_snmp != null) 	m_snmp.serializeToXML(ps);
		if(m_parms != null)
		{
			XMLEventsParser.startElement(ps, XMLEventsParser.TAG_PARMS, null);
			Iterator iter = m_parms.iterator();
			while(iter.hasNext())
			{
				((EventParameter)iter.next()).serializeToXML(ps);
			}
			XMLEventsParser.endElement(ps, XMLEventsParser.TAG_PARMS);
		}
		if(m_descr != null)	XMLEventsParser.dataElement(ps, XMLEventsParser.TAG_DESCR, null, m_descr);
		if(m_logmsg != null)	m_logmsg.serializeToXML(ps);
		if(m_severity != null)	XMLEventsParser.dataElement(ps, XMLEventsParser.TAG_SEVERITY, null, m_severity);
		if(m_operinstruct != null) XMLEventsParser.dataElement(ps, XMLEventsParser.TAG_OPERINSTR, null, m_operinstruct);
		if(m_autoaction != null)
		{
			Iterator iter = m_autoaction.iterator();
			while(iter.hasNext())
				XMLEventsParser.dataElement(ps, XMLEventsParser.TAG_AUTOACTION, null, (String)iter.next());
		}
		if(m_operaction != null)
		{
			Iterator iter = m_operaction.iterator();
			while(iter.hasNext())
				((EventOperatorAction)iter.next()).serializeToXML(ps);
		}
		if(m_loggroup != null)
		{
			Iterator iter = m_loggroup.iterator();
			while(iter.hasNext())
				XMLEventsParser.dataElement(ps, XMLEventsParser.TAG_LOGGROUP, null, (String)iter.next());
		}
		if(m_notification != null)
		{
			Iterator iter = m_notification.iterator();
			while(iter.hasNext())
				XMLEventsParser.dataElement(ps, XMLEventsParser.TAG_NOTIFICATION, null, (String)iter.next());
		}
		if(m_tticket != null)	m_tticket.serializeToXML(ps);
		if(m_forward != null)
		{
			Iterator iter = m_forward.iterator();
			while(iter.hasNext())
				((EventForward)iter.next()).serializeToXML(ps);
		}
		if(m_mouseovertext != null)	XMLEventsParser.dataElement(ps, XMLEventsParser.TAG_MOUSEOVERTEXT, null, m_mouseovertext);
		XMLEventsParser.endElement(ps, XMLEventsParser.TAG_EVENT);
	}
}


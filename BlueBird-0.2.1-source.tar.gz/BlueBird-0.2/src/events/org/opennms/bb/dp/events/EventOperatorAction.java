//
// Copyright (C) 2000 N*Manage Company, Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
// $Id: EventOperatorAction.java,v 1.4 2000/11/10 05:18:10 weave Exp $
//
package org.opennms.bb.dp.events;

import java.lang.*;
import java.io.Serializable;
import java.io.PrintStream;
import org.xml.sax.helpers.AttributesImpl;
/**
 * This class is designed to encapsulate the information in
 * the <EM>operaction</EM> element of the Event DTD. This
 * class collects the appropriate required attribute value
 * with the actual data in the node.</P>
 *
 * @author <A HREF="mailto:weave@opennms.org">Brian Weaver</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version CVS $Revision: 1.4 $
 *
 */
public class EventOperatorAction implements Serializable
{
	/**
	 * The operator action string.
	 */
	private String	m_action;
	
	/**
	 * The menu text for the action
	 */
	private String 	m_menutext;
	
	/**
	 * Writes self to event stream
	 */
	void serializeToXML(PrintStream ps)
	{
		AttributesImpl attr = new AttributesImpl();
		attr.addAttribute("", 
				  XMLEventsParser.TAG_OPERACTIONMENU, 
				  XMLEventsParser.TAG_OPERACTIONMENU, 
				  "CDATA", 
				  m_menutext == null ? "" : m_menutext);
		XMLEventsParser.dataElement(ps, XMLEventsParser.TAG_OPERACTION, attr, m_action);
	}

	/**
	 * Constructs a new operator action instance
	 * for the event stream. The default values are
	 * set to null.
	 */
	public EventOperatorAction()
	{
		m_action = null;
		m_menutext = null;
	}
	
	/**
	 * Constructs a new instance of the class and copies
	 * the data from the passed instance.
	 *
	 * @param second	The object to be copied to self.
	 *
	 */
	public EventOperatorAction(EventOperatorAction second)
	{
		m_action = second.m_action;
		m_menutext = second.m_menutext;
	}

	/**
	 * Constructs a new instance of the class with the
	 * passed values.
	 *
	 * @param action	The action string for the operator.
	 *
	 */
	public EventOperatorAction(String action)
	{
		m_action   = action;
		m_menutext = null;
	}
	
	/**
	 * Constructs a new instance of the class with the
	 * passed values.
	 *
	 * @param action	The action string for the operator.
	 * @param menutext	The menu text for the operator action.
	 *
	 */
	public EventOperatorAction(String action, String menutext)
	{
		m_action = action;
		m_menutext = menutext;
	}
	
	/**
	 * Sets the current object's value to the 
	 * new values passed in this method.
	 *
	 * @param action	The operator action text
	 * @param menutext	The menu text for the action.
	 *
	 */
	public void set(String action, String menutext)
	{
		m_action = action;
		m_menutext = menutext;
	}
	
	/**
	 * Sets the action test for the current instance.
	 *
	 * @param action	The new action text.
	 */
	public void setAction(String action)
	{
		m_action = action;
	}
	
	/**
	 * Returns the current action registered 
	 * in this object's instance.
	 *
	 * @return The action text.
	 *
	 */
	public String getAction()
	{
		return m_action;
	}
	
	/**
	 * Sets the current menu text for the operator
	 * action.
	 *
	 * @param menutext	The menu text for the action.
	 *
	 */
	public void setMenuText(String menutext)
	{
		m_menutext = menutext;
	}
	
	/**
	 * Returns the current menu text that
	 * is associated with the operator action.
	 *
	 * @return The menu text.
	 */
	public String getMenuText()
	{
		return m_menutext;
	}
}

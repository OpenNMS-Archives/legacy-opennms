//
// Copyright (C) 2000 N*Manage Company Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
// Tab Size = 8
//
// $Id: IPAddressRange.java,v 1.5 2000/08/01 17:12:11 weave Exp $
//

package org.opennms.bb.dp.discovery.components;

import java.lang.*;
import java.net.*;
import java.util.*;

/**
 * <P>The IPAddressRange object is used to encapsulate the
 * starting and ending points of a continguous IPv4 Address
 * range. The class can then generate either an Enumeration
 * or Iterator that can be used to cycle through the range
 * of addresses by the object's user.</P>
 *
 *
 * @author <A HREF="mailto:sowmya@opennms.org">Sowmya</A>
 * @author <A HREF="mailto:weave@opennms.org">Brian Weaver</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version $Revision: 1.5 $
 */
public class IPAddressRange
{
	/**
	 * The starting address for the object.
	 */
	private long m_begin;
	
	/**
	 * The ending address for the object.
	 */
	private long m_end;

	/**
	 * <P>Converts an 8-bit byte to a 64-bit
	 * long integer. If the quantity is
	 * a sign extended negative number then
	 * the value of 256 is added to wrap the
	 * conversion into the range of [0..255]. </P>
	 *
	 * @param b	The byte to convert
	 *
	 * @return 	The converted 64-bit unsigned value.
	 */
	private static long byteToLong(byte b)
	{
		long r = (long)b;
		if(r < 0) 
			r+= 256;
		return r;
	}
	
	/**
	 * <P>The convertToLong method takes an array of bytes 
	 * and shifts them into a long value. The bytes at the
	 * front of the array are shifted into the MSB of the 
	 * long as each new byte is added to the LSB of the long.
	 * if the array is of sufficent size the first bytes of 
	 * the array may be shifted out of the returned long.</P>
	 *
	 * @param addr	The array to convert to a long.
	 *
	 * @return The created long value.
	 *
	 * @exception IllegalArgumentException	Thrown if the addr
	 * 	parameter is null.
	 *
	 */
	private static long convertToLong(byte[] addr)
	{
		if(addr == null)
			throw new IllegalArgumentException("The passed array must not be null");

		long address=0;
		for(int i = 0; i < addr.length; i++)
		{
			address <<= 8;
			address |= byteToLong(addr[i]);
		}
	 	return address;
	}

	/**
	 * <P>Creates a new IPAddressRange object that can be used
	 * to encapsulate a contiguous range of IP Addresses. Once 
	 * created the object can be used to get either an Iterator
	 * or Enumeration object to cycle through the list of address
	 * encapsulated by this object.</P>
	 *
	 * <P>It is important to note that if the address for toIP
	 * is greater than fromIP, the values will be swapped so that
	 * the iteration is always from the lowest address to the
	 * highest address as defined by a 32-bit unsigned quantity.</P>
	 *
	 * @param fromIP	The starting address, resolved by InetAddress.
	 * @param toIP		The ending address, resolved by InetAddress.
	 *
	 * @see java.net.InetAddress#getByName(java.lang.String)
	 *
	 * @exception java.net.UnknownHostException Thrown by the InetAddress
	 * 	class if the hostname cannot be resolved.
	 *
	 */
	public IPAddressRange(String fromIP, String toIP) 
		throws java.net.UnknownHostException
	{
		m_begin = convertToLong(InetAddress.getByName(fromIP).getAddress());
		m_end   = convertToLong(InetAddress.getByName(toIP).getAddress());
		
		if(m_begin > m_end)
		{
			long a  = m_end;
			m_end   = m_begin;
			m_begin = a;
		}
	}

	/**
	 * <P>Creates a new IPAddressRange object that can be used
	 * to encapsulate a contiguous range of IP Addresses. Once 
	 * created the object can be used to get either an Iterator
	 * or Enumeration object to cycle through the list of address
	 * encapsulated by this object.</P>
	 *
	 * <P>It is important to note that if the address for start
	 * is greater than end, the values will be swapped so that
	 * the iteration is always from the lowest address to the
	 * highest address as defined by a 32-bit unsigned quantity.</P>
	 *
	 * @param start		The starting address.
	 * @param end		The ending address.
	 *
	 */
	public IPAddressRange(InetAddress start, InetAddress end)
	{
		m_begin = convertToLong(start.getAddress());
		m_end   = convertToLong(end.getAddress());
	}

	/**
	 * <P>Returns an Iterator object that can be used to 
	 * step through all the address encapsulated in the
	 * object.</P>
	 *
	 */
	public Iterator iterator()
	{
		return new IPAddressRangeGenerator(m_begin, m_end);
	}
	
	/**
	 * <P>Returns an Enumeration object that can be used to 
	 * list out all the address contained in the encapsulated
	 * range.</P>
	 *
	 */
	public Enumeration elements()
	{
		return new IPAddressRangeGenerator(m_begin, m_end);
	}

	
	/**
	 * <P>This class is used to enumerate or iterate through
	 * one contiguous set of IP addresses. The class can either
	 * be used as an iterator or as an enumeration. In java 1.2
	 * iterators were introduced and are being used in favor
	 * of enumerations in new classes.</P>
	 *
	 */
	private class IPAddressRangeGenerator
		implements Enumeration, Iterator
	{
		/**
		 * The next address in the range.
		 */
		long	m_next;
		
		/**
		 * The last address in the range.
		 * The remaining address are in the
		 * range of [m_next .. m_end].
		 */
		long	m_end;

		/**
		 * <P>Converts a 64-bit unsigned quantity to a
		 * IPv4 dotted decimal string address.</P>
		 *
		 * @param address	The 64-bit quantity to convert.
		 *
		 * @return The dotted decimal IPv4 address string.
		 *
		 */
		private String IPv4String(long address) 
		{
			//
			// Developer note: While I wanted this class
			// to be static, the compiler refused stating that
			// only top-level classes & member interfaces
			// can be declared static..... Oh Well!
			//
			
        		return ((address >>> 24) & 0xFF) + "." + 
			       ((address >>> 16) & 0xFF) + "." + 
			       ((address >>>  8) & 0xFF) + "." + 
			       ((address >>>  0) & 0xFF);
		}

		/**
		 * <P>Creates a generator object that iterates over
		 * the range from start to end, inclusive.</P>
		 *
		 * @param start	The start address.
		 * @param end	The ending address.
		 *
		 * @exception java.lang.IllegalArgumentException Thrown if the
		 * 	start address is greater than the ending address.
		 *
		 */
		public IPAddressRangeGenerator(long start, long end)
		{
			if(start > end)
				throw new IllegalArgumentException("start must be less than or equal to end");
				
			m_next = start;
			m_end  = end;
		}

		/**
		 * <P>Returns true if the enumeration object
		 * has more elements remaining.</P>
		 */
		public boolean hasMoreElements()
		{
			return (m_next <= m_end);
		}
		
		/**
		 * <P>Returns the next element in the enumeration.
		 * If there is no element left in the enumeration
		 * an exception will be thrown.</P>
		 *
		 * @exception java.util.NoSuchElementException Thrown
		 * 	if the collection is exhausted.
		 */
		public Object nextElement()
		{
			if (m_next <= m_end)
			{
				return IPv4String(m_next++);
			}
			else
			{
				throw new NoSuchElementException("End of Range");
			}
		}
		
		/**
		 * <P>Returns true if there are more elements in the 
		 * iteration.</P>
		 */
		public boolean hasNext()
		{
			return hasMoreElements();
		}
		
		/**
		 * <P>Returns the next object in the iteration. If
		 * there are no objects left in the iteration an 
		 * exception will be thrown.</P>
		 *
		 * @exception java.util.NoSuchElementException Thrown
		 *	if the collection is exhausted.
		 */
		public Object next()
		{
			return nextElement();
		}
		
		/**
		 * <P>The remove method of the iterator interface is considered
		 * optional for the implemetor. For the purposes of this class
		 * it is not implemented and will throw an exception.</P>
		 *
		 * @exception java.lang.UnsupportedOperationException Always thrown
		 * 	by the remove method.
		 *
		 */
		public void remove()
		{
			throw new UnsupportedOperationException("The remove operation is not supported by the iterator");
		}
	}
}

//
// Copyright (C) 2000 N*Manage Company Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
// Tab Size = 8
//
// $Id: CapsWriter.java,v 1.22 2000/10/18 19:05:39 sowmya Exp $
//

package org.opennms.bb.dp.capsd.components;

import java.net.*;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.io.*;

import com.sun.media.jsdt.*;

import org.opennms.bb.common.components.Log;
import org.opennms.bb.dp.common.components.DBRunnable;
import org.opennms.protocols.ip.IPv4Address;
import org.opennms.protocols.snmp.*;

import org.opennms.bb.dp.capsd.snmp.*;
import org.opennms.bb.dp.capsd.Capsd; 

/**
 * <P>The CapsWriter class is designed to use the information
 * collected by the CapsReadere and write the information to
 * persistant storage. The data is store into the distributed
 * poller database using SQL statements defined in the 
 * properties for the system.</P>
 *
 * <P>The class is designed to be created using an instance of
 * the CapsReader class and then run later as a database runnable.
 * The run of the instance will be passed an SQL connection where
 * the persistant information will be stored.</P>
 *
 * @author <A HREF="sowmya@opennms.org">Sowmya</A>
* @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version $Revision: 1.22 $
 */
public final class CapsWriter implements DBRunnable
{
	//
	// Used to convert decimal to hex
	//
	private static final char[] m_hexDigit = { '0', '1', '2', '3', '4', 
						   '5', '6', '7', '8', '9', 
						   'A', 'B', 'C', 'D', 'E', 'F' };
	/**
	 * <P>The original address that was sent by
	 * the discovery process to capsd.</P>
	 */
	private IPv4Address	m_nodeAddress;
	
	/**
	 * <P>The SNMP System Group information collected
	 * from the node.</P>
	 */
	private SystemGroup	m_sysGroup;
	
	/**
	 * <P>The list of IfEntry objects from the MIB
	 * on the remote host. This is a list of IfTableEntry
	 * objects.</P>
	 */
	private List	  	m_ifEntries;
	
	/**
	 * <P>The list of IP Address entries corresponding
	 * to the interfaces on the remote host. This information
	 * is also collected via SNMP.</P>
	 */
	private List 		m_ipAddrEntries;

    /**
	 * <P>Set of nodes (ip addresses) already known to Capsd.</P>
	 *	
	 */
	private Set 		m_dupNodes;

	/**
	 * <P>The dictionary of services that are index via
	 * the interface address.</P>
	 */
	private Dictionary	m_services;

	/**
	 * <P>Creation date of the node.</P>
	 */
	private String		m_createDate;

	/**
	 * <P>The JSDT Communication channel.</P>
	 */
	private Channel		m_channel;
	
	/**
	 * <P>The JSDT Client.</P>
	 */
	private Client		m_client;

	/**
	 * The lookup string for looking up the value of sysObjectID
	 */
	private final static	String	SYS_OBJECTID="sysObjectID";
	
	/**
	 * The lookup string for looking up the value of sysName
	 */
	private final static	String	SYS_NAME="sysName";
	
	/**
	 * The lookup string for looking up the value of sysDescr
	 */
	private final static	String	SYS_DESCR="sysDescr";
	
	/**
	 * The lookup string for looking up the value of sysLocation
	 */
	private final static	String	SYS_LOCATION="sysLocation";
	
	/**
	 * The lookup string for looking up the value of sysContact
	 */
	private final static	String	SYS_CONTACT="sysContact";
	
	/**
	 * The lookup string for looking up the value of ifIndex
	 */
	private final static	String	IF_INDEX="ifIndex";
	
	/**
	 * The lookup string for looking up the value of ifDescr
	 */
	private final static	String	IF_DESCR="ifDescr";
	
	/**
	 * The lookup string for looking up the value of ifType
	 */
	private final static	String	IF_TYPE="ifType";
	
	/**
	 * The lookup string for looking up the value of ifSpeed
	 */
	private final static	String	IF_SPEED="ifSpeed";
	
	/**
	 * The lookup string for looking up the value of ifPhysAddr
	 */
	private final static	String	IF_PHYS_ADDR="ifPhysAddr";
	
	/**
	 * The lookup string for looking up the value of ifAdminStatus
	 */
	private final static	String	IF_ADMIN_STATUS="ifAdminStatus";
	
	/**
	 * The lookup string for looking up the value of ifOperStatus
	 */
	private final static	String	IF_OPER_STATUS="ifOperStatus";
	
	/**
	 * The lookup string for looking up the value of ipAdEntIfIndex
	 */
	private final static	String	IP_ADDR_IF_INDEX="ipAdEntIfIndex";
	
	/**
	 * The lookup string for looking up the value of ipAdEntAddr
	 */
	private final static	String	IP_ADDR_ENT_ADDR="ipAdEntAddr";
	
	/**
	 * The lookup string for looking up the value of ipAdEntNetMask
	 */
	private final static	String	IP_ADDR_ENT_NETMASK="ipAdEntNetMask";
	
	/**
	 * <P>This static class is used to build an compliant SOAP document
	 * that is sent to the discover daemon. No instances of this
	 * class may be created.</P>
	 */
	private static final class AddressToSoapDocument
	{
		/**
		 * SOAP Envelope tag, fully qualified
		 */
		private static final String SOAP_ENV	= "SOAP-ENV:Envelope";
		
		/**
		 * SOAP Body tag, fully qualified.
		 */
		private static final String SOAP_BODY	= "SOAP-ENV:Body";
		
		/**
		 * SOAP Namespace string
		 */
		private static final String SOAP_NS	= "http://schemas.xmlsoap.org/soap/envelope/";
		
		/**
		 * SOAP Namespace tag.
		 */
		private static final String SOAP_NSTAG	= "SOAP-ENV";
		
		/**
		 * Document known address tag.
		 */
		private static final String KNOWNADDR	= "Capsd:KnownAddress";
		
		/**
		 * Document IPv4 Address tag.
		 */
		private static final String IPV4ADDR	= "Capsd:IPv4Address";
		
		/**
		 * Document namespace
		 */
		private static final String CAPSD_NS	= "http://dtds.opennms.org/bluebird/capsd/knownaddress/";
		
		/**
		 * Document namespace tag.
		 */
		private static final String CAPSD_NSTAG	= "Capsd";
		
		/**
		 * Creates a proper XML start tag.
		 *
		 * @param tag	The tag name
		 * @param out	The output stream.
		 */
		private static void startTag(String tag, PrintStream out)
		{
			out.println("<" + tag + ">");
		}
		
		/**
		 * Creates a proper XML start tag with namespace
		 *
		 * @param tag	The tag name
		 * @param ns	The namespace uri
		 * @param nstag	The namespace tag for the uri
		 * @param out	The output stream.
		 */
		private static void startTag(String tag, String ns, String nstag, PrintStream out)
		{
			out.println("<" + tag + " xmlns:" + nstag + "=\"" + ns + "\">");
		}
		
		/**
		 * Creates a proper XML end tag.
		 *
		 * @param tag	The tag name
		 * @param out	The output stream.
		 */
		private static void endTag(String tag, PrintStream out)
		{
			out.println("</" + tag + ">");
		}
		
		/**
		 * <P>Generates a properly formatted XML SOAP document
		 * that is sutiable for advertising the discovered
		 * node.</P>
		 *
		 * @param addr	The IPv4Address for the document.
		 *
		 * @return The document as a byte array.
		 */
		public static byte[] generate(IPv4Address addr)
		{
			ByteArrayOutputStream bout = new ByteArrayOutputStream();
			PrintStream prn = new PrintStream(bout);
			
			//startTag("?xml version=\"1.0\"?", prn);
			startTag(SOAP_ENV, SOAP_NS, SOAP_NSTAG, prn);
			startTag(SOAP_BODY, prn);
			startTag(KNOWNADDR, CAPSD_NS, CAPSD_NSTAG, prn);
			startTag(IPV4ADDR, prn);
			prn.println(addr.toString());
			endTag(IPV4ADDR, prn);
			endTag(KNOWNADDR, prn);
			endTag(SOAP_BODY, prn);
			endTag(SOAP_ENV, prn);
			prn.flush();
			
			return bout.toByteArray();
		}
	}	

	/**
	 * <P>This method is designed to insert the currently 
	 * known information about the queried node(interface)
	 * into the distributed poller database.</P>
	 *
	 * <P>See the create.sql script from the sql module in
	 * CVS on <A HREF="http://www.opennms.org/">OpenNMS</A>
	 * for more information about the layout of the database.</P>
	 *
	 * @param dbcomm	The JDBC database connection.
	 *
	 * @return The node identifier key from the database.
	 *
	 * @exception java.sql.SQLException Thrown if an error occurs
	 * 	inserting the node into the database.
	 * @exception java.lang.NullPointerException Thrown if the 
	 * 	sql statement could not be loaded from the system
	 * 	properties.
	 */
	private int dbInsertNode(java.sql.Connection dbcomm) throws SQLException
	{
		// Get the dpName of this distributed poller
		String dpName = Capsd.getProperty(CapsdConstants.PROP_DP_NAME);
		if(dpName == null)
			throw new NullPointerException("unable to get system property " + CapsdConstants.PROP_DP_NAME);

		//
		// Get the SQL statement that will allow us to get the
		// next node id key.
		//
		String sqlStmt = Capsd.getProperty(CapsdConstants.PROP_DB_GET_NEXTNODEID);
		if(sqlStmt == null)
			throw new NullPointerException("unable to get system property " + CapsdConstants.PROP_DB_GET_NEXTNODEID);

		//
		// DEBUGGING INFORMATION FOR THE PROGRAMMERS!
		//
		Log.print(Log.DEBUG, "CapsWriter.dbInsertNode: Property for " + CapsdConstants.PROP_DB_GET_NEXTNODEID + " is set to " + sqlStmt);
		
		//
		// Pepare and execute the statement
		//
		PreparedStatement stmt = dbcomm.prepareStatement(sqlStmt);
		ResultSet rs = stmt.executeQuery();
		rs.next();
		int key = rs.getInt(1);
		rs = null;
		stmt.close(); // automatically closes the result set as well
		
		//
		// More DEBUG information
		//
		Log.print(Log.DEBUG, "CapsWriter.dbInsertNode: The new node id for node " + m_nodeAddress + " is " + key);
		
		//
		// Get the SQL Statement. Throw an exception if the
		// string could not be loaded.
		//
		sqlStmt = Capsd.getProperty(CapsdConstants.PROP_DB_INS_NODE);
		if(sqlStmt == null)
			throw new NullPointerException("unable to get system property " + CapsdConstants.PROP_DB_INS_NODE);

		//
		// DEBUGGING INFORMATION FOR THE PROGRAMMERS!
		//
		Log.print(Log.DEBUG, "CapsWriter.dbInsertNode: Property for " + CapsdConstants.PROP_DB_INS_NODE + " is set to " + sqlStmt);

		//
		// Prepare the insert statement
		//
		stmt = dbcomm.prepareStatement(sqlStmt);
		
		//
		// Set the variables. Any changes to the order in the create.sql
		// file must be reflected in this file. The only way to make 
		// this independant would be to rework the SQL statment in the
		// BlueBird.prop file.
		//
		// 1)  nodeID
		// 2)  dpName
		// 3)  nodeCreateTime
		// 4)  nodeParentID
		// 5)  nodeType
		// 6)  nodeSysOID
		// 7)  nodeSysName
		// 8)  nodeSysDescription
		// 9)  nodeSysLocation
		// 10) nodeSysContact
		//

		int column = 1;
		
		//
		// ORDER IS IMPORTANT!!!!
		// DO NOT CHANGE THE ORDER UNLESS YOU ARE SURE OF
		// WHAT YOU ARE DOING!!!!
		//
		stmt.setInt(column++, key);			// node id
		stmt.setString(column++, dpName);    		// dpName
		stmt.setString(column++, m_createDate);		// nodeCreateTime
		stmt.setInt(column++, 0);			// nodeParentId
		stmt.setString(column++, new String("U"));	// nodeType

		if(m_sysGroup != null)
		{
			//nodeSysOID
			SnmpObjectId objid = (SnmpObjectId)m_sysGroup.get(SYS_OBJECTID);			
			if (objid != null)
				stmt.setString(column++, objid.toString());
			else
				stmt.setNull(column++, java.sql.Types.VARCHAR);	// nodeSysOID

			//nodeSysName
			SnmpOctetString sysname = (SnmpOctetString)m_sysGroup.get(SYS_NAME);
			if (sysname != null)
				stmt.setString(column++, new String(sysname.getString()));
			else
				stmt.setNull(column++, java.sql.Types.VARCHAR);	// nodeSysOID

			//nodeSysDescription
			SnmpOctetString sysdescr = (SnmpOctetString)m_sysGroup.get(SYS_DESCR);	
			if (sysdescr != null)
				stmt.setString(column++, new String(sysdescr.getString()));
			else
				stmt.setNull(column++, java.sql.Types.VARCHAR);	// nodeSysOID

			//nodeSysLocation
			SnmpOctetString sysloc = (SnmpOctetString)m_sysGroup.get(SYS_LOCATION);	
			if (sysloc != null)
				stmt.setString(column++, new String(sysloc.getString()));
			else
				stmt.setNull(column++, java.sql.Types.VARCHAR);	// nodeSysOID

			//nodeSysContact
			SnmpOctetString syscontact = (SnmpOctetString)m_sysGroup.get(SYS_CONTACT);	
			if (syscontact != null)
				stmt.setString(column++, new String(syscontact.getString()));
			else
				stmt.setNull(column++, java.sql.Types.VARCHAR);	// nodeSysOID
		}
		else
		{
			stmt.setNull(column++, java.sql.Types.VARCHAR);	// nodeSysOID
			stmt.setNull(column++, java.sql.Types.VARCHAR);	// nodeSysName
			stmt.setNull(column++, java.sql.Types.VARCHAR);	// nodeSysDescription
			stmt.setNull(column++, java.sql.Types.VARCHAR);	// nodeSysLocation
			stmt.setNull(column++, java.sql.Types.VARCHAR);	// nodeSysContact
		}

		//
		// execute, the rcount (row count) is 
		// strictly for debugging information
		//
		int rcount = stmt.executeUpdate();
	
		//
		// Log debug information
		//
		Log.print(Log.DEBUG, "CapsWriter.dbInsertNode: Executed the insertion of a new node, row count = " + rcount);

		Log.print(Log.INFORMATIONAL, "CapsWriter - Node " + m_nodeAddress.toString() + " successfully added to node table");
		
		return key;
	}

	/**
	 * <P>This method is used to insert the information about the
	 * interface into the database. The information includes all
	 * the known information queried by the CapsReader object.</P>
	 *
	 * @param dbcomm	The connection to the databse.
	 * @param nodeKey	The node id for the interfaces
	 *
	 * @exception java.sql.SQLException Thrown if an error occurs 
	 *	committing the information to the database.
	 * @exception java.lang.NullPointerException Thrown if the method
	 * 	is unable to load the SQL statements from the properties.
	 *
	 */
	private void dbInsertInterfaces(java.sql.Connection dbcomm, int nodeKey) 
		throws SQLException
	{
		//
		// Log some information
		//
		Log.print(Log.DEBUG, "CapsWriter.dbInsertInterfaces: Logging all the interface information for node " + m_nodeAddress.toString() + ", node id " + nodeKey);
		
		//
		// do the real work
		//
		boolean	bRet = true;
		
		PreparedStatement ifSnmpStmt 	= null;
		PreparedStatement ifStmt	= null;
		PreparedStatement ifSvcStmt	= null;
		
		String sqlText = Capsd.getProperty(CapsdConstants.PROP_DB_INS_IPINTERFACE);
		if(sqlText == null)
			throw new NullPointerException("Error loading the SQL Query " + CapsdConstants.PROP_DB_INS_IPINTERFACE);	
		ifStmt = dbcomm.prepareStatement(sqlText);

		sqlText = Capsd.getProperty(CapsdConstants.PROP_DB_INS_IFSERVICE);
		if(sqlText == null)
			throw new NullPointerException("Error loading the SQL Query " + CapsdConstants.PROP_DB_INS_IFSERVICE);
		ifSvcStmt = dbcomm.prepareStatement(sqlText);

		sqlText = Capsd.getProperty(CapsdConstants.PROP_DB_INS_SNMP);
		if(sqlText == null)
			throw new NullPointerException("Error loading the SQL Query " + CapsdConstants.PROP_DB_INS_SNMP);
		ifSnmpStmt = dbcomm.prepareStatement(sqlText);

		//
		// This is a catch that is used if SNMP information is not
		// acutally present. This would occur if the node did not
		// have an SNMP agent, or the community strings are improperly
		// configured.
		//
		if(m_ifEntries == null || m_ifEntries.size() == 0)
		{
			dbInsertInterface(ifStmt, 
					  null, 
					  new IPv4Address(m_nodeAddress), 
					  nodeKey);
					  
			dbInsertServices(ifSvcStmt, 
					 new IPv4Address(m_nodeAddress), 
					 -1, 
					 nodeKey);
			
			//
			// WARNING!!!
			//
			// Return here to prevent NullPointerException
			// From being thrown!
			//
			return;
		}

		//
		// Iterate over all the values
		//
		Iterator iter = m_ifEntries.iterator();
		while(iter.hasNext())
		{
			IfTableEntry iftEntry = (IfTableEntry)iter.next();
			
			//
			// Get the IP Address
			//
			int ifIndex = -1;
			SnmpInt32 snmpIfIndex = (SnmpInt32)iftEntry.get(IF_INDEX);
			if(snmpIfIndex != null)
				ifIndex = snmpIfIndex.getValue();

			String addr = getIpAddress(ifIndex);
			if (addr == null)
				addr = "0.0.0.0";
			
			//
			// convert to an IPv4Address
			//
			IPv4Address ifAddress = new IPv4Address(addr);
			
			
			//
			// insert the interface
			//
			dbInsertInterface(ifStmt, 
					  iftEntry, 
					  ifAddress, 
					  nodeKey);
			
			//
			// Insert the Snmp Information
			//
			dbInsertSnmp(ifSnmpStmt, 
				     iftEntry, 
				     ifAddress, 
				     nodeKey);
			
			//
			// Insert the services information
			dbInsertServices(ifSvcStmt, 
					 ifAddress, 
					 ifIndex,
					 nodeKey);
		}

		Log.print(Log.INFORMATIONAL, "CapsWriter - Interfaces of node " + m_nodeAddress.toString() + " successfully added to the interface tables");
	}

	/**
	 * <P>This method is used to add a specific interface into the database.
	 * The interface addition includes information discovered by the SNMP
	 * agent such as it's operational status. If the insert fails then an
	 * exception is thrown by the method. The method also attempts to lookup
	 * the hostname for the specified IP Address. If the lookup fails then
	 * a null record is written to the hostname field.</P>
	 *
	 *
	 * @param stmt		The SQL prepared statment used to insert the information
	 * @param ifEntry	The SNMP Information collected about the interface
	 * @param ifAddress	The Interface IP Address.
	 * @param nodeKey	The node identification key
	 *
	 * @exception java.sql.SQLException	Thrown if the insertion into the
	 *	database fails.
	 */
	private void dbInsertInterface(PreparedStatement stmt, 
				       IfTableEntry 	 ifEntry, 
				       IPv4Address	 ifAddress, 
				       int 		 nodeKey)
		throws SQLException
	{
		//
		// Log some information to figure out what's going on
		//
		Log.print(Log.DEBUG, "CapsWriter.dbInsertInterface: Inserting interface " + ifAddress.toString() + " for node " + m_nodeAddress.toString() + ", node id " + nodeKey);
		
		//
		// Get the hostname of the remote IP Address, if any.
		// There may be some delay as the Name Service is accessed.
		//
		String ipHostName = null; 
		try
		{
			InetAddress inetAddr = InetAddress.getByName(ifAddress.toString());
			ipHostName = inetAddr.getHostName();
		}
		catch(Exception e)
		{
			Log.print(Log.WARNING, "Name Service Lookup Failure for Interface " + ifAddress);
			Log.print(Log.WARNING, e);
			
			//
			// Set the hostname to null, and write a null record or 
			// the IP address
			//
			ipHostName = null;
		}
		
		// get ifIndex and operStatus for this interface
		int ifIndex = -1;
		int operStatus = -1;
		if(ifEntry != null)
		{
			SnmpInt32 snmpIfIndex = (SnmpInt32)ifEntry.get(IF_INDEX);
			if(snmpIfIndex != null)
				ifIndex = snmpIfIndex.getValue();


			SnmpInt32 snmpOperStatus = (SnmpInt32)ifEntry.get(IF_OPER_STATUS);
			if (snmpOperStatus != null)
				operStatus = snmpOperStatus.getValue();

		}


		//
		// column to add the data
		//
		int column = 1;
		
		//
		// ORDER IS IMPORTANT!!!!
		// DO NOT MODIFY THE ORDER UNLESS YOU KNOW
		// WHAT YOU ARE DOING!!!!!
		//

		// nodeID, foreign key
		stmt.setInt(column++, nodeKey);				

		// IP Address
		stmt.setInt(column++, ifAddress.getAddress());		

		// ifIndex
		if(ifIndex != -1)
			stmt.setInt(column++, ifIndex);
		else
			stmt.setNull(column++, java.sql.Types.INTEGER);	// ifIndex

		// IP Hostname!?
		if(ipHostName != null)
			stmt.setString(column++, ipHostName);			// IP Hostname
		else
			stmt.setNull(column++, java.sql.Types.VARCHAR);	

		// isManaged
		stmt.setString(column++, new String("U"));
		
		// operStatus
		if(operStatus != -1)
			stmt.setInt(column++, operStatus);
		else
			stmt.setNull(column++, java.sql.Types.INTEGER);
			
		// ipLastCapsdPollDate
		stmt.setString(column++, m_createDate);			
		
		// excecute
		stmt.executeUpdate();
		
		Log.print(Log.INFORMATIONAL, "CapsWriter - dbInsertInterface of " + ifAddress.toString() + " of node " + nodeKey + " successful");

	}

	/**
	 * <P>This method is used to insert the SNMP information
	 * gathered about an interface into the database. The 
	 * information includes the network maks, interface index,
	 * physical address, and interace status along with other
	 * fields.</P>
	 *
	 * @param stmt		The prepared SQL statement.
	 * @param ifEntry	The SNMP interface information.
	 * @param ifAddress	The IP Address of the interface
	 * @param nodeKey	The foreign key node identifier
	 *
	 * @exception java.sql.SQLException	Thrown if an error occurs
	 *	adding the information to the datastore.
	 *
	 */
	private void dbInsertSnmp(PreparedStatement	stmt, 
				  IfTableEntry 		ifEntry, 
				  IPv4Address 		ifAddress,
				  int			nodeKey)
		throws SQLException
	{
		Log.print(Log.DEBUG, "CapsWriter.dbInsertSnmp: Inserting snmp interface " + ifAddress.toString() + " for node " + m_nodeAddress.toString() + ", node id " + nodeKey);

		// get snmpIpAdEntNetMask
		int ifIndex = -1;
		SnmpInt32 snmpIfIndex = (SnmpInt32)ifEntry.get(IF_INDEX);
		if (snmpIfIndex != null)
			ifIndex = snmpIfIndex.getValue();

		int netmask = 0;
		{
			String mask = getNetmask(ifIndex);
			if(mask != null)
			{
				netmask = (new IPv4Address(mask)).getAddress();
			}
		}
		

		//
		// Log some debug information
		//
		Log.print(Log.DEBUG, "CapsWriter.dbInsertSnmp: Inserting snmp interface " + ifIndex + " with address " + ifAddress);
		
		// Get all the relavant data
		// snmpPhysAdr
		String physAddr = null;
		SnmpOctetString snmpPhysAddr = (SnmpOctetString)ifEntry.get(IF_PHYS_ADDR);
		if (snmpPhysAddr != null)
		{
			physAddr = toHexString(snmpPhysAddr.getString());
		}

		if(physAddr != null && physAddr.length() > 12)
			Log.print(Log.WARNING, "CapsWriter.dbInsertSnmp: WARNING, physical address greater than 12 bytes (" + physAddr + ")");

		
		// snmpIfDescr
		String snmpIfDescr = null;
		SnmpOctetString snmpDescr = (SnmpOctetString)ifEntry.get(IF_DESCR); 
		if (snmpDescr != null)
			snmpIfDescr = snmpDescr.toString();
		
		// ifType
		int ifType = -1;
		SnmpInt32 snmpIfType = (SnmpInt32)ifEntry.get(IF_TYPE);
		if (snmpIfType != null)
			ifType = snmpIfType.getValue();

		// snmpIfSpeed
		int ifSpeed = -1;
		SnmpGauge32 snmpIfSpeed = (SnmpGauge32)ifEntry.get(IF_SPEED);
		if (snmpIfSpeed != null)
			ifSpeed = (int)snmpIfSpeed.getValue();


		// snmpIfAdminStatus
		int adminStatus = -1;
		SnmpInt32 snmpAdminStatus = (SnmpInt32)ifEntry.get(IF_ADMIN_STATUS);
		if (snmpAdminStatus != null)
			adminStatus = snmpAdminStatus.getValue();


		// snmpIfOperStatus
		int operStatus = -1;
		SnmpInt32 snmpOperStatus = (SnmpInt32)ifEntry.get(IF_OPER_STATUS);
		if (snmpOperStatus != null)
			operStatus = snmpOperStatus.getValue();


		//
		// column to add the data
		//
		int column = 1;
		
		//
		// ORDER IS IMPORTANT!!!!
		// DO NOT MODIFY THE ORDER UNLESS YOU KNOW
		// WHAT YOU ARE DOING!!!!!
		//
		// node ID
		stmt.setInt(column++, nodeKey);
		
		// IP Address
		stmt.setInt(column++, ifAddress.getAddress());

		// snmpIpAdEntNetMask
		stmt.setInt(column++, netmask);

		// snmpPhysAdr
		if(physAddr != null)
			stmt.setString(column++, physAddr);
		else
			stmt.setNull(column++, java.sql.Types.CHAR);
		
		// snmpIfIndex
		if(ifIndex != -1)
			stmt.setInt(column++, ifIndex);
		else
			stmt.setNull(column++, java.sql.Types.INTEGER);

		// snmpIfDescr
		if (snmpIfDescr != null)
			stmt.setString(column++,  snmpIfDescr); 
		else
			stmt.setNull(column++, java.sql.Types.VARCHAR);
		
		// snmpIfType
		if (ifType != -1)
			stmt.setInt(column++, ifType);
		else
			stmt.setNull(column++, java.sql.Types.INTEGER);

		// snmpIfName 
		stmt.setNull(column++, java.sql.Types.VARCHAR);

		// snmpIfSpeed
		if (ifSpeed != -1)
			stmt.setInt(column++, ifSpeed);
		else
			stmt.setNull(column++, java.sql.Types.INTEGER);

		// snmpIfAdminStatus
		if (adminStatus != -1)
			stmt.setInt(column++, adminStatus);
		else
			stmt.setNull(column++, java.sql.Types.INTEGER);

		// snmpIfOperStatus
		if (operStatus != -1)
			stmt.setInt(column++, operStatus);
		else
			stmt.setNull(column++, java.sql.Types.INTEGER);
		
		// execute
		stmt.executeUpdate();

		Log.print(Log.INFORMATIONAL, "CapsWriter - dbInsertSnmp of " + ifAddress.toString() + " of node " + nodeKey + " successful");
		
	}

	/**
	 * <P>This method is used to insert the 
	 * supported services for the interface into the
	 * datastore. Each service that was supported on the
	 * interface is written as a row in the ifServices table.</P>
	 *
	 * @param stmt		The SQL statement for inserting rows.
	 * @param ifAddress	The IP Address of the interface.
	 * @param ifIndex	The index of the lan card.
	 * @param nodeKey	The node's foreign key constraint
	 *
	 * @exception java.sql.SQLException	Thrown if an error occurs
	 * 	setting up the bindings or executing the statement.
	 *
	 */
	private void dbInsertServices(PreparedStatement	stmt, 
				      IPv4Address	ifAddress,
				      int		ifIndex,
				      int		nodeKey)
		throws SQLException
	{
		Log.print(Log.DEBUG, "CapsWriter.dbInsertServices: Inserting services for " + ifAddress.toString() + " for node " + m_nodeAddress.toString() + ", node id " + nodeKey);

		//
		// Verify that there are services and
		// the services for this interface are not
		// null.
		//
		if(m_services == null)
			return;

		List ifStatus = (List) m_services.get(ifAddress.toString());
		if (ifStatus == null)
			return;

			
		//
		// Send programmer debug information to the screen.
		//
		Log.print(Log.DEBUG, "CapsWriter.dbInsertServices: Inserting supported services.");
		
		//
		// iterate through the list
		//
		Iterator iter = ifStatus.iterator();
		while(iter.hasNext())
		{
			ServiceStatus status = (ServiceStatus)iter.next();

			//
			// Only Add SUPPORTED services!
			//
			if(status.isSupported() == false)
				continue;

			Log.print(Log.DEBUG, "CapsWriter.dbInsertServices: Inserting Service Tuple (" +
						nodeKey + ", " + ifAddress + ", " + ifIndex + ", "    + 
						status.getServiceID() + ")");

			// ipAddr, serviceID
			stmt.setInt(1, nodeKey);
			stmt.setInt(2, ifAddress.getAddress());
			if(ifIndex == -1)
				stmt.setNull(3, java.sql.Types.INTEGER);
			else
				stmt.setInt(3, ifIndex);
			stmt.setInt(4, status.getServiceID());
			
			// execute and log
			stmt.executeUpdate();

			stmt.close();

		} // end services

		Log.print(Log.INFORMATIONAL, "CapsWriter - dbInsertServices of " + ifAddress.toString() + " of node " + nodeKey + " successful");

	}

	/**
	 * <P>This method is used to find the corresponding IP Address
	 * for the indexed interface. The list of IP Address entries are
	 * searched until <EM>the first</EM> IP Address is found for the
	 * interface. The IP Address is then returned as a string. If
	 * there is no interface corresponding to the index then a null
	 * is returned to the caller.</P>
	 *
	 * @param   ifIndex  The interface index for.
	 *
	 * @return  IP Address for the indexed interface.
	 */
	private String getIpAddress(int ifIndex)
	{
		if (ifIndex == -1)
		{
			return null;
		}

		Iterator iter = m_ipAddrEntries.iterator();
		while(iter.hasNext())
		{
			IpAddrTableEntry ipAddrEntry = (IpAddrTableEntry)iter.next();
			SnmpInt32 snmpIpAddrIndex = (SnmpInt32)ipAddrEntry.get(IP_ADDR_IF_INDEX);
			if (snmpIpAddrIndex == null)
				continue;

			int ipAddrIndex = snmpIpAddrIndex.getValue();
			if (ipAddrIndex ==  ifIndex)
			{
				SnmpIPAddress snmpAddr = (SnmpIPAddress)ipAddrEntry.get(IP_ADDR_ENT_ADDR);
				if (snmpAddr != null)
					return snmpAddr.toString();
				else
					return null;
			}
		}
		
		return null;
	}
	
	/**
	 * <P>This method is used to find the corresponding netmask
	 * for the indexed interface. The list of IP Address table
	 * entries are searched until <EM>the first</EM> netmask address
	 * is found for the interface. The netmask is then returned as
	 * a string. If there is no interface corresponding to the index
	 * then a null is returned.</P>
	 *
	 * @param   ifIndex The interface index to search for.
	 *
	 * @return  The netmask for the interface.
	 */
	private String getNetmask(int ifIndex)
	{
		if (ifIndex == -1)
			return null;

		Iterator iter = m_ipAddrEntries.iterator();
		while(iter.hasNext())
		{
			IpAddrTableEntry ipAddrEntry = (IpAddrTableEntry)iter.next();
			SnmpInt32 snmpIpAddrIndex = (SnmpInt32)ipAddrEntry.get(IP_ADDR_IF_INDEX);
			if (snmpIpAddrIndex == null)
				continue;

			int ipAddrIndex = snmpIpAddrIndex.getValue();
			if(ipAddrIndex ==  ifIndex)
			{
				SnmpIPAddress snmpAddr = (SnmpIPAddress)ipAddrEntry.get(IP_ADDR_ENT_NETMASK);
				if (snmpAddr != null)
					return snmpAddr.toString();
				else
					return null;
			}
		}
		
		return null;
	}

	/**
	 * <P>This method converts the physical address, normally
	 * six bytes, into a hexidecimal string. The string is not
	 * prefixed with the traditional <EM>"0x"</EM>, but is the
	 * raw hexidecimal string in upper case.</P>
	 *
	 * <P><EM>NOTICE</EM>: The string is converted based on
	 * the starndard US-ASCII table. Each NIBBLE is converted
	 * to an integer and added to the character '0' (Zero).</P>
	 *
	 * @param physAddr	The physical address to convert to a string.
	 *
	 * @return The converted physical address as a hexidecimal string.
	 *
	 */
	private String toHexString(byte[] physAddr)
	{
		//
		// Check to make sure that there 
		// is enough data.
		//
		if (physAddr == null || physAddr.length == 0)
			return null;

		//
		// Convert the actual data
		//
		StringBuffer buf = new StringBuffer(12);
		for(int i = 0; i < physAddr.length; i++)
		{
			int b = (int)physAddr[i];
			buf.append(m_hexDigit[(b >> 4) & 0xf]);	// based upon US-ASCII
			buf.append(m_hexDigit[(b & 0xf)]);		// based upon US-ASCII
		}
		return buf.toString().toUpperCase();
	}
	
	/**
	 * <P>The class' default constructor. The constructor will always
	 * throw an exception and not designed to be instantianted without
	 * a CapsReader object to interogate information from.</P>
	 *
	 * @exception java.lang.UnsupportedOperationException Always thrown
	 * 	by the constructor.
	 */
	private CapsWriter() throws UnsupportedOperationException
	{
		throw new UnsupportedOperationException("default constructor not supported");
	}
	
	/**
	 * <P>The class' constructor that is used to create an instance of
	 * a writer object. The object is always paired with a reader object
	 * that has all the information gleaned about then node.</P>
	 *
	 * <P>Once an instance of the object is initialized the dbRun
	 * method must be called to actually store the information to 
	 * the database.</P>
	 *
	 * @param capsReader	the CapsReader object that has all the data
	 * @param channel	the JSDT channel to which nodes are added
	 *                      after being added to the DB - discovery then
	 *                      reads off this channel to update the
	 *                      'knownNodes'
	 * @param client	the JSDT client identification for this object
	 *
	 */
	public CapsWriter(CapsReader capsReader, Channel channel, Client client) 
	{
		Log.print(Log.DEBUG, "CapsWriter.<ctor>: Constructing new CapsWriter for CapsReader(" + capsReader.getIfAddress() + ")");

		//
		// Get the JSDT information
		//
		m_channel = channel;
		m_client  = client;
		
		//
		// data from capsReader
		//
		m_nodeAddress  = capsReader.getIfAddress();
		m_sysGroup     = capsReader.getSystemGroup();
		m_dupNodes     = capsReader.getDuplicateNodes();

		m_ifEntries    = null;
		m_ipAddrEntries= null;

		m_services      = capsReader.getSupportedServices();
		
		if (capsReader.getIfTable() != null)
		{
			m_ifEntries     = capsReader.getIfTable().getEntries();
			m_ipAddrEntries = capsReader.getIpAddrTable().getEntries();
		}
		
	}

	/**
	 * <P>This method of the CapsWriter class does the bulk of the 
	 * work for the instance. The information that was grabbed by
	 * the constructor is written to the persistant store by the run
	 * method. The run method can be called multiple times with different
	 * connections if necessary.</P>
	 * 
	 * @param connection	the database connection to be used by this
	 *                      object to add data to the DB
	 */
	public void dbRun(java.sql.Connection connection)
	{
		Log.print(Log.DEBUG, "CapsWriter.dbRun: database run method for address " + m_nodeAddress.toString() + " invoked");

		SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy hh:mm:ss");
		m_createDate = formatter.format(new java.util.Date());
		
		Log.print(Log.DEBUG, "CapsWriter: Create date for CapsWriter is " + m_createDate);

		boolean bFailure = false; 
		try
		{
			//
			// check the commit mode
			//
			if(connection.getAutoCommit())
			{
				Log.print(Log.DEBUG, "CapsWriter.dbRun: Setting Auto-Commit to false");
				connection.setAutoCommit(false);
			}
				
			
			//
			// get the information
			//
			int key = dbInsertNode(connection);	// node table
			dbInsertInterfaces(connection, key); 	// interface and other info
			
			//
			// commit the work
			//
			Log.print(Log.DEBUG, "CapsWriter.dbRun: Commiting work to the database");
			connection.commit();
			
			//
			// send the information back to discovery
			//
			Log.print(Log.DEBUG, "CapsWriter.dbRun: Sending new interfaces to discovery");
			boolean bSentNode = false;
			if(m_ifEntries != null)
			{
				Log.print(Log.DEBUG, "m_ifEntries NOT equal to NULL...iterating ifEntries list");
				Iterator iter = m_ifEntries.iterator();
				while(iter.hasNext())
				{
					Log.print(Log.DEBUG, "inside iterator loop, node has at least one interface");
					IfTableEntry ifEntry = (IfTableEntry)iter.next();
					int ifIndex = -1;
					SnmpInt32 snmpIfIndex = (SnmpInt32)ifEntry.get(IF_INDEX);
					if (snmpIfIndex != null)
						ifIndex = snmpIfIndex.getValue();
					String ipAddr = getIpAddress(ifIndex);
					Log.print(Log.DEBUG, "Value returned by getIpAddress: " + ipAddr);
					if(ipAddr != null)
					{
						Log.print(Log.DEBUG, "CapsWriter.dbRun: Sending interface " + ipAddr + " to discovery");
						
						// 
						// Generate Soap Document in which to pass IP address to Discovery
						//
						IPv4Address ipv4Addr = new IPv4Address(ipAddr);
						Data data = new Data(AddressToSoapDocument.generate(ipv4Addr));

						//m_channel.sendToAll(m_client, data);
						m_channel.sendToOthers(m_client, data);

						if (ipAddr.equals(m_nodeAddress.toString()))
							bSentNode = true;
					}
				}	
			}
			/*else*/

			//
			// Need to make certain that we at least send the node address to discovery
			//
			if (!bSentNode)
			{
				Log.print(Log.DEBUG, "CapsWriter.dbRun: Sending node " + m_nodeAddress.toString() + " to discovery");

				// 
				// Generate Soap Document in which to pass IP address to Discovery
				//
				IPv4Address ipv4Addr = new IPv4Address(m_nodeAddress.toString());
				Data data = new Data(AddressToSoapDocument.generate(ipv4Addr));

				//m_channel.sendToAll(m_client, data);
				m_channel.sendToOthers(m_client, data);
			}				
		}
		catch(SQLException sqlE)
		{
			bFailure = true;
			Log.print(Log.ERROR, "SQL Exception on interface/node insert " + m_nodeAddress.toString());
			Log.print(Log.ERROR, sqlE.getMessage());
		}
		catch(JSDTException e)
		{
			bFailure = true;
			Log.print(Log.ERROR, "JSDT capsd->disc send exception occured");
			Log.print(Log.ERROR, e.getMessage());
		}
		catch(NullPointerException e)
		{
			bFailure = true;
			Log.print(Log.ERROR, "Property not found trying to write data to persistant storage");
			Log.print(Log.ERROR, e.getMessage());
		}

		if (bFailure)
		{
			// Regardless of the cause of the exception we need to remove all the 
			// IP addresses associated with this node from m_dupNodes so that they
			// can be added by the the next discovery poll
			Log.print(Log.DEBUG, "CapsWriter.dbRun: interface/node insertion failed, removing addresses from dupNodes");
			boolean bRemovedNode = false;

			// Loop thru interfaces and remove each ip address found
			if(m_ifEntries != null)
			{
				Log.print(Log.DEBUG, "m_ifEntries not NULL so iterate interface list...");
				Iterator iter = m_ifEntries.iterator();
				while(iter.hasNext())
				{
					IfTableEntry ifEntry = (IfTableEntry)iter.next();
					int ifIndex = -1;
					SnmpInt32 snmpIfIndex = (SnmpInt32)ifEntry.get(IF_INDEX);
					if (snmpIfIndex != null)
						ifIndex = snmpIfIndex.getValue();
					String ipAddr = getIpAddress(ifIndex);
					if(ipAddr != null)
					{
						Log.print(Log.DEBUG, "CapsWriter.dbRun: Removing interface address " + ipAddr + " from dupNodes");
						m_dupNodes.remove(ipAddr);
						if (ipAddr.equals(m_nodeAddress.toString()))
							bRemovedNode = true;
					}
				}
			}
			/* else */
			//
			// Make certain that we at least have removed the node address from duplicate node set.
			//
			if (!bRemovedNode)
			{
				Log.print(Log.DEBUG, "CapsWriter.dbRun: Removing node address " + m_nodeAddress.toString() + " from dupNodes");
				m_dupNodes.remove(m_nodeAddress.toString());
			}
		}	
	}
}

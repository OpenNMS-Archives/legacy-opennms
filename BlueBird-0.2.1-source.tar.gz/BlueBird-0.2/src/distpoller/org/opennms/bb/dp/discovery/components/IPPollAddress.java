//
// Copyright (C) 2000 N*Manage Company Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
// Tab Size = 8
//
// $Id: IPPollAddress.java,v 1.5 2000/11/09 23:30:22 mike Exp $

package org.opennms.bb.dp.discovery.components;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.*;

/**
 * <P>An IPPollAddress contains an IP Address, retry count, an
 * associated timeout, and the JSDT client name of the ICMP 
 * service monitor instance that generated the request.
 * The address is stored in a dotted decimal
 * format. The timeout should be stored in 1/1000th of a second.</P>
 *
 * @author <A HREF="mailto:sowyma@opennms.org">Sowmya</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version $Revision: 1.5 $
 */
public class IPPollAddress extends Object
{
	/** 
	 * The JSDT client name of the ICMP service monitor
	 * instance that generated this request.  This string
	 * is used to send the poll result back to the 
	 * correct service monitor instance.
	 */
	private String		m_jsdtSenderName;

	/**
	 * The dotted decimal IPv4 address for the poll.
	 */
	private String		m_address; // dotted IP m_address
	
	/**
	 * The timeout for the poller in 1/1000th of a second.
	 */
	private long		m_timeout;
	
	/**
	 * The number of times to attempt to contact the remote.
	 */
	private long		m_retries;

	/**
	 * <P>The default constructor is marked private and will
	 * always throw an UnsupportedOperationException. This is
	 * to prevent the use of the default constructor.</P>
	 *
	 * @exception java.lang.UnsupportedOperationException Always thrown.
	 */
	private IPPollAddress() throws UnsupportedOperationException
	{
		throw new UnsupportedOperationException("Default constructor not implemented");
	}
	
	/**
	 * <P>Constructs an IPPollAddress object with the specified
	 * parameters.</P>
	 *
	 * @param ipAddress	The Dotted Decimal IPv4 Address.
	 * @param timeout	The timeout between retries in 1/1000th of a second.
	 * @param retries	The number of times to attempt to contact the address.
	 *
	 */
	public IPPollAddress(String ipAddress, long timeout, long retries) 
	{
		m_address = ipAddress;
		m_timeout = timeout;
		m_retries = retries;
	}

	/**
	 * <P>Returns the timeout in 1/1000th of a 
	 * second increments.</P>
	 */
	public long getTimeout()
	{
		return m_timeout;
	}

	/**
	 * <P>Returns the current number of retries
	 * set for this address.</P>
	 */
	public long getRetries()
	{
		return m_retries;
	}

	/**
	 * <P>Returns the current IPv4 address for this object
	 * in the dotted decimal format.</P>
	 */
	public String getAddress()
	{
		return m_address;
	}

	/**
	 * <P>Returns the JSDT client name associated with the
	 * ICMP service monitor responsible for generating this 
	 * request.</P>
	 */
	public String getSenderName()
	{
		return m_jsdtSenderName;
	}

	/**
	 * <P> Sets the JSDT client name associated with this request</P>
	 *
	 * @param sender	The JSDT client name which sent this request.
	 */
	public void setSenderName(String sender)
	{
		m_jsdtSenderName = sender;
	}

	/**
	 * <P>Returns true if the passed object is equal to 
	 * self. The objects must be equal in address,
	 * timeout, and the number of retries.</P>
	 *
	 * @return True if the objects are logically equal. False
	 *	is returned otherwise.
	 */
	public boolean equals(IPPollAddress pollAddr)
	{
		boolean bRet = true;

		if (pollAddr == null)
			bRet = false;

		else if (!pollAddr.getSenderName().equals(m_jsdtSenderName))
			bRet = false;

		else if (!pollAddr.getAddress().equals(m_address))
			bRet = false;
		
		else if (pollAddr.getRetries() != m_retries)
			bRet = false;

		else if (pollAddr.getTimeout() != m_timeout)
			bRet = false;
		
		return bRet;
	}
}

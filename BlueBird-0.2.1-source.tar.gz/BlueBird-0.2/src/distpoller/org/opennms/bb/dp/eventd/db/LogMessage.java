//
// Copyright (C) 2000 N*Manage Company, Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
// $Id: LogMessage.java,v 1.1 2000/11/15 18:50:34 sowmya Exp $
//
package org.opennms.bb.dp.eventd.db;

import java.lang.*;
import org.opennms.bb.dp.events.*;

/**
 *
 * @author <A HREF="mailto:weave@opennms.org">Brian Weaver</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version CVS $Revision: 1.1 $
 *
 */
public final class LogMessage
{
	public static String format(EventLogMessage msg)
	{
		String txt = Constants.escape(msg.getMessage(), Constants.DB_ATTRIB_DELIM);
		String log = "";
		switch(msg.getLogOption())
		{
		case EventLogMessage.LOGNDISPLAY:
			log = "logndisplay";
			break;
		
		case EventLogMessage.LOGONLY:
			log = "logonly";
			break;
		
		case EventLogMessage.SUPPRESS:
			log = "suppress";
			break;
		}
		
		String fmsg = txt + Constants.DB_ATTRIB_DELIM + log;
		if(fmsg.length() >= 256)
			fmsg = fmsg.substring(0, 252) + Constants.VALUE_TRUNCATE_INDICATOR;
		
		return fmsg;
	}
}

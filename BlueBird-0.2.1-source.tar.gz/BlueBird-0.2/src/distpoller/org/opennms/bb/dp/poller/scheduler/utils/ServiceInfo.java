//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.dp.poller.scheduler.utils;

import java.util.*;

import org.opennms.bb.dp.poller.scheduler.utils.Parameter;
import org.opennms.bb.dp.poller.scheduler.utils.PollerModel;

/**This class is responsible for holding information about a
 * service parsed from the package.xml file. 
 *
 * @author <A HREF="mailto:jason@opennms.org">Jason Johns</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version $Revision: 1.4 $
 * 
 */
public class ServiceInfo
{
	/**
	*/
	public static final String INTERVAL = "interval";
	
	/**The name of the service, from the <serviceName> tag
	*/
	private String m_serviceName;
	
	/**The name of the model that this service uses for unavailable scheduling
	*/
	private String m_modelName;
	
	/**
	*/
	private PollerModel m_model;
	
	/**The group of parameters build from the <param> tags under the <service> tag
	*/
	private HashMap m_serviceDetails;
	
	/**Default constructor, allocates the m_serviceDetails member
	*/
	public ServiceInfo()
	{
		m_serviceDetails = new HashMap();
		
		//if the model name is null when getModelName() method is called
		//then there wasn't a model for the service in the package.xml file
		m_modelName = null;
	}
	
	/**This method sets the name of the model the services uses for 
	   unavailable scheduling
	   @param String aModelName, the name of the model
	*/
	public void setModelName(String aModelName)
	{
		m_modelName = aModelName;
	}
	
	/**
	*/
	public void setModel(PollerModel aModel)
	{
		m_model = aModel;
	}
	
	/**This method returns the name of the model for this service.
	   If the model name is null when getModelName() method is called
	   then there wasn't a model for the service in the package.xml file. 
	   In this case the caller should look at the interval included in 
	   this service for scheduling options.
	   @return String, the name of the model to use for scheduling, null
	           if no model was specified.
	*/
	public String getModelName()
	{
		return m_modelName;
	}
	
	/**
	*/
	public PollerModel getModel()
	{
		return m_model;
	}
	
	/**This method adds a new parameter to the service
	   @param Parameter, a new parameter parsed from the xml
	*/
	public void addServiceParameter(Parameter parameter)
	{
		m_serviceDetails.put(parameter.getName(), parameter);
	}
	
	/**This method sets the name of the service
	   @param String name, the name of the service
	*/
	public void setServiceName(String aName)
	{
		m_serviceName = aName;
	}
	
	/**This method returns the name of the service
	   @return String, the name of the service
	*/
	public String getServiceName()
	{
		return m_serviceName;
	}
	
	/**This method gets the value of a specific parameter from the service
	   @return String, the value of the parameter
	   @param String parmName, the name of the parameter being look up
	*/
	public String getServiceParameter(String parmName)
	{
		Parameter p = (Parameter)m_serviceDetails.get(parmName);
		return (String)p.getValue();
	}
	
	/**This method returns a String representation of the service class
	   @return String, a string representation
	*/
	public String toString()
	{
		StringBuffer buffer = new StringBuffer("Service = " + m_serviceName);
		
		buffer.append("\r\n");
		buffer.append(hashMapPrint(m_serviceDetails));
		
		if (m_model == null)
		{
			buffer.append("Model: No model assigned\r\n");
		}
		else
		{
			buffer.append("Model: " + m_model.toString() + "\r\n");
		}
		
		return buffer.toString();
	}
	
	/**This method walks through a HashMap and builds a StringBuffer
	   pretty print version.
	   @return StringBuffer, a conversion of the HashMap into a string
	   @param HashMap map, the map to convert
	*/
	private StringBuffer hashMapPrint(HashMap map)
	{
		StringBuffer buffer = new StringBuffer();
		
		Iterator i = map.keySet().iterator();
		
		while (i.hasNext())
		{
			buffer.append("\t");
			buffer.append(((Parameter)map.get(i.next())).toString());
			buffer.append("\r\n");
		}
		
		return buffer;
	}
}

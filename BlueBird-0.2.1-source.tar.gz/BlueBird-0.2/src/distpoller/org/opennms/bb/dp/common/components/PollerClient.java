//
// Copyright (C) 2000 N*Manage Company Inc.
// Copyright (C) 2000 PlatformWorks, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
// Tab Stop = 8
//
// $Id: PollerClient.java,v 1.6 2000/08/14 21:24:28 sowmya Exp $
//
package org.opennms.bb.dp.common.components;

import java.lang.*;
import com.sun.media.jsdt.*;

/**
 * <P>The PollerClient class is a base class that 
 * implements the JSDT Client interface for communications
 * with other JSDT clients.</P>
 *
 * <P>It is up to any class that derives from the PollerClient
 * object to set it's unique name and override the authenticate
 * method if authentication is required.</P>
 *
 * @author <A HREF="mailto:sowmya@opennms.org">Sowmya</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version $Revision: 1.6 $
 */
public class PollerClient implements Client
{
	/**
	 * <P>The acutal name of the PollerClient with
	 * respect to the JSDT library.</P>
	 */
	protected String m_name;

	/**
	 * <P>The default constructor is defined and will always
	 * throw a java.lang.UnsupportedOperationException. This
	 * behavior is to prevent an actual client object from
	 * being created without a unique name as required by the
	 * JSDT engine.</P>
	 *
	 * @exception java.lang.UnsupportedOperationException Always
	 *	thrown by this constructor.
	 *
	 */
	private PollerClient( ) throws UnsupportedOperationException
	{
		throw new UnsupportedOperationException("default constructor not supported");
	}
	
	/**
	 * <P>Initializes a PollerClient for the derived class. The
	 * passe string is kept internally for communications with
	 * the Java Shared Data Toolkit (JSDT).</P>
	 *
	 * @param name	The unique name of the JSDT client.
	 */
	public PollerClient(String name)
	{
		m_name = name;
	}
	
	/**
	 * <P>Used to perform any required authentication by
	 * the JSDT registry or JSDT manager. The default
	 * implementation is to return a <EM>null</EM> object
	 * so that authentication is not performed.</P>
	 *
	 * <P>Note: The object returned for Authentication should
	 * be serializable.</P>
	 *
	 * @param info	The Authentication challenge from
	 * 	the server.
	 *
	 */
	public Object authenticate(AuthenticationInfo info)
	{
		return null;
	}

	/**
	 * <P>Returns the name of the JSDT client as
	 * initialized by the class constructor.</P>
	 *
	 * @return The name of the PollerClient.
	 *
	 */
	public String getName()
	{
		return m_name;
	}
}


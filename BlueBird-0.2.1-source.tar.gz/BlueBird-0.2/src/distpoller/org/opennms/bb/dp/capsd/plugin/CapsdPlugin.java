//
// Copyright (C) 2000 N*Manage Company, Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
// $Id: CapsdPlugin.java,v 1.4 2000/09/13 14:50:18 weave Exp $
//
//
package org.opennms.bb.dp.capsd.plugin;

/**
 * <P>The CapsdPlugin interface is the basic interface that a
 * plugin for the capabilites daemon must support. The interface
 * allows the daemon to determine what protocols can be verified
 * by the plugin and has the required methods to verify protocol
 * support for nodes/protocol pairs.</P>
 *
 * @author <A HREF="mailto:weave@opennms.org">Brian Weaver</A>
 * @author <A HREF="http://www.opennms.org">OpenNMS</A>
 *
 * @version $Revision: 1.4 $
 */
public interface CapsdPlugin
{
	/**
	 * Returns the db-name of the capability(s) it is checking
	 *
	 * @return the db-name of the capability(s) it is checking
	 */
	public String getCapabilityName();

	/**
	 * Returns true if the default (first) protocol is supported
	 * by the address
	 *
	 * @return true if the default (first) protocol is supported by the address
	 */
	public boolean isProtocolSupported(java.net.InetAddress address);

	/**
	 * Returns true if the specified protocol is supported by the class
	 *
	 * @return true if the specified protocol is supported by the class
	 */
	public boolean isProtocolSupported(java.net.InetAddress address, java.lang.String capName)
		throws UnsupportedProtocolException;
}


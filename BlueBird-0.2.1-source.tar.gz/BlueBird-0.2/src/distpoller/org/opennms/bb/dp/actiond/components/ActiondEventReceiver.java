//
// Copyright (C) 2000 N*Manage Company, Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
package org.opennms.bb.dp.actiond.components;

import java.net.*;
import java.io.*;
import java.util.*;
import com.sun.media.jsdt.*;

import org.xml.sax.SAXException;

import org.opennms.bb.common.components.*;
import org.opennms.bb.dp.common.components.*;

/**
 * <P>ActiondEventReceiver does the initial process/receiving of all
 * events coming over the eventd JSDT channel.</P>
 * 
 * <P>It extends the PollerClient and implements the 'ChannelConsumer' 
 * interface to receive the events
 *
 * @author 	<A HREF="mailto:mike@opennms.org">Mike</A>
 * @author 	<A HREF="mailto:weave@opennms.org">Brian Weaver</A>
 * @author 	<A HREF="mailto:sowmya@opennms.org">Sowmya Kumaraswamy</A>
 * @author	<A HREF="http://www.opennms.org">OpenNMS.org</A>
 *
 * @version	$Revision: 1.2 $
 */
public class ActiondEventReceiver extends PollerClient implements ChannelConsumer
{
	/**
	 * the event listener
	 */
	 private ActiondEventListener		m_eventListenerMain;

	/**
	 * queue to which the incoming event stream is to be added
	 */
	private PCQueue			m_listenerQ;

	/**
	 * The JSDT event session
	 */
	private Session			m_session;

	/**
	 * The JSDT channel on which eventd is broadcasting events
	 */
	private Channel			m_channel;

	/**
	 * Flag indicating that operation is to be paused
	 * For now events received are simply discarded during pause
	 */
	private boolean			m_pauseOperation;

	// This variable is strictly being used for debug purposes to 
	// keep track of the number of events received via JSDT
	private static int numEventsRcvd=0; // DEBUG ONLY

	/**
	 * If operation is not paused, add the incoming event to the 'listenerQ'
	 * as an input stream. Also get the EventListener to check if the
	 * the thread pool size needs to be adjusted</pre>
	 *
	 * @param data		received JSDT data 
	 */
	public synchronized void dataReceived(Data data)
	{
		if (m_pauseOperation)
			return;

		Log.print(Log.DEBUG, "Data received  via JSDT (" + ++numEventsRcvd + ")");

		try
		{
			/**
	 	  	 * Once the event has been read, create a
	 	  	 * org.xml.sax.InputSource from this
	 	  	 * stream and parse the event
	 	  	 */
			ByteArrayInputStream bis = new ByteArrayInputStream(data.getDataAsBytes());

			// add the new stream to the queue
			m_listenerQ.add(new ActiondEventsReader(bis));

			// Get 'EventListener' to check if the thread
			// pool size needs to be adjusted
			m_eventListenerMain.threadsVsQueueSizeCheck();

		}
		catch (InterruptedException iE)
		{
			// ignore???
			Log.print(Log.WARNING, "ActiondEventReceiver: Event ignored: Unable to add event stream to event listener queue" + iE.getMessage());
		}
		catch(QueueClosedException qE)
		{
			// ignore???
			Log.print(Log.WARNING, "ActiondEventReceiver: Event ignored: Unable to add event stream to event listener queue" + qE.getMessage());
		}

	}

	/**
	 * Connect to the eventd JSDT channel for event reception
	 *
	 * @throws java.lang.InterruptedException Thrown if the running
	 * 	thread is interrupted by another thread.
	 */
	private boolean jsdtConnect() throws InterruptedException
	{
		boolean sessionExists = false;
		boolean connected = false;

		try
		{

 			URLString url = URLString.createSessionURL(
					   PollerJSDTConstants.HOSTNAME, 
					   PollerJSDTConstants.EVENTS_SESSION_PORT,
					   PollerJSDTConstants.REGISTRY_TYPE, 
					   PollerJSDTConstants.EVENTS_SESSION_NAME);

			while (!sessionExists) 
			{
				try 
				{
					if (SessionFactory.sessionExists(url)) 
					{
                            			sessionExists = true;
					}
				} 
				catch (NoRegistryException nre) 
				{
					Thread.sleep(1000);
				} 
				catch (ConnectionException ce) 
				{
					Thread.sleep(1000);
				}
			} 

			m_session = SessionFactory.createSession(this, url, true);
			m_channel = m_session.createChannel(this, 
							    PollerJSDTConstants.EVENTS_SINK_CHANNEL,
							    true, 
							    false, 
							    true);
			m_channel.addConsumer(this, this);
			connected = true;
		} 
		catch (JSDTException e)
		{
			Log.print(Log.FATAL, e.getMessage());
			connected = false;
		}

		return connected;
	}


	/**
	 * Creates a ActiondEventReceiver for actiond
	 *
	 * @param 	eListener	the event listener
	 * @param	listenerQ	queue to which events sent in are to be added
	 * @exception throws a RunTimException if connection to JSDT fails
	 * @exception throws a SAXException if the events parser cannot be created
	 */
	public ActiondEventReceiver(ActiondEventListener eListener, PCQueue listenerQ) throws SAXException
	{
		super("ActiondEventsRecv");

		m_eventListenerMain = eListener;

		m_listenerQ = listenerQ;

		m_pauseOperation = false;

		//
		// Create the JSDT communication path to recieve events
		//
		try
		{
			Log.print(Log.INFORMATIONAL, "Trying to connect to JSDT registry ...");

			if(!jsdtConnect())
			{
				Log.print(Log.FATAL, "Actiond: Unable to create JSDT communication path");
				throw new RuntimeException("Unable to connect to JSDT Registry");
			}

			Log.print(Log.INFORMATIONAL, "JSDT communication channel up");
		}
		catch(InterruptedException e)
		{
			Log.print(Log.FATAL, "Actiond: Unable to create JSDT communication path");
			throw new RuntimeException("The jsdt connection thread was interrupted");

		}

		Log.print(Log.INFORMATIONAL, "Actiond ready to accept events via JSDT");

	}

	/**
	 * Pause the operation - ignore the received messages?
	 */
	public synchronized void pauseOperation()
	{
		m_pauseOperation = true;
	}

	/**
	 * Resume the paused operation
	 */
	public synchronized void resumeOperation()
	{
		m_pauseOperation = false;
	}

	/**
	 * <P>Removes itself as a consumer for the JSDT session and closes the session</P>
	 */
	public synchronized void shutdown()
	{
		// close JSDT m_session
		try
		{
			m_channel.removeConsumer(this, this);
			m_session.close(false);
		}
		catch(JSDTException jsdtE) 
		{
			Log.print(Log.WARNING, "Error closing the JSDT session for the ActiondEventReceiver");
			Log.print(Log.WARNING, jsdtE.getMessage());
		}

	}
}

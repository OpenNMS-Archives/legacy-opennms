//
// Copyright (C) 2000 N*Manage Company, Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
package org.opennms.bb.dp.actiond.components;

import java.util.*;
import java.io.*;

import org.opennms.bb.common.components.*;
import org.opennms.bb.dp.common.components.PollerThread;

/**
 * <P>Each ActionExec thread is responsible for starting a command
 * through a call to the Runtime.Exec() method and waiting for it
 * to complete.  When the command completes result and exit/failure
 * values are set which may be retrieved via the getcmdxxx() methods.
 * On Win32 environments, at attempt is made to convert common numeric
 * Win32 API error codes into meaningful failure text.</P>
 * 
 * @author 	<A HREF="mailto:mike@opennms.org">Mike</A>
 * @author	<A HREF="http://www.opennms.org">OpenNMS.org</A>
 *
 * @version	$Revision: 1.2 $
 */
public class ActionExec extends Thread
{
	//
	// Command execution result codes
	//
	public final static int CMD_RESULT_UNKNOWN	= -1;
	public final static int CMD_RESULT_SUCCESS	= 0;
	public final static int CMD_RESULT_FAIL	= 1;

	//
	// Exit value definitions
	//
	public final static int CMD_EXIT_VALUE_UNKNOWN = -1;
		 
	// 
	// Win32 specific error codes/text
	//
	private final static int WIN32_ERROR_FILE_NOT_FOUND = 2;
	private final static int WIN32_ERROR_PATH_NOT_FOUND = 3;
	private final static int WIN32_ERROR_ACCESS_DENIED 	= 5;
	private final static int WIN32_ERROR_BAD_EXE_FORMAT = 193;

	private final static String WIN32_TEXT_FILE_NOT_FOUND 	= "File not found";
	private final static String WIN32_TEXT_PATH_NOT_FOUND 	= "Path not found";
	private final static String WIN32_TEXT_ACCESS_DENIED 	= "Access denied";
	private final static String WIN32_TEXT_BAD_EXE_FORMAT 	= "Invalid executable format";


	/**
	 *  Value which indicates the result of the Runtime.exec()
	 *  call to start the command.  
	 *
	 *  One of the following values:  CMD_RESULT_UNKNOWN, CMD_RESULT_FAIL
	 *  or CMD_RESULT_SUCCESS
	 */
	private int m_cmdExecutionResult;

	/**
	 * If m_cmdExecutionResult is set to CMD_RESULT_SUCCESS, then this 
	 * variable will contain the exit code of the process as returned
	 * by Process.exitValue() call.
	 */
	private int m_cmdExitValue;  
	
	/** 
	 * If m_cmdExecutionResult is set to CMD_RESULT_FAIL then this
	 * String will contain the reason for the failure.  
	 */
	private String m_cmdFailureText;

	/**
	 * Command to be executed.
	 */
	private String m_command;

	/**
	 *  Reference to the parent object which started this thread.
	 *  This object will be notified (via Thread.notify()) when
	 *  the command has finished and all result/exit codes have
	 *  been set.
	 */
	private ActionLauncher m_actionLauncher;

	/**
	 * Operating system identifier string.  Used to determine how
	 * to parse operating system dependent IOException error message
	 * generated during call to Runtime.Exec() to start command.
	 */
	private static String m_osName;

	//
	// Static class initialization
	//
	static 
	{
		// Retrieve system property to identify operating system
		m_osName = System.getProperty("os.name");
		if(m_osName == null)
		{
			m_osName = "unknown";
		}
	}

	/**
	 * Constructs the ActionExec thread
	 *
	 * @param	command			Command string to be executed
	 * @param	actionLauncher	ActionLauncher object to be notified when command completes
	 */
	public ActionExec(String command, ActionLauncher actionLauncher)
	{
		m_command	= command;
		m_actionLauncher	= actionLauncher;
		m_cmdExecutionResult = CMD_RESULT_UNKNOWN;
		m_cmdExitValue = CMD_EXIT_VALUE_UNKNOWN;
		m_cmdFailureText = null;
	}

	/**
	 * Does the work of actually starting a separate process to 
	 * execute the command. 
	 */
	public void run()
	{
		boolean successFlag=false;
		boolean exceptionFlag=false;
		Process process = null;

		// Launch an executable program
    	try
    	{
      		// Create new process
			Log.print(Log.DEBUG, "ActionExec: Launching command \'" + m_command + "\'");   
      		process = Runtime.getRuntime().exec(m_command); 
				
      		// Wait for process to complete
      		process.waitFor();
		}

		catch (java.io.IOException ioe)
   		{ 
			exceptionFlag = true;
		   	Log.print(Log.DEBUG, "ActionExec: IOException processing command \'" + m_command + "\', exception: " + ioe);    

			//
			// For Win32 environments the format of the exception message is:
			// 		CreateProcess: <command> [args...] error=xxx 
			//          where <command> is the command to be executed
			//                [args...] are any optional arguments passed in to the command
			//       		  xxx is a Win32 err code (valid values: 0 - 10000)
			//
			// Below are a few of the more common error codes that might occur and their
			// desription:
			//			 		Error Code			Description
	 		//			      	---------------------------------
	 		//					2					FILE_NOT_FOUND
			//					3					PATH_NOT_FOUND
			//					5					ACCESS_DENIED
	 		//			      	193					BAD_EXE_FORMAT 
			//

			if (m_osName.startsWith("Windows"))
			{
				int errCode = -1;
				// Parse the exception message to retrieve the CreateProcess() error code
				String errMessage = ioe.getMessage();
				int index = errMessage.lastIndexOf("error=");
				if (index > -1) 
				{
					String strErrCode = errMessage.substring(index+6);
					Log.print(Log.DEBUG, "ActionExec: strErrCode=" + strErrCode);
	
					try
					{
						errCode = Integer.parseInt(strErrCode);
					} 
					catch (NumberFormatException nfe)
					{
					  	// Ignore
					}
				}
	
				// Try to provide some meaningful error text for common failure causes
				switch (errCode) 
				{
					case WIN32_ERROR_FILE_NOT_FOUND :
						m_cmdFailureText = WIN32_TEXT_FILE_NOT_FOUND;
						break;
					case WIN32_ERROR_PATH_NOT_FOUND :
						m_cmdFailureText = WIN32_TEXT_PATH_NOT_FOUND;
						break;
					case WIN32_ERROR_ACCESS_DENIED :
						m_cmdFailureText = WIN32_TEXT_ACCESS_DENIED;
						break;
					case WIN32_ERROR_BAD_EXE_FORMAT :
						m_cmdFailureText = WIN32_TEXT_BAD_EXE_FORMAT;
						break;
					default : 
						m_cmdFailureText = ioe.getMessage();
						break;
				}
			}

			// For non Windows environments just use the error text (atlest
			// the linux versions I've seen this run on provide some level
			// of descriptive text rather than just an error code.
			else
			{
				m_cmdFailureText = ioe.getMessage();
			}


			// Try to terminate the process...just in case
			try 
			{
				process.destroy();
			}
			catch (Exception e)
			{
				// ignore
			}
		}

		catch (InterruptedException ie)
   		{
			exceptionFlag = true;
   			Log.print(Log.DEBUG, "ActionExec: InterruptedException processing command \'" + m_command + "\', terminating process....");    

			// Try to terminate the process...just in case
			try 
			{
				process.destroy();
			}
			catch (Exception e)
			{
				// ignore
			}
   		}

		// Set appropriate command execution and exit values
		if (exceptionFlag == true)
		{
			Log.print(Log.DEBUG, "ActionExec: Setting cmd result to FAIL...");
			m_cmdExecutionResult = CMD_RESULT_FAIL;
		}
		else
		{
			Log.print(Log.DEBUG, "ActionExec: Command \'" + m_command + "\' executed successfully, exit value: " + process.exitValue());   
			m_cmdExecutionResult = CMD_RESULT_SUCCESS;

			// Set exit value
			m_cmdExitValue = process.exitValue();
		}
		
		// Notify the launcher thread that command processing is complete	
		synchronized(m_actionLauncher)
		{
			Log.print(Log.DEBUG, "ActionExec: Notifying action launcher thread...");
			m_actionLauncher.notify();
		}
 	}

	/**
	 * Get the command execution result code which indicates the
	 * success or failure of starting an external process/command.
	 * It does not indicate success or failure of the command itself.
	 */
	public int getCmdResult()
	{
		return m_cmdExecutionResult;
	}

	/**
	 * Get the command exit value.  
	 *
	 * Returns the command exit value.  If the command was successfully
	 * started and run then this value will be set to the exit value of
	 * the process/command as returned by Process.exitValue().  This value 
	 * can then be used to determine if the command ran successfully or not. 
	 */
	public int getCmdExitValue()
	{
		return m_cmdExitValue;
	}

	/**
	 * Get the command failure text.  
	 *
	 * Returns the command failure text string.  This value will only be
	 * non-null if m_cmdExecutionResult is set to CMD_RESULT_FAIL.
	 */
	public String getCmdFailureText()
	{
		return m_cmdFailureText;
	}

}

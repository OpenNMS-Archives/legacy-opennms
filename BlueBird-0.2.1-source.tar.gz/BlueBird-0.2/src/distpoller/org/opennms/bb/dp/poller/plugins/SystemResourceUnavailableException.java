//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
// $Id: SystemResourceUnavailableException.java,v 1.1 2000/10/26 22:11:12 weave Exp $
//
package org.opennms.bb.dp.poller.plugins;

/** 
 * <P>This class is thrown by a service monitor if it is unable to
 * acquire a system resource that it cannot function without. This is considered
 * a fatal exception and the operation will not be retried.</P>
 *
 * @author <A HREF="mailto:weave@opennms.org">Weave</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version $Revision: 1.1 $
 * 
 */
public class SystemResourceUnavailableException extends ResourceUnavailableException
{
	/**
	 * Constructs a new exception instance.
	 */
	public SystemResourceUnavailableException()
	{
		super();
	}
	
	/**
	 * Constructs a new exception instance with the specific message
	 *
	 * @param msg	The exception message.
	 *
	 */
	public SystemResourceUnavailableException(String msg)
	{
		super(msg);
	};
}

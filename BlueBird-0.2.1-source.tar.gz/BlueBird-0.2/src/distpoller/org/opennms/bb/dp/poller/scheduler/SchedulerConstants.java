//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.dp.poller.scheduler;

/**This class holds all of the constants used in the scheduler module.

   @author <A HREF="mailto:jason@opennms.org">Jason Johns</A>
   @author <A HREF="http://www.opennms.org/">OpenNMS</A>
   @version $Revision: 1.2 $
*/
public class SchedulerConstants
{
    /**This is the name of the property file where all changeable
       information regarding the filter module is kept. Other classes
       in the module will be examining the property file for information.
     */
    public static final String PROPERTY_FILE = "d:/bluebird/distpoller/org/opennms/bb/dp/poller/BlueBird.prop";

    /**This is the path to the pollers.xml file.
     */
    public static final String POLLER_XML = "org/opennms/bb/dp/poller/scheduler/utils/test/testPollers.xml" ;//"../xml/examples/pollers.xml";
    
    /**This is the path to the packages.xml file.
    */
    public static final String PACKAGE_XML = "org/opennms/bb/dp/poller/scheduler/utils/test/testPackages.xml"; //"../xml/examples/packages.xml";

    /**This is the path to the models.xml file.
    */
    public static final String MODELS_XML = "org/opennms/bb/dp/poller/scheduler/utils/test/testModels.xml"; //"../xml/examples/packages.xml";
    
    /**This is the property string in BlueBird.prop to get the database driver
       string.
     */
    public static final String FILTER_DB_DRIVER = "pollers.database.driver";
    
    /**This is the property string in BlueBird.prop to get the database url
       string.
     */
    public static final String FILTER_DB_URL = "pollers.database.url";
    
    /**This is the property string in BlueBird.prop to get the database username
       string.
     */
    public static final String FILTER_DB_USER = "pollers.database.user";
    
    /**This is the property string in BlueBird.prop to get the database password
       string.
     */
    public static final String FILTER_DB_PASSWORD = "pollers.database.passwd";
}

//
// Copyright (C) 2000 N*Manage Company, Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
// $Id: XMLEventsOverrideParser.java,v 1.1 2000/11/15 18:50:34 sowmya Exp $
//
//
package org.opennms.bb.dp.eventd;

import java.io.*;
import java.util.*;

import org.xml.sax.*;
import org.apache.xerces.parsers.SAXParser;

import org.opennms.bb.dp.events.*;

/**
 * <P>This class is an extension of the default events parser from the
 * events package and is used to ensure that non-modifiable fields are
 * stripped from incomming events. This is done by overriding the validate
 * method of the events parser and resetting any secured fields.<P>*
 *
 * <P>The security information is loaded at startup by the Eventd class
 * and the events configuration parser.</P>
 *
 *
 * @author	<A HREF="mailto:weave@opennms.org">Brian Weaver</A>
 * @author	<A HREF="http://www.opennms.org">OpenNMS.org</A>
 *
 * @version	$Revision: 1.1 $
 */
public class XMLEventsOverrideParser extends XMLEventsParser
{
	/**
	 * The list of non-modifiable events.
	 */
	private List	m_overrides;
	
	/**
	 * This overridden method is not use for validating the event
	 * so much as it is used to modify the event. The inbound event
	 * is checked againt the list of non-modifiable fields, and if
	 * one is found to be set then it is reset to a null value.
	 *
	 * @param event The event to validate/modify
	 *
	 * @return True if the event should be added to the list, false
	 * 	if it should not be added.
	 *
	 * @exception java.lang.ClassCastException Thrown if the initialized
	 *	override list contained non-String objects.
	 */
	protected boolean validate(Event e)
	{
		Iterator i = m_overrides.iterator();
		while(i.hasNext())
		{
			String field = (String)i.next();
			if(field.equals("descr"))
				e.setDescription(null);
			else if(field.equals("logmsg"))
				e.setLogMessage(null);
			else if(field.equals("severity"))
				e.setSeverity(null);
			else if(field.equals("operinstruct"))
				e.setOperatorInstruction(null);
			else if(field.equals("autoaction"))
				e.setAutoActions(null);
			else if(field.equals("operaction"))
				e.setOperatorActions(null);
			else if(field.equals("loggroup"))
				e.setLogGroups(null);
			else if(field.equals("notification"))
				e.setNotifications(null);
			else if(field.equals("tticket"))
				e.setTroubleTicket(null);
			else if(field.equals("forward"))
				e.setForwards(null);
			else if(field.equals("mouseovertext"))
				e.setMouseOverText(null);
		}
		return true;
	}
	
	/**
	 * <P>Constructs a new override parser that can be used to decompose an
	 * event stream. Each incomming event is checked to ensure that it
	 * does not have a non-modifiable field set. If a non-modifiable field
	 * is set then it is reset to null by this parser.</P>
	 *
	 * <P>The list is accessed from the Eventd class.</P>
	 *
	 * @param overrides	The list of element that will be reset to null during
	 *	parsing.
	 *
	 * @exception java.lang.IllegalArgumentException Thrown if the list from the Eventd
	 * 	class is not been initialized.
	 *
	 * @see Eventd#getOverrides
	 */
	public XMLEventsOverrideParser()
	{
		this(Eventd.getOverrides());
	}
	
	/**
	 * <P>Constructs a new override parser that can be used to decompose an
	 * event stream. Each incomming event is checked to ensure that it
	 * does not have a non-modifiable field set. If a non-modifiable field
	 * is set then it is reset to null by this parser.</P>
	 *
	 * <P>The list passed to this parser must be a list of String objects
	 * for use by the parser. If any element is not a String, or derived class
	 * thereof, then a ClassCastException may be thrown during parsing.</P>
	 *
	 * @param overrides	The list of element that will be reset to null during
	 *	parsing.
	 *
	 * @exception java.lang.IllegalArgumentException Thrown if the override
	 * 	list is null.
	 */
	public XMLEventsOverrideParser(List overrides)
	{
		if(overrides == null)
			throw new IllegalArgumentException("Invalid list of overrides passed to method");
		
		m_overrides = overrides;
	}
}


//
// Copyright (C) 2000 N*Manage Company Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
// $Id: ServiceMonitorICMP.java,v 1.4 2000/11/14 21:32:10 mike Exp $
//
package org.opennms.bb.dp.poller.plugins;

import java.net.*;
import java.util.*;
import java.io.*;
import java.lang.*;
import java.util.Properties; 

import com.sun.media.jsdt.*;
import org.apache.xerces.parsers.*;
import org.xml.sax.*;

import org.opennms.bb.common.components.*;
import org.opennms.protocols.ip.*;
import org.opennms.bb.dp.poller.parsers.MonitorResponseParser;
import org.opennms.bb.dp.common.components.PollerSession;
import org.opennms.bb.dp.common.components.PollerClient;

import org.opennms.bb.common.components.Log; // For debug purposes only

/**
 * <P>This class is designed to be used by the service poller
 * framework to test the availability of the ICMP service on 
 * remote interfaces. The class implements the ServiceMonitor
 * interface that allows it to be used along with other
 * plug-ins by the service poller framework.</P>
 *
 * <P> The ICMP service monitor relies on the discovery process
 * to generate the actual ICMP 'PING's.  This monitor does
 * NOT communicate with the ICMP daemon. The ICMP service monitor
 * sends/receives XML/SOAP encoded poll requests/results to/from 
 * discovery via JSDT.</P>
 *
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version CVS $Revision: 1.4 $
 *
 */
public class ServiceMonitorICMP implements ServiceMonitor
{	
	/** 
	 * Name of monitored service.
	 */
	private static final String SERVICE_NAME	= "ICMP";

	/** 
	 * Default retries.
	 */
	private static final int DEFAULT_RETRY = 0;

	/** 
	 * Default timeout.  Specifies how long (in milliseconds) to block waiting
	 * for data from the monitored interface.
	 */
	private static final int DEFAULT_TIMEOUT = 3000;

	/*
	 * JSDT communication related parameters
	 */

	/**
	 * <P>The JSDT session used for service monitor - discovery
	 * communication.</P>
	 */
	private Session m_session;
	
	/**
	 * <P>The JSDT channel through which ICMP poll requests
	 * will be sent to discovery.</P>
	 */
	private Channel m_requestChannel;
	
	/**
	 * <P>The JSDT channel through which ICMP poll results
	 * will be received from discovery.</P>
	 */
	private Channel m_replyChannel;

	/**
	 * <P>The client that is joined to the monitor request channel
	 * of the discovery-monitor JSDT session.</P>
	 */
	private PollerClient 		m_requestClient;

	/**
	 * <P>This is the prefix of the JSDT client name which will be 
	 * used to send ICMP poll requests to discovery. A numeric identifier 
	 * which identifies the instance of the service monitor will be 
	 * appended to make the name unique.</P>
	 */
	private static final String	JSDT_CLIENT_SENDER_NAME_PREFIX = "MonitorRequestSend:";

	/**
	 * <P>This is the prefix of the JSDT client name which will be 
	 * used to receive ICMP poll results from discovery. A numeric identifier 
	 * which identifies the instance of the service monitor will be 
	 * appended to make the name unique.</P>
	 *
	 * WARNING:  This value must match the prefix defined in 
	 * 		the MonitorPinger class of discovery.
	 */
	private static final String	JSDT_CLIENT_RECEIVER_NAME_PREFIX = "MonitorReplyRecv:";

	/**
	 * <P>This is the JSDT client name to whom the ICMP service monitor
	 * sends ICMP poll requests.
	 *
	 * WARNING:  This value must match the name defined in the 
	 *  	MonitorRequestReceiver class of discovery.
	 */
	private static final String JSDT_CLIENT_DISCOVER_RECEIVER_NAME = "MonitorRequestRecv";

	/**
	 * <P>Static class counter which is incremented each time a new
	 * service monitor is constructed.</P>
	 */
	private static int m_instanceCounter = 0;

	/** Uniquely identifies a particular service monitor instance.
	 * This id will be appended to the JSDT_CLIENT_*_NAME_PREFIX values to 
	 * generate unique client names for each service monitor instance.  
	 * Discovery will in turn use the JSDT sendToClient() call rather 
	 * than the sendToOther() call so that only the service monitor 
	 * that sent a particular poll request will receive the response.</P>
	 */
	private int m_instanceID;

	/**
	 * <P>The consumer object is the final endpoint
	 * of data sent from the discovery to the service monitor. The 
	 * consumer receives messages from the session, through the
	 * channel. This class extends PollerClient so it is also
	 * a JSDT client.</P>
	 */
	private MonitorReplyConsumer m_consumer;
		
	/** <P>List of NetworkInterface objects associated with outstanding
	 *  requests.  Each NetworkInterface object in the list will have a
	 *  THREAD_KEY attribute which contains a reference
	 *  to the blocked thread and a STATUS_KEY attribute
	 *  which will be set to the result of the ICMP poll for that interface.</P>
	 */
	private List m_interfaceList;

	/** 
	 * <P> Used to store/access the thread object which is waiting on a 
	 * poll response in the NetworkInterface's attributes.</P>
	 */
	private static final String THREAD_KEY = "org.opennms.bb.dp.poller.plugins.ServiceMonitorICMP.thread";

	/** 
	 * <P> Used to store/access the status of the ICMP poll for a
	 * particular NetworkInterface.</P>
	 */
	private static final String STATUS_KEY = "org.opennms.bb.dp.poller.plugins.ServiceMonitorICMP.status";

	/**
	 * <P>This static class is used to build a compliant SOAP
	 * document that is sent to discovery in order to initiate a
	 * ICMP poll. No instances of this class may be created.</P>
	 */
	private static final class RequestToSoapDocument
	{
		/**
		 * SOAP Envelope tag, fully qualified
		 */
		private static final String SOAP_ENV	= "SOAP-ENV:Envelope";
		
		/**
		 * SOAP Body tag, fully qualified.
		 */
		private static final String SOAP_BODY	= "SOAP-ENV:Body";
		
		/**
		 * SOAP Namespace string
		 */
		private static final String SOAP_NS	= "http://schemas.xmlsoap.org/soap/envelope/";
		
		/**
		 * SOAP Namespace tag.
		 */
		private static final String SOAP_NSTAG	= "SOAP-ENV";
		
		//
		// Relevant XML Tags
		//
		private static final String MONITOR_REQUEST	= "Discovery:MonitorRequest";
		private static final String REQUEST 		= "Discovery:request";
		private static final String IPV4ADDR 		= "Discovery:ipv4Address";
		private static final String PARMS			= "Discovery:parms";
		private static final String PARM 			= "Discovery:parm";
		private static final String PARMNAME 		= "Discovery:parmName";
		private static final String PARMVALUE		= "Discovery:parmValue";
		
		/**
		 * Document namespace
		 */
		private static final String DISC_NS	= "http://dtds.opennms.org/bluebird/discovery/MonitorRequest/";
		
		/**
		 * Document namespace tag.
		 */
		private static final String DISC_NSTAG	= "Discovery";
		
		/**
		 * Creates a proper XML start tag.
		 *
		 * @param tag	The tag name
		 * @param out	The output stream.
		 */
		private static void startTag(String tag, PrintStream out)
		{
			out.println("<" + tag + ">");
		}
		
		/**
		 * Creates a proper XML start tag with namespace
		 *
		 * @param tag	The tag name
		 * @param ns	The namespace uri
		 * @param nstag	The namespace tag for the uri
		 * @param out	The output stream.
		 */
		private static void startTag(String tag, String ns, String nstag, PrintStream out)
		{
			out.println("<" + tag + " xmlns:" + nstag + "=\"" + ns + "\">");
		}
		
		/**
		 * Creates a proper XML end tag.
		 *
		 * @param tag	The tag name
		 * @param out	The output stream.
		 */
		private static void endTag(String tag, PrintStream out)
		{
			out.println("</" + tag + ">");
		}
		
		/**
		 * <P>Generates a properly formatted XML SOAP document
		 * that is suitable for requesting an ICMP service monitor
		 * poll request.</P>
		 *
		 * @param addr	The IPv4Address for the document.
		 * @param retry	Number of times to re-send the ICMP ping
		 * @param timeout	Number of milliseconds to wait for ICMP ping response
		 *
		 * @return The document as a byte array.
		 */
		public static synchronized byte[] generate(IPv4Address addr, int retry, int timeout)
		{
			ByteArrayOutputStream bout = new ByteArrayOutputStream();
			PrintStream prn = new PrintStream(bout);
			
			startTag(SOAP_ENV, SOAP_NS, SOAP_NSTAG, prn);
				startTag(SOAP_BODY, prn);
					startTag(MONITOR_REQUEST, DISC_NS, DISC_NSTAG, prn);
						startTag(REQUEST, prn);
							startTag(IPV4ADDR, prn);
								prn.println(addr.toString());
							endTag(IPV4ADDR, prn);
							startTag(PARMS, prn);
								startTag(PARM, prn);
									startTag(PARMNAME, prn);
										prn.println("retry");
									endTag(PARMNAME, prn);
									startTag(PARMVALUE, prn);
										prn.println(retry);
									endTag(PARMVALUE, prn);
								endTag(PARM, prn);
								startTag(PARM, prn);									
									startTag(PARMNAME, prn);
										prn.println("timeout");
									endTag(PARMNAME, prn);
									startTag(PARMVALUE, prn);
										prn.println(timeout);
									endTag(PARMVALUE, prn);
								endTag(PARM, prn);
							endTag(PARMS, prn);
						endTag(REQUEST, prn);
					endTag(MONITOR_REQUEST, prn);
				endTag(SOAP_BODY, prn);
			endTag(SOAP_ENV, prn);
			prn.flush();
			
			return bout.toByteArray();
		}
	}	

	/** 
	 * Increments and returns the next instance id value which
	 * can be used to distinguish between multiple instances
	 * of the service monitor.
	 */
	private static synchronized int getNextInstanceID()
	{
		return (m_instanceCounter++);
	}

	/**
	 * <P>Creates JSDT channels for communication with discovery.
	 * Establishes in inbound channel with a consumer for handling
	 * incoming ICMP poll replies from discover and an outbound
	 * channel for sending ICMP poll requests.</P>
	 *
	 * <P>If an error occurs then an exception will be thrown from
	 * the code. Be aware that this method will wait until a connection
	 * or fatal error occurs before returning control to the caller.
	 * Callers should make provisions to ensure that any locks that are
	 * held prior to calling jsdtConnect will not cause negative deadlock
	 * issues.</P>
	 *
	 * @exception  JSDTException thrown if the JSDT communication channel 
	 *	cannot be established or other error conditions occur.
	 */
	private void jsdtConnect()  
		throws JSDTException
	{
		try
		{
			//
			// Create the JSDT connection URL that is
			// used to connect to discovery subsystem.
			//
 			URLString url = URLString.createSessionURL(PollerSession.hostName, 
								   PollerSession.monitorPort,
								   PollerSession.sessionType, 
								   PollerSession.monitorSessionName);
			
			//
			// while false the JSDT registry has not
			// created the session internally, this
			// will remain false.
			//
			boolean sessionExists = false;

			//
			// While there is not a session to connect to
			// loop and retry every second. If the thread
			// is marked for cancellation prior to completing
			// the connection, then a failure is returned by
			// the method.
			//
			while (!sessionExists) 
			{
				try 
				{
					//
					// Try to connect to the session, if
					// the session exists then it will
					// be marked and the while loop will
					// exit.
					//
					if (SessionFactory.sessionExists(url)) 
					{
                    	sessionExists = true;
					} 
					else
					{
						Thread.sleep(1000);
					}

				} 
				catch(InterruptedException ie)
				{
					//
					// Re-throw as a JSDT timed out exception
					//
					throw new com.sun.media.jsdt.TimedOutException();
				}
				catch(NoRegistryException nre) 
				{
					//
					// Re-throw the no registry exception
					//
					throw new com.sun.media.jsdt.NoRegistryException();
				} 
				catch (ConnectionException ce) 
				{
					//
					// Re-throw the Connection Exception
					//
					throw new com.sun.media.jsdt.ConnectionException();
				}
			} // end while loop for registry connection

			// 
			// create request channel and client for sending poll requests
			// to discovery.  
			//
			// Generate unique JSDT client sender name.  When discovery receives
			// the request it will save the client name and use it later to 
			// build the client receive name in order to only send the response
			// to the service monitor instance that generated the request.
			String clientSender = JSDT_CLIENT_SENDER_NAME_PREFIX + m_instanceID;
			Log.print(Log.DEBUG, "ServiceMonitorICMP.JSDTConnect: JSDT client sender name: " + clientSender);
			m_requestClient  = new PollerClient(clientSender);
			
			m_session = SessionFactory.createSession(m_requestClient, url, true);
			
			m_requestChannel = m_session.createChannel(m_requestClient, 
							    PollerSession.monitorRequestChannelName,
							    true, 
							    false, 
							    true);


			//
			// create the reply channel and consumer for receiving the replies 
			// from discovery.  The consumer is also a client.  Add the 
			// consumer to the channel so it's dataReceived() method will
			// be called when JSDT receives a message addressed to the client.
			//
			// Generate unique client receiver name. This is the name that 
			// discovery will send poll result messages to over JSDT.  The 
			// instance id will be obtained from the original request.
			String clientReceiver = JSDT_CLIENT_RECEIVER_NAME_PREFIX + m_instanceID;
			Log.print(Log.DEBUG, "ServiceMonitorICMP.JSDTConnect: JSDT client rcv name: " + clientReceiver);
			m_consumer = new MonitorReplyConsumer(clientReceiver);

			m_session = SessionFactory.createSession(m_consumer, url, true);

			m_replyChannel = m_session.createChannel(m_consumer, 
							    PollerSession.monitorReplyChannelName,
							    true, 
							    false, 
							    true);

			m_replyChannel.addConsumer(m_consumer, m_consumer);

			
		} 
		catch (JSDTException e)
		{	
			//
			// Unwind the creation of the session if possible
			//
			if(m_session != null)
			{
				try
				{
					m_session.close(false);
				}
				catch(Exception ex)
				{
					//Ignore
				}
			}

			//
			// Rethrow the execption for the caller to handle
			// pass on up the stack.
			//
			throw e;
		}
	}

	/**
	 * <P>The MonitorReplyConsumer class is responsible for handling
	 * incoming ICMP poll reply messages from discovery.
	 * This class implements the JSDT ChannelConsumer interface.
	 * When JSDT receives a message bound for this client, this classes
	 * dataReceived() method will be invoked to process the message.</P>
	 *
	 * @author <A HREF="mailto:mike@opennms.org">Mike</A>
	 * @author <A HREF="mailto:sowmya@opennms.org">Sowmya</A>
	 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
	 *
	 * @version $Revision: 1.4 $
	 */
	private final class MonitorReplyConsumer 
		extends    PollerClient 
		implements ChannelConsumer
	{
		/**
		 * <P>Xerces SAX parser used to parse the SOAP exchanges.</P>
		 */
		private SAXParser m_parser;		// reusable parser
		
		/**
		 * <P>SAX ContentHandler and ErrorHandler class. This actually
		 * processes the SAX events and stores the data.</P>
		 */
		private MonitorResponseParser m_handler;	// reusable handler
		
		/**
		 * <P>The default constructor is used to assign a JSDT client
		 * name to this object. Once the client is named then the
		 * class can receive messages through the JSDT channels.</P>
		 *
		 * @param name	The name of the JSDT client.
		 */
		public MonitorReplyConsumer(String name)
		{
			super(name);
			m_parser = new SAXParser();
			m_handler= new MonitorResponseParser();
			
			m_parser.setErrorHandler(m_handler);
			m_parser.setContentHandler(m_handler);
		}

		/**
		 * <P>The dataReceived method is defined in the
		 * JSDT ChannelConsumer interface. The method receives
		 * the ICMP poll reply message from the discovery subsystem
		 * and enqueues the data into the passed queue.</P>
		 *
		 * @param data The actual JSDT data object containing
		 * 	the address string.
		 */
		public synchronized void dataReceived(Data data)
		{
			Log.print(Log.DEBUG, "MonitorReplyReceiver.dataReceived(): SOAP message received from discovery!");
			
			//
			// Parse the input stream to extract poll reply messages from discovery
			//
			try
			{
				ByteArrayInputStream istream = new ByteArrayInputStream(data.getDataAsBytes());
				m_parser.parse(new InputSource(istream));
				List replies = m_handler.getResponses();
				if(replies != null)
				{
					//
					// Process each poll reply
					//
					Iterator iter = replies.iterator();
					while(iter.hasNext())
					{ 				
						PollResponseAddress tempAddr = (PollResponseAddress)iter.next();
						Log.print(Log.DEBUG, "MonitorReplyReceiver.dataReceived(): Address: " + tempAddr.getAddress() + " Status: " + tempAddr.getStatus());
						
						synchronized(m_interfaceList)
						{
							NetworkInterface iface = null;

							//
							// iterate through the interface list and find the interface
							// that matches this reply.  Then set the interface's status
							// attribute (STATUS_KEY) with the result of the poll.  Finally, retrieve
							// a reference to the thread object (THREAD_KEY) which is blocked waiting for 
							// the poll response for this interface and signal it to wake up
							// and retrieve the response via java.lang.object.notifyAll() method.
							//
							Iterator listIter = m_interfaceList.iterator();
							while (listIter.hasNext())
							{
								iface = (NetworkInterface)listIter.next();
								if (iface.getAddress().toString().equals(tempAddr.getAddress()))
								{
									listIter.remove();
									Thread thr;
									synchronized(iface)
									{
										// Set the status of the poll for this interface
										iface.setAttribute(STATUS_KEY, tempAddr.getStatus());
										// Get the thread object which is blocked waiting for this poll result
										thr = (Thread)iface.getAttribute(THREAD_KEY);
										iface.setAttribute(THREAD_KEY, null);
									}
									Log.print(Log.DEBUG, "MonitorReplyReceiver.dataReceived(): found match, address: " + tempAddr.getAddress() + " thread: " + thr);
			
									synchronized(thr)
									{
										// Wake the blocked thread so it can retreive the
										// status of the poll.
										thr.notifyAll(); 
										break;
									}
								}
							}
						}
					}
				}
			}
			catch(Exception e) 
			{
				//
				// Ignore?
				//
			}
		}
	}

	/** 
	 * Constructs a new ICMP service monitor object.
	 *
	 * All the constructor does is obtain the next valid
	 * instance ID and assign it to m_instanceID.  This value
	 * will be used to establish unique send/recv JSDT client
	 * names for each instance of the service monitor.
	 */
	 public ServiceMonitorICMP()
	 {
		// Assign the instance identifer that will uniquely
		// identify this instance of the service monitor.
		m_instanceID = getNextInstanceID();
		Log.print(Log.DEBUG, "ServiceMonitorICMP.constructor: instance ID: " + m_instanceID + " nextInstance: " + m_instanceCounter);
	 }

	/**
	 * <P>Returns the name of the service that the plug-in monitors ("ICMP").</P>
	 *
	 * @return The service that the plug-in monitors.
	 */
	public String serviceName()
	{
		return SERVICE_NAME;
	}
	
	/**
	 * <P>Initialize the service monitor.</P>
	 *
	 * @param proxy		The object that can be used to load/save config information.
	 * @param parameter	The parameters from the appropiate package(s).
	 *
	 * @exception org.opennms.bb.dp.poller.plugins.ServiceMonitorException	Thrown if
	 * 	an unrecoverable error occurs that prevents the plug-in from functioning.
	 *
	 */
	public void initialize(ConfigurationProxy proxy, Properties parameters) 
		throws ServiceMonitorException
	{
		// Interface list initialization
		m_interfaceList = Collections.synchronizedList(new ArrayList());
		
		//
		// Establish JSDT connections for communication with discovery.
		//
		try 
		{
			jsdtConnect();
		}
		catch (NoRegistryException e)
		{
			throw new ResourceUnavailableException("JSDT registry not running - unable to establish JSDT communication channels.");
		}
		catch (ConnectionException e)
		{
			throw new ResourceUnavailableException("JSDT Connection Exception - unable to establish JSDT communication channels.");
		}	
		catch (JSDTException e)
		{
			throw new ResourceUnavailableException("Unable to establish JSDT communication channels.");
		}
		Log.print(Log.DEBUG, "ServiceMonitorICMP.initialize(): JSDT communication channels established.");
	}
		
	/**
	 * <P>Called by the poller framework when the plug-in is being unloaded.
	 * Any resources still being used by the monitor are released.</P>
	 *
	 * @exception org.opennms.bb.dp.poller.plugins.ServiceMonitorException	Thrown if
	 * 	an error occurs during deallocation.	
	 *
	 */
	public void release() 
		throws ServiceMonitorException
	{
		// Close the JSDT Session
		//
		try
		{
			m_session.close(false);
		}
		catch(Exception e) 
		{
			//
	 		// Ignore the exception...should we throw a ServiceMonitorException here?
			//
		}
		finally
		{
			m_session = null;
		}
		return;
	}
	
	/**
	 * <P>Called by the poller framework when an interface is being added
	 * to the scheduler.  Here we perform any necessary initialization
	 * to prepare the NetworkInterface object for polling.</P>
	 *
	 * @param iface		The network interface to be added to the scheduler.
	 *
	 * @exception org.opennms.bb.dp.poller.plugins.ServiceMonitorException	Thrown if
	 * 	an unrecoverable error occurs that prevents the interface from being monitored.
	 *
	 */
	public void initialize(NetworkInterface iface) 
		throws ServiceMonitorException
	{
	 	return;
	}
	
	/**
	 * <P>Called by the poller framework when an interface is being removed from
	 * the scheduler.  Here we free any resources or save any persistent 
	 * information associated with the interface.</P>
	 *
	 * <P>If an exception is thrown during the release the exception will be
	 * logged, but the interface will still be discarded for garbage collection.</P>
	 *
	 * @param iface		The network interface that was being monitored.
	 *
	 * @exception org.opennms.bb.dp.poller.plugins.ServiceMonitorException	Thrown if
	 * 	an unrecoverable error occurs for the interface.
	 */
	public void release(NetworkInterface iface) 
		throws ServiceMonitorException
	{
		return;
	}
	
	/**
	 * <P>Poll the specified address for ICMP service availability.</P>
	 *
	 * <P>The ICMP service monitor relies on Discovery for the actual
	 * generation of IMCP 'ping' requests.  A JSDT session with two
	 * channels (send/recv) is utilized for passing poll requests and
	 * receiving poll replies from discovery.  All exchanges are
	 * SOAP/XML compliant.</P>
	 *
	 * @param iface		The network interface to test the service on.
	 * @param eproxy 	The event proxy object for sending custom events.
	 * @param parameters	The package parameters (timeout, retry, etc...) to be 
	 *  used for this poll.
	 *
	 * @return The availibility of the interface and if a transition event
	 * 	should be supressed.
	 *
	 */
	public int poll(NetworkInterface iface, EventProxy eproxy, Properties parameters) 
		throws ServiceMonitorException
	{
		int serviceStatus = SERVICE_UNAVAILABLE;
		Socket  portal    = null;
		String	localName = null;
		InetAddress inetAddr = null;

		int retry = DEFAULT_RETRY;  		// Number of additional attempts to be made.
		int timeout = DEFAULT_TIMEOUT;  	// How long to block waiting for data (in milliseconds).

		//
		// Process parameters
		//

		// Retry
		String strRetry = parameters.getProperty("retry");
		if(strRetry != null)
		{
			try	{ retry = Integer.parseInt(strRetry);	}
			catch(NumberFormatException ne) { retry = DEFAULT_RETRY; }	
		} 
		
		// Timeout
		String strTimeout = parameters.getProperty("timeout");
		if (strTimeout == null)
			timeout = DEFAULT_TIMEOUT;
	    else
		{
			try
			{
				timeout = (int)convertTimeToLong(strTimeout);
			}
			catch(NumberFormatException ne) { timeout = DEFAULT_TIMEOUT; }
		}

		//
		// Get interface address from NetworkInterface
		//
		if (iface.getType() != iface.TYPE_IPV4)
			throw new ServiceMonitorException("Unsupported interface type, only TYPE_IPV4 currently supported");

		IPv4Address ipv4Addr = (IPv4Address)iface.getAddress();

		// Generate SOAP/XML message and forward to discovery through JSDT request channel.
		// generate() is a synchronized method to prevent corruption by multiple threads
		// attempting to generate XML stream at the same time.
		Log.print(Log.DEBUG, "ServiceMonitorICMP.poll: address: " + ipv4Addr.toString() + " timeout: " + timeout + " retry: " + retry);
		Data data = new Data(RequestToSoapDocument.generate(ipv4Addr, retry, timeout));
		try
		{
			// Synchronize on the request channel
			// so multiple threads can't try to send
			// simultaneously.
			synchronized(m_requestChannel)
			{
				m_requestChannel.sendToClient(m_requestClient, JSDT_CLIENT_DISCOVER_RECEIVER_NAME, data);
			}
		}
		catch(JSDTException e)
		{
			throw new ServiceMonitorException("JSDTException received while attempting to send poll request to discovery for address '" + ipv4Addr.toString() + "'");
		}

		// Add the current thread object to the attributes of the NetworkInterface object
		// so that the response handler can notify on this thread when the associated
		// response is available.
		synchronized(iface)
		{
			iface.setAttribute(THREAD_KEY, Thread.currentThread());
		}
		Log.print(Log.DEBUG, "ServiceMonitorICMP.poll(): added thread network interface, thread: " + Thread.currentThread());

		// Now add this NetworkInterface to the interface list
		synchronized(m_interfaceList)
		{
			m_interfaceList.add(iface);
		}

		synchronized(Thread.currentThread())
		{
          	try
       		{
				// Specifying a timeout on the wait will keep us
				// from waiting indefinitely if discovery is not running
				// or there is some other problem that keeps the thread
				// from being notified. 
				int waitTimeout = ((retry+1) * timeout) * 2; // basically just double the max time to process all retries
   				Thread.currentThread().wait( waitTimeout);
            }
            catch(InterruptedException ie)
            {
				throw new ServiceMonitorException("Interrupted while waiting for ICMP poll reply for address '" + ipv4Addr.toString() + "'");
            }
		}
		Log.print(Log.DEBUG, "ServiceMonitorICMP.poll(): Just woke up to process response...thread: " + Thread.currentThread());
		
		// 
		// When we reach this point there should be a 
		// poll status available for the interface.
		//
		String status;
		synchronized(iface)
		{
			status = (String)iface.getAttribute(STATUS_KEY);
			iface.setAttribute(STATUS_KEY, null);
		}

		// status should only be null if the previous wait() condition
		// timed out because discovery did not respond or some other
		// JDST error
		if (status == null)
		{
			// Not sure we want to throw exception here, perhaps just log and return UNAVAILABLE?
			throw new ServiceMonitorException("Timed out waiting for ICMP poll result from discovery for address '" + ipv4Addr.toString() + "'");
		}
		else 
		{
			if (status.equals(PollResponseAddress.STATUS_AVAILABLE))
				serviceStatus = SERVICE_AVAILABLE;
			else
				serviceStatus = SERVICE_UNAVAILABLE;
		}

		
		//
		// return the status of the service
		//
		return serviceStatus;
	}

	/**
	 * <P>Converts the passed time string to a time value that is 
	 * measured in milliseconds. The following extension are considered
	 * when converting the string:</P>
	 *
	 * <TABLE BORDER=0>
	 *	<TR><TH>Extension</TH><TH>Conversion Value</TH></TR>
	 *	<TR><TD>us</TD><TD>Microseconds</TD></TR>
	 *	<TR><TD>ms</TD><TD>Milliseconds</TD></TR>
	 *	<TR><TD>s</TD><TD>Seconds</TD></TR>
	 *	<TR><TD>m</TD><TD>Minutes</TD></TR>
	 *	<TR><TD>h</TD><TD>Hours</TD></TR>
	 *	<TR><TD>d</TD><TD>Days</TD></TR>
	 * </TABLE>
	 *
	 * <P>A number entered with out any units is considered to be
	 * in milliseconds.</P>
	 *
	 * @param valueToConvert	The string to convert to milliseconds.
	 *
	 * @return Returns the string converted to a millisecond value.
	 *
	 * @exception java.lang.NumberFormatException Thrown if the string is
	 * 	malformed and a number cannot be extracted from the value.
	 *
	 */
	private static long convertTimeToLong(String valueToConvert)
		throws NumberFormatException
	{
		String timeVal = valueToConvert.toLowerCase();
		int   index    = 0;
		float factor   = 1.0f;

		if(timeVal.endsWith("us"))
		{
			factor = 0.001f;
			index  = timeVal.indexOf("us");
		}
		else if(timeVal.endsWith("ms"))
		{
			factor= 1.0f;
			index = timeVal.indexOf("ms");
		}
		else if(timeVal.endsWith("s"))
		{
			factor = 1000.0f;
			index = timeVal.indexOf("s");
		}
		else if(timeVal.endsWith("m"))
		{
			factor = 1000.0f * 60.0f;
			index = timeVal.indexOf("m");
		}
		else if(timeVal.endsWith("h"))
		{
			factor = 1000.0f * 60.0f * 60.0f;
			index = timeVal.indexOf("h");
		}
		else if(timeVal.endsWith("d"))
		{
			factor = 1000.0f * 60.0f * 60.0f * 24.0f;
			index = timeVal.indexOf("d");
		}
		
		if(index == 0)
		{
			index = timeVal.length();
		}
		
		Float fVal = new Float(timeVal.substring(0, index));
		return ((long)(fVal.floatValue() * factor));
		
	} // end convertTimeToLong()
}


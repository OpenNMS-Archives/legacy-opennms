//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.dp.poller.scheduler.utils;

import java.util.*;

/**This class is a representation of a BlueBird model as parsed
 * from the models.xml file.
 * 
 * @author <A HREF="mailto:jason@opennms.org">Jason Johns</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version $Revision: 1.1 $
 * 
 */
public class ModelInterval
{
	/**
	*/
	public static final String DELETE = "delete";
	
	/**
	*/
	private String m_begin;
	
	/**
	*/
	private String m_end;
	
	/**
	*/
	private String m_value;
	
	/**
	*/
	public ModelInterval()
	{
	}
	
	/**
	*/
	public void setBegin(String aBegin)
	{
		m_begin = aBegin;
	}
	
	/**
	*/
	public void setEnd(String anEnd)
	{
		m_end = anEnd;
	}
	
	/**
	*/
	public void setValue(String aValue)
	{
		m_value = aValue;
	}
	
	/**
	*/
	public String getBegin()
	{
		return m_begin;
	}
	
	/**
	*/
	public String getEnd()
	{
		return m_end;
	}
	
	/**
	*/
	public String getValue()
	{
		return m_value;
	}
	
	/**
	*/
	public String toString()
	{
		return "Interval\r\n" + "Begin = " + m_begin + "\r\n" +
			                "End   = " + m_end + "\r\n" +
					"Value = " + m_value;
	}
}

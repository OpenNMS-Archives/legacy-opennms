//
// Copyright (C) 2000 N*Manage Company Inc.
// Copyright (C) 2000 PlatformWorks, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
// Tab Size = 8
//
// $Id: IPGenerator.java,v 1.15 2000/09/20 20:44:35 sowmya Exp $
//

package org.opennms.bb.dp.discovery.components;

import java.lang.*;
import java.util.*;

import org.opennms.bb.common.components.PCQueue;
import org.opennms.bb.common.components.Log;
import org.opennms.bb.dp.common.components.PollerThread;

/**
 * <P>IPGenerator queues the list of specific IPAddresses to be pinged
 * and then expands the m_ranges and queues those addresses one at a time
 * It adds the addresses to a 'm_generatedQ' to be read by the
 * DiscPingManager.</P>
 *
 * @author <A HREF="mailto:sowmya@opennms.org">Sowmya</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version $Revision: 1.15 $
 */
public class IPGenerator extends PollerThread
{
	/**
	 * The specific list items to be iterated through
	 */
	private List		m_specifics;
	
	/**
	 * The range of items to be enumerated through
	 */
	private List		m_ranges;	
	
	/**
	 * The list of items that are known by the application
	 * (to be excluded from ping)
	 */
	private Set		m_knownNodes;

	/**
	 * The output queue for placing generated addresses
	 */
	private PCQueue		m_generatedQ;

	/**
	 * <P>Constructs a generator object that iterates
	 * through the list of specific addresses. It also
	 * generates new addresses from the ranges. All
	 * generated addresses are placed into the output
	 * queue if they are not found in the knownNodes
	 * list.</P>
	 *
	 * @param ranges	The range list for address generation
	 * @param specific	The list of specific nodes.
	 * @param knownNodes	The list of known nodes
	 * @param Q		The output queue
	 *
	 */
	public IPGenerator(List ranges, 
			   List specifics, 
			   Set knownNodes, 
			   PCQueue Q)
	{
		//
		// initialize the superclass
		//
		super();
		
		//
		// initialize the queue
		//
		m_generatedQ = Q;

		//
		// set the addresses
		//
		m_ranges     = ranges;
		m_specifics  = specifics;
		m_knownNodes = knownNodes;
	}
	
	/**
	 * <P>The main routine invoked by the base class
	 * java.lang.Thread.</P>
	 *
	 */
	public void run()
	{
		setOpStatus(STATUS_NORMAL);

		//
		// Used to iterate through the addresses
		//
		int		nextSpecific = 0;
		int		nextRange    = 0;
		Enumeration 	nextRangeAddr= null;

		for(;;)
		{
			//
			// Process the possible status changes
			//
			synchronized(this)
			{
				int status = getOpStatus();
				while(status != STATUS_NORMAL)
				{
					if(status == STATUS_PAUSING)
					{
						setOpStatus(STATUS_PAUSED);
						try
						{
							notifyAll();
							wait();
						}
						catch(InterruptedException e)
						{
							// interrupted, should exit?
						}
					}
				
					if(status == STATUS_RESUMING)
					{
						setOpStatus(STATUS_NORMAL);
						notifyAll();
					}
					else if(status == STATUS_TERMINATING)
					{
						// The following two lines of code
						// are done in the shutdown() method
						//setOpStatus(STATUS_SHUTDOWN);
						//notifyAll();
						return;
					}
				}
			}
			
			//
			// Reset for the next iteration if necessary
			//
			if(nextSpecific >= m_specifics.size() && nextRange >= m_ranges.size() &&
			   ! (nextRangeAddr != null && nextRangeAddr.hasMoreElements()))
			{
				nextSpecific = 0;
				nextRange = 0;
				Log.print(Log.INFORMATIONAL, "Finished pass of specific/range address for object: " + toString());

				// wait a little before we start on the next pass?
				try
				{
					Thread.sleep(1000);
				}
				catch (InterruptedException e) {}
			}
			
			IPPollAddress pollAddr = null;
			
			//
			// Loop through the specific first
			//
			while(nextSpecific < m_specifics.size())
			{
				pollAddr = (IPPollAddress) m_specifics.get(nextSpecific++);
				
				//
				// if not known then break out of the loop
				//
				synchronized(m_knownNodes)
				{
					boolean bExist = m_knownNodes.contains(pollAddr.getAddress());
					if(!bExist)
					{
						break;
					}

					pollAddr = null;
				}
				
			}
			
			while(pollAddr == null)
			{
				if(nextRangeAddr != null && nextRangeAddr.hasMoreElements())
				{
					pollAddr = (IPPollAddress) nextRangeAddr.nextElement();
					
					//
					// don't poll known nodes
					//
					synchronized(m_knownNodes)
					{
						boolean bExist = m_knownNodes.contains(pollAddr.getAddress());
						if(bExist)
						{
							pollAddr = null;
						}
					}
				}
				else
				{
					if(nextRange < m_ranges.size())
					{
						IPPollRange pollRange = (IPPollRange)m_ranges.get(nextRange++);
						nextRangeAddr = pollRange.elements();
					}
					else
					{
						break;
					}
				}
			}
			
			//
			// Add the actual address
			//
			if(pollAddr != null)
			{
				try
				{
					// add the next one to the Q
					m_generatedQ.add(pollAddr);
				}
				catch(Exception e) 
				{
					e.printStackTrace();
				}
			}
		}
	}
	
	/**
	 * <P>Initiates the shutdown of the active thread and
	 * waits for the generator to terminate before returnning.
	 * When this method returns the operational status will
	 * be set to STATUS_SHUTDOWN and the objects notifyAll() method
	 * will have been invoked.</P>
	 */
	public void shutdown()
	{
		super.shutdown();

		try
		{
			if(Thread.currentThread().equals(this) == false)
			{
				join();
				synchronized(this)
				{
					setOpStatus(STATUS_SHUTDOWN);
					notifyAll();
				}
			}
		}
		catch(InterruptedException e) 
		{
			// do nothing
		}

	}


	/**
	 * Checking the contents of knownNodes ..
	 */
	private void checkKnownNodeContents(String addr,boolean bCheck)
	{
		Iterator iter = m_knownNodes.iterator();

		Log.print(Log.INFORMATIONAL, "Looking for :" + addr + "\t" + m_knownNodes.contains(addr) + " == " + bCheck);
		Log.print(Log.INFORMATIONAL, "Start already known nodes: ");
		while(iter.hasNext())
		{
			Log.print(Log.INFORMATIONAL, "\t" + iter.next());
		}
		Log.print(Log.INFORMATIONAL, "End already known nodes: ");

	}
}

//
// Copyright (C) 2000 N*Manage Company Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
// $Id: Parameter.java,v 1.1 2000/10/26 19:04:12 jason Exp $
//

package org.opennms.bb.dp.poller.scheduler.utils;

/**
	 * <P>The parameter class is used by the parser
	 * to represent a classic parameter block in the
	 * XML file. For an example of a parameter block
	 * see the packages.dtd file in the CVS module
	 * <EM>xml</EM>.</P>
	 *
	 * <P>This class was create to take the place of a
	 * Vector used to pass the parameters. The vector
	 * with synchronization and generic objects (1) has
	 * more overhead and (2) isn't very specific about
	 * the data.</P>
	 *
	 * @author <A HREF="mailto:weave@opennms.org">Weave</A>
	 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
	 *
	 */
public final class Parameter
{
	/**
	 * <P>The name of the parameter.</P>
	 */
	private String m_name;
		
	/**
	* <P>The value of the parameter.</P>
	*/
	private String m_value;
		
	/**
	* <P>The type for the parameter.</P>
	*/
	private String m_type;
		
	/**
	* <P>Creates a default instance of the parameter
	* class. All values are set to null initialally.</P>
	*/
	public Parameter( )
	{
		m_name = null;
		m_value= null;
		m_type = null;
	}
		
	/**
	* <P>Returns the name of the parameter object.</P>
	*/
	public String getName()
	{
		return m_name;
	}
		
	/** 
	* <P>Sets the name of the parameter object.</P>
	*
	* @param name	The name of the parameter object.
	*/
	public void setName(String name)
	{
		m_name = name;
	}
		
	/**
	* <P>Returns the type for the parmeter object.</P>
	*/
	public String getType()
	{
		return m_type;
	}
		
	/**
	* <P>Sets the type for the parameter object.</P>
	*
	* @param type	The type for the object.
	*/
	public void setType(String type)
	{
		m_type = type;
	}
		
	/**
	* <P>Returns the value of the parameter object.</P>
	*/
	public String getValue()
	{
		return m_value;
	}
		
	/**
	* <P>Sets the value for the parameter object.</P>
	*
	* @param value	The value for the instance.
	*/
	public void setValue(String value)
	{
		m_value = value;
	}
		
	public boolean isValid()
	{
		return (m_value != null && m_type != null && m_name != null);
	}
	
	/**
	*/
	public String toString()
	{
		return m_name + " = " + m_value;
	}
} // end class Parameter

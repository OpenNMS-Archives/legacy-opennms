//
// Copyright (C) 2000 N*Manage Company, Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
package org.opennms.bb.dp.eventd;

import com.sun.media.jsdt.*;

import java.util.*;
import java.sql.*;
import java.io.*;

import org.opennms.bb.common.components.*;
import org.opennms.bb.dp.common.components.*;

import org.opennms.bb.dp.events.*;

/**
 *
 * @author 	<A HREF="mailto:sowmya@opennms.org">Sowmya Kumaraswamy</A>
 * @author	<A HREF="mailto:weave@opennms.org">Brian Weaver</A>
 * @author	<A HREF="http://www.opennms.org">OpenNMS.org</A>
 *
 * @version	$Revision: 1.1 $
 */
public class EventPersistd extends PollerThread
{
	/**
	 * the number of initial threads to create in the thread pool
	 */
	private final static int	INIT_NUM_WRITERS = 5;	

	/**
	 * The queue from which EventReaders are received from
	 */
	private	PCQueue			m_readersQ;
	
	/**
	 * Queue to which this adds EventWriter objects which then run
	 * and add all the data collected to the database
	 */
	private PCQueue			m_eventWriterQ;

	/**
	 * The queue to which EventWriters add events that have been
	 * added to the database - these are then grouped 10 at a time
	 * and sent out
	 */
	private PCQueue			m_eventWriterReplyQ;

	/**
	 * database driver loaded from the properties file
	 */
	private String			m_driver;

	/**
	 * database url loaded from the properties file
	 */
	private String			m_url;

	/**
	 * database user loaded from the properties file
	 */
	private String			m_user;

	/**
	 * database password loaded from the properties file
	 */
	private String			m_passwd;

	/**
	 * the max number of threads to create in the thread pool
	 */
	private int			max_writers = 10;

	/**
	 * The pool of db consumers
	 */
	private ThreadGroup		m_writerGroup;
	
	/**
	 * the pool of threads
	 */
	private List			m_writers;
	
	/**
	 * the jsdt sender
	 */
	private PollerThread		m_jsdtSender;

	/**
	 * The channel on which events are sent out
	 */
	private Channel			m_channel;

	/**
	 * <P>This class is designed to specifically override the add
	 * behaviour of the base class. In order to ensure that the 
	 * event daemon does not get two far behind a check is performed
	 * on each addition so ensure that there are always at least
	 * N/2 threads, where N is the size of the queue.</P>
	 *
	 * <P>The number of threads are bounded by a maximum that may 
	 * be allocated by the enclosing class. For more information
	 * see the thread vs. queue size check routine.</P>
	 *
	 * @author <A HREF="mailto:weave@opennms.org">Brian Weaver</A>
	 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
	 *
	 * @see #threadVsQueueSizeCheck
	 *
	 */
	private class CheckQueue extends PCQueueLinkedList
	{
		/**
		 * <P>Adds the specified object to the tail of the 
		 * producer/consumer queue. If the queue is currently
		 * at it's predefined limit then the call blocks until
		 * there is room in the queue.</P>
		 *
		 * <P>If the queue is closed while the thread is waiting to
		 * add the object then an exception is thrown. Likewise,
		 * if the adding thread is interruped then an exception
		 * is thrown by the add method.</P>
		 *
		 * @param obj	The object to be added to the queue.
		 * @exception java.lang.InterruptedException Thrown if the adding
		 * 		thread is interrrupted prior to completing the
		 *		addition of the object.
		 * @exception org.opennmms.bb.common.components.QueueClosedException Thrown
		 *		if the queue is closed before the object is added to the
		 *		producer/consumer queue.
		 *
		 */
		public synchronized void add(Object obj)
			throws InterruptedException, QueueClosedException
		{
			super.add(obj);
			Log.print(Log.DEBUG, "Writer stats - Q size: " + entries() + "  threads in pool: " + m_writers.size());
			threadsVsQueueSizeCheck(entries());
		}
	}	

	/**
	 * After each read from the listenerQ, the threads in the thread
	 * pool call this method to adjust the number of threads in the pool
	 * if necessary
	 *
	 * If the number of entries in the queue is more than double the
	 * number of threads, the number of threads is increased by one
	 * until the configurable maximum number of threads is reached
	 *
	 * If the number of threads in thepool is more than double the
	 * number of entries in the queue, the number of threads is
	 * decreased by one until the predefined initial number of threads
	 * is reached
	 *
	 */
	synchronized void threadsVsQueueSizeCheck(int entries)
	{
		int curNumThreads = m_writers.size();
		if((curNumThreads < max_writers)  && ((entries / curNumThreads) > 2) )
		{
			// increase by 1!
			DBRunnableConsumerThread writerThread = null;
			try
			{
				writerThread = new DBRunnableConsumerThread(m_writerGroup,
									     "EventWriterConsumer-" + m_writers.size(),
									     m_eventWriterQ, 
									     m_eventWriterReplyQ,
									     m_driver,
									     m_url,
									     m_user,
									     m_passwd);
			}
			catch(ClassNotFoundException cfne)
			{
				Log.print(Log.WARNING, "Error starting new consumer thread");
				Log.print(Log.WARNING, cfne);
				writerThread = null;
			}
			catch(SQLException sqle)
			{
				Log.print(Log.WARNING, "Error starting new consumer thread");
				Log.print(Log.WARNING, sqle);
				writerThread = null;
			}

			//
			// add the collection to the 
			// map for use by the thread
			//
			try
			{
				if(writerThread != null)
				{
					writerThread.start();
					m_writers.add(writerThread);
				}
			}
			catch(RuntimeException re)
			{
				Log.print(Log.WARNING, "Error starting new consumer thread");
				Log.print(Log.WARNING, re);
				
				writerThread.shutdown();
			}
		}
	}

	/**
	 * Creates the poller JSDT client and channel to be used by the
	 * EventWriter threads to send events out once events are added 
	 * to the database
	 *
	 * @exception throws JSDTException if connection is not successful
	 */
	private void connect()
		throws JSDTException
	{
		Session session = Eventd.getSession();

		m_channel = session.createChannel(Eventd.getClient(), 
						  PollerJSDTConstants.EVENTS_SINK_CHANNEL,
						  true,
						  false,
						  true);
	}


	/**
	 * Constructs the EventPeristd thread of the Eventd
	 *
	 * @param readersQ	the queue from which the events to be written 
	 *	into the database are read
	 *
	 * @exception java.lang.NullPointerException Thrown if the database related 
	 *	properties are not found
	 * @exception com.sun.media.jsdt.JSDTException Thrown if the the JSDT 
	 *	communication channel cannot be established
	 */
	public EventPersistd(PCQueue readersQ) 
		throws JSDTException, SQLException
	{
		super();

		max_writers = 30;
		String threadNum = Eventd.getProperty(EventdConstants.PROP_MAX_EVENT_WRITER_THREADS);
		if(threadNum != null)
		{
			try
			{
				max_writers = Integer.parseInt(threadNum);
			}
			catch(NumberFormatException ne)
			{
				max_writers = 30;
			}
		}

		m_readersQ = readersQ;
		m_driver = Eventd.getProperty(EventdConstants.PROP_DB_DRIVER);
		if (m_driver == null)
		{
			throw new NullPointerException("Missing resource: " + EventdConstants.PROP_DB_DRIVER);
		}

		m_url = Eventd.getProperty(EventdConstants.PROP_DB_URL);
		if (m_url == null)
		{
			throw new NullPointerException("Missing resource: " + EventdConstants.PROP_DB_URL);
		}

		m_user = Eventd.getProperty(EventdConstants.PROP_DB_USER);
		if (m_user == null)
		{
			throw new NullPointerException("Missing resource: " + EventdConstants.PROP_DB_USER);
		}

		m_passwd = Eventd.getProperty(EventdConstants.PROP_DB_PASSWD);
		if (m_passwd == null)
		{
			throw new NullPointerException("Missing resource: " + EventdConstants.PROP_DB_PASSWD);
		}

		/* database sequence and insert statement
		 * read here so exception can be thrown at startup
		 * as against in EventsWriter which would be more of 
		 * runtime.. 
		 */
		if(Eventd.getProperty(EventdConstants.PROP_DB_GET_NEXTEVENTID) ==null)
		{
			throw new NullPointerException("Missing resource: " + EventdConstants.PROP_DB_GET_NEXTEVENTID);
		}

		if(Eventd.getProperty(EventdConstants.PROP_DB_INS_EVENT) == null)
		{
			throw new NullPointerException("Missing resource: " + EventdConstants.PROP_DB_INS_EVENT);
		}

		//
		// Q
		//
		m_eventWriterQ      = new CheckQueue();
		m_eventWriterReplyQ = new PCQueueLinkedList();

		/* 
		 * Create the thread pool 
		 */
		m_writerGroup = new ThreadGroup("EventWriterConsumerPool");
		m_writers = Collections.synchronizedList(new ArrayList(max_writers));
		for (int iIndex=0; iIndex<INIT_NUM_WRITERS; iIndex++)
		{
			DBRunnableConsumerThread writerThread = null;
			try
			{
				writerThread = new DBRunnableConsumerThread(m_writerGroup,
									     "EventWriterConsumer-" + iIndex,
									     m_eventWriterQ, 
									     m_eventWriterReplyQ, 
									     m_driver, 
									     m_url, 
									     m_user, 
									     m_passwd);
			}
			catch(ClassNotFoundException cfne)
			{
				Log.print(Log.WARNING, "Error starting db runnable consumer");
				Log.print(Log.WARNING, cfne);
			}
			catch(SQLException sqle)
			{
				Log.print(Log.WARNING, "Error starting db runnable consumer");
				Log.print(Log.WARNING, sqle);
			}
			if(writerThread != null)
				m_writers.add(writerThread);
		}
		connect();
		
		m_jsdtSender = new RunnableConsumerThread(m_writerGroup,
							  "EventWriterSendingConsumer",
							  m_eventWriterReplyQ);
	}
	
	/**
	 * Starts the thread pool. Checks for status changes. 
	 * If status is normal, reads EventBlock objects off of the m_readersQ, 
	 * constructs EventWriter objects and adds them to the
	 * m_eventWriterQ which is the input Q to the DBRunnableConsumerThreads
	 *
	 * Also reads the 'persisted' events from the m_eventWriterReplyQ
	 * and sends them out NUM_EVENTS_PER_SEND at a time
	 */
	public void run()
	{
		setOpStatus(STATUS_NORMAL);

		// Loop through and start thread pool
		Iterator threadsiter = m_writers.iterator();
		while(threadsiter.hasNext())
		{
			DBRunnableConsumerThread temp = (DBRunnableConsumerThread)threadsiter.next();
			temp.start();
		}
		m_jsdtSender.start();

		for(;;)
		{
			synchronized(this)
			{
				for(;;)
				{
					int status = getOpStatus();
					if((status & STATUS_TERMINATING) == STATUS_TERMINATING)
					{
						try
						{
							// shutdown all the writer threads 
							Iterator iter = m_writers.iterator();
							while(iter.hasNext())
							{
								shutdownThread((PollerThread)iter.next());
							}
							shutdownThread(m_jsdtSender);

							// close the writer Q
							m_eventWriterQ.close();
							m_eventWriterReplyQ.close();

							// close JSDT m_session
							m_channel.destroy(Eventd.getClient());
						}
						catch(Exception e)
						{
							// do nothing							
						}
						
						
						setOpStatus(STATUS_SHUTDOWN);
						return;
					}
					else if((status & STATUS_PAUSING) == STATUS_PAUSING)
					{
						
						boolean setPaused = true;
						try
						{
							// pause all the writer threads
							Iterator iter = m_writers.iterator();
							while(iter.hasNext())
							{
								pauseThread((PollerThread)iter.next());
							}
							pauseThread(m_jsdtSender);
						}
						catch(IllegalThreadStateException e)
						{
							setPaused = false;
							setOpStatus(STATUS_TERMINATING);
						}

						catch(InterruptedException iE)
						{
							setPaused = false;
							setOpStatus(STATUS_TERMINATING);
						}

						if(setPaused)
							setOpStatus(STATUS_PAUSED);

					}
					else if((status & STATUS_RESUMING) == STATUS_RESUMING)
					{
						boolean setNormal = true;
						try
						{
							// resume all the writer threads
							Iterator iter = m_writers.iterator();
							while(iter.hasNext())
							{
								resumeThread((PollerThread)iter.next());
							}
							resumeThread(m_jsdtSender);
						}
						catch(IllegalThreadStateException e)
						{
							setNormal = false;
							setOpStatus(STATUS_TERMINATING);
						}
						catch(InterruptedException iE)
						{
							setNormal = false;
							setOpStatus(STATUS_TERMINATING);
						}

						
						if(setNormal)
							setOpStatus(STATUS_NORMAL);

					}
					else if((status & STATUS_PAUSED) == STATUS_PAUSED)
					{
						try
						{
							wait();
						}
						catch(InterruptedException e)
						{
							setOpStatus(STATUS_TERMINATING);
						}
					}
					else if((status & STATUS_NORMAL) == STATUS_NORMAL)
					{
						// if the m_readersQ is empty, register with the queue for
						// notification on add and wait for  signal from queue
						// or signal due to status change
						boolean waitForQueue = false;
						synchronized(m_readersQ)
						{
							if(m_readersQ.isEmpty())
							{
								m_readersQ.oneShotNotifyAllOnAdd(this);
								waitForQueue = true;
							}
						}
						
						if(!waitForQueue)
							break;

	                			try
        	        			{
       							wait(); // queue or status change can signal
                				}
                				catch(InterruptedException ie)
						{
							setOpStatus(STATUS_TERMINATING);
	                			}
					}
				} // end for(;;) status check
			} // end synchronization 
            

	    		EventsReader rdr = null;
	    		synchronized(m_readersQ)
			{
				try
				{
					if(!m_readersQ.isEmpty())
						rdr = (EventsReader)m_readersQ.read();
				}
				catch(InterruptedException ie)
				{
					rdr = null;
					setOpStatus(STATUS_TERMINATING);
				}
				catch(QueueClosedException qce)
				{
					rdr = null;
					setOpStatus(STATUS_TERMINATING);
				}
			}
			
			if(rdr != null)
			{
				try
				{
					EventHeader hdr = rdr.getHeader();
					Iterator i = rdr.getEvents().iterator();
					while(i.hasNext())
					{
						m_eventWriterQ.add(new EventWriter(hdr, 
										   (Event)i.next(), 
										   Eventd.getClient(), 
										   m_channel));
					}
				}
				catch(InterruptedException ie)
				{
					setOpStatus(STATUS_TERMINATING);
				}
				catch(QueueClosedException qce)
				{
					setOpStatus(STATUS_TERMINATING);
				}
	
			}
		}
	}
	
	/**
	 * Start the shutdown and notify run() to shutdown
	 */
	public void shutdown()
	{
		try
		{
			super.shutdown();
			if(Thread.currentThread().equals(this) == false)
				join();
		}
		catch(Exception e) 
		{ 
			// do nothing
		}
	}
}

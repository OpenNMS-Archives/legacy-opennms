//
// Copyright (C) 2000 N*Manage Company Inc.
// Copyright (C) 2000 PlatformWorks, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
// Tab Size = 8
//
// $Id: PollerThread.java,v 1.10 2000/10/05 19:35:15 weave Exp $
//

package org.opennms.bb.dp.common.components;

import java.lang.*;

/**
 * <P>All the poller threads have to respond to start/stop and pause/resume
 * commands and report their current status when queried. The PollerThread
 * base class provides the default states and operations for transition
 * between states. This allows derived classes to focus on extending the 
 * object to provide specific funtionality while maintaining consistant
 * behavior in all derived objects.</P>
 *
 * <P>It is important to note that the PollerThread class provides a 
 * highlevel design for how derived classes should behave. It is up to
 * each designer of a derived class to ensure that a derived class
 * functions properly within the semantics provided by the PollerThread
 * class.</P>
 *
 * <PRE>
 * Only the following state transitions are possible:
 *
 * STATUS_STARTING ---> STATUS_NORMAL
 *
 * STATUS_NORMAL   ---> STATUS_PAUSING
 * STATUS_NORMAL   ---> STATUS_TERMINATING
 *
 * STATUS_PAUSING  ---> STATUS_PAUSED
 * STATUS_PAUSING  ---> STATUS_RESUMING
 * STATUS_PAUSING  ---> STATUS_TERMINATING
 *
 * STATUS_PAUSED   ---> STATUS_RESUMING
 * STATUS_PAUSED   ---> STATUS_TERMINATING
 *
 * STATUS_RESUMING ---> STATUS_NORMAL
 * STATUS_RESUMIMG ---> STATUS_PAUSING
 * STATUS_RESUMING ---> STATUS_TERMINATING
 *
 * STATUS_TERMINATING ---> STATUS_SHUTDOWN
 * </PRE>
 *
 *
 * @author 	<A HREF="mailto:sowyma@opennms.org">Sowmya</A>
 * @author	<A HREF="mailto:weave@opennms.org">Brian Weaver</A>
 * @author	<A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version	$Revision: 1.10 $
 */
public abstract class PollerThread extends Thread
{
	/**
	 * <P>The current operation status of the thread.
	 * This status is updated by the derived class 
	 * through a call to setOpStatus(). The actual
	 * value can be retreived via getOpStatus().</P>
	 */
	private int m_curOpStatus;

	/**
	 * <P>This is the initial status of the thread object.
	 * Indicates that the thread has be created, but that
	 * the start method has not yet been called. The 
	 * status of the thread is only correct if derived classes
	 * actually set the status correctly.</P>
	 */
	public static final int		STATUS_STARTING 	= 1 << 0;
	
	/**
	 * <P>Indicates that the thread has been started and is
	 * running normally.</P>
	 */
	public static final int		STATUS_NORMAL		= 1 << 1;
	
	/**
	 * <P>Indicates that the thread has been marked to
	 * be paused. The thread may not yet have actually
	 * reached a paused state.</P>
	 */
	public static final int 	STATUS_PAUSING 		= 1 << 2;
	
	/**
	 * <P>Indicates that the thread has paused any processing
	 * and is waiting to resume or exit.</P>
	 */
	public static final int		STATUS_PAUSED 		= 1 << 3;
	
	/**
	 * <P>Indicates that the thread has be marked for
	 * resumption. The thread may be in the process of
	 * restarting paused work.</P>
	 */
	public static final int		STATUS_RESUMING 	= 1 << 4;
	
	/**
	 * <P>The thread has been targeted for termination.
	 * The thread should exit as soon as it has performed
	 * any required cleanup.</P>
	 */
	public static final int		STATUS_TERMINATING 	= 1 << 5;
	
	/**
	 * <P>The last act of an exiting thread should be to
	 * set the status to shutdown. This is the final state
	 * of the actual object after the thread has exited.</P>
	 */
	public static final int		STATUS_SHUTDOWN 	= 1 << 6;
	
	/**
	 * <P>The following mask is used to get/set the status
	 * of the poller thread. When a status change occurs the
	 * lower 8-bits of the status word are the only parts
	 * of the status to be changed. It is up to the derived
	 * class to change the upper 24 bits of status information.</P>
	 */
	public static final int		STATUS_MASK = 0xff;

	/**
	 * <P>Create a default poller thread with the
	 * operational status equal to STATUS_STARTING.</P>
	 *
	 * @see java.lang.Thread#Thread
	 */
	protected PollerThread()
	{
		super();
		m_curOpStatus = STATUS_STARTING;
	}

	/**
	 * <P>Creates a new PollerThread. The name
	 * of the thread is equal to <EM>name</EM>.</P>
	 *
	 * @param name	The name of the new thread.
	 * 
	 * @see java.lang.Thread#Thread(java.lang.String)
	 */
	protected PollerThread(String name)
	{
		super(name);
		m_curOpStatus = STATUS_STARTING;
	}
	
	/**
	 * <P>Allocates a new PollerThread that is a member of
	 * the specified ThreadGroup. The initial status of the
	 * thread is STATUS_STARTING.</P>
	 *
	 * @param group		The owning ThreadGroup.
	 * @param name		The name of the new thread.
	 *
	 * @see java.lang.Thread#Thread(java.lang.ThreadGroup, java.lang.String)
	 * @see java.lang.ThreadGroup
	 */
	protected PollerThread(ThreadGroup group, String name)
	{
		super(group, name);
		m_curOpStatus = STATUS_STARTING;
	}

	/**
	 * <P>Sets the lower bits of the status word to 
	 * define the status of the derived class.</P>
	 *
	 * @param status	The status for the lower bits.
	 */
	protected synchronized void setCtrlStatus(int status)
	{
		m_curOpStatus = (m_curOpStatus & ~STATUS_MASK) | (status & STATUS_MASK);
	}
	
	/**
	 * <P>Sets the upper bits of the status word to 
	 * define the status of the derived class.</P>
	 *
	 * @param status	The status for the upper bits.
	 */
	protected synchronized void setUserStatus(int status)
	{
		m_curOpStatus = (status & ~STATUS_MASK) | (m_curOpStatus & STATUS_MASK);
	}
	
	/**
	 * <P>Returns the current control status for the poller thread.</P>
	 *
	 * @return The current status of the poller thread.
	 */
	protected synchronized int getCtrlStatus( )
	{
		return (m_curOpStatus & STATUS_MASK);
	}
	
	/**
	 * <P>Use by derived classes to set the current
	 * operational status of the extend PollerThread.</P>
	 *
	 * @param status	The new status of the thread.
	 *
	 * @see #STATUS_STARTING
	 * @see #STATUS_NORMAL
	 * @see #STATUS_PAUSING
	 * @see #STATUS_PAUSED
	 * @see #STATUS_RESUMING
	 * @see #STATUS_TERMINATING
	 * @see #STATUS_SHUTDOWN
	 */
	protected synchronized void setOpStatus(int status)
	{
		m_curOpStatus = status;
		notifyAll();
	}
	
	/**
	 * <P>Returns the current operational status of 
	 * the PollerThread as defined by the derived class.</P>
	 *
	 * @return The current operation status of the thread.
	 *
	 * @see #STATUS_STARTING
	 * @see #STATUS_NORMAL
	 * @see #STATUS_PAUSING
	 * @see #STATUS_PAUSED
	 * @see #STATUS_RESUMING
	 * @see #STATUS_TERMINATING
	 * @see #STATUS_SHUTDOWN
	 */
	public synchronized int getOpStatus()
	{
		return m_curOpStatus;
	}
	
	/**
	 * <P>Sets the current operational status of the
	 * thread to STATUS_TERMINATING. Once the status
	 * is set the Thread's <EM>notifyAll()</EM> method
	 * is invoked to inform all waiters.</P>
	 *
	 * @see #STATUS_TERMINATING
	 * @see java.lang.Object#notifyAll
	 */
	public synchronized void shutdown()
	{
		if((m_curOpStatus & STATUS_TERMINATING) == 0 && (m_curOpStatus & STATUS_SHUTDOWN) == 0)
		{
			setCtrlStatus(STATUS_TERMINATING);
			notifyAll();
		}
	}

	/**
	 * <P>Sets the current operational status of the
	 * thread to STATUS_PAUSING. The status of the thread
	 * must be either STATUS_NORMAL or STATUS_RESUMING for the
	 * status change to occur. If the status change 
	 * occurs then the thread's <EM>notifyAll()</EM>
	 * is called after changing the status.</P>
	 *
	 * <P>It is the derived class' responsibility to
	 * actually transition the object from an STATUS_PAUSING
	 * to an actual STATUS_PAUSED status when the object 
	 * reflects the appropiate status.</P>
	 *
	 * @see java.lang.Object#notifyAll
	 * @see #STATUS_NORMAL
	 * @see #STATUS_RESUMING
	 * @see #STATUS_PAUSING
	 */
	public synchronized void pauseOperation()
	{
		if((m_curOpStatus & STATUS_NORMAL) == 0 && (m_curOpStatus & STATUS_RESUMING) == 0)
		{
			setCtrlStatus(STATUS_PAUSING);
			notifyAll();
		}
	}

	/**
	 * <P>Sets the current operation status of the 
	 * thread to STATUS_RESUMING. It is up to the derived
	 * thread to update the status from STATUS_RESUMING to
	 * STATUS_NORMAL after restaring operations. The status
	 * will only be change if the current status is one
	 * of STATUS_PAUSED or STATUS_PAUSING. Any other status will
	 * cause the status change to fail.</P>
	 * 
	 * <P>If the status is changed then the method
	 * <EM>notifyAll()</EM> to signal the status change.</P>
	 *
	 * @see java.lang.Object#notifyAll
	 * @see #STATUS_PAUSED
	 * @see #STATUS_PAUSING
	 * @see #STATUS_RESUMING
	 *
	 */
	public synchronized void resumeOperation()
	{
		if((m_curOpStatus & STATUS_PAUSED) == 0 && (m_curOpStatus & STATUS_PAUSING) == 0)
		{
			setCtrlStatus(STATUS_RESUMING);
			notifyAll();
		}
	}

	/**
	 * <P>The pauseThread operation thread calls
	 * the pauseOperation() method on the thread
	 * and then waits for it to reach a paused
	 * status. If the thread is in an illegal
	 * state (terminated || shutdown) then an
	 * exception will be thrown.</P>
	 *
	 * @param thr	The thread to pause.
	 *
	 * @exception java.lang.InterruptedException	Thrown if the calling thread
	 * 	is interrupted by another caller.
	 * @exception java.lang.IllegalThreadStateException Thrown if the thread
	 *	to be stopped is in an illegal state.
	 * 
	 */
	public static void pauseThread(PollerThread thr)
		throws InterruptedException
	{
		synchronized(thr)
		{
			for(;;)
			{
				int status = thr.getOpStatus();
				if((status & (STATUS_TERMINATING | STATUS_SHUTDOWN)) != 0)
					throw new IllegalThreadStateException("The thread is dead!");
			
				if((status & STATUS_PAUSED) == STATUS_PAUSED)
				{
					break;
				}
				else
				{
					thr.pauseOperation();
					thr.wait();
				}
			}
		}
	}
			
	/**
	 * <P>The resumeThread operation thread calls
	 * the resumeOperation() method on the thread
	 * and then waits for it to reach a normal
	 * status. If the thread is in an illegal
	 * state (terminated || shutdown) then an
	 * exception will be thrown.</P>
	 *
	 * @param thr	The thread to resume.
	 *
	 * @exception java.lang.InterruptedException	Thrown if the calling thread
	 * 	is interrupted by another caller.
	 * @exception java.lang.IllegalThreadStateException Thrown if the thread
	 *	to be stopped is in an illegal state.
	 * 
	 */
	public static void resumeThread(PollerThread thr)
		throws InterruptedException
	{
		synchronized(thr)
		{
			for(;;)
			{
				int status = thr.getOpStatus();
				if((status & (STATUS_TERMINATING | STATUS_SHUTDOWN)) != 0)
					throw new IllegalThreadStateException("The thread is dead!");
			
				if((status & STATUS_NORMAL) == STATUS_NORMAL)
				{
					break;
				}
				else
				{
					thr.resumeOperation();
					thr.wait();
				}
			}
		}
	}
				
	/**
	 * <P>The shutdownThread operation thread calls
	 * the shutdown() method on the thread
	 * and then waits for it to reach a shutdown
	 * status.</P>
	 *
	 * @param thr	The thread to shutdown.
	 *
	 * @exception java.lang.InterruptedException	Thrown if the calling thread
	 * 	is interrupted by another caller.
	 * 
	 */
	public static void shutdownThread(PollerThread thr)
		throws InterruptedException
	{
		synchronized(thr)
		{
			for(;;)
			{
				int status = thr.getOpStatus();
				if((status & STATUS_SHUTDOWN) == STATUS_SHUTDOWN)
				{
					break;
				}
				
				if((status & STATUS_TERMINATING) == STATUS_TERMINATING)
				{
					thr.wait();
				}
				else
				{
					thr.shutdown();
					thr.wait();
				}
			}
		}
		if(currentThread().equals(thr) == false)
			thr.join();
	}				

}

//
// Copyright (C) 2000 N*Manage Company Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
// $Id: ServiceMonitor.java,v 1.5 2000/11/09 15:44:02 mike Exp $
//
package org.opennms.bb.dp.poller.plugins;

import java.lang.*;
import java.util.Properties;
import org.opennms.bb.dp.poller.plugins.*;

/**
 * <P>This is the interfact that is implemented by a poller framework
 * plug-in that performs service monitoring. Each plug-in is uniquely 
 * identified by its <EM>service name</EM>. In order for the framework
 * to appropriate use a plug-in the service name must be the exact same
 * as the service names in the service package and the Service table in
 * the distribute poller database.</P>
 *
 * <P>When a service monitor plug-in is loaded and initialized, the framework
 * will initialize the monitor by calling the <EM>initialize()</EM> method.
 * Likewise, when the monitor is unloaded the framework calls the <EM>release()</EM>
 * method is called. If the plug-in needs to save or read any configuration
 * information after the initialize() call, a reference to the proxy object should
 * be saved at initialization.</P>
 *
 * <P><STRONG>NOTE:</STRONG> The plug-in <EM>poll()</EM> must be thread safe in
 * order to operate. Any synchronized methods or data accessed in the <EM>poll()</EM>
 * can negatively affect the framework if multiple poller threads are blocked on
 * a critical resource. Synchronization issues should be seriously evaluated to ensure
 * that the plug-in scales well to large deployments.</P>
 *
 * @author <A HREF="mailto:weave@opennms.org">Brian Weaver</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version CVS $Revision: 1.5 $
 *
 */
public interface ServiceMonitor
{
	/**
	 * <P>The constant that defines a service as being in a normal
	 * state. If this is returned by the poll() method then the 
	 * framework will re-schedule the service for its next poll using
	 * the standard uptime interval</P>
	 */
	public static final int		SERVICE_AVAILABLE	= 1;
	
	/**
	 * <P>The constant that defines a service that is not working
	 * normally and should be scheduled using the downtime models.
	 */
	public static final int		SERVICE_UNAVAILABLE	= 2;
	
	/**
	 * <P>The status mask is used to mask off the bits that apply to 
	 * scheduling information only. The other bits of the status
	 * return information are used to encode special processing 
	 * instructions to the poller framework.</P>
	 */
	public static final int		SERVICE_STATUS_MASK	= 0xff;
	
	/**
	 * <P>This constants defines the mask that can be bitwise
	 * anded with the status return from the poll() method to 
	 * determine if a status event should be surpressed. By default
	 * the framework will generate an event when the status
	 * transitions from up to down or vice versa. If the mask
	 * bit is set then the framework should not generate a 
	 * transitional event.</P>
	 */
	public static final int		SURPRESS_EVENT_MASK	= 0x100;
	
	/**
	 * <P>Returns the name of the service that the plug-in monitors.
	 * A plug-in can only support a single service and the returned 
	 * name must match both the name of the service in the package
	 * definition and an entry in the distributed poller services
	 * table.</P>
	 *
	 * @return The service that the plug-in monitors.
	 */
	public String serviceName();
	
	/**
	 * <P>This method is called after the framework creates an
	 * instance of the plug-in. The framework passes the object a proxy
	 * object that can be used to retreive configuration information 
	 * specific to the plug-in. Additionally, any parameters for the 
	 * plug-in from the package definition are passed using the 
	 * parameters element.</P>
	 *
	 * <P>If there is a critical error, like missing service libraries, the
	 * the montior may throw a ServiceMonitorException. If the plug-in 
	 * throws an exception then the plug-in will be disabled in the
	 * framework.</P>
	 *
	 * @param proxy		The object that can be used to load/save config information.
	 * @param parameters	Not currently used
	 *
	 * @exception org.opennms.bb.dp.poller.plugins.ServiceMonitorException	Thrown if
	 * 	an unrecoverable error occurs that prevents the plug-in from functioning.
	 *
	 */
	public void initialize(ConfigurationProxy proxy, Properties parameters) 
		throws ServiceMonitorException;
		
	/**
	 * <P>This method is called whenever the plug-in is being unloaded, normally
	 * during framework exit. During this time the framework may release any 
	 * resource and save any state information using the proxy object from the
	 * initialization routine.</P>
	 *
	 * <P>Even if the plug-in throws a monitor exception, it will not prevent
	 * the plug-in from being unloaded. The plug-in should not return until all
	 * of its state information is saved. Once the plug-in returns from this 
	 * call its configuration proxy object is considered invalid.</P>
	 *
	 * @exception org.opennms.bb.dp.poller.plugins.ServiceMonitorException	Thrown if
	 * 	an error occurs during deallocation.
	 *
	 */
	public void release() 
		throws ServiceMonitorException;
	
	/**
	 * <P>This method is called whenever a new interface that supports the 
	 * plug-in service is added to the scheduling system. The plug-in has the
	 * option to load and/or associate configuration information with the
	 * interface before the framework begins scheduling the new device.</P>
	 *
	 * <P>Should a monitor exception be thrown during an initialization call
	 * then the framework will log an error and discard the interface from 
	 * scheduling.</P>
	 *
	 * @param iface		The network interface to be added to the scheduler.
	 *
	 * @exception org.opennms.bb.dp.poller.plugins.ServiceMonitorException	Thrown if
	 * 	an unrecoverable error occurs that prevents the interface from being monitored.
	 *
	 */
	public void initialize(NetworkInterface iface) 
		throws ServiceMonitorException;
	
	/**
	 * <P>This method is the called whenever an interface is being removed from 
	 * the scheduler. For example, if a service is determined as being no longer
	 * supported then this method will be invoked to cleanup any information 
	 * associated with this device. This gives the implementor of the interface
	 * the ability to serialize any data prior to the interface being discarded.</P>
	 *
	 * <P>If an exception is thrown during the release the exception will be
	 * logged, but the interface will still be discarded for garbage collection.</P>
	 *
	 * @param iface		The network interface that was being monitored.
	 *
	 * @exception org.opennms.bb.dp.poller.plugins.ServiceMonitorException	Thrown if
	 * 	an unrecoverable error occurs for the interface.
	 */
	public void release(NetworkInterface iface) 
		throws ServiceMonitorException;
	
	/**
	 * <P>This method is the heart of the plug-in monitor. Each time an interface
	 * requires a check to be performed as defined by the scheduler the poll method
	 * is invoked. The poll is passed the interface to check and a reference to an
	 * EventProxy object. The proxy object can be used to send special events as 
	 * defined by the monitor. This allows special events aside from the standard
	 * available/unavailable performed by the scheduler.</P>
	 *
	 * <P>By default when the status transition from up to down or vice versa the 
	 * framework will generate an event. Additionally, if the polling interval 
	 * changes due to an extended unavailbility, the framework will generate an
	 * additional down event. The plug-in can surpress the generation of the default
	 * events by setting the surpress event bit in the returned integer.</P>
	 *
	 * @param iface		The network interface to test the service on.
	 * @param eproxy 	The event proxy object for sending custom events.
	 * @param parameters	The package parameters (timeout, retry, etc...) to be 
	 *  used for this poll.
	 *
	 * @return The availibility of the interface and if a transition event
	 * 	should be surpressed.
	 *
	 * @see #SURPRESS_EVENT_MASK
	 * @see #STATUS_AVAILABLE
	 * @see #STATUS_UNAVAILABLE
	 */
	public int poll(NetworkInterface iface, EventProxy eproxy, Properties parameters) 
		throws ServiceMonitorException;
}


//
// Copyright (C) 2000 N*Manage Company, Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
// $Id: Time.java,v 1.1 2000/11/15 18:50:34 sowmya Exp $
//
package org.opennms.bb.dp.eventd.db;

import java.sql.*;
import java.util.*;

/**
 * <P>This class is designed to format time information
 * into the representation chosen for the events database
 * records. This format is defined as <EM>DD-MMM-YYYY HH:MM:SS</EM>,
 * where MMM is the first three lower case character letters of the month.</P>
 *
 * @author <A HREF="mailto:weave@opennms.org">Brian Weaver</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version $Revision: 1.1 $
 *
 */
public final class Time
{
	/**
	 * The month values to name mapping!
	 */
	private static pair[] dateMap;
	
	/**
	 * <P>This class is designed to pair an integer value
	 * with a string name. This is used as a simple way
	 * to track the Calendar.XXX month names with the 
	 * actual three letter representations that are being
	 * used in the database.</P>
	 *
	 * @author <A HREF="mailto:weave@opennms.org">Brian Weaver</A>
	 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
	 *
	 * @version $Revision: 1.1 $
	 *
	 */
	private static class pair
	{
		public int	key;
		public String 	val;
	
		pair(int k, String v)
		{
			key = k;
			val = v;
		}
	}
	
	/**
	 * Load in the static date mappings
	 */
	static
	{
		dateMap = new pair[12];
		int ndx = 0;
		
		dateMap[ndx++] = new pair(Calendar.JANUARY, 	"jan");
		dateMap[ndx++] = new pair(Calendar.FEBRUARY, 	"feb");
		dateMap[ndx++] = new pair(Calendar.MARCH, 	"mar");
		dateMap[ndx++] = new pair(Calendar.APRIL, 	"apr");
		dateMap[ndx++] = new pair(Calendar.MAY, 	"may");
		dateMap[ndx++] = new pair(Calendar.JUNE, 	"jun");
		dateMap[ndx++] = new pair(Calendar.JULY, 	"jul");
		dateMap[ndx++] = new pair(Calendar.AUGUST, 	"aug");
		dateMap[ndx++] = new pair(Calendar.SEPTEMBER, 	"sep");
		dateMap[ndx++] = new pair(Calendar.OCTOBER,	"oct");
		dateMap[ndx++] = new pair(Calendar.NOVEMBER, 	"nov");
		dateMap[ndx++] = new pair(Calendar.DECEMBER, 	"dec");
	}
	
	/**
	 * Converts the passed integer to a string. If the interger
	 * value is less than 10, a zero is prefixed to the string.
	 *
	 * @param val	The value to be converted
	 *
	 * @return The converted number to string.
	 */
	private static String width2(int val)
	{
		return (val < 10 ? "0" : "") + Integer.toString(val);
	}
	
	/**
	 * Converts the numerical value for the month to
	 * an actual string value, based upon the statically
	 * loaded mappings.
	 *
	 * @param val	The value of the month
	 *
	 * @return The converted month as a string.
	 */
	private static String month(int val)
	{
		for(int i = 0; i < dateMap.length; i++)
			if(dateMap[i].key == val)
				return dateMap[i].val;
		
		return "xxx";
	}
	
	/**
	 * Format the time value in the <EM>DD-MMM-YYYY HH:MM:SS</EM> format.
	 *
	 * @param c	The calendar representing the time.
	 *
	 * @return The database formatted string.
	 */
	public static String format(Calendar c)
	{
		String s = null;
		if(c != null)
		{
			//
			// do the work
			s =  	width2(c.get(Calendar.DAY_OF_MONTH)) + "-"
				+ month(c.get(Calendar.MONTH)) + "-"
				+ Integer.toString(c.get(Calendar.YEAR)) + " "
				+ width2(c.get(Calendar.HOUR_OF_DAY)) + ":"
				+ width2(c.get(Calendar.MINUTE)) + ":"
				+ width2(c.get(Calendar.SECOND));
		}
		return s;
	}
}
		
		

//
// Copyright (C) 2000 N*Manage Company, Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
// $Id: IpAddrTable.java,v 1.10 2000/10/28 20:11:08 weave Exp $
//
//
package org.opennms.bb.dp.capsd.snmp;

import java.util.*;

import org.opennms.protocols.snmp.*;
import org.opennms.bb.common.components.*;

/**
 * <P>IpAddrTable uses a SnmpSession to collect the ipAddrTable entries
 * It implements the SnmpHandler to receive notifications when a reply is 
 * received/error occurs in the SnmpSession used to send requests /recieve 
 * replies.</P>
 *
 * @author <A HREF="mailto:sowmya@opennms.org">Sowmya</A>
 * @author <A HREF="mailto:weave@opennms.org">Weave</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version $Revision: 1.10 $
 *
 * @see <A HREF="http://www.ietf.org/rfc/rfc1213.txt">RFC1213</A>
 */
public class IpAddrTable
	implements SnmpHandler
{
	/**
	 * <P>The list of collected IpAddrTableEntries built from
	 * the infomation collected from the remote agent.</P>
	 */
	private List		m_entries;
	
	/**
	 * <P>Flag indicating if query was successful.</P>
	 */
	private boolean		m_error;

	/**
	 * <P>Used to synchronize the class to ensure that the
	 * session has finished collecting data before the
	 * value of success or failure is set, and control
	 * is returned to the caller.</P>
	 */
	private Signaler	m_signal;

	/**
	 * <P>The default constructor is marked as private and will
	 * always throw an exception. This is done to disallow the
	 * constructor to be called. Since any instance of this class
	 * must have an SnmpSession and Signaler to properly work, the
	 * correct constructor must be used.</P>
	 *
	 * @exception java.lang.UnsupportedOperationException Always thrown from
	 *	this method since it is not supported.
	 *
	 * @see #IpAddrTable(SnmpSession, Signaler)
	 *
	 */
	private IpAddrTable( ) throws UnsupportedOperationException
	{
		throw new UnsupportedOperationException("Default constructor not supported!");
	}
	
	/**
	 * <P>Constructs an IpAddrTable object that is used to collect
	 * the address elements from the remote agent. Once all
	 * the elements are collected, or there is an error in
	 * the collection the signaler object is <EM>notified</EM>
	 * to inform other threads.</P>
	 *
	 * @param session	The session with the remote agent.
	 * @param signaler	The object to notify waiters.
	 *
	 * @see IpAddrTableEntry
	 */
	public IpAddrTable(SnmpSession session, Signaler signaler)
	{
		m_signal  = signaler;
		m_entries = new ArrayList();
		m_error   = false;
		
		SnmpPduRequest pdu = IpAddrTableEntry.getNextPdu();
		session.send(pdu, this);
	}
	
	/**
	 * <P>Returns the success or failure code for collection
	 * of the data.</P>
	 */
	public boolean failed()
	{
		return m_error;
	}
	
	/**
	 * <P>Returns the list of entry maps
	 * that can be used to access all the
	 * information about the interface table.</P>
	 *
	 * @return The list of ifTableEntry maps.
	 */
	public List getEntries()
	{
		return m_entries;
	}
		
	/**
	 * <P>This method is used to process received SNMP PDU packets from
	 * the remote agent. The method is part of the SnmpHandler interface
	 * and will be invoked when a PDU is successfully decoded. The method
	 * is passed the receiving session, the PDU command, and the actual
	 * PDU packet.</P>
	 *
	 * <P>When all the data has been received from the session the signaler
	 * object, initialized in the constructor, is signaled. In addition,
	 * the receiving instance will call notifyAll() on itself at the same
	 * time.</P>
	 *
	 * @param session	The SNMP Session that received the PDU
	 * @param command	The command contained in the received pdu
	 * @param pdu		The actual received PDU.
	 *
	 */
	public void snmpReceivedPdu(SnmpSession session, int command, SnmpPduPacket pdu)
	{
		boolean doNotify = true;
		if(command == SnmpPduPacket.RESPONSE)
		{
			//
			// The last variable in the list of elements
			// is always the first to run off the table, so 
			// we only need to check that one.
			//
			if(IpAddrTableEntry.ROOT.isRootOf(pdu.getVarBindAt(pdu.getLength()-1).getName()))
			{
				SnmpVarBind [] vblist = pdu.toVarBindArray();
				IpAddrTableEntry ent = new IpAddrTableEntry(vblist);
				m_entries.add(ent);
				
				//
				// next pdu
				//
				SnmpPduRequest nxt = new SnmpPduRequest(SnmpPduPacket.GETNEXT);
				for(int x = 0; x < vblist.length; x++)
				{
					nxt.addVarBind(new SnmpVarBind(vblist[x].getName()));
				}
			
				session.send(nxt, this);
				doNotify = false;
			}
		}
		else
		{
			m_error = true;
		}
		
		if(doNotify)
		{
			synchronized(this)
			{
				notifyAll();
			}
			if(m_signal != null)
			{
				synchronized(m_signal)
				{
					m_signal.signalAll();
				}
			}
		}
	}
	
	/**
	 * <P>This method is part of the SnmpHandler interface and called when
	 * an internal error happens in a session. This is usually the result
	 * of an I/O error. This method will not be called if the session times
	 * out sending a packet, see snmpTimeoutError for timeout handling.</P>
	 *
	 * @param session	The session that had an unexpected error
	 * @param error		The error condition
	 * @param pdu		The PDU being sent when the error occured
	 *
	 * @see #snmpTimeoutError
	 * @see org.opennms.protocols.snmp.SnmpHandler SnmpHandler
	 */
	public void snmpInternalError(SnmpSession session, int error, SnmpSyntax pdu)
	{
		m_error = true;

		synchronized(this)
		{
			notifyAll();
		}
		if(m_signal != null)
		{
			synchronized(m_signal)
			{
				m_signal.signalAll();
			}
		}
	}
	
	/**
	 * <P>This method is part of the SnmpHandler interface and is invoked
	 * when the SnmpSession does not receive a reply after exhausting 
	 * the retransmission attempts.</P>
	 *
	 * @param session	The session invoking the error handler
	 * @param pdu		The PDU that the remote failed to respond to.
	 *
	 * @see org.opennms.protocols.snmp.SnmpHandler SnmpHandler
	 *
	 */
	public void snmpTimeoutError(SnmpSession session, SnmpSyntax pdu)
	{
		m_error = true;

		synchronized(this)
		{
			notifyAll();
		}
		if(m_signal != null)
		{
			synchronized(m_signal)
			{
				m_signal.signalAll();
			}
		}
	}

}
				


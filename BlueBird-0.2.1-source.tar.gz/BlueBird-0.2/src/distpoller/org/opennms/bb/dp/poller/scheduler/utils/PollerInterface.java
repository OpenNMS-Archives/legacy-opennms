//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.dp.poller.scheduler.utils;

import java.sql.*;
import java.util.*;
import java.util.Date;
import java.text.*;

import org.opennms.bb.dp.poller.scheduler.utils.PollerNode;
import org.opennms.bb.dp.poller.scheduler.utils.PollerPackage;
import org.opennms.bb.dp.poller.scheduler.utils.UnitConverter;

import org.opennms.bb.dp.poller.plugins.ServiceMonitor;

import org.opennms.bb.common.db.DBConnection;
import org.opennms.bb.common.db.DBOpenFailureException;

/**This class represents a BlueBird interface and operations 
 * that can be made on them.
 * 
 * @author <A HREF="mailto:jason@opennms.org">Jason Johns</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version $Revision: 1.7 $
 * 
 */
public class PollerInterface
{
	/**The ip address of the interface
	*/
	private String m_address;
	
	/**The list of services that this interface supports
	*/
	private HashMap m_services;
	
	/**Indicates if the interface is managed or not
	*/
	private String m_managedStatus;
	
	/**The list of packages that this interface is a member of
	*/
	private PollerPackage m_package;
	
	/**This is the index into the list that the scheduler has. This interface
	   will be put into a list associated with a given package, this is the 
	   index to find that package.
	*/
	private int m_packageIndex;
	
	/**
	*/
	private DBConnection m_connection;
	
	/**
	*/
	public static final String MANAGED     = "Y";
	public static final String NOT_MANAGED = "N";
	
	/**
	*/
	private static final char SECONDS = 's';
	private static final char MINUTES = 'm';
	private static final char HOURS   = 'h';
	private static final char DAYS    = 'd';
	
        private static final int SECOND_MULTIPLIER = 1;
	private static final int MINUTE_MULTIPLIER = 60;
	private static final int HOUR_MULTIPLIER   = 3600;
	private static final int DAY_MULTIPLIER    = 86400;
	
	/**
	*/
	private class Service
	{
		/**
		*/
		private String m_serviceName;
		
		/**
		*/
		private Calendar m_lastGood;
		
		/**
		*/
		private Calendar m_lastFail;
		
		/**
		*/
		private SimpleDateFormat m_dateFormat;
		
		/**
		*/
		private int m_lastKnownStatus;
		
		/**
		*/
		public Service(String aName, String goodDate, String failDate)
		{
			m_serviceName = aName;
			m_lastGood = new GregorianCalendar();
			m_lastFail = new GregorianCalendar();
			
			m_dateFormat = new SimpleDateFormat("dd-MMM-yyyy hh:mm:ss");
			
			try
			{
				m_lastGood.setTime(m_dateFormat.parse(goodDate));
				m_lastFail.setTime(m_dateFormat.parse(failDate));
			}
			catch(ParseException e)
			{
				System.out.println(e);
			}
			
			if(m_lastGood.after(m_lastFail))
			{
				m_lastKnownStatus = ServiceMonitor.SERVICE_AVAILABLE;
			}
			else
			{
				m_lastKnownStatus = ServiceMonitor.SERVICE_UNAVAILABLE;
			}
		}
		
		/**
		*/
		public int getLastKnownStatus()
		{
			return m_lastKnownStatus;
		}
		
		/**
		*/
		public void setLastKnownStatus(int aStatus)
		{
			m_lastKnownStatus = aStatus;
		}
		
		/**
		*/
		public Calendar getLastGood()
		{
			return m_lastGood;
		}
		
		/**
		*/
		public Calendar getLastFail()
		{
			return m_lastFail;
		}
		
		/**
		*/
		public void setLastGood(Calendar date)
		{
			m_lastGood = date;
		}
		
		/**
		*/
		public void setLastFail(Calendar date)
		{
			m_lastFail = date;
		}
		
		/**
		*/
		public String getName()
		{
			return m_serviceName;
		}
		
		/**
		*/
		public String toString()
		{
			return m_serviceName + "\r\n" +
			       "Last good: " + m_dateFormat.format(m_lastGood.getTime()) + "\r\n" + 
			       "Last fail: " + m_dateFormat.format(m_lastFail.getTime());
		}
	}

	/**Constructor, sets the ip address
	   @param Integer anAddress, the ip address of the interface
	*/
	public PollerInterface(String anAddress, PollerPackage aPackage, int aPackageIndex)
		throws SQLException, DBOpenFailureException
	{
		m_address = anAddress;
		m_packageIndex = aPackageIndex;
		m_package = aPackage;
		
		m_connection = new DBConnection();
		
		//get information from database
		m_services = getServices(m_connection, m_address);
		m_managedStatus = getManagedStatus(m_connection, m_address);
	}
	
	/**
	*/
	public void updateStatus(String aServiceName, int aStatus)
	{
		Service service = (Service)m_services.get(aServiceName);
		
		Calendar current = new GregorianCalendar();
		current.setTime(new Date(System.currentTimeMillis()));
		
		service.setLastKnownStatus(aStatus);
		
		if (aStatus == ServiceMonitor.SERVICE_AVAILABLE)
		{
			service.setLastGood(current);
		}
		else
		{
			service.setLastFail(current);
		}
	}
	
	/**
	*/
	private int getUpIntervalSeconds(String aServiceName)
	{
		int interval = Integer.MAX_VALUE;
		
		int multiplier = 0;
		int curInterval = 0;
		
		ServiceInfo curService = (ServiceInfo)m_package.getService(aServiceName);
		
		curInterval =  UnitConverter.getSeconds(curService.getServiceParameter(ServiceInfo.INTERVAL));
		
		if (curInterval < interval)
		{
			interval = curInterval;
		}
		
		return interval;
	}
	
	/**
	*/
	private int getDownIntervalSeconds(String aServiceName, Calendar lastUp)
	{
		ServiceInfo serviceInfo = m_package.getService(aServiceName);
		
		PollerModel model = serviceInfo.getModel();
		
		//if there is no downtime model then use the available interval
		if (model == null)
			return getUpIntervalSeconds(aServiceName);
			
		//divide by 1000 to get seconds instead of milliseconds
		int difference = (int)( (System.currentTimeMillis() - ((Date)lastUp.getTime()).getTime()) / 1000);
		
		return model.getIntervalValue(difference);
	}
	
	/**
	*/
	public Integer getNewInterval(String aServiceName, int aStatus)
	{
		int interval = 0;
		
		if(aStatus == ServiceMonitor.SERVICE_AVAILABLE)
		{
			interval = getUpIntervalSeconds(aServiceName);
		}
		else if (aStatus == ServiceMonitor.SERVICE_UNAVAILABLE)
		{
			Service service = (Service)m_services.get(aServiceName);
			
			interval = getDownIntervalSeconds(aServiceName, service.getLastGood());
		}
		
		return new Integer(interval);
	}
	
	/**
	*/
	public int getServiceLastKnownStatus(String aServiceName)
	{
		Service service = (Service)m_services.get(aServiceName);
		
		return service.getLastKnownStatus();
	}
	
	/**
	*/
	public PollerPackage getPackage()
	{
		return m_package;
	}
	
	/**
	*/
	public int getPackageIndex()
	{
		return m_packageIndex;
	}
	
	/**
	*/
	private HashMap getServices(DBConnection aConnection, String anAddress)
		throws SQLException
	{
		HashMap services = new HashMap();
		
		String sql = 	"SELECT service.serviceName, ifServices.lastGood, ifServices.lastFail\r\n"+
				"FROM service, ifServices, ipInterface\r\n" +
				"WHERE ipInterface.ipaddr = '" + m_address + "'\r\n" +
				"AND ipInterface.ipaddr = ifServices.ipaddr\r\n" +
				"AND ifServices.serviceID = service.serviceID";
		
		ResultSet result = aConnection.getResultSet(sql);
		
		while (result.next ())
	    	{
			services.put(result.getString(1),
					new Service(result.getString(1), 
						    result.getString(2), 
						    result.getString(3)));
	    	}
		
		return services;
	}
	
	/**
	*/
	private String getManagedStatus(DBConnection aConnection, String anAddress)
		throws SQLException
	{
		String sql = 	"SELECT ipInterface.isManaged\r\n"+
				"FROM ipInterface\r\n" +
				"WHERE ipInterface.ipaddr = '" + m_address + "'";
			
		ResultSet result = aConnection.getResultSet(sql);
			
		result.next();
		
		return result.getString(1);
	}
	
	/**This method returns the managed status of the interface
	   @return String, the managed status
	*/
	public String getManaged()
	{
		return m_managedStatus;
	}
	
	/**This method returns the ip address
	   @return Integer, the ip address
	*/
	public String getAddress()
	{
		return m_address;
	}
	
	/**This method returns the PollerNode associated with
	   this interface
	   @return PollerNode, the interfaces parent node
	*/
	public PollerNode getNode()
	{
		return null;
	}

	/**
	*/
	public boolean supportsService(String aService)
	{
		boolean result = false;
		
		if (m_services.containsKey(aService))
		{
			result = true;
		}
		
		return result;
	}
	
	/**This method returns a string representation of the PollerInterface
	   @return String, the string representation of the PollerInterface
	*/
	public String toString()
	{
		StringBuffer buffer =  new StringBuffer("Interface: " + m_address + "\r\n" + 
		       		                        "Managed  : " + m_managedStatus + "\r\n" +
							"Packages : " + m_package.getName());
		
		buffer.append("\r\nServices: ");
		
		Iterator i = m_services.keySet().iterator();
		
		while(i.hasNext())
		{
			buffer.append( ((Service)m_services.get(i.next())).toString() + "\r\n");
		}
		
		return buffer.toString();
	}
}

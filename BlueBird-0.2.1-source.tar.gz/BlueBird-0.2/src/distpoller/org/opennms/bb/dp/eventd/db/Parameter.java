//
// Copyright (C) 2000 N*Manage Company, Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
// $Id: Parameter.java,v 1.1 2000/11/15 18:50:34 sowmya Exp $
//
package org.opennms.bb.dp.eventd.db;

import java.lang.*;
import java.util.List;
import java.util.Iterator;
import org.opennms.bb.dp.events.EventParameter;
import org.opennms.bb.dp.events.EventParamValue;

/**
 *
 * @author <A HREF="mailto:weave@opennms.org">Brian Weaver</A>
 * @author <A HREF="http://www.opennms.org">OpenNMS</A>
 *
 * @version CVS $Revision: 1.1 $
 *
 */
public final class Parameter
{
	/**
	 */
	public static String format(List parms)
	{
		boolean 	first = true;
		Iterator 	i = parms.iterator();
		StringBuffer	parmbuf = new StringBuffer();
		while(i.hasNext() && parmbuf.length() < 1024)
		{
			EventParameter parm = (EventParameter)i.next();
			if(!first)
				parmbuf.append(Constants.MULTIPLE_VAL_DELIM);
			parmbuf.append(format(parm));
			first = false;
		}
		
		if (parmbuf.length() >= 1024)
		{
			parmbuf.setLength(1020);
			parmbuf.append(Constants.VALUE_TRUNCATE_INDICATOR);
		}
		
		return parmbuf.toString();
	}

	/**
	 */
	public static String format(EventParameter parm)
	{
		String type = EventParamValue.TYPE_NAMES[parm.getValue().getType()];
		String encoding = EventParamValue.XML_ENCODING_NAMES[parm.getValue().getEncoding()];
		
		String tmp  = Constants.escape(parm.getName(), Constants.NAME_VAL_DELIM);
		String name = Constants.escape(tmp, Constants.MULTIPLE_VAL_DELIM);
		tmp = Constants.escape(parm.getValue().toString(), Constants.NAME_VAL_DELIM);
		String value = Constants.escape(tmp, Constants.MULTIPLE_VAL_DELIM);
			
		return 	name + Constants.NAME_VAL_DELIM + value + "(" + type + Constants.DB_ATTRIB_DELIM + encoding + ")";
	}
}


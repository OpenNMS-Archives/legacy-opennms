//
// Copyright (C) 2000 N*Manage Company, Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
package org.opennms.bb.dp.actiond.components;

import java.util.*;
import java.io.*;

import org.opennms.bb.common.components.*;
import org.opennms.bb.dp.common.components.PollerThread;
import org.opennms.bb.dp.actiond.Actiond;

/**
 * <pre>ActionLaunchManager is responsible for launching any auto actions
 * associated with the incoming event - it maintains a pool of 'ActionLauncher'
 * threads to do this. 
 
 * @author 	<A HREF="mailto:mike@opennms.org">Mike</A>*
 * @author 	<A HREF="mailto:sowmya@opennms.org">Sowmya Kumaraswamy</A>
 * @author	<A HREF="mailto:weave@opennms.org">Brian Weaver</A>
 * @author	<A HREF="http://www.opennms.org">OpenNMS.org</A>
 *
 * @version	$Revision: 1.2 $
 */
public class ActionLaunchManager
{

	/**
	 * <P>The property name that contains the maximum number of threads
	 * to be used by the ActionLaunchManager.</P>
	 */
	private final static String PROP_MAX_ACTION_LAUNCHER_THREADS = "org.opennms.bluebird.actiond.maxActionLauncherThreads";

	/**
	 * <P>The initial number of launcher threads.</P>
	 */
	private static int	INIT_NUM_LAUNCHERS=5; 

	/**
	 * <P>The max number of threads in the thread pool - this
	 * is configurable through the actiond properties.</P>
	 */
	private static int	max_launchers = 10;

	/**
	 * <P>The property name that contains the number of milliseconds to wait
	 * for an external command to complete before considering it hung.</P>
	 */
	private final static String PROP_COMMAND_TIMEOUT = "org.opennms.bluebird.actiond.commandTimeout";

	/** <P>Length of time (in milliseconds) to wait for a command to finish 
	 * before forcing it to terminate.  This value is configurable through 
	 * the actiond property PROP_COMMAND_TIMEOUT.</P>
	 */
	private static long COMMAND_TIMEOUT = 60 * 1000; // Default is 60 seconds

	/**
	 * <P>The queue to which the actions that are to be executed are
	 * added.</P>
	 */
	private PCQueue			m_actionQ;

	/**
	 * <P>The pool of launcher threads.</P>
	 */
	private List			m_launcherThreads;

	/**
	 * After each read from the actionQ, the threads in the thread
	 * pool call this method to adjust the number of threads in the pool
	 * if necessary
	 *
	 * If the number of entries in the queue is more than double the
	 * number of threads, the number of threads is increased by one
	 * until the configurable maximum number of threads is reached
	 *
	 * If the number of threads in thepool is more than double the
	 * number of entries in the queue, the number of threads is
	 * decreased by one until the predefined initial number of threads
	 * is reached
	 *
	 */
	protected synchronized void threadsVsQueueSizeCheck()
	{
		int curNumThreads = m_launcherThreads.size();
		int numQEntries = m_actionQ.entries();

		if ( (curNumThreads < max_launchers)  &&
		     ((numQEntries / curNumThreads) > 2) )
		{
			// increase by 1!
			ActionLauncher launcherThread = new ActionLauncher(this, m_actionQ, COMMAND_TIMEOUT);
			if (launcherThread != null)
			{
				synchronized(m_launcherThreads)
				{
					m_launcherThreads.add(launcherThread);
				}

				// Start the new thread so it can do work
				launcherThread.start();
			}
		}
	}

	/**
	 * Constructs the ActionLaunchManager - creates the 'ActionLauncher'
	 * thread pool and starts the INIT_NUM_LAUNCHERS number of the threads 
	 *
	 * The maximum number of threads in the pool can be configured via
	 * the PROP_MAX_ACTION_LAUNCHER_THREADS property -
	 * the maximum number defaults to 10
	 *
	 * The command timeout is the number of milliseconds that the launcher 
	 * should wait for a launched command to complete.  If this period is
	 * exceeded the command is considered hung and is terminated.  This value
	 * can be configured via the PROP_COMMAND_TIMEOUT property.  This value 
	 * defaults to 60 seconds.
	 *
	 * @param	actionQ	queue from which actions to be executed are read
	 *
	 */
	public ActionLaunchManager(PCQueue actionQ)
	{
		String threadNum = Actiond.getProperty(PROP_MAX_ACTION_LAUNCHER_THREADS);
		if(threadNum != null)
		{
			try
			{
				max_launchers = Integer.parseInt(threadNum);
				if (max_launchers < 1)
					max_launchers = 1;
			}
			catch(NumberFormatException ne)
			{
				max_launchers = 10;
				Log.print(Log.WARNING, "Unable to correctly parse property: " 
							+ PROP_MAX_ACTION_LAUNCHER_THREADS 
							+ ", value = " 
							+ threadNum);
				Log.print(Log.WARNING, "Defaulting to max thread count of " + max_launchers);
			}
		}
	
		String strTimeout = Actiond.getProperty(PROP_COMMAND_TIMEOUT);
		if(strTimeout != null)
		{
			try
			{
				COMMAND_TIMEOUT = Integer.parseInt(strTimeout);
			}
			catch(NumberFormatException ne)
			{
				COMMAND_TIMEOUT = 60 * 1000;
			}
		}

		m_actionQ = actionQ;

		//
		// Adjust initial monitor poller thread count based on configured max
		//
		if (max_launchers < INIT_NUM_LAUNCHERS)
			INIT_NUM_LAUNCHERS = max_launchers;

		/* 
		 * Create the listener thread pool - start with 
		 * INIT_NUM_LAUNCHERS number of threads
		 */
		m_launcherThreads = Collections.synchronizedList(new ArrayList(max_launchers));
		for (int iIndex=0; iIndex<INIT_NUM_LAUNCHERS; iIndex++)
		{
			ActionLauncher launcherThread = new ActionLauncher(this, m_actionQ, COMMAND_TIMEOUT);
			if (launcherThread != null)
			{
				m_launcherThreads.add(launcherThread);
			}
		}

		//
		// Start each of the launcher threads
		//
		synchronized(this)
		{
			Iterator iter = m_launcherThreads.iterator();
			while(iter.hasNext())
			{
				ActionLauncher launcher = (ActionLauncher)iter.next();
				launcher.start();
			}

		}

	}

	/**
	 * This method goes through and pauses all threads in the thread
	 * pool
	 */
	public synchronized void pauseOperation()
	{
		try
		{
			Iterator iter = m_launcherThreads.iterator();
			while(iter.hasNext())
				PollerThread.pauseThread((PollerThread)iter.next());
		}
		catch(InterruptedException iE)
		{
			// do nothing
		}
						
	}

	/**
	 * This method goes through and resumes all threads in the thread
	 * pool
	 */
	public synchronized void resumeOperation()
	{
		try
		{
			Iterator iter = m_launcherThreads.iterator();
			while(iter.hasNext())
				PollerThread.resumeThread((PollerThread)iter.next());
		}
		catch(InterruptedException iE)
		{
			// do nothing
		}
						
	}

	/**
	 * This method goes through and shuts down all threads in the thread
	 * pool
	 */
	public void shutdown()
	{
		try
		{
			Iterator iter = m_launcherThreads.iterator();
			while(iter.hasNext())
				PollerThread.shutdownThread((PollerThread)iter.next());
						
		}
		catch(Exception e) 
		{ 
			// do nothing
		}
	}

}

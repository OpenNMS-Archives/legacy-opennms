//
// Copyright (C) 2000 N*Manage Company Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
// $Id: DiscPollersParser.java,v 1.6 2000/10/05 19:35:15 weave Exp $
//

package org.opennms.bb.dp.discovery.utils;


import java.io.*;
import java.net.*;
import java.util.*;

import org.w3c.dom.*;

import org.opennms.bb.common.utils.BBParser;
import org.opennms.bb.common.components.Log;
import org.opennms.protocols.ip.IPv4Address;

/**
 * <P>The DiscPollersParser class is designed parse the 
 * <EM>pollersXML.xml</EM> configuration file for the information
 * that is specific to the discovery process. The class extends the
 * BBParser class and overrides the necessary methods to correctly
 * parse the XML configuration file.</P>
 *
 * @author <A HREF="sowmya@opennms.org>Sowmya</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version $Revision: 1.6 $
 *
 */
public final class DiscPollersParser extends BBParser
{
	/**
	 * <P>This defines the IPv4 Address of this poller. The class
	 * should only load the information relevant to this poller
	 * and ignore the rest.</P>
	 */
	private long		m_ipAddr; 

	/**
	 * <P>The discovery limit load for this poller from the XML
	 * configuration file.</P>
	 */
	private float		m_discLimit;

	/**
	 * <P>The list of poller packages that should be used by 
	 * discovery.</P>
	 */
	private List		m_packages;

	/**
	 * <P>This is the IP Address of the current XML configation info.
	 * As the file is parsed, this address will change to match the
	 * section being parsed.</P>
	 */
	private long 		m_curPollerIP;

	//
	// XML TAGS that are relevant
	//
	private final String DISCLIMIT	= "discLimit";
	private final String POLLERIP	= "pollerIP";
	private final String PACKAGE	= "package";
	private final String TYPE	= "type";

	/**
	 * <P>Overrides the base class' method and parses the proper
	 * element types for the discovery XML types. The method is
	 * invoked by the DOM parser when a new element is discovered.</P>
	 *
	 * @param el		The element that is currently being processed.
	 * @param isRoot	True if the element is a root element.
	 *
	 */
	protected boolean processElement(Element el, boolean isRoot)
	{
		boolean bRet = false;
		Node curNode = (Node)el;
		String tag   = el.getTagName();

		if (tag.equals(POLLERIP))
		{
			m_curElement.replace(0, m_curElement.length(), POLLERIP);

			// get attribute
			String type     = el.getAttribute(TYPE);
			String parsedIP = processParmValue(curNode); 
			if (null != parsedIP)
			{
				//
				// Parse the IP Address
				//
				if (type.equalsIgnoreCase("int"))
				{
					try
					{
						m_curPollerIP = Long.parseLong(parsedIP);
					}
					catch(NumberFormatException e) { m_curPollerIP = 0; }
				}
				else if (type.equalsIgnoreCase("hex"))
				{
					try
					{
						m_curPollerIP = Long.parseLong(parsedIP, 16);
					}
					catch(NumberFormatException e) { m_curPollerIP = 0; }
				}
				else if (type.equalsIgnoreCase("string"))
				{
					//
					// Try to convert the string to a valid 
					// IP Address
					//
					long address = 0;
					try
					{
						IPv4Address tAddr = new IPv4Address(InetAddress.getByName(parsedIP));
						address = tAddr.getAddress();
						
						//
						// wrap to the proper domain if necessary
						//
						if(address < 0)
							address += ((long)Integer.MAX_VALUE) + 1L;
					}
					catch(UnknownHostException e)
					{
						Log.print(Log.INFORMATIONAL, "Error converting string \"" 
									     + parsedIP 
									     + "\" to an InetAddress object");
						Log.print(Log.INFORMATIONAL, e);
					}
					
					m_curPollerIP = address;
				}
			}

			bRet = true;
		}
		else if (tag.equals(PACKAGE))
		{
			//
			// parse the package node. If the package is not
			// null & the current ip is correct, then add
			// the package to the list of packages.
			//
			m_curElement.replace(0, m_curElement.length(), PACKAGE);

			bRet = true;
			if (m_curPollerIP == m_ipAddr)
			{
				String packageName = processParmValue(curNode); 
				if (null != packageName)
				{
					m_packages.add(packageName);
				}
				else
				{
					bRet = false;
				}
			}
		}
		else if (tag.equals(DISCLIMIT))
		{
			//
			// Get the current discovery limit. If the
			// discovery limit fails to parse then it
			// will be equal to zero and a false will be
			// returned.
			//
			m_curElement.replace(0, m_curElement.length(), DISCLIMIT);

			bRet = true;
			if (m_curPollerIP == m_ipAddr)
			{
				m_discLimit  = 0;
				String discL = processParmValue(curNode);
				if (null != discL)
				{
					// if number format exception, ignore?
					try
					{
						Float dl    = new Float(discL);
						m_discLimit = dl.floatValue();
					}
					catch(NumberFormatException e) { bRet = false; }
				}
				else
				{
					bRet = false;
				}
			}
		}
		else
		{
			//
			// it's not a terminal node, so call
			// process node on each of its elements.
			//
			boolean bNodeRet = true;

			NodeList nl = el.getChildNodes();
			int size    = nl.getLength();

			for(int i = 0;i < size && bNodeRet ;i++)
				bNodeRet = processNode(nl.item(i));
			
			bRet = bNodeRet;
		}
		
		return bRet;
	}

	/**
	 * <P>The class constructor initilizes a new instance
	 * of the class to parse the discovery XML configation
	 * file into a DOM tree. Once the tree is loaded the
	 * relevant information is processed for the callers
	 * consumption.</P>
	 *
	 * @param ipAddr	The IP Address of the poller
	 * 	configuation that is desired.
	 */
	public DiscPollersParser(long ipAddr)
	{
		super();
		m_ipAddr = ipAddr;
		m_packages = new ArrayList();
	}

	/**
	 * <P>Returns the discovery bandwidth limitation as found
	 * in the XML configuation document.</P>
	 *
	 * @return The discovery bandwidth limit.
	 */
	public float getBandwidthLimit()
	{
		return m_discLimit;
	}

	/**
	 * <P>Returns the list of poller packages that were
	 * parsed from the XML configuration document. The 
	 * list is not synchronized and care should be used 
	 * when shared between multiple threads.</P>
	 *
	 * @return The list of packages
	 */
	public List getPackages()
	{
		return m_packages;
	}
}

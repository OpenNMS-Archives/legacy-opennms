//
// Copyright (C) 2000 N*Manage Company, Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
package org.opennms.bb.dp.actiond.components;

import java.io.*;
import java.util.*;

import org.apache.xerces.parsers.SAXParser;
import org.opennms.bb.common.components.*;
import org.opennms.bb.dp.common.components.*;

import org.opennms.bb.dp.actiond.Actiond;
import org.opennms.bb.dp.events.XMLEventsParser;

/**
 * <P>ActiondEventListener extends the PollerThread for the pause/resume/shutdown 
 * functionality </P>
 *
 * <P>Listens for events sent as XML over JSDT from the event daemon (eventd).
 * Received data as 'EventsReader'(conatining the input stream) is added
 * to the 'listenerQ'</P>
 * 
 * <P>It also maintains a pool of RunnableConsumerThreads that read and
 * run the EventsReader objects added to the listenerQ to actually parse
 * the input streams to events('EventBlocks') in order to extract any
 * automatic actions associated with the event - the 'EventsReader's are 
 * then added to the 'actionQ' where they are read by 'ExecuteAction'
 * threads and the actions actually executed by launching a new process.</P>
 *
 *
 * @author 	<A HREF="mailto:mike@opennms.org">Mike</A>
 * @author 	<A HREF="mailto:sowmya@opennms.org">Sowmya Kumaraswamy</A>
 * @author	<A HREF="mailto:weave@opennms.org">Brian Weaver</A>
 * @author	<A HREF="http://www.opennms.org">OpenNMS.org</A>
 *
 * @version	$Revision: 1.2 $
 */
public class ActiondEventListener extends PollerThread
{

	/**
	 * <P>The property name that contains the maximum number of threads
	 * to be used by the ActiondEventListenr for parsing event XML streams.	</P>
	 */
	private final static String PROP_MAX_EVENT_LISTENER_THREADS = "org.opennms.bluebird.actiond.maxEventListenerThreads";

	/**
	 * <P>The initial number of threads.</P>
	 */
	private static int INIT_NUM_READERS=2; 
	
	/**
	 * <P>The queue to which the incoming events are added.</P>
	 */
	private PCQueue		m_listenerQ;

	/**
	 * <P>The queue to which completed reader objects are sent
	 * for further processing.</P>
	 */
	private PCQueue		m_actionQ;

	/**
	 * <P>The handler for events coming in through JSDT from eventd.</P>
	 */
	private ActiondEventReceiver	m_eventReceiver;

	/**
	 * <P>The max number of RunnableConsumerThreads that should be
	 * started by the manager.</P>
	 */
	private static int		max_readers=5;

	/**
	 * The RunnableConsumerThread thread pool.  Responsible for
	 * running reader objects which parse the XML input stream
	 * and build a list of Event objects for later processing by the
	 * launchManager.  When the reader object is finished processing it
	 * is placed on the m_actionQ.
	 */
	private List		m_eventReaders;
	
	/**
	 * A hash table for the parser pool to be used by the
	 * 'RunnableConsumerThread' pool - a parser is added to the pool
	 * for each thread in the pool so that when the threads can then look
	 * up their parser by using the current thread ID
	 *
	 */
	private static Map	m_eventsParserPool;

	/*
	 * Create the parser pool hashtable
	 */
	static
	{
		m_eventsParserPool = new Hashtable();
	}

	/**
	 * After each read from the listenerQ, the threads in the thread
	 * pool call this method to adjust the number of threads in the pool
	 * if necessary
	 *
	 * If the number of entries in the queue is more than double the
	 * number of threads, the number of threads is increased by one
	 * until the configurable maximum number of threads is reached
	 *
	 * If the number of threads in thepool is more than double the
	 * number of entries in the queue, the number of threads is
	 * decreased by one until the predefined initial number of threads
	 * is reached
	 *
	 */
	protected synchronized void threadsVsQueueSizeCheck()
	{
		int curNumThreads = m_eventReaders.size();
		int numQEntries = m_listenerQ.entries();

		if ( (curNumThreads < max_readers)  &&
		     ((numQEntries / curNumThreads) > 2) )
		{
			// increase by 1!
			RunnableConsumerThread readerThread = new RunnableConsumerThread(m_listenerQ, m_actionQ);

			// create a parser for each of the threads
			SAXParser saxp = new SAXParser();
			XMLEventsParser parser = new XMLEventsParser();
			saxp.setContentHandler(parser);
			saxp.setErrorHandler(parser);

			try
			{
				// Start the thread so it can do work
				readerThread.start();
				m_eventsParserPool.put(readerThread, saxp);
				m_eventReaders.add(readerThread);
				
				
			}
			catch (RuntimeException re)
			{
				Log.print(Log.WARNING, "Error starting new consumer thread");
				Log.print(Log.WARNING, re);
				
				m_eventsParserPool.remove(readerThread);
				readerThread.shutdown();
				m_eventReaders.remove(readerThread);
			}
		}
	}

	/**
	 * <P>Creates the ActiondEventListener thread of actiond that listens for 
	 * events via JSDT from eventd</P>
	 *
	 * <P>The ActiondEventListener also has a pool of 'RunnableConsumerThread'
	 * threads that reads the input streams added by the individual
	 * listeners and parses the streams (this is done by running the
	 * EventsReader objects in the listenerQ) </P>
	 *
	 * @exception throws ActiondEventListenerException if any of the handlers fail to get created
	 */
	public ActiondEventListener(PCQueue actionQ) throws ActiondEventListenerException
	{
		String threadNum = Actiond.getProperty(PROP_MAX_EVENT_LISTENER_THREADS);
		if(threadNum != null)
		{
			try
			{
				max_readers = Integer.parseInt(threadNum);
				if (max_readers < 1)
					max_readers = 1;
			}
			catch(NumberFormatException ne)
			{
				max_readers = 5;
				Log.print(Log.WARNING, "Unable to correctly parse property: " 
							+ PROP_MAX_EVENT_LISTENER_THREADS 
							+ ", value = " 
							+ threadNum);
				Log.print(Log.WARNING, "Defaulting to max thread count of " + max_readers);
			}
		}
		
		ArrayList unwinder = new ArrayList(max_readers);
		try
		{
			m_listenerQ  = new PCQueueLinkedList();

			m_actionQ  = actionQ;

			m_eventReceiver= new ActiondEventReceiver(this, m_listenerQ);

			
			//
			// Adjust initial monitor poller thread count based on configured max
			//
			if (max_readers < INIT_NUM_READERS)
				INIT_NUM_READERS = max_readers;

			/* 
		 	 * Create the listener thread pool 
		 	 */
			m_eventReaders = Collections.synchronizedList(new ArrayList(max_readers));
			for (int iIndex = 0; iIndex < INIT_NUM_READERS; iIndex++)
			{
				RunnableConsumerThread readerThread = new RunnableConsumerThread(m_listenerQ, m_actionQ);
				m_eventReaders.add(readerThread);
				unwinder.add(readerThread);
				
				// create a parser for each of the threads
				SAXParser saxp = new SAXParser();
				XMLEventsParser parser = new XMLEventsParser();
				saxp.setContentHandler(parser);
				saxp.setErrorHandler(parser);
				m_eventsParserPool.put(readerThread, saxp);
			}

		}
		catch (Exception e)
		{
			Log.print(Log.ERROR, "Error starting up the RunnableConsumerThreads for the ActiondEventListener: " + e.getMessage());
			
			Iterator iter = unwinder.iterator();
			while(iter.hasNext())
			{
				try
				{
					((RunnableConsumerThread)iter.next()).shutdown();
				}
				catch(Exception e2) { }
			}

			throw new ActiondEventListenerException(e.getMessage());
		}
	}

	/**
	 * Loop through and keep track of the status changes. When a pause/
	 * resume/shutdown is recieved, the status is updated and 
	 * the handler threads are paused/resumed as appropriate
	 */
	public void run()
	{	
		// Start the initial number of threads
		Iterator readsIter = m_eventReaders.iterator();
		while(readsIter.hasNext())
		{
			RunnableConsumerThread thr = (RunnableConsumerThread)readsIter.next();
			thr.start();
		}
		setOpStatus(STATUS_NORMAL);

		Log.print(Log.INFORMATIONAL, "ActiondEventListener readers thread pool up");

		for (;;)
		{
			synchronized(this)
			{
				for(;;)
				{
					// wait for status change
					try
					{
						wait();
					}
					catch(InterruptedException e)
					{
					}

					int status = getOpStatus();
					if((status & STATUS_TERMINATING) == STATUS_TERMINATING)
					{
						m_eventReceiver.shutdown();

						Iterator iter = m_eventReaders.iterator();
						while(iter.hasNext())
						{
							try
							{
								shutdownThread((RunnableConsumerThread)iter.next());
							}
							catch(Exception e)
							{
								Log.print(Log.ERROR, "Error shutting down the RunnableConsumerThread: " + e.getMessage());
							}
						}
												
						setOpStatus(STATUS_SHUTDOWN);
						return;
					}
					else if((status & STATUS_PAUSING) == STATUS_PAUSING)
					{
						boolean setPaused = true;
						try
						{
							m_eventReceiver.pauseOperation();

							Iterator iter = m_eventReaders.iterator();
							while(iter.hasNext())
							{
								try
								{
									pauseThread((RunnableConsumerThread)iter.next());
								}
								catch(Exception e)
								{
									Log.print(Log.ERROR, "Error pausing the RunnableConsumerThread: " + e.getMessage());
								}
							}
						}
						catch(IllegalThreadStateException e)
						{
							setPaused = false;
							setOpStatus(STATUS_TERMINATING);
							break;
						}

						if(setPaused)
							setOpStatus(STATUS_PAUSED);
	
					}
					else if((status & STATUS_RESUMING) == STATUS_RESUMING)
					{

						boolean setNormal = true;
						try
						{
							m_eventReceiver.resumeOperation();

							Iterator iter = m_eventReaders.iterator();
							while(iter.hasNext())
							{
								try
								{
									resumeThread((RunnableConsumerThread)iter.next());
								}
								catch(Exception e)
								{
									Log.print(Log.ERROR, "Error resuming the RunnableConsumerThrea: " + e.getMessage());
								}
							}
						}
						catch(IllegalThreadStateException e)
						{
							setNormal = false;
							setOpStatus(STATUS_TERMINATING);
						}
							
						if(setNormal)
							setOpStatus(STATUS_NORMAL);
					}
					else if((status & STATUS_PAUSED) == STATUS_PAUSED)
					{
						try
						{
							wait();
						}
						catch(InterruptedException e)
						{
							setOpStatus(STATUS_TERMINATING);
						}
					}
					else if((status & STATUS_NORMAL) == STATUS_NORMAL)
					{
						break; // exit status checking loop
					}

				} // end for(;;) status check

			} // end synchronization 
			
		}
	}

	/**
	 * <P>Initiates the shutdown sequence and  waits for 
	 * this thread to exit.</P>
	 */
	public synchronized void shutdown()
	{
		m_eventReceiver.shutdown();

		try
		{
			super.shutdown();
			if(Thread.currentThread().equals(this) == false)
				join();
		}
		catch(Exception e) 
		{ 
			// do nothing
		}
	}

	/**
	 * Returns the SAX based parser that can be used to 
	 * decompose the event. Use the getContentHandler
	 * method of the parser to get the event parser!
	 *
	 * @param key	the currently running thread
	 *
	 * @return The SAX parser that can be used to decompose
	 * 	the event object.
	 *
	 * @see org.apache.xerces.parser.SAXParser#getContentHandler
	 * @see org.apache.soap.sax.SAXParser#getContentHandler
	 */
	public static SAXParser getEventsParser(Object key)
	{
		return (SAXParser)m_eventsParserPool.get(key);
	}
	
}

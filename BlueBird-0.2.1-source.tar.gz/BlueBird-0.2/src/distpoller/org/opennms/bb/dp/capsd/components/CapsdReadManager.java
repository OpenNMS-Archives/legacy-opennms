//
// Copyright (C) 2000 N*Manage Company Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
// Tab Stop = 8
//
// $Id: CapsdReadManager.java,v 1.12 2000/10/18 19:05:39 sowmya Exp $
//

package org.opennms.bb.dp.capsd.components;

import java.net.*;
import java.io.*;
import java.util.*;

import org.opennms.bb.common.components.*;
import org.opennms.bb.dp.common.components.*;

/**
 * <P>CapsdReadManager is responsible to query the IPAddresses received 
 * from discovery for the SNMP information. It maintains a pool of 
 * RunnableConsumerThreads that take input (CapsReader) from the 
 * discRecvQ, send out the SNMP query requests and then adds the
 * CapsReader object to the databaseQ.</P>
 *
 * @author <A HREF="mailto:sowmya@opennms.org">Sowmya</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version $Revision: 1.12 $
 */
public class CapsdReadManager extends PollerThread
{
	/**
	 * <P>The queue to which the newly discovered nodes from discovery are
	 * received.</P>
	 */
	private PCQueue	m_discRecvQ;

	/**
	 * <P>Input queue to the RunnableConsumerThreads. CapsReader objects
	 * are added to the queue so when these run they query the
	 * nodes for SNMP info and the services status.</P>
	 */
	private PCQueue	m_capsPropReadQ;

	/**
	 * <P>The backside queue for the RunnableConsumerThread instances.
	 * Once the objects are actually executed via their run methods, the
	 * completed object is palced into this queue.</P>
	 */
	private PCQueue	m_databaseQ;

	/**
	 * <P>The list of RunnableConsumerThreads used to execute
	 * the CapsReader objects.</P>
	 */
	private List	m_threads;
	
	/**
	 * <P>The number of RunnableConsumerThreads that should be
	 * started by the manager.</P>
	 */
	private static final int	NUM_READERS  	= 10;

	/**
	 * <P>The list containing the service plugin objects.</P>
	 */
	private List	m_plugins;
	
	/**
	 * Set of nodes (ip addresses) already known by Capsd
	 */
   	private Set		m_dupNodes;

	/**
	 * <P>The default constructor for the class. The constructor
	 * is not supported and will always throw an unsupported 
	 * operation exception.</P>
	 *
	 * @exception UnsupportedOperationException Always thrown 
	 * 	by the constructor.
	 */
	private CapsdReadManager() 
		throws UnsupportedOperationException
	{
		throw new UnsupportedOperationException("The default constructor is not supported");
	}

	/**
	 * <P>Creates a new CapsdReadManager that creates a RunnableConsumerThread
	 * thread pool. The instance manages the thread pool and the queueus that
	 * are the source of information for the runnable consumer classes.</P>
	 *
	 * @param discRecvQ	 The queue to which the newly discovered nodes
	 *                       from discovery are added.
	 * @param databaseQ	 The queue to which nodes are added after the SNMP 
	 *                       and plugin queries are completed - output Q  
	 *                       to the RunnableConsumerThread(s).
	 * @param servicePlugins The list that contains all the service plugins
	 *                       with each plugin having its capability name
	 *                       class to handle the plugin etc.
	 * @param dupNodes 	The set that contains all the addresses already known
	 *                  to Capsd.
	 *
	 * @exception java.lang.IllegalArgumentException Thrown if either of the passed
	 * 	queues are null.
	 */
	public CapsdReadManager(PCQueue discRecvQ, PCQueue databaseQ, List servicePlugins, Set dupNodes)
	{
		//
		// check the queues to make sure they are non-null. The 
		// service plugins may be null, if only SNMP is to be supported.
		//
		if(discRecvQ == null || databaseQ == null)
			throw new IllegalArgumentException("The passed queues must not be null");
		
		//
		// Setup the queues and the list of plugins
		//
		m_discRecvQ = discRecvQ;
		m_databaseQ = databaseQ;
		m_plugins   = servicePlugins;

		//
		// Set the m_dupNodes reference
		//
		m_dupNodes = dupNodes;

		/*
		 * Input Q to the RunnableConsumerThreads
		 */
		m_capsPropReadQ = new PCQueueLinkedList();

		/* 
		 * Create the listener thread pool 
		 */
		m_threads = new ArrayList(NUM_READERS);
		for (int iIndex = 0; iIndex < NUM_READERS; iIndex++)
		{
			RunnableConsumerThread readerThread = new RunnableConsumerThread(m_capsPropReadQ, m_databaseQ);
			m_threads.add(readerThread);
		}

		// Once here set operational status 
		setOpStatus(STATUS_STARTING);
	}


	/**
	 * <P>The run method is the core of the object in terms of managing
	 * the consumer threads and enqueuing objects for the consumers. When
	 * the run method is first called the consumer threads are started.
	 * After the threads are started the method monitors for status changes
	 * and transforms discovery messages into CapsReader objects for the
	 * runnable consumers.</P>
	 */
	public void run()
	{
		// Loop through and start the thread pool
		{ // start up the threads
			ArrayList unwinder = new ArrayList(NUM_READERS);
			try
			{
				Iterator iter = m_threads.iterator();
				while(iter.hasNext())
				{
					RunnableConsumerThread thr = (RunnableConsumerThread)iter.next();
					thr.start();
					unwinder.add(thr);
				}
			}
			catch(Exception e)
			{
				Log.print(Log.ERROR, "Error starting up the RunnableConsumerThreads for the CapsdReadManager");
				Log.print(Log.ERROR, e);
			
				Iterator iter = unwinder.iterator();
				while(iter.hasNext())
				{
					try
					{
						((RunnableConsumerThread)iter.next()).shutdown();
					}
					catch(Exception e2) { }
				}
				setOpStatus(STATUS_SHUTDOWN);
				return;
			}
		} // end threads startup

		setOpStatus(STATUS_NORMAL);
		
		for(;;)
		{
			synchronized(this)
			{
				for(;;)
				{
					int status = getOpStatus();
					if((status & STATUS_TERMINATING) == STATUS_TERMINATING)
					{
						try
						{// close the capsProp Q
							m_capsPropReadQ.close();
						}
						catch(Exception e)
						{
							Log.print(Log.ERROR, "Error closing the read queue");
							Log.print(Log.ERROR, e);
						}

						Iterator iter = m_threads.iterator();
						while(iter.hasNext())
						{
							try
							{
								((RunnableConsumerThread)iter.next()).shutdown();
							}
							catch(Exception e)
							{
								Log.print(Log.ERROR, "Error shutting down the RunnableConsumerThread");
								Log.print(Log.ERROR, e);
							}
						}

						setOpStatus(STATUS_SHUTDOWN);
						return;
					}
					else if((status & STATUS_PAUSING) == STATUS_PAUSING)
					{
						Iterator iter = m_threads.iterator();
						while(iter.hasNext())
							((RunnableConsumerThread)iter.next()).pauseOperation();
						setOpStatus(STATUS_PAUSED);
					}
					else if((status & STATUS_RESUMING) == STATUS_RESUMING)
					{
						Iterator iter = m_threads.iterator();
						while(iter.hasNext())
							((RunnableConsumerThread)iter.next()).pauseOperation();
						setOpStatus(STATUS_NORMAL);
					}
					else if((status & STATUS_PAUSED) == STATUS_PAUSED)
					{
						try
						{
							wait();
						}
						catch(InterruptedException e)
						{
							Log.print(Log.WARNING, "CapsdReadManager interrrupted, status changed to terminating");
							Log.print(Log.WARNING, e);
							setOpStatus(STATUS_TERMINATING);
						}
					}
					else if((status & STATUS_NORMAL) == STATUS_NORMAL)
					{
						break; // exit status checking loop
					}
				} // end for(;;) status check
			} // end synchronization 

			// if the m_discRecvQ is empty, register with the queue for
			// notification on add and wait for  signal from queue
			// or signal due to status change
			boolean waitForQueue = false;
			synchronized(m_discRecvQ)
			{
				if(m_discRecvQ.entries() == 0)
				{
					m_discRecvQ.oneShotNotifyAllOnAdd(this);
                    			waitForQueue = true;
                		}
            		}

            		if(waitForQueue)
            		{
				synchronized(this)
				{
                			try
                			{
       						wait(); // queue or status change can signal
                			}
                			catch(InterruptedException ie)
                			{
                			}
				}

				// if status is not normal, continue and handle
				// status change
				int status = getOpStatus();
				if((status & STATUS_NORMAL) != STATUS_NORMAL)
					continue;
            		}


			//
			// read off of the m_discRecvQ and add entries to the
			// m_capsPropReadQ
			//
			String ipAddress=null;
			try
			{
				ipAddress =  (String)m_discRecvQ.read();
			}
			catch(QueueClosedException qcE)
			{
				Log.print(Log.ERROR, "The input queue from discovery is closed, status terminating");
				Log.print(Log.ERROR, qcE);
				setOpStatus(STATUS_TERMINATING);
				ipAddress = null;
			}
			catch(InterruptedException iE)
			{
				Log.print(Log.ERROR, "CapsdReadManager: Unable to read IP address from discovery receive Q");
				Log.print(Log.ERROR, iE);
				setOpStatus(STATUS_TERMINATING);
				ipAddress = null;
			}

			if (ipAddress != null)
			{
				try
				{
					m_capsPropReadQ.add(new CapsReader(ipAddress, m_plugins, m_dupNodes));
				}
				catch(InterruptedException intE)
				{
					Log.print(Log.ERROR, "CapsdReadManager: Unable to add IP address to SNMP properties read Q:" + ipAddress);
					Log.print(Log.ERROR, intE);
					setOpStatus(STATUS_TERMINATING);
				}
			}
		}
	}

	/**
	 * Start the shutdown and notify run() to shutdown
	 */
	public void shutdown()
	{
		try
		{
			super.shutdown();
			if(Thread.currentThread().equals(this) == false)
				join();
		}
		catch(Exception e) 
		{ 
			// do nothing
		}
	}
}

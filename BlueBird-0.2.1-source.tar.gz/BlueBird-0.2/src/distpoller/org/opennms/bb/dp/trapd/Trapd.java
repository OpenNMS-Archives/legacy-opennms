//
// Copyright (C) 2000 N*Manage Company, Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
// $Id: Trapd.java,v 1.1 2000/11/15 18:50:34 sowmya Exp $
//
package org.opennms.bb.dp.trapd;

import java.lang.*;
import java.net.*;
import java.util.*;
import java.io.*;
import com.sun.media.jsdt.*;

import org.opennms.protocols.snmp.*;
import org.opennms.protocols.ip.IPv4Address;
import org.opennms.bb.common.components.*;
import org.opennms.bb.dp.common.components.*;

import org.opennms.bb.dp.events.*;


/**
 * <P>The Trapd listens for SNMP traps on the standard port(162).
 * Creates a SnmpTrapSession and implements the SnmpTrapHandler to get
 * callbacks when traps are received</P>
 *
 * <P>The received traps are converted into XML and sent to eventd via
 * JSDT </P>
 *
 * @author 	<A HREF="mailto:sowmya@opennms.org">Sowmya Kumaraswamy</A>
 * @author	<A HREF="mailto:weave@opennms.org">Brian Weaver</A>
 * @author	<A HREF="http://www.opennms.org">OpenNMS.org</A>
 *
 * @version	$Revision: 1.1 $
 */
public class Trapd extends PollerClient implements SnmpTrapHandler
{
	/**
	 * The trap session used by Trapd to receive traps
	 */
	private SnmpTrapSession	m_trapSession;

	/**
	 * The JSDT session on which messages are sent to eventd
	 */
	private Session		m_session;

	/**
	 * The JSDT channel on which eventd is listening for messages
	 */
	private Channel		m_channel;

	// DEBUG 
	// Used to maintain count of the number of traps processed by trapd during a run
	private static long trapCount=0;

	/**
	 * Connect to the eventd JSDT channel
	 *
	 * @throws java.lang.InterruptedException Thrown if the running
	 * 	thread is interrupted by another thread.
	 */
	private void connect() 
		throws JSDTException
	{
		URLString url = URLString.createSessionURL(PollerJSDTConstants.HOSTNAME, 
							   PollerJSDTConstants.EVENTS_SESSION_PORT,
							   PollerJSDTConstants.REGISTRY_TYPE, 
							   PollerJSDTConstants.EVENTS_SESSION_NAME);
		if(!SessionFactory.sessionExists(url))
			throw new NoSuchSessionException();
			
		m_session = SessionFactory.createSession(this, url, true);
		m_channel = m_session.createChannel(this, 
						    PollerJSDTConstants.EVENTS_SOURCE_CHANNEL,
						    true, 
						    false, 
						    true);
	}

	/**
	 * Create the SNMP trap session and create the JSDT communication 
	 * channel to communicate with eventd.
	 *
	 * @param port	The port number where SNMP traps should be received.
	 *	If the port number is equal to -1 then the default port is used.
	 *
	 * @exception java.net.SocketException 		Thrown when the SnmpTrapSession 
	 *	cannot create the datagram socket
	 * @exception java.lang.SecurityException 	Thrown if the security manager 
	 *	disallows the creation of the handler
	 *
	 * @see org.opennms.protocols.snmp.SnmpTrapSession
	 * @see org.opennms.protocols.snmp.SnmpTrapHandler
	 */
	private void trapdInit(int port)  
		throws SocketException, JSDTException
	{
		if (port == -1)
			m_trapSession = new SnmpTrapSession(this);
		else
			m_trapSession = new SnmpTrapSession(this, port);
		connect();
	}
	
	/**
	 * <P>Constructs a new Trapd object that receives and forwards
	 * trap messages via JSDT. The session is initialized with the
	 * default client name of <EM>OpenNMS.trapd</EM>. The trap session
	 * is started on the default port, as defined by the SNMP libarary.</P>
	 *
	 * @see org.opennms.protocols.snmp.SnmpTrapSession
	 *
	 * @exception java.net.SocketException 		Thrown when the SnmpTrapSession 
	 *	cannot create the datagram socket
	 * @exception java.lang.SecurityException 	Thrown if the security manager 
	 *	disallows the creation of the handler
	 */
	public Trapd()
		throws SocketException, JSDTException
	{
		super("OpenNMS.trapd");
		trapdInit(-1);
	}

	/**
	 * <P>Constructs a new Trapd object that receives and forwards
	 * trap messages via JSDT. The trap session is started on the 
	 * default port, as defined by the SNMP libarary.</P>
	 *
	 * @param clientName 	The JSDT client identifier for Trapd
	 *
	 * @exception java.net.SocketException 		Thrown when the SnmpTrapSession 
	 *	cannot create the datagram socket
	 * @exception java.lang.SecurityException 	Thrown if the security manager 
	 *	disallows the creation of the handler
	 */
	public Trapd(String clientName)
		throws SocketException, JSDTException
	{
		super(clientName);
		trapdInit(-1);
	}

	/**
	 * <P>Constructs a new Trapd object that receives and forwards
	 * trap messages via JSDT. The session is initialized with the
	 * client name of <EM>OpenNMS.trapd:&lt;port&gt;</EM>. The trap session
	 * is started on the passed number.</P>
	 *
	 * @param port	The port number for the trap session.
	 *
	 * @exception java.net.SocketException 		Thrown when the SnmpTrapSession 
	 *	cannot create the datagram socket
	 * @exception java.lang.SecurityException 	Thrown if the security manager 
	 *	disallows the creation of the handler
	 */
	public Trapd(int port)
		throws SocketException, JSDTException
	{
		super("OpenNMS.trapd:" + port);
		trapdInit(port);
	}

	/**
	 * Constructor for Trapd
	 *
	 * @parm clientName the JSDT client identifier for Trapd
	 * @parm port       the port to be used by the SnmpTrapSession of Trapd
	 *
	 * @exception throws SocketException thrown when the SnmpTrapSession cannot create the datagram socket
	 * @exception throws SecurityException thrown if the security manager disallows the creation of the handler
	 */
	/**
	 * <P>Constructs a new Trapd object that receives and forwards
	 * trap messages via JSDT. The new session is initialized with
	 * the passed JSDT client name and the defined trap port number.</P>
	 *
	 * @param clientName	The name for this JSDT client.
	 * @param port		The port number for the trap session.
	 *
	 * @exception java.net.SocketException 		Thrown when the SnmpTrapSession 
	 *	cannot create the datagram socket
	 * @exception java.lang.SecurityException 	Thrown if the security manager 
	 *	disallows the creation of the handler
	 */
	public Trapd(String clientName, int port)
		throws SocketException, JSDTException
	{
		super(clientName);
		trapdInit(port);
	}

	/**
	 * <P>Process the recieved SNMP v2c trap that was received
	 * by the underlying trap session.</P>
	 *
	 * @param session	The trap session that received the datagram.
	 * @param agent		The remote agent that sent the datagram.
	 * @param port		The remmote port the trap was sent from.
	 * @param community	The community string contained in the message.
	 * @param pdu		The protocol data unit containing the data
	 *
	 */
	public void snmpReceivedTrap(SnmpTrapSession	session,
			             InetAddress	agent,
			             int		port,
			             SnmpOctetString	community,
			             SnmpPduPacket	pdu)
	{
		if(pdu.typeId() != SnmpPduPacket.V2TRAP)
		{
			// if not V2 trap, do nothing
			Log.print(Log.INFORMATIONAL, "Recieved not SNMPv2 Trap from host " + agent.getHostAddress());
			Log.print(Log.INFORMATIONAL, "PDU Type = " + pdu.getCommand());
			return;
		}
		IPv4Address addr = new IPv4Address(agent);

		Event event = new Event();
		event.setSource("trapd");
		event.setSnmpHost(addr.toString());
		event.setTime(new GregorianCalendar());
		
		//
		// set the information
		//
		if(pdu.getLength() >= 2)
		{
			EventSnmpInfo snmpInfo = new EventSnmpInfo();
			snmpInfo.setEnterpriseID(pdu.getVarBindAt(1).getValue().toString());
			event.setSnmpInfo(snmpInfo);
			
			for(int i = 0; i < pdu.getLength(); i++)
			{
				EventParamValue val = null;
				
				String name    = pdu.getVarBindAt(i).getName().toString();
				SnmpSyntax obj = pdu.getVarBindAt(i).getValue();
				if(obj instanceof SnmpInt32)
				{
					val = new EventParamValue(EventParamValue.TYPE_SNMP_INT32,
								  EventParamValue.XML_ENCODING_TEXT,
								  obj);
				}
				else if(obj instanceof SnmpNull)
				{
					val = new EventParamValue(EventParamValue.TYPE_SNMP_NULL,
								  EventParamValue.XML_ENCODING_TEXT,
								  obj);
				}
				else if(obj instanceof SnmpObjectId)
				{
					val = new EventParamValue(EventParamValue.TYPE_SNMP_OBJECT_IDENTIFIER,
								  EventParamValue.XML_ENCODING_TEXT,
								  obj);
				}
				else if(obj instanceof SnmpIPAddress)
				{
					val = new EventParamValue(EventParamValue.TYPE_SNMP_IPADDRESS,
								  EventParamValue.XML_ENCODING_TEXT,
								  obj);
				}
				else if(obj instanceof SnmpTimeTicks)
				{
					val = new EventParamValue(EventParamValue.TYPE_SNMP_TIMETICKS,
								  EventParamValue.XML_ENCODING_TEXT,
								  obj);
				}
				else if(obj instanceof SnmpCounter32)
				{
					val = new EventParamValue(EventParamValue.TYPE_SNMP_COUNTER32,
								  EventParamValue.XML_ENCODING_TEXT,
								  obj);
				}
				else if(obj instanceof SnmpGauge32)
				{
					val = new EventParamValue(EventParamValue.TYPE_SNMP_GAUGE32,
								  EventParamValue.XML_ENCODING_TEXT,
								  obj);
				}
				else if(obj instanceof SnmpOpaque)
				{
					val = new EventParamValue(EventParamValue.TYPE_SNMP_OPAQUE,
								  EventParamValue.XML_ENCODING_BASE64,
								  obj);
				}
				else if(obj instanceof SnmpOctetString)
				{
					//
					// check for non-printable characters. If they
					// exist then print the string out as hexidecimal
					//
					boolean asHex = false;
					byte[]  data  = ((SnmpOctetString)obj).getString();
					for(int x = 0; x < data.length; x++)
					{
						byte b = data[x];
						if((b < 32 && b != 10 && b != 13) ||  b == 127)
						{
							asHex = true;
							break;
						}
					}
					data = null;
					val = new EventParamValue(EventParamValue.TYPE_SNMP_OCTET_STRING,
								  asHex ? EventParamValue.XML_ENCODING_BASE64 
								  	: EventParamValue.XML_ENCODING_TEXT,
								  obj);

					// DEBUG
					if (!asHex)
					{
						Log.print(Log.DEBUG, "snmpReceivedTrap: string varbind: " + ( ((SnmpOctetString)obj).toString() ));
					}
				}
				else if(obj instanceof SnmpCounter64)
				{
					val = new EventParamValue(EventParamValue.TYPE_SNMP_COUNTER64,
								  EventParamValue.XML_ENCODING_TEXT,
								  obj);
				}
				else
				{
					val = new EventParamValue(EventParamValue.TYPE_STRING,
								  EventParamValue.XML_ENCODING_TEXT,
								  obj.toString());
				}
				
				event.addParm(new EventParameter(name,val));
			} // end for loop
		}
		
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		List events = new ArrayList(1);
		events.add(event);
		XMLEventsParser.serializeToXML(bos, events);
		try
		{
			m_channel.sendToOthers(this, new Data(bos.toByteArray()));
			Log.print(Log.DEBUG, "snmpReceivedTrap(packet): total traps processed: " + ++trapCount); // DEBUG
		}
		catch(JSDTException jE)
		{
			Log.print(Log.WARNING, "Unable to send trap to eventd");
			Log.print(Log.WARNING, jE.getMessage());
		}
	}

	/**
	 * <P>Process the recieved SNMP v1 trap that was received
	 * by the underlying trap session.</P>
	 *
	 * @param session	The trap session that received the datagram.
	 * @param agent		The remote agent that sent the datagram.
	 * @param port		The remmote port the trap was sent from.
	 * @param community	The community string contained in the message.
	 * @param pdu		The protocol data unit containing the data
	 *
	 */
	public void snmpReceivedTrap(SnmpTrapSession	session,
				     InetAddress	agent,
				     int		port,
				     SnmpOctetString	community,
				     SnmpPduTrap	pdu)
	{
		IPv4Address addr = new IPv4Address(agent);

		Event event = new Event();
		event.setSource("trapd");
		event.setHost(addr.toString());
		event.setSnmpHost(pdu.getAgentAddress().toString());
		event.setTime(new GregorianCalendar());
		
		//
		// set the information
		//
		EventSnmpInfo snmpInfo = new EventSnmpInfo();
		snmpInfo.setEnterpriseID(pdu.getEnterprise().toString());
		snmpInfo.setGeneric(pdu.getGeneric());
		snmpInfo.setSpecific(pdu.getSpecific());
		
		event.setSnmpInfo(snmpInfo);
			
		List parms = new ArrayList(pdu.getLength());
		for(int i = 0; i < pdu.getLength(); i++)
		{
			EventParamValue val = null;
			
			String name    = pdu.getVarBindAt(i).getName().toString();
			SnmpSyntax obj = pdu.getVarBindAt(i).getValue();
			if(obj instanceof SnmpInt32)
			{
				val = new EventParamValue(EventParamValue.TYPE_SNMP_INT32,
							  EventParamValue.XML_ENCODING_TEXT,
							  obj);
			}
			else if(obj instanceof SnmpNull)
			{
				val = new EventParamValue(EventParamValue.TYPE_SNMP_NULL,
							  EventParamValue.XML_ENCODING_TEXT,
							  obj);
			}
			else if(obj instanceof SnmpObjectId)
			{
				val = new EventParamValue(EventParamValue.TYPE_SNMP_OBJECT_IDENTIFIER,
							  EventParamValue.XML_ENCODING_TEXT,
							  obj);
			}
			else if(obj instanceof SnmpIPAddress)
			{
				val = new EventParamValue(EventParamValue.TYPE_SNMP_IPADDRESS,
							  EventParamValue.XML_ENCODING_TEXT,
							  obj);
			}
			else if(obj instanceof SnmpTimeTicks)
			{
				val = new EventParamValue(EventParamValue.TYPE_SNMP_TIMETICKS,
							  EventParamValue.XML_ENCODING_TEXT,
							  obj);
			}
			else if(obj instanceof SnmpCounter32)
			{
				val = new EventParamValue(EventParamValue.TYPE_SNMP_COUNTER32,
							  EventParamValue.XML_ENCODING_TEXT,
							  obj);
			}
			else if(obj instanceof SnmpGauge32)
			{
				val = new EventParamValue(EventParamValue.TYPE_SNMP_GAUGE32,
							  EventParamValue.XML_ENCODING_TEXT,
							  obj);
			}
			else if(obj instanceof SnmpOpaque)
			{
				val = new EventParamValue(EventParamValue.TYPE_SNMP_OPAQUE,
							  EventParamValue.XML_ENCODING_BASE64,
							  obj);
			}
			else if(obj instanceof SnmpOctetString)
			{
				//
				// check for non-printable characters. If they
				// exist then print the string out as hexidecimal
				//
				boolean asHex = false;
				byte[]  data  = ((SnmpOctetString)obj).getString();
				for(int x = 0; x < data.length; x++)
				{
					byte b = data[x];
					if((b < 32 && b != 10 && b != 13) ||  b == 127)
					{
						asHex = true;
						break;
					}
				}
				data = null;
				val = new EventParamValue(EventParamValue.TYPE_SNMP_OCTET_STRING,
							  asHex ? EventParamValue.XML_ENCODING_BASE64 
								: EventParamValue.XML_ENCODING_TEXT,
							  obj);

				// DEBUG
				if (!asHex)
				{
					Log.print(Log.DEBUG, "snmpReceivedTrap: string varbind: " + ( ((SnmpOctetString)obj).toString() ));
				}
			}
			else if(obj instanceof SnmpCounter64)
			{
				val = new EventParamValue(EventParamValue.TYPE_SNMP_COUNTER64,
							  EventParamValue.XML_ENCODING_TEXT,
							  obj);
			}
			else
			{
				val = new EventParamValue(EventParamValue.TYPE_STRING,
							  EventParamValue.XML_ENCODING_TEXT,
							  obj.toString());
			}
			
			parms.add(new EventParameter(name,val));
		} // end for loop
		
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		List events = new ArrayList(1);
		events.add(event);
		XMLEventsParser.serializeToXML(bos, events);
		try
		{
			m_channel.sendToOthers(this, new Data(bos.toByteArray()));
			Log.print(Log.DEBUG, "snmpReceivedTrap(trap): total traps processed: " + ++trapCount); // DEBUG
		}
		catch(JSDTException jE)
		{
			Log.print(Log.WARNING, "Unable to send trap to eventd");
			Log.print(Log.WARNING, jE.getMessage());
		}
	}


	/**
	 * <P>Processes an error condition that occurs in the SnmpTrapSession.
	 * The errors are logged and ignored by the trapd class.</P>
	 *
	 * @see org.opennms.bb.common.components.Log
	 */
	public void snmpTrapSessionError(SnmpTrapSession session, 
					 int		 error,
					 Object		 ref)
	{
		Log.print(Log.WARNING, "Error Processing Received Trap: error = " + error 
					+ (ref != null ? ", ref = " + ref.toString() : ""));
	}


	/**
	 * Closes the JSDT channel and the trap session
	 */
	public void close()
	{
		try
		{
			m_session.close(false);
		}
		catch(JSDTException e) 
		{
			Log.print(Log.WARNING, "Exception while trying to close JSDT session");
			Log.print(Log.WARNING, e);
		}

		m_trapSession.close();
	}

	/**
	 * Instantiate a trap listener
	 */
	public static void main(String[] args)
	{
		Log.setLevel(Log.SPILLGUTS);
		try
		{
			Trapd trapListener = new Trapd("Trapd");
			Log.print(Log.INFORMATIONAL, "Trapd: Ready to receive traps.");
		}
		catch(SocketException sockE)
		{
			Log.print(Log.FATAL, sockE);
			System.exit(1);
		}
		catch(JSDTException jsdtE)
		{
			Log.print(Log.FATAL, jsdtE);
			System.exit(1);
		}
	}
}

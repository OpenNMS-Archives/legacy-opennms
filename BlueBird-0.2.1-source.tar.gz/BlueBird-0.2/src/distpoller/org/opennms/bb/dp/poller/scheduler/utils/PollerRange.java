//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.dp.poller.scheduler.utils;

import java.util.*;

import org.opennms.bb.dp.poller.scheduler.utils.Parameter;

/**This class is responsible for holding information about ranges
 * parsed from the package.xml file. It basically provides a wrapper
 * for a number of Parameter object that are taken from on of the 
 * children tags under the <ranges> tag in the xml file.
 *
 * @author <A HREF="mailto:jason@opennms.org">Jason Johns</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version $Revision: 1.1 $
 * 
 */
public class PollerRange
{
	/**These are parameter names used to associate with name/value pairs
	*/
	public static final String TIMEOUT   = "timeout";
	public static final String RETRIES   = "retries";
	public static final String BEGIN     = "begin";
	public static final String END       = "end";
	public static final String IPADDRESS = "IP Address";
	public static final String URL       = "URL";
	
	/**A map to hold multiple Parameter objects
	*/
	private HashMap m_rangeDetails;
	
	/**Default constructor, allocates the members
	*/
	public PollerRange()
	{
		m_rangeDetails = new HashMap();
	}
	
	/**This method adds a Parameter object to the PollerRange
	   @param Parameter param, the new Parameter to add
	*/
	public void addRangeParam(Parameter param)
	{
		m_rangeDetails.put(param.getName(), param);
	}
	
	/**This method returns the value of a named Parameter
	   @return String, the value assocaited with the key
	   @param String key, the key to the value to look up
	*/
	public String getValue(String key)
	{
		Parameter p = (Parameter)m_rangeDetails.get(key);
		return (String)p.getValue();
	}
	
	/**This method provides a string representation of the PollerRange
	   @String, the string representation
	*/
	public String toString()
	{
		StringBuffer buffer = new StringBuffer();
		
		Iterator i = m_rangeDetails.keySet().iterator();
		
		while (i.hasNext())
		{
			buffer.append("\t");
			buffer.append(((Parameter)m_rangeDetails.get(i.next())).toString());
			buffer.append("\r\n");
		}
		
		return buffer.toString();
	}
}

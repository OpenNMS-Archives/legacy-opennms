//
// Copyright (C) 2000 N*Manage Company Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
// Tab Stop = 8
//

package org.opennms.bb.dp.spmd;

import java.io.*;
import java.util.Properties;
import com.sun.media.jsdt.*;

import org.opennms.bb.common.components.Log;
import org.opennms.bb.dp.common.components.*;

/**
 * Spmd is the class that will bring up the discovery/capsd/other poller
 * processes.. - as of now, just creates the JSDT registry -
 * (will be replaced by the SCM) 
 *
 *
 * @author Sowmya
 */
public class Spmd
{
	private PollerClient client;

	/**
	 * <P>The properties that are specific to the spmd process. The 
	 * properties are a combination of the JVM's system properties, plus
	 * the inclusion of the OpenNMS specific property files. There are two
	 * additional files that are loaded, if the system properties are 
	 * correctly set.</P>
	 *
	 * <P>In order to properly load the OpenNMS specific file(s) their
	 * location must be known in advance. Instead of hard coding the
	 * location of the files, the files are referenced by properties.
	 * The following list declares the properites that reference the 
	 * specific files. The property files are loaded in the order
	 * they appear in the list.</P>
	 *
	 * <UL>
	 *	<LI>org.opennms.bluebird.propertyFile</LI>
	 *	<LI>org.openmms.bluebird.spmd.propertyFile</LI>
	 * </UL>
	 *
	 * <P>Currently the string returned for the propertyFile(s) must
	 * be a file on the local filesystem. Later support for remote
	 * files via HTTP, JSDT, etc al may be supported.</P>
	 */
	private static Properties	m_properties = null;
	
	/**
	 * <P>Copy the System properties and then load the bluebird
	 * and spmd specific files into the property object.
	 * For more information see the javadoc comment for the m_properties
	 * element.</P>
	 *
	 * <P>Additionally, this static loading will also look at the debugging 
	 * options and will setup the Logging Facility. This can only be done
	 * after the properties have been loaded.</P>
	 */
	static
	{
		//
		// get a new properties element and make the 
		// system properties the backing map
		//
		m_properties     = new Properties(System.getProperties());

		//
		// try to load the bluebird specific properties
		//
		String file = m_properties.getProperty("org.opennms.bluebird.propertyFile");
		if(file != null)
		{
			FileInputStream pfile = null;
			try
			{
				pfile = new FileInputStream(file);
				m_properties.load(pfile);
				pfile.close();
				m_properties = new Properties(m_properties); // new property with loaded as backing map
			}
			catch(IOException e) 
			{
				// do nothing
			}
		}

		//
		// Load the spmd specific files now
		//
		file = m_properties.getProperty("org.opennms.bluebird.spmd.propertyFile");
		if(file != null)
		{
			FileInputStream pfile = null;
			try
			{
				pfile = new FileInputStream(file);
				m_properties.load(pfile);
				pfile.close();
			}
			catch(IOException e)
			{
				// do nothing
			}
		}
		// end static load of properties.

		//
		// setup the debug and log facility for spmd
		//
		Log.setLevel(0);
		String logLevel = m_properties.getProperty("org.opennms.bluebird.spmd.logLevel");
		if(logLevel != null)
		{
			try
			{
				Log.setLevel(Integer.parseInt(logLevel));
			}
			catch(NumberFormatException ne) { Log.setLevel(Log.WARNING); }
		}
		
		file = m_properties.getProperty("org.opennms.bluebird.spmd.logFile");
		if(file != null)
		{
			try
			{
				Log.setOut(file);
			}
			catch(IOException e)
			{
				Log.disable();
			}
		}

		// end Log class setup
		
	} // end static class initialization

	/**
	 * Creates the Spmd
	 */
	public Spmd()
	{

		if(!jsdtInitialize("Spmd"))
		{
			Log.print(Log.FATAL, "Unable to create JSDT communication between discovery and capsd");
			System.exit(1);
		}
		else
			Log.print(Log.INFORMATIONAL, "Server up");

	}

	/**
	 * Create all the required JSDT Sessions 
	 */
	public boolean jsdtInitialize(String clientName)  
	{
		boolean sessionExists=false;
		boolean connected=false;

		Session		 session1;
		Session		 session2;
		Session		 session3;

		try
		{
			/* Start Registry if its not already running */
            		if (!RegistryFactory.registryExists(PollerJSDTConstants.REGISTRY_TYPE)) 
			{
                		RegistryFactory.startRegistry(PollerJSDTConstants.REGISTRY_TYPE);
            		}

			// Events session used by Events, Discovery, Capsd and ICMP service monitor
 			URLString url1 = URLString.createSessionURL(
					PollerJSDTConstants.HOSTNAME, 
					PollerJSDTConstants.EVENTS_SESSION_PORT,
					PollerJSDTConstants.REGISTRY_TYPE, 
					PollerJSDTConstants.EVENTS_SESSION_NAME);

			Log.print(Log.INFORMATIONAL, "url: " + url1);

	        	client = new PollerClient(clientName);

			session1 = SessionFactory.createSession(client, url1, false);

			/******
			// Events session
 			URLString url2 = URLString.createSessionURL(
					PollerJSDTConstants.HOSTNAME, 
					PollerJSDTConstants.EVENTS_SESSION_PORT,
					PollerJSDTConstants.REGISTRY_TYPE, 
					PollerJSDTConstants.EVENTS_SESSION_NAME);

			Log.print(Log.INFORMATIONAL, "url: " + url2);

			session2 = SessionFactory.createSession(client, url2, false);

			// Discovery - ICMP Service Monitor session
			URLString url3 = URLString.createSessionURL(
					PollerJSDTConstants.HOSTNAME, 
					PollerJSDTConstants.EVENTS_SESSION_PORT,
					PollerJSDTConstants.REGISTRY_TYPE, 
					PollerJSDTConstants.EVENTS_SESSION_NAME);

			Log.print(Log.INFORMATIONAL, "url: " + url3);
	        client = new PollerClient(clientName);
			session3 = SessionFactory.createSession(client, url3, false);
			***********/

			connected = true;
		} 
		catch (JSDTException e)
		{
			connected = false;

			System.err.println(e.getMessage());
			e.printStackTrace();

			System.exit(1);
		}
		

		return connected;
	}

	public static Properties getProperties()
	{
		return m_properties;
	}
	
	public static String getProperty(String key)
	{
		return m_properties.getProperty(key);
	}

	/**
	 * Start the Spmd process
	 */
	public static void main(String[] args)
	{
		new Spmd();
	}
}

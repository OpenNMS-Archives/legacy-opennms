//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.dp.poller.scheduler.utils;

import java.util.*;

import org.opennms.bb.common.components.PCQueue;
import org.opennms.bb.common.components.PCQueueLinkedList;
import org.opennms.bb.dp.poller.plugins.PollerTask;

/**
*/
public class IntervalScheduler extends Thread
{
	/**Queue holding NetworkInterface runnables that need to be scheduled
	*/
	private HashMap m_waitList;
	
	/**
	*/
	private PCQueue m_readyQ;
	
	/**
	*/
	private int m_schedulePeriod;
	
	/**
	*/
	private int m_numDequeue;
	
	/**
	*/
	private int m_processRate;
	
	/**
	*/
	private Iterator m_iterator;
	
	/**
	*/
	private boolean m_done;
	
	/**
	*/
	public IntervalScheduler(int aSchedulePeriod, PCQueue aReadyQ)
	{
		m_schedulePeriod = aSchedulePeriod;
		m_waitList = new HashMap(); 
		m_iterator = m_waitList.keySet().iterator();
		m_readyQ = aReadyQ;
		m_done = false;
	}
	
	/**
	*/
	public void addPollerTask(PollerTask aTask)
	{
		m_waitList.put(aTask.getAddress().toString(), aTask);
		
		recalculateParams();
	}
	
	/**
	*/
	public int getScheduleInterval()
	{
		return m_schedulePeriod;
	}
	
	/**
	*/
	public int getProcessingRate()
	{
	 	return m_processRate;
	}
	
	/**
	*/
	public void removePollerTask(PollerTask aTask)
	{
		m_waitList.remove(aTask.getAddress().toString());
		
		//if we have removed the last task from this scheduler shut it down
		if (m_waitList.size() == 0)
		{
			stopScheduling();
		}
		else
		{
			recalculateParams();
		}
	}
	
	/**
	*/
	public void stopScheduling()
	{
		m_done = true;
	}
	
	/**
	*/
	public void restart()
	{
		m_done = false;
		start();
	}
	
	/**
	*/
	private void recalculateParams()
	{
		//determine the number we have to take off the queue each interval
		m_numDequeue = (int)Math.floor(m_waitList.size()/m_schedulePeriod) + 1;
		
		//determine how often we process interfaces, in milliseconds
		m_processRate = ((m_schedulePeriod * m_numDequeue) / m_waitList.size()) * 1000;
		
		System.out.println("Period = " + m_schedulePeriod + " Items: " + m_waitList.size() + " Dequeue # = " + m_numDequeue + " Process Rate = " + m_processRate);
	}
	
	/**
	*/
	public Object getNextTask()
	{
		if (!m_iterator.hasNext())
		{
			m_iterator = m_waitList.keySet().iterator();
		}
		
		return m_waitList.get(m_iterator.next());
	}
	
	/**
	*/
	public void run()
	{
		PollerTask next = null;

		try
		{
			while(!m_done)
			{
				for (int i = 0; i < m_numDequeue; i++)
				{
					next = (PollerTask)getNextTask();
				
					//System.out.println("sending " + next.getAddress().toString());
				
					if (!next.isProcessing())
					{
						next.setProcessing(true);
						m_readyQ.add( getNextTask() );
					}
				}
				
				sleep(m_processRate);
			}
		}
		catch (InterruptedException e)
		{
			System.out.println(e);
			e.printStackTrace();
		}
	}
}

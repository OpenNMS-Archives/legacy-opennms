//
// Copyright (C) 2000 N*Manage Company, Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
// $Id: UDPHandler.java,v 1.1 2000/11/15 18:50:34 sowmya Exp $
//
// Note: This file copied and modified from the original file located at
// events/org/opennms/bb/dp/events/eventd/components/UDPHandler.java
// 
package org.opennms.bb.dp.eventd;

import java.net.*;
import java.io.*;
import java.util.*;

import org.opennms.bb.common.components.*;
import org.opennms.bb.dp.common.components.*;

/**
 * <P>UDPHandler extends the PollerThread for the pause/resume/shutdown
 * functionality</P>
 *
 * <P>It handles all the events sent to eventd via UDP. It handles events
 * that are 16K or lesser in size</P>
 *
 * Comments: Some code adpated/changed from Rick's initial code for eventd - sk
 *
 * @author 	<A HREF="mailto:caseyh@colorado.edu">Rick Casey</A>
 * @author 	<A HREF="mailto:sowmya@opennms.org">Sowmya Kumaraswamy</A>
 * @author	<A HREF="mailto:weave@opennms.org">Brian Weaver</A>
 * @author	<A HREF="http://www.opennms.org">OpenNMS.org</A>
 *
 * @version	$Revision: 1.1 $
 */
public class UDPHandler extends PollerThread
{
	/**
	 * Buffer size used for input
	 */
	private final static int	BUF_SIZE = 16384;	// 16k buffer
	
	/**
	 * queue to the eventExpander
	 */
	private PCQueue			m_readerQ;

	/**
	 * UDP socket on which events are received
	 */
	private DatagramSocket		m_server;
	
	/**
	 * queue between the inner class that accepts new datagram packets and
	 * the main thread
	 */
	private PCQueue			m_udpQ;

	/**
	 * The datagram packet handler that accepts datagram packets and
	 * queues them back to the main thread
	 */
	private DatagramPacketHandler	m_handler;

	// This variable is strictly being used for debug purposes to 
	// keep track of the number of events received
	private static int numEventsRcvd=0; // DEBUG ONLY

	/**
	 * When the UDPHandler blocks on the 'receive()', there is no reliable
	 * way to interrupt the thread on a status change. Hence we use this
	 * inner class to handle the receive() and queue it back to the main
	 * handler
	 */
	private static class DatagramPacketHandler extends Thread
	{
		/**
		 * Flag to determine end of operation in the 'run' method
		 */
		private volatile boolean	m_shutdown;

		/**
		 * Flag indicating that operation be paused
		 */
		private volatile boolean	m_pause;
		
		/**
		 * The datagram reciever
		 */
		private DatagramSocket		m_server;
		
		/**
		 * The datagram destination
		 */
		private PCQueue			m_dest;

		/**
		 * Create the datagram packet handler object 
		 */
		public DatagramPacketHandler(DatagramSocket sock, PCQueue dest)
		{
			m_shutdown = false;
			m_pause    = false;
			m_server   = sock;
			m_dest	   = dest;
		}

		/**
		 * If not paused, accept datagram packets and queue them back to the
		 * main thread
		 */
		public void run()
		{
			int bufSz = 0;
			try
			{
				bufSz = m_server.getReceiveBufferSize();
				if(bufSz <= 0)
					throw new RuntimeException("Buffer Size Invalid!");
			}
			catch(SocketException se)
			{
				Log.print(Log.WARNING, "Error Starting receiving thread: " + se.getMessage());
				Log.print(Log.WARNING, se);
				return;
			}
			
			while(!m_shutdown)
			{
				try
				{
					DatagramPacket dgp = new DatagramPacket(new byte[bufSz], bufSz);
					m_server.receive(dgp);
				 	if (dgp.getLength() > bufSz)
					{
						Log.print(Log.WARNING, "Datagram size large than accepted limit of " + bufSz);
						Log.print(Log.WARNING, "Datagram will be discarded from host: " 
									+ dgp.getAddress().getHostName() 
									+ ", port: " + dgp.getPort());
					}
					else if (!m_pause)
					{
						m_dest.add(dgp);
					}
				}
				catch(IOException ioE)
				{
					Log.print(Log.WARNING, "UDPHandler: Event ignored: Unable to add event stream to event listener queue" + ioE.getMessage());
					Log.print(Log.WARNING, ioE);
				}
				catch(InterruptedException iE)
				{
					Log.print(Log.WARNING, "UDPHandler: Event ignored: Unable to add event stream to event listener queue" + iE.getMessage());
					Log.print(Log.WARNING, iE);
				}
				catch(QueueClosedException qE)
				{
					// if queue has been closed by the main thread, shutdown
					m_shutdown = true;
				}
			}
		}

		/**
		 * Set the 'm_pause' flag to indicate that operation be paused
		 */
		public void pauseOperation()
		{
			m_pause = true;
		}


		/**
		 * Set the 'm_pause' flag to indicate that operation be resumed
		 */
		public void resumeOperation()
		{
			m_pause = false;
		}

		/**
		 * Set the 'm_shutdown' flag to indicate that operation be ended
		 */
		public void shutdown()
		{
			m_shutdown = true;
		}
	}

	/**
	 * Called to setup the communications channel buffers.
	 * The method attempts to set the receive buffer size
	 * to 16k. If it fails then the default buffer size
	 * is recovered. If the default buffer size cannot be
	 * recovered then a zero is returned. 
	 *
	 * @return The communications channel receive buffer size.
	 *	A zero is returned on error
	 */
	private int setUpComm() 
	{
		int bufSz=BUF_SIZE;

		//
		// set the receive buffer
		//
		try
		{
			m_server.setReceiveBufferSize(BUF_SIZE);
			bufSz = m_server.getReceiveBufferSize();
		}
		catch(SocketException err)
		{
			bufSz = 0;
		}

		if(bufSz <= 0)
		{
			try
			{
				bufSz = m_server.getReceiveBufferSize();
			}
			catch(SocketException err)
			{
				bufSz = 0;
			}
		}
		return bufSz;
	}

	/**
	 * Constructs a handler listening at the port 'port'
	 *
	 * @param eListener	the event listener
	 * @param port		port number on which this handler is to listen
	 * @param readerQ	queue to which incoming events are to be addded
	 *
	 * @exception throws java.net.SocketException if the socket cannot
	 *		     be opened or if it cannot bind to the port number
	 *
	 * @exception throws org.xml.sax.SAXException if the events parser cannot be created
	 */
	UDPHandler(int port, PCQueue readerQ) 
		throws SocketException
	{
		super("UDPHandler-" + port);
	
		m_server    = new DatagramSocket(port);
		int bufSz   = setUpComm();
		if(bufSz == 0)
			throw new SocketException("Unable to set receive buffer size");
			
		m_readerQ = readerQ;
		m_udpQ	    = new PCQueueFixedArray(10);
		m_handler   = new DatagramPacketHandler(m_server, m_udpQ);
	}
	
	/**
	 * The main method of the UDPHandler that reads the datagram packets
	 * from the 'udpQ'. A 'EventsReader' is created for each of the packets
	 * and queued to the listener queue from where the 'EventListener'
	 * thread pool picks it up and parses the input stream before
	 * closing the input stream in EventsReader
	 */
	public void run()
	{
		setOpStatus(STATUS_NORMAL);
		Log.print(Log.INFORMATIONAL, "Eventd ready to accept UDP packets");
		for (;;)
		{
			synchronized(this)
			{
				for(;;)
				{
					//
					// get the thread's status
					//
					int status = getOpStatus();
					
					//
					// check the child thread!
					//
					if(m_handler.isAlive() == false && (status & STATUS_TERMINATING) != STATUS_TERMINATING)
					{
						Log.print(Log.WARNING, "UDP Connection handler terminated abnormally");
						shutdown();
						continue;
					}
					
					//
					// do normal status checks now
					//
					if((status & STATUS_TERMINATING) == STATUS_TERMINATING)
					{
						setOpStatus(STATUS_SHUTDOWN);
						return;
					}
					else if((status & STATUS_PAUSING) == STATUS_PAUSING)
					{
						m_handler.pauseOperation();
						setOpStatus(STATUS_PAUSED);
					}
					else if((status & STATUS_RESUMING) == STATUS_RESUMING)
					{
						m_handler.resumeOperation();
						setOpStatus(STATUS_NORMAL);
					}
					else if((status & STATUS_PAUSED) == STATUS_PAUSED)
					{
						try
						{
							wait();
						}
						catch(InterruptedException e)
						{
							setOpStatus(STATUS_TERMINATING);
						}
					}
					else if((status & STATUS_NORMAL) == STATUS_NORMAL)
					{
						//
						// check the queue, if it is empty then
						// have it notify us when there is a 
						// connection to be processed
						//
						boolean doWait = false;
						synchronized(m_udpQ)
						{
							if(m_udpQ.isEmpty())
							{
								doWait = true;
								m_udpQ.oneShotNotifyAllOnAdd(this);
							}
						}
						
						//
						// have a connection
						//
						if(!doWait)
							break; // exit status checking loop
						
						//
						// no connnection so wait!
						//
						try
						{
							wait();
						}
						catch(InterruptedException ie)
						{
							setOpStatus(STATUS_TERMINATING);
						}
					}
				} // end for(;;)
			} // end sync

			//
			// to get here we must have had at least one
			// element on the queue, however another thread
			// could have nabbed it!
			//
			DatagramPacket dgp = null;
			try
			{
				synchronized(m_udpQ)
				{
					if(!m_udpQ.isEmpty())
						dgp = (DatagramPacket)m_udpQ.read();
				}
			}
			catch(InterruptedException iE)
			{
				dgp = null;
			}
			catch(QueueClosedException qE)
			{
				// ignore - not really possible to get here
				// since this is the  thread that will close
				// the queue
				dgp = null;
			}

			//
			// check the datagram
			//
			if (dgp == null)
				continue;

			Log.print(Log.DEBUG, "Data received  via UDP (" + ++numEventsRcvd + ")");

			try
			{
				/**
	 	 		 * Once the event(s) is(are) read, create a
	 	 		 * input stream of this to be parsed
	 	 		 */
				ByteArrayInputStream bis = new ByteArrayInputStream(dgp.getData(), 0, dgp.getLength());
				m_readerQ.add(new EventsReader(bis));
			}
			catch(InterruptedException iE)
			{
				Log.print(Log.WARNING, "UDPHandler: Event ignored: Unable to add event stream to event listener queue" + iE.getMessage());
			}
			catch(QueueClosedException qE)
			{
				Log.print(Log.WARNING, "UDPHandler: Event ignored: Unable to add event stream to event listener queue" + qE.getMessage());
			}
		} // end for(;;)
	} // end run()

	/**
	 * Start operation
	 */
	public void start()
	{
		m_handler.start();
		super.start();
	}

	/**
	 * <P>Initiates the shutdown sequence and  waits for 
	 * this thread to exit.</P>
	 *
	 * Close the datagram socket and the internal queue and shutdown
	 * the datagram packet reciever thread
	 */
	public synchronized void shutdown()
	{
		m_handler.shutdown();
		try
		{
			m_server.close();
		}
		catch(Exception e) { }
		m_udpQ.close();
		
		try
		{
			if(!Thread.currentThread().equals(m_handler))
				m_handler.join();
		}
		catch(InterruptedException ie)
		{
			Log.print(Log.WARNING, "Thread interrupted while waiting on connection handler to terminate");
			Log.print(Log.WARNING, ie);
		}
		
		super.shutdown();
	}
} 

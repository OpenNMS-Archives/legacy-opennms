//
// Copyright (C) 2000 N*Manage Company Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
// Tab Size = 8
//

package org.opennms.bb.dp.discovery.components;

import java.lang.*;
import java.net.*;
import java.util.*;
import java.io.*;

import com.sun.media.jsdt.*;

import org.opennms.protocols.icmpd.*;
import org.opennms.protocols.icmp.*;
import org.opennms.protocols.ip.*;
import org.opennms.bb.common.components.*;
import org.opennms.bb.dp.common.components.*;
import org.opennms.bb.dp.discovery.Discovery;

/**
 * <pre>The DiscPingManager is the thread responsible to send and receive
 * the PING requests to discover nodes
 *
 * It maintains a pool of DiscPingerThreads to send out the PING requests. 
 * These threads read off the m_pingRequestQ to which the IPGenerator queues 
 * node and send out the requests to the icmpd
 *
 * It also has a DiscPingReplyReceiver thread that recieves all the filtered
 * replies from the icmpd and queues it back to the main thread. Once a reply
 * is received, the manager notifies the DiscPinger thread that was in charge 
 * of sending out the request for which the reply has been received so
 * that it stops any retries that might be pending and starts on the next 
 * address
 *
 * Once a reply has been received, the capsd is informed about the new node
 * found
 *
 * @author Sowmya
 */
public final class DiscPingManager extends PollerThread
{
	/**
	 * queue to which IPGenerator adds the next address to ping
	 */
	private PCQueue			m_requestQ;

	/**
	 * queue to which MonitorRequestReceiver adds the next address to ping
	 */
	private PCQueue			m_monitorRequestQ;

	/**
	 * queue to which DiscReplyReceiver adds the address whose ping
	 * reply was received
	 */
	private PCQueue			m_replyQ;

	/**
	 * thread pool 
	 */
	private List			m_pollers;

	/**
	 * ping receiver thread
	 */
	private DiscPingReplyReceiver 	m_receiver;
	
	/**
	 * Filter to be used for communication with icmpd
	 */
	private short			m_filterID;

	/**
	 * JSDT client identifier of this thread
	 */
	private PollerClient 		m_client;

	/**
	 * JSDT session in which discovery and capsd communicate
	 */
	private Session			m_session;

	/**
	 * JSDT channel that capsd is listening on
	 */
	private Channel			m_channel;
	
	/**
	 * icmpd portal
	 */
	private DaemonConnection 	m_portal;
	
	/*******************************************************************/ 
	/* JSDT related variables for Discover-ICMP Service Monitor Bridge */
	/*******************************************************************/
	private Session			m_monitorSession;
	private Channel			m_monitorReplyChannel;
	private PollerClient	m_monitorReplyClient;

	/**
	 * MonitorPinger thread pool 
	 */
	private List			m_monitorPollers;

	/**
	 * Max number of MonitorPinger threads to create.
	 */
	private int				m_maxNumMonitorThreads;
	/** 
	 * True if the monitor thread pool has already been created
	 * and the MonitorPinger threads started.  False otherwise.
	 */
	private boolean			bMonitorThreadPoolCreated;

	/**
	 * the initial number of monitor pinger threads
	 */
	private static int	INIT_NUM_MONITOR_POLLERS=5; 

	/**
	 * Base thread id for the monitor pinger threads...this
	 * value distinguishes a thread in the monitor pool from
	 * a thread in the discovery pool.  This was necessary
	 * because we weren't able to distinguish between the
	 * two thread pools based on filter ID.
	 */
	private static final long BASE_MONITOR_THREADID = 500;

	/**
	 * Extends the PollerClient class to allow
	 * the string constructor to be called.
	 */
	private class ManagerClient extends PollerClient
	{
		/**
		 * <P>Class constructor that sets the base class'
		 * clientName.</P>
		 *
		 * @param name	The name of the JSDT client.
		 */
		public ManagerClient(String name)
		{
			super(name);
		}
	}
	
	/**
	 * <P>This static class is used to build an compliant SOAP document
	 * that is sent to the capabilities daemon. No instances of this
	 * class may be created.</P>
	 */
	private static final class AddressToSoapDocument
	{
		/**
		 * SOAP Envelope tag, fully qualified
		 */
		private static final String SOAP_ENV	= "SOAP-ENV:Envelope";
		
		/**
		 * SOAP Body tag, fully qualified.
		 */
		private static final String SOAP_BODY	= "SOAP-ENV:Body";
		
		/**
		 * SOAP Namespace string
		 */
		private static final String SOAP_NS	= "http://schemas.xmlsoap.org/soap/envelope/";
		
		/**
		 * SOAP Namespace tag.
		 */
		private static final String SOAP_NSTAG	= "SOAP-ENV";
		
		/**
		 * Document new address tag.
		 */
		private static final String NEWADDR	= "Discovery:NewAddress";
		
		/**
		 * Document IPv4 Address tag.
		 */
		private static final String IPV4ADDR	= "Discovery:IPv4Address";
		
		/**
		 * Document namespace
		 */
		private static final String DISC_NS	= "http://dtds.opennms.org/bluebird/discovery/newaddress/";
		
		/**
		 * Document namespace tag.
		 */
		private static final String DISC_NSTAG	= "Discovery";
		
		/**
		 * Creates a proper XML start tag.
		 *
		 * @param tag	The tag name
		 * @param out	The output stream.
		 */
		private static void startTag(String tag, PrintStream out)
		{
			out.println("<" + tag + ">");
		}
		
		/**
		 * Creates a proper XML start tag with namespace
		 *
		 * @param tag	The tag name
		 * @param ns	The namespace uri
		 * @param nstag	The namespace tag for the uri
		 * @param out	The output stream.
		 */
		private static void startTag(String tag, String ns, String nstag, PrintStream out)
		{
			out.println("<" + tag + " xmlns:" + nstag + "=\"" + ns + "\">");
		}
		
		/**
		 * Creates a proper XML end tag.
		 *
		 * @param tag	The tag name
		 * @param out	The output stream.
		 */
		private static void endTag(String tag, PrintStream out)
		{
			out.println("</" + tag + ">");
		}
		
		/**
		 * <P>Generates a properly formatted XML SOAP document
		 * that is sutiable for advertising the discovered
		 * node.</P>
		 *
		 * @param addr	The IPv4Address for the document.
		 *
		 * @return The document as a byte array.
		 */
		public static byte[] generate(IPv4Address addr)
		{
			ByteArrayOutputStream bout = new ByteArrayOutputStream();
			PrintStream prn = new PrintStream(bout);
			
			//startTag("?xml version=\"1.0\"?", prn);
			startTag(SOAP_ENV, SOAP_NS, SOAP_NSTAG, prn);
			startTag(SOAP_BODY, prn);
			startTag(NEWADDR, DISC_NS, DISC_NSTAG, prn);
			startTag(IPV4ADDR, prn);
			prn.println(addr.toString());
			endTag(IPV4ADDR, prn);
			endTag(NEWADDR, prn);
			endTag(SOAP_BODY, prn);
			endTag(SOAP_ENV, prn);
			prn.flush();
			
			return bout.toByteArray();
		}
	}	
	
	/**
	 * <P>Creates a connection to the JSDT registry and
	 * also creates the session for sending updates
	 * about discovered nodes.</P>
	 *
	 * @param name	The name of the new client.
	 *
	 * @return True if the connection is created, false otherwise.
	 *
	 * @exception java.lang.InterruptedException Thrown if the thread
	 * 	is interrupted while attempting to setup the jsdt connection.
	 *
	 */
	private boolean jsdtConnect(String name)
		throws InterruptedException
	{
		boolean sessionExists = false;
		boolean isConnected = false;

		try
		{
 			URLString url = URLString.createSessionURL(PollerSession.hostName,
								   PollerSession.discCapsdPort,
								   PollerSession.sessionType, 
								   PollerSession.discToCapsdSessionName);

			while(!sessionExists)
			{
				try 
				{
					if (SessionFactory.sessionExists(url)) 
					{
                            			sessionExists = true;
					}
				} 
				catch (NoRegistryException nre) 
				{
					Thread.sleep(1000);
				} 
				catch (ConnectionException ce) 
				{
					Thread.sleep(1000);
				}
			} 

	        m_client  = new ManagerClient(name);
			m_session = SessionFactory.createSession(m_client, url, true);
			m_channel = m_session.createChannel(m_client, 
							    PollerSession.discToCapsdChannelName,
							    true, 
							    false, 
							    true);

			isConnected = true;
		} 
		catch (JSDTException e)
		{
			isConnected = false;
			Log.print(Log.ERROR, e.getMessage());
		}

		return isConnected;
	}

	/**
	 * <P>Creates a connection to the JSDT registry and
	 * also creates the session/channel through which the
	 * MonitorPinger threads will send poll results to the 
	 * ICMP service monitor.</P>
	 *
	 * @param name	The name of the new client.
	 *
	 * @return True if the connection is created, false otherwise.
	 *
	 * @exception java.lang.InterruptedException Thrown if the thread
	 * 	is interrupted while attempting to setup the jsdt connection.
	 *
	 */
	private boolean jsdtConnectMonitor(String name)
		throws InterruptedException
	{
		boolean sessionExists = false;
		boolean isConnected = false;

		try
		{
 			URLString url = URLString.createSessionURL(PollerSession.hostName,
								   PollerSession.monitorPort,
								   PollerSession.sessionType, 
								   PollerSession.monitorSessionName);

			while(!sessionExists)
			{
				try 
				{
					if (SessionFactory.sessionExists(url)) 
					{
                            			sessionExists = true;
					}
				} 
				catch (NoRegistryException nre) 
				{
					Thread.sleep(1000);
				} 
				catch (ConnectionException ce) 
				{
					Thread.sleep(1000);
				}
			} 

	       	m_monitorReplyClient  = new PollerClient(name);
			m_monitorSession = SessionFactory.createSession(m_monitorReplyClient, url, true);
			m_monitorReplyChannel = m_monitorSession.createChannel(m_monitorReplyClient, 
							    PollerSession.monitorReplyChannelName,
							    true, 
							    false, 
							    true);

			isConnected = true;
		} 
		catch (JSDTException e)
		{
			isConnected = false;
			Log.print(Log.ERROR, e.getMessage());
		}

		return isConnected;
	}

	/**
	 * After each read from the monitorRequestQ, the threads in the monitor 
	 * thread pool call this method to adjust the number of threads in the 
	 * pool if necessary
	 *
	 * If the number of entries in the queue is more than double the
	 * number of threads, the number of threads is increased by one
	 * until the configurable maximum number of threads is reached
	 *
	 */
	protected synchronized void threadsVsQueueSizeCheck()
	{
		int curNumThreads = m_monitorPollers.size();

		int numQEntries = m_monitorRequestQ.entries();

		Log.print(Log.DEBUG, "DiscPingManager.threadsVsQueueSizeCheck(): current thread count: " + curNumThreads);
		Log.print(Log.DEBUG, "DiscPingManager.threadsVsQueueSizeCheck(): current num entries in actionQ: " + numQEntries);

		if ( (curNumThreads < m_maxNumMonitorThreads)  &&
		     ((numQEntries / curNumThreads) > 2) )
		{
			// increase by 1!
			Log.print(Log.DEBUG, "DiscPingManager.threadsVsQueueSizeCheck(): Increasing launcher thread pool by 1, new size: " + (curNumThreads+1));
		
			MonitorPinger pinger = new MonitorPinger(this, (curNumThreads)+BASE_MONITOR_THREADID, m_monitorRequestQ, m_portal, m_filterID);
			if (pinger != null)
			{	
				synchronized(m_monitorPollers)
				{
					m_monitorPollers.add(pinger);
				}

				// Start the new thread so it can do work
				pinger.start();
			}
		}
	}

	/**
	 * <P>Find the thread that was assigned to send ping packets for this
	 * IP Address.</P>
	 *
	 * @param threadID	the id of the thread to find
	 *
	 */
	private DiscPinger getPingSender(long threadID)
	{
		Iterator iter = m_pollers.iterator();
		while(iter.hasNext())
		{
			DiscPinger pt = (DiscPinger)iter.next();
			if(pt.getThreadID() == threadID)
				return pt;
		}
		return null;
	}

	/**
	 * <P>Find the MonitorPinger thread that was assigned to send ping 
	 * packets for this IP Address.</P>
	 *
	 * @param threadID	the id of the thread to find
	 *
	 */
	private MonitorPinger getMonitorPingSender(long threadID)
	{
		Iterator iter = m_monitorPollers.iterator();
		while(iter.hasNext())
		{
			MonitorPinger pt = (MonitorPinger)iter.next();
			if(pt.getThreadID() == threadID)
				return pt;
		}
		return null;
	}

	/**
	 * <P>The ping manager's constructor is used to initialize
	 * the connection to the icmpd, open the jsdt connections,
	 * and startup the pinger thread pool. In addition is also
	 * starts the icmp receiver thread for discovery and prepares
	 * the thread for prime time.</P>
	 *
	 * @param port		The port for the icmpd connection
	 * @param nThreads	The number of poller threads to create
	 * @param nPktsPerSec	The limiter number for sending icmp messages.
	 * @param PCQueue	The input icmp request queue to be managed.
     * @param nThreads	The maximum number of monitor poller threads to create
	 * @param PCQueue	A 2nd icmp request Q for incoming ICMP Service Monitor requests
	 *
	 * @exception java.io.IOException	Thrown if an error occurs with
	 *	the icmpd connection.
	 * @exception java.lang.RuntimeException Thrown if an error occurs setting
	 * 	up threads or the JSDT collaboritive environment.
	 *
	 */
	public DiscPingManager(int port, long nThreads, long nPktsPerSec, PCQueue requestQ, int maxMonitorThreads, PCQueue monitorRequestQ)
				throws IOException
	{
		// Initialize with info. passed in
		m_requestQ = requestQ;
		m_monitorRequestQ = monitorRequestQ;
		m_maxNumMonitorThreads = maxMonitorThreads;

		m_client  = null;
		m_session = null;
		m_channel = null;

		bMonitorThreadPoolCreated = false;

		/*
		 * create/connect to JSDT communication m_channel for
		 *  communication with capsd
		 */
		try
		{
			if(!jsdtConnect("DiscSend"))
			{
				Log.print(Log.FATAL, "Unable to create JSDT communication with capsd");
				throw new RuntimeException("Unable to initialize JSDT connections");
			}
		}
		catch(InterruptedException e)
		{
			Log.print(Log.FATAL, "The jsdt connection thread was interrupted");
			throw new RuntimeException("Unable to initialize JSDT connections");
		}
		
		m_monitorSession = null;
		m_monitorReplyClient = null;
		m_monitorReplyChannel = null;

		/*
		 * create/connect to JSDT communication m_monitor ReplyChannel for
		 * communication with ICMP service monitor.  MonitorPinger threads
		 * will access a static reference to the channel and client through 
		 * which they can send ICMP poll results to the ICMP service monitor.
		 */
		try
		{
			if(!jsdtConnectMonitor("MonitorReplySend"))
			{
				Log.print(Log.FATAL, "Unable to create JSDT communication with ICMP Service Monitor");
				throw new RuntimeException("Unable to initialize JSDT connections");
			}
		}
		catch(InterruptedException e)
		{
			Log.print(Log.FATAL, "The jsdt connection thread was interrupted for client: " + "MonitorReplySend");
			throw new RuntimeException("Unable to initialize JSDT connections");
		}

		//
		// Create the daemon connection
		//
		m_filterID = (short)((new Random((new Date()).getTime())).nextInt());
		Log.print(Log.INFORMATIONAL, "Discovery filter id: " + (short)m_filterID);
		
		//
		// Unfortunately it does not appear that icmpd supports passing multiple 
		// PASS filters for the same offset.  Well, actually it supports it but both
		// filters will be checked against incoming ICMP replies and one of them will
		// always not match and the response will be discarded by icmpd.
		//
		//m_monitorFilterID = (short)(m_filterID + 1);

		m_portal = null;
		if (port == -1)
			m_portal = new DaemonConnection(); // throws IOException
		else
			m_portal = new DaemonConnection(port); // throws IOException

		//
		// Setup  filters
		//
		byte[] filterOne = new byte[1];
		filterOne[0] = ICMPHeader.TYPE_ECHO_REPLY;

		// DiscPinger filter ID
		byte[] filterTwo = new byte[2];
		filterTwo[0] = (byte)(m_filterID >>> 8);
		filterTwo[1] = (byte)(m_filterID & 0xff);

		//
		// Create the filter messages
		//
		CtrlFilterMessage fone = new CtrlFilterMessage(CtrlFilterMessage.FILTER_ON_ICMP,
				       			       CtrlFilterMessage.ACTION_PASS,
							       0,
							       filterOne);

		CtrlFilterMessage ftwo = new CtrlFilterMessage(CtrlFilterMessage.FILTER_ON_ICMP,
				       			       CtrlFilterMessage.ACTION_PASS,
				       			       4,
				       			       filterTwo);

		//
		// Install the filters
		//
		m_portal.sendMessage(fone);
		Log.print(Log.INFORMATIONAL, "Pushed first filter onto channel");
		if(getOkResponse(m_portal))
		{
			Log.print(Log.INFORMATIONAL, "Filter push O.K.");
			
			m_portal.sendMessage(ftwo);
			Log.print(Log.INFORMATIONAL, "Pushed second filter onto channel");
			
			if (getOkResponse(m_portal))
				Log.print(Log.INFORMATIONAL, "Filter push O.K.");
			else 
			{
			Log.print(Log.FATAL, "Filter push failed");
			throw new RuntimeException("failed to set filter in icmpd");
			}
		}
		else
		{
			Log.print(Log.FATAL, "Filter push failed");
			throw new RuntimeException("failed to set filter in icmpd");
		}
		
		//
		// help out garbage collection
		//
		fone = null;
		ftwo = null;

		Log.print(Log.INFORMATIONAL, "received filter responses");

		//
		// Create the m_pingReplyQ and the receiver thread
		//
		m_replyQ    = new PCQueueLinkedList();
		m_receiver  = new DiscPingReplyReceiver(m_portal, m_replyQ, this);
		m_receiver.start();

		//
		// "resume" to indicate that the receiver is ready to receive
		// responses
		//
		m_portal.sendMessage(new CtrlResumeMessage());

		//
		// Create the packet limiter
		//
		QuantumSemaphore pktLimiter = new QuantumSemaphore(nPktsPerSec, 1000);

		// 
		// Create the pinger thread pool 
		//
		m_pollers = new ArrayList((int)nThreads);
		for(long i = 0; i < nThreads; i++)
		{
			DiscPinger pinger = new DiscPinger(i, m_requestQ, m_portal, m_filterID, pktLimiter);
			if (pinger != null)
				m_pollers.add(pinger);
		}

		//
		// Create an empty monitor poller thread pool
		// The pool's threads will be created and started after the first ICMP poll
		// request is received from the ICMP service monitor.
		// 
		m_monitorPollers = Collections.synchronizedList(new ArrayList(m_maxNumMonitorThreads)); 

		Log.print(Log.INFORMATIONAL, "Created QuantumSemaphore and the discovery thread pool");
	}
		
	/**
	 * <P>Get's the response message from the icmp daemon
	 * and checks it for a zero return code. If an I/O
	 * error occurs then an exception is thrown. The value
	 * of the boolean return indicates the success or failure
	 * of the last message</P>
	 *
	 * @param dc	The connection to the icmp daemon
	 *
	 * @return A value of true is returned if no error occured.
	 *	A false value indicates that an error occured with
	 * 	the last control message.
	 *
	 * @exception java.io.IOException Thrown if there is an error
	 *	communicating with the icmpd.
	 */
	public boolean getOkResponse(DaemonConnection dc) 
						throws IOException
	{
		boolean bResponseOK = false;
		try
		{
			MessageHeader hdr = m_portal.recvMessage();
			if(hdr instanceof CtrlResponseMessage)
			{
				CtrlResponseMessage response = (CtrlResponseMessage)hdr;

				if(response.getErrorCode() == 0)
				{
					bResponseOK = true;
				}
			}
			else
			{
				throw new IOException("Unknown response to discovery filters");
			}
		}
		catch(IOException e0)
		{
			Log.print(Log.ERROR, "error in filter response: " + e0.getMessage());
			throw e0;
		}

		return bResponseOK;
	}
	
	/**
	 * Wait for a notify() - the thread is notified if there is a status
	 * change  or by the DiscReplyReciever thread if a reply has been
	 * received for any ping request
	 * 
	 * Everytime it is interrupted from a wait, it checks for a status
	 * change - if there is a status change, appropriate action is taken
	 * if the status is normal, it means a reply has been
	 * received, it reads from the recieve Q, informs the pinger thread 
	 * that sent the request out, informs capsd and goes back to waiting
	 *
	 */
	public void run()
	{
		//
		// Start each of the poller threads
		//
		synchronized(this)
		{
			// DiscPinger thread pool
			Iterator iter = m_pollers.iterator();
			while(iter.hasNext())
			{
				DiscPinger pt = (DiscPinger)iter.next();
				pt.start();
			}

			setOpStatus(STATUS_NORMAL);	
		}

		for(;;)
		{
			synchronized(this)
			{
				for(;;)
				{
					try
					{
						wait();
					}
					catch(InterruptedException e) {	}

					// Check if there was a status change
					int status = getOpStatus();
					if((status & STATUS_TERMINATING) == STATUS_TERMINATING)
					{
						try
						{
							Iterator iter;
							// Shutdown DiscPinger thread pool
							iter = m_pollers.iterator();
							while(iter.hasNext())
								shutdownThread((PollerThread)iter.next());

							// Shutdown MonitorPinger thread pool
							iter = m_monitorPollers.iterator();
							while(iter.hasNext())
								shutdownThread((PollerThread)iter.next());
							
							shutdownThread(m_receiver);

							m_portal.sendMessage(new CtrlCloseMessage());
							m_portal.close();

							m_replyQ.close();
						}
						catch(InterruptedException e)
						{
							// do nothing							
						}
						catch(IOException e)
						{
							// do nothing
						}
						
						
						setOpStatus(STATUS_SHUTDOWN);
						return;
					}
					else if((status & STATUS_PAUSING) == STATUS_PAUSING)
					{
						//
						// be a bit more patient here and make
						// sure they pause
						//
						boolean setPaused = true;
						 
						// Pause DiscPinger thread pool
						for(int i = 0; i < m_pollers.size(); i++)
						{
							try
							{
								DiscPinger pt = (DiscPinger)m_pollers.get(i);
								pauseThread(pt);
							}
							catch(IllegalThreadStateException e)
							{
								setPaused = false;
								setOpStatus(STATUS_TERMINATING);
								break;
							}
							catch(InterruptedException e)
							{
								setPaused = false;
								setOpStatus(STATUS_TERMINATING);
								break;
							}
						}
						
						// Pause MonitorPinger thread pool
						for(int i = 0; i < m_monitorPollers.size(); i++)
						{
							try
							{
								MonitorPinger pt = (MonitorPinger)m_monitorPollers.get(i);
								pauseThread(pt);
							}
							catch(IllegalThreadStateException e)
							{
								setPaused = false;
								setOpStatus(STATUS_TERMINATING);
								break;
							}
							catch(InterruptedException e)
							{
								setPaused = false;
								setOpStatus(STATUS_TERMINATING);
								break;
							}
						}
						//
						// All the threads are paused so 
						// now stop the receiver
						//
						try
						{
							pauseThread(m_receiver);
						}
						catch(IllegalThreadStateException e)
						{
							setPaused = false;
							setOpStatus(STATUS_TERMINATING);
						}
						catch(InterruptedException e)
						{
							setPaused = false;
							setOpStatus(STATUS_TERMINATING);
						}

						if(setPaused)
							setOpStatus(STATUS_PAUSED);

					}
					else if((status & STATUS_RESUMING) == STATUS_RESUMING)
					{

						boolean setNormal = true;
						
						try
						{
							resumeThread(m_receiver);
						}
						catch(IllegalThreadStateException e)
						{
							setNormal = false;
							setOpStatus(STATUS_TERMINATING);
						}
						catch(InterruptedException e)
						{
							setNormal = false;
							setOpStatus(STATUS_TERMINATING);
						}
						
						// Resume the DiscPinger thread pool
						for(int i = 0; setNormal = true && i < m_pollers.size(); i++)
						{
							try
							{
								DiscPinger pt = (DiscPinger)m_pollers.get(i);
								resumeThread(pt);
							}
							catch(IllegalThreadStateException e)
							{
								setNormal = false;
								setOpStatus(STATUS_TERMINATING);
								break;
							}
							catch(InterruptedException e)
							{
								setNormal = false;
								setOpStatus(STATUS_TERMINATING);
								break;
							}
						}

						// Resume the MonitorPinger thread pool
						for(int i = 0; setNormal = true && i < m_monitorPollers.size(); i++)
						{
							try
							{
								MonitorPinger pt = (MonitorPinger)m_monitorPollers.get(i);
								resumeThread(pt);
							}
							catch(IllegalThreadStateException e)
							{
								setNormal = false;
								setOpStatus(STATUS_TERMINATING);
								break;
							}
							catch(InterruptedException e)
							{
								setNormal = false;
								setOpStatus(STATUS_TERMINATING);
								break;
							}
						}

						if(setNormal)
							setOpStatus(STATUS_NORMAL);

					}
					else if((status & STATUS_PAUSED) == STATUS_PAUSED)
					{
						try
						{
							wait();
						}
						catch(InterruptedException e)
						{
							setOpStatus(STATUS_TERMINATING);
						}
					}
					else if((status & STATUS_NORMAL) == STATUS_NORMAL)
					{
						break; // exit status checking loop
					}
				} // end for(;;) status check
			} // end synchronization 
		
			//
			// If the MonitorPinger thread pool has not yet been started
			// lets see if there are any monitor poll requests on the Q.
			//
			if (!bMonitorThreadPoolCreated)
			{
				if (m_monitorRequestQ.entries() > 0)
				{
					// 
					// Create the Monitor Pinger thread pool 
					//
					MonitorPinger.setChannel(m_monitorReplyChannel); // Set static reference to the reply channel
					MonitorPinger.setClient(m_monitorReplyClient);   // Set static reference to the JSDT client

					//
					// Adjust initial monitor poller thread count base on configured max
					//
					if (m_maxNumMonitorThreads < INIT_NUM_MONITOR_POLLERS)
						INIT_NUM_MONITOR_POLLERS = m_maxNumMonitorThreads;
						
					for(long i = 0; i < INIT_NUM_MONITOR_POLLERS; i++)
					{
						MonitorPinger pinger = new MonitorPinger(this, i+BASE_MONITOR_THREADID, m_monitorRequestQ, m_portal, m_filterID);
						if (pinger != null)
						{
							m_monitorPollers.add(pinger);
							pinger.start();
						}
					}	

					Log.print(Log.DEBUG, "DiscPingManager.run: monitor thread pool created.");
				}
			}	

			/*
		 	 * If status is normal, check out if there are any responses
		 	 */
			if (m_replyQ.entries() > 0)
			{
				try
				{
					DataRecvMessage pollReply = (DataRecvMessage)m_replyQ.read();
					if(pollReply != null)
					{
						
						//
						// Figure out from which thread pool this request was sent
						//
						DiscPingPacket pingRep  = new DiscPingPacket(pollReply.getICMPData());
						
						// Wanted to determine the thread pool based on the filter ID but
						// can't do that because icmpd does not support multiple filters for the
						// same offset.  So we'll try it based on thread id...
						//if (pingRep.getIdentity() == m_filterID)
						long threadID = pingRep.getTID();
						if (threadID < BASE_MONITOR_THREADID)
						{
							//
							// Find the thread that sent this request out
							//
							DiscPinger sender = getPingSender(threadID);
							if(sender != null)
							{
								//
								// Notify thread that sent out the request
								//
								IPHeader  ip = new IPHeader(pollReply.getIPHeader(), 0);
								IPv4Address replyRecdFor = new IPv4Address(ip.getSourceAddress());
	
								if(sender != null && sender.received(replyRecdFor.toString()))
								{
									// Send it to capsd
									Data data = new Data(AddressToSoapDocument.generate(replyRecdFor));
									m_channel.sendToOthers(m_client, data);
								}
							}
						}
						else
						{
							//
							// Find the Monitor Pinger thread that sent this request out
							//
							MonitorPinger sender = getMonitorPingSender(threadID);
							if(sender != null)
							{
								//
								// Notify thread that sent out the request
								//
								IPHeader  ip = new IPHeader(pollReply.getIPHeader(), 0);
								IPv4Address replyRecdFor = new IPv4Address(ip.getSourceAddress());
								sender.received(replyRecdFor.toString());
							}
						}
					}
				}
				catch(QueueClosedException e)
				{
					setOpStatus(STATUS_TERMINATING);
					break;
				}
				catch(InterruptedException e) 
				{ 
					setOpStatus(STATUS_TERMINATING);
					break; 
				}
				catch(JSDTException e)
				{
					setOpStatus(STATUS_TERMINATING);
					break;
				}
			}
		}
	}
	
	/**
	 * <P>Initiates the shutdown sequence and 
	 * waits for the ping manager thread to
	 * exit.</P>
	 *
	 */
	public synchronized void shutdown()
	{
		try
		{
			super.shutdown();
			if(Thread.currentThread().equals(this) == false)
				join();
		}
		catch(Exception e) 
		{ 
			// do nothing
		}
	}
}

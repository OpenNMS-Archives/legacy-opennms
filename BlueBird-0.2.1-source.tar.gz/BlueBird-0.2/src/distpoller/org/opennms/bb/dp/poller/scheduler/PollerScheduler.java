//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.dp.poller.scheduler;

import java.util.*;
import java.io.*;
import java.sql.*;

import org.opennms.bb.dp.discovery.utils.DiscPollersParser;

import org.opennms.bb.dp.poller.plugins.PollerTask;
import org.opennms.bb.dp.poller.plugins.PluginLoader;
import org.opennms.bb.dp.poller.plugins.PluginLoader.Plugin;
import org.opennms.bb.dp.poller.plugins.ServiceMonitor;
import org.opennms.bb.dp.poller.plugins.ServiceMonitorException;

import org.opennms.bb.dp.poller.parsers.PackageParser;
import org.opennms.bb.dp.poller.parsers.ModelsParser;
import org.opennms.bb.dp.poller.scheduler.SchedulerConstants;
import org.opennms.bb.dp.poller.scheduler.utils.PollerPackage;
import org.opennms.bb.dp.poller.scheduler.utils.PollerInterface;
import org.opennms.bb.dp.poller.scheduler.utils.PollerModel;
import org.opennms.bb.dp.poller.scheduler.utils.ModelInterval;
import org.opennms.bb.dp.poller.scheduler.utils.IntervalScheduler;
import org.opennms.bb.dp.poller.scheduler.utils.ServiceInfo;

import org.opennms.bb.common.filter.util.BBIPAddress;
import org.opennms.bb.common.db.DBOpenFailureException;
import org.opennms.bb.common.components.Log;
import org.opennms.bb.common.components.PCQueue;
import org.opennms.bb.common.components.PCQueueLinkedList;

import org.opennms.bb.dp.common.components.RunnableConsumerThread;

import org.opennms.protocols.ip.IPv4Address;

/**This class is responsible for reading the information from
 * the poller.xml and the packages.xml in order to schedule and
 * run the service monitors for all interfaces dictated by the
 * package information for the poller.
 *
 * @author <A HREF="mailto:jason@opennms.org">Jason Johns</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version $Revision: 1.7 $
 * 
 */
public class PollerScheduler
{
	/**The parser responsible for getting the poller information from poller.xml
	*/
	private DiscPollersParser m_pollerParser;
	
	/**The parser responsible for getting the package information
	*/
	private PackageParser m_packageParser;
	
	/**The parser responsible for getting the model information
	*/
	private ModelsParser m_modelParser;
	
	/**A list of services this scheduler should look for and schedule
	*/
	private String m_activeService;
	
	/**A list of full package information for all packages belonging with this poller
	*/
	private List m_packageList;
	
	/**A list of full model information for all packages
	*/
	private Map m_modelMap;
	
	/**A list of interface lists that need to be scheduled
	*/
	private List m_packageInterfaces;
	
	/**Queue holding NetworkInterface runnables that have been scheduled
	*/
	private PCQueue m_inQueue;
	
	/**Queue holding NetworkInterfaces that have completeted polling
	*/
	private PCQueue m_outQueue;
	
	/**A list of consumer threads that process the m_inQueue
	*/
	private List m_consumerThreadPool;
	
	/**A final list of the interfaces to schedule
	*/
	private Map m_scheduleMaster;
	
	/**
	*/
	private ServiceMonitor m_serviceMonitor;
	
	/**A blooean indicating that the scheduler should shutdown
	*/
	private boolean m_doneScheduling;
	
	/**
	*/
	private List m_interfaceErrorList;
	
	/**The initial size of the consumer thread pool
	*/
	private static final int INITIAL_POOL_SIZE = 10;
	
	/**Constructor, intializes the queues and thread pool, parses the
	   poller.xml and package.xml and builds the list of interfaces ready
	   to be scheduled.
	   @param String anIpAddr, the ip address of the poller
	   @param List aServiceList, the list of services that should be scheduled
	*/
	public PollerScheduler(String anIpAddr, String aService)
           throws IOException
	{
		m_activeService = aService;
		m_interfaceErrorList = new ArrayList();
		
		m_inQueue = new PCQueueLinkedList();
		m_outQueue = new PCQueueLinkedList();
		
		m_consumerThreadPool = new ArrayList(INITIAL_POOL_SIZE);
		
		m_doneScheduling = false;
		
		//get information on the poller
		m_pollerParser = new DiscPollersParser(BBIPAddress.getIpAsInteger(anIpAddr));
		//m_pollerParser.parse(SchedulerConstants.POLLER_XML);
		m_pollerParser.parse("../bluebird/distpoller/org/opennms/bb/dp/poller/test/testPollers.xml");
		System.out.println("Scheduling poller " + anIpAddr);
		
                //get information on the packages in the poller
		m_packageParser = new PackageParser(m_pollerParser.getPackages());
		//m_packageParser.parse(SchedulerConstants.PACKAGE_XML);
		m_packageParser.parse("../bluebird/distpoller/org/opennms/bb/dp/poller/test/testPackages.xml");
		m_packageList = m_packageParser.getPackages();
		System.out.println("packages: " + m_pollerParser.getPackages());
		
		//get the model information for unavaliable scheduling
		m_modelParser = new ModelsParser(m_packageParser.getModelNames());
		//m_modelParser.parse(SchedulerConstants.MODELS_XML);
		m_modelParser.parse("../bluebird/distpoller/org/opennms/bb/dp/poller/test/testModels.xml");
		m_modelMap = m_modelParser.getModelsAsMap();
		
		//assign the models to the services in each package
		assignModelsToPackages(m_modelMap, m_packageList, m_activeService);
		
		//System.out.println(m_packageList);
		
		//figure out what interfaces we need to schedule
		m_packageInterfaces = getInterfacesToSchedule(m_packageList, m_activeService);
		
		//load the service plugins
		PluginLoader loader = new PluginLoader();
		loader.loadFromJar("/home/jason/bluebird/distpoller/org/opennms/bb/dp/poller/plugins/ServiceMonitors/");
		m_serviceMonitor = loader.retrieveServiceMonitor(m_activeService);
		
		//initialize the monitor
		try
		{
			m_serviceMonitor.initialize(null, null);
		}
		catch(ServiceMonitorException e)
		{
			System.out.println(e);
		}
		
		//Log.print(Log.DEBUG, m_packageInterfaces);
	}
	
	/**
	*/
	private void assignModelsToPackages(Map aModelMap, List aPackageList, String aServiceName)
	{
		PollerPackage curPackage = null;
		ServiceInfo serviceInfo = null;
	
		for (int i = 0; i < aPackageList.size(); i++)
		{
			curPackage = (PollerPackage)aPackageList.get(i);
			
			serviceInfo = curPackage.getService(aServiceName);
			
			serviceInfo.setModel( (PollerModel)aModelMap.get(serviceInfo.getModelName()));
		}
	}
	
	/**
	*/
	private Map buildServiceMaster(String aService, List aPackageInterfacesList, ServiceMonitor aMonitor)
	{
		Map newMaster = new HashMap();
		
		PollerTask newTask = null;
		PollerInterface curInterface = null;
		
		Map interfaceMap = null;
		Map newServiceMap = null;
		
		for (int i = 0; i < aPackageInterfacesList.size(); i++)
		{
			interfaceMap = (Map)aPackageInterfacesList.get(i);
			
			Iterator iter = interfaceMap.keySet().iterator();
			
			while(iter.hasNext())
			{
				newServiceMap = new HashMap();
			
				curInterface = (PollerInterface)interfaceMap.get(iter.next());
			
				//choose the uptime information, get the last known status of this service
				Integer interval = curInterface.getNewInterval(aService, 
									       curInterface.getServiceLastKnownStatus(aService));
			
				//NEED TO GET THE PARAMETER INFORMATION
				newTask = new PollerTask(aMonitor, new IPv4Address(curInterface.getAddress()), null, null);
				newTask.setPackageIndex(i);
				newTask.setCurrentInterval(interval.intValue());
				
				updateSchedule(newMaster, interval, newTask);
			}
		}
		
		return newMaster;
	}
	
	/**
	*/
	public void updateSchedule(Map aSchedule, Integer anInterval, PollerTask aTask)
	{
		IntervalScheduler scheduler = null;
		
		//if there isn't a scheduler for this interval yet
		if (!aSchedule.containsKey(anInterval.toString()))
		{
			//build a new scheduler, add the task to it, add the scheduler to the master list
			scheduler = new IntervalScheduler(anInterval.intValue(), m_inQueue);
			scheduler.addPollerTask(aTask);
					
			aSchedule.put(anInterval.toString(), scheduler);
			scheduler.start();
		}
		else
		{
			//get the scheduler for this interval, add the task to it
			scheduler = (IntervalScheduler)aSchedule.get(anInterval.toString());
			scheduler.addPollerTask(aTask);
		}
	}
	
	/**This method builds the NetworkInterface runnables and places them
	   on the m_inQueue. The consumer threads process the runnables and
	   place them onto m_outQueue where they are removed and evaluated
	   for status and rescheduled accordingly.
	*/
	public void start()
	{
		//initialize the consumer thread pool with new threads
		for (int i = 0; i < INITIAL_POOL_SIZE; i++)
		{
			RunnableConsumerThread thread = new RunnableConsumerThread(m_inQueue, m_outQueue);
			m_consumerThreadPool.add(thread);
			thread.start();
		}
		
		//this list (m_scheduleMaster) holds the timer tasks that will get scheduled
		m_scheduleMaster = buildServiceMaster(m_activeService, m_packageInterfaces, m_serviceMonitor);
		
		PollerTask processedTask = null;
		Object objAddress = null;
		String address = null;
		PollerInterface curInterface = null;
		Map interfacesMap = null;
		int status;
		int index;
		
		//this code should probably be in a runnable consumer thread
		while(!m_doneScheduling)
		{
			//check the jsdt stream to see if there are any new interfaces
			//this should have its own thread
			
			//read the out queue to get interfaces that have been processed
			try
			{
				processedTask = (PollerTask)m_outQueue.read();
			}
			catch (InterruptedException e)
			{
				System.out.println(e);
				e.printStackTrace();
			}
			
			//get the new interval, may need to check on instanceof
			address = processedTask.getAddress().toString();
			status = processedTask.getStatus();
			
			System.out.println(address + " polled. Status = " + status);
			
			//based on the package and address get the interface
			index = processedTask.getPackageIndex();
			interfacesMap = (Map)m_packageInterfaces.get(index);
			
			curInterface = (PollerInterface)interfacesMap.get(address);
			
			if (status != curInterface.getServiceLastKnownStatus(m_activeService))
			{
				//generate an event signaling transition from status
				//this will save most recent status info to database
				String msg = null;
				if (status == ServiceMonitor.SERVICE_AVAILABLE)
				{
					msg = " has become available.";
				}
				else
				{
					msg = " has become unavailable.";
				}
				System.out.println("EVENT: interface" + address + " " + msg);
			}
			
			//update internal interface based on status?
			curInterface.updateStatus(m_activeService, status);
			
			//reschedule the interface
			rescheduleInterface(m_scheduleMaster,
					    curInterface.getNewInterval(m_activeService, status), 
					    processedTask);
		}
		
		//stop the scheduler threads
		Iterator iterator = m_scheduleMaster.keySet().iterator();
			
		IntervalScheduler task = null;
			
		while(iterator.hasNext())
		{
			task = (IntervalScheduler)m_scheduleMaster.get(iterator.next());
			task.stopScheduling();
		}
	}
	
	/**
	*/
	private void rescheduleInterface(Map aMaster, Integer newInterval, PollerTask aTask)
	{
		int oldInterval = aTask.getCurrentInterval();
		System.out.println("old= " + oldInterval + " new= " + newInterval);
		
		//see if we need to reschedule
		if (oldInterval != newInterval.intValue())
		{
			//need to generate an event saying it transition from one model interval to another
			System.out.println("EVENT: interface " + aTask.getAddress().toString() + 
					   " transitioned from " + oldInterval + "s to " + 
					   newInterval.intValue() + "s.");
			
			IntervalScheduler oldScheduler = (IntervalScheduler)aMaster.get(String.valueOf(oldInterval));
			oldScheduler.removePollerTask(aTask);
			
			//if the new interval is -1 the interface should not be rescheduled
			if (newInterval.intValue() == PollerModel.DELETE_FLAG)
			{
				//send event to signal interface should be deleted
				System.out.println("EVENT: interface " + aTask.getAddress().toString() + " not available, please delete.");
			}
			else
			{
				aTask.setCurrentInterval(newInterval.intValue());
				updateSchedule(aMaster, newInterval, aTask);
			}
		}
		
		aTask.setProcessing(false);
	}
	
	/**This method builds the interface ip lists for each service that requires scheduling.
	   To be eligible for scheduling an interface address must be included in the filter
	   expression of the package, be in the valid range (member of specific, or not in the
	   exclude range and in the inlcude range) and be associated with one of the services
	   the scheduler was told to schedule. The structure that is build is a list of lists, 
	   where each inner list contains interface ip addresses conforming to the above
	   conditions.
	   @return List, a list containing lists of interfaces to be scheduled
	   @param List, the list of package names
	*/
	private List getInterfacesToSchedule(List aPackageList, String aService)
	{
		//this list holds all the ip's for each package
		//each index will hold another list for the package at the same index in m_packageList
		List packageInterfaceLists = new ArrayList(aPackageList.size());
		
		PollerPackage curPackage = null;
		List filterList = null;
		Map prunedInterfaceMap = null;
		String address = null;
		String service = null;
		PollerInterface newInterface = null;
		
		//go through each package 
		for (int i = 0; i < aPackageList.size(); i++)
		{
			curPackage = (PollerPackage)aPackageList.get(i);
			
			//run the rule and get the ip list
			filterList = curPackage.getFilterList();
			
			//prune the filter list to make sure it includes only addresses
			//in the proper poller ranges
			prunedInterfaceMap = new HashMap();
			
			//look at each ip from the filter
			for (int j = 0; j < filterList.size(); j++)
			{
				address = (String)filterList.get(j);
				
				//database errors can occur when creating a new interface. if an interface
				//erros out don't put it into the scheduled list, put it into an error list
				//to be logged.
				try
				{
					newInterface = new PollerInterface(address, curPackage, i);
					
					//if the current filtered ip is within the poller range
					//and if it supports one of the services we are interested in 
					//and it is managed then add it to the pruned list
					if ( curPackage.ipInRange(address)             &&
				     	     newInterface.supportsService(aService)    &&
				             newInterface.getManaged().equals(PollerInterface.MANAGED)
				           )
				        {
						prunedInterfaceMap.put(address, newInterface);
					}
				}
				catch(SQLException e)
				{
					m_interfaceErrorList.add(address + " " + e.toString());
				}
				catch(DBOpenFailureException e)
				{
					m_interfaceErrorList.add(address + " " + e.toString());
				}
			}
			
			//make some debugging logs
			Log.print(Log.ERROR, "interfaces not scheduled: " + m_interfaceErrorList);
			Log.print(Log.DEBUG, "filtered list = " + filterList);
			Log.print(Log.DEBUG, "pruned list = " + prunedInterfaceMap);
			
			//add the filter list to the list to be scheduled at the proper index
			packageInterfaceLists.add(i, prunedInterfaceMap);
		}
		
		return packageInterfaceLists;
	}
	
	/**This method returns the list of package information this poller has
	   @return List, the list of packages
	*/
	public List getPackages()
	{
		return m_pollerParser.getPackages();
	}
	
	/**A main method to allow a scheduler to be invoked from a command line.
	   The arguments include: -ipaddr, ip address of the poller
	   -service, list of service name strings the scheduler should look for
	   -packages, print the list of packages this poller has
	*/
	public static void main(String args[])
	{
		try
		{
			//set up logging
	   		Log.setOut("scheduler.debug");
	    		Log.setLevel(Log.DEBUG);
	    		Log.enable();
		
			String ipAddr = null;
			boolean ipAddressSet = false;
		
			String service = null;
			boolean listPackages = false;
			
			//parse the switches from the command line
			for (int i = 0; i < args.length; i++)
			{
				String arg = args[i];
			
				//see if the user wants to see the packages
				if (arg.toLowerCase().equals("-packages"))
				{
					listPackages = true;
				}
			
				//get the ip address
				if (arg.toLowerCase().equals("-ipaddr"))
				{
					ipAddr = args[i+1];
				}
			
				//
				if (arg.toLowerCase().equals("-service"))
				{
					service = args[i+1];
				}
			}
			
			//build the new scheduler with the services
			PollerScheduler scheduler = new PollerScheduler(ipAddr, service);
			
			scheduler.start();
			
			//list the packages if the user wants them
			if (listPackages)
			{
				List list = scheduler.getPackages();
		
				for (int j = 0; j < list.size(); j++)
				{
					System.out.println((String)list.get(j));
				}
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
			e.printStackTrace();
		}
	}
}

//
// Copyright (C) 2000 N*Manage Company, Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
// $Id: Forward.java,v 1.1 2000/11/15 18:50:34 sowmya Exp $
//
package org.opennms.bb.dp.eventd.db;

import java.lang.*;
import java.util.List;
import java.util.Iterator;
import org.opennms.bb.dp.events.*;

/**
 * 
 *
 * @author <A HREF="mailto:weave@opennms.org">Brian Weaver</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version CVS $Revision: 1.1 $
 *
 */
public class Forward
{
	public static String format(EventForward fwd)
	{
		StringBuffer retForward = new StringBuffer();
		
		String text  = fwd.getDestination();
		String state = "off";
		if(fwd.getState() == EventForward.STATE_ON)
			state = "on";
		
		String how = "";
		switch(fwd.getForwardType())
		{
		case EventForward.FWD_SNMP_UDP:
			how = "snmpudp";
			break;
		case EventForward.FWD_SNMP_TCP:
			how = "snmptcp";
			break;
		case EventForward.FWD_XML_UDP:
			how = "xmludp";
			break;
		case EventForward.FWD_XML_TCP:
			how = "xmltcp";
			break;
		}

		return  Constants.escape(text, Constants.DB_ATTRIB_DELIM) 
			+ Constants.DB_ATTRIB_DELIM + state + Constants.DB_ATTRIB_DELIM + how;
			
	}
	
	public static String format(List forwards, int sz)
	{
		StringBuffer	buf = new StringBuffer();
		boolean		first = true;
		Iterator 	i = forwards.iterator();
		
		while(i.hasNext() && buf.length() < sz)
		{
			if(!first)
				buf.append(Constants.MULTIPLE_VAL_DELIM);
			buf.append(Constants.escape(format((EventForward)i.next()), Constants.MULTIPLE_VAL_DELIM));
		}
		
		if(buf.length() >= sz)
		{
			buf.setLength(sz-4);
			buf.append(Constants.VALUE_TRUNCATE_INDICATOR);
		}
		
		return buf.toString();
	}
}


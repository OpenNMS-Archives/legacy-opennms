//
// Copyright (C) 2000 N*Manage Company, Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
package org.opennms.bb.dp.actiond.components;

import java.util.*;

import org.opennms.bb.common.components.*;
import org.opennms.bb.dp.common.components.PollerThread;
import org.opennms.bb.dp.actiond.Actiond;
import org.opennms.bb.dp.events.*;

/**
 * <pre>ActionLauncher reads events from the ActiondEventsReader object and runs
 * any/all auto actions defined within the event.
 *
 * ActionLauncher extends the 'PollerThread' to handle the pause/resume/shutdown
 * functionality
 * </pre>
 * 
 * @author 	<A HREF="mailto:mike@opennms.org">Mike</A>
 * @author 	<A HREF="mailto:sowmya@opennms.org">Sowmya Kumaraswamy</A>
 * @author	<A HREF="http://www.opennms.org">OpenNMS.org</A>
 *
 * @version	$Revision: 1.2 $
 */
public class ActionLauncher extends PollerThread
{
	/**
	 * <P>This defines the thread specific bits that mark
	 * the thread as idle when its status is STATUS_NORMAL.</P>
	 */
	public final static int		STATUS_IDLE	= 1 << 8;
	
	/**
	 * <P>This defines the thread specific bits that mask
	 * the thread as busy when its status is STATUS_NORMAL.</P>
	 */
	public final static int		STATUS_BUSY	= 1 << 9;
	
	/**
	 * <P>The action launch manager.</P>
	 */
	private ActionLaunchManager	m_launchMgr;

	/**
	 * <P>The queue to which completed reader objects are added.</P>
	 */
	private	PCQueue			m_actionQ;

	/**
	 * <P>Time (in milliseconds) to wait for a command to complete.</P>
	 */
	private	long			m_timeout;

	/**
	 * <P> Receives a single command string as an argument, instantiates a 
	 * and starts an AutoExec thread object to execute it, blocks waiting
	 * for the action to complete or timeout, and writes the results
	 * to the log.  If the process times out it will be forcefully 
	 * terminated by calling the interrupt() method on the ActionExec thread.</P>
	 * 
	 * @param cmd	Command to be executed
	 */
	private void launchAndWait(String cmd)
	{
		// Instantiate ActionExec thread and call its start method
		// to execute the command.  ActionExec thread will notify
		// us when the command completes.
		ActionExec actionExec = new ActionExec(cmd, this);
		actionExec.start();
		synchronized (this)
		{
			try
			{
				wait(m_timeout); // Don't want to block indefinitely in case command never completes!
			}
			catch (Exception e)
			{
				Log.print(Log.WARNING, "ActionLauncher.launchAndWait: Exception while processing cmd '" + cmd + "' : " + e);
			}
		}
		// At this point either the ActionExec thread has completed
		// and notified us, or the wait(m_timeout) call timed out and
		// we consider the command hung.  In either case we check
		// the command execution result and log the results.
		if (actionExec.getCmdResult() == ActionExec.CMD_RESULT_UNKNOWN)
		{
			Log.print(Log.INFORMATIONAL, "Actiond: Timeout period (" + m_timeout + "ms) exceeded for command '" + cmd + "'.  Process terminating...");
			actionExec.interrupt(); // command is hung, interrupt the thread
		}
		else if (actionExec.getCmdResult() == ActionExec.CMD_RESULT_SUCCESS)
			Log.print(Log.INFORMATIONAL, "Actiond: Command '" + cmd + "' succeeded, exit value: " + actionExec.getCmdExitValue());
		else if (actionExec.getCmdResult() == ActionExec.CMD_RESULT_FAIL)
			Log.print(Log.INFORMATIONAL, "Actiond: Command '" + cmd + "' failed, reason: " + actionExec.getCmdFailureText());
	}

	/**
	 * <P>For each event contained within the reader object, sequentially execute
	 * all auto actions, notifications and trouble ticket actions.</P>
	 *
	 * @param eventsReader	the reader that has the events w/ actions to be launched
	 */
	private void processEvents(ActiondEventsReader eventsReader)
	{
		// Make sure we've got a valid eventsReader and that it contains
		// at least one event
		if (eventsReader == null)
			return;
		
		List events = eventsReader.getEvents();
		if (events == null)
			return;

		// Process each event in the event list sequentially
		int size = events.size();
		for (int i=0; i < size; i++)
		{
			EventBase inEvent;
			List commandList;
			
			// get next event
			inEvent = (EventBase)events.get(i);
	
			// Launch auto actions
			if (inEvent.hasAutoActions())
			{
				commandList = inEvent.getAutoActions();

				Iterator iter = commandList.iterator();
				while (iter.hasNext())
				{
					launchAndWait((String)iter.next());
				}
			}

			// Launch notifications
			if (inEvent.hasNotifications())
			{
				commandList = inEvent.getNotifications();

				Iterator iter = commandList.iterator();
				while (iter.hasNext())
				{
					launchAndWait((String)iter.next());
				}
			}

			// Launch trouble ticket
			if (inEvent.hasTroubleTicket())
			{
				EventTroubleTicket eTicket = inEvent.getTroubleTicket();
				if (eTicket.getState() == EventAttributeStateOnOff.STATE_ON)
				{
					launchAndWait(eTicket.getTicket());
				}
			}
		}
	}

	/**
	 * Constructs the ActionLauncher thread.
	 *
	 * @param	launchMgr	the action launch manager
	 * @param	actionQ		the queue from which actions to be launched are read
	 * @param	timeout		the number of milliseconds to wait for a command to complete
	 */
	public ActionLauncher(ActionLaunchManager launchMgr, PCQueue actionQ, long timeout)
	{
		m_launchMgr	= launchMgr;
		m_actionQ	= actionQ;
		m_timeout = timeout;
	}

	/**
	 * Loop through and wait for status changes - if status is normal,
	 * read an ActiondEventsReader object off of the input actionQ and launch
	 * any actions associated with the event in the reader.
	 */
	public void run()
	{
		setOpStatus(STATUS_NORMAL | STATUS_IDLE);
		
		for(;;)
		{
			//
			// Synchronize around all the status checks. This
			// is due to the PollerThread class design. The base
			// class will notifyAll() on itself when a status
			// change occurs.
			//
			synchronized(this)
			{
				
				//
				// Process the current status
				//
				for(;;)
				{
					int status = getOpStatus();
				
					if((status & STATUS_TERMINATING) != 0)
					{
						// terminating so just exit
						setOpStatus(STATUS_SHUTDOWN);
						return;
					}
					else if((status & STATUS_PAUSING) != 0)
					{
						// set to pausing and let next loop 
						// handle calling wait
						setOpStatus(STATUS_PAUSED);
					}
					else if((status & STATUS_RESUMING) != 0)
					{
						// set the status to normal

						setOpStatus(STATUS_NORMAL | STATUS_IDLE);
					}
					else if((status & STATUS_PAUSED) != 0)
					{
						//
						// The thread is paused or there is currently 
						// no address ready to be polled
						//
						try
						{
							wait();
						}
						catch(InterruptedException e)
						{
							// thread interrupted so terminate
							setOpStatus(STATUS_TERMINATING);
						}
					}
					else if((status & STATUS_NORMAL) != 0)
					{
						break; // exit the inner for(;;) loop
					}
				} // end inner for(;;)
			} // end synchronization
			
			setUserStatus(STATUS_BUSY);

			// Status must be equal to STATUS_NORMAL and STATUS_IDLE at this point
			// if the m_actionQ is empty, register with the queue for
			// notification on add and wait for  signal from queue
			// or signal due to status change
			boolean waitForQueue = false;
			synchronized(m_actionQ)
			{
				if(m_actionQ.entries() == 0)
				{
					m_actionQ.oneShotNotifyAllOnAdd(this);
                    waitForQueue = true;
                }
            }

            if(waitForQueue)
            {
				synchronized(this)
				{
            		try
            		{
       					wait(); // queue or status change can signal
            		}
                	catch(InterruptedException ie)
                	{
                	}
				}

				// if status is not normal, continue and handle
				// status change
				int status = getOpStatus();
				if((status & STATUS_NORMAL) != STATUS_NORMAL)
					continue;
            }

			try
			{
				// Get Next Object from Q
				ActiondEventsReader eventsReader = (ActiondEventsReader)m_actionQ.read();
							  
				// Call processEvents() to launch the actions defined within the event
				Log.print(Log.DEBUG, "ActionLauncher.run: processing new action in thread: " + Thread.currentThread());
				processEvents(eventsReader);

				// Allow the manager to see if there is a
				// need to increase the number of threads
				m_launchMgr.threadsVsQueueSizeCheck();
			}
			catch(QueueClosedException e) 
			{
				setOpStatus(STATUS_TERMINATING);
				break;
			}
			catch(InterruptedException e) 
			{ 
				setOpStatus(STATUS_TERMINATING);
				break;
			}

			setUserStatus(STATUS_IDLE);
		}
 	}
}

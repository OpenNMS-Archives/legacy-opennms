//
// Copyright (C) 2000 N*Manage Company, Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
// $Id: EventListener.java,v 1.1 2000/11/15 18:50:34 sowmya Exp $
//
package org.opennms.bb.dp.eventd;

import java.io.*;
import java.util.*;

import org.apache.xerces.parsers.SAXParser;
import org.opennms.bb.common.components.*;
import org.opennms.bb.dp.common.components.*;
import org.opennms.bb.dp.events.*;

/**
 * <P>Listener extends the PollerThread for the pause/resume/shutdown 
 * functionality </P>
 *
 * <P>Its threads listen for events sent as XML over a TCP, UDP or JSDT
 * connection. These threads add the received data as 'EventsReader'(
 * conatining the input stream) to the 'readerQ'
 * 
 * <P>It also maintains a pool of RunnableConsumerThreads that read and
 * run the EventsReader objects added to the readerQ to actually parse
 * the input streams to events('EventBlocks') - the 'EventsReader's are then
 * added to the 'expanderQ' from where the 'EventsExpander's pick them up, 
 * and add data from the 'event.conf' to the events
 *
 *
 * @author 	<A HREF="mailto:sowmya@opennms.org">Sowmya Kumaraswamy</A>
 * @author	<A HREF="mailto:weave@opennms.org">Brian Weaver</A>
 * @author	<A HREF="http://www.opennms.org">OpenNMS.org</A>
 *
 * @version	$Revision: 1.1 $
 */
class EventListener
{
	/**
	 * Port on which Listener accepts TCP connections 
	 */
	private final static int EVENTD_TCP_PORT = 5817;

	/**
	 * Port on which Listener accepts UDP connections 
	 */
	private final static int EVENTD_UDP_PORT = 5817;

	/**
	 * The initial number of threads
	 */
	private final static int INIT_NUM_READERS = 5;
	
	/**
	 * The queue to which the incoming events are added
	 */
	private PCQueue		m_readerQ;
	
	/**
	 * The queue to were completed reader objects are sent.
	 */
	private PCQueue		m_destQ;

	/**
	 * The handler for events coming in through TCP
	 */
	private TCPHandler	m_tcpHandler;

	/**
	 * The handler for events coming in through UDP
	 */
	private UDPHandler	m_udpHandler;

	/**
	 * The handler for events coming in through JSDT
	 */
	private JSDTHandler	m_jsdtHandler;

	/**
	 * <P>The max number of RunnableConsumerThreads that should be
	 * started by the manager.</P>
	 */
	private int		max_readers;

	/**
	 * The RunnableConsumerThread thread pool that takes a event
	 * input source, parses it to the event datablocks and adds that
	 * to the expanderQ
	 */
	private List		m_readers;
	
	/**
	 * <P>The thread group that all the reader threads belong two.
	 * This group can then be used to control/access the entire
	 * group. (If all the good methods were not depreciated).</P>
	 *
	 * <P>It's mainly for separating the threads in the debugger now.</P>
	 */
	private ThreadGroup	m_readerGroup;
	
	/**
	 * A hash table for the parser pool to be used by the
	 * 'RunnableConsumerThread' pool - a parser is added to the pool
	 * for each thread in the pool so that when the threads can then look
	 * up their parser by using the current thread ID
	 *
	 */
	private static Map	m_parserMap;


	/*
	 * Create the parser pool hashtable
	 */
	static
	{
		//
		// create the map that is used ot match threads
		// to sax parsers. This ensures that one parser
		// per thread, but we do not have to worry about
		// extending the thread to do this
		//
		m_parserMap = Collections.synchronizedMap(new HashMap());
	}

	/**
	 * <P>This class is designed to specifically override the add
	 * behaviour of the base class. In order to ensure that the 
	 * event daemon does not get two far behind a check is performed
	 * on each addition so ensure that there are always at least
	 * N/2 threads, where N is the size of the queue.</P>
	 *
	 * <P>The number of threads are bounded by a maximum that may 
	 * be allocated by the enclosing class. For more information
	 * see the thread vs. queue size check routine.</P>
	 *
	 * @author <A HREF="mailto:weave@opennms.org">Brian Weaver</A>
	 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
	 *
	 * @see #threadVsQueueSizeCheck
	 *
	 */
	private class CheckQueue extends PCQueueLinkedList
	{
		/**
		 * <P>Adds the specified object to the tail of the 
		 * producer/consumer queue. If the queue is currently
		 * at it's predefined limit then the call blocks until
		 * there is room in the queue.</P>
		 *
		 * <P>If the queue is closed while the thread is waiting to
		 * add the object then an exception is thrown. Likewise,
		 * if the adding thread is interruped then an exception
		 * is thrown by the add method.</P>
		 *
		 * @param obj	The object to be added to the queue.
		 * @exception java.lang.InterruptedException Thrown if the adding
		 * 		thread is interrrupted prior to completing the
		 *		addition of the object.
		 * @exception org.opennmms.bb.common.components.QueueClosedException Thrown
		 *		if the queue is closed before the object is added to the
		 *		producer/consumer queue.
		 *
		 */
		public synchronized void add(Object obj)
			throws InterruptedException, QueueClosedException
		{
			super.add(obj);
			Log.print(Log.DEBUG, "Reader stats - Q size: " + entries() + "  threads in pool: " + m_readers.size());
			threadsVsQueueSizeCheck(entries());
		}
	}	

	/**
	 * After each read from the readerQ, the threads in the thread
	 * pool call this method to adjust the number of threads in the pool
	 * if necessary
	 *
	 * If the number of entries in the queue is more than double the
	 * number of threads, the number of threads is increased by one
	 * until the configurable maximum number of threads is reached
	 *
	 * If the number of threads in thepool is more than double the
	 * number of entries in the queue, the number of threads is
	 * decreased by one until the predefined initial number of threads
	 * is reached
	 *
	 */
	synchronized void threadsVsQueueSizeCheck(int entries)
	{
		int curNumThreads = m_readers.size();
		if((curNumThreads < max_readers)  && ((entries / curNumThreads) > 2) )
		{
			// increase by 1!
			RunnableConsumerThread readerThread = new RunnableConsumerThread(m_readerGroup,
											 "EventReaderConsumer-" + m_readers.size(),
											 m_readerQ, 
											 m_destQ);

			//
			// create a parser for the threads
			//
			SAXParser saxp = new SAXParser();
			XMLEventsParser parser = new XMLEventsOverrideParser();
			saxp.setContentHandler(parser);
			saxp.setErrorHandler(parser);

			//
			// add the collection to the 
			// map for use by the thread
			//
			try
			{
				readerThread.start();
				m_readers.add(readerThread);
				m_parserMap.put(readerThread,saxp);
			}
			catch(RuntimeException re)
			{
				Log.print(Log.WARNING, "Error starting new consumer thread");
				Log.print(Log.WARNING, re);
				
				m_parserMap.remove(readerThread);
				readerThread.shutdown();
				m_readers.remove(readerThread);
			}
		}
	}

	/**
	 * <P>Creates the Listener thread of eventd that listens for 
	 * events sent via TCP, UDP or JSDT</P>
	 *
	 * <P>The Listener also has a pool of 'RunnableConsumerThread'
	 * threads that reads the input streams added by the individual
	 * listeners and parses the streams (this is done by running the
	 * EventsReader objects in the readerQ) </P>
	 *
	 * @exception EventListenerException if any of the handlers fail to get created
	 */
	public EventListener(PCQueue destQ) 
		throws EventListenerException
	{
		//
		// get the default number of threads
		//
		max_readers = 30;
		String threadNum = Eventd.getProperty(EventdConstants.PROP_MAX_EVENT_LISTENER_THREADS);
		if(threadNum != null)
		{
			try
			{
				max_readers = Integer.parseInt(threadNum);
				if(max_readers < 1)
					max_readers = 1;
			}
			catch(NumberFormatException ne)
			{
				Log.print(Log.WARNING, "Unable to correctly parse property: " 
							+ EventdConstants.PROP_MAX_EVENT_LISTENER_THREADS 
							+ ", value = " 
							+ threadNum);
			}
		}
		
		//
		// Try creating the handlers and list
		// of threads
		//
		m_readerGroup = new ThreadGroup("EventReaderConsumerPool");
		m_readers = Collections.synchronizedList(new ArrayList(max_readers));
		try
		{
			m_destQ      = destQ;
			m_readerQ    = new CheckQueue();
			m_tcpHandler = new TCPHandler(EVENTD_TCP_PORT, m_readerQ);
			m_udpHandler = new UDPHandler(EVENTD_UDP_PORT, m_readerQ);
			m_jsdtHandler= new JSDTHandler(m_readerQ);

			/* 
		 	 * Create the listener thread pool 
		 	 */
			for (int iIndex = 0; iIndex < INIT_NUM_READERS; iIndex++)
			{
				RunnableConsumerThread readerThread = new RunnableConsumerThread(m_readerGroup,
												 "EventReaderConsumer-" + iIndex,
												 m_readerQ, 
												 m_destQ);
				m_readers.add(readerThread);
				
				// create a parser for each of the threads
				XMLEventsParser parser = new XMLEventsOverrideParser();
				SAXParser saxp = new SAXParser();
				saxp.setContentHandler(parser);
				saxp.setErrorHandler(parser);
				
				m_parserMap.put(readerThread, saxp);
			}

		}
		catch (Exception e)
		{
			Log.print(Log.ERROR, "Error starting up the RunnableConsumerThreads for the Listener: " + e.getMessage());
			
			Iterator iter = m_readers.iterator();
			while(iter.hasNext())
			{
				try
				{
					m_parserMap.remove(iter.next());
				}
				catch(Exception e2) { }
			}

			throw new EventListenerException(e.getMessage());
		}
	}
	
	/**
	 * Start all the threads to handle the various communication paths
	 */
	public void start()
	{
		m_tcpHandler.start();
		m_udpHandler.start();
		Iterator iter = m_readers.iterator();
		while(iter.hasNext())
			((Thread)iter.next()).start();
	}
	
	/**
	 *
	 */
	public void pauseOperation() throws InterruptedException
	{
		PollerThread.pauseThread(m_tcpHandler);
		PollerThread.pauseThread(m_udpHandler);
		m_jsdtHandler.pauseOperation();

		Iterator iter = m_readers.iterator();
		while(iter.hasNext())
			PollerThread.pauseThread((PollerThread)iter.next());
	}
	
	/**
	 *
	 */
	public void resumeOperation() throws InterruptedException
	{
		PollerThread.resumeThread(m_tcpHandler);
		PollerThread.resumeThread(m_udpHandler);
		m_jsdtHandler.resumeOperation();

		Iterator iter = m_readers.iterator();
		while(iter.hasNext())
			PollerThread.resumeThread((PollerThread)iter.next());
	}
		

	/**
	 * <P>Initiates the shutdown sequence and waits for 
	 * this thread to exit.</P>
	 */
	public synchronized void shutdown()
	{
		m_tcpHandler.shutdown();
		m_udpHandler.shutdown();
		m_jsdtHandler.shutdown();
		
		Iterator iter = m_readers.iterator();
		while(iter.hasNext())
		{
			try
			{
				PollerThread pt = (PollerThread)iter.next();
				PollerThread.shutdownThread(pt);
				if(!Thread.currentThread().equals(pt))
					pt.join();
			}
			catch(InterruptedException ie)
			{
				Log.print(Log.WARNING, "Got Interrupted Exception, skipping to next");
				Log.print(Log.WARNING, ie);
			}
		}

		try
		{
			m_udpHandler.join();
			m_tcpHandler.join();
		}
		catch(InterruptedException ie)
		{
			Log.print(Log.WARNING, "Got Interrupted Exception");
			Log.print(Log.WARNING, ie);
		}
	}

	/**
	 * Returns the SAX based parser that can be used to 
	 * decompose the event. Use the getContentHandler
	 * method of the parser to get the event parser!
	 *
	 * @param key	the currently running thread
	 *
	 * @return The SAX parser that can be used to decompose
	 * 	the event object.
	 *
	 * @see org.apache.xerces.parser.SAXParser#getContentHandler
	 * @see org.apache.soap.sax.SAXParser#getContentHandler
	 */
	public static SAXParser getEventsParser(Object key)
	{
		return (SAXParser)m_parserMap.get(key);
	}
}

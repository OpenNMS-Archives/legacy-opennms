//
// Copyright (C) 2000 N*Manage Company Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
// Tab Size = 8
//
// $Id: MonitorResponseParser.java,v 1.2 2000/11/10 01:57:19 mike Exp $
//

package org.opennms.bb.dp.poller.parsers;

import java.lang.*;
import java.util.*;

import org.apache.xerces.parsers.*;
import org.xml.sax.*;
import org.xml.sax.helpers.*;

import org.opennms.protocols.ip.IPv4Address;
import org.opennms.bb.dp.discovery.components.IPPollAddress;
import org.opennms.bb.dp.poller.plugins.PollResponseAddress;

/**
 * <P>The MonitorResponseParser is designed to parse ICMP monitor
 * responses from discovery. The SOAP document that is exchanged 
 * can be decomposed into an ICMP poll reply including (but not
 * limited to) IPv4 address, number of retries and timeout (ms).</P>
 * 
 * <P>In order to use the class, first create an instance of an XML
 * parser using the Xerces <EM>SAXPaser</EM> class. Then set an 
 * instance of this class as the <EM>ErrorHandler</EM> and the
 * <EM>ContentHandler</EM>. After seting up the parser just call
 * the parse method. If the parser fails then the list of address
 * returned will be null.</P>
 *
 * @see org.apache.xerces.parsers.SAXParser
 * @see org.xml.sax.ContentHandler
 * @see org.xml.sax.ErrorHandler
 * @see org.xml.sax.helpers.DefaultHandler
 *
 */
public final class MonitorResponseParser 
	extends org.xml.sax.helpers.DefaultHandler
{
	/**
	 * <P>A list of response objects extracted from the document.</P>
	 */
	private List 		m_responses;	
	
	/**
	 * <P>A temporary string buffer to store character data
	 * when the m_isIPv4Addr is true.</P>
	 */
	private StringBuffer	m_addrBuf;	// temporary storage until endElement called

	/**
	 * <P>A temporary string buffer to store character data
	 * when the m_isStatus is true.</P>
	 */
	private StringBuffer	m_statusBuf;	// temporary storage until endElement called
	
	/**
	 * <P>Set to true if the SOAP envlope was processed successfully.</P>
	 */
	private boolean		m_isSoapCompliantEnv;
	
	/**
	 * <P>Set to true if the SOAP body tag was processed successfully</P>
	 */
	private boolean		m_isSoapCompliantBody;
	
	/**
	 * <P>Set to true if the corresponding tag was processed successfully.</P>
	 */
	private boolean    	m_isMonitorResponse;
	private boolean     m_isResponse;
	private boolean   	m_isIPv4Addr;
	private boolean 	m_isStatus;

	/**
	 * <P>Set if a tag is in error. Each call to start element will
	 * increment the tag, if non-zero. Each call to end element will
	 * decrement the tag, if non-zero. This keeps tags from being 
	 * processed when an error occurs until the corresponding end
	 * tag is caught.</P>
	 */
	private int		m_error;

	/**
	 * <P>The SOAP Envelope tag</P>
	 */
	private final String SOAP_ENV		= "SOAP-ENV:Envelope";
	
	/**
	 * <P>The SOAP Body tag</P>
	 */
	private final String SOAP_BODY		= "SOAP-ENV:Body";
	
	/**
	 * <P>The SOAP envelope namespace that is required for
	 * SOAP conformance.</P>
	 */
	private final String SOAP_NS		= "http://schemas.xmlsoap.org/soap/envelope/";
	
	//
	// Relevant XML tags
	//
	private final String MONITOR_RESPONSE	= "Discovery:MonitorResponse";
	private final String RESPONSE 			= "Discovery:response";
	private final String IPV4ADDR 			= "Discovery:ipv4Address";
	private final String STATUS				= "Discovery:status";
	
	
	/**
	 * <P>The BlueBird Discovery namespace uri.</P>
	 */
	private final String DISCOVERY_NS	= "http://dtds.opennms.org/bluebird/discovery/MonitorResponse/";
	
	/**
	 * </P>The class constructor creates a new instance of the
	 * MonitorResponseParser. The parser is used to decompose
	 * SOAP messages from the discovery system about addresses
	 * the discovery system found.</P>
	 *
	 */
	public MonitorResponseParser()
	{
		m_isSoapCompliantEnv = false;
		m_isSoapCompliantBody= false;
		m_responses	= null;
		m_isMonitorResponse	= false;
		m_isResponse 	= false;
		m_isIPv4Addr    = false;
		m_addrBuf	= null;

		m_isStatus = false;
		m_statusBuf = null;

		m_error		= 0;
	}
	
	/**
	 * <P>The startDocument method is called by the xerces
	 * parser when a new document is started. If the instance
	 * previously contained any data, then it is lost since
	 * the class is reset to its initial state. This allows
	 * for an instance to be reused to parse new document
	 * and avoid creating new instances.</P>
	 *
	 * @exception org.xml.sax.SAXException Thrown if an error
	 * 	occurs parsing the start of the document.
	 */
	public void startDocument()
		throws SAXException
	{
		m_isSoapCompliantEnv = false;
		m_isSoapCompliantBody= false;
		m_responses 	= new ArrayList();
		m_isMonitorResponse = false;
		m_isResponse 	= false;
		m_isIPv4Addr    = false;
		m_addrBuf	= new StringBuffer();
		m_isStatus 		= false;
		m_statusBuf	= new StringBuffer();
		m_error		= 0;
	}
	
	/**
	 * <P>Called to process the start of a new element for 
	 * the document. If namespaces are enabled, then the
	 * uri will be a valid namesapce. See the base class
	 * for more information.</P>
	 *
	 * @param uri		The XML namespace.
	 * @param localName	The local name with the namespace prefix.
	 * @param qName		The qualified name (includs namepace prefix).
	 * @param attributes	The attributes associated with the element.
	 *
	 * @exception org.xml.sax.SAXException	Thrown if a processing 
	 * 	error occurs.
	 */
	public void startElement(String		uri,
				 String		localName,
				 String		qName,
				 Attributes	attributes)
		throws SAXException
	{

		//
		// If an error has occurs, all levels will be
		// in error untl the corresponding endElement()
		// is called.
		//
		if(m_error != 0)
		{
			m_error++;
			return;
		}
			
		if(qName.equals(SOAP_ENV) && uri.equals(SOAP_NS))
		{
			m_isSoapCompliantEnv = true;
		}
		else if(m_isSoapCompliantEnv && qName.equals(SOAP_BODY) && uri.equals(SOAP_NS))
		{
			m_isSoapCompliantBody = true;
		}
		else if(m_isSoapCompliantBody && qName.equals(MONITOR_RESPONSE) && uri.equals(DISCOVERY_NS))
		{
			m_isMonitorResponse = true;
		}
		else if(m_isMonitorResponse && qName.equals(RESPONSE) && uri.equals(DISCOVERY_NS))
		{
			m_isResponse = true;
		}
		else if(m_isResponse && qName.equals(IPV4ADDR) && uri.equals(DISCOVERY_NS))
		{
			m_isIPv4Addr = true;
			if(m_addrBuf.length() > 0)
				m_addrBuf.delete(0, m_addrBuf.length()); // Clear buffer for next pass
		}
		else if(m_isResponse && qName.equals(STATUS) && uri.equals(DISCOVERY_NS))
		{
			m_isStatus = true;
		}
		else
		{
			//
			// Should a SAX Exception be thrown instead?
			//
			m_error = 1;
		}
	}
	
	/**
	 * <P>Called to process the end of an element for 
	 * the document. If namespaces are enabled, then the
	 * uri will be a valid namesapce. See the base class
	 * for more information.</P>
	 *
	 * @param uri		The XML namespace.
	 * @param localName	The local name with the namespace prefix.
	 * @param qName		The qualified name (includs namepace prefix).
	 *
	 * @exception org.xml.sax.SAXException	Thrown if a processing 
	 * 	error occurs.
	 */
	public void endElement(String uri,
			       String localName,
			       String qName)
		throws SAXException
	{

		if(m_error > 0)
		{
			--m_error;
		}
		
		if(m_isStatus)
		{
			m_isStatus = false;
		}
		else if(m_isIPv4Addr)
		{
			m_isIPv4Addr = false;
		}
		else if (qName.equals(RESPONSE))
		{	
			m_isResponse = false;

			//
			// Create new PollResponseAddress object and add it to response list
			//
			m_responses.add(new PollResponseAddress(m_addrBuf.toString().trim(), m_statusBuf.toString().trim()));
		}
		else if(qName.equals(MONITOR_RESPONSE))
		{
			m_isMonitorResponse = false;
		}
		else if(qName.equals(SOAP_BODY))
		{
			m_isSoapCompliantBody = false;
		}
		else if(qName.equals(SOAP_ENV))
		{
			m_isSoapCompliantEnv = false;
		}
	}
	
	/**
	 * <P>This method is used to receive event notifiaction
	 * of character data. The character data is attached to the
	 * last tag that was processed by the startElement method.</P>
	 *
	 * <P>The character data in this method is ignored unless 
	 * an address tag is being processed. No validation is performed
	 * to ensure that non-data elements have no data.</P>
	 *
	 * @param data		The character data from the parser.
	 * @param offset	The offset in the data buffer that is valid.
	 * @param length	The length of valid data from the offset.
	 *
	 * @exception org.xml.sax.SAXException Thrown if a processing error
	 * 	occurs.
	 */
	public void characters(char[] data, int offset, int length)
		throws SAXException
	{
		if(m_isIPv4Addr)
			m_addrBuf.append(data, offset, length);
		else if (m_isStatus)
			m_statusBuf.append(data, offset, length);
	}
	
	/**
	 * <P>The warning handler is invoked by the parser when
	 * a recoverable error occurs parsing the document.</P>
	 *
	 * @param ex	The exception that occured.
	 *
	 * @exception org.xml.sax.SAXException Thrown if an error
	 * 	occurs processing the exception.
	 */
	public void warning(SAXParseException ex)
		throws SAXException
	{
		System.out.println("WARNING: " + ex.getMessage());
		ex.printStackTrace(System.out);
	}

	/**
	 * <P>The error handler is invoked by the parser when
	 * a recoverable error occurs parsing the document.</P>
	 *
	 * @param ex	The exception that occured.
	 *
	 * @exception org.xml.sax.SAXException Thrown if an error
	 * 	occurs processing the exception.
	 */
	public void error(SAXParseException ex)
		throws SAXException
	{
		System.out.println("ERROR: " + ex.getMessage());
		ex.printStackTrace(System.out);
	}

	/**
	 * <P>The fatal error handler is invoked by the parser when
	 * a non-recoverable error occurs parsing the document.</P>
	 *
	 * @param ex	The exception that occured.
	 *
	 * @exception org.xml.sax.SAXException Thrown if an error
	 * 	occurs processing the exception.
	 */
	public void fatalError(SAXParseException ex)
		throws SAXException
	{
		m_responses = null;
			
		System.out.println("FATAL: " + ex.getMessage());
		ex.printStackTrace(System.out);
	}
	
	/**
	 * <P>Returns the list of responses recovered by the parser.</P>
	 */
	public List getResponses()
	{
		return m_responses;
	}
	
	/**
	 * <P>A sample test program. Creates an instance of the parser
	 * and parses each file passed on the command line. Once the
	 * each file is parse, the address(es) in the file are printed
	 * to the commmand line.</P>
	 *
	 * <P>This is used solely for debugging and development testing.</P>
	 *
	 * @param args	The arguments to main.
	 *
	 */
	public static void main(String[] args)
	{
		MonitorResponseParser handler = new MonitorResponseParser();
		SAXParser parser = new SAXParser();
		
		parser.setContentHandler(handler);
		parser.setErrorHandler(handler);
		
		for(int i = 0; i < args.length; i++)
		{
			try
			{
				parser.parse(args[i]);
				List addrs = handler.getResponses();
				Iterator iter = addrs.iterator();
				while(iter.hasNext())
				{
					System.out.println("got address " + iter.next());
				}
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
			}
		}
	}
}			
		

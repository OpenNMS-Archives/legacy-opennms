//
// Copyright (C) 2000 N*Manage Company Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
// Tab Size = 8
//
// $Id: DiscKnownNodesRetriever.java,v 1.8 2000/10/18 19:05:39 sowmya Exp $
//

package org.opennms.bb.dp.discovery.components;

import java.sql.*;
import java.util.*;

import org.opennms.protocols.ip.IPv4Address;
import org.opennms.bb.common.components.BBDataRetriever;
import org.opennms.bb.dp.discovery.Discovery;

/**
 * <P>The DiscKnownNodesRetriever extends the BBDataRetriever and
 * retrieves the list known nodes from the datasource. The set
 * of known nodes is created when the constructor is called and
 * can be synchronized at any time using the syncSet() method.</P>
 *
 *
 * @author <A HREF="mailto:sowmya@opennms.org">Sowmya</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version $Revision: 1.8 $
 */
public final class DiscKnownNodesRetriever extends BBDataRetriever
{
	/**
	 * The HashSet of known nodes. A known
	 * node is an IP address string.
	 */
	private Set	 m_knownNodes;
	
	/**
	 * <P>The property name used to get the SQL
	 * text for loading the currently known nodes.</P>
	 */
	private final String	LOAD_ADDR_PROP = "org.opennms.bluebird.discovery.database.loadAddressSQL";

	/**
	 * Creates the connection to the data store
	 * and the set of known nodes. The list is
	 * not loaded until the first call to syncSet()
	 *
	 * @param driver	The fully qualified class name of the sql driver.
	 * @param url		The database url.
	 * @param user		The database user name.
	 * @param passwd	The database user's password.
	 *
	 */
	public DiscKnownNodesRetriever(String driverName, String url, String user, String passwd)
	{
		super(driverName, url, user, passwd);
		m_knownNodes = Collections.synchronizedSet(new HashSet());
	}

	/**
	 * Synchronizes the set of known nodes with the contents
	 * of the persistant data store. Any nodes in the list
	 * are removed so that only nodes in the database are 
	 * actually in the list.
	 *
	 * @return The set of known nodes.
	 *
	 * @exception java.lang.ClassNotFoundException Thrown if the database
	 * 	driver class cannot be loaded.
	 * @exception java.SQLException Thrown if there is an SQL driver error.
	 *
	 */
	public Set syncSet() 
		throws ClassNotFoundException, SQLException
	{
		String sqlText = Discovery.getProperty(LOAD_ADDR_PROP);
		if(sqlText == null)
		{
			throw new NullPointerException("Property \"" + LOAD_ADDR_PROP + "\" not found");
		}
		
		synchronized(m_knownNodes)
		{
			//
			//clear out the known nodes
			//
			m_knownNodes.clear();
			
			// load driver
			Class.forName(driver);
	
			// Connect to the database
			Connection con = DriverManager.getConnection(url, user, passwd);
	
			// query
			Statement stmt = con.createStatement();
	
			//
			// The first column should be the ip address. 
			//
			ResultSet rs = stmt.executeQuery(sqlText);
	
			// construct known nodes vector
			while(rs.next())
			{
				int rawAddr = rs.getInt(1);
				if(rawAddr != 0)
				{
					String ipAddr = IPv4Address.addressToString(rawAddr);
					m_knownNodes.add(ipAddr);
				}
			}

			stmt.close(); // also closes the result set
		}
		return m_knownNodes;
	}
	
	/**
	 * Returns the known node set as it 
	 * is currently.
	 */
	public Set getNodes()
	{
		return m_knownNodes;
	}
}

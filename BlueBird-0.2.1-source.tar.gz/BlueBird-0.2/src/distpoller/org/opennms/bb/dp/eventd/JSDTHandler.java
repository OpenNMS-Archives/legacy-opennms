//
// Copyright (C) 2000 N*Manage Company, Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
package org.opennms.bb.dp.eventd;

import java.net.*;
import java.io.*;
import java.util.*;
import com.sun.media.jsdt.*;

import org.xml.sax.SAXException;

import org.opennms.bb.common.components.*;
import org.opennms.bb.dp.common.components.*;
import org.opennms.bb.dp.events.*;

/**
 * <P>JSDTHandler handles all the events sent to Eventd via JSDT</P>
 * 
 * <P>It extends the PollerClient and implements the 'ChannelConsumer' 
 * interface to receive the events
 *
 * @author 	<A HREF="mailto:weave@opennms.org">Brian Weaver</A>
 * @author 	<A HREF="mailto:sowmya@opennms.org">Sowmya Kumaraswamy</A>
 * @author	<A HREF="http://www.opennms.org">OpenNMS.org</A>
 *
 * @version	$Revision: 1.1 $
 */
public class JSDTHandler 
	implements ChannelConsumer
{
	/**
	 * queue to which the incoming event stream is to be added
	 */
	private PCQueue			m_readerQ;

	/**
	 * The JSDT channel on which eventd is listening for messages
	 */
	private Channel			m_channel;

	/**
	 * Flag indicating that operation is to be paused
	 * For now events received are simply discarded during pause
	 */
	private boolean			m_paused;

	// This variable is strictly being used for debug purposes to 
	// keep track of the number of events received
	private static int numEventsRcvd=0; // DEBUG ONLY

	/**
	 * Connect to the eventd JSDT channel
	 *
	 * @throws java.lang.InterruptedException Thrown if the running
	 * 	thread is interrupted by another thread.
	 */
	private void jsdtConnect() 
		throws JSDTException
	{
		Session session = Eventd.getSession();
		m_channel = session.createChannel(Eventd.getClient(), 
						  PollerJSDTConstants.EVENTS_SOURCE_CHANNEL,
						  true,
						  false,
						  true);
		m_channel.addConsumer(Eventd.getClient(), this);
	}


	/**
	 * Creates a JSDTHandler for eventd
	 *
	 * @param	readerQ	The where EventsReader objects are placed.
	 *
	 * @exception 	java.lang.RunTimeException Thrown if connection to JSDT fails
	 */
	public JSDTHandler(PCQueue readerQ)
	{
		m_readerQ = readerQ;
		m_paused  = false;

		//
		// Create the JSDT communication path to recieve events
		//
		try
		{
			Log.print(Log.INFORMATIONAL, "Trying to connect to JSDT registry ...");
			jsdtConnect();
			Log.print(Log.INFORMATIONAL, "JSDT communication channel up");
		}
		catch(JSDTException je)
		{
			Log.print(Log.WARNING, "Error trying to connect using jsdt");
			Log.print(Log.WARNING, je);
			throw new RuntimeException("The jsdt connection had errors");
		}
		Log.print(Log.INFORMATIONAL, "Eventd ready to accept events via JSDT");
	}

	/**
	 * Pause the operation - ignore the received messages?
	 */
	public synchronized void pauseOperation()
	{
		m_paused = true;
	}

	/**
	 * Resume the paused operation
	 */
	public synchronized void resumeOperation()
	{
		m_paused = false;
	}

	/**
	 * <P>Removes itself as a consumer for the JSDT session and closes the session</P>
	 */
	public synchronized void shutdown()
	{
		// close JSDT m_session
		try
		{
			m_channel.removeConsumer(Eventd.getClient(), this);
			m_channel.destroy(Eventd.getClient());
			m_channel = null;
		}
		catch(JSDTException jsdtE) 
		{
			Log.print(Log.WARNING, "Error closing the JSDT session for the JSDTHandler");
			Log.print(Log.WARNING, jsdtE);
		}
	}
	
	/**
	 * If operation is not paused, add the incoming event to the 'listenerQ'
	 * as an input stream. Also get the EventListener to check if the
	 * the thread pool size needs to be adjusted</pre>
	 *
	 * @param data		received JSDT data 
	 */
	public synchronized void dataReceived(Data data)
	{
		if (m_paused)
			return;

		Log.print(Log.DEBUG, "Data received  via JSDT (" + ++numEventsRcvd + ")");

		try
		{
			/**
	 	  	 * Once the event has been read, create a
	 	  	 * org.xml.sax.InputSource from this
	 	  	 * stream and parse the event
	 	  	 */
			ByteArrayInputStream bis = new ByteArrayInputStream(data.getDataAsBytes());
			m_readerQ.add(new EventsReader(bis));

		}
		catch (InterruptedException iE)
		{
			// ignore???
			Log.print(Log.WARNING, "JSDTHandler: Event ignored: Unable to add event stream to event listener queue" + iE.getMessage());
		}
		catch(QueueClosedException qE)
		{
			// ignore???
			Log.print(Log.WARNING, "JSDTHandler: Event ignored: Unable to add event stream to event listener queue" + qE.getMessage());
		}

	}
}

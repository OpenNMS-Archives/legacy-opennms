//
// Copyright (C) 2000 N*Manage Company Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
// Tab Size = 8
//
// $Id: DiscPinger.java,v 1.12 2000/11/03 16:29:02 mike Exp $
//

package org.opennms.bb.dp.discovery.components;

import java.net.*;
import java.io.*;

import org.opennms.protocols.ip.*;
import org.opennms.protocols.icmpd.*;
import org.opennms.bb.common.components.*;
import org.opennms.bb.dp.common.components.PollerThread;

/**
 * <P>DiscPinger is the type of thread that is maintained in the
 * ping manager's thread pool. This is responsible for actually 
 * creating, sending and retrying the PING packets.</P>
 *
 * <P>Note however that object does not directly receive echo replies. The 
 * manager receives the replies and notifies this thread that a response 
 * to the request sent out has been received</P>
 *
 * @author <A HREF="mailto:sowmya@opennms.org">Sowmya</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version $Revision: 1.12 $
 */
public final class DiscPinger extends PollerThread
{
	/**
	 * <P>The thread key for this particular thread. This key
	 * is placed into all the icmp echo requests that are sent
	 * by this thread. The manager can the use this id to find
	 * the sending thread.</P>
	 */
	private long			m_tid;
	
	private PCQueue			m_requestQ;

	/**
	 * <P>This is the connection to the icmp daemon that sends
	 * and receives request for the discovery process. Since 
	 * most process must have superuser privilage to send and
	 * receive icmp messages, the icmpd is used to isolate the
	 * java code from the operating system.</P>
	 */
	private DaemonConnection	m_portal;

	/**
	 * <P>The limiter is used to ensure that only a specific
	 * number of packets are sent within a specific time 
	 * quantium. The number is reset to the maximum each 
	 * time quantum.</P>
	 */
	private QuantumSemaphore	m_limiter;
	
	/**
	 * <P>This is the filterID to include in the icmp
	 * echo request message. Unless this id is included
	 * in the sending packet the echo reply will be 
	 * discarded by the icmpd.</P>
	 */
	private short			m_filterID;
	
	/**
	 * <P>This object is used to synchronize access to
	 * the m_addr and m_responded. Those member variables
	 * should not be modified unless the lock for m_sync
	 * is held. Also, while waiting on those modification
	 * the m_sync.wait() will be called instead of the
	 * thread's wait() method.</P>
	 */
	private Object			m_sync;
	
	/**
	 * <P>The IP Address object to poll.</P>
	 */
	private IPPollAddress		m_addr;		// access ctrl m_sync
	
	/**
	 * <P>When the manager calls the receive method
	 * this variable will be updated with the value
	 * of true if the responding address matches the
	 * value of m_addr.</P>
	 */
	private boolean			m_responded;	// access ctrl m_sync

	/**
	 * <P>Creates a new discovery ping thread that will
	 * attempt to poll addresses as they are set by the
	 * manager.</P>
	 *
	 * @param lThreadId	The thread identifer used by the manager.
	 * @param Q		The Q from which to read off the address to ping
	 * @param portal	The connection to the icmp daemon.
	 * @param pingFilterID	The filter id used by the icmp daemon.
	 * @param pktLimiter	Limits the packets per quantum.
	 *
	 */
	public DiscPinger(long 			lThreadID, 
			  PCQueue		requestQ,
			  DaemonConnection 	portal, 
			  short 		pingFilterID, 
			  QuantumSemaphore 	pktLimiter)
	{
		super("DiscPinger" + lThreadID);

		m_tid		= lThreadID;
		m_requestQ	= requestQ;
		m_portal	= portal;
		m_filterID	= pingFilterID;
		m_limiter	= pktLimiter;
		m_sync		= new Object();
		m_responded	= false;
		m_addr		= null;
	}

			

	/**
	 * <P>Return the current IP Address being polled
	 * by this thread. If no address is being polled
	 * then a null pointer will be returned.</P>
	 */
	public IPPollAddress getIPAddress()
	{
		synchronized(m_sync)
		{
			return m_addr;
		}
	}

	
	/**
	 * <P>Returns the thread id as specified by the manager.</P>
	 */
	public long getThreadID()
	{
		return m_tid;
	}


	/**
 	 * <P>The ping manager calls this function to indicate that 
 	 * the request sent by this thread has been received. If
	 * the thread is currently attempting to query the remote
	 * host then a value of true will be returned.</P>
	 *
	 * @param ipAddress	The remote echo reply address.
	 *
	 * @return True if the ipAddress matches the queried node.
	 *
 	 */
	public synchronized boolean received(String ipAddress)
	{	
		boolean bRet 	= false;
		int	status	= getOpStatus();
		
		if((status & STATUS_NORMAL) != 0 )
		{
			synchronized(m_sync)
			{
				if(m_addr != null && m_addr.getAddress().equals(ipAddress))
				{
					Log.print(Log.INFORMATIONAL, "Reply Received For: " + ipAddress + "\n");
					bRet = true;
					m_responded = true;
					m_sync.notifyAll();
				}
			}
		}
		return bRet;
	}

	/**
	 * <P>The run() method does the hard work of the discovery
	 * poller thread. It waits for new addresses to be served
	 * out by the manager and then polls each address. When
	 * either the retries are exhausted or the manager informs
	 * the object that the remote has responded, the thread
	 * will go back to an idle state and wait for a new address.</P>
	 *
	 */
	public void run()
	{
		/*
		 * let the manager know that were ready!
		 */
		setOpStatus(STATUS_NORMAL);
		
		for(;;)
		{
			//
			// Synchronize around all the status checks. This
			// is due to the PollerThread class design. The base
			// class will notifyAll() on itself when a status
			// change occurs.
			//
			synchronized(this)
			{
				
				//
				// Process the current status
				//
				for(;;)
				{
					int status = getOpStatus();
				
					if((status & STATUS_TERMINATING) != 0)
					{
						// terminating so just exit
						setOpStatus(STATUS_SHUTDOWN);
						return;
					}
					else if((status & STATUS_PAUSING) != 0)
					{
						// set to pausing and let next loop 
						// handle calling wait
						setOpStatus(STATUS_PAUSED);
					}
					else if((status & STATUS_RESUMING) != 0)
					{
						// set the status to normal

						setOpStatus(STATUS_NORMAL);
					}
					else if((status & STATUS_PAUSED) != 0)
					{
						//
						// The thread is paused or there is currently 
						// no address ready to be polled
						//
						try
						{
							wait();
						}
						catch(InterruptedException e)
						{
							// thread interrupted so terminate
							setOpStatus(STATUS_TERMINATING);
						}
					}
					else if((status & STATUS_NORMAL) != 0)
					{
						break; // exit the inner for(;;) loop
					}
				} // end inner for(;;)
			} // end synchronization
			

			// if the m_requestQ is empty, register with the queue for
			// notification on add and wait for  signal from queue
			// or signal due to status change
			boolean waitForQueue = false;
			synchronized(m_requestQ)
			{
				if(m_requestQ.entries() == 0)
				{
					m_requestQ.oneShotNotifyAllOnAdd(this);
                    			waitForQueue = true;
                		}
            		}

            		if(waitForQueue)
            		{
				synchronized(this)
				{
                			try
                			{
       						wait(); // queue or status change can signal
                			}
                			catch(InterruptedException ie)
                			{
                			}
				}

				// if status is not normal, continue and handle
				// status change
				int status = getOpStatus();
				if((status & STATUS_NORMAL) != STATUS_NORMAL)
					continue;
            		}

			//
			// Status must be equal to STATUS_NORMAL at this point
			//
			try
			{
				// Get Next Object from Q
				IPPollAddress pollAddr = (IPPollAddress)m_requestQ.read();

				Log.print(Log.INFORMATIONAL, 
					  getName() + " to ping " + 
					  pollAddr.getAddress());
							  
				synchronized(m_sync)
				{
					m_addr = pollAddr;
					m_responded = false;
				}
			}
			catch(QueueClosedException e) 
			{
				setOpStatus(STATUS_TERMINATING);
				break;
			}
			catch(InterruptedException e) 
			{ 
				setOpStatus(STATUS_TERMINATING);
				break;
			}

			synchronized(m_sync)
			{
				if(m_addr == null)
				{
					continue; // go to top of loop
				}
			}

			//
			// construct a new ping packet with this 
			// thread's id and then set the filter id.
			// lastly computer the checksum and get the
			// buffer.
			//
			DiscPingPacket pingPkt = new DiscPingPacket(m_tid);
			pingPkt.setIdentity(m_filterID);
			pingPkt.computeChecksum();
			byte [] pktArray = pingPkt.toBytes();
			
			//
			// if the VM is doing a mark and sweep (garbage collection)
			// let's give it a head start.
			//
			pingPkt = null;

			//
			// Get the Internet Address to query
			//
			InetAddress inetAddr = null;
			try
			{
				inetAddr = InetAddress.getByName(m_addr.getAddress());
			}
			catch (UnknownHostException uhe)
			{
				m_addr = null;
				continue;
			}
			
			//
			// create the actual message that will
			// be sent to the icmp daemon
			//
			DataSendMessage msg = new DataSendMessage(inetAddr, pktArray);

			/* Make the required attempts */
			int iAttempts = 0;
			while(iAttempts <= m_addr.getRetries())
			{
				//
				// check shutdown status
				//
				if((getOpStatus() & STATUS_TERMINATING) != 0)
					break; // exit the while loop
			
				try
				{
					//
					// loop until a token is granted
					//
					while(!m_limiter.acquire())
						/* do nothing */;
				}
				catch(InterruptedException e)
				{
					//
					// The packet limiter object uses
					// its wait() method to help release
					// the monitors held by the thread. Thus
					// it is subject to interruption. An
					// interruption means that it's time to exit.
					//
					setOpStatus(STATUS_TERMINATING);
					break; // exit the while loop
				}

				//
				// Don't know how long we waited to 
				// reacquire the monitors so 
				// check the status again
				//
				if((getOpStatus() & STATUS_TERMINATING) != 0)
					break;


				// Send
				try
				{
					synchronized(m_sync)
					{
						++iAttempts;
						m_portal.sendMessage(msg);
						Log.print(Log.INFORMATIONAL, 
							  getName() + " sent request " 
							  + iAttempts + " for " + 
							  m_addr.getAddress());
							 
						m_sync.wait(m_addr.getTimeout());
						
						if(m_responded == true)
						{
							iAttempts = (int)m_addr.getRetries() + 1;
							break;
						}
					}
				}
				catch(IOException e)
				{
					//
					// go to the top of while loop
					//
					continue;
				}
				catch(InterruptedException e)
				{
					// exit stage left
					setOpStatus(STATUS_TERMINATING);
					break;
				}
			}

			/**
			 * Once we are here,  we have either gotten a response
			 * or exhausted all retries
			 */
			synchronized(m_sync)
			{
				if (!m_responded)
					Log.print(Log.INFORMATIONAL, 
						  getName() + " exhausted retries for " 
						  + m_addr.getAddress());
			
				m_addr = null;
				m_responded = false;
			}
		}
 	}
}

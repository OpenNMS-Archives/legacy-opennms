//
// Copyright (C) 2000 N*Manage Company Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
// $Id: ServiceMonitorDNS.java,v 1.6 2000/11/14 21:32:10 mike Exp $
//
package org.opennms.bb.dp.poller.plugins;

import java.net.*;
import java.util.*;
import java.io.*;
import java.lang.*;
import java.util.Properties;

import org.opennms.protocols.ip.*;
import org.opennms.bb.dp.poller.plugins.*;
import org.opennms.bb.dp.capsd.plugin.dns.*;

import org.opennms.bb.common.components.Log; // Debug purposes only

/**
 * <P>This class is designed to be used by the service poller
 * framework to test the availability of the DNS service on 
 * remote interfaces. The class implements the ServiceMonitor
 * interface that allows it to be used along with other
 * plug-ins by the service poller framework.</P>
 *
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version CVS $Revision: 1.6 $
 *
 */
public class ServiceMonitorDNS implements ServiceMonitor
{	
	/** 
	 * Name of monitored service.
	 */
	private static final String SERVICE_NAME	= "DNS";

	/** 
	 * Default DNS port.
	 */
	private static final int DEFAULT_PORT = 53;

	/** 
	 * Default retries.
	 */
	private static final int DEFAULT_RETRY = 0;

	/** 
	 * Default timeout.  Specifies how long (in milliseconds) to block waiting
	 * for data from the monitored interface.
	 */
	private static final int DEFAULT_TIMEOUT = 5000; 

	/**
	 * <P>Returns the name of the service that the plug-in monitors ("DNS").</P>
	 *
	 * @return The service that the plug-in monitors.
	 */
	public String serviceName()
	{
		return SERVICE_NAME;
	}
	
	/**
	 * <P>Initialize the service monitor.</P>
	 *
	 * @param proxy		The object that can be used to load/save config information.
	 * @param parameter	The parameters from the appropiate package(s).
	 *
	 * @exception org.opennms.bb.dp.poller.plugins.ServiceMonitorException	Thrown if
	 * 	an unrecoverable error occurs that prevents the plug-in from functioning.
	 *
	 */
	public void initialize(ConfigurationProxy proxy, Properties parameters) 
		throws ServiceMonitorException
	{
		return;
	}
		
	/**
	 * <P>Called by the poller framework when the plug-in is being unloaded.
	 * Any resources still being used by the monitor are released.</P>
	 *
	 * @exception org.opennms.bb.dp.poller.plugins.ServiceMonitorException	Thrown if
	 * 	an error occurs during deallocation.
	 *
	 */
	public void release() 
		throws ServiceMonitorException
	{
		return;
	}
	
	/**
	 * <P>Called by the poller framework when an interface is being added
	 * to the scheduler.  Here we perform any necessary initialization
	 * to prepare the NetworkInterface object for polling.</P>
	 *
	 * @param iface		The network interface to be added to the scheduler.
	 *
	 * @exception org.opennms.bb.dp.poller.plugins.ServiceMonitorException	Thrown if
	 * 	an unrecoverable error occurs that prevents the interface from being monitored.
	 *
	 */
	public void initialize(NetworkInterface iface) 
		throws ServiceMonitorException
	{
	 	return;
	}
	
	/**
	 * <P>Called by the poller framework when an interface is being removed from
	 * the scheduler.  Here we free any resources or save any persistent 
	 * information associated with the interface.</P>
	 *
	 * <P>If an exception is thrown during the release the exception will be
	 * logged, but the interface will still be discarded for garbage collection.</P>
	 *
	 * @param iface		The network interface that was being monitored.
	 *
	 * @exception org.opennms.bb.dp.poller.plugins.ServiceMonitorException	Thrown if
	 * 	an unrecoverable error occurs for the interface.
	 */
	public void release(NetworkInterface iface) 
		throws ServiceMonitorException
	{
		return;
	}
	
	/**
	 * <P>Poll the specified address for DNS service availability.</P>
	 *
	 * <P>During the poll an DNS address request query packet is generated
	 * for hostname 'localhost'.  The query is sent via UDP socket to the
	 * interface at the specified port (by default UDP port 53).  If a 
	 * response is received, it is parsed and validated.  If the DNS lookup
	 * was successful the service status is set to SERVICE_AVAILABLE and the
	 * method returns.</P>
	 *
	 * @param iface		The network interface to test the service on.
	 * @param eproxy 	The event proxy object for sending custom events.
	 * @param parameters	The package parameters (timeout, retry, etc...) to be 
	 *  used for this poll.
	 *
	 * @return The availibility of the interface and if a transition event
	 * 	should be supressed.
	 *
	 */
	public int poll(NetworkInterface iface, EventProxy eproxy, Properties parameters) 
		throws ServiceMonitorException
	{
		int serviceStatus = SERVICE_UNAVAILABLE;
		InetAddress inetAddr = null;

		int retry = DEFAULT_RETRY;  		// Number of additional attempts to be made.
		int port = DEFAULT_PORT;  			// Port which will be tested for the DNS service.
		int timeout = DEFAULT_TIMEOUT;  	// How long to block waiting for data (in milliseconds).
		String lookup = null;				// Host name used for DNS lookups

		// 
		// Process parameters
		//

		// Retry
		String strRetry = parameters.getProperty("retry");
		if(strRetry != null)
		{
			try	{ retry = Integer.parseInt(strRetry);	}
			catch(NumberFormatException ne) { retry = DEFAULT_RETRY; }	
		} 
		
		// Port
		String strPort = parameters.getProperty("port");
		if(strPort != null)
		{
			try	{ port = Integer.parseInt(strPort);	}
			catch(NumberFormatException ne) { port = DEFAULT_PORT; }	
		} 

		// Timeout
		String strTimeout = parameters.getProperty("timeout");
		if (strTimeout == null)
			timeout = DEFAULT_TIMEOUT;
	    else
		{
			try
			{
				timeout = (int)convertTimeToLong(strTimeout);
			}
			catch(NumberFormatException ne) { timeout = DEFAULT_TIMEOUT; }
		}

		// Lookup
		lookup = parameters.getProperty("lookup");
		if (lookup == null)
		{
			// Get hostname of local machine for future DNS lookups
			try 
			{
				lookup = InetAddress.getLocalHost().getHostName();
			}
			catch(UnknownHostException ukE)
			{
				//
				// Recast the exception as a Service Monitor Exception
				//
				throw new ServiceMonitorException("Get local host address generated unknown host exception: " + ukE.getMessage());
			}
		}
				
		//
		// Get interface address from NetworkInterface
		//
		if (iface.getType() != iface.TYPE_IPV4)
			throw new ServiceMonitorException("Unsupported interface type, only TYPE_IPV4 currently supported");

		IPv4Address ipv4Addr = (IPv4Address)iface.getAddress();

		DNSAddressRequest request = new DNSAddressRequest(lookup);

		try
		{
			// Convert address to InetAddress for use in socket() call
			inetAddr = InetAddress.getByName(ipv4Addr.toString());
		}
		catch(Exception e)
		{
			// Throw ServiceMonitorException?
			return serviceStatus;
		}

		Log.print(Log.DEBUG, "ServiceMonitorDNS.poll: address: " + ipv4Addr.toString() + " timeout: " + timeout + " retry: " + retry);
		try 
		{
			DatagramSocket socket = new DatagramSocket();
			socket.setSoTimeout(timeout);
			
			try 
			{
				for (int attempts=0; attempts <= retry && serviceStatus != SERVICE_AVAILABLE; attempts++)
				{
					try 
					{
						sendRequest(request, socket, inetAddr, port);
						getResponse(request, socket);
						serviceStatus = SERVICE_AVAILABLE;
					} 
					catch (InterruptedIOException ex) 
					{
						// Ignore
					}
				}
			} 
			finally 
			{
				socket.close ();
			}
		} 
		catch (IOException ex) 
		{
			// ignore
			Log.print(Log.DEBUG, "ServiceMonitorDNS.poll: IOException while polling address '" + ipv4Addr.toString() + "': " + ex);
		}
	
		//
		// return the status of the service
		//
		return serviceStatus;
	}

	/**
	 * <P>Sends a DNSAddressRequest to the name server.</P>
	 *
	 * @param request	The address request to send to the name server.
	 * @param socket	The datagram socket the request is sent on.
	 * @param nameServer	The nameserver address for the packet destination.
	 * @param port		The port number to send the address.
	 *
	 * @exception java.io.IOException	Thrown if an error occurs while
	 *	sending the datagram packet.
	 */
	private void sendRequest(DNSAddressRequest 	request, 
				 DatagramSocket 	socket, 
				 InetAddress 		nameServer,
				 int			port) 
		throws IOException 
	{
		byte[] data = request.buildRequest();
		DatagramPacket packet = new DatagramPacket(data, 
							   data.length, 
							   nameServer, 
							   port);
		socket.send(packet);
	}

	/**
	 * <P>Receives the data packet and retrieves 
	 * the address from the packet.</P> 
	 *
	 * @param request	the DNSAddressRequest whose response is to be got
	 * @param socket	the socket on which the response  is recieved
	 *
	 * @exception java.io.IOException  Thrown if response is not decoded
	 *	as expected.
	 */
	private void getResponse(DNSAddressRequest request, 
				 DatagramSocket socket) 
		throws IOException 
	{
		byte[] buffer = new byte[512];
		DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
		socket.receive(packet);
		request.receiveResponse(packet.getData(), packet.getLength());
	}

	/**
	 * <P>Converts the passed time string to a time value that is 
	 * measured in milliseconds. The following extension are considered
	 * when converting the string:</P>
	 *
	 * <TABLE BORDER=0>
	 *	<TR><TH>Extension</TH><TH>Conversion Value</TH></TR>
	 *	<TR><TD>us</TD><TD>Microseconds</TD></TR>
	 *	<TR><TD>ms</TD><TD>Milliseconds</TD></TR>
	 *	<TR><TD>s</TD><TD>Seconds</TD></TR>
	 *	<TR><TD>m</TD><TD>Minutes</TD></TR>
	 *	<TR><TD>h</TD><TD>Hours</TD></TR>
	 *	<TR><TD>d</TD><TD>Days</TD></TR>
	 * </TABLE>
	 *
	 * <P>A number entered with out any units is considered to be
	 * in milliseconds.</P>
	 *
	 * @param valueToConvert	The string to convert to milliseconds.
	 *
	 * @return Returns the string converted to a millisecond value.
	 *
	 * @exception java.lang.NumberFormatException Thrown if the string is
	 * 	malformed and a number cannot be extracted from the value.
	 *
	 */
	private static long convertTimeToLong(String valueToConvert)
		throws NumberFormatException
	{
		String timeVal = valueToConvert.toLowerCase();
		int   index    = 0;
		float factor   = 1.0f;

		if(timeVal.endsWith("us"))
		{
			factor = 0.001f;
			index  = timeVal.indexOf("us");
		}
		else if(timeVal.endsWith("ms"))
		{
			factor= 1.0f;
			index = timeVal.indexOf("ms");
		}
		else if(timeVal.endsWith("s"))
		{
			factor = 1000.0f;
			index = timeVal.indexOf("s");
		}
		else if(timeVal.endsWith("m"))
		{
			factor = 1000.0f * 60.0f;
			index = timeVal.indexOf("m");
		}
		else if(timeVal.endsWith("h"))
		{
			factor = 1000.0f * 60.0f * 60.0f;
			index = timeVal.indexOf("h");
		}
		else if(timeVal.endsWith("d"))
		{
			factor = 1000.0f * 60.0f * 60.0f * 24.0f;
			index = timeVal.indexOf("d");
		}
		
		if(index == 0)
		{
			index = timeVal.length();
		}
		
		Float fVal = new Float(timeVal.substring(0, index));
		return ((long)(fVal.floatValue() * factor));
		
	} // end convertTimeToLong()
}

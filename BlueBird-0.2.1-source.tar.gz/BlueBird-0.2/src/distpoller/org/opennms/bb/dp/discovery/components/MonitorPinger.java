//
// Copyright (C) 2000 N*Manage Company Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
// Tab Size = 8
//
// $Id: MonitorPinger.java,v 1.2 2000/11/09 23:30:22 mike Exp $
//

package org.opennms.bb.dp.discovery.components;

import java.net.*;
import java.io.*;

import com.sun.media.jsdt.*;

import org.opennms.protocols.ip.*;
import org.opennms.protocols.icmpd.*;
import org.opennms.bb.common.components.*;
import org.opennms.bb.dp.common.components.PollerClient;
import org.opennms.bb.dp.common.components.PollerThread;
import org.opennms.bb.dp.poller.plugins.PollResponseAddress;

/**
 * <P>MonitorPinger is another type of thread that is maintained in the
 * ping manager's thread pool(the other being DiscPinger). This type of
 * thread is responsible for creating, sending and retrying the PING packets
 * as well as notifying the ICMP Service Monitor via JSDT of the result
 * of the PING attempt(s).</P>
 *
 * <P>Note however that object does not directly receive echo replies. The 
 * manager receives the replies and notifies this thread that a response 
 * to the request sent out has been received</P>
 *
 * @author <A HREF="mailto:mike@opennms.org">Mike</A>
 * @author <A HREF="mailto:sowmya@opennms.org">Sowmya</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version $Revision: 1.2 $
 */
public final class MonitorPinger extends PollerThread
{
	/**
	 * JSDT channel through which replies are sent to the ICMP service monitor.
	 */
	private static Channel			m_channel;

	/**
	 * JSDT client identifier
	 */
	private static PollerClient 	m_client;

	/** 
	 * This the prefix for the JSDT client to which ICMP poll result
	 * messages will be sent.  The unique id which identifies the
	 * instance of the ICMP service monitor which sent the request
	 * will be appended to this prefix in order to ensure that only the
	 * monitor instance that sent the request gets the reply.
	 *
	 * WARNING:  This value must match the prefix defined in 
	 * 		the ServiceMonitorICMP class.
	 */
	private static final String JSDT_CLIENT_RECEIVER_NAME_PREFIX = "MonitorReplyRecv:";

	/**
	 * <P>The thread key for this particular thread. This key
	 * is placed into all the icmp echo requests that are sent
	 * by this thread. The manager can the use this id to find
	 * the sending thread.</P>
	 */
	private long			m_tid;
	
	/**
	 * <P>The monitor request queue is the link between the discovery
	 * system and the ICMP service monitor. The queue is used to hold
	 * IPPollAddress objects used by Monitor Pinger objects to generate
	 * ICMP requests directed at remote nodes.  The data contained by
	 * an IPPollAddress object (IP address, timeout, retries) is received
	 * via a JSDT connection with the ICMP service monitor.</P>
	 */
	private PCQueue		m_monitorRequestQ;

	/**
	 * <P>This is the connection to the icmp daemon that sends
	 * and receives request for the discovery process. Since 
	 * most process must have superuser privilage to send and
	 * receive icmp messages, the icmpd is used to isolate the
	 * java code from the operating system.</P>
	 */
	private DaemonConnection	m_portal;
	
	/**
	 * <P>This is the filterID to include in the icmp
	 * echo request message. Unless this id is included
	 * in the sending packet the echo reply will be 
	 * discarded by the icmpd.</P>
	 */
	private short			m_filterID;

	/**
	 * <P>This object is used to synchronize access to
	 * the m_addr and m_responded. Those member variables
	 * should not be modified unless the lock for m_sync
	 * is held. Also, while waiting on those modification
	 * the m_sync.wait() will be called instead of the
	 * thread's wait() method.</P>
	 */
	private Object			m_sync;

	/**
	 * <P>The discover ping manager.</P>
	 */
	private DiscPingManager	m_pingMgr;	

	/**
	 * <P>The IP Address object to poll.</P>
	 */
	private IPPollAddress		m_addr;		// access ctrl m_sync
	
	/**
	 * <P>When the manager calls the receive method
	 * this variable will be updated with the value
	 * of true if the responding address matches the
	 * value of m_addr.</P>
	 */
	private boolean			m_responded;	// access ctrl m_sync
	
	/**
	 * <P> Static method for setting the JSDT channel through
	 * which the MonitorPinger threads will forward ICMP poll
	 * results to the ICMP service monitor.</P> 
	 *
	 * @param replyChannel	The JSDT channel for sending replies
	 */ 
	public static void setChannel(Channel replyChannel)
	{
		m_channel = replyChannel;
	}

	/**
	 * <P> Static method for retrieving the JSDT channel through
	 * which the MonitorPinger threads forwards ICMP poll
	 * results to the ICMP service monitor.</P> 
	 *
	 * @return The JSDT channel for replies or null if not set
	 */ 
	public static Channel getChannel()
	{
		return m_channel;
	}

	/**
	 * <P> Static method for setting the JSDT client through
	 * which the MonitorPinger threads will forward ICMP poll
	 * results to the ICMP service monitor.</P> 
	 *
	 * @param replyChannel	The JSDT client for sending replies
	 */ 
	public static void setClient(PollerClient replyClient)
	{
		m_client = replyClient;
	}

	/**
	 * <P> Static method for retrieving the JSDT client through
	 * which the MonitorPinger threads forwards ICMP poll
	 * results to the ICMP service monitor.</P> 
	 *
	 * @return The JSDT client for replies or null if not set
	 */ 
	public static PollerClient getClient()
	{
		return m_client;
	}

	/**
	 * <P>This static class is used to build a compliant SOAP
	 * document that is sent to the ICMP service monitor. No 
	 * instances of this class may be created.</P>
	 */
	private static final class ReplyToSoapDocument
	{
		/**
		 * SOAP Envelope tag, fully qualified
		 */
		private static final String SOAP_ENV	= "SOAP-ENV:Envelope";
		
		/**
		 * SOAP Body tag, fully qualified.
		 */
		private static final String SOAP_BODY	= "SOAP-ENV:Body";
		
		/**
		 * SOAP Namespace string
		 */
		private static final String SOAP_NS	= "http://schemas.xmlsoap.org/soap/envelope/";
		
		/**
		 * SOAP Namespace tag.
		 */
		private static final String SOAP_NSTAG	= "SOAP-ENV";
		
		//
		// Relevant XML tags
		//
		private static final String MONITOR_RESPONSE	= "Discovery:MonitorResponse";
		private static final String RESPONSE 			= "Discovery:response";
		private static final String IPV4ADDR 			= "Discovery:ipv4Address";
		private static final String STATUS				= "Discovery:status";
		
		/**
		 * Document namespace
		 */
		private static final String DISC_NS	= "http://dtds.opennms.org/bluebird/discovery/MonitorResponse/";
		
		/**
		 * Document namespace tag.
		 */
		private static final String DISC_NSTAG	= "Discovery";
		
		/**
		 * Creates a proper XML start tag.
		 *
		 * @param tag	The tag name
		 * @param out	The output stream.
		 */
		private static void startTag(String tag, PrintStream out)
		{
			out.println("<" + tag + ">");
		}
		
		/**
		 * Creates a proper XML start tag with namespace
		 *
		 * @param tag	The tag name
		 * @param ns	The namespace uri
		 * @param nstag	The namespace tag for the uri
		 * @param out	The output stream.
		 */
		private static void startTag(String tag, String ns, String nstag, PrintStream out)
		{
			out.println("<" + tag + " xmlns:" + nstag + "=\"" + ns + "\">");
		}
		
		/**
		 * Creates a proper XML end tag.
		 *
		 * @param tag	The tag name
		 * @param out	The output stream.
		 */
		private static void endTag(String tag, PrintStream out)
		{
			out.println("</" + tag + ">");
		}
		
		/**
		 * <P>Generates a properly formatted XML SOAP document
		 * that is suitable for requesting an ICMP service monitor
		 * poll request.</P>
		 *
		 * @param address	The IPv4 address in dotted decimal format
		 * @param status The result of the ICMP poll:  "available" or "unavailable"
		 *
		 * @return The document as a byte array.
		 */
		public static synchronized byte[] generate(String address, String status)
		{
			ByteArrayOutputStream bout = new ByteArrayOutputStream();
			PrintStream prn = new PrintStream(bout);
			
			startTag(SOAP_ENV, SOAP_NS, SOAP_NSTAG, prn);
				startTag(SOAP_BODY, prn);
					startTag(MONITOR_RESPONSE, DISC_NS, DISC_NSTAG, prn);
						startTag(RESPONSE, prn);
							startTag(IPV4ADDR, prn);
								prn.println(address);
							endTag(IPV4ADDR, prn);
							startTag(STATUS, prn);
								prn.println(status);
							endTag(STATUS, prn);
						endTag(RESPONSE, prn);
					endTag(MONITOR_RESPONSE, prn);
				endTag(SOAP_BODY, prn);
			endTag(SOAP_ENV, prn);
			prn.flush();
			
			return bout.toByteArray();
		}
	}	

	/**
	 * <P>Creates a new monitor ping thread that will
	 * attempt to poll addresses as they are added to the
	 * request queue.</P>
	 *
	 * @param pingMgr	The thread manager
	 * @param lThreadId	The thread identifer used by the manager.
	 * @param Q			The Q from which to read off the address to ping
	 * @param portal	The connection to the icmp daemon.
	 * @param pingFilterID	The filter id used by the icmp daemon.
	 *
	 */
	public MonitorPinger(DiscPingManager pingMgr,
			  long 	lThreadID, 
			  PCQueue			requestQ,
			  DaemonConnection 	portal, 
			  short 			pingFilterID)
	{
		super("MonitorPinger" + lThreadID);

		m_pingMgr 	= pingMgr;
		m_tid		= lThreadID;
		m_monitorRequestQ	= requestQ;
		m_portal	= portal;
		m_filterID	= pingFilterID;
		m_sync		= new Object();
		m_responded	= false;
		m_addr		= null;
	}

			

	/**
	 * <P>Return the current IP Address being polled
	 * by this thread. If no address is being polled
	 * then a null pointer will be returned.</P>
	 */
	public IPPollAddress getIPAddress()
	{
		synchronized(m_sync)
		{
			return m_addr;
		}
	}

	
	/**
	 * <P>Returns the thread id as specified by the manager.</P>
	 */
	public long getThreadID()
	{
		return m_tid;
	}


	/**
 	 * <P>The ping manager calls this function to indicate that 
 	 * the request sent by this thread has been received. If
	 * the thread is currently attempting to query the remote
	 * host then a value of true will be returned.</P>
	 *
	 * @param ipAddress	The remote echo reply address.
	 *
	 * @return True if the ipAddress matches the queried node.
	 *
 	 */
	public synchronized boolean received(String ipAddress)
	{	
		boolean bRet 	= false;
		int	status	= getOpStatus();
		
		if((status & STATUS_NORMAL) != 0 )
		{
			synchronized(m_sync)
			{
				if(m_addr != null && m_addr.getAddress().equals(ipAddress))
				{
					Log.print(Log.INFORMATIONAL, "Reply Received For: " + ipAddress + "\n");
					bRet = true;
					m_responded = true;
					m_sync.notifyAll();
				}
			}
		}
		return bRet;
	}

	/**
	 * <P>The run() method does the hard work of the monitor
	 * poller thread. It waits for new addresses to be served
	 * out by the Monitor Request Receiver and then polls each address. When
	 * either the retries are exhausted or the manager informs
	 * the object that the remote has responded, the thread
	 * will go back to an idle state and wait for a new address.</P>
	 *
	 */
	public void run()
	{
		/*
		 * let the manager know that were ready!
		 */
		setOpStatus(STATUS_NORMAL);
		
		for(;;)
		{
			//
			// Synchronize around all the status checks. This
			// is due to the PollerThread class design. The base
			// class will notifyAll() on itself when a status
			// change occurs.
			//
			synchronized(this)
			{
				
				//
				// Process the current status
				//
				for(;;)
				{
					int status = getOpStatus();
				
					if((status & STATUS_TERMINATING) != 0)
					{
						// terminating so just exit
						setOpStatus(STATUS_SHUTDOWN);
						return;
					}
					else if((status & STATUS_PAUSING) != 0)
					{
						// set to pausing and let next loop 
						// handle calling wait
						setOpStatus(STATUS_PAUSED);
					}
					else if((status & STATUS_RESUMING) != 0)
					{
						// set the status to normal

						setOpStatus(STATUS_NORMAL);
					}
					else if((status & STATUS_PAUSED) != 0)
					{
						//
						// The thread is paused or there is currently 
						// no address ready to be polled
						//
						try
						{
							wait();
						}
						catch(InterruptedException e)
						{
							// thread interrupted so terminate
							setOpStatus(STATUS_TERMINATING);
						}
					}
					else if((status & STATUS_NORMAL) != 0)
					{
						break; // exit the inner for(;;) loop
					}
				} // end inner for(;;)
			} // end synchronization
			

			// if the m_monitorRequestQ is empty, register with the queue for
			// notification on add and wait for  signal from queue
			// or signal due to status change
			boolean waitForQueue = false;
			synchronized(m_monitorRequestQ)
			{
				if(m_monitorRequestQ.entries() == 0)
				{
					m_monitorRequestQ.oneShotNotifyAllOnAdd(this);
                	waitForQueue = true;
                }
           	}

            if(waitForQueue)
            {
				synchronized(this)
				{
                	try
                	{
       					wait(); // queue or status change can signal
                	}
                	catch(InterruptedException ie)
                	{
                	}
				}

				// if status is not normal, continue and handle
				// status change
				int status = getOpStatus();
				if((status & STATUS_NORMAL) != STATUS_NORMAL)
					continue;
            }

			//
			// Status must be equal to STATUS_NORMAL at this point
			//
			try
			{
				// Get Next Object from Q
				IPPollAddress pollAddr = (IPPollAddress)m_monitorRequestQ.read();

				Log.print(Log.INFORMATIONAL, 
					  getName() + " to ping " + 
					  pollAddr.getAddress());
						
				// Allow the manager to see if there is a
				// need to increase the number of threads
				m_pingMgr.threadsVsQueueSizeCheck();
					  
				synchronized(m_sync)
				{
					m_addr = pollAddr;
					m_responded = false;
				}
			}
			catch(QueueClosedException e) 
			{
				setOpStatus(STATUS_TERMINATING);
				break;
			}
			catch(InterruptedException e) 
			{ 
				setOpStatus(STATUS_TERMINATING);
				break;
			}

			synchronized(m_sync)
			{
				if(m_addr == null)
				{
					continue; // go to top of loop
				}
			}

			//
			// construct a new ping packet with this 
			// thread's id and then set the filter id.
			// lastly computer the checksum and get the
			// buffer.
			//
			DiscPingPacket pingPkt = new DiscPingPacket(m_tid);
			pingPkt.setIdentity(m_filterID);
			pingPkt.computeChecksum();
			byte [] pktArray = pingPkt.toBytes();
			
			//
			// if the VM is doing a mark and sweep (garbage collection)
			// let's give it a head start.
			//
			pingPkt = null;

			//
			// Get the Internet Address to query
			//
			InetAddress inetAddr = null;
			try
			{
				inetAddr = InetAddress.getByName(m_addr.getAddress());
			}
			catch (UnknownHostException uhe)
			{
				m_addr = null;
				continue;
			}
			
			//
			// create the actual message that will
			// be sent to the icmp daemon
			//
			DataSendMessage msg = new DataSendMessage(inetAddr, pktArray);

			/* Make the required attempts */
			int iAttempts = 0;
			Log.print(Log.DEBUG, getName() + " addr: " + 
						m_addr.getAddress() + " retries: " + m_addr.getRetries() + 
						" timeout: " + m_addr.getTimeout());
			while(iAttempts <= m_addr.getRetries())
			{
				//
				// check shutdown status
				//
				if((getOpStatus() & STATUS_TERMINATING) != 0)
					break; // exit the while loop

				// Send
				try
				{
					synchronized(m_sync)
					{
						++iAttempts;
						m_portal.sendMessage(msg);
						Log.print(Log.INFORMATIONAL, 
							  getName() + " sent request " 
							  + iAttempts + " for " + 
							  m_addr.getAddress());
							 
						m_sync.wait(m_addr.getTimeout());
						
						if(m_responded == true)
						{
							iAttempts = (int)m_addr.getRetries() + 1;
							break;
						}
					}
				}
				catch(IOException e)
				{
					//
					// go to the top of while loop
					//
					continue;
				}
				catch(InterruptedException e)
				{
					// exit stage left
					setOpStatus(STATUS_TERMINATING);
					break;
				}
			}

			//
			// Once we are here,  we have either gotten a response
			// or exhausted all retries
			//
			synchronized(m_sync)
			{
				String status=null;

				if (!m_responded)
				{
					Log.print(Log.INFORMATIONAL, getName() + " exhausted retries for "  + m_addr.getAddress());
					status = PollResponseAddress.STATUS_UNAVAILABLE;;
				}
				else
				{
					Log.print(Log.DEBUG, getName() + " received response for "  + m_addr.getAddress());
					status = PollResponseAddress.STATUS_AVAILABLE;;
				}
			
				// Send reply with result of poll back to ICMP service monitor via JSDT
				Data data = new Data(ReplyToSoapDocument.generate(m_addr.getAddress(), status));
				try
				{
					// synchronize on the channel to avoid
					// conflicts with multiple threads attempting
					// to send simultaneously.
					synchronized(m_channel)
					{
						//m_channel.sendToOthers(m_client, data);
						
					    // Parse out unique ID from sender client name and build reply client name
						// Sender client name has format: "MonitorRequestSend:<unique_id>"
						String sender = m_addr.getSenderName();
						int index = sender.lastIndexOf(':');
					    String id = sender.substring(index + 1);
						sender = JSDT_CLIENT_RECEIVER_NAME_PREFIX + id;
						Log.print(Log.DEBUG, "Client name where reply will be sent: '" + sender + "'");
						m_channel.sendToClient(m_client, sender, data);
						
					}
					Log.print(Log.DEBUG, getName() + " SOAP/XML generated and sent to ICMP service monitor");
				}
				catch (JSDTException jsdte)
				{
					setOpStatus(STATUS_TERMINATING);
				}
				
				m_addr = null;
				m_responded = false;
			}
		}
 	}
}

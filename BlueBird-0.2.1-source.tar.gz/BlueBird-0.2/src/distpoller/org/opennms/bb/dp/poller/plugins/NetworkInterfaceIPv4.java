//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.dp.poller.plugins;

import java.util.*;

import org.opennms.protocols.ip.*;

/**
 * This class implements the NetworkInterface interface for IPv4
 * addresses.  Currently only used for the purpose of testing
 * the service monitor implementations.
 * 
 * @author <A HREF="mailto:mike@opennms.org">Mike</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version $Revision: 1.1 $
 * 
 */
public class NetworkInterfaceIPv4 implements NetworkInterface
{	
	private static final int m_type = TYPE_IPV4;

	private static IPv4Address m_interface;

	private static Map m_attributes;

	public NetworkInterfaceIPv4(String address)
	{
		m_interface = new IPv4Address(address);
		m_attributes = new HashMap();
	}

	public int getType()
	{
		return m_type;
	}

	public Object getAddress()
	{
		return m_interface;		
	}

	public Object getAttribute(String property)
	{
		return m_attributes.get(property);
	}

	public Object setAttribute(String property, Object value)
	{
		return m_attributes.put(property, value);
	}
}

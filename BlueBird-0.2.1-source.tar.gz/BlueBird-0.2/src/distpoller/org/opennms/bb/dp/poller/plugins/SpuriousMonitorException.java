//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
// $Id: SpuriousMonitorException.java,v 1.2 2000/10/28 22:17:39 shaneo Exp $

package org.opennms.bb.dp.poller.plugins;

/** 
 * <P>This class is used by a service monitor to encapsulate an 
 * unexpected exception that it does not know how to handle. The
 * exception is wrapped in the thrown instance that is caught
 * by the framework.</P>
 *
 * @author <A HREF="mailto:weave@opennms.org">Weave</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version $Revision: 1.2 $
 * 
 */
public class SpuriousMonitorException extends ServiceMonitorException
{
	/**
	 * The unexpected exception that is returned to the caller.
	 */
	private Exception m_exception;
	
	/**
	 * Constructs a new exception instance.
	 */
	public SpuriousMonitorException(Exception ex)
	{
		super();
		m_exception = ex;
	}
	
	/**
	 * Constructs a new exception instance with the specific message
	 *
	 * @param msg	The exception message.
	 *
	 */
	public SpuriousMonitorException(String msg, Exception ex)
	{
		super(msg);
		m_exception = ex;
	};
	
	/**
	 * Returns the unexpected exception encapsulated
	 * within this exception instance.
	 *
	 * @return The encapsulated exception
	 */
	public Exception spuriousException()
	{
		return m_exception;
	}
	
	/**
	 * Returns a string representation of this object and its
	 * encapsulated exception.
	 *
	 */
	public String toString()
	{
		String msg = getMessage();
		if(msg.length() == 0)
		{
			msg = "Service Monitor Spurious Exception [ " + m_exception.toString() + " ]";
		}
		else
		{
			msg = msg + " [ " + m_exception.toString() + " ]";
		}
		return msg;
	}
}

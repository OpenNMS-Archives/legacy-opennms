//
// Copyright (C) 2000 N*Manage Company Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
// Tab Stop = 8
//
// $Id: CapsReader.java,v 1.13 2000/10/12 12:47:37 mike Exp $
//
package org.opennms.bb.dp.capsd.components;

import java.net.*;
import java.util.*;
import java.io.*;

import org.opennms.bb.common.components.Log;
import org.opennms.bb.dp.common.components.DBRunnable;

import org.opennms.bb.dp.capsd.snmp.*;
import org.opennms.bb.dp.capsd.plugin.*;
import org.opennms.protocols.snmp.*;
import org.opennms.protocols.ip.IPv4Address;

/**
 * <P>The CapsReader class is used to query a remote host for
 * its SNMP information and the services it supports. The SNMP
 * data collected from the host includes:</P>
 *
 * <UL>
 *	<LI>System Group Information</LI>
 *	<LI>Interface Table</LI>
 *	<LI>IP Address Table</LI>
 *	<LI>IP Route Table</LI>
 *	<LI>IP Network To Media Table</LI>
 * </UL>
 *
 * <P>In addition to collecting the SNMP information, each 
 * discovered interface is queried about the services it 
 * supports. The services are interogated via the plugins
 * provided to the constructor.</P>
 *
 * @author <A HREF="mailto:sowmya@opennms.org">Sowmya</A>
 * @author <A HREF="http://www.opennms.org">OpenNMS</A>
 *
 * @version $Revision: 1.13 $
 */
public final class CapsReader implements Runnable
{
	/**
	 * The lookup string for looking up the value of ifIndex
	 */
	private final static	String	IF_INDEX="ifIndex";
	
	/**
	 * The lookup string for looking up the value of ifType
	 */
	private final static	String	IF_TYPE="ifType";
	
	/**
	 * The lookup string for looking up the value of ipAdEntIfIndex
	 */
	private final static	String	IP_ADDR_IF_INDEX="ipAdEntIfIndex";
	
	/**
	 * The lookup string for looking up the value of ipAdEntAddr
	 */
	private final static	String	IP_ADDR_ENT_ADDR="ipAdEntAddr";
	
	/**
	 * <P>The list of plugin modules. The list is 
	 * used to query for protocol support on each
	 * discovered interface.</P>
	 */
	private List			m_plugins;
	
	/**
	 * <P>The node address that is being queried 
	 * by the reader. The address will be tested
	 * for SNMP support and then by each of the 
	 * service plugins.</P>
	 */
	private IPv4Address		m_nodeAddress;
	
	/** 
	 * duplicate nodes set.  Reader will add the ip
	 * addresses of all the interfaces for the targeted
	 * node if SNMP query is successful
	 */
 	private Set m_dupNodes;

	/**
	 * <P>The SNMP session used to communicate with the 
	 * remote interface.</P>
	 */
	private SnmpSession 		m_session;

	//
	// SNMP tables and information to be collected
	// using the SNMP session.
	//
	
	/**
	 * <P>The SNMP System Group information.</P>
	 */
	private SystemGroup		m_sysGroup;
	
	/**
	 * <P>The remote agents interface table. This
	 * is a collection of interface entries.</P>
	 */
	private IfTable			m_ifTable;
	
	/**
	 * <P>The remote agent's IP Address table.
	 * This can be used to pair interfaces with
	 * their IP Addresses.</P>
	 */
	private IpAddrTable		m_ipAddrTable;
	
	/**
	 * <P>The remote agents routing information.</P>
	 */
	private IpRouteTable		m_ipRouteTable;
	
	/**
	 * <P>The remote agents Network to Media table.</P>
	 */
	private IpNetToMediaTable	m_ipNetToMediaTable;

	/**
	 * <P>Tracks the status of various plugin
	 * modules.</P>
	 */
	private	Dictionary		m_services;

	/**
	 * <P>The SignalAfter class is used to delay the notification
	 * of a signal until a predefined number of "signals" have
	 * occured. It can be though of as a high water mark signaler.
	 * Once the high water mark has been reached each call to signal
	 * or signalAll will always result in the object's notify or
	 * notifyAll being called, respecitively.</P>
	 *
	 * @author <A HREF="mailto:sowmya@opennms.org">Sowmya</A>
	 * @author <A HREF="mailto:weave@opennms.org">Weave</A>
	 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
	 *
	 * @version $Revision: 1.13 $
	 */
	private final class SignalAfter 
		implements Signaler
	{
		/**
		 * <P>The high water mark condition for when
		 * to start passing through notifications.</P>
		 */
		private int	m_notifyAfter;
		
		/**
		 * <P>The number of times that the signal or 
		 * signalAll methods have been called.</P>
		 */
		private	int	m_numNotifies;
		
		/**
		 * <P>Constructs a high watermark signaler object.
		 * The object will have an initial number of notifications
		 * equal to zero, and after when notifications occur the
		 * instance will pass through each successive notification.</P>
		 *
		 * @param when	The high watermark count.
		 */
		public SignalAfter(int when)
		{
			m_notifyAfter = when;
			m_numNotifies = 0;
		}
		
		/**
		 * <P>The signal method follows the same rules
		 * that apply to the java Object's notify method.
		 * The only change is that until the high watermark
		 * is reached, the notification of signals will be 
		 * blocked.</P>
		 *
		 * @see java.lang.Object#notify
		 */
		public void signal()
		{
			if(++m_numNotifies == m_notifyAfter)
			{
				--m_numNotifies; // keeps from wrapping
				notify();
			}
		}
		
		/**
		 * <P>The signal method follows the same rules
		 * that apply to the java Object's notifyAll method.
		 * The only change is that until the high watermark
		 * is reached, the notification of signals will be 
		 * blocked.</P>
		 *
		 * @see java.lang.Object#notifyAll
		 */
		public void signalAll()
		{
			if(++m_numNotifies == m_notifyAfter)
			{
				--m_numNotifies;
				notifyAll();
			}
		}
	}
	
	/** 
	 * <P>This method is used to probe the passed interface address
	 * for service support using the currently loaded plugins. Each
	 * plugin is tested against the interface and a list of supported
	 * ServiceStatus objects are returned to the caller. If there are
	 * no supported services, or the plugins could not be loaded then
	 * a null object is returned.</P>
	 *
	 * @param ifAddr	The interface address to test for services.
	 *
	 * @return A list of ServiceStatus objects for the supporting
	 * 	services or null if no services are found. Additionally,
	 *	if errors occur then a null is returned.
	 */
	private List ifProbe(InetAddress ifAddr)
	{
		//
		// Sanity check
		//
		if(m_plugins == null)
			return null;

		Log.print(Log.DEBUG, "CapsReader.ifProbe: Probing interface " + IPv4Address.addressToString(ifAddr.getAddress()) + " for services via plugins");
		
		List	ifStatus = new ArrayList();
		Iterator iter 	 = m_plugins.iterator();
		
		while(iter.hasNext())
		{
			//
			// Get the plugin information for polling
			//
			List plugin = (List)iter.next();
			
				//
			// Get the data from the plugin. This 
			// includes it's name, capability, java
			// class name, and it's service id.
			//
			String name 	    = (String)plugin.get(0);
			String dbCapability = (String)plugin.get(1);
			String className    = (String)plugin.get(2);
			int serviceID 	    = ((Integer)plugin.get(3)).intValue();

			CapsdPlugin	capsdPlugin  = null;
			Exception 	caught       = null;

			//
			// Try to create an instance of the 
			// plugin to check the interface(s).
			//
			try 
			{
				capsdPlugin = (CapsdPlugin)Class.forName(className).newInstance();
			}
			catch (Exception e)
			{
				caught = e;
			}
			
			//
			// If no exception was genereated by
			// the created of the instance of a capsd
			// plugin element, then actually do the
			// plugin test.
			//
			if(caught == null)
			{
				try
				{
					Log.print(Log.DEBUG, "CapsReader.ifProbe: Testing address " + ifAddr 
							   + " for service " + capsdPlugin.getCapabilityName());
					
					boolean bSup = capsdPlugin.isProtocolSupported(ifAddr, dbCapability);
					
					// ONLY add supported protocols!
					if(bSup)
						ifStatus.add(new ServiceStatus(serviceID, bSup));

					Log.print(Log.DEBUG, "CapsReader.ifProbe: " + ifAddr + " " 
							   + capsdPlugin.getCapabilityName() 
							   + "? : " + bSup);
				}
				catch(Exception e)
				{
					caught = e;
				}
			}
			
			//
			// Do a final test to see if any exceptions
			// were generated during the testing of this
			// plugin. If they were then log the exception
			// and the stack trace to the logger.
			//
			if(caught != null)
			{
				Log.print(Log.WARNING, "CapsReader.ifProbe: Exception from plugin " + dbCapability);
				Log.print(Log.WARNING, caught);
			}
		} // end plugin loop
		
		if(ifStatus.size() == 0)
		{
			Log.print(Log.DEBUG, "CapsReader.ifProbe: No services were found to be supported for address " + ifAddr);
			ifStatus = null;
		}
		
		return ifStatus;
	}

	/**
	 * <P>The probe method is used to check the remote
	 * interfaces discovered by through SNMP for service
	 * support using the registered plugins. The list of 
	 * interfaces are iterated though and probed if the
	 * interface is not unnammed (it must have an IP 
	 * address bound to it).</P>
	 *
	 * <P>The method modifies the serviceStatus dictionary
	 * and associates either a list of ServiceStatus information
	 * or a null with the interfaces address.</P>
	 */
	private void probe()
	{
		//
		// Sanity Check!
		//
		if(m_ifTable == null)
			return;
			
		// loop through the interfaces
		Iterator iter = m_ifTable.getEntries().iterator();
		while(iter.hasNext())
		{
			// get interface address
			String ifStrAddr = null; // needed here for exception
			try
			{
				IfTableEntry  iftEntry = (IfTableEntry)iter.next();
				int ifType = -1;
				SnmpInt32 snmpIfType = (SnmpInt32)iftEntry.get(IF_TYPE);
				if (snmpIfType != null)
					ifType = snmpIfType.getValue();
				
				if (ifType == -1)
					continue;

				if(ifType != 24) 	// IGNORE THE SOFTWARE LOOPBACK!
				{
					int ifIndex = -1;

					SnmpInt32 snmpIfIndex = (SnmpInt32)iftEntry.get(IF_INDEX);
					if (snmpIfIndex != null)
						ifIndex = snmpIfIndex.getValue();

					ifStrAddr = getIpAddress(ifIndex);
					if(ifStrAddr != null)
					{
						InetAddress 	ifAddr   = InetAddress.getByName(ifStrAddr);

						// 
						// Add interface to dupNodes
						//
						Log.print(Log.DEBUG, "CapsReader.probe: adding interface " + ifAddr.getHostAddress() + " to duplicate nodes\n");
						m_dupNodes.add(ifAddr.getHostAddress());
					    
						List		ifStatus = ifProbe(ifAddr);
						if(ifStatus != null)
							m_services.put(ifStrAddr, ifStatus);
					}
				}
			}
			catch(UnknownHostException e)
			{
			 	// how did this happen?
				Log.print(Log.WARNING, "CapsReader.probe: UnknownHostException generated for interface " + ifStrAddr);
				Log.print(Log.WARNING, e);
			}
			catch(Exception e)
			{
			 	// MUST be a runtime exception!?
				if(ifStrAddr != null)
					Log.print(Log.WARNING, "CapsReader.probe: Exception generated for interface " + ifStrAddr);
				else
					Log.print(Log.WARNING, "CapsReader.probe: Exception generated, unknown interface");

				Log.print(Log.WARNING, e);
			}
		} // end interfaces
	}

	/**
	 * <P>Returns the IP Address of the specified interface. The 
	 * interface is specified by the interface's index number from
	 * the remotes interface table. If no corresponding address or
	 * interface is found then a null address is returned.</P>
	 *
	 * @param ifIndex	The interface's index number from the remote
	 *			SNMP agent.
	 *
	 * @return The IP Address string for the interface. Null if the 
	 *	interface or address is not found.
	 *
	 */
	private String getIpAddress(int ifIndex)
	{
		if (ifIndex == -1)
			return null;

		Iterator iter = m_ipAddrTable.getEntries().iterator();
		while(iter.hasNext())
		{
			IpAddrTableEntry ipAddrEntry = (IpAddrTableEntry)iter.next();
			SnmpInt32 snmpIpAddrIndex = (SnmpInt32)ipAddrEntry.get(IP_ADDR_IF_INDEX);
			if (snmpIpAddrIndex == null)
				continue;

			int ipAddrIndex = snmpIpAddrIndex.getValue();
			if (ipAddrIndex ==  ifIndex)
			{
				SnmpIPAddress snmpAddr = (SnmpIPAddress)ipAddrEntry.get(IP_ADDR_ENT_ADDR);
				if (snmpAddr != null)
					return snmpAddr.toString();
				else
					return null;
			}
		}
		return null;
	}

	/**
	 * <P>The class constructor used to create an instance of the
	 * CapsdReader. The constructor will verify the validity of
	 * the passed address and initialize the object to query the
	 * remote host. In order to query the remote host the run
	 * method should be invoked to actually query the host.</P>
	 *
	 * @param ifAddress	The IP Address of the remote interface.
	 * @param plugins	The list of plugin modules to invoke.
	 * @param dupNodes 	Set of ip addresses already known to Capsd.
	 *
	 * @exception java.net.SocketException Thrown if there is an error
	 *	settting up the SnmpSession to query the remote.
	 * @exception java.net.UnknownHostException Thrown if a lookup 
	 * 	error occurs trying to resolve the address of the remote.
	 *
	 * @see org.opennms.protocols.snmp.SnmpSession
	 */
	public CapsReader(String ifAddress, List plugins, Set dupNodes)
	{
		// DEBUG INFORMATION
		Log.print(Log.DEBUG, "CapsReader.<ctor>: New CapsReader instance with ifAddress = " + ifAddress);
		
		//
		// Save the plugin information
		//
		m_plugins = plugins;

		m_nodeAddress = new IPv4Address(ifAddress);

		m_dupNodes = dupNodes;
		
		//
		// NOTE: The SNMP session construction was moved
		// to the run method to prevent abandoned SNMP
		// session which could pervent garbage collection!
		//
		//m_session   = new SnmpSession(m_nodeAddress);
		m_session = null;
		
		//
		// Create the dictionary
		//
		m_services = new Hashtable();

		//
		// Initialize the SNMP variables
		//
		m_sysGroup 		= null;
		m_ifTable  		= null;
		m_ipAddrTable		= null;
		m_ipRouteTable 		= null;
		m_ipNetToMediaTable 	= null;
	}

	/**
	 * <P>The run method is required by the Runnable interface and
	 * actually preforms the bulk of the work for the CapsdReader 
	 * object. When the run method is invoked the reader will attempt
	 * to connect to the remote host's SNMP agent, if any. While
	 * connected to the remote the MIB system group, interface table,
	 * net to media table, and other SNMP objects are collected by
	 * the reader.</P>
	 *
	 * <P>Once the information has been collected by the reader the
	 * SNMP connection is closed and a set of capsd plugin checkers
	 * are run against the remote inteface(s). If there are multiple
	 * interfaces on the remote host then each interface is tried to
	 * determine what services are supported.</P>
	 *
	 */
	public void run()
	{
		//
		// Log the start of the run for this address.
		// This means that the object has finally gotten
		// to the thread pool.
		//
		Log.print(Log.DEBUG, "CapsReader.run: Executing probe for address " + m_nodeAddress.toString());
		
		try
		{
			m_session = new SnmpSession(InetAddress.getByName(m_nodeAddress.toString()));
		}
		catch(SocketException e)
		{
			Log.print(Log.ERROR, "CapsReader.run: Error creating the SnmpSession to collect from " + m_nodeAddress.toString());
			Log.print(Log.ERROR, e);
			
			return;
		}
		catch(UnknownHostException e)
		{
			Log.print(Log.ERROR, "CapsReader.run: Error converting address " + m_nodeAddress.toString() + " to an InetAddress object");
			Log.print(Log.ERROR, e);
			
			return;
		}

		//
		// read snmp properties. Create a blocking
		// signaler and then create & start the 
		// snmp collection.
		//
		SignalAfter blocker = new SignalAfter(5);
		synchronized(blocker)
		{
			//
			// collect the information
			//
			m_sysGroup 		= new SystemGroup(m_session, blocker);
			m_ifTable  		= new IfTable(m_session, blocker);
			m_ipAddrTable		= new IpAddrTable(m_session, blocker);
			m_ipRouteTable  	= new IpRouteTable(m_session, blocker);
			m_ipNetToMediaTable	= new IpNetToMediaTable(m_session, blocker);

			try
			{
				//
				// This will release the semaphore and
				// allows the collection objects to finish
				// collecting information.
				//
				blocker.wait();
				Log.print(Log.INFORMATIONAL, "CapsReader.run: SNMP query for address " + m_nodeAddress.toString() + " complete.");
			}
			catch(InterruptedException e)
			{
				//
				// Log the messages
				//
				Log.print(Log.WARNING, "Collection of snmp data interrupted!");
				Log.print(Log.WARNING, e);
				
				//
				// return to the caller with collecting the
				// data from the remote agent.
				//
				return;
			}
			finally
			{
				//
				// Regardless of what happens with
				// the collection, close the session
				// when we're finished collecting data.
				//
				try
				{
					m_session.close();
				}
				catch(Exception e)
				{
					Log.print(Log.WARNING, "CapsReader.run: An error occured closing the SNMP session for " + m_nodeAddress.toString());
					Log.print(Log.WARNING, e);
				}
			}
		} // end sync & collection, close the session

		//
		// check if there was an error in any step - error out
		//
		if(m_sysGroup.failed())
		{
			Log.print(Log.INFORMATIONAL, "CapsReader.run: No SNMP information collected for " + m_nodeAddress.toString());
			
			//
			// Failed to collect the system
			// group. This probably means that
			// there is no snmp agent on the remote
			// node.
			//
			m_sysGroup = null;
			m_ifTable  = null;
			m_ipAddrTable = null;
			m_ipRouteTable = null;
			m_ipNetToMediaTable = null;
		}
		else if(m_ifTable.failed() 	|| m_ipAddrTable.failed() || 
			m_ipRouteTable.failed() 	|| m_ipNetToMediaTable.failed())
		{
			Log.print(Log.DEBUG, "CapsReader.run: An error occured collecting one or more tables for address " +
					     m_nodeAddress.toString() + ", but system group information collected.");

			//
			// Don't delete the system group if it did
			// not have an error. We want to log the basics,
			// but if any of the other tables fail then
			// consider them all failures
			//
			// Should this be handled differently?
			//
			m_ifTable  = null;
			m_ipAddrTable = null;
			m_ipRouteTable = null;
			m_ipNetToMediaTable = null;
		}

		// Check the service plugins 
		if (m_ifTable != null && m_ifTable.failed() == false)
		{
			probe();
		}
		else
		{
			List ifStatus = null;
			try
			{
				ifStatus = ifProbe(InetAddress.getByName(m_nodeAddress.toString()));
			}
			catch(UnknownHostException e)
			{
				Log.print(Log.WARNING, "CapsReader.run: Error converting address " + m_nodeAddress.toString() + " to InetAddress object");
				Log.print(Log.WARNING, e);
				ifStatus = null;
			}
				
			if(ifStatus != null)
			{
				m_services.put(m_nodeAddress.toString(), ifStatus);
				Log.print(Log.DEBUG, "CapsReader.run: Added services for address " + m_nodeAddress.toString());
			}
			else
			{
				Log.print(Log.DEBUG, "CapsReader.run: Interface probe of address " + m_nodeAddress.toString() + " yeilded no services");
			}
		}
			

		//
		// log the success
		//
		Log.print(Log.INFORMATIONAL, "CapsReader complete for: " + m_nodeAddress.toString() + "\t" 
				     + (m_sysGroup != null ? "true" : "false") + "\n");
	}


	/**
	 * <P>Returns the IP address of the host that was queried for
	 * information by the reader.<P>
	 *
	 * @return The IP Address of the probed remote.
	 */
	public IPv4Address getIfAddress()
	{
		return m_nodeAddress;
	}
	
	/**
	 * <P>Returns the SNMP system group information collected
	 * from the remote host. If there was an SNMP error or
	 * no agent on the remote then a null pointer is returned
	 * to the caller.</P>
	 *
	 * @return The SNMP system group information if successfully
	 * 	collected. A null if the collection failed.
	 */
	public SystemGroup getSystemGroup()
	{
		return m_sysGroup;
	}
	
	/**
	 * <P>Returns the SNMP interface table collected 
	 * from the remote host. If the host did not have
	 * an agent or an error occured during the collection
	 * then a null pointer is returned.</P>
	 *
	 * @return The SNMP interface table on success, a null
	 * 	if the collection failed.
	 */
	public IfTable getIfTable()
	{
		return m_ifTable;
	}

	/**
	 * <P>Returns the SNMP IP Address table from the
	 * remote host. Should and error occur or the
	 * host not have an SNMP agent then a null will
	 * be returned to the caller.</P>
	 *
	 * @return The SNMP IP Address table information on
	 * 	success, a null if the collection failed.
	 */
	public IpAddrTable getIpAddrTable()
	{
		return m_ipAddrTable;
	}

	/**
	 * <P>Returns the SNMP IP Route information from
	 * the remote. If an error should occur or the
	 * remote not have an SNMP agent then a null will
	 * be returned to the caller.</P>
	 *
	 * @return The SNMP IP Routing table on success, a
	 * 	null if the information could not be collected.
	 */
	public IpRouteTable getIpRouteTable()
	{
		return m_ipRouteTable;
	}

	/**
	 * <P>Returns the SNMP IP Network to Media table from
	 * the remote SNMP agent. If an error occurs during the
	 * collection or the remote does not have an SNMP agent
	 * then a null will be returned.
	 *
	 * @return The SNMP IP Network to Media table on success.
	 * 	A null will be returned if an error occured.
	 */
	public IpNetToMediaTable getIpNetToMediaTable()
	{
		return m_ipNetToMediaTable;
	}
		
	/**
	 * <P>Returns the dictionary that contains the 
	 * status mapping of interface address to supported
	 * protocols. The dictionary key is the IP address 
	 * of the interface. The mapped object is a list of
	 * supported services.</P>
	 *
	 * @return The mapping for interface to capabilities.
	 */
	public Dictionary getSupportedServices()
	{
		return m_services;
	}

	/**
	 * <P>Returns the duplicate nodes set.</P>
	 */
	public Set getDuplicateNodes()
	{
		return m_dupNodes;
	}

}

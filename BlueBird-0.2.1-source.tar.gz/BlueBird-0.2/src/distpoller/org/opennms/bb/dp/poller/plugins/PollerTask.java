//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.dp.poller.plugins;

import java.util.*;

import org.opennms.bb.dp.poller.plugins.ServiceMonitor;
import org.opennms.bb.dp.poller.plugins.ServiceMonitorException;
import org.opennms.bb.dp.poller.plugins.NetworkInterface;
import org.opennms.protocols.ip.IPv4Address;

/**This class provides the main class construct that will be
 * used to schedule interfaces for polling. A PollerTask object
 * will be placed on a producer/consumer queue and processed
 * as a thread by the run() method. The polling service will
 * be invoked during the execution of the run() method.
 *
 * @author <A HREF="mailto:jason@opennms.org">Jason Johns</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version $Revision: 1.5 $
 * 
 */
public class PollerTask implements Runnable, NetworkInterface
{
	/**The object that will be called to do the actual service polling
	*/
	private ServiceMonitor m_monitor;
	
	/**The address that the ServiceMonitor must poll
	*/
	private Object m_interfaceAddress;
	
	/**The object through which the ServiceMonitor can send events
	*/
	private EventProxy m_eventProxy;
	
	/**The map that a ServiceMonitor can use to persist data
	*/
	private Map m_properties;
	
	/**
	*/
	private boolean m_processing;
	
	/**
	*/
	private int m_currentInterval;
	
	/**
	*/
	private int m_packageIndex;
	
	/**The status of the task updated for each call of the poller.
	   Used by the scheduler to base the next schedule update of this
	   ServiceMonitor.
	*/
	private int m_currentStatus;
	
	/**Constructor, initializes the members.
	   @param ServiceMonitor aMonitor, the monitor to do the polling
	   @param IPv4Address iface, the service interface ip address
	   @param EventProxy anEventProxy, the object for sending events
	   @param Map props, a map used for persiting data
	*/
	public PollerTask(ServiceMonitor aMonitor, Object iface, EventProxy anEventProxy, Map props)
	{
		m_monitor = aMonitor;
		m_interfaceAddress = iface;
		m_eventProxy = anEventProxy;
		m_properties = props;
		m_processing = false;
		
		try
		{
			m_monitor.initialize(this);
		}
		catch(ServiceMonitorException e)
		{
			System.out.println(e);
		}
	}
	
	/**
	*/
	public void setCurrentInterval(int newInterval)
	{
		m_currentInterval = newInterval;
	}
	
	/**
	*/
	public int getCurrentInterval()
	{
		return m_currentInterval;
	}
	
	/**
	*/
	public void setPackageIndex(int aPackageIndex)
	{
		m_packageIndex = aPackageIndex;
	}
	
	/**
	*/
	public int getPackageIndex()
	{
		return m_packageIndex;
	}
	
	/**
	*/
	public boolean isProcessing()
	{
		return m_processing;
	}
	
	/**
	*/
	public void setProcessing(boolean aBool)
	{
		m_processing = aBool;
	}
	
	/**This method fulfills the Runnable interface. When this PollerTask is pulled
	   from the producer queue this method will be called and will perform the 
	   actual poll for the service. The status is updated and the PollerTask
	   will be placed onto a consumer queue for the scheduler to consume.
	*/
	public void run()
	{
		try
		{
			//System.out.println(Thread.currentThread().toString());
			System.out.println("Polling " + m_interfaceAddress.toString());
			m_currentStatus = m_monitor.poll(this, m_eventProxy, new Properties());
		}
		catch(ServiceMonitorException e)
		{
			System.out.println(e);
		}
	}
	
	/**This method returns the status of the service that was recieved
	   when last polled.
	   @return int, the constant indicating the current status
	*/
	public int getStatus()
	{
		return m_currentStatus;
	}
	
	/**This method returns the ip address of the service interface
	   @return Object, the object encapulating the address
	*/
	public Object getAddress()
	{
		return m_interfaceAddress;
	}
	
	/**This method returns an attribute from the m_properties member.
	   @return Object, and Object encapulating the attribute
	   @param String property, the property to look up
	*/
	public Object getAttribute(String property)
	{
		return m_properties.get(property);
	}
	
	/**This method sets an attribute in the m_properties member
	   @return Object, previous value associated with specified key, or null if there was no mapping for key
	   @param String property, the property to set
	   @param Object value, the Object encapulating the attribute
	*/
	public Object setAttribute(String property, Object value)
	{
		return m_properties.put(property, value);
	}
	
	public int getType()
	{
		return NetworkInterface.TYPE_IPV4;
	}
} 

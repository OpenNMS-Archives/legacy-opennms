//
// Copyright (C) 2000 N*Manage Company Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
// Tab Stop = 8
//
// $Id: CapsdPluginLoader.java,v 1.13 2000/10/09 21:28:15 mike Exp $
//
package org.opennms.bb.dp.capsd.components;

import java.util.*;
import java.io.*;
import java.sql.*;
import java.net.*;

import org.opennms.bb.common.components.Log;
import org.opennms.bb.dp.capsd.utils.*;
import org.opennms.bb.dp.capsd.Capsd;

/**
 * <P>CapsdPluginLoader loads the plugins from the 'capsdPluginXml' xml file
 * into the 'service' table of the database. Also includes the serviceID
 * of the services to the plugins vector.</P>
 *
 * @author <A HREF="mailto:sowmay@opennms.org">Sowmya</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version $Revision: 1.13 $
 */
public class CapsdPluginLoader
{
	/**
	 * <P>The list of plugin modules that were successfully
	 * loaded.</P>
	 */
	private List		m_plugins;

	/**
	 * <P>Checks each service plugin to see if its already loaded in 
	 * database. If it is, the service ID is read and added to the
	 * m_plugins structure. If not already in the database,
	 * a new row is added for this plugin to the SERVICE table and 
	 * this data is added to the m_plugins.</P>
	 *
	 * @param con	The connection to the database.
	 *
	 * @exception java.lang.NullPointerException	Thrown if a requried
	 * 	property cannot be found.
	 * @exception java.sql.SQLException Thrown if a JDBC error occurs accessing
	 *	the database.
	 */
	private void sync(Connection con)
		throws SQLException
	{
		String insSvcText = Capsd.getProperty(CapsdConstants.PROP_DB_INS_SERVICE);
		if(insSvcText == null)
		{
			Log.print(Log.WARNING, "CapsdPluginLoader.sync: Error loading property " + CapsdConstants.PROP_DB_INS_SERVICE);
			throw new NullPointerException("Unable to load required property " + CapsdConstants.PROP_DB_INS_SERVICE);
		}
			
		String getSvcIdText = Capsd.getProperty(CapsdConstants.PROP_DB_SVCIDFROMSVCNAME);
		if(getSvcIdText == null)
		{
			Log.print(Log.WARNING, "CapsdPluginLoader.sync: Error loading property " + CapsdConstants.PROP_DB_SVCIDFROMSVCNAME);
			throw new NullPointerException("Unable to load required propery " + CapsdConstants.PROP_DB_SVCIDFROMSVCNAME);
		}

		//String getNxtSvcIdText = System.getProperty(CapsdConstants.PROP_DB_GET_NEXTSVCID);
		String getNxtSvcIdText = Capsd.getProperty(CapsdConstants.PROP_DB_GET_NEXTSVCID);
		if(getNxtSvcIdText == null)
		{
			Log.print(Log.WARNING, "CapsdPluginLoader.sync: Error loading property " + CapsdConstants.PROP_DB_GET_NEXTSVCID);
			throw new NullPointerException("Unable to load required property " + CapsdConstants.PROP_DB_GET_NEXTSVCID);
		}
			
		PreparedStatement serviceInsStmt   = null;
		PreparedStatement serviceIdStmt    = null;
		PreparedStatement serviceNxtIdStmt = null;

		try
		{
			// Service table insert string
			serviceInsStmt = con.prepareStatement(insSvcText);

			// Service ID retrieve string
			serviceIdStmt  = con.prepareStatement(getSvcIdText);

			// Service ID retrieve string
			serviceNxtIdStmt  = con.prepareStatement(getNxtSvcIdText);
		}
		catch (SQLException e) 
		{ 
			Log.print(Log.ERROR, "CapsPluginLoader.sync: Exception in prepared statement");
			Log.print(Log.ERROR , e);
			throw e;
		}
		
		//
		// check to see if there are any plugins
		//
		if(m_plugins == null)
		{
			Log.print(Log.DEBUG, "CapsdPluginLoader.sync: No Plugins found or loaded.");
			return;
		}
		
		//
		// Iterate over the plugins and insert
		// them into the database.
		//
		Iterator iter = m_plugins.iterator();
		while(iter.hasNext())
		{
			boolean		bException=false;
			int		iServiceID=-1;

			List plugin = (List)iter.next();
			String name = (String)plugin.get(0);
			
			//
			// Log the debug information
			//
			Log.print(Log.DEBUG, "CapsdPluginLoader.sync: Attempting to find service " + name + " in database");
			
			//
			// get the service id of the service name if already present
			//
			try
			{
				serviceIdStmt.setString(1, name);
				ResultSet  rs = serviceIdStmt.executeQuery();
				rs.next();
				iServiceID = rs.getInt(1);
				
				//
				// Log the service id
				//
				Log.print(Log.DEBUG, "CapsdPluginLoader.sync: Found service id " + iServiceID + " for service " + name);
			}
			catch (Exception e2)		
			{
				/*
				 * Note: A general exception is caught here because 
				 * Oracle throws a SQLException for this case while
				 * Postgres throws a NullPointerException
				 */

				//not already in table
				bException = true;
				Log.print(Log.DEBUG, "CapsdPluginLoader.sync: Service " + name + " not found (SQLException)");
			}

			// If not already present, insert a new row for 
			// this service and get its serviceID
			if(bException)
			{
				bException = false;
				boolean doRollback = true;
				try
				{
					ResultSet rs = serviceNxtIdStmt.executeQuery();
					rs.next();
					iServiceID = rs.getInt(1);
					
					//
					// Show me the next id
					//
					Log.print(Log.DEBUG, "CapsdPluginLoader.sync: New Service Identifier is " + iServiceID); 
					
					//
					// put this into the service table
					//
					serviceInsStmt.setInt(1, iServiceID);
					serviceInsStmt.setString(2, name);
					
					//
					// Update
					//
					serviceInsStmt.executeUpdate();
					
					//
					// commit
					//
					Log.print(Log.DEBUG, "CapsdPluginLoader.sync: Commiting ..");
					con.commit();
					doRollback = false;
					
				}
				catch (SQLException e)
				{
					// oops! not already in and canot be inserted
					Log.print(Log.ERROR, "CapsdPluginLoader.sync: Unable to register service\'" + name + "\' in the SERVICE table");
					Log.print(Log.ERROR, e);
					bException = true;
					
					try
					{
						if(doRollback)
							con.rollback();
					}
					catch(Exception ex) { }
				}
			}

			if (!bException)
			{
				plugin.add(new Integer(iServiceID));
			}
			else
			{
				iter.remove(); // remove the last accessed!
				Log.print(Log.WARNING, "Removing plugin named " + (String)(plugin.get(0)));
			}
		} // end while
	}

	/**
	 * Constructs a new CapsdPluginLoader. Reads the database login
	 * parameters from properties loaded and throws an exception if
	 * these parameters are not found or if it cannot connect or load
	 * data into the database
	 *
	 * @exception org.opennms.bb.dp.capsd.components.CapsdPluginException Thrown 
	 *	if the plugins cannot be loaded.
	 * @exception java.lang.NullPointerException Thrown if there is an error
	 * 	loading or getting properity strings.
	 */
	public CapsdPluginLoader() throws CapsdPluginException
	{
		// get plugin related properties
		String driver = Capsd.getProperty(CapsdConstants.PROP_DB_DRIVER);
		if(driver == null)
			throw new NullPointerException("Unable to load required property " + CapsdConstants.PROP_DB_DRIVER);

		String url = Capsd.getProperty(CapsdConstants.PROP_DB_URL);
		if(url == null)
			throw new NullPointerException("Unable to load required property " + CapsdConstants.PROP_DB_URL);
		
		String user = Capsd.getProperty(CapsdConstants.PROP_DB_USER);
		if(user == null)
			throw new NullPointerException("Unable to load required property " + CapsdConstants.PROP_DB_USER);
		
		String passwd = Capsd.getProperty(CapsdConstants.PROP_DB_PASSWD);
		if(passwd == null)
			throw new NullPointerException("Unable to load required property " + CapsdConstants.PROP_DB_PASSWD);

		String fileDir = Capsd.getProperty(CapsdConstants.PROP_XML_REPOSITORY);
		if(fileDir == null)
			throw new NullPointerException("Unable to load required property " + CapsdConstants.PROP_XML_REPOSITORY);
			

		// get address and parse
		InetAddress inetAddr=null;
		try
		{
			inetAddr = InetAddress.getLocalHost();
		}
		catch(UnknownHostException ukE)
		{
			throw new CapsdPluginException(ukE.getMessage());
		}

		byte[] addr = inetAddr.getAddress();
		long address  = (addr[3] & 0xFFL) 
			      | ((addr[2] << 8) & 0xFF00L) 
			      | ((addr[1] << 16) & 0xFF0000L)
			      | ((addr[0] << 24) & 0xFF000000L);

		/**
		 * parse plugin xml
		 */
		try
		{
			CapsdPluginParser capsPluginParser = new CapsdPluginParser(address);
			capsPluginParser.parse(fileDir + "capsdPluginXML.xml");
			m_plugins = capsPluginParser.getPlugins();
		}
		catch(IOException ioe)
		{
			throw new CapsdPluginException("Unable to parse plugin xml: " + ioe.getMessage());
		}

		Log.print(Log.INFORMATIONAL, "CapsdPluginLoader: Successfully parsed plugin xml");

		try
		{
			/**
		 	 * load database driver
		 	 */
			Class.forName(driver);

    			/**
		 	 * Connect to the database
		 	 */
			Connection con = DriverManager.getConnection(url, user, passwd);
			con.setAutoCommit(false);
				
			/**
		 	 * load into database
		 	 */
			sync(con);
			
			//
			// close the connection
			//
			con.close();
		}
		catch(ClassNotFoundException cnfe)
		{
			throw new CapsdPluginException(cnfe.getMessage());
		}
		catch(SQLException sqle)
		{
			throw new CapsdPluginException(sqle.getMessage());
		}
	}
	
	/**
	 * <P>Returns the list of valid plugins loaded
	 * by the class.</P>
	 */
	public List getPlugins()
	{
		return m_plugins;
	}
}

//
// Copyright (C) 2000 N*Manage Company Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
// Tab Size = 8
//
// $Id: CapsdDiscReceiver.java,v 1.17 2000/10/12 12:47:37 mike Exp $
//

package org.opennms.bb.dp.capsd.components;

import java.lang.*;
import java.util.*;
import java.io.*;

import com.sun.media.jsdt.*;
import org.apache.xerces.parsers.*;
import org.xml.sax.*;

import org.opennms.protocols.ip.IPv4Address;
import org.opennms.bb.dp.capsd.utils.*;
import org.opennms.bb.common.components.*;
import org.opennms.bb.dp.common.components.*;

/**
 * <P>This class is designed to handle the setup, communications, and
 * shutdown between capsd and discovery using JSDT. Each instance
 * of the class is passed a queue where address recoreds from the 
 * discovery system are written.</P>
 *
 * @author <A HREF="mailto:sowmya@opennms.org">Sowmya</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version $Revision: 1.17 $
 */
public final class CapsdDiscReceiver extends Object
{
	/**
	 * <P>The discovery queue is the link between the capabilites
	 * daemon and the discovery system. The queue is used to hold
	 * String object that are IPv4 address in dotted decimal format.
	 * The address strings are received using the JSDT connection
	 * to discovery.</P>
	 */
	private PCQueue		m_discRecvQ;

	/**
	 * <P>The current receiver status of the JSDT class. If 
	 * the variable is set then JSDT messages are rejected
	 * by the inner class.</P>
	 *
	 * <P>This member is marked as volitalie to ensure that
	 * changes are not cached and missed by the JSDT 
	 * thread(s).</P>
	 */
	private volatile boolean m_paused;

	/**
	 * <P>JSDT session for communication with discovery. 
	 * This session is used to exchange messages about 
	 * discovered IP addresses.</P>
	 */
	private Session		m_session;

	 /**
	  * <P>JSDT channel from which discoveyr data is received.
	  * The channel is part of the JSDT session between capsd
	  * and discovery.</P>
	  */
	private Channel		m_channel;

	/**
	 * <P>The consumer object is the final endpoint
	 * of data sent from discovery to capsd. The consumer
	 * receives messages from the session, through the
	 * channel, and then is responsible for placing those
	 * messages in the objects queue.</P>
	 */
	private CapsdDiscConsumer m_consumer;
	
	/**
	 * Duplicate node set.  If an address is received
	 * from discovery process and it is a member of this set
	 * it is not added to the discovery queue.
	 */
	private Set m_dupNodes;

	/**
	 * <P>The JSDT client name used by this class. This is
	 * the client that will receive ip address object from
	 * the discovery system and then forward them on to the
	 * rest of the capsd system.</P>
	 */
	private static final String	JSDT_CLIENT_NAME = "CapsdRecv";

	/**
	 * <P>Creates a connection using JSDT between the capabilities daemon
	 * and the discovery system. The capsd client name is passed in and
	 * used to join the address exchange channel.</P>
	 *
	 * <P>If an error occurs then an exception will be thrown from
	 * the code. Be aware that this method will wait until a connection
	 * or fatal error occurs before returning control to the caller.
	 * Callers should make provisions to ensure that any locks that are
	 * held prior to calling jsdtConnect will not cause negative deadlock
	 * issues.</P>
	 *
	 * @exception  JSDTException thrown if the JSDT communication channel 
	 *	cannot be established or other error conditions occur.
	 */
	private void jsdtConnect()  
		throws JSDTException
	{
		try
		{
			//
			// Create the JSDT connection URL that is
			// used to connect to discovery subsystem.
			//
 			URLString url = URLString.createSessionURL(PollerSession.hostName, 
								   PollerSession.discCapsdPort,
								   PollerSession.sessionType, 
								   PollerSession.discToCapsdSessionName);
			
			//
			// while false the JSDT registry has not
			// created the session internally, this
			// will remain false.
			//
			boolean sessionExists = false;

			//
			// While there is not a session to connect to
			// loop and retry every second. If the thread
			// is marked for cancellation prior to completing
			// the connection, then a failure is returned by
			// the method.
			//
			while (!sessionExists) 
			{
				try 
				{
					//
					// Try to connect to the session, if
					// the session exists then it will
					// be marked and the while loop will
					// exit.
					//
					if (SessionFactory.sessionExists(url)) 
					{
                            			sessionExists = true;
					}
				} 
				catch(NoRegistryException nre) 
				{
					//
					// Log the warning
					//
					Log.print(Log.WARNING, "Failure to connect to the registry");
					Log.print(Log.WARNING, nre);
					
					//
					// The registry has not been started
					// yet. Wait for a single second before
					// before trying again.
					//
					// There is a downside in that any locks
					// held by this thread is kept during
					// the second that the thread sleeps.
					//
					try
					{
						Thread.sleep(1000);
					}
					catch (InterruptedException iE1) 
					{
						Log.print(Log.WARNING, "JSDT Connection Thread Interrupted, throwing JSDT Exception");
						Log.print(Log.WARNING, iE1);
						
						//
						// TimedOutException does not support string
						// argument in the constructor. I hope that is
						// just an oversite on Sun's part. 
						//
						throw new com.sun.media.jsdt.TimedOutException();
					}
				} 
				catch (ConnectionException ce) 
				{
					//
					// Log the warning
					//
					Log.print(Log.WARNING, "Failure to connect to the registry");
					Log.print(Log.WARNING, ce);

					//
					// An exception occured trying
					// to connect to the JSDT registry.
					// The thread will be suspended for a 
					// second before trying again. As stated
					// above, any locks currently held will
					// not be released by the thread.
					//
					try
					{
						Thread.sleep(1000);
					}
					catch (InterruptedException iE2) 
					{
						Log.print(Log.WARNING, "JSDT Connection Thread Interrupted, throwing JSDT Exception");
						Log.print(Log.WARNING, iE2);

						//
						// TimedOutException does not appear to support string
						// argument in the constructor. I hope that is
						// just an oversite on Sun's part. 
						//
						throw new com.sun.media.jsdt.TimedOutException();
					}
				}
			} // end while loop for registry connection

			//
			// create the consumer object to receive
			// the addresses from the discovery system.
			//
			// Note: the consumer is also a client.
			//
			m_consumer = new CapsdDiscConsumer(JSDT_CLIENT_NAME);

			//
			// create a session for the client
			//
			m_session = SessionFactory.createSession(m_consumer, 
								 url, 
								 true);

			//
			// create the consumer channel
			//
			m_channel = m_session.createChannel(m_consumer, 
							    PollerSession.discToCapsdChannelName,
							    true, 
							    false, 
							    true);

			//
			// Add the cosumer for the channel
			//
			m_channel.addConsumer(m_consumer, m_consumer);

		} 
		catch (JSDTException e)
		{
			//
			// Log the error
			//
			Log.print(Log.ERROR, "JSTD Error trying to create the connection for the client " + JSDT_CLIENT_NAME);
			Log.print(Log.ERROR, e.getMessage());
			
			//
			// Unwind the creation of the session if possible
			//
			if(m_session != null)
			{
				try
				{
					m_session.close(false);
				}
				catch(Exception ex)
				{
					Log.print(Log.WARNING, "Exception thrown while trying to unwind JSDT creation");
					Log.print(Log.WARNING, ex);
				}
			}

			//
			// Rethrow the execption for the caller to handle
			// pass on up the stack.
			//
			throw e;
		}
	}

	/**
	 * <P>The CapsdDiscConsumer class is used by the capabilities
	 * daemon to receive actual IP address information from
	 * discovery. When the information is forwarded via JSDT this
	 * class, the dataReceived method is invoked to process the
	 * information.</P>
	 *
	 * @author <A HREF="mailto:sowmya@opennms.org">Sowmya</A>
	 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
	 *
	 * @version $Revision: 1.17 $
	 */
	private final class CapsdDiscConsumer 
		extends    PollerClient 
		implements ChannelConsumer
	{
		/**
		 * <P>Xerces SAX parser used to parse the SOAP exchanges.</P>
		 */
		private SAXParser m_parser;		// reusable parser
		
		/**
		 * <P>SAX ContentHandler and ErrorHandler class. This actually
		 * processes the SAX events and stores the data.</P>
		 */
		private DiscNewAddressParser m_handler;	// reusable handler
		
		/**
		 * <P>The default constructor is used to assign a JSDT client
		 * name to this object. Once the client is named then the
		 * class can receive messages through the JSDT channels.</P>
		 *
		 * @param name	The name of the JSDT client.
		 */
		public CapsdDiscConsumer(String name)
		{
			super(name);
			m_parser = new SAXParser();
			m_handler= new DiscNewAddressParser();
			
			m_parser.setErrorHandler(m_handler);
			m_parser.setContentHandler(m_handler);
		}

		/**
		 * <P>The dataReceived method is defined in the
		 * JSDT ChannelConsumer interface. The method receives
		 * the actual address data from the discovery subsystem
		 * and enqueues the data into the passed queue.</P>
		 *
		 * @param data The actual JSDT data object containing
		 * 	the address string.
		 */
		public synchronized void dataReceived(Data data)
		{
			Log.print(Log.DEBUG, "SOAP message received from Discovery!");
			//Log.print(Log.DEBUG, data.getDataAsString());
			
			//
			// if the paused flag is set then
			// "reject" message from the discovery 
			// system.
			//
			// Gracefully handle the case where the
			// storeage queue is closed. This should
			// not happen, but we'll be nice.
			//
			// Should we warn about a closed queue?
			//
			if(m_paused || m_discRecvQ.isClosed())
				return;

			//
			// Get the IP Address data from the 
			// discovery system.
			//
			try
			{
				ByteArrayInputStream istream = new ByteArrayInputStream(data.getDataAsBytes());
				m_parser.parse(new InputSource(istream));
				List addrs = m_handler.getAddresses();
				if(addrs != null)
				{
					//
					// Add the address to the queue
					//
					Iterator iter = addrs.iterator();
					while(iter.hasNext())
					{ // Before we add the address to the receive Q, lets make
					  // sure it is not a member of m_dupNodes.
					  String newAddr = new String(iter.next().toString());
					  if (!m_dupNodes.contains(newAddr))
					  {
					    Log.print(Log.DEBUG, "CapsdDiscReceiver.dataReceived: Address " + newAddr + " not found in dupNodes...adding to RecvQ.");
						m_discRecvQ.add(newAddr);

						// Add the node to dupNodes
						Log.print(Log.DEBUG, "CapsdDiscReceiver.dataReceived: Adding " + newAddr + " to duplicate nodes\n");
						m_dupNodes.add(newAddr);
					  }
					  else
					    Log.print(Log.DEBUG, "CapsdDiscReceiver.dataReceived: Discarding duplicate address: " + newAddr);
					}
				}
			}
			catch(Exception e) 
			{
				//
				// Print the stack trace to a new 
				// byte array and then actually log
				// the stack trace
				//
				Log.print(Log.ERROR, "Error adding the received data address to the received queue");
				Log.print(Log.ERROR, e);
			}
		}
	}
	
	/**
	 * <P>The default constructor. The construct is implemented
	 * for completeness, but will always throw an exception. Since
	 * any instance must have a queue to write recieved addresses 
	 * the default constructor is denied via the exception.<P>
	 *
	 * @exception java.lang.UnsupportedOperationException Always thrown
	 * 	to prevent default construction.
	 */
	private CapsdDiscReceiver( ) 
		throws UnsupportedOperationException
	{
		throw new UnsupportedOperationException("The class does not support a default constructor");
	}
	
	/**
	 * <P>The class' constructor is used to create an instance of the
	 * capsd/discovery address exchange channel. The object will consume
	 * address data from the discovery system and place the messages into
	 * the passed queue. By default when the object it will be in a ready
	 * state and will accept & queue messages from discovery. The queue
	 * should be prepared to handle messages prior to calling the start
	 * method.</P>
	 *
	 * <P><EM>However</EM>, should the queue closed the class will behave just as if
	 * the object's instance had been suspended via the pause method.</P>
	 *
	 * @param Q	The queue where address records are written from discovery.
	 * @param dupNodes The set of addresses which are already known by Capsd.
	 *
	 */
	public CapsdDiscReceiver(PCQueue Q, Set dupNodes)
	{
		m_discRecvQ = Q;
		m_dupNodes = dupNodes;
		m_paused = false;
		
		m_session = null;
		m_channel = null;
		m_consumer= null;
	}
	
	/**
	 * <P>Resumes the recipt of messages from the 
	 * JSDT channel. If the channel was not paused
	 * then the resume is silently ignored. If the
	 * channel was paused, then messages will again
	 * be received by the consumer.</P>
	 */
	public void resume()
	{
		m_paused = false;
	}
	
	/**
	 * <P>Pauses the recipt of messages from the
	 * JSDT channel. All messages received while
	 * the channel is paused will be discarded by
	 * the consumer.</P>
	 */
	public void pause()
	{
		m_paused = true;
	}

	/**
	 * <P>The start method is used to connect the object
	 * to the JSDT channel between the capsd and discovery
	 * systems. When called the method will block until 
	 * the connection is established or an exception is 
	 * thrown. The method will also reset the instance
	 * to receive messages from the discovery system. If 
	 * the instance was previously paused, it will be 
	 * resumed.</P>
	 *
	 * @exception	com.sun.media.jsdt.JSDTException Thrown 
	 *	if a the connection cannot be completed due to
	 * 	a JSDT error.
	 * @exception	java.lang.IllegalStateException Thrown if 
	 * 	the session has already been established.
	 */
	public synchronized void open() 
		throws JSDTException
	{
		if(m_consumer != null)
			throw new IllegalStateException("session already started, close first");

		m_paused = false;

		Log.print(Log.INFORMATIONAL, "Trying to connect to JSDT registry...");

		jsdtConnect();

		Log.print(Log.INFORMATIONAL, "JSDT communication channel up");
	}

	/**
	 * <P>Closes the connection to the JSDT session and channel.
	 * This will permanently close the connection. If the connection
	 * is needed again, then a new object should be created.</P>
	 *
	 * <P>If a JSDTException occurs it is caught, and then logged
	 * as a warning in the log. The exception is then silently 
	 * discarded and not rethrown.</P>
	 * 
	 */
	public synchronized void close()
	{
		// close JSDT m_session
		try
		{
			if(m_consumer != null)
			{
				m_channel.removeConsumer(m_consumer, m_consumer);
			}
			m_consumer = null;
			m_channel  = null;
		}
		catch(JSDTException jsdtE) 
		{
			//
			// Log the error
			//
			ByteArrayOutputStream trace = new ByteArrayOutputStream();
			jsdtE.printStackTrace(new PrintStream(trace));
			
			Log.print(Log.WARNING, jsdtE.getMessage());
			Log.print(Log.WARNING, trace.toString());
		}
		finally
		{
			try 
			{ 
				m_session.close(false); 
			} 
			catch(Exception e) 
			{ 
				Log.print(Log.WARNING, "JSDT Error closing the session");
				Log.print(Log.WARNING, e);
			}
			m_session = null;
		}
	}
}

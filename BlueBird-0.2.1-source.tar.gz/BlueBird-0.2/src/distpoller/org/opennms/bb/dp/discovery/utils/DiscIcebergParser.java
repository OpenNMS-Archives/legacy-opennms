//
// Copyright (C) 2000 N*Manage Company Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
// $Id: DiscIcebergParser.java,v 1.8 2000/10/05 19:35:15 weave Exp $
//

package org.opennms.bb.dp.discovery.utils;

import java.io.*;
import java.net.*;
import java.util.*;

import org.w3c.dom.*;

import org.opennms.bb.common.utils.BBParser;
import org.opennms.bb.common.components.Log;
import org.opennms.bb.dp.discovery.components.*;

/**
 * <P>The DiscIcebergParser class is used to parse the XML configuration
 * file defined by the pollers.dtd. The information is parsed and the
 * resulting data can be extracted from the instance.</P>
 *
 * @author <A HREF="mailto:sowmya@opennms.org">Sowmya</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version $Revision: 1.8 $
 * 
 */
public final class DiscIcebergParser extends BBParser
{
	/**
	 * packages to be read - this info.
	 * is in pollersXML and is passed in
	 */
	private List		m_packages;	

	/**
	 * if the current package being read is to
	 * be considered, this is flagged to true
	 */
	private boolean		m_readPackage;

	/**
	 * Data collected for the poller - the ranges to include
	 */
	private List		m_incRanges;

	/**
	 * Data collected for the poller - the ranges to exclude
	 */
	private List		m_excRanges;

	/**
	 * Data collected for the poller - the specifics to include
	 */
	private List		m_specifics;

	//
	// Relevant XML TAGS
	//
	private final String PARMS	= "parms";
	private final String PARM 	= "parm";
	private final String PARM_NAME	= "parmName";
	private final String PARM_VALUE	= "value";
	private final String PARM_TYPE	= "type";

	private final String PACKAGENAME= "packageName";
	private final String DEFAULT	= "rangeDef";
	private final String RANGES	= "ranges";
	private final String IRANGE	= "irange";
	private final String ERANGE	= "erange";
	private final String SPECIFIC	= "specific";
	private final String URL	= "url";

	private final String FROM	= "From IP Address";
	private final String TO		= "To IP Address";
	private final String SPECIP	= "IP Address";
	private final String URLNAME	= "File name";

	// we only need 'retries' and 'timeout' for discovery
	private final String RETRIES	= "Retries";
	private final String TIMEOUT	= "timeout";
	
	//
	// XML value, not part of document
	//
	private final String TAKE_DEFAULT_VALUE	="<default>";

	/**
	 * default values (note that these will get overwritten for each
	 * 'rangeDef' block in each package that is to be considered)
	 */
	private long			m_packDefRetries;
	private long			m_packDefTimeout;

	/**
	 * Global default values - take the minimum since this is discovery
	 */
	private long			m_defaultRetries;
	private long			m_defaultTimeout;
	
	/**
	 * <P>The parameter class is used by the parser
	 * to represent a classic parameter block in the
	 * XML file. For an example of a parameter block
	 * see the packages.dtd file in the CVS module
	 * <EM>xml</EM>.</P>
	 *
	 * <P>This class was create to take the place of a
	 * Vector used to pass the parameters. The vector
	 * with synchronization and generic objects (1) has
	 * more overhead and (2) isn't very specific about
	 * the data.</P>
	 *
	 * @author <A HREF="mailto:weave@opennms.org">Weave</A>
	 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
	 *
	 */
	private final class Parameter
	{
		/**
		 * <P>The name of the parameter.</P>
		 */
		private String m_name;
		
		/**
		 * <P>The value of the parameter.</P>
		 */
		private String m_value;
		
		/**
		 * <P>The type for the parameter.</P>
		 */
		private String m_type;
		
		/**
		 * <P>Creates a default instance of the parameter
		 * class. All values are set to null initialally.</P>
		 */
		public Parameter( )
		{
			m_name = null;
			m_value= null;
			m_type = null;
		}
		
		/**
		 * <P>Returns the name of the parameter object.</P>
		 */
		public String getName()
		{
			return m_name;
		}
		
		/** 
		 * <P>Sets the name of the parameter object.</P>
		 *
		 * @param name	The name of the parameter object.
		 */
		public void setName(String name)
		{
			m_name = name;
		}
		
		/**
		 * <P>Returns the type for the parmeter object.</P>
		 */
		public String getType()
		{
			return m_type;
		}
		
		/**
		 * <P>Sets the type for the parameter object.</P>
		 *
		 * @param type	The type for the object.
		 */
		public void setType(String type)
		{
			m_type = type;
		}
		
		/**
		 * <P>Returns the value of the parameter object.</P>
		 */
		public String getValue()
		{
			return m_value;
		}
		
		/**
		 * <P>Sets the value for the parameter object.</P>
		 *
		 * @param value	The value for the instance.
		 */
		public void setValue(String value)
		{
			m_value = value;
		}
		
		public boolean isValid()
		{
			return (m_value != null && m_type != null && m_name != null);
		}
	} // end class Parameter

	/**
	 * <P>This method is used to convert a long value
	 * into an IPv4 dotted decimal string address. The
	 * string returned will be in the form of 
	 * <EM>"d.d.d.d"</EM>, where <EM>d</EM> is a number
	 * in the range 0 to 255 inclusive.</P>
	 *
	 * @param intAddress	IPv4 address in decimal format (unsigned).
	 *
	 * @return The dotted decimal IPv4 address string.
	 *
	 */
	private static String convertIntToIP(String intAddress)
	{
		long lAddr = 0;
		try
		{
			lAddr = Long.parseLong(intAddress);
		}
		catch(NumberFormatException e) { return "0.0.0.0"; }

       		return ((lAddr >>> 24) & 0xFF) + "." + 
		       ((lAddr >>> 16) & 0xFF) + "." + 
		       ((lAddr >>>  8) & 0xFF) + "." + 
		       ((lAddr >>>  0) & 0xFF);
	}


	/**
	 * <P>Converts the passed time string to a time value that is 
	 * measured in milliseconds. The following extension are considered
	 * when converting the string:</P>
	 *
	 * <TABLE BORDER=0>
	 *	<TR><TH>Extension</TH><TH>Conversion Value</TH></TR>
	 *	<TR><TD>us</TD><TD>Microseconds</TD></TR>
	 *	<TR><TD>ms</TD><TD>Milliseconds</TD></TR>
	 *	<TR><TD>s</TD><TD>Seconds</TD></TR>
	 *	<TR><TD>m</TD><TD>Minutes</TD></TR>
	 *	<TR><TD>h</TD><TD>Hours</TD></TR>
	 *	<TR><TD>d</TD><TD>Days</TD></TR>
	 * </TABLE>
	 *
	 * <P>A number entered with out any units is considered to be
	 * in milliseconds.</P>
	 *
	 * @param valueToConvert	The string to convert to milliseconds.
	 *
	 * @return Returns the string converted to a millisecond value.
	 *
	 * @exception java.lang.NumberFormatException Thrown if the string is
	 * 	malformed and a number cannot be extracted from the value.
	 *
	 */
	private static long convertTimeToLong(String valueToConvert)
		throws NumberFormatException
	{
		String timeVal = valueToConvert.toLowerCase();
		int   index    = 0;
		float factor   = 1.0f;

		if(timeVal.endsWith("us"))
		{
			factor = 0.001f;
			index  = timeVal.indexOf("us");
		}
		else if(timeVal.endsWith("ms"))
		{
			factor= 1.0f;
			index = timeVal.indexOf("ms");
		}
		else if(timeVal.endsWith("s"))
		{
			factor = 1000.0f;
			index = timeVal.indexOf("s");
		}
		else if(timeVal.endsWith("m"))
		{
			factor = 1000.0f * 60.0f;
			index = timeVal.indexOf("m");
		}
		else if(timeVal.endsWith("h"))
		{
			factor = 1000.0f * 60.0f * 60.0f;
			index = timeVal.indexOf("h");
		}
		else if(timeVal.endsWith("d"))
		{
			factor = 1000.0f * 60.0f * 60.0f * 24.0f;
			index = timeVal.indexOf("d");
		}
		
		if(index == 0)
		{
			index = timeVal.length();
		}
		
		Float fVal = new Float(timeVal.substring(0, index));
		return ((long)(fVal.floatValue() * factor));
		
	} // end convertTimeToLong()

	/**
	 * <P>This method override the method in the base class that
	 * is the default target for processing elements in the DOM
	 * tree. The method is invoked by the DOM parser to handle
	 * each element.</P>
	 *
	 * @param el		The DOM element to be processed.
	 * @param isRoot	True if the element is a root element.
	 *
	 * @return True if the element was successfully handled.
	 */
	protected boolean processElement(Element el,boolean isRoot)
	{
		boolean bRet = false;

		Node  curNode = (Node)el;
		String tag = el.getTagName();

		if (tag.equals(PACKAGENAME))
		{
			//
			// check the package name to see if 
			// it exist in our list of packages to
			// be processed. If it does then set 
			// the appropate flag.
			//
			String packName = processParmValue(curNode); 

			m_readPackage = false;
			if (m_packages.contains(packName))
				m_readPackage = true;
			
			bRet = true;
		}
		else if (tag.equals(DEFAULT) && m_readPackage)
		{
			m_curElement.replace(0, m_curElement.length(), DEFAULT);

			bRet = processDefaultElement(el);
		}
		else if (tag.equals(IRANGE) && m_readPackage)
		{
			m_curElement.replace(0, m_curElement.length(), IRANGE);

			// data
			bRet = processIncRange(el);
		}
		else if (tag.equals(ERANGE) && m_readPackage)
		{
			m_curElement.replace(0, m_curElement.length(), ERANGE);

			// data
			bRet = processExcRange(el);
		}
		else if (tag.equals(SPECIFIC) && m_readPackage)
		{
			m_curElement.replace(0, m_curElement.length(), SPECIFIC);

			// data
			bRet = processSpecific(el);
		}
		else if (tag.equals(URL) && m_readPackage)
		{
			//
			// TODO: FIX THIS TO ACTUALLY READ THE 
			// TODO: URL AND ADD TO THE LIST OF ADDRESSES
			//
			bRet = true;
		}
		else
		{
			boolean bNodeRet=true;

			NodeList nl = el.getChildNodes();
			int size = nl.getLength();

			for(int i = 0;i < size && bNodeRet ;i++)
				bNodeRet = processNode(nl.item(i));
			
			bRet = bNodeRet;
		}
		
		return bRet;
	}

	/** 
	 * <P>This method is used to handle the range defaults
	 * section of the document. This method iterates through
	 * the nodes children elements and then calls the
	 * processDefaultParms method to process the data</P>
	 *
	 * @param defNode The DOM node to handle.
	 *
	 * @return Returns true if successful, false otherwise.
	 *
	 */
	protected boolean processDefaultElement(Node defNode)
	{
		boolean bRet = true;

		NodeList nl = defNode.getChildNodes();
		int size = nl.getLength();
		for(int i = 0;i < size && bRet ;i++)
		{
			Node curNode = nl.item(i);
			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
				if(curTag.equals(PARMS))
					bRet = processDefaultParms(curNode);
			}
			
		}

		return bRet;

	}

	/**
	 * <P>This method is used to process the default
	 * parameters for all the ranges. The defaults are
	 * applied to all the packages that do not override
	 * with their own specific values.</P>
	 *
	 * @param parmsNode	The node containing the parm blocks.
	 *
	 * @return True if the node is parsed successfully, false
	 *	if it fails.
	 *
	 */
	protected boolean processDefaultParms(Node parmsNode)
	{
		boolean bRet = true;

		NodeList nl = parmsNode.getChildNodes();
		int size = nl.getLength();

		for(int i = 0;i < size && bRet;i++)
		{
			Node curNode = nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
				if(curTag.equals(PARM))
				{
					Parameter parm = processParm(curNode);
					if(!parm.isValid())
					{
						continue; // do the next loop
					}

					if (parm.getName().equalsIgnoreCase(RETRIES))
					{
						m_packDefRetries = -1;
						try
						{
							m_packDefRetries = Long.parseLong(parm.getValue());
						}
						catch(NumberFormatException e) { }

						// keep track of the minimum retries
						if (m_defaultRetries == -1 || m_packDefRetries < m_defaultRetries)
						{
							m_defaultRetries = m_packDefRetries;
						}

					}
					else if (parm.getName().equalsIgnoreCase(TIMEOUT))
					{
						m_packDefTimeout = -1;
						try
						{
							m_packDefTimeout = Long.parseLong(parm.getValue());
						}
						catch(NumberFormatException e) { }

						// keep track of the minimum timeout
						if (m_defaultTimeout == -1 || m_packDefTimeout < m_defaultTimeout)
						{
							m_defaultTimeout = m_packDefTimeout;
						}
					}
				}
			} // end if node is ELEMENT TYPE
		} // end for(...)

		return bRet;
	}

	/**
	 * <P>This method is used to process the list of IP address
	 * ranges that should be included in the addresses used
	 * to discover the network. The processIncRangeParms method
	 * is called repeatly to process the multiple ranges that
	 * are to be used by discovery.</P>
	 *
	 * @param rangesNode	The toplevel DOM node containing
	 *	the inclusion ranges.
	 *
	 * @return True if successful in processing the parms, 
	 *	false if an error occurs.
	 *
	 */
	protected boolean processIncRange(Node rangesNode)
	{
		boolean bRet = true;

		NodeList nl = rangesNode.getChildNodes();
		int size = nl.getLength();

		for(int i = 0;i < size && bRet;i++)
		{
			Node curNode = nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
				if(curTag.equals(PARMS))
				{
					bRet = processIncRangeParms(curNode);
				}
			}
		}
		
		return bRet;
	}

	/**
	 * <P>This method is used to process a parm block that
	 * contains range information for inclusion into the 
	 * discovery process. The processed information will
	 * be added to the m_incRanges list for use by the
	 * discovery process.</P>
	 *
	 * @param tabNode	The DOM node containing the 
	 *	relevant part of the tree.
	 *
	 * @return True if successful, false on error.
	 *
	 */
	protected boolean processIncRangeParms(Node tabNode)
	{
		boolean bRet = true;

		NodeList nl = tabNode.getChildNodes();
		int size    = nl.getLength();

		/* values to expect */
		String	fromIP = "0.0.0.0";
		String	toIP   = "0.0.0.0";

		long	retries = m_packDefRetries;
		long	timeout = m_packDefTimeout;

		for(int i = 0;i < size;i++)
		{
			Node curNode = nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
				if(curTag.equals(PARM))
				{
					Parameter parm = processParm(curNode);

					if(parm.isValid())
					{
						//
						// if parm value is '<default>', replace with 
						// the actual value
						//
						if(parm.getName().equals(RETRIES))
						{
							retries = m_packDefRetries;
							if(! parm.getValue().equals(TAKE_DEFAULT_VALUE))
							{
								try
								{
									retries = Long.parseLong(parm.getValue());
								}
								catch(NumberFormatException e) { }
							}
					 	}
						else if(parm.getName().equals(TIMEOUT) )
						{
							timeout = m_packDefTimeout;
							if(! parm.getValue().equals(TAKE_DEFAULT_VALUE))
							{
								try
								{
									timeout = convertTimeToLong(parm.getValue());
								}
								catch(NumberFormatException ne) { }
							}
						}
						else if(parm.getName().equals(FROM))
						{
							if(parm.getType().equalsIgnoreCase("int"))
							{
								fromIP = convertIntToIP(parm.getValue());
							}
							else
							{
								fromIP = parm.getValue();
							}
						}
						else if (parm.getName().equals(TO))
						{
							if(parm.getType().equalsIgnoreCase("int"))
							{
								toIP = convertIntToIP(parm.getValue());
							}
							else
							{
								toIP = parm.getValue();
							}
						}
					} // end if parm is valid
				} // end if parm tag
			} // end if node is ELEMENT 
		} // end for loop

		//
		// try to convert the information from the parameter block
		// into an address range for use by discovery.
		//
		IPPollRange incRange = null;
		try
		{
			//
			// create a new poll range for the 
			// start, stop, timeout, and retries.
			//
			incRange = new IPPollRange(fromIP, toIP, timeout, retries);
			m_incRanges.add(incRange);
		}
		catch(UnknownHostException e) { }

		//
		// return true if the block got
		// parsed correctly.
		//
		return (incRange == null ? false : true);
	}

	/**
	 * <P>This method is used to process an excluded range in 
	 * the XML configuration file. An exclusion block will
	 * consist of one or more parm blocks that contain 
	 * address ranges to exclued. The excluded ranges will
	 * be added to the m_excRanges for use by the discovery
	 * applciation.</P>
	 *
	 * @param rangesNode	The exclusion range nodes.
	 *
	 * @return True on success, false on error.
	 *
	 */
	protected boolean processExcRange(Node rangesNode)
	{
		boolean bRet = true;

		NodeList nl = rangesNode.getChildNodes();
		int size = nl.getLength();

		for(int i = 0;i < size && bRet;i++)
		{
			Node curNode = nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
				if(curTag.equals(PARMS))
				{
					bRet = processExcRangeParms(curNode);
				}

			}
		}
		
		return bRet;
	}

	/**
	 * <P>This method is designed to process the individual parm
	 * blocks for an excluded range address. The parm block contains
	 * a start and stop range that need to be converted to an
	 * IPAddressRange object that is added to the exclusion list.</P.
	 *
	 * @param tabNode	The node containing the parm block.
	 *
	 * @return True if the call is successful, false if an error occurs.
	 *
	 */
	protected boolean processExcRangeParms(Node tabNode)
	{
		NodeList nl = tabNode.getChildNodes();
		int size    = nl.getLength();

		/* values to expect */
		String	fromIP = "0.0.0.0";
		String	toIP   = "0.0.0.0";

		for(int i = 0;i < size;i++)
		{
			Node curNode = nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
				if(curTag.equals(PARM))
				{
					Parameter parm = processParm(curNode);

					if(parm.isValid())
					{
						if (parm.getName().equals(FROM))
						{
							if (parm.getType().equalsIgnoreCase("int"))
							{
								fromIP = convertIntToIP(parm.getValue());
							}
							else
							{
								fromIP = parm.getValue();
							}
						}

						else if (parm.getName().equals(TO))
						{
							if (parm.getType().equalsIgnoreCase("int"))
							{
								toIP = convertIntToIP(parm.getValue());
							}
							else
							{
								toIP = parm.getValue();
							}
						}

					}
				}

			}

		}

		//
		// create a new IPAddressRange and add to the list
		//
		IPAddressRange addrRange = null;
		try
		{
			addrRange = new IPAddressRange(fromIP, toIP);
			m_excRanges.add(addrRange);
		}
		catch(UnknownHostException e)
		{
			m_exceptionMsg = "Problem with range: " + fromIP + "-" + toIP;
		}

		//
		// return success if the address range
		// is not null. False if it is
		//
		return (addrRange == null ? false : true);
	}

	/**
	 * <P>This method is used to process multiple 
	 * parameter blocks that exist as childern of the
	 * passed node. If a "parms" block exist then the
	 * <EM>processSpecificParms</EM> method is called
	 * to handle the DOM elements.</P>
	 *
	 * @param specificsNode	The DOM element representing 
	 *	the parent of the parms block.
	 *
	 * @return True if the parsing is succcessful, false
	 *	if an error occurs.
	 *
	 */
	protected boolean processSpecific(Node specificsNode)
	{
		boolean bRet = true;

		NodeList nl = specificsNode.getChildNodes();
		int size = nl.getLength();

		for(int i = 0;i < size && bRet;i++)
		{
			Node curNode = nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
				if(curTag.equals(PARMS))
				{
					bRet  = processSpecificParms(curNode);
				}
			}
		}
		
		return bRet;
	}

	/**
	 * <P>Process the parameters associated with a specific IP 
	 * Address in the XML configuation file. If the elements
	 * are processed correctly then a new IPPollAddress element
	 * will be added to the m_specifics list of objects.</P>
	 *
	 * @param tabNode	The node containing the parameter information.
	 *
	 * @return True if the subtree is processed correctly, false otherwise.
	 *
	 */
	protected boolean processSpecificParms(Node tabNode)
	{
		boolean bRet = true;

		NodeList nl = tabNode.getChildNodes();
		int size    = nl.getLength();

		/* values to expect */
		String	specIP = "0.0.0.0";

		//
		// go ahead and setup the values that will be 
		// the defaults unless the childern nodes contain
		// the information we need.
		//
		long	retries = m_packDefRetries;
		long	timeout = m_packDefTimeout;

		//
		// Process all the childern node.
		//
		for(int i = 0;i < size;i++)
		{
			Node curNode = nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
				if(curTag.equals(PARM))
				{
					//
					// Process the parm block of the XML file
					//
					Parameter parm = processParm(curNode);
					if(!parm.isValid())
						continue;
					
					//
					// if parm value is '<default>', replace with 
					// the actual value
					//
					if (parm.getName().equalsIgnoreCase(RETRIES))
					{
						if (parm.getValue().equals(TAKE_DEFAULT_VALUE))
						{
							retries = m_packDefRetries; 
						}
						else
						{
							try
							{
								retries = Long.parseLong(parm.getValue());
							}
							catch(NumberFormatException ne)
							{
								Log.print(Log.WARNING, "Error parsing retries value \"" + parm.getValue() + "\"");
								Log.print(Log.WARNING, ne);
								retries = m_packDefRetries;
							}
						}
					}
					else if (parm.getName().equalsIgnoreCase(TIMEOUT) )
					{
						if(parm.getValue().equals(TAKE_DEFAULT_VALUE))
						{
							timeout = m_packDefTimeout; 
						}
						else
						{
							try
							{
								timeout = convertTimeToLong(parm.getValue());
							}
							catch(NumberFormatException ne)
							{
								Log.print(Log.WARNING, "Error parsing time value \"" + parm.getValue() + "\"");
								Log.print(Log.WARNING, ne);
							}
						}
					}
					else if(parm.getName().equals(SPECIP))
					{
						if (parm.getType().equalsIgnoreCase("int"))
						{
							specIP = convertIntToIP(parm.getValue());
						}
						else
						{
							specIP = parm.getValue();
						}
					}
					
				} // end if tag == PARAM
			} // end if DOM node is ELEMENT type
		} // end for(...)

		IPPollAddress pollAddr = new IPPollAddress(specIP, timeout, retries);
		m_specifics.add(pollAddr);

		return true;
	}

	/**
	 * <P>This method is used to process the DTDs 
	 * parameter block. The parameter block consist of
	 * a name, value, and the values type as an attribute.
	 * The elements are parsed out and stored in the
	 * returned <EM>Parameter</EM> object.</P>
	 *
	 * @param parmsNode	The node containing the parameter information
	 *
	 * @return The Parameter object containing the parsed data on success.
	 *	If an error occurs then a <EM>null</EM> is returned.
	 *
	 */
	protected Parameter processParm(Node parmsNode)
	{
		boolean bRet = false;
		NodeList nl  = parmsNode.getChildNodes();
		int size     = nl.getLength();
		Parameter parm = new Parameter();
		
		for(int i = 0;i < size;i++)
		{
			Node curNode = nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
				if(curTag.equals(PARM_NAME))
				{
					//
					// process the parameter name
					//
					processParmName(curNode, parm);
				}
				else if(curTag.equals(PARM_VALUE))
				{
					//
					// process the parameter value
					//
					processParmValue(curNode, parm);
				}
			}
		}

		//
		// if everything is ok then return the
		// parameter object with the parsed information.
		//
		return parm;
	}

	/**
	 * <P>This method process the parameter <EM>&lt;name&gt;</EM>
	 * element of the parameter block in the DTD. The value
	 * for the element is returned to the caller upon success.</P>
	 *
	 * @param parmNameNode	The DOM Node containing the parm name.
	 * @param parm		The parameter element to store the name.
	 *
	 * @return True if the call succeeds, false if an error occurs.
	 */
	protected boolean processParmName(Node parmNameNode, Parameter parm)
	{
		String parmName = null;

		Node temp = parmNameNode.getChildNodes().item(0);
		if (temp.getNodeType() == Node.TEXT_NODE)
			parmName = ((Text)temp).getData();
		
		parm.setName(parmName);
		return true;
	}

	/**
	 * <P>Process the <EM>&lt;value&gt;</EM> element of the <EM>parm</EM>
	 * block and returns the information in the passed parm element.
	 * If the data is successfully extracted then a value of true is
	 * returned. If an error occurs then a false value is returned.</P>
	 *
	 * @param parmValNode	The node element from the DOM parser.
	 * @param parm		The [in/out] element modified by the call.
	 *
	 * @return True if the call succeeds, false if an error occurs.
	 */
	protected boolean processParmValue(Node parmValNode, Parameter parm)
	{
		String parmVal = null;

		//
		// Get the first item and extract the data
		//
		Node temp = parmValNode.getChildNodes().item(0);
		if (temp.getNodeType() == Node.TEXT_NODE)
			parmVal = ((Text)temp).getData();
		
		//
		// if the value is null then return 
		// a false, indicating that the call failed.
		//
		if (parmVal == null)
			return false;

		//
		// extract the attribute value
		//
		String parmType = ((Element)parmValNode).getAttribute(PARM_TYPE);

		//
		// Save the data and return the success code.
		//
		parm.setType(parmType);
		parm.setValue(parmVal);
		
		return true;
	}

	/**
	 * <P>Creates the new parser that can be used to disassemble
	 * an XML file corresponding to the <EM>packages.dtd</EM> as
	 * defined by the OpenNMS specifications. A new instance of
	 * a DOM parser is created to parse the passed file. The
	 * list of package that should be read by the parser are
	 * passed to the object on construction.</P>
	 *
	 * @param packages	The list of packages to be read.
 	 */
	public DiscIcebergParser(List packages)
	{
		super();
		
		m_readPackage = false;
		m_defaultTimeout = -1;
		m_defaultRetries = -1;
		
		m_packages = packages;
		
		m_incRanges = new ArrayList();
		m_excRanges = new ArrayList();
		m_specifics = new ArrayList();
		
	}

	


	/**
	 * <P>Returns the list of IP Address Ranges that
	 * are to be included when polling the network.</P>
	 *
	 * @return The list of IPAddressRange object to be included.
	 */
	public List getIncludeRanges()
	{
		return m_incRanges;
	}

	/**
 	 * <P>Returns the list of IP Address ranges that
	 * should not be included when polling the network.
	 *
	 * @return The list of IPAddressRange objects to exclude
	 */
	public List getExcludeRanges()
	{
		return m_excRanges;
	}

	/**
	 * <P>Returns the list of specific IP Addresses that
	 * should attempt to be contacted by disocvery. This
	 * is a list of IPPollAddress objects.</P>
	 *
	 * @return The list of specific IPPollAddress objects 
	 *	to discover.
	 */
	public List getSpecifics()
	{
		return m_specifics;
	}

	/**
	 * <P>Returns the global value for the minimum amount of
	 * time to wait between retries. This value is measured
	 * in milliseconds. If no default value is found in 
	 * the package specification then a value of -1 is 
	 * returned by the method.</P>
	 *
	 * @return The default timeout for discovery, in milliseconds.
	 */
	 public long getDefaultTimeout()
	 {
	 	return m_defaultTimeout;
	 }

	/**
	 * <P>Returns the global value for the minimum number of retries
	 * for all the packages. If no retries were found in the packages
	 * then a value of <EM>-1</EM> will be returned by the method.</P>
	 *
	 * @return The global number of retries for discovery.
	 */
	 public long getDefaultRetries()
	 {
	 	return m_defaultRetries;
	 }
}

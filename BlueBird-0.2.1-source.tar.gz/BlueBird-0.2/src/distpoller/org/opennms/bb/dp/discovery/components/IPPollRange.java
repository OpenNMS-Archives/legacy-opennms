//
// Copyright (C) 2000 N*Manage Company Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
// Tab Size = 8
//
// $Id: IPPollRange.java,v 1.5 2000/08/01 17:51:05 weave Exp $
//

package org.opennms.bb.dp.discovery.components;

import java.lang.*;
import java.net.*;
import java.util.*;

/**
 * <P>The IPPollRange class is used to encapsulate a range
 * of addresses that are assocaited with a timeout and
 * retry count. The core class encapsulated is the IPAddressRange
 * class.</P>
 *
 * <P>The IPPollRange class can generate either an Iterator or
 * an Enumeration to cycle over the addresses. The generated
 * objects encapsulate generators returned by the IPAddressRange
 * object and simply attach the correct timeout and retry for
 * the new objects.</P>
 *
 *
 * @author <A HREF="mailto:sowmya@opennms.org">Sowmya</A>
 * @author <A HREF="mailto:weave@opennms.org">Brian Weaver</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version $Revision: 1.5 $
 */
public class IPPollRange
{
	/**
	 * The range to cycle over.
	 */
	private IPAddressRange	m_range;
	
	/**
	 * The timeout in milliseconds (1/1000th) 
	 */
	private long		m_timeout;
	
	/**
	 * The number of retries for each generate
	 * object.
	 */
	private long		m_retries;

	/**
	 * <P>Creates an IPPollRange object that can be used to
	 * generate IPPollAddress objects. The addresses are 
	 * encapsulated by the range object and the values of timeout
	 * and retry are set in each generated IPPollAddress object.</P>
	 *
	 * @param fromIP	The start of the address range to cycle over.
	 * @param toIP		The end of the address range to cycle over.
	 * @param timeout	The timeout for each generated IPPollAddress.
	 * @param retries	The number of retries for generated addresses.
	 *
	 * @see IPPollAddress
	 * @see IPAddressRange
	 *
	 */
	public IPPollRange(String fromIP, String toIP, long timeout, long retries)
		throws java.net.UnknownHostException
	{
		m_range = new IPAddressRange(fromIP, toIP);
		m_timeout= timeout;
		m_retries= retries;
	}
	
	/**
	 * <P>Creates an IPPollRange object that can be used to
	 * generate IPPollAddress objects. The addresses are 
	 * encapsulated by the range [start..end] and the values of timeout
	 * and retry are set in each generated IPPollAddress object.</P>
	 *
	 * @param start		The start of the address range to cycle over.
	 * @param end		The end of the address range to cycle over.
	 * @param timeout	The timeout for each generated IPPollAddress.
	 * @param retries	The number of retries for generated addresses.
	 *
	 * @see IPPollAddress
	 * @see IPAddressRange
	 *
	 */
	public IPPollRange(InetAddress start, InetAddress end, long timeout, long retries)
	{
		m_range = new IPAddressRange(start, end);
		m_timeout = timeout;
		m_retries = retries;
	}

	/**
	 * <P>Creates an IPPollRange object that can be used to
	 * generate IPPollAddress objects. The addresses are 
	 * encapsulated by the range object and the values of timeout
	 * and retry are set in each generated IPPollAddress object.</P>
	 *
	 * @param range		The address range to cycle over.
	 * @param timeout	The timeout for each generated IPPollAddress.
	 * @param retries	The number of retries for generated addresses.
	 *
	 * @see IPPollAddress
	 *
	 */
	public IPPollRange(IPAddressRange range, long timeout, long retries)
	{
		m_range = range;
		m_timeout= timeout;
		m_retries= retries;
	}

	/**
	 * <P>Returns the timeout set for the object. The
	 * timeout should be in 1/1000th of a second increments.</P>
	 */
	public long getTimeout()
	{
		return m_timeout;
	}

	/**
	 * <P>Returns the retry count for the object.</P>
	 */
	public long getRetries()
	{
		return m_retries;
	}
	
	/**
	 * <P>Returns the configured address ranges that
	 * are encapsulated by this object.</P>
	 */
	public IPAddressRange getAddressRange()
	{
		return m_range;
	}

	/**
	 * <P>Returns an Enumeration that can be used to
	 * cycle over the range of pollable addresses.</P>
	 */
	public Enumeration elements()
	{
		return new IPPollRangeGenerator(m_range.elements());
	}
	
	/**
	 * <P>Returns an Iterator object that can be used to 
	 * cycle over the range of pollable address information.</P>
	 */
	public Iterator iterator()
	{
		return new IPPollRangeGenerator(m_range.elements());
	}

	/**
	 * <P>The purpose of the IPPollRangeGenerator class is to provide
	 * an Enumeration or Iterator object that can be returned by the
	 * encapsulating class. The class implements the new style Iterator
	 * interface, as well as the old style Enumeration to allow the 
	 * developer freedom of choice when cycling over ranges.</P>
	 *
	 * @see java.util.Iterator
	 * @see java.util.Enumeration
	 */
	private class IPPollRangeGenerator 
		implements Enumeration, Iterator
	{
		/**
		 * <P>The range of address to generate.</P>
		 */
		private Enumeration	m_range;
		
		/**
		 * <P>Creates a poll range generator object.</P>
		 *
		 * @param enum	The Enumeration to use for address generation.
		 */
		public IPPollRangeGenerator(Enumeration enum)
		{
			m_range = enum;
		}
		
		/**
		 * <P>Returns true if the Enumeration described
		 * by this object still has more elements.</P>
		 */
		public boolean hasMoreElements()
		{
			return m_range.hasMoreElements();
		}
		
		/**
		 * <P>Returns the next IPPollAddress in the enumeration.</P>
		 *
		 * @exception java.util.NoSuchElementException Thrown if there
		 * 	are no more elements in the iteration.
		 */
		public Object nextElement()
		{
			return new IPPollAddress((String)m_range.nextElement(), 
						 m_timeout, 
						 m_retries);
		}

		/**
		 * <P>If there are more elements left in the iteration
		 * then a value of true is returned. Else a false value
		 * is returned.</P>
		 */
		public boolean hasNext()
		{
			return hasMoreElements();
		}
		
		/**
		 * <P>Returns the next object in the iteration and increments
		 * the internal pointer.</P>
		 *
		 * @exception java.util.NoSuchElementException Thrown if there
		 * 	are no more elements in the iteration.
		 */
		public Object next()
		{
			return nextElement();
		}
		
		/**
		 * The remove method is part of the Iterator interface and
		 * is optional. Since it is not implemnted it will always
		 * throw an UnsupportedOperationException.
		 *
		 * @exception java.lang.UnsupportedOperationException Always thrown
		 * 	by this method.
		 */
		public void remove()
		{
			throw new UnsupportedOperationException("remove operation not supported");
		}
	}
}

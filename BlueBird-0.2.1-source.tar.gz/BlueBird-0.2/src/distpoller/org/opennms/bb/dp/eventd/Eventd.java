//
// Copyright (C) 2000 N*Manage Company, Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//  Brian Weaver    <weave@opennms.org>
//  http://www.opennms.org/
//
// Tab Size = 8
//
package org.opennms.bb.dp.eventd;

import java.io.*;
import java.util.*;
import java.sql.SQLException;
import com.sun.media.jsdt.*;
import org.apache.xerces.parsers.SAXParser;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import org.opennms.bb.common.components.*;
import org.opennms.bb.dp.common.components.*;
import org.opennms.bb.dp.events.*;

/**
 * <P>Eventd listens for events from the discovery, capsd, trapd processes
 * and sends events to the Master Station when queried for.</P>
 *
 * <P>Eventd receives events sent in as XML, looks up the event.conf and
 * adds information to these events and stores them to the db. It also
 * reconverts them back to XML to be sent to other processes like 'actiond'</P>
 *
 * <P>Process like trapd, capsd etc. that are local to the distributed poller
 * use JSDT to send events to the eventd. Events can also be sent via
 * TCP or UDP to eventd
 *
 * <P>Eventd has the following components - EventListener, EventExpandManager,
 * and EventPersistd to listen for incoming events, load info from the 
 * 'event.conf' and to add the expanded events to the database respectively.
 * The events added to the database are then sent out via JSDT
 *
 * @author 	<A HREF="mailto:sowmya@opennms.org">Sowmya Kumaraswamy</A>
 * @author	<A HREF="http://www.opennms.org">OpenNMS.org</A>
 *
 * @version	$Revision: 1.1 $
 */
public class Eventd
{
	/**
	 * The thread that listens to incoming threads
	 */
	private EventListener	m_listener;

	/**
	 * the thread that is responsible for writing event data to the db
	 */
	private	EventPersistd	m_persistd;

	/**
	 * The queue of EventReaders from the TCP/UDP/JSDT
	 * receivers. These events have already been run
	 * so all events are already decomposed.
	 */
	private	PCQueue		m_bridgeQ;

	/**
 	 * The jsdt session that all tranactions should occur
	 * on.
	 */
	private static Session	m_session;
	
	/**
	 * The JSDT client that is registered for the session
	 * and channels.
	 */
	private static Client	m_client;
	
	/**
	 * The list of elements in each event that cannot be overridden
	 * by the input source. If an input event has one of the fields
	 * set then it is discarded by the event stream.
	 */
	private	static List	m_overrides;
	
	/**
	 * The list of base events from the event configuration file.
	 * This is loaded once when the Event object is loaded by the
	 * system, and again if the loadConfiguration() method is called
	 * to explicitily load the events.
	 */
	private static Map	m_eventConf;

	/**
	 * <P>The properties that are specific to the eventd process. The 
	 * properties are a combination of the JVM's system properties, plus
	 * the inclusion of the OpenNMS specific property files. There are two
	 * additional files that are loaded, if the system properties are 
	 * correctly set.</P>
	 *
	 * <P>In order to properly load the OpenNMS specific file(s) their
	 * location must be known in advance. Instead of hard coding the
	 * location of the files, the files are referenced by properties.
	 * The following list declares the properites that reference the 
	 * specific files. The property files are loaded in the order
	 * they appear in the list.</P>
	 *
	 * <UL>
	 *	<LI>org.opennms.bluebird.propertyFile</LI>
	 *	<LI>org.openmms.bluebird.eventd.propertyFile</LI>
	 * </UL>
	 *
	 * <P>Currently the string returned for the propertyFile(s) must
	 * be a file on the local filesystem. Later support for remote
	 * files via HTTP, JSDT, etc al may be supported.</P>
	 */
	private static Properties	m_properties = null;
	
	/**
	 * The JSDT client.
	 */
	private static class EventdClient implements Client
	{
		static final String clientName = "Eventd";
		
		public String getName()
		{
			return clientName;
		}
		
		public Object authenticate(AuthenticationInfo authinfo)
		{
			return null;
		}
	}
	
	/**
	 * <P>Copy the System properties and then load the bluebird
	 * and eventd specific files into the property object.
	 * For more information see the javadoc comment for the m_properties
	 * element.</P>
	 *
	 * <P>Additionally, this static loading will also look at the debugging 
	 * options and will setup the Logging Facility. This can only be done
	 * after the properties have been loaded.</P>
	 */
	static
	{
		//
		// Init the jsdt client
		//
		m_client = new EventdClient();
		m_session = null;
	
		//
		// Initialize the configuration data
		//
		m_overrides = null;
		m_eventConf = null;
		
		//
		// get a new properties element and make the 
		// system properties the backing map
		//
		m_properties = System.getProperties();

		//
		// try to load the bluebird specific properties
		//
		String file = m_properties.getProperty("org.opennms.bluebird.propertyFile");
		if(file != null)
		{
			FileInputStream pfile = null;
			try
			{
				m_properties = new Properties(m_properties);
				pfile = new FileInputStream(file);
				m_properties.load(pfile);
				pfile.close();
			}
			catch(IOException e) 
			{
				// do nothing
			}
		}

		//
		// Load the eventd specific files now
		//
		file = m_properties.getProperty("org.opennms.bluebird.eventd.propertyFile");
		if(file != null)
		{
			FileInputStream pfile = null;
			try
			{
				m_properties = new Properties(m_properties);
				pfile = new FileInputStream(file);
				m_properties.load(pfile);
				pfile.close();
			}
			catch(IOException e)
			{
				// do nothing
			}
		}
		System.setProperties(m_properties);
		// end static load of properties.

		//
		// setup the debug and log facility for eventd
		//
		Log.setLevel(0);
		String logLevel = m_properties.getProperty("org.opennms.bluebird.eventd.logLevel");
		if(logLevel != null)
		{
			try
			{
				Log.setLevel(Integer.parseInt(logLevel));
			}
			catch(NumberFormatException ne) { Log.setLevel(Log.WARNING); }
		}
		
		file = m_properties.getProperty("org.opennms.bluebird.eventd.logFile");
		if(file != null)
		{
			try
			{
				Log.setOut(file);
			}
			catch(IOException e)
			{
				Log.disable();
			}
		}

		// end Log class setup
		
	} // end static class initialization

	/**
	 * Eventd constructor creates the eventlistener to listen for events..
	 *
	 *
	 * @exception org.opennms.bb.dp.eventd.EventListenerException if the event 
	 *	listener communication channels cannot be set up
	 * @exception java.lang.NullPointerException Thrown if the properties eventd 
	 *	is looking for cannot be read
	 * @exception com.sun.media.JSDTPropertiesException Thrown if the JSDT 
	 *	communication channel cannot be established
	 */
	public Eventd()
		throws JSDTException, SQLException, EventListenerException
	{
		m_bridgeQ	= new PCQueueLinkedList();
		m_listener	= new EventListener(m_bridgeQ);
		m_persistd	= new EventPersistd(m_bridgeQ);
	}
	
	/**
	 *
	 * @exception java.lang.NullPointerException Thrown if a required property cannot be found.
	 *
	 */
	public static synchronized void loadConfiguration()
		throws IOException, SAXException
	{
		//
		// Check to see if the properties are set properly
		//
		String fdir = m_properties.getProperty(EventdConstants.PROP_XML_REPOSITORY);
		if(fdir == null)
			throw new NullPointerException("Unable to load property \"" + EventdConstants.PROP_XML_REPOSITORY + "\"");

		//
		// See if the required file exists, if it does
		// not exists then throw a file not found exception
		//
		// Note: Should we fall back to the default (current) directory or look
		// in a jar file for the required configuration file?
		//
		if(!fdir.endsWith(File.separator))
			fdir = fdir + File.separator;
		File f = new File(fdir + EventdConstants.EVENT_CONF_FNAME);
		if(!f.exists())
			throw new FileNotFoundException("The event configuration file does not exist, file = " + fdir + EventdConstants.EVENT_CONF_FNAME);

		//
		// Create the base event parser
		//
		XMLEventsConfParser econf = new XMLEventsConfParser();

		//
		// Create the Xerces SAX based parser
		//
		SAXParser xsaxp = new SAXParser();	// Xerces SAX parser

		//
		// set out parser as the error handler and
		// context handler.
		//
		xsaxp.setContentHandler(econf);
		xsaxp.setErrorHandler(econf);

		//
		// Now parse the file, this may actually
		// throw a SAXException
		//
		InputStream is = new FileInputStream(f);
		xsaxp.parse(new InputSource(is));
		is.close();
		
		//
		// set the overrides and events
		//
		m_overrides = econf.getOverrides();
		m_eventConf = new TreeMap();
		List e	    = econf.getEvents();
		if(e != null)
		{
			//
			// Stuff the events into the map
			//
			Iterator i = e.iterator();
			while(i.hasNext())
			{
				EventBase event = (EventBase)i.next();
				m_eventConf.put(event.getUEI(), event);
				if(event.hasSnmpInfo() && event.getSnmpInfo().getEnterpriseID() != null)
					m_eventConf.put(event.getSnmpInfo().getEnterpriseID(), event);
			}
		}
	} // end loadConfig()
	
	/** 
	 * Opens up hte current JSDT session for the event daemon.
	 * If the session was already open then an exception will 
	 * be generated.
	 *
	 * @exception com.sun.media.jsdt.JSDTException	Thrown if an error occurs
	 * 	openning the session.
	 * @exception java.lang.IllegalStateException Thrown if the session was
	 * 	already open for the eventd system.
	 *
	 */
	public static synchronized void initSession()
		throws JSDTException
	{
		if(m_session != null)
			throw new IllegalStateException("Session already initialized");
			
		if(RegistryFactory.registryExists(PollerJSDTConstants.REGISTRY_TYPE) == false)
			throw new NoRegistryException(); 	// can't add message... DORKS!
		
		//
		// Create and join the session
		//
		URLString sess = URLString.createSessionURL(PollerJSDTConstants.HOSTNAME,
							    PollerJSDTConstants.EVENTS_SESSION_PORT,
							    PollerJSDTConstants.REGISTRY_TYPE,
							    PollerJSDTConstants.EVENTS_SESSION_NAME);
		
		try
		{
			m_session = SessionFactory.createSession(m_client, sess, true);
		}
		catch(JSDTException je)
		{
			m_session = null;
			throw je;
		}
	}
	
	/**
	 * Closes the global JSDT communication session for the 
	 * event daemon. If the session has already been closed
	 * then an exception will be generated.
	 *
	 * @exception com.sun.media.jsdt.JSDTException Thrown if an error
	 *	occurs shutting down the session.
	 * @exception java.lang.IllegalStateException Thrown if the session
	 * 	was not open.
	 *
	 */
	public static synchronized void closeSession()
		throws JSDTException
	{
		if(m_session == null)
			throw new IllegalStateException("The session is already closed");
		
		try
		{
			m_session.close(false);
		}
		catch(JSDTException je)
		{
			throw je;
		}
		finally
		{
			m_session = null;
		}
	}
	
	/**
	 * Returns the global Event daemon session to the requestor.
	 * There is only one session per JVM for the event daemon.
	 * Thus there can only be one eventd per JVM.
	 *
	 * @return The global JSDT session.
	 *
	 * @exception java.lang.IllegalStateException Thrown if the
	 * 	session has not yet been initalized.
	 */
	public static synchronized Session getSession()
	{
		if(m_session == null)
			throw new IllegalStateException("The session is not currently open");

		return m_session;
	}
	
	/**
	 * Returns the JSDT Client for the event system.
	 * This client can be shared, so long as there is 
	 * one and only one listener per channel.
	 *
	 */
	public static Client getClient()
	{
		return m_client;
	}

	/**
	 * <P>Initiates the shutdown sequence and  waits for 
	 * this thread to exit.</P>
	 */
	public synchronized void shutdown()
	{
		m_listener.shutdown();
		m_persistd.shutdown();
	}
	
	public synchronized void start()
	{
		m_listener.start();
		m_persistd.start();
	}
		

	/**
	 * @return all the loaded properties
	 */
	public static Properties getProperties()
	{
		return m_properties;
	}
	
	/**
	 * @return value for the specified property
	 */
	public static String getProperty(String key)
	{
		return m_properties.getProperty(key);
	}
	
	/**
	 * Returns list of strings that must be
	 * reset in the parser.
	 */
	public static synchronized List getOverrides()
	{
		return m_overrides;
	}
	
	/**
	 * <P>Find the mapped event base object for the passed key.
	 * When the event configuration is loaded the event base
	 * objects are indexed using their UEI and if available, the
	 * SNMP Enterprise identifier.</P>
	 *
	 * @param key	The key for the required event base object.
	 *
	 * @return The base configuration object.
	 */
	public static synchronized EventBase getEventByName(String key)
	{
		EventBase e = null;
		if(m_eventConf != null)
			e = (EventBase)m_eventConf.get(key);
		
		return e;
	}
	
	/**
	 * Start up Eventd
	 */
	public static void main(String[] args)
	{
		try
		{
			Eventd.loadConfiguration();
		}
		catch(FileNotFoundException fnfe)
		{
			Log.print(Log.ERROR, "Error loading the events configuration file.");
			Log.print(Log.ERROR, fnfe);
			System.exit(1);
		}
		catch(IOException ioe)
		{
			Log.print(Log.ERROR, "Unknown I/O error while attempting to load the events configuration file");
			Log.print(Log.ERROR, ioe);
			System.exit(1);
		}
		catch(NullPointerException ne)
		{
			Log.print(Log.ERROR, "A required property for the data directory could not be found");
			Log.print(Log.ERROR, ne);
			System.exit(1);
		}
		catch(SAXException se)
		{
			Log.print(Log.ERROR, "The configuration file had errors, not loaded");
			Log.print(Log.ERROR, se);
			System.exit(1);
		}
		catch(Exception ue)
		{
			Log.print(Log.ERROR, "An unknown exception occured while trying to load the configuration file");
			Log.print(Log.ERROR, ue);
			System.exit(1);
		}
			

		try
		{
			Eventd.initSession();
			Eventd daemon = new Eventd();
			daemon.start();
		}
		catch(JSDTException je)
		{
			Log.print(Log.ERROR, "An error occured initializing the communications channels");
			Log.print(Log.ERROR, je);
			System.exit(1);
		}
		catch(SQLException sqlE)
		{
			Log.print(Log.ERROR, "An error occured initializing the database connections");
			Log.print(Log.ERROR, sqlE);
			System.exit(1);
		}
		catch(EventListenerException e)
		{
			Log.print(Log.ERROR, "An error occured initializing the event listeners");
			Log.print(Log.ERROR, e);
			System.exit(1);
		}
		
		
	}
}

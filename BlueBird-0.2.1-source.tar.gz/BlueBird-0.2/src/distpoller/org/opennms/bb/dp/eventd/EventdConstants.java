//
// Copyright (C) 2000 N*Manage Company Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
// Tab Stop = 8
//
//

package org.opennms.bb.dp.eventd;

import java.lang.*;

/**
 * <P>This class is a repository for constant, static information
 * concerning the database. Currently it is only used to store
 * the property strings that map to database infomation or SQL
 * statements and the XML repository.</P>
 *
 * @author	<A HREF="mailto:weave@opennms.org">Brian Weaver</A>
 * @author	<A HREF="http://www.opennms.org">OpenNMS.org</A>
 *
 * @version	$Revision: 1.1 $
 */
final class EventdConstants
{
	/**
	 * <P>The bluebird property string that defines
	 * the driver used to connect to the JDBC database.</P>
	 */
	public final static String	PROP_DB_DRIVER		= "org.opennms.bluebird.poller.database.driver";
	
	/**
	 * <P>The bluebird property that defines
	 * the connection URL for the JDBC database.</P>
	 */
	public final static String	PROP_DB_URL		= "org.opennms.bluebird.poller.database.url";
	
	/**
	 * <P>The bluebird property that defines 
	 * the database user for the system.</P>
	 */
	public final static String	PROP_DB_USER		= "org.opennms.bluebird.poller.database.user";
	
	/**
	 * <P>The bluebird property that defines
	 * the database user's password.</P>
	 */
	public final static String	PROP_DB_PASSWD		= "org.opennms.bluebird.poller.database.passwd";
	
	/**
	 * <P>The XML repository for finding and loading XML files.</P>
	 */
	 public final static String	PROP_XML_REPOSITORY	= "org.opennms.bluebird.dp.xml.directory";
	//public final static String	PROP_XML_REPOSITORY	= "data.common.conf";

	/**
	 * <P>The property name that contains the sql statement
	 * that is used to get the next event id from sequence.</P>
	 */
	final static String	PROP_DB_GET_NEXTEVENTID	= "org.opennms.bluebird.eventd.database.getNextEventID";
	
	/**
	 * <P>The property name that contains the insertion string used
	 * by eventd to store the event information into the
	 * database.</P>
	 */
	final static String	PROP_DB_INS_EVENT	= "org.opennms.bluebird.eventd.database.insertEvent";
	
	/**
	 * <P>The property name that contains the maximum number of threads
	 * to be used by the EventListener
	 */
	final static String	PROP_MAX_EVENT_LISTENER_THREADS	= "org.opennms.bluebird.eventd.maxEventListenerThreads";

	/**
	 * <P>The property name that contains the maximum number of threads
	 * to be used by the EventPersistd
	 */
	final static String	PROP_MAX_EVENT_WRITER_THREADS	= "org.opennms.bluebird.eventd.maxEventWriterThreads";

	final static String	EVENT_CONF_FNAME	= "eventconf.xml";
}


//
// Copyright (C) 2000 N*Manage Company, Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
// $Id: TestForFtpServer.java,v 1.7 2000/09/13 14:50:18 weave Exp $
//
//
package org.opennms.bb.dp.capsd.plugin;

import java.lang.*;
import java.io.*;
import java.net.*;
import java.util.*;


/**
 * <P>This class is designed to be used by the capabilities
 * daemon to test for the existance of an FTP server on 
 * remote interfaces. The class implements the CapsdPlugin
 * interface that allows it to be used along with other
 * plugins by the daemon.</P>
 *
 * @author <A HREF="mailto:sowmya@opennms.org">Sowmya</A>
 * @author <A HREF="mailto:weave@opennms.org">Weaver</A>
 * @author <A HREF="http://www.opennsm.org">OpenNMS</A>
 *
 * @version $Revision: 1.7 $
 *
 */
public class TestForFtpServer extends java.lang.Object 
	implements CapsdPlugin
{
	/**
	 * <P>The port on which the host is checked to
	 * see if it supports FTP.</P>
	 */
	private static final int	DEFAULT_PORT	= 21;
	
	/**
	 * <P>The capability name of the plugin.</P>
	 */
	private static final String 	CAPABILITY_NAME = "isFTP";
	
	/**
	 * <P>Reads a single line at a time from the input stream. Each line
	 * is terminated by the sequence </EM>'\r\n'</EM>. For more information
	 * on the format of the line see the FTP RFC.</P>
	 *
	 * <P>If the end of file condition is reached before the cariage-return
	 * line-feed sequence then the received buffer is returned, or a string
	 * of zero length.</P>
	 *
	 * <P><EM>NOTE</EM>: The \r\n sequence is stripped from the returned line.</P>
	 *
	 * @param istream	The input stream from which characters are to be read.
	 *
	 * @return A line of characters read off the input stream.
	 *
	 * @exception java.lang.IOException Thrown if an error occurs reading
	 * 	the data from the stream.
	 */
	private String getLine(InputStream istream) 
		throws IOException
	{
		StringBuffer sbuf = new StringBuffer();
		
		boolean done = false;
		while(!done)
		{
			//
			// get the next character from the
			// stream. Ignore the EOF for now
			//
			int i = istream.read();
			if(i == -1)
			{
				done=true;
				continue;
			}
			
			//
			// check for a cariage return
			// character and scan for the
			// newline.
			while(i == (int)'\r')
			{
				i = istream.read();
				if(i == -1)
				{
					sbuf.append('\r');
					done = true;
					break;
				}
				else if(i == '\n')
				{
					return sbuf.toString();
				}
				sbuf.append('\r');
			}

			//
			// if the end of line is not reached
			// then add the character to the buffer.
			// this will include any character received
			// from the above while loop if the \r is not
			// followed by the \n character.
			//
			if(!done)
			{
				sbuf.append((char)i);
			}
		}
		
		return sbuf.toString();
	}
			
	/**
	 * <P>Test to see if the passed host-port pair is the 
	 * endpoint for an FTP server. If there is an FTP server
	 * at that destination then a value of true is returned
	 * from the method. Otherwise a false value is returned 
	 * to the caller.</P>
	 *
	 * @param host	The remote host to connect to.
	 * @param port 	The remote port on the host.
	 *
	 * @return True if server supports FTP on the specified 
	 *	port, false otherwise
	 */
	private boolean isServer(InetAddress host, int port)
	{
		boolean isAServer = false;
		Socket  portal    = null;
		try
		{
			//
			// create a connected socket
			//
			portal = new Socket(host, port);
			portal.setSoTimeout(3000); // 3 second blocking time!
			
			//
			// Tokenize the Banner Line, and check the first 
			// line for a valid return.
			//
			StringTokenizer t = new StringTokenizer(getLine(portal.getInputStream()));
			int rc = Integer.parseInt(t.nextToken());
			if(rc > 99 && rc < 600)
			{
				//
				// FTP should recoginize the QUIT command
				//
				String cmd = "QUIT\r\n";
				portal.getOutputStream().write(cmd.getBytes());
				
				//
				// get the returned string, tokenize, and 
				// verify the correct output.
				//
				t = new StringTokenizer(getLine(portal.getInputStream()));
				rc = Integer.parseInt(t.nextToken());
				if(rc > 99 && rc < 600)
					isAServer = true;
			}
		}
		catch(NumberFormatException e)
		{
			isAServer = false;
		}
		catch(IOException e)
		{
			isAServer = false;
		}
		finally
		{
			try
			{
				if(portal != null)
					portal.close();
			}
			catch(Exception e) { }
		}

		//
		// return the success/failure of this
		// attempt to contact an ftp server.
		//
		return isAServer;
	}

	/**
	 * <P>The default constructor for the object. There is currently
	 * no data to be initialized in the constructor. It is present
	 * for completeness.</P>
	 */
	public TestForFtpServer()
	{
		// do nothing in the default constructor.
	}
	
	/**
	 * <P>Returns true if the host supports FTP.</P> 
	 *
	 * @param  host 	The InetAddress which is to be checked for FTP support
	 *
	 * @return True if the host supports FTP, false otherwise
	 */
	public boolean isProtocolSupported(java.net.InetAddress host)
	{
		return isServer(host, DEFAULT_PORT);
	}

	/**
	 * <P>Returns true if the host supports FTP on the port specified.</P>
	 *
	 * @param  host 	The InetAddress which is to be checked for FTP support.
	 * @param  port 	The port on which the FTP test is to be done.
	 *
	 * @return True if the host supports FTP, false otherwise.
	 */
	public boolean isProtocolSupported(java.net.InetAddress host, int port)
	{
		return isServer(host,port);
	}

	/**
	 * <P>Returns true if the host supports the classes protocol. If the protocl
	 * passed to the method is not supported by this instance the an exception 
	 * is thrown to the caller.</P>
	 *
	 * @param  host    The InetAddress which is to be checked for FTP support
	 * @param  capName The capability whose suport is to be checked for
	 *
	 * @return True if the host supports FTP, false otherwise
	 *
	 * @exception org.opennms.bb.dp.capsd.plugin.UnsupportedProtocolException Thrown 
	 *	if capability specified is not supported by this instance.
	 */
	public boolean isProtocolSupported(java.net.InetAddress host, String capName) 
		throws UnsupportedProtocolException
	{
		if(!CAPABILITY_NAME.equalsIgnoreCase(capName))
			throw new UnsupportedProtocolException(capName + " not supported");

		return isServer(host, DEFAULT_PORT);
	}

	/**
	 * <P>Returns true if the host supports FTP on the specified port 
	 * and the capability specified is 'isFtp'</P>
	 *
	 * @param  host    The InetAddress which is to be checked for FTP support
	 * @param  port    The port number to be used for the FTP support
	 * @param  capName The capability whose suport is to be checked for
	 *
	 * @return True if the host supports FTP, false otherwise
	 *
	 * @exception org.opennms.bb.dp.capsd.plugin.UnsupportedProtocolException Thrown 
	 *	if capability specified is not supported by the instance.
	 */
	public boolean isProtocolSupported(java.net.InetAddress host, int port, String capName) 
		throws UnsupportedProtocolException
	{
		if(!CAPABILITY_NAME.equalsIgnoreCase(capName))
			throw new UnsupportedProtocolException(capName + " not supported");

		return isServer(host, port);
	}

	/**
	 * <P>Returns the capability name of the plugin poller.
	 * In this instance it will be the string "isFTP".</P>
	 *
	 * @return The capability name.
	 */
	public String getCapabilityName()
	{
		return CAPABILITY_NAME;
	}
}

//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.dp.poller.plugins;

import java.io.*;
import java.util.*;

import org.opennms.bb.dp.poller.plugins.JARClassLoader;
import org.opennms.bb.dp.poller.plugins.JARClassLoader.*;

/** 
 * @author <A HREF="mailto:jason@opennms.org">Jason Johns</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version $Revision: 1.1 $
 * 
 */
public class RunFramework
{
	/**
	*/
	private HashMap pluginList;
	
	/**
	*/
	public RunFramework()
	{
		pluginList = new HashMap();
		
		System.out.println("loading");
		loadPlugins("jars");
		
		System.out.println("running");
		runPlugins();
	}

	private void runPlugins()
	{
		Iterator i = pluginList.keySet().iterator();
		
		while(i.hasNext())
		{
			JAR pluginJar = (JAR)pluginList.get(i.next());
			PollerTask curPlugin = pluginJar.getPlugin();
			
			//curPlugin.start(null, null);
		}
	}
	
	/**
	*/
	private void loadPlugins(String aDirectory)
	{
		File directory = new File(aDirectory);
		
		//see if the directory exists
		if(!(directory.exists() || directory.isDirectory()))
			return;
		
		String[] plugins = directory.list();
		
		//if there are no files in the directory then there is nothing to load 
		if(plugins == null)
			return;
			
		for(int i = 0; i < plugins.length; i++)
		{
			String plugin = plugins[i];
			if(!plugin.toLowerCase().endsWith(".jar"))
				continue;
			try
			{
				//get the full path of the plugin
				String path = "d:/bluebird/distpoller/org/opennms/bb/dp/common/plugins/" + directory + "/" + plugin;
				
				//Log.log(Log.DEBUG,jEdit.class,"Scanning JAR file: " + path);
				
				//add this plugin JAR to the list of plugins
				JARClassLoader jarLoader = new JARClassLoader(path);
				pluginList.put(plugin, jarLoader.getJar());
			}
			catch(IOException io)
			{
				System.out.println(io);
				io.printStackTrace();
				//Log.log(Log.ERROR,jEdit.class,"Cannot load" + " plugin " + plugin);
				//Log.log(Log.ERROR,jEdit.class,io);
			}
			catch(Exception e)
			{
				System.out.println(e);
				e.printStackTrace();
			}
		}
	}
	
	/**
	*/
	public static void main(String args[])
	{
		RunFramework framework = new RunFramework();
	}
}

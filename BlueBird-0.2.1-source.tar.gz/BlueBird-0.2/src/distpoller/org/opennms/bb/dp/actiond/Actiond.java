// Copyright (C) 2000 N*Manage Company, Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//  Brian Weaver    <weave@opennms.org>
//  http://www.opennms.org/
//
// Tab Size = 8
//
package org.opennms.bb.dp.actiond;

import java.io.*;
import java.util.Properties;

import com.sun.media.jsdt.JSDTException;

import org.opennms.bb.common.components.*;
import org.opennms.bb.dp.common.components.*;
import org.opennms.bb.dp.actiond.components.*;

/**
 * <P>Actiond listens for events coming from eventd over JSDT.  The
 * XML stream is validated and parsed in order to extract any auto
 * actions.  These actions are added to a queue and processed by
 * a pool of runnable consumer threads.  Actions are executed as 
 * separate processes, monitored for termination (terminated 
 * forcefully if a timeout expires) and then results are logged to
 * a file.</P>
 *
 * @author 	<A HREF="mailto:mike@opennms.org">Mike/A>
 * @author	<A HREF="http://www.opennms.org">OpenNMS.org</A>
 *
 * @version	$Revision: 1.2 $
 */
public class Actiond extends PollerThread
{
	/**
	 * The thread that listens to incoming threads
	 */
	private		ActiondEventListener		m_eventListener;

	/**
	 * the thread that manages the pool of runnable
	 * consumer threads which launch the auto actions
	 */
	private		ActionLaunchManager		m_launchManager;

	/**
	 * the queue between the ActiondEventListener and the execManager
	 */
	private		PCQueue			m_actionQ;

	/**
	 * <P>The properties that are specific to the Actiond process. The 
	 * properties are a combination of the JVM's system properties, plus
	 * the inclusion of the OpenNMS specific property files. There are two
	 * additional files that are loaded, if the system properties are 
	 * correctly set.</P>
	 *
	 * <P>In order to properly load the OpenNMS specific file(s) their
	 * location must be known in advance. Instead of hard coding the
	 * location of the files, the files are referenced by properties.
	 * The following list declares the properites that reference the 
	 * specific files. The property files are loaded in the order
	 * they appear in the list.</P>
	 *
	 * <UL>
	 *	<LI>org.opennms.bluebird.propertyFile</LI>
	 *	<LI>org.openmms.bluebird.Actiond.propertyFile</LI>
	 * </UL>
	 *
	 * <P>Currently the string returned for the propertyFile(s) must
	 * be a file on the local filesystem. Later support for remote
	 * files via HTTP, JSDT, etc al may be supported.</P>
	 */
	private static Properties	m_properties = null;
	
	/**
	 * <P>Copy the System properties and then load the bluebird
	 * and Actiond specific files into the property object.
	 * For more information see the javadoc comment for the m_properties
	 * element.</P>
	 *
	 * <P>Additionally, this static loading will also look at the debugging 
	 * options and will setup the Logging Facility. This can only be done
	 * after the properties have been loaded.</P>
	 */
	static
	{
		//
		// get a new properties element and make the 
		// system properties the backing map
		//
		m_properties     = new Properties(System.getProperties());

		//
		// try to load the bluebird specific properties
		//
		String file = m_properties.getProperty("org.opennms.bluebird.propertyFile");
		if(file != null)
		{
			FileInputStream pfile = null;
			try
			{
				pfile = new FileInputStream(file);
				m_properties.load(pfile);
				pfile.close();
				m_properties = new Properties(m_properties); // new property with loaded as backing map
			}
			catch(IOException e) 
			{
				// do nothing
			}
		}

		//
		// Load the Actiond specific files now
		//
		file = m_properties.getProperty("org.opennms.bluebird.actiond.propertyFile");
		if(file != null)
		{
			FileInputStream pfile = null;
			try
			{
				pfile = new FileInputStream(file);
				m_properties.load(pfile);
				pfile.close();
			}
			catch(IOException e)
			{
				// do nothing
			}
		}

		// end static load of properties.

		//
		// setup the debug and log facility for Actiond
		//
		Log.setLevel(0);
		String logLevel = m_properties.getProperty("org.opennms.bluebird.actiond.logLevel");
		if(logLevel != null)
		{
			try
			{
				Log.setLevel(Integer.parseInt(logLevel));
			}
			catch(NumberFormatException ne) { Log.setLevel(Log.WARNING); }
		}
		
		file = m_properties.getProperty("org.opennms.bluebird.actiond.logFile");
		if(file != null)
		{
			try
			{
				Log.setOut(file);
			}
			catch(IOException e)
			{
				Log.disable();
			}
		}

		// end Log class setup
		
	} // end static class initialization


	/**
	 * Actiond constructor creates the ActiondEventListener to listen for events..
	 *
	 *
	 * @exception throws ActiondEventListenerException if the event listener communication channel cannot be set up
	 * @exception throws JSDTPropertiesException if the JSDT communication channel cannot be established
	 */
	public Actiond() throws ActiondEventListenerException, JSDTException
	{
		super();
		m_actionQ	= new PCQueueLinkedList();
		m_eventListener = new ActiondEventListener(m_actionQ);
		m_launchManager	= new ActionLaunchManager(m_actionQ);
	}

	/**
	 * Start all the threads of Actiond
	 */
	public void start()
	{
		m_eventListener.start();
		super.start();
	}

	/**
	 * Loop through and wait for status changes - if a status change is
	 * detected, all the threads are informed of the status change
	 * for appropriate action to be taken
	 */
	public void run()
	{
		setOpStatus(STATUS_NORMAL);
		
		synchronized(this)
		{
			for(;;)
			{
				// wait for status change
				try
				{
					wait();
				}
				catch(InterruptedException e)
				{
				}

				int status = getOpStatus();
				if((status & STATUS_TERMINATING) == STATUS_TERMINATING)
				{
					try
					{
						shutdownThread(m_eventListener);
						m_launchManager.shutdown();
						m_actionQ.close();
					}
					catch(InterruptedException e)
					{
						// do nothing							
					}
					
					setOpStatus(STATUS_SHUTDOWN);
					return;
				}
				else if((status & STATUS_PAUSING) == STATUS_PAUSING)
				{
					boolean setPaused = true;
					try
					{
						pauseThread(m_eventListener);
						m_launchManager.pauseOperation();
					}
					catch(IllegalThreadStateException e)
					{
						setPaused = false;
						setOpStatus(STATUS_TERMINATING);
						break;
					}
					catch(InterruptedException e)
					{
						setPaused = false;
						setOpStatus(STATUS_TERMINATING);
						break;
					}

					if(setPaused)
						setOpStatus(STATUS_PAUSED);

				}
				else if((status & STATUS_RESUMING) == STATUS_RESUMING)
				{

					boolean setNormal = true;
					try
					{
						m_launchManager.resumeOperation();
						resumeThread(m_eventListener);
					}
					catch(IllegalThreadStateException e)
					{
						setNormal = false;
						setOpStatus(STATUS_TERMINATING);
					}
					catch(InterruptedException e)
					{
						setNormal = false;
						setOpStatus(STATUS_TERMINATING);
					}
						
					if(setNormal)
						setOpStatus(STATUS_NORMAL);

				}
				else if((status & STATUS_PAUSED) == STATUS_PAUSED)
				{
					try
					{
						wait();
					}
					catch(InterruptedException e)
					{
						setOpStatus(STATUS_TERMINATING);
					}
				}
				else if((status & STATUS_NORMAL) == STATUS_NORMAL)
				{
					break; // exit status checking loop
				}

			} // end for(;;) status check

		} // end synchronization 
			
	}

	/**
	 * <P>Initiates the shutdown sequence and  waits for 
	 * this thread to exit.</P>
	 */
	public synchronized void shutdown()
	{
		m_eventListener.shutdown();

		try
		{
			super.shutdown();
			if(Thread.currentThread().equals(this) == false)
				join();
		}
		catch(Exception e) 
		{ 
			// do nothing
		}
	}

	/**
	 * @return all the loaded properties
	 */
	public static Properties getProperties()
	{
		return m_properties;
	}
	
	/**
	 * @return value for the specified property
	 */
	public static String getProperty(String key)
	{
		return m_properties.getProperty(key);
	}
	
	/**
	 * Start up Actiond
	 */
	public static void main(String[] args)
	{
		try
		{
			Actiond Actiond = new Actiond();
			Actiond.start();
		}
		catch(Exception e)
		{
			Log.print(Log.FATAL, e.getMessage());

		}
		
	}
}

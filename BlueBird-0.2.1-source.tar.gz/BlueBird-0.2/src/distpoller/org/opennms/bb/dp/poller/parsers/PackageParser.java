//
// Copyright (C) 2000 N*Manage Company Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
// $Id: PackageParser.java,v 1.2 2000/10/31 20:23:56 jason Exp $
//

package org.opennms.bb.dp.poller.parsers;

import java.io.*;
import java.net.*;
import java.util.*;

import org.w3c.dom.*;

import org.opennms.bb.dp.poller.scheduler.utils.PollerPackage;
import org.opennms.bb.dp.poller.scheduler.utils.PollerRange;
import org.opennms.bb.dp.poller.scheduler.utils.Parameter;
import org.opennms.bb.dp.poller.scheduler.utils.ServiceInfo;
import org.opennms.bb.common.utils.BBParser;
import org.opennms.bb.common.components.Log;

/**This class is used to parse the packages.xml and load the
 * information into classes to be used programatically.
 * 
 * @author <A HREF="mailto:jason@opennms.org">Jason Johns</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version $Revision: 1.2 $
 * 
 */
public final class PackageParser extends BBParser
{
	/**The list of packages to parse from the xml file. If a package
	   name is not in this list it will not be parsed.
	*/
	private List m_packageList;
	
	/**The list of Package objects that are created by parsing from
	   the list of packages.
	*/
	private List m_packages;
	
	/**The list of model names that are associated with the packages
	*/
	private List m_modelNames;
	
	/**Indicates if a certain package should be read or ignored
	*/
	private boolean m_readPackage;
	
	/**As each package is parsed this object will be built and then placed
	   into the m_packages list when complete
	*/
	private PollerPackage m_pollerPackage;
	
	//
	// Relevant XML TAGS
	//
	private final String FILTER 		= "filter";
	private final String FILTER_COMMENT 	= "filterComment";
	private final String MODEL              = "model";
	private final String FILTER_EXPR 	= "filterExpr";
	private final String SERVICE 		= "service";
	private final String SERVICE_NAME 	= "serviceName";
	
	private final String PARMS		= "parms";
	private final String PARM 		= "parm";
	private final String PARM_NAME		= "parmName";
	private final String PARM_VALUE		= "value";
	private final String PARM_TYPE		= "type";

	private final String PACKAGENAME	= "packageName";
	private final String DEFAULT		= "rangeDef";
	private final String RANGES		= "ranges";
	private final String IRANGE		= "irange";
	private final String ERANGE		= "erange";
	private final String SPECIFIC		= "specific";
	private final String URL		= "url";

	/**
	 * <P>Creates the new parser that can be used to disassemble
	 * an XML file corresponding to the <EM>m_packages.dtd</EM> as
	 * defined by the OpenNMS specifications. A new instance of
	 * a DOM parser is created to parse the passed file. The
	 * list of package that should be read by the parser are
	 * passed to the object on construction.</P>
	 *
	 * @param List aPackageList, The list of m_packages to be read.
 	 */
	public PackageParser(List aPackageList)
	{
		m_packageList = aPackageList;
		m_packages = new ArrayList();
		m_modelNames = new ArrayList();
		m_pollerPackage = null;
		m_readPackage = false;
	}
	
	/**
	 * <P>This method override the method in the base class that
	 * is the default target for processing elements in the DOM
	 * tree. The method is invoked by the DOM parser to handle
	 * each element. This extends the DiscIcebergParser by parsing
	 * out all information from the xml file. Additions will be 
	 * commented.</P>
	 *
	 * @param el		The DOM element to be processed.
	 * @param isRoot	True if the element is a root element.
	 *
	 * @return True if the element was successfully handled.
	 */
	protected boolean processElement(Element el, boolean isRoot)
	{
		boolean bRet = false;
		
		Node  curNode = (Node)el;
		String curTag = el.getTagName();
		
		if (curTag.equals(PACKAGENAME))
		{
			// check the package name to see if it exist in our list of m_packages to
			// be processed. If it does then set the m_readPackage flag.
			String packName = processParmValue(curNode);
			
			m_readPackage = false;
			if (m_packageList.contains(packName))
			{
				//create a new PollerPackage object
				m_pollerPackage = new PollerPackage(packName);
				m_packages.add(m_pollerPackage);
				m_readPackage = true;
			}
			
			bRet = true;
		}
		//get the filter expression
		if (curTag.equals(FILTER) && m_readPackage)
		{
			m_curElement.replace(0, m_curElement.length(), FILTER);
			
			bRet = processFilterTag(curNode, m_pollerPackage);
		}
		//get the rangeDef information
		else if (curTag.equals(DEFAULT) && m_readPackage)
		{
			m_curElement.replace(0, m_curElement.length(), DEFAULT);
			
			bRet = processDefRangeElement(el, m_pollerPackage);
		}
		//get the include range information
		else if (curTag.equals(IRANGE) && m_readPackage)
		{
			m_curElement.replace(0, m_curElement.length(), IRANGE);

			bRet = processIRangeElement(el, m_pollerPackage);
		}
		//get the exclude range information
		else if (curTag.equals(ERANGE) && m_readPackage)
		{
			m_curElement.replace(0, m_curElement.length(), ERANGE);

			bRet = processERangeElement(el, m_pollerPackage);
		}
		//get the specific address information
		else if (curTag.equals(SPECIFIC) && m_readPackage)
		{
			m_curElement.replace(0, m_curElement.length(), SPECIFIC);
			
			bRet = processSpecificElement(el, m_pollerPackage);
		}
		//get the url information
		else if (curTag.equals(URL) && m_readPackage)
		{
			m_curElement.replace(0, m_curElement.length(), URL);
			
			bRet = processUrlElement(el, m_pollerPackage);
		}
		//get the service information
		else if (curTag.equals(SERVICE) && m_readPackage)
		{
			m_curElement.replace(0, m_curElement.length(), SERVICE);

			bRet = processServiceElement(el, m_pollerPackage);
		}
		else
		{
			boolean bNodeRet=true;

			NodeList nl = el.getChildNodes();
			int size = nl.getLength();

			for(int i = 0;i < size && bNodeRet ;i++)
				bNodeRet = processNode(nl.item(i));
			
			bRet = bNodeRet;
		}
		
		return bRet;
	}
	
	/** 
	 * <P>This method is used to process the filter tag
	 * section of the document. If there is a return between the tag 
	 * and the CDATA section the data will not be retrieved. This seems to
	 * be an issue with either Xerces or the XML spec. Make sure that the 
	 * tag and the data for the filter expression are on the same line.</P>
	 *
	 * @param List aPackageList, the DOM node to handle.
	 * @param PollerPackage m_pollerPackage, the package object we are building
	 *
	 * @return Returns true if successful, false otherwise.
	 *
	 */
	private boolean processFilterTag(Node filterNode, PollerPackage m_pollerPackage)
	{
		boolean bRet = true;

		NodeList nl = filterNode.getChildNodes();
		int size = nl.getLength();
		
		//walk through the children of the filter tag
		for(int i = 0; i < size && bRet; i++)
		{
			Node curNode = nl.item(i);
			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
				
				//we only want the expression, we can ignore the filter comment
				if(curTag.equals(FILTER_EXPR))
				{
					m_pollerPackage.setFilterExpr(processParmValue(curNode));
					
					bRet = true;
				}
			}
		}

		return bRet;
	}
	
	/**<P>This method is used to process the <service> tags</P>
	 *
	 * @param Element serviceElement, the DOM element to handle.
	 * @param PollerPackage m_pollerPackage, the package object we are building
	 *
	 * @return Returns true if successful, false otherwise.
	 */
	private boolean processServiceElement(Element serviceElement, PollerPackage m_pollerPackage)
	{
		boolean bRet = true;

		NodeList nl = ((Node)serviceElement).getChildNodes();
		int size = nl.getLength();
		
		ServiceInfo newService = new ServiceInfo();
		
		for(int i = 0; i < size && bRet; i++)
		{
			Node curNode = nl.item(i);
			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
				
				//we only want the expression, we can ignore the filter comment
				if(curTag.equals(SERVICE_NAME))
				{
					newService.setServiceName(processParmValue(curNode));
				}
				else if (curTag.equals(PARMS))
				{
					processServiceParameters(curNode, newService);
				}
				else if (curTag.equals(MODEL))
				{
					String modelName = processParmValue(curNode);
					
					newService.setModelName(modelName);
					
					//add it to a global list so that a caller doesn't have to 
					//loop through all services to get model names
					if (!m_modelNames.contains(modelName))
					{
						m_modelNames.add(modelName);
					}
				}
			}
		}
		
		m_pollerPackage.addService(newService);

		return bRet;
	}
	
	/**<P>This method parses the parameter tags (<parms>) from within the
	   <service> tags</P>
	   @param Node paramNode, the DOM node to handle.
	   @param ServiceInfo aService, the object to place the Parameter into
	*/
	private void processServiceParameters(Node paramNode, ServiceInfo aService)
	{
		NodeList nl = paramNode.getChildNodes();
		int size = nl.getLength();
		
		for(int i = 0; i < size; i++)
		{
			Node curNode = nl.item(i);
			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
				
				if (curTag.equals(PARM))
				{
					aService.addServiceParameter(processParameter(curNode));
				}
			}
		}
	}
	
	/**<P>This method is used to process the default range tags</P>
	 *
	 * @param Element defaultElement, the DOM element to handle.
	 * @param PollerPackage m_pollerPackage, the package object we are building
	 *
	 * @return Returns true if successful, false otherwise.
	 */
	private boolean processDefRangeElement(Element defaultElement, PollerPackage m_pollerPackage)
	{
		boolean bRet = true;

		NodeList nl = ((Node)defaultElement).getChildNodes();
		int size = nl.getLength();
		
		PollerRange newRange = new PollerRange();
		
		for(int i = 0; i < size && bRet; i++)
		{
			Node curNode = nl.item(i);
			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
				
				if (curTag.equals(PARMS))
				{
					processRange(curNode, newRange);
				}
			}
		}
		
		m_pollerPackage.getRangeInfo().addDefRange(newRange);

		return bRet;
	}
	
	/**<P>This method is used to process the <irange> tags</P>
	 *
	 * @param Element irangeElement, the DOM element to handle.
	 * @param PollerPackage m_pollerPackage, the package object we are building
	 *
	 * @return Returns true if successful, false otherwise.
	 */
	private boolean processIRangeElement(Element irangeElement, PollerPackage m_pollerPackage)
	{
		boolean bRet = true;

		NodeList nl = ((Node)irangeElement).getChildNodes();
		int size = nl.getLength();
		
		PollerRange newRange = new PollerRange();
		
		for(int i = 0; i < size && bRet; i++)
		{
			Node curNode = nl.item(i);
			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
				
				if (curTag.equals(PARMS))
				{
					processRange(curNode, newRange);
				}
			}
		}
		
		m_pollerPackage.getRangeInfo().addIrange(newRange);

		return bRet;
	}
	
	/**<P>This method is used to process the <erange> tags</P>
	 *
	 * @param Element erangeElement, the DOM element to handle.
	 * @param PollerPackage m_pollerPackage, the package object we are building
	 *
	 * @return Returns true if successful, false otherwise.
	 */
	private boolean processERangeElement(Element erangeElement, PollerPackage m_pollerPackage)
	{
		boolean bRet = true;

		NodeList nl = ((Node)erangeElement).getChildNodes();
		int size = nl.getLength();
		
		PollerRange newRange = new PollerRange();
		
		for(int i = 0; i < size && bRet; i++)
		{
			Node curNode = nl.item(i);
			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
				
				if (curTag.equals(PARMS))
				{
					processRange(curNode, newRange);
				}
			}
		}
		
		m_pollerPackage.getRangeInfo().addErange(newRange);

		return bRet;
	}
	
	/**<P>This method is used to process the <specific> tags</P>
	 *
	 * @param Element specificElement, the DOM element to handle.
	 * @param PollerPackage m_pollerPackage, the package object we are building
	 *
	 * @return Returns true if successful, false otherwise.
	 */
	private boolean processSpecificElement(Element specificElement, PollerPackage m_pollerPackage)
	{
		boolean bRet = true;

		NodeList nl = ((Node)specificElement).getChildNodes();
		int size = nl.getLength();
		
		PollerRange newRange = new PollerRange();
		
		for(int i = 0; i < size && bRet; i++)
		{
			Node curNode = nl.item(i);
			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
				
				if (curTag.equals(PARMS))
				{
					processRange(curNode, newRange);
				}
			}
		}
		
		m_pollerPackage.getRangeInfo().addSpecific(newRange);

		return bRet;
	}
	
	/**<P>This method is used to process the <url> tags</P>
	 *
	 * @param Element urlElement, the DOM element to handle.
	 * @param PollerPackage m_pollerPackage, the package object we are building
	 *
	 * @return Returns true if successful, false otherwise.
	 */
	private boolean processUrlElement(Element urlElement, PollerPackage m_pollerPackage)
	{
		boolean bRet = true;

		NodeList nl = ((Node)urlElement).getChildNodes();
		int size = nl.getLength();
		
		PollerRange newRange = new PollerRange();
		
		for(int i = 0; i < size && bRet; i++)
		{
			Node curNode = nl.item(i);
			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
				
				if (curTag.equals(PARMS))
				{
					processRange(curNode, newRange);
				}
			}
		}
		
		m_pollerPackage.getRangeInfo().addUrl(newRange);

		return bRet;
	}
	
	/**<P>This method parses the parameter tags (<parms>) from within the
	   <irange>, <erange>, <defRange>, <specific> and <url> tags</P>
	   @param Node rangeNode, the DOM node to handle.
	   @param PollerRange aRange, the object to place the Parameter into
	*/
	private void processRange(Node rangeNode, PollerRange aRange)
	{
		NodeList nl = rangeNode.getChildNodes();
		int size = nl.getLength();
		
		for(int i = 0; i < size; i++)
		{
			Node curNode = nl.item(i);
			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
				
				if (curTag.equals(PARM))
				{
					aRange.addRangeParam(processParameter(curNode));
				}
			}
		}
	}
	
	/**<P>This method is used to process the DTDs 
	 * parameter block. The parameter block consist of
	 * a name, value, and the values type as an attribute.
	 * The elements are parsed out and stored in the
	 * returned <EM>Parameter</EM> object.</P>
	 *
	 * @param parmsNode	The node containing the parameter information
	 *
	 * @return The Parameter object containing the parsed data on success.
	 *	If an error occurs then a <EM>null</EM> is returned.
	 *
	 */
	protected Parameter processParameter(Node parmsNode)
	{
		boolean bRet = true;
		NodeList nl  = parmsNode.getChildNodes();
		int size     = nl.getLength();
		Parameter parm = new Parameter();
		
		for(int i = 0;i < size;i++)
		{
			Node curNode = nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
				if(curTag.equals(PARM_NAME))
				{
					//
					// process the parameter name
					//
					getParameterName(curNode, parm);
				}
				else if(curTag.equals(PARM_VALUE))
				{
					//
					// process the parameter value
					//
					getParameterValue(curNode, parm);
				}
			}
		}

		//
		// if everything is ok then return the
		// parameter object with the parsed information.
		//
		return parm;
	}
	
	/**<P>This method process the parameter <EM>&lt;name&gt;</EM>
	 * element of the parameter block in the DTD. The value
	 * for the element is returned to the caller upon success.</P>
	 *
	 * @param parmNameNode	The DOM Node containing the parm name.
	 * @param parm		The parameter element to store the name.
	 *
	 * @return True if the call succeeds, false if an error occurs.
	 */
	protected boolean getParameterName(Node parmNameNode, Parameter parm)
	{
		String parmName = null;

		Node temp = parmNameNode.getChildNodes().item(0);
		if (temp.getNodeType() == Node.TEXT_NODE)
			parmName = ((Text)temp).getData().trim();
		
		parm.setName(parmName);
		return true;
	}

	/**<P>Process the <EM>&lt;value&gt;</EM> element of the <EM>parm</EM>
	 * block and returns the information in the passed parm element.
	 * If the data is successfully extracted then a value of true is
	 * returned. If an error occurs then a false value is returned.</P>
	 *
	 * @param parmValNode	The node element from the DOM parser.
	 * @param parm		The [in/out] element modified by the call.
	 *
	 * @return True if the call succeeds, false if an error occurs.
	 */
	protected boolean getParameterValue(Node parmValNode, Parameter parm)
	{
		String parmVal = null;

		//
		// Get the first item and extract the data
		//
		Node temp = parmValNode.getChildNodes().item(0);
		if (temp.getNodeType() == Node.TEXT_NODE)
			parmVal = ((Text)temp).getData().trim();
		
		//
		// if the value is null then return 
		// a false, indicating that the call failed.
		//
		if (parmVal == null)
			return false;

		//
		// extract the attribute value
		//
		String parmType = ((Element)parmValNode).getAttribute(PARM_TYPE);

		//
		// Save the data and return the success code.
		//
		parm.setType(parmType);
		parm.setValue(parmVal);
		
		return true;
	}
	
	/**<P>This method returns the list of Packages that was created
	      by parsing.</P>
	      @return List, the list of Packages
	*/
	public List getPackages()
	{
		return m_packages;
	}
	
	/**<P></P>
	*/
	public List getModelNames()
	{
		return m_modelNames;
	}
}

//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.dp.poller.scheduler.utils;

import java.util.*;

import org.opennms.bb.dp.poller.scheduler.utils.ModelInterval;

/**This class is responsible for holding information about a
 * model parsed from the models.xml file. 
 *
 * @author <A HREF="mailto:jason@opennms.org">Jason Johns</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version $Revision: 1.2 $
 * 
 */
public class PollerModel
{
	/**
	*/
	public static final int DELETE_FLAG = -1;
	
	/**The name of the model, from the <modelName> tag
	*/
	private String m_modelName;
	
	/**The group of model begin, end and values build from the <interval> tags
	*/
	private List m_modelDetails;
	
	/**Default constructor, allocates the m_serviceDetails member
	*/
	public PollerModel(String aName)
	{
		m_modelName = aName;
		m_modelDetails = new ArrayList();
	}
	
	/**This method adds a new interval to the model
	   @param ModelInterval anInterval, a new ModelInterval object
	*/
	public void addInterval(ModelInterval anInterval)
	{
		m_modelDetails.add(anInterval);
	}
	
	/**This method returns the name of the model
	   @return String, the name of the model
	*/
	public String getModelName()
	{
		return m_modelName;
	}
	
	/**This method gets the value of the model based on what begin
	   time is passed in.
	   @return String, the value of the interval end for the corresponding begin
	   @param String intervalBegin, the begin time of the interval
	*/
	public int getIntervalValue(int lengthOfTime)
	{
		ModelInterval interval = null;
		String value = null;
		int returnValue = DELETE_FLAG;
		
		lengthOfTime = Math.max(lengthOfTime, 0);
		
		for (int i = 0; i < m_modelDetails.size(); i++)
		{
			interval = (ModelInterval)m_modelDetails.get(i);
			
			//if the interval has been down for at least this amount of time
			if (lengthOfTime >= UnitConverter.getSeconds(interval.getBegin()))
			{
				value = interval.getValue();
			}
			//we have found the proper interval already
			else
			{
				break;
			}
		}
		
		//if the interface has been down to long it should be deleted, the -1 default
		//will signal this. Set the return value to the proper interval if it shouldn't
		//be deleted yet
		if (!value.equals(ModelInterval.DELETE))
		{
			returnValue  = UnitConverter.getSeconds(value);
		}
		
		return returnValue;
	}
	
	/**
	*/
	public String toString()
	{
		return m_modelName + "\r\n" + m_modelDetails;
	}
}

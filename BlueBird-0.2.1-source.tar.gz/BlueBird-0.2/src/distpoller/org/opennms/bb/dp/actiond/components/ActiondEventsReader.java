//
// Copyright (C) 2000 N*Manage Company, Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
package org.opennms.bb.dp.actiond.components;

import java.io.*;
import java.util.*;

import org.apache.xerces.parsers.SAXParser;
import org.xml.sax.*;

import org.opennms.bb.common.components.*;
import org.opennms.bb.dp.events.XMLEventsParser;

/**
 * <P>ActiondEventsReader holds the input stream of events - this stream is then
 * parsed to get the events store that is a list of 'EventBlock's - the
 * ActiondEventReceiver creates the ActiondEventsReader objects and adds
 * them to the listener queue. From where the EventListener 'RunnableConsumerThread's
 * thread pool, pick them up and parse the input stream in the object. The parsed 
 * objects are then added to the action Q where they are processed by ActionExec 
 * threads.
 *
 * @author 	<A HREF="mailto:mike@opennms.org">Mike</A>
 * @author 	<A HREF="mailto:sowmya@opennms.org">Sowmya Kumaraswamy</A>
 * @author	<A HREF="mailto:weave@opennms.org">Brian Weaver</A>
 * @author	<A HREF="http://www.opennms.org">OpenNMS.org</A>
 *
 * @version	$Revision: 1.2 $
 */
public class ActiondEventsReader implements Runnable
{
	/**
	 * The input stream that has the events
	 */
	private InputStream	m_inputStream;

	/**
	 * the events in the input stream
	 */
	private List		m_events;

	/**
	 * Constructs the ActiondEventsReader object
	 *
	 * @param inpStream	the input stream to be parsed
	 */
	public ActiondEventsReader(InputStream inpStream)
	{
		m_inputStream = inpStream;
		m_events = null;
	}

	/**
	 * <pre>The EventListener holds a hashtable of 'EventsParser' objects for
	 * each thread in its 'RunnableConsumerThread' thread pool - the
	 * 'ActiondEventsReader' queries the EventListener for the parser for this
	 * thread and uses that to parse the input stream
	 *
	 * Once the parse is complete, the input stream is closed</pre>
	 */
	public void run()
	{
		try
		{
			m_events = null;
			if (m_inputStream != null)
			{
				SAXParser parser = ActiondEventListener.getEventsParser(Thread.currentThread());
				parser.parse(new InputSource(m_inputStream));
				Log.print(Log.DEBUG, "ActiondEventsReader: retrieving parsed events.  Thread ID: " + Thread.currentThread());
				m_events = ((XMLEventsParser)parser.getContentHandler()).getEvents();
			}
			else
				Log.print(Log.DEBUG, "ActiondEventsReader: input stream is null, nothing to parse.");
		}
		catch (SAXException se)
		{
			Log.print(Log.WARNING, "ActiondEventsReader: Error parsing input stream!: " + se.getMessage());
			m_events = null;
		}
		catch (java.io.IOException ioE)
		{
			Log.print(Log.WARNING, "ActiondEventsReader: Unable to parse input event stream: " + ioE.getMessage());
			m_events = null;
		}
		finally
		{
			try 
			{ 
				if(m_inputStream != null)
					m_inputStream.close(); 
				m_inputStream = null;
			} 
			catch(Exception e) { }
		}
	}

	/**
	 * Returns the list of 'EventBlock's in the input stream
	 *
	 * @return the list of 'EventBlock's in the input stream
	 */
	public List getEvents()
	{
		return m_events;
	}
}

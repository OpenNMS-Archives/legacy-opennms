//
// Copyright (C) 2000 N*Manage Company, Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
package org.opennms.bb.dp.eventd;

import java.io.*;
import java.util.*;

import org.apache.xerces.parsers.SAXParser;
import org.xml.sax.*;

import org.opennms.bb.common.components.*;
import org.opennms.bb.dp.events.*;

/**
 * <P>EventsReader holds the input stream of events - this stream is then
 * parsed to get the events store that is a list of 'EventBlock's - the
 * EventListener sub-components(TCPHandler, UDPHandler and JSDTHandler) create
 * the EventsReader objects and add them to the listener queue from where the
 * EventListener 'RunnableConsumerThread's thread pool, pick them up
 * and parse the input stream in the object. The parsed objects are then
 * queued to the event expand manager
 *
 * @author 	<A HREF="mailto:sowmya@opennms.org">Sowmya Kumaraswamy</A>
 * @author	<A HREF="mailto:weave@opennms.org">Brian Weaver</A>
 * @author	<A HREF="http://www.opennms.org">OpenNMS.org</A>
 *
 * @version	$Revision: 1.1 $
 */
public class EventsReader implements Runnable
{
	/**
	 * The input stream that has the events
	 */
	private InputStream	m_input;

	/**
	 * The event stream header
	 */
	private EventHeader	m_header;
	
	/**
	 * the events in the input stream
	 */
	private List		m_events;

	/**
	 * The enterprise ID prefix - incoming events and the events in
	 * event.conf can have EIDs that have the partial EIDs as in
	 * '18.1.1.6' instead of '.1.3.6.1.4.1.18.1.1.6'. When a event lookup
	 * is done based on the EID, a lookup with both the partial and the
	 * full EID is done
	 */
	private final static String ENTERPRISE_PRE	= ".1.3.6.1.4.1";

	/**
	 * The default event UEI - if the event lookup into the 'event.conf'
	 * fails, the event is loaded with information from this default UEI 
	 */
	private final static String DEFAULT_EVENT_UEI	= "http://uei.opennms.org/default/event";

	/**
	 * The default trap UEI - if the trap lookup into the 'event.conf'
	 * fails, the trap event is loaded with information from this default UEI 
	 */
	private final static String DEFAULT_TRAP_UEI	= "http://uei.opennms.org/default/trap";
	
	/**
	 * <P>This method is call to check the event againt the configuration information
	 * and make any necessary modifications to the event. If the event does not have
	 * any particular field that is part of a matching configuration event, then
	 * the configuration information is copied to the new event.</P>
	 *
	 * @param e	The event to check/modify
	 *
	 */
	private static void expand(Event e)
	{
		EventBase econf = null;
		
		//
		// search based on the UEI first
		//
		if(e.hasUEI())
		{
			econf = Eventd.getEventByName(e.getUEI());
		}
		else if(e.hasSnmpInfo())
		{
			//
			// Set the UEI here if the host does not have one!
			//
			e.setUEI(DEFAULT_TRAP_UEI);
		}
		else  // no uei and not a trap
		{
			//
			// No UEI and it's not a trap!
			//
			e.setUEI(DEFAULT_EVENT_UEI); 
			econf = Eventd.getEventByName(DEFAULT_EVENT_UEI);
		}
		
		//
		// if the UEI search did not succeed then search
		// based on the enterprise identifier
		//
		if(econf == null && e.hasSnmpInfo())
		{
			String eid = e.getSnmpInfo().getEnterpriseID();
			if(eid != null)
			{
				//
				// do a lookup on the fully qualified name first
				//
				econf = Eventd.getEventByName(eid);
				if(econf == null && eid.startsWith(ENTERPRISE_PRE))
				{
					// try partial match
					econf = Eventd.getEventByName(eid.substring(ENTERPRISE_PRE.length()));
				}

				if (econf != null)
					// Override event's default trap uei since we found a matching config entry
					e.setUEI(econf.getUEI());
			}
			
			if(econf == null)
			{
				//
				// Not able to find a usable configuration, but since it has
				// a trap we will use the trap default uei. If this fails to
				// resolve, what then? I guess that we fall back to the default
				// for non-traps? don't know!
				//
				econf = Eventd.getEventByName(DEFAULT_TRAP_UEI);
			}
		}

		//
		// One last check, if the event is not defined anywhere then we will log a 
		// message and not perform any expanding of the event, but pass it as is
		// The question is should we discard events that have no UEI?
		//
		if(econf != null)
		{
			//
			// Use the config object to fill in the data!
			// If the data is not an immutable Sting object
			// then a deep copy is performed using new!
			//
			if(!e.hasUEI())
			{
				e.setUEI(econf.getUEI());
			}
			
			if(!e.hasSnmpInfo() && econf.hasSnmpInfo())
				e.setSnmpInfo(new EventSnmpInfo(econf.getSnmpInfo()));
			
			if(!e.hasDescription())
				e.setDescription(econf.getDescription());
			
			if(!e.hasLogMessage())
				e.setLogMessage(econf.getLogMessage());
			
			if(!e.hasSeverity())
				e.setSeverity(econf.getSeverity());
			
			if(!e.hasOperatorInstruction())
				e.setOperatorInstruction(econf.getOperatorInstruction());
			
			if(!e.hasAutoActions() && econf.hasAutoActions())
			{
				Iterator i = econf.getAutoActions().iterator();
				while(i.hasNext())
					e.addAutoAction((String)(i.next()));
			}
			
			if(!e.hasOperatorActions() && econf.hasOperatorActions())
			{
				Iterator i = econf.getOperatorActions().iterator();
				while(i.hasNext())
				{
					//
					// Avoid trouble later by making a new reference
					//
					EventOperatorAction act = (EventOperatorAction)i.next();
					e.addOperatorAction(new EventOperatorAction(act));
				}
			}
			
			if(!e.hasLogGroups() && econf.hasLogGroups())
			{
				Iterator i = econf.getLogGroups().iterator();
				while(i.hasNext())
					e.addLogGroup((String)i.next());
			}
			
			if(!e.hasNotifications() && econf.hasNotifications())
			{
				Iterator i = econf.getNotifications().iterator();
				while(i.hasNext())
					e.addNotification((String)i.next());
			}
			
			if(!e.hasTroubleTicket() && econf.hasTroubleTicket())
			{
				//
				// make a reference to avoid problem of 
				// modifications down the line
				//
				e.setTroubleTicket(new EventTroubleTicket(econf.getTroubleTicket()));
			}
			
			if(!e.hasForwards() && econf.hasForwards())
			{
				//
				// deep copy to avoid modification problems
				//
				Iterator i = econf.getForwards().iterator();
				while(i.hasNext())
					e.addForward(new EventForward((EventForward)i.next()));
			}
			
			if(!e.hasMouseOverText())
				e.setMouseOverText(econf.getMouseOverText());
		} // end fill of event using econf
		
		//
		// the event has been udpated, so just return
		//
	} // end expand()

	/**
	 * Constructs the EventsReader object
	 *
	 * @param inpStream	the input stream to be parsed
	 */
	public EventsReader(InputStream inpStream)
	{
		m_input = inpStream;
		m_events= null;
	}

	/**
	 * <pre>The EventListener holds a hadhtable of 'EventsParser' objects for
	 * each thread in its 'RunnableConsumerThread' thread pool - the
	 * 'EventsReader' queries the EventListener for the parser for this
	 * thread and uses that to parse the input stream
	 *
	 * Once the parse is complete, the input stream is closed</pre>
	 */
	public void run()
	{
		try
		{
			m_events = null;
			if(m_input != null)
			{
				SAXParser parser = EventListener.getEventsParser(Thread.currentThread());
				parser.parse(new InputSource(m_input));
				m_header = ((XMLEventsParser)parser.getContentHandler()).getHeader();
				m_events = ((XMLEventsParser)parser.getContentHandler()).getEvents();
			}
		}
		catch(SAXException se)
		{
			Log.print(Log.WARNING, "EventsReader: Error parsing input stream!: " + se.getMessage());
			m_events = null;
		}
		catch (IOException ioE)
		{
			Log.print(Log.WARNING, "EventsReader: Unable to parse input event stream: " + ioE.getMessage());
			m_events = null;
		}
		finally
		{
			try 
			{ 
				if(m_input != null)
					m_input.close(); 
				m_input = null;
			} 
			catch(Exception e) { }
		}
		
		//
		// Expand each event returned
		// by the parser
		//
		if(m_events != null)
		{
			Iterator i = m_events.iterator();
			while(i.hasNext())
			{
				expand((Event)i.next());
			}
		}
	}

	/**
	 * Returns the list of 'EventBlock's in the input stream
	 *
	 * @return the list of 'EventBlock's in the input stream
	 */
	public List getEvents()
	{
		return m_events;
	}
	
	public EventHeader getHeader()
	{
		return m_header;
	}
}

//
// Copyright (C) 2000 N*Manage Company Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
// $Id: ModelsParser.java,v 1.2 2000/11/10 02:19:45 jason Exp $
//

package org.opennms.bb.dp.poller.parsers;

import java.io.*;
import java.net.*;
import java.util.*;

import org.w3c.dom.*;

import org.opennms.bb.dp.poller.scheduler.utils.PollerModel;
import org.opennms.bb.dp.poller.scheduler.utils.ModelInterval;
import org.opennms.bb.common.utils.BBParser;
import org.opennms.bb.common.components.Log;

/**This class is used to parse the packages.xml and load the
 * information into classes to be used programatically.
 * 
 * @author <A HREF="mailto:jason@opennms.org">Jason Johns</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version $Revision: 1.2 $
 * 
 */
public final class ModelsParser extends BBParser
{
	/**The list of models to parse from the xml file. If a model
	   name is not in this list it will not be parsed.
	*/
	private List m_modelList;
	
	/**The list of Model objects that are created by parsing from
	   the list of models.
	*/
	private List m_models;
	
	/**Indicates if a certain model should be read or ignored
	*/
	private boolean m_readModel;
	
	/**As each model is parsed this object will be built and then placed
	   into the m_models list when complete
	*/
	private PollerModel m_pollerModel;
	
	//
	// Relevant XML TAGS
	//
	private static final String SERVICE_MODELS = "serviceModels";
	private static final String HEADER         = "header";
	private static final String VER            = "ver";
	private static final String MSTATION       = "mstation";
	private static final String CREATED        = "created";
	private static final String MODELS         = "models";
	private static final String MODEL          = "model";
	private static final String MODEL_NAME     = "modelName";
	private static final String MODEL_DESCR    = "modelDescr";
	private static final String INTERVALS      = "intervals";
	private static final String INTERVAL       = "interval";
	private static final String BEGIN          = "begin";
	private static final String END            = "end";
	private static final String VALUE          = "value";

	/**
	 * <P>Creates the new parser that can be used to disassemble
	 * an XML file corresponding to the <EM>models.dtd</EM> as
	 * defined by the OpenNMS specifications. A new instance of
	 * a DOM parser is created to parse the passed file. The
	 * list of models that should be read by the parser are
	 * passed to the object on construction.</P>
	 *
	 * @param List aPackageList, The list of m_packages to be read.
 	 */
	public ModelsParser(List aModelList)
	{
		m_modelList = aModelList;
		m_models = new ArrayList();
	}
	
	/**
	 * <P>This method override the method in the base class that
	 * is the default target for processing elements in the DOM
	 * tree. The method is invoked by the DOM parser to handle
	 * each element.</P>
	 *
	 * @param el		The DOM element to be processed.
	 * @param isRoot	True if the element is a root element.
	 *
	 * @return True if the element was successfully handled.
	 */
	protected boolean processElement(Element el, boolean isRoot)
	{
		boolean bRet = false;
		
		Node  curNode = (Node)el;
		String curTag = el.getTagName();
		
		if (curTag.equals(MODEL_NAME))
		{
			// check the model name to see if it exist in our list of m_models to
			// be processed. If it does then set the m_readModel flag.
			String modelName = processParmValue(curNode);
			
			m_readModel = false;
			if (m_modelList.contains(modelName))
			{
				//create a new PollerPackage object
				m_pollerModel = new PollerModel(modelName);
				m_models.add(m_pollerModel);
				m_readModel = true;
			}
			
			bRet = true;
		}
		//get the filter expression
		if (curTag.equals(INTERVAL) && m_readModel)
		{
			m_curElement.replace(0, m_curElement.length(), INTERVALS);
			
			bRet = processIntervalElement(el, m_pollerModel);
		}
		else
		{
			boolean bNodeRet=true;

			NodeList nl = el.getChildNodes();
			int size = nl.getLength();

			for(int i = 0;i < size && bNodeRet ;i++)
				bNodeRet = processNode(nl.item(i));
			
			bRet = bNodeRet;
		}
		
		return bRet;
	}
	
	/**<P>This method is used to process the <intervals> tags</P>
	 *
	 * @param Element serviceElement, the DOM element to handle.
	 * @param PollerPackage m_pollerPackage, the package object we are building
	 *
	 * @return Returns true if successful, false otherwise.
	 */
	private boolean processIntervalElement(Element intervalElement, PollerModel aPollerModel)
	{
		boolean bRet = true;

		NodeList nl = ((Node)intervalElement).getChildNodes();
		int size = nl.getLength();
		
		ModelInterval newInterval = new ModelInterval();
		
		for(int i = 0; i < size && bRet; i++)
		{
			Node curNode = nl.item(i);
			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
			
				if (curTag.equals(BEGIN))
				{
					newInterval.setBegin(processParmValue(curNode));
				}
				else if (curTag.equals(END))
				{
					newInterval.setEnd(processParmValue(curNode));
				}
				else if (curTag.equals(VALUE))
				{
					newInterval.setValue(processParmValue(curNode));
				}
				else
				{
					bRet = false;
				}
			}
		}
		
		aPollerModel.addInterval(newInterval);

		return bRet;
	}
	
	/**<P>This method returns the list of models that was created
	      by parsing.</P>
	      @return List, the list of Models
	*/
	public List getModels()
	{
		return m_models;
	}
	
	/**<P>This method returns the list of models as a Map object,
	      indexed by the model name.</P>
	      @return Map, the map of models
	  */
	public Map getModelsAsMap()
	{
		Map modelMap = new HashMap();
		PollerModel model = null;
		
		for (int i = 0; i < m_models.size(); i++)
		{
			model = (PollerModel)m_models.get(i);
			
			modelMap.put(model.getModelName(), model);
		}
		
		return modelMap;
	}
}

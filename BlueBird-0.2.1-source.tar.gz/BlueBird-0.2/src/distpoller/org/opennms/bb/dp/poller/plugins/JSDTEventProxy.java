//
// Copyright (C) 2000 N*Manage Company, Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
// $Id: JSDTEventProxy.java,v 1.2 2000/11/15 20:35:03 sowmya Exp $
//
package org.opennms.bb.dp.poller.plugins;

import java.io.*;
import com.sun.media.jsdt.*;

import org.opennms.bb.common.components.*;
import org.opennms.bb.dp.common.components.*;

import org.opennms.bb.dp.events.Event;

/**
 * The JSDTEventProxy implements the EventProxy to send an event to the
 * events subsystem via JSDT
 *
 * @author <A HREF="mailto:sowmya@opennms.org">Sowmya Kumaraswamy</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version $Revision: 1.2 $
 *
 */
public class JSDTEventProxy implements EventProxy
{
	
	/**
	 * The events JSDT session
	 */
	private	Session		m_session;

	/**
	 * The JSDT client that this identifies itself as 
	 */
	private Client		m_client;

	/**
	 * The events source channel
	 */
	private Channel		m_channel;

	/**
	 * The JSDT client identifier that the sender wants to use
	 */
	private String		m_clientID;

	/**
	 * A flag set by the user that indicates if the sender wants to
	 * receive the event being sent 
	 *
	 * A 'true' indicates that the sender wants to receive the sent event
	 * A 'false' indicates that the sender only wants to send the event, not recieve it
	 */
	private boolean		m_receiveSentEvent;
	

	/**
	 * Connect to the events session's source channel - the JSDT exceptions
	 * don't have their 'getMessage()' defined - so create a new
	 * exception for each
	 *
	 * @exception JSDTException	thrown if the JSDT connection does not go throught for any reason
	 */
	private void jsdtConnect() throws JSDTException
	{

		// form the URL
		URLString url = URLString.createSessionURL(PollerJSDTConstants.HOSTNAME, 
							 PollerJSDTConstants.EVENTS_SESSION_PORT,
							 PollerJSDTConstants.REGISTRY_TYPE, 
							 PollerJSDTConstants.EVENTS_SESSION_NAME);

		try
		{
			// check if the events session is up
			if (!SessionFactory.sessionExists(url)) 
			{
				throw new JSDTException("Session \'" + url  + "\' not up");
			} 

			// this client
			m_client  = new PollerClient(m_clientID);
		
			// create(get an handle to) the events session
			m_session = SessionFactory.createSession(m_client, url, true);

			// create(get an handle to) the events source channel
			m_channel = m_session.createChannel(m_client, 
							PollerJSDTConstants.EVENTS_SOURCE_CHANNEL,
							true, 
							false, 
							true);
		}
		catch (ConnectionException ce)
		{
			throw new JSDTException("Network error");
		}
		catch (NoSuchHostException nshe)
		{
			throw new JSDTException("No such host");
		}
		catch (NoRegistryException nre)
		{
			throw new JSDTException("No registry");
		}
		catch (InvalidURLException iue)
		{
			throw new JSDTException("Invalid URL");
		}
		catch (TimedOutException toe)
		{
			throw new JSDTException("Operation timed out");
		}
		catch (InvalidClientException ice)
		{
			throw new JSDTException("Invalid Client");
		}
		catch (NameInUseException niue)
		{
			throw new JSDTException("Name already in use");
		}
		catch (NoSuchClientException nshe)
		{
			throw new JSDTException("No such client");
		}
		catch (NoSuchSessionException nsse)
		{
			throw new JSDTException("No such session");
		}
		catch (PermissionDeniedException pde)
		{
			throw new JSDTException("Operation not permitted");
		}
		catch (PortInUseException piue)
		{
			throw new JSDTException("Port in use");
		}
	}

	/**
	 * The default constructor is not supported since a JSDT client identifer is a must
	 *
	 * @exception UnsupportedOperationException thrown
	 */
	public JSDTEventProxy() throws UnsupportedOperationException
	{
		throw new UnsupportedOperationException("Default constructor not supported! - client ID required for JSDT communcations!");

	}

	/**
	 * Constructor
	 *
	 * @param clientID	the JSDT client identifier
	 *
	 * @exception JSDTException	thrown if the JSDT communication path cannot be set up
	 */
	public JSDTEventProxy(String clientID) throws JSDTException
	{
		m_clientID = clientID;
		m_receiveSentEvent = false;

		jsdtConnect();
	}

	/**
	 * Constructor
	 *
	 * @param clientID		the JSDT client identifier
	 * @param recieveSentEvent	flag indicating if the sent event is also required to be received
	 *
	 * @exception JSDTException	thrown if the JSDT communication path cannot be set up
	 */
	public JSDTEventProxy(String clientID, boolean bReceiveSentEvent) throws JSDTException
	{
		m_clientID = clientID;
		m_receiveSentEvent = bReceiveSentEvent;

		jsdtConnect();
	}

	/**
	 * Implements the EventProxy-> send() method to send the event to
	 * the events source channel
	 *
	 * @param event		the event to be sent
	 *
	 * @exception EventProxyException thrown if the event cannot be sent for any reason  
	 */
	public void send(Event event) throws EventProxyException
	{
		try
		{
			// serialize the event
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			PrintStream ps = new PrintStream(baos);
	
			event.serializeToXML(ps);

			// construct JSDT data
			Data data = new Data(baos.toByteArray());
		
			// send the event
			if (m_receiveSentEvent)
			{
				m_channel.sendToAll(m_client, data);
			}
			else
			{
				m_channel.sendToOthers(m_client, data);
			}
		}
		catch (ConnectionException ce)
		{
			throw new EventProxyException("Network Error");
		}
		catch (InvalidClientException ivce)
		{
			throw new EventProxyException("Invalid Client");
		}
		catch (NoSuchChannelException nsce)
		{
			throw new EventProxyException("No such Channel");
		}
		catch (NoSuchClientException nscle)
		{
			throw new EventProxyException("No such Client");
		}
		catch (NoSuchSessionException nsse)
		{
			throw new EventProxyException("No such Session");
		}
		catch (PermissionDeniedException pde)
		{
			throw new EventProxyException("Operation not permitted");
		}
		catch (TimedOutException te)
		{
			throw new EventProxyException("Operation timed out");
		}
	}
	
	/**
	 * Send a test event out to the events source channel
	 */
	public static void main(String[] args)
	{
		
		// sample event
		Event outEvent = new Event("test");
		outEvent.setUEI("http://uei.opennms.org/products/bluebird/test/test");

		outEvent.setNodeID("1234");
		outEvent.setInterface("1.2.3.4");
		outEvent.setTime(new java.util.Date());
		
		try
		{
			EventProxy ep = new JSDTEventProxy("test", false);
			ep.send(outEvent);
		}
		catch(Exception e)
		{
			Log.print(Log.FATAL, e.getMessage());
			Log.print(Log.FATAL, e);
		}
	}
}

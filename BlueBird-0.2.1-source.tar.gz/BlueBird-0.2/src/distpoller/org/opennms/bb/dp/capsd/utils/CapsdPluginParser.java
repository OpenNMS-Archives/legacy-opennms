//
// Copyright (C) 2000 N*Manage Company Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.dp.capsd.utils;

import org.w3c.dom.*;

import java.io.*;
import java.net.*;
import java.util.*;

import org.opennms.bb.common.utils.BBParser;
import org.opennms.bb.common.components.Log;
import org.opennms.protocols.ip.IPv4Address;

/**
 * <pre> CapsdPluginParser parses the 'capsdPluginXML.xml' to get 
 * plugin information for this poller
 *
 * It throws an IOException if the xml file is not found or if it does not
 * conform to its DTD </pre>
 *
 * @author Sowmya
 *
 */
public class CapsdPluginParser extends BBParser
{
	long		m_ipAddr; // To read info. relevant only to this poller

	List		m_plugins;

	long 		m_curPollerIP;

	/**
	 * XML TAGS that are relevant
	 */
	final String POLLERIP		= "pollerIP";
	final String TYPE		= "type";
	final String PLUGINS		= "plugins";
	final String PLUGIN		= "plugin";
	final String NAME		= "name";
	final String DBCAPABILITY	= "dbcapability";
	final String CLASSNAME		= "class";

	/**
 	 * Creates the DOM parser and the data stores
 	 */
	public CapsdPluginParser(long ipAddr) throws IOException
	{
		super();
		
		Log.print(Log.DEBUG, "CapsdPluginParser.<ctor>: Parser for address " 
			  + (new IPv4Address((int)ipAddr)));

		m_ipAddr  = ipAddr;
		m_plugins = new ArrayList();
	}

	protected boolean processElement(Element el, boolean isRoot)
	{
		Log.print(Log.DEBUG, "CapsdPluginParser.processElement(" + el + ", " + isRoot + ")");
		
		boolean bRet = false;

		Node curNode = (Node)el;

		String tag = el.getTagName();
		if (tag.equals(POLLERIP))
		{
			m_curElement.replace(0, m_curElement.length(), POLLERIP);

			// get attribute
			String type = el.getAttribute(TYPE);

			String parsedIP = processParmValue(curNode); 
			if (null != parsedIP)
			{
				if (type.equalsIgnoreCase("int"))
					m_curPollerIP = Long.parseLong(parsedIP);
				
				else if (type.equalsIgnoreCase("hex"))
					m_curPollerIP = Long.parseLong(parsedIP, 10);
				
				else if (type.equalsIgnoreCase("string"))
				{
					InetAddress inetAddr=null;
					boolean	bException=false;

					try
					{
						inetAddr = InetAddress.getByName(parsedIP);
					}
					catch(UnknownHostException e)
					{
						bException = true;
					}

					byte[] addr = inetAddr.getAddress();

					long address  = addr[3] & 0xFFL |
						(addr[2] << 8) & 0xFF00L |
						(addr[1] << 16) & 0xFF0000L |
						(addr[0] << 24) & 0xFF000000L;

					m_curPollerIP = address;
					
				}
			}

			bRet = true;
		}

		else if (tag.equals(PLUGINS))
		{
			m_curElement.replace(0, m_curElement.length(), PLUGINS);

			if (m_curPollerIP == m_ipAddr)
			{
				bRet = processPlugins(el);
			}
			else
				bRet = true;
			
		}

		else
		{
			boolean bNodeRet=true;

			NodeList nl = el.getChildNodes();
			int size = nl.getLength();

			for(int i = 0;i < size && bNodeRet ;i++)
				bNodeRet = processNode(nl.item(i));
			
			bRet = bNodeRet;
		}
		
		return bRet;
	}


	protected boolean processPlugins(Element pluginsNode)
	{
		boolean bRet = true;


		NodeList nl = pluginsNode.getChildNodes();
		int size = nl.getLength();

		for(int i = 0;i < size && bRet;i++)
		{
			Node curNode = nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
				if(curTag.equals(PLUGIN))
				{
					bRet = processPlugin((Element)curNode);
				}

			}
		}
		
		return bRet;
	}
	
	
	protected boolean processPlugin(Element pluginNode)
	{
		boolean bRet = true;

		m_curElement.replace(0, m_curElement.length(), PLUGIN);

		NodeList nl = pluginNode.getChildNodes();
		int size = nl.getLength();

		List	plugin = new ArrayList();

		for(int i = 0;i < size && bRet;i++)
		{
			Node curNode = nl.item(i);

			if (curNode.getNodeType()== Node.ELEMENT_NODE)
			{
				String curTag = ((Element)curNode).getTagName();
				if(curTag.equals(NAME))
				{
					String name = processParmValue(curNode);
					if (null != name)
						plugin.add(0, name);
				}
				else if(curTag.equals(DBCAPABILITY))
				{
					String dpCapability = processParmValue(curNode);
					if (null != dpCapability)
						plugin.add(1, dpCapability);
				}
				else if(curTag.equals(CLASSNAME))
				{
					String className = processParmValue(curNode);
					if (null != className)
						plugin.add(2, className);
				}

			}
		}

		if (plugin.isEmpty() || plugin.size() != 3)
		{
			bRet = false;
		}
		else
		{
			Log.print(Log.DEBUG, "CapsdPluginParser.processPlugin: Loaded new plugin (" +
						(String)(plugin.get(0)) + ", " + 
						(String)(plugin.get(1)) + ", " +
						(String)(plugin.get(2)) + ")");
			m_plugins.add(plugin);
		}
		
		return bRet;
	}

	/**
	 * Returns the poller plugins
	 */
	public List getPlugins()
	{
		return m_plugins;
	}
}

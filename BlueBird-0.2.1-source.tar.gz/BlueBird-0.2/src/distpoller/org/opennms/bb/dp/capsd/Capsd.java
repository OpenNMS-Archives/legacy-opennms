//
// Copyright (C) 2000 N*Manage Company Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
// Tab Stop = 8
//
// $Id: Capsd.java,v 1.19 2000/10/12 12:57:37 mike Exp $
//

package org.opennms.bb.dp.capsd;

import java.net.*;
import java.io.*;
import java.util.*;
import java.sql.SQLException;

import com.sun.media.jsdt.JSDTException;

import org.opennms.protocols.snmp.*;
import org.opennms.bb.common.components.*;
import org.opennms.bb.dp.common.components.*;
import org.opennms.bb.dp.capsd.components.*;

/**
 * <P>The Capability daemon - it is notified by the discovery process when
 * a new node is discovered - it then polls for all the capabilities for
 * this node and is responsible for loading the data collected into the
 * database.</P>
 *
 * <P>Once a node is added to the database, its sends an indication back to the 
 * discovery which then flags this node as 'known'.</P>
 *
 * @author <A HREF="mailto:sowmya@opennms.org">Sowmya</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version $Revision: 1.19 $
 */
public class Capsd extends PollerThread
{
	/**
	 * capsd plugins for capability checks
	 */
	CapsdPluginLoader	m_capsdPluginLoader;

	/**
	 * thread listening for nodes discovered
	 */
	CapsdDiscReceiver	m_discReceiver;

	/**
	 * thread maintaning a pool of threads for SNMP/service queries
	 */
	CapsdReadManager	m_capsReadMgr;

	/** 
	 * Queue to which nodes received from discovery are added
	 */
	PCQueue			m_capsReadQ;

	/**
	 * thread maintaining a pool of threads to add data to the database
	 */
	CapsdWriteManager	m_databaseWriter;

	/**
	 * Queue between the capability read and the the database writer
	 */
	PCQueue			m_databaseQ;

	/**
	 * Used to filter out duplicate addresses being sent to Capsd from
	 * discovery due to the lag between the time an address is sent
	 * to Capsd and when it is sent back to the discovery
	 * process as a "known" node.
	 * A duplicate address is any node or interface "known"
	 * by Capsd.  This includes any interfaces found via SNMP queries.
	 */
	private Set		m_dupNodes;

	/**
	 * CTRL MESSAGES - this communication needs to be replaced
	 * with JSDT comm. with the SCM
	 */
	ServerSocket		m_ctrlMessagesSocket;
	int			CTRL_COMM_SOCKET = 1235;

	/**
	 * <P>The properties that are specific to the capsd process. The 
	 * properties are a combination of the JVM's system properties, plus
	 * the inclusion of the OpenNMS specific property files. There are two
	 * additional files that are loaded, if the system properties are 
	 * correctly set.</P>
	 *
	 * <P>In order to properly load the OpenNMS specific file(s) their
	 * location must be known in advance. Instead of hard coding the
	 * location of the files, the files are referenced by properties.
	 * The following list declares the properites that reference the 
	 * specific files. The property files are loaded in the order
	 * they appear in the list.</P>
	 *
	 * <UL>
	 *	<LI>org.opennms.bluebird.propertyFile</LI>
	 *	<LI>org.openmms.bluebird.capsd.propertyFile</LI>
	 * </UL>
	 *
	 * <P>Currently the string returned for the propertyFile(s) must
	 * be a file on the local filesystem. Later support for remote
	 * files via HTTP, JSDT, etc al may be supported.</P>
	 */
	private static Properties	m_properties = null;
	
	/**
	 * <P>Copy the System properties and then load the bluebird
	 * and capsd specific files into the property object.
	 * For more information see the javadoc comment for the m_properties
	 * element.</P>
	 *
	 * <P>Additionally, this static loading will also look at the debugging 
	 * options and will setup the Logging Facility. This can only be done
	 * after the properties have been loaded.</P>
	 */
	static
	{
		//
		// get a new properties element and make the 
		// system properties the backing map
		//
		m_properties     = new Properties(System.getProperties());

		//
		// try to load the bluebird specific properties
		//
		String file = m_properties.getProperty("org.opennms.bluebird.propertyFile");
		if(file != null)
		{
			FileInputStream pfile = null;
			try
			{
				pfile = new FileInputStream(file);
				m_properties.load(pfile);
				pfile.close();
				m_properties = new Properties(m_properties); // new property with loaded as backing map
			}
			catch(IOException e) 
			{
				// do nothing
			}
		}

		//
		// Load the capsd specific files now
		//
		file = m_properties.getProperty("org.opennms.bluebird.capsd.propertyFile");
		if(file != null)
		{
			FileInputStream pfile = null;
			try
			{
				pfile = new FileInputStream(file);
				m_properties.load(pfile);
				pfile.close();
			}
			catch(IOException e)
			{
				// do nothing
			}
		}
		// end static load of properties.

		//
		// setup the debug and log facility for capsd
		//
		Log.setLevel(0);
		String logLevel = m_properties.getProperty("org.opennms.bluebird.capsd.logLevel");
		if(logLevel != null)
		{
			try
			{
				Log.setLevel(Integer.parseInt(logLevel));
			}
			catch(NumberFormatException ne) { Log.setLevel(Log.WARNING); }
		}
		
		file = m_properties.getProperty("org.opennms.bluebird.capsd.logFile");
		if(file != null)
		{
			try
			{
				Log.setOut(file);
			}
			catch(IOException e)
			{
				Log.disable();
			}
		}

		// end Log class setup
		
	} // end static class initialization

	/**
	 * Construts the Capsd object
	 *
	 * @exception CapsdPLuginException thrown when capsd plugins cannot be loaded
	 * @exception JSDTException thrown when the JSDT communication channel cannot be established
	 */
	public Capsd() 
		throws 	CapsdPluginException, 
			JSDTException,
			FileNotFoundException,
			SQLException
	{
		/* 
		 * Moved property/log setup to static class block
		 */

		/**
		 * initialize duplicate nodes list to empty set
		 */
		m_dupNodes = Collections.synchronizedSet(new HashSet());

		/**
		 * Capsd Plugins
		 */
		m_capsdPluginLoader = new CapsdPluginLoader();

		Log.print(Log.INFORMATIONAL, "Capsd service hash: " + m_capsdPluginLoader.getPlugins());

		/**
		 * create Q to be shared between the receiver and the
		 * reader
		 */
		m_capsReadQ = new PCQueueLinkedList(); // unlimited

		/**
		 * create Q to be shared between the SNMP reader and the
		 * database writer
		 */
		m_databaseQ = new PCQueueLinkedList(); // unlimited

		/**
		 * read manager
		 */
		m_capsReadMgr = new CapsdReadManager(m_capsReadQ, m_databaseQ, m_capsdPluginLoader.getPlugins(), m_dupNodes);

		/**
		 * disc receiver
		 */
		m_discReceiver= new CapsdDiscReceiver(m_capsReadQ, m_dupNodes);

		/**
		 * database writer
		 */
		m_databaseWriter= new CapsdWriteManager(m_databaseQ);

		// Set up parameters to listen to control commands
		/***
		try
		{
			m_ctrlMessagesSocket = new ServerSocket(CTRL_COMM_SOCKET);
		}
		catch(IOException ctrlE)
		{
			Log.print(Log.FATAL, "Unable to create control server socket");
			Log.print(Log.FATAL, ctrlE.getMessage());
		}
		***/
		
		setOpStatus(STATUS_STARTING);
	}


	/**
	 * Start all the threads
	 */
	public void start()
	{
		try
		{
			m_discReceiver.open();
			m_databaseWriter.connect();
		}
		catch(Exception e)
		{
			return;
		}
		
		// eventually will only start on command?
		m_databaseWriter.start();
		m_capsReadMgr.start();
		

		super.start();
	}


	/**
	 * Start the shutdown and notify run() to shutdown
	 */
	public void shutdown()
	{
		try
		{
			super.shutdown();
			if(Thread.currentThread().equals(this) == false)
				join();
		}
		catch(Exception e) 
		{ 
			// do nothing
		}
	}


	/**
	 * Waits for control messages and takes appropriate action
	 */
	public void run()
	{
		setOpStatus(STATUS_NORMAL);


		Socket			commSock;
		DataInputStream		din;

		// Temp vars (until a packet is designed for this communication 
		int		CTRL_START	= 1111;
		int		CTRL_PAUSE  	= 2222;
		int		CTRL_RESUME	= 3333;
		int		CTRL_SHUTDOWN	= 4444;

		for(;;)
		{
			synchronized(this)
			{
				for(;;)
				{
					// wait for status change notification
					try
					{
						wait();
					}
					catch(InterruptedException e)
					{
					}

					int status = getOpStatus();
					if((status & STATUS_TERMINATING) == STATUS_TERMINATING)
					{
						try
						{
							m_discReceiver.close();
							shutdownThread(m_capsReadMgr);
							shutdownThread(m_databaseWriter);

						}
						catch(InterruptedException e)
						{
							// do nothing							
						}
						
						
						setOpStatus(STATUS_SHUTDOWN);
						return;
					}
					else if((status & STATUS_PAUSING) == STATUS_PAUSING)
					{
						
						boolean setPaused = true;

						//
						try
						{
							m_discReceiver.pause();
							pauseThread(m_capsReadMgr);
							pauseThread(m_databaseWriter);

						}
						catch(IllegalThreadStateException e)
						{
							setPaused = false;
							setOpStatus(STATUS_TERMINATING);
						}
						catch(InterruptedException e)
						{
							setPaused = false;
							setOpStatus(STATUS_TERMINATING);
						}

						if(setPaused)
							setOpStatus(STATUS_PAUSED);

					}
					else if((status & STATUS_RESUMING) == STATUS_RESUMING)
					{

						// be a bit more patient here and make
						// sure they pause
						//
						boolean setNormal = true;
						try
						{
							m_discReceiver.pause();
							resumeThread(m_capsReadMgr);
							resumeThread(m_databaseWriter);
						}
						catch(IllegalThreadStateException e)
						{
							setNormal = false;
							setOpStatus(STATUS_TERMINATING);
						}
						catch(InterruptedException e)
						{
							setNormal = false;
							setOpStatus(STATUS_TERMINATING);
						}
						
						if(setNormal)
							setOpStatus(STATUS_NORMAL);

					}
					else if((status & STATUS_PAUSED) == STATUS_PAUSED)
					{
						try
						{
							wait();
						}
						catch(InterruptedException e)
						{
							setOpStatus(STATUS_TERMINATING);
						}
					}
					else if((status & STATUS_NORMAL) == STATUS_NORMAL)
					{
						break; // exit status checking loop
					}
				} // end for(;;) status check
			} // end synchronization 

			boolean bException = false;
			int		iControl=-1;

			/***
			try
			{
				// Listen for control commands
				commSock = m_ctrlMessagesSocket.accept();
	
				// Read from this socket and get command, set iControl 

			}
			catch(IOException e)
			{
				bException = true;
			}
			**/

			if (bException)
				continue;

			if(iControl == CTRL_START)
			{
				start();
			}
			else if(iControl == CTRL_PAUSE)
			{
				pauseOperation();
			}
			else if (iControl == CTRL_RESUME)
			{
				resumeOperation();
			}
			else if (iControl == CTRL_SHUTDOWN)
			{
				shutdown();
			}
			
		}
	}
	
	public static Properties getProperties()
	{
		return m_properties;
	}
	
	public static String getProperty(String key)
	{
		return m_properties.getProperty(key);
	}

	public static void main(String[] args)
	{
		try
		{
			Capsd capsd = new Capsd();
			capsd.start();
		}
		catch(Exception e)
		{
			Log.print(Log.FATAL, e.getMessage());
			e.printStackTrace();
		}
	}
	
}

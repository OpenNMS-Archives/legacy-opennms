//
// Copyright (C) 2000 N*Manage Company, Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
// $Id: SnmpInfo.java,v 1.1 2000/11/15 18:50:34 sowmya Exp $
//
package org.opennms.bb.dp.eventd.db;

import java.lang.*;
import org.opennms.bb.dp.events.EventSnmpInfo;

/**
 * This class is used to format the EventSnmpInfo block into
 * an appropiate string for storage in the event data storage.
 *
 * @author <A HREF="mailto:weave@opennms.org">Brian Weaver</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version CVS $Revision: 1.1 $
 *
 */
public final class SnmpInfo
{
	/**
	 * <P>Converts the SNMP iformation from the event into a 
	 * string that can be stored into the database. The information
	 * is formatted in by separating the of the textual fields
	 * with a delimiter character (a comma ',').</P>
	 *
	 * <P>If the enterprise id text information is not present then
	 * the string will have only two commas. An extra comma is not 
	 * added to signify the missing field.</P>
	 *
	 * @see Constants#DB_ATTRIB_DELIM
	 * @see Constants#escape
	 *
	 * @return The smnpblock as a string
	 */
	public static String format(EventSnmpInfo info)
	{
		if (info == null)
			return null;

		StringBuffer snmpStr = new StringBuffer(info.getEnterpriseID() + Constants.DB_ATTRIB_DELIM);
		if (info.getEnterpriseText() != null)
		{
			snmpStr.append(Constants.escape(info.getEnterpriseText(), 
							Constants.DB_ATTRIB_DELIM) 
				       + Constants.DB_ATTRIB_DELIM);
		}
		snmpStr.append(Integer.toString(info.getGeneric()) + Constants.DB_ATTRIB_DELIM);
		snmpStr.append(Integer.toString(info.getSpecific()));

		return snmpStr.toString();
	}
}
		
	

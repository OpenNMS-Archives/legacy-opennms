//
// Copyright (C) 2000 N*Manage Company, Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
package org.opennms.bb.dp.eventd.db;

import java.lang.*;
import java.util.List;
import java.util.Iterator;

public class Constants
{
	/**
	 * Enumerated values for severity being indeterminate
	 */
	final static int	SEV_INDETERMINATE	= 1;

	/**
	 * Enumerated values for severity being unimplemented at this time
	 */
	final static int	SEV_CLEARED		= 2;

	/**
	 * Enumerated values for severity indicates a warning
	 */
	final static int	SEV_WARNING		= 3;

	/**
	 * Enumerated values for severity is minor
	 */
	final static int	SEV_MINOR		= 4;

	/**
	 * Enumerated values for severity is major
	 */
	final static int	SEV_MAJOR		= 5;

	/**
	 * Enumerated values for severity is critical
	 */
	final static int	SEV_CRITICAL		= 6;

	/**
	 * Enumerated value for the state(tticket and forward) when entry is active
	 */
	final static int	STATE_ON		= 1;

	/**
	 * Enumerated value for the state(tticket and forward) when entry is not active
	 */
	final static int	STATE_OFF		= 0;

	/**
	 * The 'parms' are added to a single column of the DB - the parm name
	 * and value are added as delimiter separated list of 
	 * '<parmName>=<value>' strings
	 */
	final static char	NAME_VAL_DELIM		= '=';

	/**
	 * The delimiter used to delimit multiple values of the same
	 * element that are appended and made the value of a single
	 * database column
	 */
	final static char	MULTIPLE_VAL_DELIM	=';';

	/**
	 * The parser adds the value and attributes of an element to a single
	 * element of eventBlock and uses the ATTRIB_DELIM to separate
	 * these values
	 */
	final static String	ATTRIB_DELIM		="/\\";
	
	/**
	 * The values and the corresponding attributes of an element are added
	 * to a single column of the table and delimited by DB_ATTRIB_DELIM
	 */
	final static char	DB_ATTRIB_DELIM		=',';

	/**
	 * Multiple values of any xml element are appended into one value 
	 * when inserted into the database - if the length of the appended
	 * string exceeds the column length, the value is appended with this
	 * pattern
	 */
	final static String	VALUE_TRUNCATE_INDICATOR="...";

	
	/**
	 * <P>This method is used to escape required values from strings
	 * that may contain those values. If the passed string contains
	 * the passed value then the character is reformatted into its
	 * <EM>%dd</EM> format.</P>
	 *
	 *
	 * @param inStr		string that might contain the delimiter
	 * @param delimChar	delimiter to escape
	 *
	 * @return The string with the delimiter escaped as in URLs
	 *
	 * @see #DB_ATTRIB_DELIM
	 * @see #MULTIPLE_VAL_DELIM
	 */
	public static String escape(String inStr, char delimchar)
	{
		// integer equivalent of the delimiter
		int  delim = delimchar;

		// convert this to a '%<int>' string
		String delimEscStr = "%" + String.valueOf(delim);

		// the buffer to return
		StringBuffer outBuffer = new StringBuffer(inStr);
		
		int index=0;
		int delimIndex = inStr.indexOf(delimchar, index);
		while(delimIndex != -1)
		{
			// delete the delimiter and add the escape string
			outBuffer.deleteCharAt(delimIndex);
			outBuffer.insert(delimIndex, delimEscStr);

			index = delimIndex + delimEscStr.length() + 1;
			delimIndex = outBuffer.toString().indexOf(delimchar, index);
		}
		
		return outBuffer.toString();
	}

	
	/**
	 * <P>This method is passed a list of string and a 
	 * maximum string size that must not be exceeded by
	 * the composite string.</P>
	 *
	 * @param string	The list of String objects.
	 * @param maxlen	The maximum length of the composite string
	 *
	 * @return The composite string.
	 *
	 * @exception java.lang.ClassCastException Thrown if any processed
	 * 	item in the list is not a string object.
	 *
	 */
	public static String format(List strings, int maxlen)
	{
		StringBuffer 	buf = new StringBuffer();
		boolean 	first = true;
		Iterator 	i = strings.iterator();
		
		while(i.hasNext() && buf.length() < maxlen)
		{
			String s = (String)i.next();
			s = escape(s, MULTIPLE_VAL_DELIM);
			if(!first)
				buf.append(MULTIPLE_VAL_DELIM);
			buf.append(s);
			first = false;
		}
		
		if(buf.length() >= maxlen)
		{
			buf.setLength(maxlen-4);
			buf.append(VALUE_TRUNCATE_INDICATOR);
		}
		return buf.toString();
	}
	
	/**
	 * Converts the severity to an integer
	 *
	 * @returns integer equivalent for the severity
	 */
	public static int getSeverity(String sev)
	{
		int rc = SEV_INDETERMINATE;
		if(sev != null)
		{
			if (sev.equalsIgnoreCase("warning"))
				rc = SEV_WARNING;
			else if (sev.equalsIgnoreCase("minor"))
				rc = SEV_MINOR;
			else if (sev.equalsIgnoreCase("major"))
				rc = SEV_MAJOR;
			else if (sev.equalsIgnoreCase("critical"))
				rc = SEV_CRITICAL;
			else if (sev.equalsIgnoreCase("cleared"))
				rc = SEV_CLEARED;
		}
		return rc;
	}

}



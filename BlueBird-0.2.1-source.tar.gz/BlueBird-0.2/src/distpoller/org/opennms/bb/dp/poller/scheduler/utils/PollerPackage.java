//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.dp.poller.scheduler.utils;

import java.util.*;

import org.opennms.bb.dp.poller.scheduler.utils.RangeInfo;
import org.opennms.bb.dp.poller.scheduler.utils.ServiceInfo;
import org.opennms.bb.common.db.DBOpenFailureException;
import org.opennms.bb.common.filter.exceptions.FailedParseException;
import org.opennms.bb.common.filter.BBFilter;

/**This class is a representation of a BlueBird package as parsed
 * from the package.xml file.
 * 
 * @author <A HREF="mailto:jason@opennms.org">Jason Johns</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version $Revision: 1.3 $
 * 
 */
public class PollerPackage
{
	/**The name of the package
	*/
	private String m_name;
	
	/**The filter expression rule for the package
	*/
	private String m_filterExpr;
	
	/**Range information for the package
	*/
	private RangeInfo m_rangeInfo;
	
	/**List of services associated with the package
	*/
	private HashMap m_services;
	
	/**The parser to parse and execute a filter expression
	*/
	private BBFilter m_filterParser;

	/**Constructor to assign a name to the package and initialize
	   the various members.
	   @param String aName, the name of the package
	*/
	public PollerPackage(String aName)
	{
		m_name = aName;
		m_rangeInfo = new RangeInfo();
		m_services = new HashMap();
		
		try
		{
			m_filterParser = new BBFilter();
		}
		catch(DBOpenFailureException e)
		{
			System.out.println(e);
			e.printStackTrace();
		}
	}
	
	/**This method determines if an ip address is within the range specifications
	   of the package. This includes the specific addresses, the exclude ranges
	   and the inlcude ranges. An ip is in the range if it is specifically mentioned,
	   or if it is not in the exclude range and within the include range.
	   @return boolean, indicating if the ip is in the package range
	   @param String ipAddr, the address to check the range for
	*/
	public boolean ipInRange(String ipAddr)
	{
		//if the ip address is specifically included then return true
		if(m_rangeInfo.inSpecific(ipAddr))
			return true;
		
		//if the address was not specifically included and it is within the exclude
		//ranges then return false
		if(m_rangeInfo.inExclude(ipAddr))
			return false;
		
		//if the address was not within the exclude ranges see if it is in the
		//include ranges
		if(m_rangeInfo.inInclude(ipAddr))
			return true;
		
		//the address was not specifically included and was not in the include ranges
		return false;
	}
	
	/**This method runs the filterExpr against the database to get back
	   a list of ip addresses that match the rule.
	   @return List, a list of matching ip addresses
	*/
	public List getFilterList()
	{
		List filterList = null;
		
		try
		{
			filterList = m_filterParser.getIPList(m_filterExpr);
		}
		catch(FailedParseException e)
		{
			System.out.println(e);
			e.printStackTrace();
		}
		
		return filterList;
	}
	
	/**This method checks to see if a particular ip address is within
	   the list returned by a filter expression.
	   @return boolean, indicating if the ip address is a member of the
	                    filter expression set
	   @param String ipAddr, the address to check
	*/
	public boolean ipInFilter(String ipAddr)
	{
		boolean result = false;
		
		try
		{
			result = m_filterParser.isValid(ipAddr, m_filterExpr);
		}
		catch (FailedParseException e)
		{
			System.out.println(e);
			e.printStackTrace();
		}
		
		return result;
	}
	
	/**This method adds a service to the package
	   @param ServiceInfo aService, a class encapulating the service information
	*/
	public void addService(ServiceInfo aService)
	{
		m_services.put(aService.getServiceName(), aService);
	}
	
	/**This method returns the ServiceInfo for a given service name
	   @return ServiceInfo, the service information
	   @param String aServiceName, the name of the service to look up
	*/
	public ServiceInfo getService(String aServiceName)
	{
		return (ServiceInfo)m_services.get(aServiceName);
	}
	
	/**
	*/
	public List getServiceNames()
	{
		List serviceNames = new ArrayList();
		
		Iterator i = m_services.keySet().iterator();
		
		while(i.hasNext())
		{
			serviceNames.add( (String)i.next() );
		}
		
		return serviceNames;
	}
	
	/**This method returns the range information for this package
	   @return RangeInfo, the range information
	*/
	public RangeInfo getRangeInfo()
	{
		return m_rangeInfo;
	}
	
	/**This method sets the filterExpr member. A semi-colon is 
	   placed at the end of the rule to conform to the BNF for the
	   rule expression language.
	   @param String anExpr, the expression to set
	*/
	public void setFilterExpr(String anExpr)
	{
		//must have terminating semi-colon
		m_filterExpr = anExpr + ";";
	}
	
	/**This method returns the filter expression member
	   @return String, the filter expression
	*/
	public String getFilterExpr()
	{
		return m_filterExpr;
	}
	
	/**This method returns the package name
	   @return String, the package name
	*/
	public String getName()
	{
		return m_name;
	}
	
	/**This method returns a string representation of the package
	   @return String, a string representation of the package
	*/
	public String toString()
	{
		StringBuffer buffer = new StringBuffer("Package " + m_name);
		
		buffer.append("\r\nFilter = ").append(m_filterExpr);
		buffer.append("\r\n").append(m_rangeInfo.toString());
		
		Iterator i = m_services.keySet().iterator();
		
		while(i.hasNext())
		{
			buffer.append("\r\n").append(((ServiceInfo)m_services.get(i.next())).toString());
		}
		
		return buffer.toString();
	}
}

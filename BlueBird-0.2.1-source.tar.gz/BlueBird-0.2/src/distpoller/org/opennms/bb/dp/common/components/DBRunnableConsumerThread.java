//
// Copyright (C) 2000 N*Manage Company, Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
// $Id: DBRunnableConsumerThread.java,v 1.2 2000/10/13 17:43:36 weave Exp $
//
// Extra Log Information
//---------------------------
// Weave 9/11/00
//	Changed the class to extend from PollerThread instead of Thread. I 
//	think I get the same functionally in a better class by just 
//	rewriting the constructors and run method. Thus we only have to
//	maintain the PollerThread class. Plus, most threads are inheriented
//	from poller thread and this would keep that consistant.
//---------------------------
//

package org.opennms.bb.dp.common.components;

import java.lang.*;
import java.sql.*;
import org.opennms.bb.common.components.PCQueue;
import org.opennms.bb.common.components.QueueClosedException;

/**
 * <P>The DBRunnableConsumerThread class is similar to 
 * RunnableConsumerThread. It creates or uses an existing
 * database connection and deals with a queue of DBRunnable
 * objects that are executed with the database connection.</P>
 *
 * @author <A HREF="mailto:sowmya@opennms.org">Sowmya</A>
 * @author <A HREF="mailto:weave@opennms.org">Weave</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version $Revision: 1.2 $
 */
public final class DBRunnableConsumerThread extends PollerThread
{
	/**
	 * <P>The Producer/Consumer Queue where Runnable
	 * Objects are dequeued and run by the run() 
	 * method.</P>
	 */
	private PCQueue		m_input;
	
	/**
	 * <P>The Producer/Consumer Queue where the 
	 * Runnable objects from the input queue are
	 * placed when their run() method returns.
	 * If the queue is <EM>null</EM> then the Runnable
	 * objects are discarded.</P>
	 */
	private PCQueue		m_output;
	
	/**
	 * <P>The connection to the sql database.</P>
	 */
	private Connection	m_dbConn;
	
	/**
	 * <P>This defines the thread specific bits that mark
	 * the thread as idle when its status is STATUS_NORMAL.</P>
	 */
	public final static int		STATUS_IDLE	= 1 << 8;
	
	/**
	 * <P>This defines the thread specific bits that mask
	 * the thread as busy when its status is STATUS_NORMAL.</P>
	 */
	public final static int		STATUS_BUSY	= 1 << 9;

	/**
	 * <P>Called by the constructor for this class. It attempts to 
	 * load the specified JDBC Driver class and allocate a connection
	 * to the database. The conection is opened at the specified
	 * URL using the passed user name/password combination.</P>
	 *
	 * @param dbDriver	The JDBC Driver class to load
	 * @param url		The location of the database for the driver
	 * @param user		The username for the database
	 * @param passwd	The password for the user
	 *
	 * @exception java.lang.ClassNotFoundException Thrown if the specified
	 * 	driver class cannot be found and loaded.
	 * @exception java.sql.SQLException Thrown by the driver if an sql
	 * 	error occurs.
	 *
	 */
	private void dbConnect(String dbDriver, 
			       String url, 
			       String user, 
			       String passwd) 
		throws 	ClassNotFoundException, 
			SQLException
	{
		// load driver
		Class.forName(dbDriver);

    		// Connect to the database
		m_dbConn = DriverManager.getConnection(url, user, passwd);
	}

	/**
	 * <P>Constructs a thread consumer of objects that implement the 
	 * DBRunnable interface. The objects are consumed from the
	 * input queue specified in the constructor.</P>
	 *
	 * @param input 	The source of the runnable objects.
	 * @param dbDriver	The JDBC driver class name
	 * @param url		The URL location of the database
	 * @param user		The user for the connection
	 * @param passwd	The password for the user.
	 *
	 * @exception java.lang.IllegalArgumentException Thrown if the
	 * 	input queue is not valid.
	 * @exception java.lang.ClassNotFoundException Thrown if the driver
	 * 	class cannot be loaded.
	 * @exception java.sql.SQLException Thrown if an exception is generated in
	 * 	the SQL handing of the connect.
	 */
	public DBRunnableConsumerThread(PCQueue 	input, 
				        String 		dbDriver, 
					String		url, 
					String		user, 
					String 		passwd) 
		throws ClassNotFoundException,	SQLException
	{
		super();
		
		m_dbConn = null;
		m_input  = input;
		m_output = null;

		if(m_input == null)
			throw new IllegalArgumentException("input queue must not be null");
		
		dbConnect(dbDriver, url, user, passwd);
	}

	/**
	 * <P>Constructs a thread consumer of objects that implement the 
	 * DBRunnable interface. The objects are consumed from the
	 * input queue specified in the constructor.</P>
	 *
	 * @param input 	The source of the runnable objects.
	 * @param dbconn	An existing JDBC connection.
	 *
	 * @exception java.lang.IllegalArgumentException Thrown if the
	 * 	input queue is not valid.
	 */
	public DBRunnableConsumerThread(PCQueue input, Connection dbconn)
	{
		super();
		
		m_dbConn = dbconn;
		m_input  = input;
		m_output = null;
		if(m_input == null)
			throw new IllegalArgumentException("input queue must not be null");
	}
	
	/**
	 * <P>Constructs a consumer of objects that implement the 
	 * DBRunnable interface. The objects are consumed from the
	 * input queue specified in the constructor. Once the runnable
	 * objects have had their run() method invoked and return the
	 * objects are then enqueued on the output queue.</P>
	 *
	 * @param input 	The source of the runnable objects.
	 * @param output 	The destination of the spent runnable objects.
	 * @param dbDriver	The JDBC driver class name
	 * @param url		The URL location of the database
	 * @param user		The user for the connection
	 * @param passwd	The password for the user.
	 *
	 * @exception java.lang.IllegalArgumentException Thrown if the
	 * 	input or output queue are not valid.
	 * @exception java.lang.ClassNotFoundException Thrown if the driver
	 * 	class cannot be loaded.
	 * @exception java.sql.SQLException Thrown if an exception is generated in
	 * 	the SQL handing of the connect.
	 */
	public DBRunnableConsumerThread(PCQueue 	input, 
					PCQueue 	output,
					String 		dbDriver, 
					String 		url, 
					String 		user, 
					String 		passwd) 
		throws ClassNotFoundException, SQLException
	{
		this(input, dbDriver, url, user, passwd);
		
		m_output = output;
		if(m_output == null)
			throw new IllegalArgumentException("output queue must not be null");
	}

	/**
	 * <P>Constructs a consumer of objects that implement the 
	 * DBRunnable interface. The objects are consumed from the
	 * input queue specified in the constructor. Once the runnable
	 * objects have had their run() method invoked and return the
	 * objects are then enqueued on the output queue.</P>
	 *
	 * @param input 	The source of the runnable objects.
	 * @param output 	The destination of the spent runnable objects.
	 * @param dbconn	An existing JDBC connection.
	 *
	 * @exception java.lang.IllegalArgumentException Thrown if the
	 * 	input or output queue are not valid.
	 */
	public DBRunnableConsumerThread(PCQueue 	input, 
					PCQueue 	output,
					Connection	dbconn)
	{
		this(input, dbconn);
		
		m_output = output;
		if(m_output == null)
			throw new IllegalArgumentException("output queue must not be null");
	}
	
	/**
	 * <P>Constructs a thread consumer of objects that implement the 
	 * DBRunnable interface. The objects are consumed from the
	 * input queue specified in the constructor. The name of the
	 * thread is specified in the constructor.</P>
	 *
	 * @param name		The thread name supplied to base class.
	 * @param input 	The source of the runnable objects.
	 * @param dbDriver	The JDBC driver class name
	 * @param url		The URL location of the database
	 * @param user		The user for the connection
	 * @param passwd	The password for the user.
	 *
	 * @exception java.lang.IllegalArgumentException Thrown if the
	 * 	input queue is not valid.
	 * @exception java.lang.ClassNotFoundException Thrown if the driver
	 * 	class cannot be loaded.
	 * @exception java.sql.SQLException Thrown if an exception is generated in
	 * 	the SQL handing of the connect.
	 */
	public DBRunnableConsumerThread(String 		name, 
					PCQueue 	input,
					String 		dbDriver, 
					String 		url, 
					String 		user, 
					String 		passwd) 
		throws ClassNotFoundException, SQLException
	{
		super(name);
		
		m_input  = input;
		m_output = null;
		if(m_input == null)
			throw new IllegalArgumentException("input queue must not be null");
		
		dbConnect(dbDriver, url, user, passwd);
	}

	/**
	 * <P>Constructs a thread consumer of objects that implement the 
	 * DBRunnable interface. The objects are consumed from the
	 * input queue specified in the constructor. The name of the
	 * thread is specified in the constructor.</P>
	 *
	 * @param name		The thread name supplied to base class.
	 * @param input 	The source of the runnable objects.
	 * @param dbconn	An existing JDBC conneciton.
	 *
	 * @exception java.lang.IllegalArgumentException Thrown if the
	 * 	input queue is not valid.
	 */
	public DBRunnableConsumerThread(String 		name, 
					PCQueue 	input,
					Connection	dbconn) 
	{
		super(name);
		
		m_dbConn = dbconn;
		m_input  = input;
		m_output = null;
		if(m_input == null)
			throw new IllegalArgumentException("input queue must not be null");
	}

	/**
	 * <P>Constructs a consumer of objects that implement the 
	 * DBRunnable interface. The objects are consumed from the
	 * input queue specified in the constructor. Once the runnable
	 * objects have had their run() method invoked and return the
	 * objects are then enqueued on the output queue.</P>
	 *
	 * @param name		The thread name supplied to the base class.
	 * @param input 	The source of the runnable objects.
	 * @param output 	The destination of the spent runnable objects.
	 * @param dbDriver	The JDBC driver class name
	 * @param url		The URL location of the database
	 * @param user		The user for the connection
	 * @param passwd	The password for the user.
	 *
	 * @exception java.lang.IllegalArgumentException Thrown if the
	 * 	input or output queue are not valid.
	 * @exception java.lang.ClassNotFoundException Thrown if the driver
	 * 	class cannot be loaded.
	 * @exception java.sql.SQLException Thrown if an exception is generated in
	 * 	the SQL handing of the connect.
	 */
	public DBRunnableConsumerThread(String 		name, 
					PCQueue 	input, 
					PCQueue 	output, 
					String 		dbDriver, 
					String 		url, 
					String 		user, 
					String 		passwd) 
		throws ClassNotFoundException, SQLException
	{
		this(name, input, dbDriver, url, user, passwd);
		
		m_output = output;
		if(m_output == null)
			throw new IllegalArgumentException("output queue must not be null!");
	}

	/**
	 * <P>Constructs a consumer of objects that implement the 
	 * DBRunnable interface. The objects are consumed from the
	 * input queue specified in the constructor. Once the runnable
	 * objects have had their run() method invoked and return the
	 * objects are then enqueued on the output queue.</P>
	 *
	 * @param name		The thread name supplied to the base class.
	 * @param input 	The source of the runnable objects.
	 * @param output 	The destination of the spent runnable objects.
	 * @param dbconn	An existing connection to the database.
	 *
	 * @exception java.lang.IllegalArgumentException Thrown if the
	 * 	input or output queue are not valid.
	 */
	public DBRunnableConsumerThread(String 		name, 
					PCQueue 	input, 
					PCQueue 	output, 
					Connection	dbconn)
	{
		this(name, input, dbconn);
		
		m_output = output;
		if(m_output == null)
			throw new IllegalArgumentException("output queue must not be null!");
	}
	
	/**
	 * <P>Constructs a thread consumer of objects that implement the 
	 * Runnable interface. The objects are consumed from the
	 * input queue specified in the constructor. The actual thread
	 * is created as a member of the ThreadGroup grp.</P>
	 *
	 * @param grp	The thread group for the new thread.
	 * @param name	The thread name to pass to the base class.
	 * @param input The source of the runnable objects.
	 * @param dbDriver	The JDBC driver class name
	 * @param url		The URL location of the database
	 * @param user		The user for the connection
	 * @param passwd	The password for the user.
	 *
	 * @exception java.lang.IllegalArgumentException Thrown if the
	 * 	input queue is not valid.
	 * @exception java.lang.ClassNotFoundException Thrown if the driver
	 * 	class cannot be loaded.
	 * @exception java.sql.SQLException Thrown if an exception is generated in
	 * 	the SQL handing of the connect.
	 */
	public DBRunnableConsumerThread(ThreadGroup 	grp, 
					String 		name, 
					PCQueue 	input, 
					String 		dbDriver, 
					String 		url, 
					String 		user, 
					String 		passwd)
		throws ClassNotFoundException, SQLException
	{
		super(grp, name);
		
		m_input  = input;
		m_output = null;
		if(m_input == null)
			throw new IllegalArgumentException("input queue must not be null");
		
		dbConnect(dbDriver, url, user, passwd);
	}

	/**
	 * <P>Constructs a thread consumer of objects that implement the 
	 * Runnable interface. The objects are consumed from the
	 * input queue specified in the constructor. The actual thread
	 * is created as a member of the ThreadGroup grp.</P>
	 *
	 * @param grp		The thread group for the new thread.
	 * @param name		The thread name to pass to the base class.
	 * @param input 	The source of the runnable objects.
	 * @param dbconn	An existing connection to the database.
	 *
	 * @exception java.lang.IllegalArgumentException Thrown if the
	 * 	input queue is not valid.
	 */
	public DBRunnableConsumerThread(ThreadGroup 	grp, 
					String 		name, 
					PCQueue 	input, 
					Connection	dbconn)
	{
		super(grp, name);
		
		m_dbConn = dbconn;
		m_input  = input;
		m_output = null;
		if(m_input == null)
			throw new IllegalArgumentException("input queue must not be null");
	}

	/**
	 * <P>Constructs a threadconsumer of objects that implement the 
	 * Runnable interface. The objects are consumed from the
	 * input queue specified in the constructor. Once the runnable
	 * objects have had their run() method invoked and return the
	 * objects are then enqueued on the output queue. The thread is
	 * created in the passed thread group with the passed name.</P>
	 *
	 * @param grp		The thread group for membership.
	 * @param name		The name of the new thread.
	 * @param input 	The source of the runnable objects.
	 * @param output 	The destination of the spent runnable objects.
	 * @param dbDriver	The JDBC driver class name
	 * @param url		The URL location of the database
	 * @param user		The user for the connection
	 * @param passwd	The password for the user.
	 *
	 * @exception java.lang.IllegalArgumentException Thrown if the
	 * 	input or output queue are not valid.
	 * @exception java.lang.ClassNotFoundException Thrown if the driver
	 * 	class cannot be loaded.
	 * @exception java.sql.SQLException Thrown if an exception is generated in
	 * 	the SQL handing of the connect.
	 */
	public DBRunnableConsumerThread(ThreadGroup 	grp, 
					String 		name, 
					PCQueue 	input, 
					PCQueue 	output, 
					String		dbDriver, 
					String		url, 
					String 		user, 
					String 		passwd) 
		throws ClassNotFoundException, 
		SQLException
	{
		this(grp, name, input, dbDriver, url, user, passwd);
		
		m_output = output;
		if(m_output == null)
			throw new IllegalArgumentException("output queue must not be null!");
	}

	/**
	 * <P>Constructs a threadconsumer of objects that implement the 
	 * Runnable interface. The objects are consumed from the
	 * input queue specified in the constructor. Once the runnable
	 * objects have had their run() method invoked and return the
	 * objects are then enqueued on the output queue. The thread is
	 * created in the passed thread group with the passed name.</P>
	 *
	 * @param grp		The thread group for membership.
	 * @param name		The name of the new thread.
	 * @param input 	The source of the runnable objects.
	 * @param output 	The destination of the spent runnable objects.
	 * @param dbconn	An existing connection to the database.
	 *
	 * @exception java.lang.IllegalArgumentException Thrown if the
	 * 	input or output queue are not valid.
	 */
	public DBRunnableConsumerThread(ThreadGroup 	grp, 
					String 		name, 
					PCQueue 	input, 
					PCQueue 	output, 
					Connection	dbconn) 
	{
		this(grp, name, input, dbconn);
		
		m_output = output;
		if(m_output == null)
			throw new IllegalArgumentException("output queue must not be null!");
	}
	
	
	/**
	 * <P>The run() method is actually invoked by the Thread
	 * base class and calls the run() method for each Runnable
	 * object dequeued by the class. The method ensures that 
	 * the status of the object is kept updated as it dequeues,
	 * runs, and enqueues the runnables.</P>
	 *
	 * <P>If the thread is paused the run() method may not 
	 * transition to paused until the current runnable object,
	 * if any, completes. Likewise the thread will not terminate
	 * until the current runnable returns control to the thread.</P>
	 *
	 */
	public void run( )
	{
		setOpStatus(STATUS_NORMAL | STATUS_IDLE);
		
		for(;;)
		{
			// infinite loop
			
			synchronized(this)
			{
				for(;;)
				{
					int status = getOpStatus();
					if((status & STATUS_TERMINATING) == STATUS_TERMINATING)
					{
						setOpStatus(STATUS_SHUTDOWN);
						return;
					}
					else if((status & STATUS_PAUSING) == STATUS_PAUSING)
					{
						setOpStatus(STATUS_PAUSED);
					}
					else if((status & STATUS_RESUMING) == STATUS_RESUMING)
					{
						setOpStatus(STATUS_NORMAL | STATUS_IDLE);
					}
					else if((status & STATUS_PAUSED) == STATUS_PAUSED)
					{
						try
						{
							wait();
						}
						catch(InterruptedException e)
						{
							setOpStatus(STATUS_TERMINATING);
						}
					}
					else if((status & STATUS_NORMAL) == STATUS_NORMAL)
					{
						//
						// Check the input queue. If the queue is empty
						// then we need to have the queue signal this 
						// thread. This allows the thread to wait on itself
						// for status changes.
						//
						boolean doWait = false;
						synchronized(m_input)
						{
							if(m_input.isEmpty())
							{
								//
								// queue is empty, so set the notification
								// and then release the sync on the queue.
								//
								doWait = true;
								m_input.oneShotNotifyAllOnAdd(this);
							}
						}
						
						if(doWait)
						{
							try
							{
								//
								// This will release lock on self and 
								// allow status changes and queue additions
								// to signal the thread.
								//
								wait();
							}
							catch(InterruptedException e)
							{
								setOpStatus(STATUS_TERMINATING);
							}
						}
						else
						{
							//
							// The queue has at least one element
							// so now we need to break out and chekc
							//
							break;
						}
					}
				} // end loop
			} // end sync()
			
			//
			// get the next runnable object, and send it the
			// DB connection info. Do this all at once, another
			// thread could have grabbed the entry we wanted!
			//
			
			DBRunnable todo = null;
			try
			{
				synchronized(m_input)
				{
					//
					// synchronization allow us to check
					// the number of elements and read 
					// all in one atomic operation
					//
					if(!m_input.isEmpty())
					{
						Object obj  = m_input.read();
						try
						{
							if(obj != null)
								todo = (DBRunnable)obj;
						}
						catch(ClassCastException e)
						{
							todo = null;
						}
					}
				}
			}
			catch(InterruptedException e)
			{
				//
				// interrupted exception means it's time
				// to exit the run method
				//
				setOpStatus(STATUS_TERMINATING);
				todo = null;
			}
			catch(QueueClosedException e)
			{
				setOpStatus(STATUS_TERMINATING);
				todo = null;
			}
				
			//
			// if the conversion failed then
			// continue. Also, if the terminate
			// flag is now set after waiting then 
			// go to the top of the loop
			//
			// NOTE: don't continue on a pause, if there
			// is an object by this point we have to process
			// it or lose it. 
			//
			if(todo == null || (getOpStatus() & STATUS_TERMINATING) == STATUS_TERMINATING)
			{
				continue;
			}
			
			setUserStatus(STATUS_BUSY);
	
			try
			{
				todo.dbRun(m_dbConn);
				if(m_output != null)
					m_output.add(todo);
			}
			catch(QueueClosedException e)
			{
				setOpStatus(STATUS_TERMINATING);
			}
			catch(Exception t)
			{
				// what to do here?
				// Ignore it I guess
			}
	
			setUserStatus(STATUS_IDLE);
			
		} // end outer infinite loop
		
	} // end run method

}


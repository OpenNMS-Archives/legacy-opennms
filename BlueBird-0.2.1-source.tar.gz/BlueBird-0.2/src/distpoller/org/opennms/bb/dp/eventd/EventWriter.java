//
// Copyright (C) 2000 N*Manage Company, Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
package org.opennms.bb.dp.eventd;

import java.lang.*;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.sql.Types;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import com.sun.media.jsdt.*;

import org.opennms.bb.common.components.*;
import org.opennms.bb.dp.common.components.*;
import org.opennms.bb.dp.events.Event;
import org.opennms.bb.dp.events.EventHeader;
import org.opennms.bb.dp.events.EventOperatorAction;
import org.opennms.bb.dp.events.EventTroubleTicket;
import org.opennms.bb.dp.events.XMLEventsParser;
import org.opennms.bb.dp.eventd.db.*;

/**
 * <P>EventWriter loads the information in each 'EventBlock' into the database
 * Once the events are added to the database, they are sent out via JSDT
 * for other processes (such as actiond) to read</P>
 *
 * <P>While loading mutiple values of the same element into a single DB column,
 * the mutiple values are delimited by MULTIPLE_VAL_DELIM</P>
 *
 * <P>When an element and its attribute are loaded into a single DB column,
 * the value and the attribute are separated by a DB_ATTRIB_DELIM</P>
 *
 * <P>When using delimiters to append values, if the values already have the
 * delimiter, the delimiter in the value is escaped as in URLs</P>
 *
 * <P>Values for the '<parms>' block are loaded with each parm name and
 * parm value delimited with the NAME_VAL_DELIM</P>
 *
 * @see #MULTIPLE_VAL_DELIM
 * @see #DB_ATTRIB_DELIM
 * @see #escapeDelimiter()
 * @see #NAME_VAL_DELIM
 *
 * @author 	<A HREF="mailto:sowmya@opennms.org">Sowmya Kumaraswamy</A>
 * @author	<A HREF="http://www.opennms.org">OpenNMS.org</A>
 *
 * @version	$Revision: 1.1 $
 */
public class EventWriter implements DBRunnable, Runnable
{
	/**
	 * The current event that is to be written
	 */
	private Event		m_event;
	
	/**
	 * The event header
	 */
	private EventHeader	m_header;
	
	/**
	 * The JSDT client
	 */
	private Client		m_client;
	
	/**
	 * The JSDT channel
	 */
	private Channel		m_channel;

	/**
	 * Sets the statement up for an interger type. If the 
	 * interger type is less than zero, then it is set to
	 * null!
	 *
	 * @param stmt	The statement to add the value to.
	 * @param ndx	The ndx for the value.
	 * @param value The value to add to the statement.
	 *
	 * @exception java.sql.SQLException Thrown if there is an error
	 * 	adding the value to the statement.
	 */
	private void set(PreparedStatement stmt, int ndx, String value)
		throws SQLException
	{
		if(value == null || value.length() == 0)
			stmt.setNull(ndx, Types.VARCHAR);
		else
			stmt.setString(ndx, value);
	}
	
	/**
	 * Sets the statement up for an interger type. If the 
	 * interger type is less than zero, then it is set to
	 * null!
	 *
	 * @param stmt	The statement to add the value to.
	 * @param ndx	The ndx for the value.
	 * @param value The value to add to the statement.
	 *
	 * @exception java.sql.SQLException Thrown if there is an error
	 * 	adding the value to the statement.
	 */
	private void set(PreparedStatement stmt, int ndx, int value)
		throws SQLException
	{
		if(value < 0)
			stmt.setNull(ndx, Types.INTEGER);
		else
			stmt.setInt(ndx, value);
	}

	/**
	 * Insert values into the EVENTS table 
	 *
	 * @see org.opennms.bb.events.eventd.databalocks.EventBlock
	 * @see org.opennms.bb.events.eventd.utils.EventsParser#ATTRIB_DELIM
	 * @see #ATTRIB_DELIM
	 * @see #DB_ATTRIB_DELIM
	 * @see #VALUE_TRUNCATE_INDICATOR
	 *
	 * @return true if the add is successful, false if not
	 *
	 * @exception java.sql.SQLException Thrown if there is an error adding
	 *	the event to the database.
	 * @exception java.lang.NullPointerException Thrown if a required resource cannot
	 * 	be found in the properties file.
	 */
	private void add(Connection db) throws SQLException
	{
		boolean	bRet = true;
		int eventID = -1;

		PreparedStatement eventIdStmt = null;
		try
		{
			// events next id from sequence
			String stmt = Eventd.getProperty(EventdConstants.PROP_DB_GET_NEXTEVENTID);
			if(stmt == null)
				throw new NullPointerException("Unable to locate property: " + EventdConstants.PROP_DB_GET_NEXTEVENTID);
			eventIdStmt = db.prepareStatement(stmt);
			
			//
			// Execute the statementto get the next event id
			//
			ResultSet rs = eventIdStmt.executeQuery();
			rs.next();
			eventID = rs.getInt(1);
			rs = null;
		}
		catch(SQLException e)
		{
			Log.print(Log.WARNING, "SQL Exception while trying to get the next id");
			Log.print(Log.WARNING, e);
			Log.print(Log.WARNING, "Rethrowing exception to next level");
			throw e;
		}
		finally
		{
			try
			{
				if(eventIdStmt != null)
					eventIdStmt.close();
				eventIdStmt = null;
			}
			catch(Exception e) { }
		}
				

		PreparedStatement eventInsStmt = null;
		try
		{
	
			// events table insert string
			String stmt = Eventd.getProperty(EventdConstants.PROP_DB_INS_EVENT);
			if(stmt == null)
				throw new NullPointerException("Unable to locate property: " + EventdConstants.PROP_DB_INS_EVENT);
			eventInsStmt = db.prepareStatement(stmt);
			
			Log.print(Log.DEBUG, "eventInsStmt = " + eventInsStmt.toString());
			
	
			//
			// Set up the sql information now
			//
			eventInsStmt.setInt(1, eventID);				// eventID
			eventInsStmt.setString(2, m_event.getUEI());			// eventUEI
			
			if(m_event.hasSnmpInfo())					// eventSnmp
				eventInsStmt.setString(3, SnmpInfo.format(m_event.getSnmpInfo()));
			else
				eventInsStmt.setNull(3, Types.VARCHAR);
	
			eventInsStmt.setString(4, Time.format(m_event.getTime()));	// eventTime
			set(eventInsStmt, 5, m_event.getHost());			// eventHost
			set(eventInsStmt, 6, m_event.getSnmpHost());			// eventSnmpHost
			eventInsStmt.setString(7, m_header != null
							? m_header.getDPName()
							: "undefined");			// eventDpName
			set(eventInsStmt, 8, m_event.hasParms() 
						? Parameter.format(m_event.getParms()) 
						: null);				// eventParms
			try								// nodeID
			{
				set(eventInsStmt, 9, m_event.hasNodeID() 
							? Integer.parseInt(m_event.getNodeID())
							: -1);
			}
			catch(NumberFormatException ne)
			{
				set(eventInsStmt, 9, -1);
			}
			try								// serviceID
			{
				set(eventInsStmt, 10, m_event.hasService() 
							? Integer.parseInt(m_event.getService())
							: -1);
			}
			catch(NumberFormatException ne)
			{
				set(eventInsStmt, 10, -1);
			}
			
			set(eventInsStmt, 11, m_event.getInterface());			// ipAddr
			eventInsStmt.setString(12, Time.format(new GregorianCalendar())); // eventCreateTime
			set(eventInsStmt, 13, m_event.getDescription());		// eventDescr
			set(eventInsStmt, 14, m_event.hasLogGroups() 			// eventLoggroup
						? Constants.format(m_event.getLogGroups(),32) 
						: null);
			set(eventInsStmt, 15, m_event.hasLogMessage()			// eventLogmsg
						? LogMessage.format(m_event.getLogMessage())
						: null);
			set(eventInsStmt, 16, Constants.getSeverity(m_event.getSeverity()));// eventSeverity
			set(eventInsStmt, 17, m_event.getOperatorInstruction());		// eventOperInstruct
			set(eventInsStmt, 18, m_event.hasAutoActions()
						? Constants.format(m_event.getAutoActions(), 256)
						: null);
	
			if(m_event.hasOperatorActions())				// eventOperAction
			{								// eventOperActionMenuText
				List a = new ArrayList();
				List b = new ArrayList();
				Iterator i = m_event.getOperatorActions().iterator();
				while(i.hasNext())
				{
					EventOperatorAction eoa = (EventOperatorAction)i.next();
					a.add(eoa.getAction());
					b.add(eoa.getMenuText());
				}
	
				set(eventInsStmt, 19, Constants.format(a, 256));
				set(eventInsStmt, 20, Constants.format(b, 64));
			}
			else
			{
				set(eventInsStmt, 19, null);
				set(eventInsStmt, 20, null);
			}
			
			set(eventInsStmt, 21, m_event.hasNotifications()		// eventNotification
						? Constants.format(m_event.getNotifications(), 128)
						: null);
			set(eventInsStmt, 22, m_event.hasTroubleTicket()		// eventTroubleTicket
						? m_event.getTroubleTicket().getTicket()
						: null);
			set(eventInsStmt, 23, m_event.hasTroubleTicket() 
						//? (m_event.getTroubleTicket().getState() == EventTroubleTicket.STATE_ON ? "on" : "off")
						//: null);
						? (m_event.getTroubleTicket().getState() == EventTroubleTicket.STATE_ON ? 1 : 0)
						: -1);
			set(eventInsStmt, 24, m_event.hasForwards()
						? Forward.format(m_event.getForwards(), 256)
						: null);
			set(eventInsStmt, 25, m_event.getMouseOverText());
	
			// execute
			eventInsStmt.executeUpdate();
	
			Log.print(Log.INFORMATIONAL, "SUCCESSFULLY added " + m_event.getUEI() + " related  data into the EVENTS table");
		}
		catch(SQLException se)
		{
			Log.print(Log.WARNING, "SQL Exception while trying to add event");
			Log.print(Log.WARNING, se);
			Log.print(Log.WARNING, "Rethrowing exception to next level");
			throw se;
		}
		finally
		{
			try
			{
				if(eventInsStmt != null)
					eventInsStmt.close();
			}
			catch(Exception e) { }
		}
	}

	/**
	 * Constructs an EventWriter thread
	 *
	 * @param	eventBlock	the event to be 'persisted'
	 * @param	channel		JSDT channel to be used to send events out once they are added to the database
	 * @param	client		JSDT client ID for this thread
	 */
	public EventWriter(EventHeader header, Event event, Client client, Channel channel)
	{
		Log.print(Log.INFORMATIONAL, "EventWriter for : " + event.getUEI());
		m_header = header;
		m_event  = event;
		m_client = client;
		m_channel= channel;
	}

	/**
	 * The method that starts the processing for this object 
	 * 
	 * @param connection	the database connection to be used by this
	 *                      object to add data to the DB
	 */
	public void dbRun(Connection connection)
	{
		if(m_event != null)
		{
			//
			// set the database for rollback support
			//
			boolean acommit = false;
			try
			{
				acommit = connection.getAutoCommit();
				if(acommit)
					connection.setAutoCommit(false);
			}
			catch(SQLException se)
			{
				Log.print(Log.WARNING, "Unable to get/set auto commit mode");
				Log.print(Log.WARNING, se);
			}
			
			Log.print(Log.INFORMATIONAL, "EventWriter run for : " + m_event.getUEI());
			try
			{
				add(connection);
				connection.commit();
			}
			catch(Exception e)
			{
				Log.print(Log.WARNING, "Error inserting event into the datastore");
				Log.print(Log.WARNING, e);
				try
				{
					connection.rollback();
				}
				catch(Exception e2)
				{
					Log.print(Log.WARNING, "Rollback of transaction failed!");
					Log.print(Log.WARNING, e2);
				}
			}
			
			if(acommit)
			{
				try
				{
					connection.setAutoCommit(acommit);
				}
				catch(SQLException se)
				{
					Log.print(Log.WARNING, "Error resetting autocommit mode!");
					Log.print(Log.WARNING, se);
				}
			}
			
			Log.print(Log.INFORMATIONAL, "EventWriter finished for : " + m_event.getUEI());
		}
	}
	
	/**
	 * The run method is invoked to send the new serialized
	 * event to other listening applications using JSDT.
	 *
	 */
	public void run()
	{
		try
		{
			Log.print(Log.DEBUG, "Writing Event(" + m_event.getUEI() + ") to byte stream for broadcasting");
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			
			List l = new ArrayList(1);
			l.add(m_event);
			if(m_header != null)
				XMLEventsParser.serializeToXML(bos, m_header, l);
			else
				XMLEventsParser.serializeToXML(bos, l);
			
			Log.print(Log.SPILLGUTS, "Sending XML Stream:\n" + bos.toString());
			m_channel.sendToOthers(m_client, new Data(bos.toByteArray()));
			Log.print(Log.DEBUG, "Sent Event(" + m_event.getUEI() + ") using channel " + m_channel.getName()); 
		}
		catch (JSDTException jsdte)
		{
			Log.print(Log.WARNING, "EventWriter: error sending finished event");
			Log.print(Log.WARNING, jsdte);
		}
		catch (RuntimeException re)
		{
			Log.print(Log.ERROR, "EventWriter: caught runtime exception: " + re.getMessage());
			Log.print(Log.ERROR, re);
		}
	}		
	
	/**
	 * Return the event header used during serialzation to the database.
	 */
	public EventHeader getHeader()
	{
		return m_header;
	}
	
	/**
	 * Return the event serialzed to the database.
	 */
	public Event getEvent()
	{
		return m_event;
	}
}


package org.opennms.bb.dp.poller.plugins;

public class DPStatus
{
}

//
// Copyright (C) 2000 N*Manage Company Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
// Tab Size = 8
//
// $Id: Discovery.java,v 1.19 2000/11/09 23:30:22 mike Exp $
//

package org.opennms.bb.dp.discovery;

import java.io.*;
import java.net.*;
import java.util.*;

import com.sun.media.jsdt.*;

import org.opennms.protocols.ip.*;

import org.opennms.bb.common.components.*;
import org.opennms.bb.dp.common.components.*;
import org.opennms.bb.dp.discovery.components.*;
import org.opennms.bb.dp.discovery.utils.*;


/**
 * The main class for discovery
 *
 * @author <A HREF="mailto:sowmya@opennms.org">Sowmya</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 */
public class Discovery extends PollerThread
{
	/**
	 * <P>The calculated number of packets per second that discovery 
	 * can send when querying the network. Discovery should never send
	 * more than this number of packets in one second. This does not 
	 * restrict the size of the packets, but for discovery all the 
	 * packets should roughly be the same size.</P>
	 */
	private long 			m_lPktsPerSec;
	
	/**
	 * <P>The calcualted number of threads that maximize the use of
	 * the packets per second limitiation. This is the number of 
	 * threads that are sending ICMP request.</P>
	 */
	private long 			m_lNumThreads;

	/**
	 * <P>The IP Generator object is used to create IP addresses 
	 * and add those addresses to the passed queue. The generator
	 * is a cyclic object that uses its own thread to generate 
	 * the addresses.</P>
	 */
	private IPGenerator		m_ipGenerator;

	/**
	 * <P>The MonitorRequestReceiver object listens for ICMP 
	 * poll requests from the ICMP service monitor and adds those
	 * requests to the passed queue.</P>
	 */
	private MonitorRequestReceiver		m_monitorRequestReceiver;

	/**
	 * <P>The discovery thread manager. The manager is responsible
	 * for controlling numerous threads that constantly send ICMP
	 * request to remote addresses.</P>
	 *
	 * @see org.opennms.bb.dp.discovery.components.DiscPinger
	 */
	private DiscPingManager		m_pingManager;

	/**
	 * <P>The producer/cosumer queue that is the sink for the 
	 * IPGenerator and the source for the numerous discovery
	 * ping threads. This object is passed to the IPGenerator
	 * and the DiscPingManager objects.</P>
	 */
	private PCQueue 		m_pingRequestQ;

	/**
	 * <P>The producer/cosumer queue that is the sink for the 
	 * MonitorRequestReceiver and the source for the numerous monitor
	 * ping threads. This object is passed to the MonitorRequestReceiver
	 * and the DiscPingManager objects.</P>
	 */
	private PCQueue 		m_monitorRequestQ;

	/**
	 * The property name used to get max number of monitor
	 * pinger threads to use to service ICMP poll requests.
	 */
	private final String	PROP_MAX_MONITOR_POLL_THREADS = "org.opennms.bluebird.discovery.maxICMPMonitorPollThreads";

	/**
	 * <P>The maximum number of threads in the monitor thread pool which
	 * will be processing incoming ICMP poll requests from
	 * the ICMP service monitor.  This value is configurable
	 * through the discovery properties. Default value is 10.</P>
	 */
	private int 			m_maxNumMonitorThreads = 10;

	/**
	 * <P>The thread that recieves the confirmation from capsd that a node
	 * has been added to the database - once this confirmation is got,
	 * the node is acknowledged as 'known'.</P>
	 */
	private DiscCapsdReceiver	m_discCapsdReceiver;
		
	/**
	 * <P>The properties that are specific to the discovery process. The 
	 * properties are a combination of the JVM's system properties, plus
	 * the inclusion of the OpenNMS specific property files. There are two
	 * additional files that are loaded, if the system properties are 
	 * correctly set.</P>
	 *
	 * <P>In order to properly load the OpenNMS specific file(s) their
	 * location must be known in advance. Instead of hard coding the
	 * location of the files, the files are referenced by properties.
	 * The following list declares the properites that reference the 
	 * specific files. The property files are loaded in the order
	 * they appear in the list.</P>
	 *
	 * <UL>
	 *	<LI>org.opennms.bluebird.propertyFile</LI>
	 *	<LI>org.openmms.bluebird.discovery.propertyFile</LI>
	 * </UL>
	 *
	 * <P>Currently the string returned for the propertyFile(s) must
	 * be a file on the local filesystem. Later support for remote
	 * files via HTTP, JSDT, etc al may be supported.</P>
	 */
	private static Properties	m_properties = null;
	
	/**
	 * <P>Copy the System properties and then load the bluebird
	 * and discovery specific files into the property object.
	 * For more information see the javadoc comment for the m_properties
	 * element.</P>
	 *
	 * <P>Additionally, this static loading will also look at the debugging 
	 * options and will setup the Logging Facility. This can only be done
	 * after the properties have been loaded.</P>
	 */
	static
	{
		//
		// get a new properties element and make the 
		// system properties the backing map
		//
		m_properties     = new Properties(System.getProperties());

		//
		// try to load the bluebird specific properties
		//
		String file = m_properties.getProperty("org.opennms.bluebird.propertyFile");
		if(file != null)
		{
			FileInputStream pfile = null;
			try
			{
				pfile = new FileInputStream(file);
				m_properties.load(pfile);
				pfile.close();
				m_properties = new Properties(m_properties); // new property with loaded as backing map
			}
			catch(IOException e) 
			{
				// do nothing
			}
		}

		//
		// Load the discovery specific files now
		//
		file = m_properties.getProperty("org.opennms.bluebird.discovery.propertyFile");
		if(file != null)
		{
			FileInputStream pfile = null;
			try
			{
				pfile = new FileInputStream(file);
				m_properties.load(pfile);
				pfile.close();
			}
			catch(IOException e)
			{
				// do nothing
			}
		}
		// end static load of properties.

		//
		// setup the debug and log facility for discovery
		//
		Log.setLevel(0);
		String logLevel = m_properties.getProperty("org.opennms.bluebird.discovery.logLevel");
		if(logLevel != null)
		{
			try
			{
				Log.setLevel(Integer.parseInt(logLevel));
			}
			catch(NumberFormatException ne) { Log.setLevel(Log.WARNING); }
		}
		
		file = m_properties.getProperty("org.opennms.bluebird.discovery.logFile");
		if(file != null)
		{
			try
			{
				Log.setOut(file);
			}
			catch(IOException e)
			{
				Log.disable();
			}
		}

		// end Log class setup
		
	} // end static class initialization
	
	/**
	 * <P>This method is used by the class constructor to load the currently
	 * known IP Addresses from the database into the discovery VM. The addresses
	 * are stored in a synchronzied Set collection so multiple threads can
	 * use the set together without causing data corruption.</P>
	 *
	 * <P>If a non-fatal database error occurs, then an empty set is returned
	 * for use by the discovery process.</P>
	 *
	 * @return The Set of all known IP addresses.
	 *
	 * @exception java.lang.NullPointerException Thrown if one of the database
	 * 	parameters cannot be loaded.
	 * @exception java.lang.ClassNotFoundException Thrown if the database driver
	 * 	cannot be loaded by the JVM.
	 */
	private Set loadDatabaseNodes( )
		throws ClassNotFoundException
	{
		/**
		 * database stuff (to read known nodes)
		 */
		String dbDriver = m_properties.getProperty("org.opennms.bluebird.poller.database.driver");
		String dbUrl    = m_properties.getProperty("org.opennms.bluebird.poller.database.url");
		String dbUser   = m_properties.getProperty("org.opennms.bluebird.poller.database.user");
		String dbPasswd = m_properties.getProperty("org.opennms.bluebird.poller.database.passwd");
		
		if(dbDriver == null || dbUrl == null || dbUser == null || dbPasswd == null)
		{
			throw new NullPointerException("Error loading the database resource.\nOne or more resources missing");
		}
		
		/**
		 * Load 'known' nodes/interfaces from the database -
		 * do not quit if there is an exception
		 */
		Set knownNodes = null;
		try
		{
			//
			// Attempts to load the known nodes from the 
			// distributed poller database. Once the
			// set is got don't forget to synchronize it.
			//
			DiscKnownNodesRetriever knownNodesRetriever = new DiscKnownNodesRetriever(dbDriver, 
												  dbUrl, 
												  dbUser, 
												  dbPasswd);
			//
			// Now "synchronize" the set with the database!
			//
			knownNodes = knownNodesRetriever.syncSet();
		}
		catch (ClassNotFoundException cE)  
		{
			Log.print(Log.FATAL, cE);
			throw cE;
		}
		catch (java.sql.SQLException sqE) 
		{ 
			//
			// This isn't quite fatal since we can
			// still connect to the database.
			//
			Log.print(Log.WARNING, "Exception while reading database");
			Log.print(Log.WARNING, sqE);
			knownNodes = null;
		}

		if (knownNodes == null)
		{
			//
			// The synchronization with the database failed, so we need
			// a working set!
			//
			knownNodes = Collections.synchronizedSet(new HashSet());
		}
		else
		{
			Log.print(Log.INFORMATIONAL, "Known nodes read successfully from the DB: " + knownNodes.size());
		}
		
		return knownNodes;
	}

	/**
	 * <P>This method is used by the discovery constructor to determine
	 * what the maximum number of packets per second should be and the
	 * number of icmp sending threads. This is done in accordance with
	 * the method described in the OpenNMS polling documentation.</P>
	 *
	 * <P>Currently there is no JAVA method for getting the interfaces
	 * and their transmission rates. So for now the transmission rate
	 * has be hard coded at 10Mbs until a correct method is introduced.</P>
	 *
	 * @param fNetPercent	The maximum amount of the network interface's
	 *	bandwidth that may be used for discovery.
	 * @param lTimeout	The (default) timeout that will be used by 
	 *	discovery.
	 * @param iRetires	The (default) number of retries that will be
	 *	used when sending icmp packets.
	 *
	 */
	 private void  computeNetParameters(float fNetPercent, long lTimeout, int iRetries)
	 {
		long lNetSpeed = 1;
		long lPktSz    = 0;

		//
		// lNetSpeed = GetMaxInterfaceSpeed();
		//
		lNetSpeed = 10 * 1024 * 1024; // temporary hard-coded value

		//
		// log the discovered (calculated) network speed
		//
		Log.print(Log.DEBUG, "Discovery.computeNetParameters: Network speed computed to be " + lNetSpeed + "bps");

		/*
	 	 * Calculate the speed using send/receive packet size
	 	 * (sizeof (DiscPingPacket w/20 byte standard IPv4 header))
	 	 */
		lPktSz = DiscPingPacket.getNetworkSize() + 20/* ip header */ ;

		//
		// log the packets per second
		//
		Log.print(Log.DEBUG, "Discovery.computeNetParameters: The computed packet size is " + lPktSz + " bytes");

		/* 
		 * Calculate max packets per second  
		 */
		Float fPktsPerSec = new Float((lNetSpeed / (lPktSz * 16.0)) * (fNetPercent / 100.0));
		m_lPktsPerSec     = fPktsPerSec.longValue();
		if(m_lPktsPerSec == 0)
			++m_lPktsPerSec;

		//
		// Print out the packets per second to make sure it's 
		// working as designed.
		//
		Log.print(Log.DEBUG, "Discovery.computeNetParameters: The computed packets/sec is " + m_lPktsPerSec);

		/* 
		 * Calculate the number of threads 
		 */
		float sum = 0.0f;
		for(int x = iRetries+1; x > 0; x--)
			sum = sum + x * (lTimeout / 1000.0f);

		float avg = sum/iRetries;
		Float fThreads = new Float(avg * lNetSpeed * (fNetPercent / 100.0f) / (lPktSz * 16.0f));

		m_lNumThreads = fThreads.longValue();
		if(m_lNumThreads == 0)
			++m_lNumThreads;
	
		Log.print(Log.INFORMATIONAL, "Discovery.computeNetParameters: The number of computed icmpd senders is " + m_lNumThreads);
	}

	/**
	 * Instantiates the discovery process
	 *
	 * @exception java.lang.ClassNotFoundException	Thrown if an error occurs loading
	 *	the database driver for collecting the known nodes.
	 * @exception java.io.IOException	Thrown if an file I/O error occurs
	 *	loading and parsing the configuration files.
	 * @exception java.lang.RuntimeException	Thrown if an unexpected runtime
	 *	error occurs creating the discovery instance.
	 * @exception java.lang.NullPointerException	Thrown if an expected property
	 *	is null and the discovery initilization cannot recover.
	 */
	public Discovery() 
		throws ClassNotFoundException, IOException
	{
		//
		// if an exception occurs then this 
		// variable needs to be set.
		//
		boolean bException = false;
		

		//
		// get IP address and the hostname for
		// the local system
		//
		long address = 0;
		IPv4Address thisAddr = null;
		try
		{
			thisAddr = new IPv4Address(InetAddress.getLocalHost());
			address = thisAddr.getAddress();
			
			//
			// If the address is 128.0.0.0 or greater then
			// we will have to wrap it back into the correct
			// domain
			//
			if(address < 0)
				address += ((long)Integer.MAX_VALUE) + 1L;
		}
		catch(UnknownHostException ukE)
		{
			Log.print(Log.FATAL, "Error getting the address of the local host");
			Log.print(Log.FATAL, ukE);
			
			//
			// Recast the exception as a Runtime Error
			//
			throw new RuntimeException(ukE.getMessage());
		}
		
		//
		// print an informational message so
		// that we know the address conversion works!
		//
		Log.print(Log.DEBUG, "Local host is 0x" + Long.toHexString(address));

		//
		// Figure out where the XML configuration files live
		//
		String fileDir = m_properties.getProperty("org.opennms.bluebird.dp.xml.directory");
		if(fileDir == null)
		{
			Log.print(Log.FATAL, "Error finding configuration files repository");
			throw new NullPointerException("Error finding configuration files repository");
		}

		//
		// parser that gets the packages relevant to this poller
		//
		DiscPollersParser pollerParser = null;

		//
		// parse the relevant data stores
		//
		try
		{
			//
			// Get 'poller' info. from 'pollersXML'
			//
			pollerParser = new DiscPollersParser(address);
			pollerParser.parse(fileDir + "pollersXML.xml");
		}
		catch(IOException pollersE)
		{
			Log.print(Log.FATAL, "Unable to read poller information from pollersXML.xml");
			Log.print(Log.FATAL, pollersE);

			throw new RuntimeException(pollersE.getMessage());
		}
		
		List packages = pollerParser.getPackages();
		if (packages.size() == 0)
		{
			String s = "Unable to find any poller packages for poller \'" + thisAddr + "\' in pollersXML.xml";
			Log.print(Log.FATAL, s);
			throw new RuntimeException(s);
		}

		//
		// parser that gets the specifics/ranges etc. from the 
		// packages meant to be used by this parser
		//
		DiscIcebergParser icebergParser = null;

		//
		// parse the iceberg now using the packages from
		// the previous parser.
		//
		try
		{
			//
			// Get 'packages' info. from 'packages.XML'
			//
			icebergParser = new DiscIcebergParser(packages);
			icebergParser.parse(fileDir + "packages.xml");
		}
		catch(IOException iceE)
		{
			Log.print(Log.FATAL, "Unable to read package information from iceberg");
			Log.print(Log.FATAL, iceE);

			throw new RuntimeException("Unable to read package information from iceberg: " + iceE.getMessage());
		}

		//
		// Load the known nodes from the distributed poller database
		//
		Set knownNodes = loadDatabaseNodes();

		/*
		 * add the 'nodes to exclude' to the 'known' list so as
		 * to remove them from consideration
		 */
		Iterator iter   = icebergParser.getExcludeRanges().iterator();
		while(iter.hasNext())
		{
			IPAddressRange addrRange = (IPAddressRange)iter.next();
			Iterator eiter = addrRange.iterator();
			while(eiter.hasNext())
			{
				knownNodes.add(eiter.next());
			}
		}

		/*
		 * Get net/poll parameters
		 */
	 	computeNetParameters(pollerParser.getBandwidthLimit(),
				     icebergParser.getDefaultTimeout(),
				     (int)icebergParser.getDefaultRetries());


		/**
		 * Create the producer-consumer Q that will hold IP addresses
		 * to be pinged
		 */
		m_pingRequestQ = new PCQueueFixedArray((int)(m_lNumThreads * 1.5));

		//
		// Print the size of the request queue for debugging purposes
		//
		Log.print(Log.DEBUG, "Created ping requestQ of size: " + m_pingRequestQ.size());

		/**
		 * Create the producer-consumer Q that will hold ICMP poll requests
		 * from the ICMP service monitor.  Initial size of Q will be
		 * based on the max number of monitor threads configured in
		 * the discovery properties.
		 */
		 // Retrieve max monitor poll thread count property.
		String threadNum = getProperty(PROP_MAX_MONITOR_POLL_THREADS);
		if(threadNum != null)
		{
			try
			{
				m_maxNumMonitorThreads = Integer.parseInt(threadNum);
			}
			catch(NumberFormatException ne)
			{
				m_maxNumMonitorThreads = 10;
			}
		}
		m_monitorRequestQ = new PCQueueFixedArray((int)(m_maxNumMonitorThreads * 1.5));

		//
		//  the IPGenerator thread
		//
		m_ipGenerator = new IPGenerator(icebergParser.getIncludeRanges(),
						icebergParser.getSpecifics(),
						knownNodes,
						m_pingRequestQ);

		//
		//  the capsd receiver
		//
		m_discCapsdReceiver = new DiscCapsdReceiver(knownNodes);

		//
		// the ping manager thread
		//
		String icmpdPortStr = m_properties.getProperty("org.opennms.icmpd.port");
		int icmpdPort = -1;
		if(icmpdPortStr != null)
		{
			try 
			{
				icmpdPort = Integer.parseInt(icmpdPortStr);
			}
			catch(NumberFormatException e)
			{
				Log.print(Log.WARNING, "Property org.opennms.icmpd.port contains a malformed value: " + icmpdPortStr);
				Log.print(Log.INFORMATIONAL, e);
				icmpdPort = -1;
			}
		}
		
		//
		// try to connect to the discovery icmp daemon
		//
		//try
		//{
			m_pingManager= new DiscPingManager(icmpdPort, 
				  			   m_lNumThreads,
							   m_lPktsPerSec,
							   m_pingRequestQ,
							   m_maxNumMonitorThreads,
							   m_monitorRequestQ);
		//}
		//catch(IOException pingMgrE)
		//{
		//	Log.print(Log.FATAL, "Unable to create PING Manager");
		//	Log.print(Log.FATAL, pingMgrE);
		//	throw new RuntimeException("Unable to create PING manager: " + pingMgrE.getMessage());
		//}

		//
		//  the MonitorRequestReceiver thread
		//
		m_monitorRequestReceiver = new MonitorRequestReceiver(m_monitorRequestQ, m_pingManager);

	} // end of constructor

	/**
	 * Start all the threads
	 */
	public synchronized void start()
	{
		//
		// Tell the sub-threads to start
		// running before we start self
		// 
		m_ipGenerator.start();
		m_pingManager.start();
		try
		{
			m_monitorRequestReceiver.open(); //Create JSDT connection to ICMP service monitor 
		}
		catch (JSDTException e)
		{
			Log.print(Log.FATAL, "Unable to create JSDT session for communication with ICMP service monitor");
			Log.print(Log.FATAL, e);
			throw new RuntimeException("Unable to create JSDT session: " + e.getMessage());
		}
		super.start();
	}
	
	/**
	 * <P>Initiates the shutdown of the thread's
	 * run method in accordance with the base class'
	 * specification. Once the class is notified to
	 * terminate, the method waits for the thread to
	 * exit. If the calling thread equals the thread
	 * for the instance, then the join method will
	 * not be called.</P>
	 */
	public synchronized void shutdown()
	{
		try
		{
			super.shutdown();
			if(Thread.currentThread().equals(this) == false)
				join();
		}
		catch(Exception e) 
		{ 
			// do nothing
		}
	}

	/**
	 * Waits for control messages and takes appropriate action
	 */
	public void run()
	{
		setOpStatus(STATUS_NORMAL);

		for(;;)
		{
			synchronized(this)
			{
				for(;;)
				{
					int status = getOpStatus();
					if((status & STATUS_TERMINATING) == STATUS_TERMINATING)
					{
						//
						// Status is set to terminating, so terminate the
						// the sub-threads and then suicide.
						//
						try
						{
							shutdownThread(m_ipGenerator);
							shutdownThread(m_pingManager);
							m_discCapsdReceiver.close();
							m_pingRequestQ.close();
							m_monitorRequestReceiver.close();
							m_monitorRequestQ.close();
						}
						catch(InterruptedException e)
						{
							// do nothing							
						}

						setOpStatus(STATUS_SHUTDOWN);
						return;
					}
					else if((status & STATUS_PAUSING) == STATUS_PAUSING)
					{
						try
						{
							pauseThread(m_ipGenerator);
							pauseThread(m_pingManager);
							m_discCapsdReceiver.pause();
							m_monitorRequestReceiver.pause();
							setOpStatus(STATUS_PAUSED);
						}
						catch(InterruptedException e)
						{
							setOpStatus(STATUS_TERMINATING);
						}
					}
					else if((status & STATUS_RESUMING) == STATUS_RESUMING)
					{
						try
						{
							resumeThread(m_pingManager);
							resumeThread(m_ipGenerator);
							m_discCapsdReceiver.resume();
							m_monitorRequestReceiver.resume();
							setOpStatus(STATUS_NORMAL);
						}
						catch(InterruptedException e)
						{
							setOpStatus(STATUS_TERMINATING);
						}
					}
					else if((status & STATUS_PAUSED) == STATUS_PAUSED)
					{
						try
						{
							wait();
						}
						catch(InterruptedException e)
						{
							setOpStatus(STATUS_TERMINATING);
						}
					}
					else if((status & STATUS_NORMAL) == STATUS_NORMAL)
					{
						break; // exit status checking loop
					}
				} // end for(;;) status check
			} // end synchronization 
			

			try
			{
				//
				// SCM Code goes here!
				//
				Thread.sleep(5000);
			}
			catch(InterruptedException e)
			{
				setOpStatus(STATUS_TERMINATING);
			}
		}
	} // end run method!
	
	/**
	 * Returns the discovery specific properties.
	 */
	public static Properties getProperties()
	{
		return m_properties;
	}
	
	/**
	 * Returns the property identified by 'key' from the
	 * discovery specific properties.
	 */
	public static String getProperty(String key)
	{
		return m_properties.getProperty(key);
	}
	
	/**
	 * Start the discovery process
	 */
	public static void main(String[] args)
	{
		try
		{
			Discovery discover = new Discovery();
			discover.start();
		}
		catch(Exception e)
		{
			Log.print(Log.FATAL, e);
		}
	}
}

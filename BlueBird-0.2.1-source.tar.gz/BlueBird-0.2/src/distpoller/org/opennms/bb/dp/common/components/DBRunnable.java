//
// Copyright (C) 2000 N*Manage Company, Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
// $Id: DBRunnable.java,v 1.1 2000/09/12 17:10:02 weave Exp $
//
// Extra Log Info
// ------------------------------
// Weave 9/11/00
//	Moved the file from org.opennms.bb.common.components to
//	org.opennms.bb.dp.common.components.
//-------------------------------
//

package org.opennms.bb.dp.common.components;

import java.sql.Connection;

/**
 * <P>The DBRunnable interface is very similar in concept to
 * the interface java.lang.Runnable. The DBRunnable interface
 * provides a method that objects must implement and takes 
 * a single argument of type java.sql.Connection. The
 * connection can be used to communicate with the connected
 * database using any JDBC techniques.</P>
 *
 * @see java.lang.Runnable
 *
 * @author <A HREF="mailto:sowmya@opennms.org">Sowmya</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @Version $Revision: 1.1 $
 */
public interface DBRunnable 
{
	/**
	 * <P>The method to invoke on an implementing object
	 * when it is to be run with a specific database
	 * connection.</P>
	 *
	 * @param dbConnection	The connection to the JDBC database.
	 *
	 */
	public void dbRun(Connection dbConnection);
}

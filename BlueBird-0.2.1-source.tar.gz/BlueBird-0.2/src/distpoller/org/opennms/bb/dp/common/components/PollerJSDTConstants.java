//
// Copyright (C) 2000 N*Manage Company Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
// Tab Stop = 8
//
// $Id: PollerJSDTConstants.java,v 1.3 2000/11/09 14:38:34 sowmya Exp $
//
package org.opennms.bb.dp.common.components;

import java.lang.*;
import com.sun.media.jsdt.*;

/**
 * PollerJSDTConstants holds information pertaining to the JSDT sessions
 * between the poller processes(spmd, discovery, capsd)
 *
 * @author <A HREF="mailto:sowmya@opennms.org">Sowmya</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version $Revision: 1.3 $
 */
public final class PollerJSDTConstants
{
	/**
	 * <P>Defines the hostname of the JSDT server where
	 * the JSDT register is located.</P>
	 */
	public static final String	HOSTNAME    = "localhost";
	
	/**
	 * <P>Defines the type of communication channel and 
	 * which registry will be contacted for session and
	 * client creation.</P>
	 */
	public static final String	REGISTRY_TYPE = "socket";

	/**
	 * The Events session used by the event subcystem and discovery and
	 * capsd
	 */
	public static final String	EVENTS_SESSION_NAME	= "EventsSession";

	public static final String	DISCTOCAPSDCHANNELNAME	= "DiscToCapsdChannel";

	public static final String	CAPSDTODISCCHANNELNAME	= "CapsdToDiscChannel";

	public static final int 	EVENTS_SESSION_PORT   	= 5816;

	public static final String	EVENTS_SOURCE_CHANNEL	= "eventdRecvChannel";
	public static final String	EVENTS_SINK_CHANNEL	= "eventdSendChannel";

	public static void disconnect(Client client, Channel channel, Session session) 
	{
		try 
		{
			/* Leave the channel and leave the session. */
	    		channel.leave(client);
	    		session.leave(client);
		} 
		catch (Exception e) 
		{
	    		System.err.print("Caught exception while trying to ");
	    		System.err.println("leave the whiteboard channel and session: " + e);
		}

		/* Close the session */
		try 
		{
            		session.close(true);
        	} 
		catch (Exception e) 
		{
            		System.err.println("Caught exception while trying to " +
                                "close the session: " + e);
        	}
    	}
}

//
// Copyright (C) 2000 N*Manage Company Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
// Tab Size = 8
//
// $Id: CapsdWriteManager.java,v 1.15 2000/10/18 19:05:39 sowmya Exp $
//

package org.opennms.bb.dp.capsd.components;

import java.sql.*;
import java.util.*;
import java.io.*;

import com.sun.media.jsdt.*;

import org.opennms.bb.common.components.*;
import org.opennms.bb.dp.common.components.*;

import org.opennms.bb.dp.common.components.*;
import org.opennms.bb.dp.capsd.Capsd; //MAD

/**
 * <P>CapsdWriteManager reads CapsReader objects from the in input queue  
 * and uses a thread pool of 'DBRunnableConsumerThread's to write this
 * data to the database. The CapsdWriteManager converts the 
 * CapsReader objects into CapsWriter objects and enqueues the new
 * writer for execution by the DBRunnableConsumerThreads.</P>
 *
 * @author <A HREF="mailto:sowmya@opennms.org">Sowmya</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version $Revision: 1.15 $
 */
public final class CapsdWriteManager extends PollerThread
{
	/**
	 * <P>Queue to which CapsReader objects that have results of the
	 * SNMP, service queries are added by the CapsdReadManager.</P>
	 */
	private PCQueue	m_mgrInputQ;

	/**
	 * <P>Queue to which this adds CapsWriter objects which then run
	 * and all the data collected to the database.</P>
	 */
	private PCQueue	m_capsWriterQ;

	/**
	 * <P>The number of thread writers to start for 
	 * the manager.</P>
	 */
	private static final int	NUM_WRITERS = 10;
	
	/**
	 * <P>The list of DBRunnableConsumerThreads that
	 * are being managed by this instance.</P>
	 */
	private List			m_threads;

	/*
	 * JSDT communication related parameters
	 */
	/**
	 * <P>The client that is joined to the JSDT
	 * session.</P>
	 */
	private PollerClient 		m_client;
	
	/**
	 * <P>The JSDT Session that is used to communicate
	 * with the discovery system.</P>
	 */
	private Session			m_session;
	
	/**
	 * <P>The actual channel used to exchange
	 * messages between systems.</P>
	 */
	private Channel			m_channel;
	
	/**
	 * <P>The name of the JSDT client for all
	 * instances of this object. There should
	 * only ever be one instances since clients
	 * must be unique.</P>
	 */
	private static final String	JSDT_CLIENT_NAME = "CapsdSend";
	
	/**
	 * <P>The default constructor for the class is not 
	 * supported. This constructor will always throw
	 * and UnsupportedOperationException.</P>
	 *
	 * @exception java.lang.UnsupportedOperationException Always thrown
	 * 	from this method.
	 */
	private CapsdWriteManager( ) throws UnsupportedOperationException
	{
		throw new UnsupportedOperationException("default constructor not supported!");
	}

	/**
	 * <P>Constructs a new CapsdWriteManager object that maintains a 
	 * DBRunnableConsumerThread thread pool to handle the serilization
	 * of data to persistant storage (the database).</P>
	 *
	 * @param Q	The input queue where CapsReader objects are received.
	 *		These CapsReader objects contain results of the 
	 *		SNMP and services staus queries.
	 *
	 * @exception java.lang.NullPointerException Thrown when database 
	 *	related properites is not found.
	 * @exception com.sun.media.jsdt.JSDTException Thrown when the 
	 *	JSDT communication channel cannot be established.
	 * @exception java.sql.SQLException Thrown if there is an error
	 *	creating the connections to the database.
	 */
	public CapsdWriteManager(PCQueue Q) 
		throws JSDTException, SQLException
	{
		super();
		m_mgrInputQ = Q;

		Log.print(Log.INFORMATIONAL, "Inside CapsdWriteManager()...retrieving BlueBird properties");

		String driver = Capsd.getProperty(CapsdConstants.PROP_DB_DRIVER);
		if(driver == null)
			throw new NullPointerException("Missing resource " + CapsdConstants.PROP_DB_DRIVER);
			
		String url    = Capsd.getProperty(CapsdConstants.PROP_DB_URL);
		if(url == null)
			throw new NullPointerException("Missing resource " + CapsdConstants.PROP_DB_URL);

		String user   = Capsd.getProperty(CapsdConstants.PROP_DB_USER);
		if(user == null)
			throw new NullPointerException("Missing resource " + CapsdConstants.PROP_DB_USER);

		String passwd = Capsd.getProperty(CapsdConstants.PROP_DB_PASSWD);
		if(passwd == null)
			throw new NullPointerException("Missing resource " + CapsdConstants.PROP_DB_PASSWD);

		//
		// The manager to writer threads queue.
		//
		m_capsWriterQ = new PCQueueLinkedList();

		// 
		// Create the thread pool 
		//
		m_threads = new ArrayList(NUM_WRITERS);
		for (int iIndex=0; iIndex<NUM_WRITERS; iIndex++)
		{
			DBRunnableConsumerThread writerThread = null;
			try
			{
				writerThread = new DBRunnableConsumerThread(m_capsWriterQ, 
									    driver, 
									    url, 
									    user, 
									    passwd);
				m_threads.add(writerThread);
			}
			catch (SQLException sqlE)
			{
				Log.print(Log.FATAL, "An SQL error occured connecting to the database");
				Log.print(Log.FATAL, sqlE);
				
				m_threads.clear();
				m_threads = null;
				
				throw sqlE;
			}
			catch (ClassNotFoundException cnfE)
			{
				Log.print(Log.FATAL, "Error loading the JDBC driver");
				Log.print(Log.FATAL, cnfE);

				m_threads.clear();
				m_threads = null;
				
				throw new SQLException("Error loading JDBC driver class: " + cnfE.getMessage());
			}
		} // end for(...) to create all DBRunnableConsumerThreads
	}
	
	/**
	 * <P>Starts the thread pool, reads CapsReader objects from the
	 * m_mgrInputQ, constructs CapsWriter objects and adds them to the
	 * m_capsWriterQ. In short the run method is a transform thread
	 * that reads CapsReader objects from one queue and writes 
	 * CapsWriter objects to another. The thread pool started and managed
	 * by the object read from the manager's queue and process the 
	 * queues objects.</P>
	 */
	public void run()
	{
		//
		// Loop through and start thread pool. If any exception
		// occurs there is an UNWIND list that is used to shutdown
		// previously started threads.
		//
		{ // start of thread pool startup
			List unwinder = new ArrayList(m_threads.size());
			try
			{
				Iterator iter = m_threads.iterator();
				while(iter.hasNext())
				{
					DBRunnableConsumerThread thr = (DBRunnableConsumerThread)iter.next();
					thr.start();
					unwinder.add(thr);
				}
			}
			catch(Exception e)
			{
				Log.print(Log.ERROR, "Error starting up CapsdWriteManager thread pool");
				Log.print(Log.ERROR, e);
					
				//
				// Unwind the startup of the 
				// DBRunnableConsumerThread(s) if an error occurs.
				//
				Iterator iter = unwinder.iterator();
				while(iter.hasNext())
				{
					try
					{
						((DBRunnableConsumerThread)iter.next()).shutdown();
					}
					catch(Exception ie) { }
				}
				setOpStatus(STATUS_SHUTDOWN);
				return;
			}
		} // end of starting thread pool

		setOpStatus(STATUS_NORMAL);

		//
		// Loop Infinately until the thread is
		// shutdown
		//
		for(;;)
		{
			synchronized(this)
			{
				//
				// Loop here until the status is NORMAL.
				// if the status is anything other than
				// normal then the method will be stuck
				// in this infinite loop
				//
				for(;;)
				{
					int status = getOpStatus();
					if((status & STATUS_TERMINATING) == STATUS_TERMINATING)
					{
						//
						// close the queue
						//
						try
						{
							m_capsWriterQ.close();	// close the write queue
						}
						catch(Exception e)
						{
							//
							// Ignore the exception, but log them anyway
							//
							Log.print(Log.WARNING, "Error closing the CapsWriter queue");
							Log.print(Log.WARNING, e);
						}

						//
						// Thread should exit as soon as possible. They
						// may already be doing so thanks to the close queue
						//
						Iterator iter = m_threads.iterator();
						while(iter.hasNext())
						{
							try
							{
								((DBRunnableConsumerThread)iter.next()).shutdown();
							}
							catch(Exception e) 
							{
								Log.print(Log.ERROR, "Error shutting down DBRunnableConsumerThread");
								Log.print(Log.ERROR, e);
							}
						}
						
						//
						// Close the JSDT Session
						//
						try
						{
							m_session.close(false);
						}
						catch(Exception e) 
						{
							//
							// Ignore the exception, but log them anyway
							//
							Log.print(Log.ERROR, "Error closing the JSDT session");
							Log.print(Log.ERROR, e);
						}
						
						//
						// Set the status to shutdown and return
						// from the run method.
						//
						setOpStatus(STATUS_SHUTDOWN);
						return;
					}
					else if((status & STATUS_PAUSING) == STATUS_PAUSING)
					{
						Iterator iter = m_threads.iterator();
						while(iter.hasNext())
							((DBRunnableConsumerThread)iter.next()).pauseOperation();
						setOpStatus(STATUS_PAUSED);
					}
					else if((status & STATUS_RESUMING) == STATUS_RESUMING)
					{
						Iterator iter = m_threads.iterator();
						while(iter.hasNext())
							((DBRunnableConsumerThread)iter.next()).resumeOperation();
						setOpStatus(STATUS_NORMAL);

					}
					else if((status & STATUS_PAUSED) == STATUS_PAUSED)
					{
						try
						{
							wait();
						}
						catch(InterruptedException e)
						{
							Log.print(Log.ERROR, "The CapsdWriteManager run method interrupted while paused");
							Log.print(Log.ERROR, e);
							setOpStatus(STATUS_TERMINATING);
						}
					}
					else if((status & STATUS_NORMAL) == STATUS_NORMAL)
					{
						break; // exit status checking loop
					}
				} // end for(;;) status check
			} // end synchronization 


			// if the m_mgrInputQ is empty, register with the queue for
			// notification on add and wait for  signal from queue
			// or signal due to status change
			boolean waitForQueue = false;
			synchronized(m_mgrInputQ)
			{
				if(m_mgrInputQ.entries() == 0)
				{
					m_mgrInputQ.oneShotNotifyAllOnAdd(this);
                    			waitForQueue = true;
                		}
            		}

            		if(waitForQueue)
            		{
				synchronized(this)
				{
                			try
                			{
       						wait(); // queue or status change can signal
                			}
                			catch(InterruptedException ie)
                			{
                			}
				}

				// if status is not normal, continue and handle
				// status change
				int status = getOpStatus();
				if((status & STATUS_NORMAL) != STATUS_NORMAL)
					continue;
            		}

			//
			// read from Q and write the relevant data into the
			// database
			//
			CapsReader capsReader = null;
			try
			{
				capsReader = (CapsReader)m_mgrInputQ.read();
			}
			catch (InterruptedException intE) 
			{
				Log.print(Log.ERROR, "CapsdWriteManager: InterruptedException while reading from Q");
				Log.print(Log.ERROR, intE);

				setOpStatus(STATUS_TERMINATING);
				capsReader = null;
			}
			catch (QueueClosedException qcE)
			{
				Log.print(Log.ERROR, "CapsdWriteManager: QueueClosedException while reading from Q");
				Log.print(Log.ERROR, qcE);

				setOpStatus(STATUS_TERMINATING);
				capsReader = null;
			}

			try
			{
				if(capsReader != null)
					m_capsWriterQ.add(new CapsWriter(capsReader, m_channel, m_client));
			}
			catch(InterruptedException intE)
			{
				Log.print(Log.ERROR, "The CapsdWriter thread interrupted adding information to the db consumer thread queue");
				Log.print(Log.ERROR, intE);
				setOpStatus(STATUS_TERMINATING);
			}
			catch(QueueClosedException qcE)
			{
				Log.print(Log.ERROR, "The CapsdWriter DBRunnableConsumerThread queue is closed, unable to add CapsWriter objects");
				Log.print(Log.ERROR, qcE);
				setOpStatus(STATUS_TERMINATING);
			}
			
		} // end infinite status/queue read/queue write loop
	
	} // end of run method
	
	/**
	 * <P>Initiates the shutdown sequence and then
	 * waits for the thread's run method to exit. If the
	 * thread that calls shutdown is the same thread being
	 * terminated, then a join() will not occur to prevent
	 * a deadlock.</P>
	 */
	public void shutdown()
	{
		try
		{
			super.shutdown();
			if(Thread.currentThread().equals(this) == false)
				join();
		}
		catch(Exception e) 
		{ 
			// do nothing
		}
	}

	/**
	 * <P>Creates the poller JSDT client and channel to be used by the
	 * CapsWriter object to send confirmation to discovery once a
	 * node has been added to the database.</P>
	 *
	 * @exception JSDTException thrown when the JSDT communication 
	 *	channel cannot be established.
	 */
	public void connect( )  
		throws JSDTException
	{
		boolean sessionExists=false;

		//
		// Create the connection URL string to
		// communicate with the registry
		//
		URLString url = URLString.createSessionURL(PollerSession.hostName, 
							   PollerSession.discCapsdPort,
							   PollerSession.sessionType, 
							   PollerSession.discToCapsdSessionName);
		while (!sessionExists) 
		{
			try 
			{
				//
				// check to see if the session currently exists
				//
				sessionExists = SessionFactory.sessionExists(url);
			} 
			catch (ConnectionException ce) 
			{
				try
				{
					Thread.sleep(1000);
				}
				catch (InterruptedException iE2) 
				{
					Log.print(Log.WARNING, "JSDT Connection thread interrrupted");
					Log.print(Log.WARNING, iE2);
					
					throw new ConnectionException();
				}
			}
			catch (NoRegistryException nre) 
			{
				try
				{
					Thread.sleep(1000);
				}
				catch (InterruptedException iE1)
				{
					Log.print(Log.WARNING, "JSDT Connection thread interrupted");
					Log.print(Log.WARNING, iE1);
					
					throw new ConnectionException();
				}
			} 
		} 

		try
		{
			//
			// Try to initialize and create/join the session
			// so as to receive messages from the discovery system.
			//
			m_client  = new PollerClient(JSDT_CLIENT_NAME);
			m_session = SessionFactory.createSession(m_client, url, true);
			m_channel = m_session.createChannel(m_client, 
							    PollerSession.capsdToDiscChannelName,
							    true, 
							    false, 
							    true);
		}
		catch(JSDTException je)
		{
			//
			// Log the exception and try to clean up the
			// session. Then rethrow the exception
			//
			if(m_session != null)
			{
				try
				{
					m_session.close(false);
				}
				catch(Exception e)
				{
					Log.print(Log.WARNING, "Error closing session before rethrowing exception");
					Log.print(Log.WARNING, e);
				}
			}
			
			//
			// reset the JSDT parameters
			//
			m_session = null;
			m_channel = null;
			m_client  = null;
			
			//
			// rethrow the exception that started
			// this whole problem.
			//
			throw je;
		}
	} // end connect method
}

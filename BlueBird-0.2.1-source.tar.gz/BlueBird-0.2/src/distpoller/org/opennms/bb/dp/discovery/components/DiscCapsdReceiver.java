//
// Copyright (C) 2000 N*Manage Company Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
// Tab Size = 8
//
// $Id: DiscCapsdReceiver.java,v 1.9 2000/10/18 17:30:13 sowmya Exp $
//

package org.opennms.bb.dp.discovery.components;

import java.lang.*;
import java.util.*;
import java.io.*;

import com.sun.media.jsdt.*;
import org.apache.xerces.parsers.*;
import org.xml.sax.*;

import org.opennms.bb.dp.discovery.utils.*;
import org.opennms.bb.common.components.*;
import org.opennms.bb.dp.common.components.*;

/**
 * <P>DiscCapsdReceiver is the thread that handles JSDT communication 
 * from capsd. It adds the received IP addresses to the 'knownNodes'
 *
 * @author <A HREF="mailto:sowmya@opennms.org">Sowmya</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version $Revision: 1.9 $
 */
public final class DiscCapsdReceiver extends Object
{
	/**
	 * The set of known interfaces. Each interface is a String
	 * in IPv4 dotted decimal address format.
	 */
	private Set		m_knownNodes;
	
	/**
	 * The current status of either paused or normal. This
	 * is used to either accept or reject JSDT messages.
	 */
	private volatile boolean m_paused;

	/**
	 * The client class for the JSDT registry to 
	 * work correctly. This is actually a private
	 * derived class.
	 */
	private PollerClient 	m_client;
	
	/**
	 * The JSDT session on which messages are sent.
	 */
	private Session		m_session;
	
	/**
	 * The actual channel between the discovery
	 * process and the capabilities poller.
	 */
	private Channel		m_channel;
	
	/**
	 * The consumer that reads in the new addresses
	 * from the capabilities process.
	 */
	private DiscCapsdConsumer m_consumer;
	
	/**
	 * <P>The JSDT channel consumer that receives messages
	 * from the capabilities poller and other potential
	 * interfaces that discovery new interfaces. Only interfaces
	 * added to the database should be broadcast.</P>
	 *
	 * <P>The consumer adds each new received interface into the
	 * list of known nodes maintained by the discovery process.</P>
	 */
	private final class DiscCapsdConsumer extends PollerClient
		implements ChannelConsumer
	{	
		/** 
		 * <P>Xerces SAX parser used to parse the SOAP exchanges.</P>
		 */
		private SAXParser m_parser;		// reusable parser

		/**
		 * <P>SAX ContentHandler and ErrorHandler class. This actually
		 * processes the SAX events and stores the data.</P>
		 */
		private CapsdKnownAddressParser m_handler;	// reusable handler

		/**
		 * <P>The default constructor is used to assign a JSDT client
		 * name to this object. Once the client is named then the
		 * class can receive messages through the JSDT channels.</P>
		 *
		 * @param name	The name of the JSDT client.
		 */
		public DiscCapsdConsumer(String name)
		{
			super(name);
			m_parser = new SAXParser();
			m_handler= new CapsdKnownAddressParser();
			
			m_parser.setErrorHandler(m_handler);
			m_parser.setContentHandler(m_handler);
		}
		
		/**
		 * <P>The dataReceived method is defined in the
		 * JSDT ChannelConsumer interface. The method receives
		 * the actual address data from the Capsd subsystem
		 * and adds the address to the list of known nodes.</P>
		 *
		 * @param data The actual JSDT data object containing
		 * 	the address string.
		 */
		public synchronized void dataReceived(Data data)
		{
			if(m_paused)
				return;

			// Debug
			Log.print(Log.DEBUG, "SOAP message received from Capsd, inside dataReceived()...");
			//Log.print(Log.DEBUG, "SOAP content: " + data.getDataAsString());

			synchronized(m_knownNodes)
			{
				// add to the knownNodes
				ByteArrayInputStream istream = new ByteArrayInputStream(data.getDataAsBytes());
				try
				{
					Log.print(Log.DEBUG, "Parsing SOAP document...");
					m_parser.parse(new InputSource(istream));					
					List addrs = m_handler.getAddresses();
					if(addrs != null)
					{
						//
						// Add the address to knownNodes
						//
						Iterator iter = addrs.iterator();
						while(iter.hasNext())
						{
							String knownnode = new String(iter.next().toString());
							m_knownNodes.add(knownnode);
							Log.print(Log.INFORMATIONAL, "Data received from capsd: " + knownnode + "\n\n");
						}
					}
				}
				catch (Exception e)
				{
					Log.print(Log.ERROR, "Error adding the received data address to the knownNodes list");
					Log.print(Log.ERROR, e);
				}
			}
		}
	}
	
	/**
	 * Connect to the discovery-capsd JSDT channel.
	 *
	 * @param clientName 	The name of this client
	 *
	 * @throws java.lang.InterruptedException Thrown if the running
	 * 	thread is interrupted by another thread.
	 */
	private boolean jsdtConnect(String clientName) 
		throws InterruptedException
	{
		boolean sessionExists = false;
		boolean connected = false;

		try
		{

 			URLString url = URLString.createSessionURL(PollerSession.hostName, 
								   PollerSession.discCapsdPort,
								   PollerSession.sessionType, 
								   PollerSession.discToCapsdSessionName);

			while (!sessionExists) 
			{
				try 
				{
					if (SessionFactory.sessionExists(url)) 
					{
                            			sessionExists = true;
					}
				} 
				catch (NoRegistryException nre) 
				{
					Thread.sleep(1000);
				} 
				catch (ConnectionException ce) 
				{
					Thread.sleep(1000);
				}
			} 

			m_consumer = new DiscCapsdConsumer(clientName);
	        	m_client  = m_consumer;
			m_session = SessionFactory.createSession(m_client, url, true);
			m_channel = m_session.createChannel(m_client, 
							    PollerSession.capsdToDiscChannelName,
							    true, 
							    false, 
							    true);
			m_channel.addConsumer(m_client, m_consumer);
			connected = true;
		} 
		catch (JSDTException e)
		{
			Log.print(Log.FATAL, e.getMessage());
			connected = false;
		}

		return connected;
	}

	/**
	 * <P>Creates a new discovery capabilities bridge that
	 * receives new node notification from capsd. When a 
	 * notification is received it is parsed and then added
	 * to the list of known nodes.</P>
	 *
	 * @param knownNodes	The set containing the known interfaces.
	 *
	 */
	public DiscCapsdReceiver(Set knownNodes)
	{
		m_knownNodes = knownNodes;
		m_paused = false;

		Log.print(Log.INFORMATIONAL, "Trying to connect to JSDT registry...");

		//
		// Create communication path with discovery to get known nodes
		//
		try
		{
			if(!jsdtConnect("DiscRecv"))
			{
				Log.print(Log.FATAL, "Capsd: Unable to create JSDT communication with discovery");
				throw new RuntimeException("Unable to connect to JSDT Registry");
			}
		}
		catch(InterruptedException e)
		{
			throw new RuntimeException("The jsdt connection thread was interrupted");
		}

		Log.print(Log.INFORMATIONAL, "JSDT communication channel established");
	}
	
	/**
	 * <P>Resumes the receipt of messages from the JSDT
	 * channel.</P>
	 */
	public void resume()
	{
		m_paused = false;
	}
	
	/**
	 * <P>Pauses the recipt of messages from the
	 * JSDT channel. All messages will be discarded.</P>
	 */
	public void pause()
	{
		m_paused = true;
	}
	
	/**
	 * <P>Closes the connection to the JSDT
	 * session and channel.</P>
	 */
	public void close()
	{
		// close JSDT m_session
		try
		{
			m_channel.removeConsumer(m_client, m_consumer);
			m_session.close(false);
		}
		catch(JSDTException jsdtE) 
		{
			// do nothing
		}
	}
}

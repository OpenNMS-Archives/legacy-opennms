//
// Copyright (C) 2000 N*Manage Company Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
// Tab Size = 8
//
// $Id: PollResponseAddress.java,v 1.1 2000/11/03 16:20:48 mike Exp $

package org.opennms.bb.dp.poller.plugins;

import java.util.*;

/**
 * <P>A PollResponseAddress contains an IP Address and a poll status.
 * The address is stored in a dotted decimal format.  The status
 * indicates the result of the poll and should be one of two strings:
 * "available" or "unavailable".</P>
 *
 * @author <A HREF="mailto:mike@opennms.org">Mike</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version $Revision: 1.1 $
 */
public class PollResponseAddress extends Object
{
	/**
	 * Indicates poll response was positive for this address
	 */
	public static final String STATUS_AVAILABLE = "available";

	/**
	 * Indicates poll response was negative for this address
	 */
	public static final String STATUS_UNAVAILABLE = "unavailable";

	/**
	 * The dotted decimal IPv4 address on which the poll was performed.
	 */
	private String		m_address; // dotted IP m_address
	
	/**
	 * The status of the polled service.
	 */
	private String		m_status;

	/**
	 * <P>The default constructor is marked private and will
	 * always throw an UnsupportedOperationException. This is
	 * to prevent the use of the default constructor.</P>
	 *
	 * @exception java.lang.UnsupportedOperationException Always thrown.
	 */
	private PollResponseAddress() throws UnsupportedOperationException
	{
		throw new UnsupportedOperationException("Default constructor not implemented");
	}
	
	/**
	 * <P>Constructs a PollResponseAddress object with the specified
	 * parameters.</P>
	 *
	 * @param ipAddress	The Dotted Decimal IPv4 Address.
	 * @param status	The status of the polled service.
	 *
	 */
	public PollResponseAddress(String ipAddress, String status) 
	{
		m_address = ipAddress;
		m_status = status;
	}

	/**
	 * <P>Returns the status.</P>
	 */
	public String getStatus()
	{
		return m_status;
	}

	/**
	 * <P>Returns the current IPv4 address for this object
	 * in the dotted decimal format.</P>
	 */
	public String getAddress()
	{
		return m_address;
	}

	/**
	 * <P>Returns true if the passed object is equal to 
	 * self. The objects must be equal in address,
	 * and status.</P>
	 *
	 * @return True if the objects are logically equal. False
	 *	is returned otherwise.
	 */
	public boolean equals(PollResponseAddress pollAddr)
	{
		boolean bRet = true;

		if (pollAddr == null)
			bRet = false;

		else if (!pollAddr.getAddress().equals(m_address))
			bRet = false;
		
		else if (!pollAddr.getStatus().equals(m_status))
			bRet = false;

		return bRet;
	}
}

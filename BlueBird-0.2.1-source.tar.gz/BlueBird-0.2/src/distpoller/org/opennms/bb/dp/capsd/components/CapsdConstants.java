//
// Copyright (C) 2000 N*Manage Company Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
// Tab Stop = 8
//
// $Id: CapsdConstants.java,v 1.6 2000/10/18 17:30:13 sowmya Exp $
//

package org.opennms.bb.dp.capsd.components;

import java.lang.*;

/**
 * <P>This class is a repository for constant, static information
 * concerning the database. Currently it is only used to store
 * the property strings that map to database infomation or SQL
 * statements and the XML repository.</P>
 *
 * <P>NOTE: This class and its members are marked as package 
 * protected. This is by design, not by accident.</P>
 *
 * @author <A HREF="mailto:weave@opennms.org">Weave</A>
 * @author <A HREF="http://www.opennms.org">OpenNMS</A>
 *
 * @version $Revision: 1.6 $
 *
 */
final class CapsdConstants
{
	/**
	 * <P>The bluebird property string that defines this distributed
	 * poller's name</P>
	 */
	final static String	PROP_DP_NAME		= "org.opennms.bluebird.poller.name";

	/**
	 * <P>The bluebird property string that defines
	 * the driver used to connect to the JDBC database.</P>
	 */
	final static String	PROP_DB_DRIVER		= "org.opennms.bluebird.poller.database.driver";
	
	/**
	 * <P>The bluebird property that defines
	 * the connection URL for the JDBC database.</P>
	 */
	final static String	PROP_DB_URL		= "org.opennms.bluebird.poller.database.url";
	
	/**
	 * <P>The bluebird property that defines 
	 * the database user for the system.</P>
	 */
	final static String	PROP_DB_USER		= "org.opennms.bluebird.poller.database.user";
	
	/**
	 * <P>The bluebird property that defines
	 * the database user's password.</P>
	 */
	final static String	PROP_DB_PASSWD		= "org.opennms.bluebird.poller.database.passwd";
	
	/**
	 * <P>The property name that contains the sql statement
	 * that is used to get the next node id in the sequence.</P>
	 */
	final static String	PROP_DB_GET_NEXTNODEID	= "org.opennms.bluebird.capsd.database.getNextNodeID";
	
	/**
	 * <P>The property name that contains the insertion string used
	 * by capsd to store the initial node information into the
	 * database.</P>
	 */
	final static String	PROP_DB_INS_NODE	= "org.opennms.bluebird.capsd.database.insertNode";
	
	/**
	 * <P>The property name that contains the insertion string used
	 * by capsd to store the node's interface information into the
	 * database.</P>
	 */
	final static String	PROP_DB_INS_IPINTERFACE	= "org.opennms.bluebird.capsd.database.insertIpInterface";
	
	/**
	 * <P>The property name that contains the insertion string used
	 * by capsd to store the node's supported services into the
	 * database.</P>
	 */
	final static String	PROP_DB_INS_IFSERVICE	= "org.opennms.bluebird.capsd.database.insertIfService";
	
	/**
	 * <P>The property name that contains the insertion string used
	 * by capsd to store the node's SNMP informaiton on a per
	 * interface basis.</P>
	 */
	final static String	PROP_DB_INS_SNMP	= "org.opennms.bluebird.capsd.database.insertSnmpInterface";
	
	/**
	 * <P>The property name that constains the insertion string for
	 * adding new plugin services.</P>
	 */
	final static String	PROP_DB_INS_SERVICE	= "org.opennms.bluebird.capsd.database.insertService";
	
	/**
	 * <P>The property that returns a service id from the 
	 * services table given the name of a service.</P>
	 */
	final static String	PROP_DB_SVCIDFROMSVCNAME= "org.opennms.bluebird.capsd.database.serviceIdFromServiceName";
	
	/**
	 * <P>The property name that contains the sql statement
	 * that is used to get the next node id in the sequence.</P>
	 */
	final static String	PROP_DB_GET_NEXTSVCID	= "org.opennms.bluebird.capsd.database.getNextServiceID";
	
	/**
	 * <P>The XML repository for finding and loading XML files.</P>
	 */
	final static String	PROP_XML_REPOSITORY	= "org.opennms.bluebird.dp.xml.directory";
}


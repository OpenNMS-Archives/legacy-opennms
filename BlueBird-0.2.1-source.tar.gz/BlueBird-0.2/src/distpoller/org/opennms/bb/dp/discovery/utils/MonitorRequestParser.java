//
// Copyright (C) 2000 N*Manage Company Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
// Tab Size = 8
//
// $Id: MonitorRequestParser.java,v 1.1 2000/11/03 16:33:53 mike Exp $
//

package org.opennms.bb.dp.discovery.utils;

import java.lang.*;
import java.util.*;

import org.apache.xerces.parsers.*;
import org.xml.sax.*;
import org.xml.sax.helpers.*;

import org.opennms.protocols.ip.IPv4Address;
import org.opennms.bb.dp.discovery.components.IPPollAddress;

import org.opennms.bb.common.components.Log; // Debug purposes only

/**
 * <P>The MonitorRequestParser is designed to parse monitor requests
 * from the ICMP service monitor. The SOAP document that is exchanged 
 * can be decomposed into an ICMP poll request including (but not
 * limited to) IPv4 address, number of retries and timeout (milliseconds).</P>
 * 
 * <P>In order to use the class, first create an instance of an XML
 * parser using the Xerces <EM>SAXPaser</EM> class. Then set an 
 * instance of this class as the <EM>ErrorHandler</EM> and the
 * <EM>ContentHandler</EM>. After seting up the parser just call
 * the parse method. If the parser fails then the list of address
 * returned will be null.</P>
 *
 * @see org.apache.xerces.parsers.SAXParser
 * @see org.xml.sax.ContentHandler
 * @see org.xml.sax.ErrorHandler
 * @see org.xml.sax.helpers.DefaultHandler
 *
 */
public final class MonitorRequestParser 
	extends org.xml.sax.helpers.DefaultHandler
{
	/**
	 * <P>A list of IPPollAddress objects extracted from the document.</P>
	 */
	private List 		m_requests;	
	
	/**
	 * <P>Used to store name/value paris as they are extracted from
	 * the document.</P>
	 */
	private Properties m_parameters; 

	/**
	 * <P>A temporary string buffer to store character data
	 * when the m_isIPv4Addr is true.</P>
	 */
	private StringBuffer	m_addrBuf;	// temporary storage until endElement called

	/**
	 * <P>A temporary string buffer to store character data
	 * when the m_isParmName is true.</P>
	 */
	private StringBuffer	m_parmNameBuf;	// temporary storage until endElement called

	/**
	 * <P>A temporary string buffer to store character data
	 * when the m_isParmValue is true.</P>
	 */
	private StringBuffer	m_parmValueBuf;	// temporary storage until endElement called
	
	/**
	 * <P>Set to true if the SOAP envlope was processed successfully.</P>
	 */
	private boolean		m_isSoapCompliantEnv;
	
	/**
	 * <P>Set to true if the SOAP body tag was processed successfully</P>
	 */
	private boolean		m_isSoapCompliantBody;
	
	/**
	 * <P>Set to true if the corresponding tag was processed successfully.</P>
	 */
	private boolean    	m_isMonitorRequest;
	private boolean     m_isRequest;
	private boolean   	m_isIPv4Addr;
	private boolean 	m_isParms;
	private boolean		m_isParm;
	private boolean 	m_isParmName;
	private boolean  	m_isParmValue;

	/**
	 * <P>Set if a tag is in error. Each call to start element will
	 * increment the tag, if non-zero. Each call to end element will
	 * decrement the tag, if non-zero. This keeps tags from being 
	 * processed when an error occurs until the corresponding end
	 * tag is caught.</P>
	 */
	private int		m_error;

	/**
	 * <P>The SOAP Envelope tag</P>
	 */
	private final String SOAP_ENV		= "SOAP-ENV:Envelope";
	
	/**
	 * <P>The SOAP Body tag</P>
	 */
	private final String SOAP_BODY		= "SOAP-ENV:Body";
	
	/**
	 * <P>The SOAP envelope namespace that is required for
	 * SOAP conformance.</P>
	 */
	private final String SOAP_NS		= "http://schemas.xmlsoap.org/soap/envelope/";
	
	//
	// Relevant XML Tags
	//
	private final String MONITOR_REQUEST	= "Discovery:MonitorRequest";
	private final String REQUEST 			= "Discovery:request";
	private final String IPV4ADDR 			= "Discovery:ipv4Address";
	private final String PARMS				= "Discovery:parms";
	private final String PARM 				= "Discovery:parm";
	private final String PARMNAME 			= "Discovery:parmName";
	private final String PARMVALUE			= "Discovery:parmValue";
	
	
	/**
	 * <P>The BlueBird Discovery namespace uri.</P>
	 */
	private final String DISCOVERY_NS	= "http://dtds.opennms.org/bluebird/discovery/MonitorRequest/";
	
	/**
	 * </P>The class constructor creates a new instance of the
	 * MonitorRequestParser. The parser is used to decompose
	 * SOAP messages from the discovery system about addresses
	 * the discovery system found.</P>
	 *
	 */
	public MonitorRequestParser()
	{
		m_isSoapCompliantEnv = false;
		m_isSoapCompliantBody= false;
		m_requests	= null;
		m_isMonitorRequest 	= false;
		m_isRequest 	= false;
		m_isIPv4Addr    = false;
		m_addrBuf	= null;

		m_isParms = false;
		m_isParm = false;

		m_isParmName = false;
		m_parmNameBuf = null;

		m_isParmValue = false;
		m_parmValueBuf = null;

		m_parameters = new Properties();
		m_error		= 0;
	}
	
	/**
	 * <P>The startDocument method is called by the xerces
	 * parser when a new document is started. If the instance
	 * previously contained any data, then it is lost since
	 * the class is reset to its initial state. This allows
	 * for an instance to be reused to parse new document
	 * and avoid creating new instances.</P>
	 *
	 * @exception org.xml.sax.SAXException Thrown if an error
	 * 	occurs parsing the start of the document.
	 */
	public void startDocument()
		throws SAXException
	{
		m_isSoapCompliantEnv = false;
		m_isSoapCompliantBody= false;
		m_requests 	= new ArrayList();
		m_isMonitorRequest = false;
		m_isRequest 	= false;
		m_isIPv4Addr    = false;
		m_addrBuf	= new StringBuffer();
		m_isParms 		= false;
		m_isParm		= false;
		m_isParmName	= false;
		m_isParmValue	= false;
		m_parmNameBuf = new StringBuffer();
		m_parmValueBuf = new StringBuffer();
		m_error		= 0;
	}
	
	/**
	 * <P>Called to process the start of a new element for 
	 * the document. If namespaces are enabled, then the
	 * uri will be a valid namesapce. See the base class
	 * for more information.</P>
	 *
	 * @param uri		The XML namespace.
	 * @param localName	The local name with the namespace prefix.
	 * @param qName		The qualified name (includs namepace prefix).
	 * @param attributes	The attributes associated with the element.
	 *
	 * @exception org.xml.sax.SAXException	Thrown if a processing 
	 * 	error occurs.
	 */
	public void startElement(String		uri,
				 String		localName,
				 String		qName,
				 Attributes	attributes)
		throws SAXException
	{

		//
		// If an error has occurs, all levels will be
		// in error untl the corresponding endElement()
		// is called.
		//
		if(m_error != 0)
		{
			m_error++;
			return;
		}
			
		if(qName.equals(SOAP_ENV) && uri.equals(SOAP_NS))
		{
			m_isSoapCompliantEnv = true;
		}
		else if(m_isSoapCompliantEnv && qName.equals(SOAP_BODY) && uri.equals(SOAP_NS))
		{
			m_isSoapCompliantBody = true;
		}
		else if(m_isSoapCompliantBody && qName.equals(MONITOR_REQUEST) && uri.equals(DISCOVERY_NS))
		{
			m_isMonitorRequest = true;
		}
		else if(m_isMonitorRequest && qName.equals(REQUEST) && uri.equals(DISCOVERY_NS))
		{
			m_isRequest = true;
		}
		else if(m_isRequest && qName.equals(IPV4ADDR) && uri.equals(DISCOVERY_NS))
		{
			m_isIPv4Addr = true;
			if(m_addrBuf.length() > 0)
				m_addrBuf.delete(0, m_addrBuf.length()); // Clear buffer for next pass
		}
		else if(m_isRequest && qName.equals(PARMS) && uri.equals(DISCOVERY_NS))
		{
			m_isParms = true;
		}
		else if(m_isParms && qName.equals(PARM) && uri.equals(DISCOVERY_NS))
		{
			m_isParm = true;
		}
		else if(m_isParm && qName.equals(PARMNAME) && uri.equals(DISCOVERY_NS))
		{
			m_isParmName = true;
			if (m_parmNameBuf.length() > 0)
				m_parmNameBuf.delete(0, m_parmNameBuf.length()); // Clear buffer
		}
		else if(m_isParm && qName.equals(PARMVALUE) && uri.equals(DISCOVERY_NS))
		{
			m_isParmValue = true;
			if (m_parmValueBuf.length() > 0)
				m_parmValueBuf.delete(0, m_parmValueBuf.length()); // Clear buffer
		}
		else
		{
			//
			// Should a SAX Exception be thrown instead?
			//
			m_error = 1;
		}
	}
	
	/**
	 * <P>Called to process the end of an element for 
	 * the document. If namespaces are enabled, then the
	 * uri will be a valid namesapce. See the base class
	 * for more information.</P>
	 *
	 * @param uri		The XML namespace.
	 * @param localName	The local name with the namespace prefix.
	 * @param qName		The qualified name (includs namepace prefix).
	 *
	 * @exception org.xml.sax.SAXException	Thrown if a processing 
	 * 	error occurs.
	 */
	public void endElement(String uri,
			       String localName,
			       String qName)
		throws SAXException
	{

		if(m_error > 0)
		{
			--m_error;
		}
		
		if(m_isParmValue)
		{
			m_isParmValue = false;

			// 
			// We now have a complete name/value pair to store in m_parameters
			//
			if (m_parmNameBuf.length() > 0 && m_parmValueBuf.length() > 0)
				m_parameters.setProperty(m_parmNameBuf.toString().trim(), m_parmValueBuf.toString().trim());
		}
		else if(m_isParmName)
		{
			m_isParmName = false;
		}
		else if (m_isParm)
		{
			m_isParm = false;
		}
		else if(m_isParms)
		{
			m_isParms = false;
		}
		else if(m_isIPv4Addr)
		{
			m_isIPv4Addr = false;
		}
		else if (qName.equals(REQUEST))
		{	
			m_isRequest = false;

			// Process the request.
			// NOTE:  retry and timeout values are required
			//        If either are missing or invalid a request will not
			//        be added to the Q.
			String strRetry = m_parameters.getProperty("retry");
			String strTimeout = m_parameters.getProperty("timeout");
			if (strRetry != null && strTimeout != null)
			{
				int retry;
				int timeout;
				try	{ retry = Integer.parseInt(strRetry);	}
				catch(NumberFormatException ne) { retry = -1; }	
				try	{ timeout = Integer.parseInt(strTimeout);	}
				catch(NumberFormatException ne) { timeout = -1; }	

				if (retry > -1 && timeout > -1)
				{
					//
					// Create new IPPollAddress object and add it to request list
					//
					m_requests.add(new IPPollAddress(m_addrBuf.toString().trim(), timeout, retry));
					Log.print(Log.DEBUG, "MonitorRequestParser.endElement(): added request to Q - addr: " + 
									m_addrBuf.toString().trim() + " retry: " + retry + " timeout: " + timeout);
				}
			}
		}
		else if(qName.equals(MONITOR_REQUEST))
		{
			m_isMonitorRequest = false;
		}
		else if(qName.equals(SOAP_BODY))
		{
			m_isSoapCompliantBody = false;
		}
		else if(qName.equals(SOAP_ENV))
		{
			m_isSoapCompliantEnv = false;
		}
	}
	
	/**
	 * <P>This method is used to receive event notifiaction
	 * of character data. The character data is attached to the
	 * last tag that was processed by the startElement method.</P>
	 *
	 * <P>The character data in this method is ignored unless 
	 * an address tag is being processed. No validation is performed
	 * to ensure that non-data elements have no data.</P>
	 *
	 * @param data		The character data from the parser.
	 * @param offset	The offset in the data buffer that is valid.
	 * @param length	The length of valid data from the offset.
	 *
	 * @exception org.xml.sax.SAXException Thrown if a processing error
	 * 	occurs.
	 */
	public void characters(char[] data, int offset, int length)
		throws SAXException
	{
		if(m_isIPv4Addr)
			m_addrBuf.append(data, offset, length);
		else if (m_isParmName)
			m_parmNameBuf.append(data, offset, length);
		else if (m_isParmValue)
			m_parmValueBuf.append(data, offset, length);

	}
	
	/**
	 * <P>The warning handler is invoked by the parser when
	 * a recoverable error occurs parsing the document.</P>
	 *
	 * @param ex	The exception that occured.
	 *
	 * @exception org.xml.sax.SAXException Thrown if an error
	 * 	occurs processing the exception.
	 */
	public void warning(SAXParseException ex)
		throws SAXException
	{
		System.out.println("WARNING: " + ex.getMessage());
		ex.printStackTrace(System.out);
	}

	/**
	 * <P>The error handler is invoked by the parser when
	 * a recoverable error occurs parsing the document.</P>
	 *
	 * @param ex	The exception that occured.
	 *
	 * @exception org.xml.sax.SAXException Thrown if an error
	 * 	occurs processing the exception.
	 */
	public void error(SAXParseException ex)
		throws SAXException
	{
		System.out.println("ERROR: " + ex.getMessage());
		ex.printStackTrace(System.out);
	}

	/**
	 * <P>The fatal error handler is invoked by the parser when
	 * a non-recoverable error occurs parsing the document.</P>
	 *
	 * @param ex	The exception that occured.
	 *
	 * @exception org.xml.sax.SAXException Thrown if an error
	 * 	occurs processing the exception.
	 */
	public void fatalError(SAXParseException ex)
		throws SAXException
	{
		m_requests = null;
			
		System.out.println("FATAL: " + ex.getMessage());
		ex.printStackTrace(System.out);
	}
	
	/**
	 * <P>Returns the list of requests recovered by the parser.</P>
	 */
	public List getRequests()
	{
		return m_requests;
	}
	
	/**
	 * <P>A sample test program. Creates an instance of the parser
	 * and parses each file passed on the command line. Once the
	 * each file is parse, the address(es) in the file are printed
	 * to the commmand line.</P>
	 *
	 * <P>This is used solely for debugging and development testing.</P>
	 *
	 * @param args	The arguments to main.
	 *
	 */
	public static void main(String[] args)
	{
		MonitorRequestParser handler = new MonitorRequestParser();
		SAXParser parser = new SAXParser();
		
		parser.setContentHandler(handler);
		parser.setErrorHandler(handler);
		
		for(int i = 0; i < args.length; i++)
		{
			try
			{
				parser.parse(args[i]);
				List addrs = handler.getRequests();
				Iterator iter = addrs.iterator();
				while(iter.hasNext())
				{
					System.out.println("got address " + iter.next());
				}
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
			}
		}
	}
}			
		

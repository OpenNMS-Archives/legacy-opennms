//
// Copyright (C) 2000 N*Manage Company, Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
// $Id: IfTableEntry.java,v 1.9 2000/10/16 20:25:29 weave Exp $
//
//
package org.opennms.bb.dp.capsd.snmp;

import java.util.*;
import org.opennms.protocols.snmp.*;

import org.opennms.bb.common.components.Log; //Added temporarily for debugging purposes

/**
 * <P>This object contains a list of all the elements 
 * defined in the MIB-II interface table. An instance
 * object is initialized by calling the constructor and
 * passing in a variable list from an SNMP PDU. The
 * actual data can be recovered via the base class map
 * interface.</P>
 *
 * <P>Once an instance is created and its data set either
 * via the constructor or from the update method, the actual
 * elements can be retreived using the instance names. The 
 * names include: <EM>ifIndex</EM>, <EM>ifDescr</EM>, 
 * <EM>ifSpeed</EM>, <EM>etc al</EM>. The information can
 * also be accessed by using the complete object identifer
 * for the entry.</P>
 *
 * <P>For more information on the individual fields, and
 * to find out their respective object identifiers see
 * RFC1213 from the IETF.</P>
 *
 * @author <A HREF="mailto:sowmya@opennms.org">Sowmya</A>
 * @author <A HREF="mailto:weave@opennms.org">Weave</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version $Revision: 1.9 $
 *
 * @see <A HREF="http://www.ietf.org/rfc/rfc1213.txt">RFC1213</A>
 */
public final class IfTableEntry 
	extends java.util.TreeMap
{
	/**
	 * <P>The keys that will be supported by default from the 
	 * TreeMap base class. Each of the elements in the list
	 * are an instance of the SNMP Interface table. Objects
	 * in this list should be used by multiple instances of
	 * this class.</P>
	 */
	private static NamedSnmpVar[]	ms_elemList = null;
	
	/**
	 * <P>Initialize the element list for the class. This
	 * is class wide data, but will be used by each instance.</P>
	 */
	static
	{
		ms_elemList = new NamedSnmpVar[22];
		int ndx = 0;
		
		ms_elemList[ndx++] = new NamedSnmpVar(NamedSnmpVar.SNMPINT32, 		"ifIndex", 		".1.3.6.1.2.1.2.2.1.1",  1);
		ms_elemList[ndx++] = new NamedSnmpVar(NamedSnmpVar.SNMPOCTETSTRING, 	"ifDescr", 		".1.3.6.1.2.1.2.2.1.2",  2);
		ms_elemList[ndx++] = new NamedSnmpVar(NamedSnmpVar.SNMPINT32, 		"ifType", 		".1.3.6.1.2.1.2.2.1.3",  3);
		ms_elemList[ndx++] = new NamedSnmpVar(NamedSnmpVar.SNMPINT32, 		"ifMtu", 		".1.3.6.1.2.1.2.2.1.4",  4);
		ms_elemList[ndx++] = new NamedSnmpVar(NamedSnmpVar.SNMPGAUGE32,		"ifSpeed", 		".1.3.6.1.2.1.2.2.1.5",  5);
		ms_elemList[ndx++] = new NamedSnmpVar(NamedSnmpVar.SNMPOCTETSTRING,	"ifPhysAddr",		".1.3.6.1.2.1.2.2.1.6",  6);
		ms_elemList[ndx++] = new NamedSnmpVar(NamedSnmpVar.SNMPINT32, 		"ifAdminStatus",	".1.3.6.1.2.1.2.2.1.7",  7);
		ms_elemList[ndx++] = new NamedSnmpVar(NamedSnmpVar.SNMPINT32, 		"ifOperStatus", 	".1.3.6.1.2.1.2.2.1.8",  8);
		ms_elemList[ndx++] = new NamedSnmpVar(NamedSnmpVar.SNMPTIMETICKS, 	"ifLastChange", 	".1.3.6.1.2.1.2.2.1.9",  9);
		ms_elemList[ndx++] = new NamedSnmpVar(NamedSnmpVar.SNMPCOUNTER32, 	"ifInOctets",		".1.3.6.1.2.1.2.2.1.10", 10);
		ms_elemList[ndx++] = new NamedSnmpVar(NamedSnmpVar.SNMPCOUNTER32,	"ifInUcastPkts",	".1.3.6.1.2.1.2.2.1.11", 11);
		ms_elemList[ndx++] = new NamedSnmpVar(NamedSnmpVar.SNMPCOUNTER32,	"ifInNUcastPkts", 	".1.3.6.1.2.1.2.2.1.12", 12);
		ms_elemList[ndx++] = new NamedSnmpVar(NamedSnmpVar.SNMPCOUNTER32,	"IfInDiscards", 	".1.3.6.1.2.1.2.2.1.13", 13);
		ms_elemList[ndx++] = new NamedSnmpVar(NamedSnmpVar.SNMPCOUNTER32,	"ifInErrors", 		".1.3.6.1.2.1.2.2.1.14", 14);
		ms_elemList[ndx++] = new NamedSnmpVar(NamedSnmpVar.SNMPCOUNTER32,	"ifInUnknownProtos",	".1.3.6.1.2.1.2.2.1.15", 15);
		ms_elemList[ndx++] = new NamedSnmpVar(NamedSnmpVar.SNMPCOUNTER32,	"ifOutOctets", 		".1.3.6.1.2.1.2.2.1.16", 16);
		ms_elemList[ndx++] = new NamedSnmpVar(NamedSnmpVar.SNMPCOUNTER32,	"ifOutUcastPkts", 	".1.3.6.1.2.1.2.2.1.17", 17);
		ms_elemList[ndx++] = new NamedSnmpVar(NamedSnmpVar.SNMPCOUNTER32,	"ifOutNUcastPkts", 	".1.3.6.1.2.1.2.2.1.18", 18);
		ms_elemList[ndx++] = new NamedSnmpVar(NamedSnmpVar.SNMPCOUNTER32,	"ifOutDiscards",	".1.3.6.1.2.1.2.2.1.19", 19);
		ms_elemList[ndx++] = new NamedSnmpVar(NamedSnmpVar.SNMPCOUNTER32,	"ifOutErrors", 		".1.3.6.1.2.1.2.2.1.20", 20);
		ms_elemList[ndx++] = new NamedSnmpVar(NamedSnmpVar.SNMPGAUGE32,		"ifOutQLen", 		".1.3.6.1.2.1.2.2.1.21", 21);
		ms_elemList[ndx++] = new NamedSnmpVar(NamedSnmpVar.SNMPOBJECTID,	"ifSpecific",	 	".1.3.6.1.2.1.2.2.1.22", 22);
	}

	/**
	 * <P>The TABLE_OID is the object identifier that represents
	 * the root of the interface table in the MIB forest.</P>
	 */
	public static final String	TABLE_OID	= ".1.3.6.1.2.1.2.2.1";	// start of table (GETNEXT)
	
	/**
	 * <P>The SnmpObjectId that represents the root of the 
	 * interface tree. It is created when the class is 
	 * initialized and contains the value of TABLE_OID.
	 *
	 * @see #TABLE_OID
	 */
	public static final SnmpObjectId ROOT = new SnmpObjectId(TABLE_OID);

	/**
	 * <P>Creates a default instance of the interface
	 * table entry map. The map represents a singular
	 * instance of the interface table. Each column in
	 * the table for the loaded instance may be retreived
	 * either through its name or object identifier.</P>
	 *
	 * <P>The initial table is constructied with zero
	 * elements in the map.</P>
	 */
	public IfTableEntry()
	{
		super();
	}
	
	/**
	 * <P>The class constructor used to initialize the 
	 * object to its initial state. Although the
	 * object's attributes and data can be changed after
	 * its created, this constructor will initialize
	 * all the variables as per their named varbind
	 * in the passed array. This array should have been
	 * collected from an SnmpPduRequest that was received
	 * from a remote host.</P>
	 *
	 * @param vars	The array of variable bindings.
	 *
	 */
	public IfTableEntry(SnmpVarBind[] vars)
	{
		//
		// Initialize the map
		//
		this();
		update(vars);
	}
	
	/**
	 * <P>This method is used to update the map
	 * with the current information from the agent.
	 * The array of variables should be all the
	 * elements in the interfaces row.</P>
	 *
	 * </P>This does not clear out any column in the
	 * actual ifEntry row that does not have a definition.</P>
	 *
	 * @param vars	The variables in the interface row.
	 *
	 */
	public void update(SnmpVarBind[] vars)
	{
		//
		// iterate through the variable bindings
		// and set the members appropiately.
		//
		// Note: the creation of the snmp object id
		// is in the outer loop to limit the times a
		// new object is created.
		//
		for(int x = 0; x < ms_elemList.length; x++)
		{
			SnmpObjectId id = new SnmpObjectId(ms_elemList[x].getOid());
			for(int y = 0; y < vars.length; y++)
			{
				if(id.isRootOf(vars[y].getName()))
				{
					try 
					{
						//
						// Retrieve the class object of the expected SNMP data type for this element
						//
						Class classObj = ms_elemList[x].getTypeClass();
						
						//
						// If the SnmpSyntax object matches the expected class 
						// then store it in the map. Else, store a null pointer
						// in the map.
						//
						if (classObj.isInstance(vars[y].getValue()))
						{
							Log.print(Log.DEBUG, "IfTableEntry.update(): Types match!  SNMP Alias: " 
									   +  ms_elemList[x].getAlias() + "  Vars[y]: " + vars[y].toString());
							put(ms_elemList[x].getAlias(), vars[y].getValue());
							put(ms_elemList[x].getOid(), vars[y].getValue());
						}
						else
						{
							put(ms_elemList[x].getAlias(), null);
							put(ms_elemList[x].getOid(), null);
							Log.print(Log.DEBUG, "IfTableEntry.update(): object type '" + classObj.getName() 
									   + "' does NOT match expected type '" + ms_elemList[x].getType() + "'");
						}
					}
					catch (ClassNotFoundException e)
					{
						Log.print(Log.ERROR, "IfTableEntry.update(): Failed retrieving SNMP type class for element: " 
								   + ms_elemList[x].getAlias());
						Log.print(Log.ERROR, e);
					}
					catch (NullPointerException e)
					{
						Log.print(Log.ERROR, e);
					}
					break;
				}
			}	
		}
	}

	/**
	 * <P>This method is used to get a generic SNMP GETNEXT PDU that
	 * constains one varbind per member element. The PDU can then be
	 * used to perform an <EM>SNMP walk</EM> of the MIB-II interface
	 * table a remote host.</P>
	 *
	 * @return An SnmpPduRequest with the command of GETNEXT and
	 * 	one varbind for each member variable.
	 */
	public static SnmpPduRequest getNextPdu( )
	{
		SnmpPduRequest pdu = new SnmpPduRequest(SnmpPduRequest.GETNEXT);
		for(int x = 0; x < ms_elemList.length; x++)
		{
			SnmpObjectId   oid = new SnmpObjectId(ms_elemList[x].getOid());
			pdu.addVarBind(new SnmpVarBind(oid));
		}
		return pdu;
	}
}


//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.dp.poller.plugins;

import java.util.zip.*;
import java.io.*;
import java.util.*;

import org.opennms.bb.dp.poller.plugins.PollerTask;

/**This class is responsible for loading plugin classes from 
 * jar files.
 *
 * @author <A HREF="mailto:jason@opennms.org">Jason Johns</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version $Revision: 1.2 $
 * 
 */
public class JARClassLoader extends ClassLoader
{
	/**A jar file read from disk
	*/
	private JAR m_jar; //Binks!
	
	/**Used to open a jar file and load it
	*/
	private ZipFile m_zipFile;
	
	/**Constructor, loads any classes from a jar file on the
	   filesystem.
	   @param String path, the path of the jar file to open
	*/
	public JARClassLoader(String path)
		throws IOException
	{
		m_zipFile = new ZipFile(path);
		m_jar = new JAR(path, this);
		
		Enumeration entires = m_zipFile.entries();
		
		while(entires.hasMoreElements())
		{
			ZipEntry entry = (ZipEntry)entires.nextElement();
			String name = entry.getName();
			if(name.toLowerCase().endsWith(".props"))
			{
				System.out.println(name);
				//jEdit.loadProps(m_zipFile.getInputStream(entry));
			}
			else if(name.toLowerCase().endsWith(".class"))
			{
				
				if(name.endsWith("Plugin.class"))
				{
					loadPluginClass(name, m_jar);
					//pluginClasses.addElement(name);
				}
			}
		}
	}
	
	/**Adapted from the JARClassLoader.java source from the jEdit project.
	 * 
	 * Converts a file name to a class name. All slash characters are
	 * replaced with periods and the trailing '.class' is removed.
	 * @param name The file name
	 * @author <A HREF="sp@gjt.org">Slava Pestov
	 */
	public static String fileToClass(String name)
	{
		char[] clsName = name.toCharArray();
		for(int i = clsName.length - 6; i >= 0; i--)
			if(clsName[i] == '/')
				clsName[i] = '.';
		return new String(clsName,0,clsName.length - 6);
	}
	
	/**This method returns the jar file that was created 
	   @return JAR, a newly constructed jar file
	*/
	public JAR getJar()
	{
		return m_jar;
	}
	
	/**Adapted from the JARClassLoader.java source from the jEdit project.
	* @author <A HREF="sp@gjt.org">Slava Pestov
	*/
	private Class loadClassFromZip(String fileName, boolean resolveIt)
		throws ClassNotFoundException
	{
		//see if the class is already loaded
		Class cls = findLoadedClass(fileName);
		if(cls != null)
		{
			if(resolveIt)
				resolveClass(cls);
			return cls;
		}

		try
		{
			ZipEntry entry = m_zipFile.getEntry(fileName);

			if(entry == null)
			{
				return null;
			}

			InputStream in = m_zipFile.getInputStream(entry);

			int len = (int)entry.getSize();
			byte[] data = new byte[len];
			int success = 0;
			int offset = 0;
			while(success < len)
			{
				len -= success;
				offset += success;
				success = in.read(data,offset,len);
				if(success == -1)
				{
					//Log.log(Log.ERROR,this,"Failed to load class "
					//	+ className + " from " + m_zipFile.getName());
					throw new ClassNotFoundException(fileName);
				}
			}

			cls = defineClass(fileToClass(fileName),data,0,data.length);

			if(resolveIt)
				resolveClass(cls);

			return cls;
		}
		catch(IOException io)
		{
			//Log.log(Log.ERROR,this,io);

			throw new ClassNotFoundException(fileName);
		}
	}
	
	/**This method gets a newly constructed class from the jar file
	   and creates a new instance of it and loads it into a JAR file
	   object.
	   @param String aClassName, the name of the class in the jar file
	   @param JAR aJar, the JAR object to add the class instance to
	*/
	private void loadPluginClass(String aClassName, JAR aJar)
	{
		try
		{
			Class pluginClass = loadClassFromZip(aClassName, true);
		
			aJar.addPlugin((PollerTask)pluginClass.newInstance());
		}
		catch (ClassNotFoundException e)
		{
			System.out.println(e);
			e.printStackTrace();
		}
		catch(InstantiationException e)
		{
			System.out.println(e);
			e.printStackTrace();
		}
		catch (IllegalAccessException e)
		{
			System.out.println(e);
			e.printStackTrace();
		}
	}
	
	/**Adapted from the JARClassLoader.java source from the jEdit project.
	 *
	 * A Jar file where a plugin and all associated files
	   live.
	 *
	 * @author <A HREF="sp@gjt.org">Slava Pestov
	 */
	public static class JAR
	{
		// package-private members
		private int index;
	    	private String path;
		private Vector plugins;
		private ClassLoader loader;

		public JAR(String aPath, ClassLoader aLoader)
		{
			path = aPath;
			loader = aLoader;
			plugins = new Vector();
		}
		
		/**
		*/
		public String getPath()
		{
			return path;
		}

		/**
		*/
		public void addPlugin(PollerTask plugin)
		{
			plugins.addElement(plugin);
		}

		public PollerTask getPlugin()
		{
			return (PollerTask)plugins.get(0);
		}
		
		/**
		*/
		public PollerTask[] getPlugins()
		{
			PollerTask[] array = new PollerTask[plugins.size()];
			plugins.copyInto(array);
			return array;
		}

		/**
		*/
		public int getIndex()
		{
			return index;
		}

		/**
		*/
		public void getPlugins(Vector vector)
		{
			for(int i = 0; i < plugins.size(); i++)
			{
				vector.addElement(plugins.elementAt(i));
			}
		}
	}
}

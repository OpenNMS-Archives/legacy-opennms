//
// Copyright (C) 2000 N*Manage Company Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
// Tab Size = 8
//
// $Id: ServiceMonitorTester.java,v 1.4 2000/11/10 01:51:14 mike Exp $
//

package org.opennms.bb.dp.poller.plugins;

import java.io.*;
import java.net.*;
import java.util.*;

import org.opennms.protocols.icmpd.*;
import org.opennms.protocols.icmp.*;
import org.opennms.protocols.ip.*;

import org.opennms.bb.common.components.*;
import org.opennms.bb.dp.common.components.*;
import org.opennms.bb.dp.discovery.components.*;
import org.opennms.bb.dp.discovery.utils.*;


/**
 * Class which allows us to test the service monitors against ip addresses
 * entered by a user.
 *
 * @author <A HREF="mailto:mike@opennms.org">Mike</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 */
public class ServiceMonitorTester
{

	public class ICMPRequestGenerator extends Thread
	{
		ServiceMonitorICMP m_monICMP;
		Properties m_propICMP;
		NetworkInterface m_iface;

		public ICMPRequestGenerator(Properties propICMP, NetworkInterface iface)
		{
			m_monICMP = new ServiceMonitorICMP();;
			m_propICMP = propICMP;
			m_iface = iface;
		}

		public void run() 
		{
			try 
			{
				m_monICMP.initialize(null, null);
				int status = m_monICMP.poll(m_iface, null, m_propICMP);
				Log.print(Log.INFORMATIONAL,
					"ICMP service: " + (status==m_monICMP.SERVICE_AVAILABLE ? "Available" : "Unavailable") + "\n");
				m_monICMP.release();
			}
			catch (Exception e)
			{
				Log.print(Log.DEBUG, "ICMPRequestGenerator.run: exception: " + e);
			}
		}
	}

	public ServiceMonitorTester()
	{
	}

	public void start()
	{
		InetAddress inetAddr = null;
		Log.setLevel(Log.DEBUG);

		// Intro 
		System.out.print("\nService poller test utility.\n");
		System.out.print("Enter an IP address or hostname at the prompt or the\n");
		System.out.print("letter 'q' to quit.  The IP address entered will be polled\n");
		System.out.print("to determine the available services (FTP, DNS, SMTP, HTTP, ICMP).\n\n");
		System.out.flush();

		// Set up ICMP monitor properties
		Properties propICMP = new Properties();
		propICMP.setProperty("retry", "1");
		propICMP.setProperty("timeout", "2s");

		// Set up SMTP monitor properties
		Properties propSMTP = new Properties();
		propSMTP.setProperty("retry", "1");
		propSMTP.setProperty("port", "25");
		propSMTP.setProperty("timeout", "2s");

		// Set up FTP monitor properties
		Properties propFTP = new Properties();
		propFTP.setProperty("retry", "2");
		propFTP.setProperty("port", "21");
		propFTP.setProperty("timeout", "2s");

		// Set up HTTP monitor properties
		Properties propHTTP = new Properties();
		propHTTP.setProperty("retry", "2");
		propHTTP.setProperty("port", "80");
		propHTTP.setProperty("timeout", "2s");
		//propHTTP.setProperty("alternate port", "8080");
		propHTTP.setProperty("url", "/");
		propHTTP.setProperty("response", "200");
		//propHTTP.setProperty("response text", "Revolution");

		// Set up DNS monitor properties
		Properties propDNS = new Properties();
		propDNS.setProperty("retry", "0");
		propDNS.setProperty("port", "53");
		propDNS.setProperty("timeout", "4s");

		// Service monitor construction
		//ServiceMonitorICMP monICMP = new ServiceMonitorICMP();
		ServiceMonitorSMTP monSMTP = new ServiceMonitorSMTP();
		ServiceMonitorFTP monFTP = new ServiceMonitorFTP();
		ServiceMonitorHTTP monHTTP = new ServiceMonitorHTTP();
		ServiceMonitorDNS monDNS = new ServiceMonitorDNS();

		// Main Loop
		for(;;)
		{
			InputStreamReader is = new InputStreamReader( System.in);
			BufferedReader br = new BufferedReader(is);
			StringTokenizer st;

			try 
			{
				System.out.print("Enter IP address/hostname to poll: ");
				System.out.flush();
				
				String addr = br.readLine();
			
				//	
				// Quit
				//
				if (addr.equals("Q") || addr.equals("q"))
				{
					System.out.print("Goodbye...");
					return;
				}

				//
				// Modify properties
				//	
				if (addr.startsWith("prop"))
				{
					StringTokenizer t = new StringTokenizer(addr);
					t.nextToken();
					t.nextToken();
					String parm = t.nextToken();
					
					if (parm.startsWith("\""))
					{
						do
						{
							parm = parm.concat(" ");
							parm = parm.concat(t.nextToken());
							System.out.println("Concatenated next token: " + parm);
						} while (!parm.endsWith("\""));

						// Remove quotes from beginning and end of parameter
						StringBuffer parmbuf = new StringBuffer(parm);
						parmbuf.deleteCharAt(0);
						parmbuf.deleteCharAt(parmbuf.length()-1);
						parm = parmbuf.toString();
					}

					String val = t.nextToken();
					if (val.startsWith("\""))
					{
						do
						{
							val = val.concat(" ");
							val = val.concat(t.nextToken());
							System.out.println("Concatenated next token: " + val);
						} while (!val.endsWith("\""));

						// Remove quotes from beginning and end of value
						StringBuffer valbuf = new StringBuffer(val);
						valbuf.deleteCharAt(0);
						valbuf.deleteCharAt(valbuf.length()-1);
						val = valbuf.toString();
					}

					if (parm != null && val != null)
					{
						if (addr.indexOf("ICMP") != -1)
						{
							propICMP.setProperty(parm, val);
							System.out.println("ICMP Property set:  parm: '" + parm + "' value: '" + val + "'");
						}
						else if (addr.indexOf("SMTP") != -1)
						{
							propSMTP.setProperty(parm, val);
							System.out.println("SMTP Property set:  parm: '" + parm + "' value: '" + val + "'");
						}
						else if (addr.indexOf("FTP") != -1)
						{
							propFTP.setProperty(parm, val);
							System.out.println("FTP Property set:  parm: '" + parm + "' value: '" + val + "'");
						}
						else if (addr.indexOf("HTTP") != -1)
						{
							propHTTP.setProperty(parm, val);
							System.out.println("HTTP Property set:  parm: '" + parm + "' value: '" + val + "'");
						}
						else if (addr.indexOf("DNS") != -1)
						{
							propDNS.setProperty(parm, val);
							System.out.println("DNS Property set:  parm: '" + parm + "' value: '" + val + "'");
						}
					} 
					else
						System.out.println("Error, unable to set property!");
					continue;
				}

				//
				// List properties
				//	
				if (addr.startsWith("list"))
				{
					if (addr.indexOf("ICMP") != -1)
						propSMTP.list(System.out);
					else if (addr.indexOf("SMTP") != -1)
						propSMTP.list(System.out);
					else if (addr.indexOf("FTP") != -1)
						propFTP.list(System.out);
					else if (addr.indexOf("HTTP") != -1)
						propHTTP.list(System.out);
					else if (addr.indexOf("DNS") != -1)
						propDNS.list(System.out);
					else
						System.out.println("Error, invalid service monitor specified");
					continue;
				}

				try 
				{ 
					inetAddr = InetAddress.getByName(addr); 
				} 
				catch (IOException e)
				{
					System.out.println("Unknown host entered...try again.");
					continue;
				}

				System.out.println("address to test: '" + inetAddr + "'");

				//
				// Create appropriate NetworkInterface object
				//
				NetworkInterfaceIPv4 iface = new NetworkInterfaceIPv4(inetAddr.getHostAddress());
							
				//
				// Launch various service monitors against address
				//
				try
				{	
					int status;
					String poll=null;
				
					// ICMP Poll
					poll = propICMP.getProperty("enabled");	
					if (poll == null || poll.equals("1"))
					{
						Log.print(Log.DEBUG, "Started asynchronous ICMP request...");
						ICMPRequestGenerator requester = new ICMPRequestGenerator(propICMP, iface);
						requester.start();
					}

					// SMTP Poll
					poll = propSMTP.getProperty("enabled");	
					if (poll == null || poll.equals("1"))
					{
						monSMTP.initialize(null, null);
						status = monSMTP.poll(iface, null, propSMTP);
						Log.print(Log.INFORMATIONAL,
							"SMTP service: " + (status==monSMTP.SERVICE_AVAILABLE ? "Available" : "Unavailable") + "\n");
						monSMTP.release();
					}

					// FTP Poll
					poll = propFTP.getProperty("enabled");	
					if (poll == null || poll.equals("1"))
					{
						monFTP.initialize(null, null);
						status = monFTP.poll(iface, null, propFTP);
						Log.print(Log.INFORMATIONAL,
							"FTP service: " + (status==monFTP.SERVICE_AVAILABLE ? "Available" : "Unavailable") + "\n");
						monFTP.release();
					}
							
					// HTTP Poll
					poll = propHTTP.getProperty("enabled");	
					if (poll == null || poll.equals("1"))
					{			
						monHTTP.initialize(null, null);
						status = monHTTP.poll(iface, null, propHTTP);
						Log.print(Log.INFORMATIONAL,
							"HTTP service: " + (status==monHTTP.SERVICE_AVAILABLE ? "Available" : "Unavailable") + "\n");
						monHTTP.release();
					}
					
					// DNS Poll
					poll = propDNS.getProperty("enabled");	
					if (poll == null || poll.equals("1"))
					{
						monDNS.initialize(null, null);
						status = monDNS.poll(iface, null, propDNS);
						Log.print(Log.INFORMATIONAL,
							"DNS service: " + (status==monDNS.SERVICE_AVAILABLE ? "Available" : "Unavailable") + "\n");
						monDNS.release();
					}
				}
				catch (ServiceMonitorException sme)
				{
					System.out.println("Caught ServiceMonitorException: " + sme);
				}				

				System.out.println("****Service monitor poll for " + addr + " completed.****\n\n");
			}
			catch (IOException ioe)
			{
				System.out.println("IO error:" + ioe);
			}
		}
	}

	/**
	 * Start the ServiceMonitorTester process
	 */
	public static void main(String[] args)
	{
		ServiceMonitorTester tester = new ServiceMonitorTester();
		tester.start();
	}
}

//
// Copyright (C) 2000 N*Manage Company, Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
// $Id: TestForDnsServer.java,v 1.8 2000/09/13 14:50:18 weave Exp $
//
//

package org.opennms.bb.dp.capsd.plugin;

import java.io.*;
import java.net.*;
import java.util.*;

import org.opennms.bb.common.components.Log;
import org.opennms.bb.dp.capsd.plugin.dns.*;

/**
 * <P>Tests if a node is a DNS server. Sends a DNS address request for
 * localhost and expects a response of the IP address. The request
 * is retries 3 times.</P>
 *
 * @author <A HREF="mailto:sowmya@opennms.org">Sowmya</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version $Revision: 1.8 $
 */
public class TestForDnsServer extends Object 
	implements CapsdPlugin
{
	/**
	 * </P>The capability name.</P>
	 */
	private final static String	CAPABILITY_NAME = "isDNS";

	/**
	 * </P>The port on which the host is checked 
	 * to see if it supports DNS.</P>
	 */
	private static int 		DEFAULT_PORT = 53;


	/**
	 * <P>Sends a DNSAddressRequest to the name server.</P>
	 *
	 * @param request	The address request to send to the name server.
	 * @param socket	The datagram socket the request is sent on.
	 * @param nameServer	The nameserver address for the packet destination.
	 * @param port		The port number to send the address.
	 *
	 * @exception java.io.IOException	Thrown if an error occurs while
	 *	sending the datagram packet.
	 */
	private void sendRequest(DNSAddressRequest 	request, 
				 DatagramSocket 	socket, 
				 InetAddress 		nameServer,
				 int			port) 
		throws IOException 
	{
		byte[] data = request.buildRequest();
		DatagramPacket packet = new DatagramPacket(data, 
							   data.length, 
							   nameServer, 
							   port);
		socket.send(packet);
	}

	/**
	 * <P>Receives the data packet and retrieves 
	 * the address from the packet.</P> 
	 *
	 * @param request	the DNSAddressRequest whose response is to be got
	 * @param socket	the socket on which the response  is recieved
	 *
	 * @exception java.io.IOException  Thrown if response is not decoded
	 *	as expected.
	 */
	private void getResponse(DNSAddressRequest request, 
				 DatagramSocket socket) 
		throws IOException 
	{
		byte[] buffer = new byte[512];
		DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
		socket.receive(packet);
		request.receiveResponse(packet.getData(), packet.getLength());
	}

	/**
	 * <P>Sends a DNS address request for 'localhost' - if a reply is
	 * received, the interface is a DNS server.</P>
	 *
	 * @return True if server, false if not.
	 */
	private boolean isServer(InetAddress nserver, int port)
	{
		boolean isAServer = false;
		DNSAddressRequest request = new DNSAddressRequest("localhost");

		try 
		{
			int count = 0;
			boolean received = false;
			DatagramSocket socket = new DatagramSocket();
			socket.setSoTimeout(5000);
			
			try 
			{
				while (!received) 
				{
					try 
					{
						sendRequest(request, socket, nserver, port);
						getResponse(request, socket);
						received  = true;
						isAServer = true;
					} 
					catch (InterruptedIOException ex) 
					{
						if (count++ >= 3) 
						{
							throw new IOException ("No response received from nameserver");
						}
						isAServer = false;
					}
				}
			} 
			finally 
			{
				socket.close ();
			}
		} 
		catch (IOException ex) 
		{
			// ignore
		}

		return isAServer;
	}
	
	/**
	 * <P>The Default constructor.</P>
	 */
	public TestForDnsServer()
	{
		// do nothing
	}

	/**
	 * <P>Returns true if the address is a DNS server.</P>
	 *
	 * @return True if DNS server, false otherwise
	 */
	public boolean isProtocolSupported(java.net.InetAddress host)
	{
		return isServer(host, DEFAULT_PORT);
	}

	/**
	 * returns true if the address is a DNS server and responds to DNS 
	 * queries at the specified port
	 *
	 * @return true if DNS server, false otherwise
	 */
	public boolean isProtocolSupported(java.net.InetAddress host, int port)
	{
		return isServer(host, port);
	}


	/**
	 * <P>Returns true only if the address is a DNS server and the capability
	 * queried for is 'isDNS'</P>
	 *
	 * @return True if DNS server, false otherwise
	 */
	public boolean isProtocolSupported(InetAddress host, String capName)
		throws UnsupportedProtocolException
	{
		if(!CAPABILITY_NAME.equalsIgnoreCase(capName))
			throw new UnsupportedProtocolException(capName + " not supported");

		return isServer(host, DEFAULT_PORT);
	}

	/**
	 * <P>returns true only if the address is a DNS server and the capability
	 * queried for is 'isDns' and if the interface answers a DNS query
	 * on the port number specified.</P>
	 *
	 * @return True if DNS server, false otherwise
	 */
	public boolean isProtocolSupported(java.net.InetAddress host, int port, String capName) 
		throws UnsupportedProtocolException
	{
		if(!CAPABILITY_NAME.equalsIgnoreCase(capName))
			throw new UnsupportedProtocolException(capName + " not supported");

		return isServer(host, port);
	}

	
	/**
	 * <P>Returns the capability string.</P>
	 *
	 * @return The capbility name
	 */
	public String getCapabilityName()
	{
		return CAPABILITY_NAME;
	}
}

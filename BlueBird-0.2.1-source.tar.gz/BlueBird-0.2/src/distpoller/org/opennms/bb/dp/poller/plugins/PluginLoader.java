//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.dp.poller.plugins;

import java.util.zip.*;
import java.io.*;
import java.util.*;

import org.opennms.bb.dp.poller.plugins.ServiceMonitor;

/**This class is responsible for loading plugin classes from 
 * jar files.
 *
 * @author <A HREF="mailto:jason@opennms.org">Jason Johns</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version $Revision: 1.1 $
 * 
 */
public class PluginLoader extends ClassLoader
{
	/**
	*/
	private HashMap m_plugins;
	
	/**
	*/
	private File m_directory;
	
	/**
	*/
	private final static String PLUGIN_PREFIX = "ServiceMonitor";
	
	/**
	*/
	public PluginLoader()
	{
		m_plugins = new HashMap();
	}
	
	/**
	*/
	public void loadFromJar(String aDirectory)
	{	
		File directory = new File(aDirectory);
		
		//see if the directory exists
		if(!(directory.exists() || directory.isDirectory()))
			return;
		
		String[] pluginJarNames = directory.list();
		
		//if there are no files in the directory then there is nothing to load 
		if(pluginJarNames == null)
			return;
			
		for(int i = 0; i < pluginJarNames.length; i++)
		{
			String jarName = pluginJarNames[i];
			
			if(!jarName.toLowerCase().endsWith(".jar"))
				continue;
			
			try
			{
				Plugin plugin = jarLoader(aDirectory + jarName);
				m_plugins.put(jarName, plugin);
			}
			catch(IOException io)
			{
				System.out.println(io);
				io.printStackTrace();
			}
		}
	}
	
	/**
	*/
	public void loadFromDirectory(String aDirectory)
	{
		File directory = new File(aDirectory);
		
		//see if the directory exists
		if(!(directory.exists() || directory.isDirectory()))
			return;
		
		String[] pluginFileNames = directory.list();
		
		//if there are no files in the directory then there is nothing to load 
		if(pluginFileNames == null)
			return;
			
		for(int i = 0; i < pluginFileNames.length; i++)
		{
			String fileName = pluginFileNames[i];
			
			if( !fileName.toLowerCase().endsWith(".class") ||
			    !fileName.startsWith(PLUGIN_PREFIX) )
				continue;
			
		
			Plugin plugin = fileLoader(aDirectory + fileName);
			m_plugins.put(fileName, plugin);
			
		}
	}
	
	/**
	*/
	public ServiceMonitor retrieveServiceMonitor(String aServiceName)
	{
		ServiceMonitor monitor = null;
		ServiceMonitor curMonitor = null;
		Plugin currentPlugin = null;
		
		Iterator i = m_plugins.keySet().iterator();
		
		while(i.hasNext())
		{
			currentPlugin = (Plugin)m_plugins.get(i.next());
			curMonitor = (ServiceMonitor)currentPlugin.getPlugin();
			
			if (curMonitor.serviceName().equals(aServiceName))
			{
				monitor = curMonitor;
				break;
			}
		}
		
		return monitor;
	}
	
	/**
	*/
	public HashMap getPlugins()
	{
		return m_plugins;
	}
	
	/**
	*/
	public Plugin fileLoader(String path)
	{
		Plugin plugin = new Plugin(path);
		
		try
		{
			Class pluginClass = loadClassFromFile(path, true);
			plugin.addPlugin((ServiceMonitor)pluginClass.newInstance());
		}
		catch (ClassNotFoundException e)
		{
			System.out.println(e);
			e.printStackTrace();
		}
		catch(InstantiationException e)
		{
			System.out.println(e);
			e.printStackTrace();
		}
		catch (IllegalAccessException e)
		{
			System.out.println(e);
			e.printStackTrace();
		
		}
		return plugin;
	}
	
	/**
	*/
	public Class loadClassFromFile(String aFileName, boolean resolveIt)
		throws ClassNotFoundException
	{
		//see if the class is already loaded
		Class cls = findLoadedClass(aFileName);
		if(cls != null)
		{
			if(resolveIt)
				resolveClass(cls);
			return cls;
		}

		try
		{
			File file = new File(aFileName);
			InputStream in = new FileInputStream(file);

			int len = (int)file.length();
			byte[] data = new byte[len];
			int success = 0;
			int offset = 0;
			while(success < len)
			{
				len -= success;
				offset += success;
				success = in.read(data,offset,len);
				if(success == -1)
				{
					//Log.log(Log.ERROR,this,"Failed to load class "
					//	+ className + " from " + m_zipFile.getName());
					throw new ClassNotFoundException(aFileName);
				}
			}

			cls = defineClass(fileToClass(aFileName),data,0,data.length);
			//cls = defineClass("org.opennms.bb.dp.poller.plugins.ServiceMonitorHTTP",data,0,data.length);

			if(resolveIt)
				resolveClass(cls);

			return cls;
		}
		catch(IOException io)
		{
			//Log.log(Log.ERROR,this,io);

			throw new ClassNotFoundException(aFileName);
		}
	}
	
	/**loads any classes from a jar file on the
	   filesystem.
	   @param String path, the path of the jar file to open
	*/
	public Plugin jarLoader(String aPath)
		throws IOException
	{
		ZipFile zipFile = new ZipFile(aPath);
		Plugin plugin =  new Plugin(aPath);
		
		Enumeration entries = zipFile.entries();
		
		while(entries.hasMoreElements())
		{
			ZipEntry entry = (ZipEntry)entries.nextElement();
			String name = entry.getName();
			
			if(name.toLowerCase().endsWith(".class"))
			{
				if(name.startsWith(PLUGIN_PREFIX))
				{
					try
					{
						Class pluginClass = loadClassFromZip(name, zipFile, true);
						
						plugin.addPlugin((ServiceMonitor)pluginClass.newInstance());
					}
					catch (ClassNotFoundException e)
					{
						System.out.println(e);
						e.printStackTrace();
					}
					catch(InstantiationException e)
					{
						System.out.println(e);
						e.printStackTrace();
					}
					catch (IllegalAccessException e)
					{
						System.out.println(e);
						e.printStackTrace();
					}
				}
			}
		}
		
		return plugin;
	}
	
	/**Adapted from the JARClassLoader.java source from the jEdit project.
	 * 
	 * Converts a file name to a class name. All slash characters are
	 * replaced with periods and the trailing '.class' is removed.
	 * @param name The file name
	 * @author <A HREF="sp@gjt.org">Slava Pestov
	 */
	public static String fileToClass(String name)
	{
		char[] clsName = name.toCharArray();
		
		for(int i = clsName.length - 6; i >= 0; i--)
		{
			if(clsName[i] == '/')
			{
				clsName[i] = '.';
			}
		}
		
		return new String(clsName,0,clsName.length - 6);
	}
	
	/**Adapted from the JARClassLoader.java source from the jEdit project.
	* @author <A HREF="sp@gjt.org">Slava Pestov
	*/
	private Class loadClassFromZip(String aFileName, ZipFile aZipFile, boolean resolveIt)
		throws ClassNotFoundException
	{
		//see if the class is already loaded
		Class cls = findLoadedClass(aFileName);
		if(cls != null)
		{
			if(resolveIt)
				resolveClass(cls);
			return cls;
		}

		try
		{
			ZipEntry entry = aZipFile.getEntry(aFileName);

			if(entry == null)
			{
				return null;
			}

			InputStream in = aZipFile.getInputStream(entry);

			int len = (int)entry.getSize();
			byte[] data = new byte[len];
			int success = 0;
			int offset = 0;
			while(success < len)
			{
				len -= success;
				offset += success;
				success = in.read(data,offset,len);
				if(success == -1)
				{
					//Log.log(Log.ERROR,this,"Failed to load class "
					//	+ className + " from " + m_zipFile.getName());
					throw new ClassNotFoundException(aFileName);
				}
			}

			cls = defineClass(null,data,0,data.length);
			
			if(resolveIt)
				resolveClass(cls);

			return cls;
		}
		catch(IOException io)
		{
			//Log.log(Log.ERROR,this,io);

			throw new ClassNotFoundException(aFileName);
		}
	}
	
	/**Adapted from the JARClassLoader.java source from the jEdit project.
	 * This class was originally called JAR, renamed to make more sense (it
	 * is loaded from a .jar file but models what is contained in the jar)
	 *
	 * A Jar file where a plugin and all associated files
	   live.
	 *
	 * @author <A HREF="sp@gjt.org">Slava Pestov
	 */
	public static class Plugin
	{
		// package-private members
		private int index;
	    	private String path;
		private Vector plugins;
		
		public Plugin(String aPath)
		{
			path = aPath;
			plugins = new Vector();
		}
		
		/**
		*/
		public String getPath()
		{
			return path;
		}
		
		/**
		*/
		public void addPlugin(Object plugin)
		{
			plugins.addElement(plugin);
		}

		public Object getPlugin()
		{
			return plugins.get(0);
		}
		
		/**
		*/
		public Object[] getPlugins()
		{
			Object[] array = new Object[plugins.size()];
			plugins.copyInto(array);
			return array;
		}

		/**
		*/
		public int getIndex()
		{
			return index;
		}

		/**
		*/
		public void getPlugins(Vector vector)
		{
			for(int i = 0; i < plugins.size(); i++)
			{
				vector.addElement(plugins.elementAt(i));
			}
		}
	}
}

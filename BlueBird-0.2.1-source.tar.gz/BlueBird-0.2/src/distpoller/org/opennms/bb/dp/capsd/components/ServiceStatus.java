//
// Copyright (C) 2000 N*Manage Company Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
// Tab Size = 8
//
// $Id: ServiceStatus.java,v 1.5 2000/09/08 20:43:11 weave Exp $
//

package org.opennms.bb.dp.capsd.components;

import java.lang.*;

/**
 * <P>The ServiceStatus is designed to hold a serviceID, the identifier
 * in the database, and its current status. The service will either
 * be supported or unsupported.</P>
 *
 * @author <A HREF="mailto:sowmya@opennms.org">Sowmya</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version $Revision: 1.5 $
 */
public final class ServiceStatus extends Object
{
	/**
	 * <P>The service identifier.</P>
	 */
	private int	m_serviceID;		// service ID
	
	/**
	 * <P>The supported flag. If set to true
	 * the the protocol is supported, if false
	 * then the protocol is not supported.</P>
	 */
	private boolean	m_supported;		// true if service supported

	/**
	 * <P>The default class constructor. The constructor
	 * will always throw an exception.</P>
	 *
	 * @exception java.lang.UnsupportedOperationException Always
	 * 	thrown by the constructor.
	 */
	private ServiceStatus()
		throws UnsupportedOperationException
	{
		throw new UnsupportedOperationException("default constructor not supported");
	}
	
	/**
	 * <P>Constructs a new service status object.</P>
	 *
	 * @param serviceID	service ID of the service in the SERVICE table
	 * @param b		true if the service is supported, false if not
	 */
	public ServiceStatus(int serviceID, boolean b)
	{
		m_serviceID = serviceID;
		m_supported = b;
	}

	/**
	 * <P>Returns the service identifier for the 
	 * status object.</P>
	 *
	 * @return The service id for the status information.
	 */
	public int getServiceID()
	{
		return m_serviceID;
	}
	
	/**
	 * <P>Returns true if the service defined by 
	 * this object is supported. A false is returned
	 * if the services is not supported.</P>
	 *
	 * @return The supported status of the service.
	 */
	public boolean isSupported()
	{
		return m_supported;
	}
}


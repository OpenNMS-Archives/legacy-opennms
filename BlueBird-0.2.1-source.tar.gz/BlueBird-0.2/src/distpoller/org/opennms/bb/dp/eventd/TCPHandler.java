//
// Copyright (C) 2000 N*Manage Company, Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
package org.opennms.bb.dp.eventd;

import java.net.*;
import java.io.*;
import java.util.*;

import org.xml.sax.SAXException;

import org.opennms.bb.common.components.*;
import org.opennms.bb.dp.common.components.*;

/**
 * <P>TCPHandler handles TCP connections to the eventd. For each conenction
 * accepted, it creates a 'SocketShadowInputStream' object to pass the
 * input stream of the socket to be parsed for events
 *
 * <P>TCPHandler extends the PollerThread for the pause/resume/shutdown
 * functionality</P>
 * 
 * @author	<A HREF="mailto:weave@opennms.org">Brian Weaver</A>
 * @author 	<A HREF="mailto:sowmya@opennms.org">Sowmya Kumaraswamy</A>
 * @author	<A HREF="http://www.opennms.org">OpenNMS.org</A>
 *
 * @version	$Revision: 1.1 $
 */
public class TCPHandler extends PollerThread
{
	/**
	 * the length of the queue of connections
	 */
	private final static int	CONN_BACKLOG = 10;

	/**
	 * The socket on which eventd/eventListener listens for TCP connections
	 */
	private ServerSocket 		m_server;
	
	/**
	 * queue of the EventsReaders
	 */
	private PCQueue			m_readerQ;

	/**
	 * queue between the inner class that accepts new connections and the
	 * main thread
	 */
	private PCQueue			m_tcpQ;

	/**
	 * The connection handler that accepts connections and queues them
	 * back to the main thread
	 */
	private ConnectionHandler	m_handler;

	/**
	 * the current number of connections being handled - is updated
	 * during the creation and close of the inner class
	 * SocketShadowInputStream
	 */
	private Counter			m_connections;

	// This variable is strictly being used for debug purposes to 
	// keep track of the number of events received
	private static int numEventsRcvd=0; // DEBUG ONLY

	/**
	 * <P>The counter class is used to ensure that the count
	 * is kept accurate when multiple threads could be trying
	 * to adjust the count at the same time.</P>
	 */
	private static class Counter
	{
		/**
		 * <P>The counters value.</P>
		 */
		private int m_count;
		
		/**
		 * <P>Creates a default counter with the initial
		 * value equal to zero.</P>
		 */
		public Counter()
		{
			m_count = 0;
		}
		
		/**
		 * <P>Creates a counter with the passed value.</P>
		 *
		 * @param count	The start value for the counter.
		 */
		public Counter(int count)
		{
			m_count = count;
		}
		
		/**
		 * Increments the counter by one.
		 *
		 * @return The new value of the counter.
		 */
		public synchronized int increment()
		{
			return ++m_count;
		}
		
		/**
		 * Decrements the counter by one.
		 *
		 * @return The new value of the counter.
		 */
		public synchronized int decrement()
		{
			return --m_count;
		}
		
		/**
		 * Returns the current value for the counter.
		 */
		public synchronized int count()
		{
			return m_count;
		}
	}

	/**
	 * An input stream that is a a shadow of the socket's input stream
	 * except that on a close(), the socket is closed so that the input
	 * stream is still open for parse - the input stream is closed
	 * after the parse is complete
	 */
	private class SocketShadowInputStream extends InputStream
	{
		/**
		 * The input stream of the socket for which this shadow
		 * is created
		 */
		private InputStream m_stream;

		/**
		 * The socket whose input stream's shadow this holds
		 */
		private Socket	    m_socket;

		/**
		 * Create the shadow input stream for the socket
		 *
		 * @exception java.io.IOException Thrown if the socket has an error while creating the input stream
		 *
		 */
		SocketShadowInputStream(Socket sock) throws IOException
		{
			m_socket = sock;
			m_stream = sock.getInputStream();
			
			m_connections.increment();
		}

		/**
		 * Returns the number of bytes that can be read from the
		 * input stream without blocking 
		 * 
		 * @exception java.io.IOException Thrown if an I/O error occurs
		 * @see java.io.InputStream#available()
		 */
		public int available() throws IOException
		{
			return m_stream.available();
		}

		/**
		 * Closes the socket
		 *
		 * @exception throws IOException if an I/O error occurs when closing the socket
		 * @see java.net.Socket#close()
		 */
		public void close() throws IOException
		{
			try
			{
				m_socket.close();
			}
			catch(IOException e)
			{
				throw e;
			}
			finally
			{
				m_connections.decrement();
			}
		}

		/**
		 * Marks the current position in the input stream
		 *
		 * @see java.io.InputStream#mark(int)
		 */
		public void mark(int readLimit)
		{
			m_stream.mark(readLimit);
		}

		/**
		 * Tests if this input stream supports the mark and reset 
		 * methods
		 *
		 * @see java.io.InputStream#markSupported()
		 */
		public boolean markSupported()
		{
			return m_stream.markSupported();
		}

		/**
		 * Reads the next byte of input from the input stream
		 *
		 * @exception throws IOException if an I/O error occurs
		 *
		 * @see java.io.InputStream#read()
		 */
		public int read() throws IOException
		{
			return m_stream.read();
		}

		/**
		 * Reads and stores the bytes from the input stream into
		 * the buffer
		 *
		 * @returns number of bytes actually read
		 * @exception throws IOException if an I/O error occurs
		 *
		 * @see java.io.InputStream#read(byte[])
		 */
		public int read(byte[] b) throws IOException
		{
			return m_stream.read(b);
		}

		/**
		 * Reads up to len bytes of  data from the input stream into
		 * the array of bytes
		 *
		 * @exception throws IOException if an I/O error occurs
		 *
		 * @see java.io.InputStream#read(byte[], int, int)
		 */
		public int read(byte[] b, int off, int len) throws IOException
		{
			return m_stream.read(b, off, len);
		}

		/**
		 * Repositions this stream to the position at the time the
		 * mark method was last called on this input stream.
		 *
		 * @exception throws IOException if an I/O error occurs
		 *
		 * @see java.io.InputStream#reset()
		 */
		public void reset() throws IOException
		{
			m_stream.reset();
		}

		/**
		 * Skips over and discards n bytes of data from this input stream.
		 *
		 * @exception throws IOException if an I/O error occurs
		 *
		 * @see java.io.InputStream#skip(int)
		 */
		public long skip(long n) throws IOException
		{
			return m_stream.skip(n);
		}
	}

	/**
	 * When the TCPHandler blocks on the 'accept()', there is no reliable
	 * way to interrupt the thread on a status change. Hence we use this
	 * inner class to handle the accept() and queue it back to the main
	 * handler
	 */
	private static class ConnectionHandler extends Thread
	{
		/**
		 * Flag to determine end of operation in the 'run'method
		 */
		private volatile boolean	m_shutdown;

		/**
		 * Flag to indicate that operation be paused
		 */
		private volatile boolean	m_pause;
		
		/**
		 * The server socket to accept from
		 */
		private ServerSocket		m_server;
		
		/**
		 * The destination of the accepted clients.
		 */
		private PCQueue			m_dest;

		/**
		 * Create the connection handler object 
		 */
		public ConnectionHandler(ServerSocket sock, PCQueue dest)
		{
			m_shutdown = false;
			m_pause    = false;
			m_server   = sock;
			m_dest	   = dest;
		}

		/**
		 * If not paused, accept connections and queue them back to the
		 * main thread - else refuse the connections
		 */
		public void run()
		{
			while(!m_shutdown)
			{
				try
				{
					Socket client = m_server.accept();
					if (!m_pause)
					{
						m_dest.add(client);
					}
					else
					{
						client.close();
			                       	String errorMsg = "Connection refused for " 
								  + client.getInetAddress().getHostAddress() 
								  + ":" 
								  + client.getPort() 
								  + ": operation currently paused";
						Log.print(Log.INFORMATIONAL, errorMsg);
					}
				}
				catch(IOException ioE)
				{
					Log.print(Log.WARNING, "TCPHandler: Event ignored: Unable to add event stream to event listener queue" + ioE.getMessage());
					Log.print(Log.WARNING, ioE);
				}
				catch(InterruptedException iE)
				{
					Log.print(Log.WARNING, "TCPHandler: Event ignored: Unable to add event stream to event listener queue" + iE.getMessage());
					Log.print(Log.WARNING, iE);
				}
				catch(QueueClosedException qE)
				{
					//
					// if queue has been closed by the main thread, shutdown
					//
					m_shutdown = true;
				}
			}
		}

		/**
		 * Set the 'm_pause' flag to indicate that operation be paused
		 */
		public void pauseOperation()
		{
			m_pause = true;
		}

		/**
		 * Set the 'm_pause' flag to indicate that operation be resumed
		 */
		public void resumeOperation()
		{
			m_pause = false;
		}

		/**
		 * Set the 'm_shutdown' flag to indicate that operation be ended
		 */
		public void shutdown()
		{
			m_shutdown = true;
		}
	}

	/**
	 * Instantiate the TCPHandler at the said port with the default name
	 *
	 * @param port		port number to be used by the handler
	 * @param readerQ	queue to which the incoming events are to be added
	 * 
	 * @exception java.io.IOException 		Thrown if communication port cannot be set up
	 * @exception org.apache.sax.SAXException 	Thrown if the event parser pool cannot be created
	 */
	TCPHandler(int port, PCQueue readerQ) 
		throws IOException
	{
		this("TCPHandler-" + port, port, readerQ);
	}
	
	/**
	 * Instantiate the TCPHandler at the said port with the specified name
	 *
	 * @param name		name of this thread
	 * @param port		port number to be used by the handler
	 * @param readerQ	queue to which the incoming events are to be added
	 * 
	 * @exception java.io.IOException 		Thrown if communication port cannot be set up
	 * @exception org.apache.sax.SAXException 	Thrown if the event parser pool cannot be created
	 */
	TCPHandler(String name, int port, PCQueue readerQ) 
		throws IOException
	{
		super(name);

		m_readerQ 	= readerQ;

		m_server 	= new ServerSocket(port, CONN_BACKLOG);
		m_connections 	= new Counter();
		m_tcpQ		= new PCQueueFixedArray(CONN_BACKLOG);
		m_handler 	= new ConnectionHandler(m_server, m_tcpQ);

	}

	/**
	 * The main method that keeps track of status changes and reads accepted
	 * connections from the 'tcpQ'. For each accepted connection, a
	 * 'SocketShadowInputStream' is created and added to the listener queue
	 * from where the EventListener thread pool picks it up and parses it
	 * before closing it
	 * 
	 */
	public void run()
	{
		setOpStatus(STATUS_NORMAL);
		Log.print(Log.INFORMATIONAL, "Eventd ready to accept TCP connections");

		//
		// Loop through each connected client
		//
		for (;;)
		{
			//
			// synchronize on self so that we can check our status
			//
			synchronized(this)
			{
				//
				// Loop until there is a new client or we
				// are shutdown
				//
				for(;;)
				{
					int status = getOpStatus();
					
					//
					// check the child thread!
					//
					if(m_handler.isAlive() == false && (status & STATUS_TERMINATING) != STATUS_TERMINATING)
					{
						Log.print(Log.WARNING, "TCP Connection handler terminated abnormally");
						shutdown();
						continue;
					}
					
					//
					// do normal status checks now
					//
					if((status & STATUS_TERMINATING) == STATUS_TERMINATING)
					{
						setOpStatus(STATUS_SHUTDOWN);
						return;
					}
					else if((status & STATUS_PAUSING) == STATUS_PAUSING)
					{
						m_handler.pauseOperation();
						setOpStatus(STATUS_PAUSED);
					}
					else if((status & STATUS_RESUMING) == STATUS_RESUMING)
					{
						m_handler.resumeOperation();
						setOpStatus(STATUS_NORMAL);
					}
					else if((status & STATUS_PAUSED) == STATUS_PAUSED)
					{
						try
						{
							wait();
						}
						catch(InterruptedException e)
						{
							setOpStatus(STATUS_TERMINATING);
						}
					}
					else if((status & STATUS_NORMAL) == STATUS_NORMAL)
					{
						//
						// check the queue, if it is empty then
						// have it notify us when there is a 
						// connection to be processed
						//
						boolean doWait = false;
						synchronized(m_tcpQ)
						{
							if(m_tcpQ.isEmpty())
							{
								doWait = true;
								m_tcpQ.oneShotNotifyAllOnAdd(this);
							}
						}
						
						//
						// have a connection
						//
						if(!doWait)
							break; // exit status checking loop
						
						//
						// no connnection so wait!
						//
						try
						{
							wait();
						}
						catch(InterruptedException ie)
						{
							setOpStatus(STATUS_TERMINATING);
						}
					}
				} // end for(;;)
			} // end synchronized(this)
			
			//
			// to get here we must have had at least one
			// element on the queue, however another thread
			// could have nabbed it!
			//
			Socket client = null;
			try
			{
				synchronized(m_tcpQ)
				{
					if(!m_tcpQ.isEmpty())
						client = (Socket)m_tcpQ.read();
				}
			}
			catch(InterruptedException iE)
			{
				client = null;
			}
			catch(QueueClosedException qE)
			{
				// ignore - not really possible to get here
				// since this is the  thread that will close
				// the queue
				client = null;
			}

			//
			// check the client
			//
			if (client == null)
				continue;

			Log.print(Log.DEBUG, "Data received  via TCP (" + ++numEventsRcvd + ")");

			try
			{
				SocketShadowInputStream ssis = new SocketShadowInputStream(client);
				m_readerQ.add(new EventsReader(ssis));
			}
			catch(InterruptedException iE)
			{
				Log.print(Log.WARNING, "TCPHandler: Event ignored: Unable to add event stream to event listener queue" + iE.getMessage());
			}
			catch(IOException e)
			{
				Log.print(Log.WARNING, "TCPHandler: Event ignored: Unable to add event stream to event listener queue" + e.getMessage());
			}
			catch(QueueClosedException qE)
			{
				// ignore???
				Log.print(Log.WARNING, "TCPHandler: Event ignored: Unable to add event stream to event listener queue" + qE.getMessage());
			}

		}
	}
	
	/**
	 * Start operation
	 */
	public void start()
	{
		m_handler.start();
		super.start();
	}
	
	/**
	 * Shutdown operation. Close the server socket and the internal queue
	 * and shutdown the ConnectionHandler thread
	 */
	public synchronized void shutdown()
	{
		m_handler.shutdown();
		try
		{
			m_server.close();
		}
		catch(Exception e) { }
		m_tcpQ.close();
		
		try
		{
			if(!Thread.currentThread().equals(m_handler))
				m_handler.join();
		}
		catch(InterruptedException ie)
		{
			Log.print(Log.WARNING, "Thread interrupted while waiting on connection handler to terminate");
			Log.print(Log.WARNING, ie);
		}
		
		super.shutdown();
	}
}

//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.dp.poller.scheduler.utils;

import java.util.*;

import org.opennms.bb.dp.poller.scheduler.utils.Parameter;
import org.opennms.bb.dp.poller.scheduler.utils.PollerRange;
import org.opennms.bb.common.filter.util.BBIPAddress;

/**This class is responsible for holding information about a
 * range parsed from the package.xml file.
 
 * @author <A HREF="mailto:jason@opennms.org">Jason Johns</A>
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version $Revision: 1.2 $
 * 
 */
public class RangeInfo
{
	/**The default range parameters, from the <rangeDef> tags
	*/
	private List m_rangeDef;
	
	/**The include range parameters, from the <irange> tags
	*/
	private List m_irange;
	
	/**The exclude range parameters, from the <erange> tags
	*/
	private List m_erange;
	
	/**The specific parameters, from the <specific> tags
	*/
	private List m_specific;
	
	/**The url parameters, from the <url> tags
	*/
	private List m_url;
	
	/**Default constructor, allocates members
	*/
	public RangeInfo()
	{
		m_rangeDef = new ArrayList();
		m_irange   = new ArrayList();
		m_erange   = new ArrayList();
		m_specific = new ArrayList();
		m_url      = new ArrayList();
	}
	
	/**This method returns a boolean indicating if an ip address matches
	   any ip addresses contained in the specific ranges
	   @return boolean, indicating if address matches a specific
	   @param String ipAddr, the address to check
	*/
	public boolean inSpecific(String ipAddr)
	{
		boolean result = false;
		
		PollerRange range = null;
		
		for (int i = 0; i < m_specific.size(); i++)
		{
			range = (PollerRange)m_specific.get(i);
			if (ipAddr.equals(range.getValue(PollerRange.IPADDRESS)))
			{
				result = true;
				break;
			}
		}
		
		return result;
	}
	
	/**This method returns a boolean indicating if an ip address 
	   falls within the exclude ranges.
	   @return boolean, indicating if address is excluded
	   @param String ipAddr, the address to check
	*/
	public boolean inExclude(String ipAddr)
	{
		boolean result = false;
		
		PollerRange range = null;
		int high;
		int low;
		int address;
		
		for (int i = 0; i < m_erange.size(); i++)
		{
			range = (PollerRange)m_erange.get(i);
			
			address = BBIPAddress.getIpAsInteger(ipAddr);
			
			low = BBIPAddress.getIpAsInteger(range.getValue(PollerRange.BEGIN));
			high = BBIPAddress.getIpAsInteger(range.getValue(PollerRange.END));
			
			if ( address >= low && address <= high)
			{
				result = true;
				break;
			}
		}
		
		return result;
	}
	
	/**This method returns a boolean indicating if an ip address 
	   falls within the include ranges.
	   @return boolean, indicating if address is included
	   @param String ipAddr, the address to check
	*/
	public boolean inInclude(String ipAddr)
	{
		boolean result = false;
		
		PollerRange range = null;
		int high;
		int low;
		int address;
		
		for (int i = 0; i < m_irange.size(); i++)
		{
			range = (PollerRange)m_irange.get(i);
			low = BBIPAddress.getIpAsInteger(range.getValue(PollerRange.BEGIN));
			high = BBIPAddress.getIpAsInteger(range.getValue(PollerRange.END));
			address = BBIPAddress.getIpAsInteger(ipAddr);
			
			low = BBIPAddress.getIpAsInteger(range.getValue(PollerRange.BEGIN));
			high = BBIPAddress.getIpAsInteger(range.getValue(PollerRange.END));
			
			if ( address >= low && address <= high)
			{
				result = true;
				break;
			}
		}
		
		return result;
	}
	
	/**This method adds a default range
	   @param PollerRange aRange, the range to be added
	*/
	public void addDefRange(PollerRange aRange)
	{
		m_rangeDef.add(aRange);
	}
	
	/**This method adds a include range
	   @param PollerRange aRange, the range to be added
	*/
	public void addIrange(PollerRange aRange)
	{
		m_irange.add(aRange);
	}
	
	/**This method adds a exclude range
	   @param PollerRange aRange, the range to be added
	*/
	public void addErange(PollerRange aRange)
	{
		m_erange.add(aRange);
	}
	
	/**This method adds a specific range
	   @param PollerRange aRange, the range to be added
	*/
	public void addSpecific(PollerRange aRange)
	{
		m_specific.add(aRange);
	}
	
	/**This method adds a url range
	   @param PollerRange aRange, the range to be added
	*/
	public void addUrl(PollerRange aRange)
	{
		m_url.add(aRange);
	}
	
	/**This method returns a string representation of the RangeInfo
	   @return String, the string representation of the RangeInfo
	*/
	public String toString()
	{
		StringBuffer buffer = new StringBuffer();
		
		//add the range defaults to the string
		buffer.append("\r\nm_rangeDef:\r\n\t").append(rangePrint(m_rangeDef));
		
		//add the include ranges to the string
		buffer.append("\r\nm_irange:\r\n\t").append(rangePrint(m_irange));
		
		//add the exclude ranges to the string
		buffer.append("\r\nm_erange:\r\n\t").append(rangePrint(m_erange));
		
		//add the m_specific ips to the string
		buffer.append("\r\nm_specific:\r\n\t").append(rangePrint(m_specific));
		
		//add the m_urls to the string
		buffer.append("\r\nm_url:\r\n\t").append(rangePrint(m_url));
		
		return buffer.toString();
	}
	
	/**This method takes the elements from the member lists and 
	   appends them to a string buffer for string representation.
	   @return StringBuffer, the contents of the list as a StringBuffer
	   @param List list, the list to convert to StringBuffer
	*/
	private StringBuffer rangePrint(List list)
	{
		StringBuffer buffer = new StringBuffer();
		
		for(int i = 0; i < list.size(); i++)
		{
			buffer.append( ((PollerRange)list.get(i)).toString() );
		}
		
		return buffer;
	}
}

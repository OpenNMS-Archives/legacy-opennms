//
// Copyright (C) 2000 N*Manage Company Inc.
// Copyright (C) 2000 PlatformWorks Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
// $Id: ServiceMonitorHTTP.java,v 1.5 2000/11/14 21:32:10 mike Exp $
//
package org.opennms.bb.dp.poller.plugins;

import java.net.*;
import java.util.*;
import java.io.*;
import java.lang.*;
import java.util.Properties;

import org.opennms.protocols.ip.*;
import org.opennms.bb.dp.poller.plugins.*;

import org.opennms.bb.common.components.Log; // Debug purposes only

/**
 * <P>This class is designed to be used by the service poller
 * framework to test the availability of the HTTP service on 
 * remote interfaces. The class implements the ServiceMonitor
 * interface that allows it to be used along with other
 * plug-ins by the service poller framework.</P>
 *
 * @author <A HREF="http://www.opennms.org/">OpenNMS</A>
 *
 * @version CVS $Revision: 1.5 $
 *
 */
public class ServiceMonitorHTTP implements ServiceMonitor
{	
	/** 
	 * Name of monitored service.
	 */
	private static final String SERVICE_NAME	= "HTTP";

	/** 
	 * Default HTTP ports.
	 */
	private static final int[] DEFAULT_PORTS = {80, 8080, 8888};

	/** 
	 * Default retries.
	 */
	private static final int DEFAULT_RETRY = 0;

	/**
	 * Default URL to 'GET'
	 */
	private static final String DEFAULT_URL = "/";

	/** 
	 * Default timeout. Specifies how long (in milliseconds) to block waiting
	 * for data from the monitored interface.
	 */
	private static final int DEFAULT_TIMEOUT = 3000; // 3 second timeout on read()

	/**
	 * <P>Returns the name of the service that the plug-in monitors ("HTTP").</P>
	 *
	 * @return The service that the plug-in monitors.
	 */
	public String serviceName()
	{
		return SERVICE_NAME;
	}
	
	/**
	 * <P>Initialize the service monitor.</P>
	 *
	 * @param proxy		The object that can be used to load/save config information.
	 * @param parameter	The parameters from the appropiate package(s).
	 *
	 * @exception org.opennms.bb.dp.poller.plugins.ServiceMonitorException	Thrown if
	 * 	an unrecoverable error occurs that prevents the plug-in from functioning.
	 *
	 */
	public void initialize(ConfigurationProxy proxy, Properties parameters) 
		throws ServiceMonitorException
	{
		return;
	}
		
	/**
	 * <P>Called by the poller framework when the plug-in is being unloaded.
	 * Any resources still being used by the monitor are released.</P>
	 *
	 * @exception org.opennms.bb.dp.poller.plugins.ServiceMonitorException	Thrown if
	 * 	an error occurs during deallocation.
	 *
	 */
	public void release() 
		throws ServiceMonitorException
	{
		return;
	}
	
	/**
	 * <P>Called by the poller framework when an interface is being added
	 * to the scheduler.  Here we perform any necessary initialization
	 * to prepare the NetworkInterface object for polling.</P>
	 *
	 * @param iface		The network interface to be added to the scheduler.
	 *
	 * @exception org.opennms.bb.dp.poller.plugins.ServiceMonitorException	Thrown if
	 * 	an unrecoverable error occurs that prevents the interface from being monitored.
	 *
	 */
	public void initialize(NetworkInterface iface) 
		throws ServiceMonitorException
	{
	 	return;
	}
	
	/**
	 * <P>Called by the poller framework when an interface is being removed from
	 * the scheduler.  Here we free any resources or save any persistent 
	 * information associated with the interface.</P>
	 *
	 * <P>If an exception is thrown during the release the exception will be
	 * logged, but the interface will still be discarded for garbage collection.</P>
	 *
	 * @param iface		The network interface that was being monitored.
	 *
	 * @exception org.opennms.bb.dp.poller.plugins.ServiceMonitorException	Thrown if
	 * 	an unrecoverable error occurs for the interface.
	 */
	public void release(NetworkInterface iface) 
		throws ServiceMonitorException
	{
		return;
	}
	
	/**
	 * <P>Poll the specified address for HTTP service availability</P>
	 *
	 * <P>During the poll an attempt is made to connect on the specified
	 * port(s) (by default TCP ports 80, 8080, 8888).  If the connection
	 * request is successful, an HTTP 'GET' command is sent to the interface.
	 * The response is parsed and a return code extracted and verified.  
	 * Provided that the interface's response is valid we set the service 
	 * status to SERVICE_AVAILABLE and return.</P>
	 *
	 * @param iface		The network interface to test the service on.
	 * @param eproxy 	The event proxy object for sending custom events.
	 * @param parameters	The package parameters (timeout, retry, etc...) to be 
	 *  used for this poll.
	 *
	 * @return The availibility of the interface and if a transition event
	 * 	should be supressed.
	 *
	 */
	public int poll(NetworkInterface iface, EventProxy eproxy, Properties parameters) 
		throws ServiceMonitorException
	{
		int serviceStatus = SERVICE_UNAVAILABLE;
		Socket  portal    = null;
		InetAddress inetAddr = null;

		int retry = DEFAULT_RETRY;		// Number of additional attempts to be made.
		int[] ports = DEFAULT_PORTS;	// Ports which will be tested for HTTP service.
		int timeout = DEFAULT_TIMEOUT;  // How long to block waiting for data (in milliseconds).
		String url = DEFAULT_URL;		// URL to "GET"
		int response = -1;				// Expected 'GET' command response return code
		String responseText; 			// A text string that must be present in the content of the retrieved URL

	 	// Set to true if "response" property has a valid return code specified.
	 	//  By default response will be deemed valid if the return code 
	 	//  falls in the range:   100 < rc < 500
	 	//  This is based on the following information from RFC 1945 (HTTP 1.0)
	 	// 		HTTP 1.0 GET return codes:
	 	//		 	1xx: Informational - Not used, future use
	 	//			2xx: Success
	 	//			3xx: Redirection
	 	//			4xx: Client error
	 	//			5xx: Server error
		boolean bStrictResponse = false;

		//
		// Process parameters
		//
	
		// Retry
		String strRetry = parameters.getProperty("retry");
		if(strRetry != null)
		{
			try	{ retry = Integer.parseInt(strRetry);	}
			catch(NumberFormatException ne) { retry = DEFAULT_RETRY; }	
		} 
		
		// Ports
		ports = new int[2];
		ports[0] = 0;
		ports[1] = 0;
		int index = 0;

		try 
		{
			String strPort = parameters.getProperty("port");
			if (strPort != null) 
				ports[index++] = Integer.parseInt(strPort);

			String strAltPort = parameters.getProperty("alternate port");
			if (strAltPort != null) 
				ports[index++] = Integer.parseInt(strAltPort);
		}	
		catch (NumberFormatException ne)
		{
			ports = DEFAULT_PORTS;
		}

		// URL
		url = parameters.getProperty("url");
		if(url == null)
			url = DEFAULT_URL;

		// Response
		String strResponse = parameters.getProperty("response");
		if(strResponse != null)
		{
			try	
			{ 
				response = Integer.parseInt(strResponse);	
				bStrictResponse = true;
			}
			catch(NumberFormatException ne) { bStrictResponse = false; }	
		} 

		// Response Text
		responseText = parameters.getProperty("response text");
		
		// Timeout
		String strTimeout = parameters.getProperty("timeout");
		if (strTimeout == null)
			timeout = DEFAULT_TIMEOUT;
	    else
		{
			try
			{
				timeout = (int)convertTimeToLong(strTimeout);
			}
			catch(NumberFormatException ne) { timeout = DEFAULT_TIMEOUT; }
		}

		//
		// Get interface address from NetworkInterface
		//
		if (iface.getType() != iface.TYPE_IPV4)
			throw new ServiceMonitorException("Unsupported interface type, only TYPE_IPV4 currently supported");

		IPv4Address ipv4Addr = (IPv4Address)iface.getAddress();

		try
		{
			// Convert address to InetAddress for use in socket() call
			inetAddr = InetAddress.getByName(ipv4Addr.toString());
		}
		catch(Exception e)
		{
			return serviceStatus;
		}
	
		Log.print(Log.DEBUG, "ServiceMonitorHTTP.poll: address: " + ipv4Addr.toString() + " timeout: " + timeout + " retry: " + retry);
		for (int portIndex=0; portIndex<ports.length && serviceStatus != SERVICE_AVAILABLE; portIndex++)
		{
			// Is there a valid port at this index?
			if (ports[portIndex] == 0)
				continue;

			for (int attempts=0; attempts <= retry && serviceStatus != SERVICE_AVAILABLE; attempts++)
			{
				try
				{
					//
					// create a connected socket
					//
					portal = new Socket(inetAddr, ports[portIndex]);
					portal.setSoTimeout(timeout);
					
					//
					// Issue HTTP 'GET' command and check the return code in the response
					//
					String cmd = "GET " + url + " HTTP/1.0\r\n\r\n";
					Log.print(Log.DEBUG, "ServiceMonitorHTTP.poll: HTTP cmd text: " + cmd); // DEBUG
					portal.getOutputStream().write(cmd.getBytes());
			
					String line = getLine(portal.getInputStream());
					Log.print(Log.DEBUG, "ServiceMonitorHTTP.poll: HTTP response: " + line); // DEBUG
					if(line.startsWith("HTTP/"))
					{
						StringTokenizer t = new StringTokenizer(line);
						t.nextToken();
						int rVal = Integer.parseInt(t.nextToken());
						Log.print(Log.DEBUG, "ServiceMonitorHTTP.poll: Expected response: " + response); // DEBUG
						if (bStrictResponse)
						{
							if (rVal == response)
								serviceStatus = SERVICE_AVAILABLE;	
						}
						else
						{
							if(rVal > 100 && rVal < 500)
								serviceStatus = SERVICE_AVAILABLE;
						}
					}
	
					if (responseText != null)
					{
						Log.print(Log.DEBUG, "ServiceMonitorHTTP.poll: Expected response text: " + responseText); // DEBUG

						// This loop will rip through the rest of the Response Header
						do {
							line = getLine(portal.getInputStream());
							//Log.print(Log.DEBUG, "ServiceMonitorHTTP.poll: HTTP response: " + line); // DEBUG
						} while (line.length() != 0);
						
						// Now lets rip through the Entity-Body (i.e., content) looking
						// for the required text.
						boolean bResponseTextFound = false;
						do {
							line = getLine(portal.getInputStream());
							int responseIndex = line.indexOf(responseText);
							if (responseIndex != -1)
							{
								Log.print(Log.DEBUG, "ServiceMonitorHTTP.poll: Found response text."); //DEBUG
								bResponseTextFound = true;
							}	
							//Log.print(Log.DEBUG, "ServiceMonitorHTTP.poll: HTTP response: " + line); // DEBUG
						} while (line.length() != 0 && !bResponseTextFound);

						if (!bResponseTextFound)
						{
							serviceStatus = SERVICE_UNAVAILABLE;
							Log.print(Log.DEBUG, "ServiceMonitorHTTP.poll: Response text not found."); //DEBUG
						}
					}

				}
				catch(NumberFormatException e)
				{
					// Ignore
				}
				catch(IOException e)
				{
					// Ignore
					Log.print(Log.DEBUG, "ServiceMonitorHTTP.poll: IOException while polling address '" + ipv4Addr.toString() + "': " + e);
				}
				finally
				{
					try
					{
						if(portal != null)
							portal.close();
					}
					catch(Exception e) 
					{ 
						// Ignore
					}
				}
			}
		}
	
		//
		// return the status of the service
		//
		return serviceStatus;
	}

	/**
	 * <P>Reads a single line at a time from the input stream. Each line
	 * is terminated by the sequence </EM>'\r\n'</EM>. For more information
	 * on the format of the line see the HTTP RFC.</P>
	 *
	 * <P>If the end of file condition is reached before the cariage-return
	 * line-feed sequence then the received buffer is returned, or a string
	 * of zero length.</P>
	 *
	 * <P><EM>NOTE</EM>: The \r\n sequence is stripped from the returned line.</P>
	 *
	 * @param istream	The input stream from which characters are to be read.
	 *
	 * @return A line of characters read off the input stream.
	 *
	 * @exception java.lang.IOException Thrown if an error occurs reading
	 * 	the data from the stream.
	 */
	private String getLine(InputStream istream) 
		throws IOException
	{
		StringBuffer sbuf = new StringBuffer();
		
		boolean done = false;
		while(!done)
		{
			//
			// get the next character from the
			// stream. Ignore the EOF for now
			//
			int i = istream.read();
			if(i == -1)
			{
				done=true;
				continue;
			}
			
			//
			// check for a cariage return
			// character and scan for the
			// newline.
			while(i == (int)'\r')
			{
				i = istream.read();
				if(i == -1)
				{
					sbuf.append('\r');
					done = true;
					break;
				}
				else if(i == '\n')
				{
					return sbuf.toString();
				}
				sbuf.append('\r');
			}

			//
			// if the end of line is not reached
			// then add the character to the buffer.
			// this will include any character received
			// from the above while loop if the \r is not
			// followed by the \n character.
			//
			if(!done)
			{
				sbuf.append((char)i);
			}
		}
		
		return sbuf.toString();
	}

	
	/**
	 * <P>Converts the passed time string to a time value that is 
	 * measured in milliseconds. The following extension are considered
	 * when converting the string:</P>
	 *
	 * <TABLE BORDER=0>
	 *	<TR><TH>Extension</TH><TH>Conversion Value</TH></TR>
	 *	<TR><TD>us</TD><TD>Microseconds</TD></TR>
	 *	<TR><TD>ms</TD><TD>Milliseconds</TD></TR>
	 *	<TR><TD>s</TD><TD>Seconds</TD></TR>
	 *	<TR><TD>m</TD><TD>Minutes</TD></TR>
	 *	<TR><TD>h</TD><TD>Hours</TD></TR>
	 *	<TR><TD>d</TD><TD>Days</TD></TR>
	 * </TABLE>
	 *
	 * <P>A number entered with out any units is considered to be
	 * in milliseconds.</P>
	 *
	 * @param valueToConvert	The string to convert to milliseconds.
	 *
	 * @return Returns the string converted to a millisecond value.
	 *
	 * @exception java.lang.NumberFormatException Thrown if the string is
	 * 	malformed and a number cannot be extracted from the value.
	 *
	 */
	private static long convertTimeToLong(String valueToConvert)
		throws NumberFormatException
	{
		String timeVal = valueToConvert.toLowerCase();
		int   index    = 0;
		float factor   = 1.0f;

		if(timeVal.endsWith("us"))
		{
			factor = 0.001f;
			index  = timeVal.indexOf("us");
		}
		else if(timeVal.endsWith("ms"))
		{
			factor= 1.0f;
			index = timeVal.indexOf("ms");
		}
		else if(timeVal.endsWith("s"))
		{
			factor = 1000.0f;
			index = timeVal.indexOf("s");
		}
		else if(timeVal.endsWith("m"))
		{
			factor = 1000.0f * 60.0f;
			index = timeVal.indexOf("m");
		}
		else if(timeVal.endsWith("h"))
		{
			factor = 1000.0f * 60.0f * 60.0f;
			index = timeVal.indexOf("h");
		}
		else if(timeVal.endsWith("d"))
		{
			factor = 1000.0f * 60.0f * 60.0f * 24.0f;
			index = timeVal.indexOf("d");
		}
		
		if(index == 0)
		{
			index = timeVal.length();
		}
		
		Float fVal = new Float(timeVal.substring(0, index));
		return ((long)(fVal.floatValue() * factor));
		
	} // end convertTimeToLong()
}

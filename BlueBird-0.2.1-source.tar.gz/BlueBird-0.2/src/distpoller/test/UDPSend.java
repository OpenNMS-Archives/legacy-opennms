package test;

import java.io.*;
import java.net.*;

import com.sun.media.jsdt.*;

import org.opennms.bb.common.components.*;
import org.opennms.bb.dp.common.components.*;

/**
 * This class sends the specified text or file as a UDP packet to the 
 * specified port of the specified host.
 *
 * @author Sowmya 
 *
 */
public class UDPSend 
{

	/**
	 * Port on which Listener accepts UDP connections 
	 */
	private final static int EVENTD_UDP_PORT = 5817;
	
	/**
	 * UDP socket to which events are sent
	 */
	private static DatagramSocket		m_server;


	public UDPSend() throws SocketException
	{
		//
		// Create UDP socket 
		//
		m_server    = new DatagramSocket();

	}

	/**
	 * Read the event xml from the file specified and send it to
	 * eventd via JSDT
	 */
	public static void main(String args[]) 
	{
		/*
	 	 * the length to be read each time while reading the file
	 	 */
		int	READ_LEN=1024;

		try 
		{

			// Check the number of arguments
			if (args.length != 2) 
				throw new IllegalArgumentException("Wrong number of arguments");
			
			ByteArrayOutputStream xmlStr = new ByteArrayOutputStream();
			if (args[0].equals("-f")) 
			{
				/**
			 	 * Check if file exists, if not, throw an error
				 */
				File	fileDes    = new File(args[1]);
				
				if (!fileDes.exists())
				{
					throw new IOException("File " + args[1] + " does not exist");
				}

				int	fileLen	   = (int)fileDes.length();

				FileInputStream in = new FileInputStream(fileDes);

				int bytesInThisRead	= 0;

				// loop until we've read it all
				do 
				{
					byte[]  message = new byte[READ_LEN];

					bytesInThisRead = in.read(message);

					// append to xml string
					if (bytesInThisRead > 0)
					{
						xmlStr.write(message, 0, bytesInThisRead);
					}
	
				} while(bytesInThisRead != -1);

				System.out.println("fileLen/lenRead: " + fileLen + "/" + xmlStr.toByteArray().length);
			}
			

			// create the JSDT channel and send
			Log.print(Log.INFORMATIONAL, "data sent: " + xmlStr.toString());

			Log.print(Log.INFORMATIONAL, "creating datagram socket...");
			UDPSend send = new UDPSend();

			// Get hostname of local machine for future DNS lookups
			InetAddress localHost;
			try 
			{
				localHost = InetAddress.getLocalHost();
			}
			catch(UnknownHostException ukE)
			{
				//
				// Recast the exception as a Service Monitor Exception
				//
				throw new RuntimeException("Get local host address generated unknown host exception: " + ukE.getMessage());
			}
			
			Log.print(Log.INFORMATIONAL, "creating datagram packet...");
			DatagramPacket packet = new DatagramPacket(xmlStr.toByteArray(), xmlStr.size(), localHost, EVENTD_UDP_PORT);

			try
			{
				m_server.send(packet);
			}
			catch (IOException ioe)
			{
				throw new RuntimeException("IO exception sending packet: " + ioe.getMessage());
			}

			//Data data = new Data(xmlStr.toByteArray());
			//m_channel.sendToAll(m_client, data);

		}
		catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}
}

package test;

import java.io.*;
import java.net.*;

import com.sun.media.jsdt.*;

import org.opennms.bb.common.components.*;
import org.opennms.bb.dp.common.components.*;

/**
 * This class sends the specified text or file as a JSDT packet to the 
 * specified port of the specified host.
 *
 * @author Sowmya 
 *
 */
public class JSDTSend 
{
	/**
	 * The JSDT client class that is the identifier for this
	 */
	private static PollerClient 	m_client;

	/**
	 * The JSDT session on which messages are sent to eventd
	 */
	private Session		m_session;

	/**
	 * The JSDT channel on which eventd is listening for messages
	 */
	private static Channel		m_channel;


	public JSDTSend()
	{
		//
		// Create the JSDT communication path to send events
		//
		try
		{
			if(!jsdtConnect("TrapdSend"))
			{
				Log.print(Log.FATAL, "Trapd: Unable to create JSDT communication path");
				throw new RuntimeException("Unable to connect to JSDT Registry");
			}
		}
		catch(InterruptedException e)
		{
			throw new RuntimeException("The jsdt connection thread was interrupted");

		}

	}

	/**
	 * Connect to the eventd JSDT channel
	 *
	 * @param clientName 	The name of this client
	 *
	 * @throws java.lang.InterruptedException Thrown if the running
	 * 	thread is interrupted by another thread.
	 */
	 private boolean jsdtConnect(String clientName) throws InterruptedException
	 {
		boolean sessionExists = false;
		boolean connected = false;

		try
		{

 			URLString url = URLString.createSessionURL(PollerJSDTConstants.HOSTNAME, 
									 PollerJSDTConstants.EVENTS_SESSION_PORT,
									 PollerJSDTConstants.REGISTRY_TYPE, 
									 PollerJSDTConstants.EVENTS_SESSION_NAME);
			while (!sessionExists) 
			{
				try 
				{
					if (SessionFactory.sessionExists(url)) 
					{
																	sessionExists = true;
					}
				} 
				catch (NoRegistryException nre) 
				{
					Thread.sleep(1000);
				} 
				catch (ConnectionException ce) 
				{
					Thread.sleep(1000);
				}
			} 

			m_client  = new PollerClient(clientName);
			m_session = SessionFactory.createSession(m_client, url, true);
			m_channel = m_session.createChannel(m_client, 
							PollerJSDTConstants.EVENTS_SOURCE_CHANNEL,
							//PollerJSDTConstants.EVENTS_SINK_CHANNEL,
							true, 
							false, 
							true);
			connected = true;
		} 
		catch (JSDTException e)
		{
			Log.print(Log.FATAL, e.getMessage());
			connected = false;
		}

		return connected;
	}

	/**
	 * Read the event xml from the file specified and send it to
	 * eventd via JSDT
	 */
	public static void main(String args[]) 
	{
		/*
	 	 * the length to be read each time while reading the file
	 	 */
		int	READ_LEN=1024;

		try 
		{

			// Check the number of arguments
			if (args.length != 2) 
				throw new IllegalArgumentException("Wrong number of arguments");
			
			ByteArrayOutputStream xmlStr = new ByteArrayOutputStream();
			if (args[0].equals("-f")) 
			{
				/**
			 	 * Check if file exists, if not, throw an error
				 */
				File	fileDes    = new File(args[1]);
				
				if (!fileDes.exists())
				{
					throw new IOException("File " + args[1] + " does not exist");
				}

				int	fileLen	   = (int)fileDes.length();

				FileInputStream in = new FileInputStream(fileDes);

				int bytesInThisRead	= 0;

				// loop until we've read it all
				do 
				{
					byte[]  message = new byte[READ_LEN];

					bytesInThisRead = in.read(message);

					// append to xml string
					if (bytesInThisRead > 0)
					{
						xmlStr.write(message, 0, bytesInThisRead);
					}
	
				} while(bytesInThisRead != -1);

				System.out.println("fileLen/lenRead: " + fileLen + "/" + xmlStr.toByteArray().length);
			}
			

			// create the JSDT channel and send
			Log.print(Log.INFORMATIONAL, "data sent: " + xmlStr.toString());

			JSDTSend send = new JSDTSend();
			Data data = new Data(xmlStr.toByteArray());
			m_channel.sendToAll(m_client, data);
		}
		catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}
}

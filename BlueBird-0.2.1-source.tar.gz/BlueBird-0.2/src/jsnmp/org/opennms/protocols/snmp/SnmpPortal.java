// 
//    JoeSNMP - SNMPv1 & v2 Compliant Libraries for Java
//    Copyright (C) 2000  PlatformWorks, Inc.
//
//    This library is free software; you can redistribute it and/or
//    modify it under the terms of the GNU Lesser General Public
//    License as published by the Free Software Foundation; either
//    version 2.1 of the License, or (at your option) any later version.
//
//    This library is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
//    Lesser General Public License for more details.
//
//    You should have received a copy of the GNU Lesser General Public
//    License along with this library; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//   
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
// $Id: SnmpPortal.java,v 1.7 2000/10/31 22:11:47 ben Exp $

// Log:
//	6/8/00 - Weave
//		Found a bug where the InetAddress object was being
//		passed to the handler from the incorrect source. The
//		address was being passed from the comm channel, and not
//		the datagram packet as it should have been.
//

package org.opennms.protocols.snmp;

import java.lang.*;
import java.net.*;
import java.io.*;
import java.util.*;

import org.opennms.protocols.snmp.*;
import org.opennms.protocols.snmp.asn1.*;


/**
 * Abstracts the communication related details from the SnmpSession and
 * SnmpTrapSession.
 *
 * @author <a href="mailto:weave@opennms.org">Brian Weaver</a>
 * @author <a href="http://www.opennms.org">OpenNMS</a>
 * @author Sowmya
 * @version $Revision: 1.7 $ $Date: 2000/10/31 22:11:47 $
 *
 * @see SnmpSession
 * @see SnmpTrapSession
 * @see java.net.DatagramSocket
 */
class SnmpPortal extends Object
{
	/** 
	 * The packet handler that is used to process
	 * received SNMP packets and invalid datagrams.
	 * The handler must also process any exceptions
	 * that occurs in the receiving thread.
	 *
	 */
	private SnmpPacketHandler m_handler;

	/**
	 * The datagram socket used to send and receive
	 * SNMP messages.
	 *
	 */
	private DatagramSocket m_comm;

	/**
	 * the receiver thread that runs the inner class Receiver.
	 */
	private Thread m_recvThread;

	/**
	 * ASN.1 encoder used to decode the SNMP messages.
	 * If the decoded fails to decode the specific messages
	 * the is should throw and appropiate ASN.1 exception
	 *
	 */
	private AsnEncoder m_encoder;

	/**
	 * When set the portal object's close method has been
	 * invoked. This is needed since the internal receiver
	 * thread will block on the communication channel. To 
	 * "wake" the thread the close() method on the comm channel
	 * is performed. This will cause an exception to be genereated
	 * in the receiver thread. If the value of m_isClosing is true
	 * then the exception is ignored.
	 */
	private boolean m_isClosing;

	/**
	 * Private constructor used to disallow the 
	 * default constructor.
	 *
	 * @exception java.lang.UnsupportedOperationException Always thrown!
	 */
	private SnmpPortal() 
		throws java.lang.UnsupportedOperationException
	{
		throw new java.lang.UnsupportedOperationException("Illegal constructor call");
	}

	/**
	 * The SnmpPortal constructor. The constructor is used to build a portal
	 * on the specified port, and forward messages to the defined handler.
	 * All messages are decoded using the encoder specified during construction.
	 *
	 * @param handler	The SNMP packet handler.
	 * @param encoder	The ASN.1 codec object.
	 * @param port		The port to send and receive datagram from.
	 *
	 * @exception java.net.SocketException Thrown if an error occurs setting
	 *	up the communication channel.
	 * @exception java.lang.IllegalArgumentException Thrown if any of the parameters
	 *	are null or invalid.
	 *
	 */
	SnmpPortal(SnmpPacketHandler handler, AsnEncoder encoder, int port) 
		throws SocketException
	{
		if(handler == null || encoder == null || port < 0)
			throw new IllegalArgumentException("Invalid argument");

		m_handler    = handler;
		m_comm       = new DatagramSocket(port);
		m_isClosing  = false;

		m_recvThread = new Thread(new Receiver());
		m_encoder    = encoder;

		m_recvThread.start();

	}


	/**
	 * Defines the inner class that monitors the 
	 * datagram socket and receives all the PDU responses.
	 * If an exception is generated then it is saved 
	 * in m_why and can be re-generated with a call
	 * to raise().
	 *
	 */
	private class Receiver implements Runnable
	{
		/**
	 	 * Called to setup the communications channel buffers.
	 	 * The method attempts to set the received buffer size
	 	 * to 16k. If it fails then the default buffer size
	 	 * is recovered. If the default buffer size cannot be
	 	 * recovered then a zero is returned. 
	 	 *
	 	 * @return The communications channel receive buffer size.
	 	 *	A zero is returned on error
	 	 */
		private int setup() 
		{
			int bufSz = 16*1024;
	
			//
			// set the receiver buffer
			//
			try
			{
				m_comm.setReceiveBufferSize(bufSz);
			}
			catch(SocketException err)
			{
				bufSz = 0;
			}
	
			if(bufSz == 0)
			{
				try
				{
					bufSz = m_comm.getReceiveBufferSize();
				}
				catch(SocketException err)
				{
					bufSz = 0;
				}
			}
			return bufSz;
		}

		/**
		 * The run method is an infinite loop method that
		 * receives all datagrams for the session. If an
		 * unrecoverable error occurs then the m_handler is
		 * informed of the error
		 *
		 * If a pdu is recovered from the channel then the associated
		 * handler is invoked to process the pdu.
		 *
		 * @see SnmpPacketHandler
		 */
		public void run()
		{
			int bufSz = setup();
			if(bufSz == 0)
			{
				return;
			}
		
			//
			// get a buffer for the datagrams
			//
			byte[] buf = new byte[bufSz];
			DatagramPacket pkt = new DatagramPacket(buf, bufSz);
			while(!m_isClosing)
			{
				try
				{
					//
					// reset the packet's length
					//
					pkt.setLength(bufSz);
					m_comm.receive(pkt);
					handlePkt(pkt);
				}
				catch(SnmpPduEncodingException err)
				{
					m_handler.processBadDatagram(pkt);
				}
				catch(AsnDecodingException err)
				{
					m_handler.processBadDatagram(pkt);
				}
				catch(Exception e)
				{
					//System.out.println("Caught Exception: " + e.getMessage());
					//e.printStackTrace(System.out);
					
					if(!m_isClosing)
						m_handler.processException(e);
				}
			}
		} // end run()
		
	}


	/**
	 * Recovers a SnmpPduPacket or SnmpPduTrap from the passed datagram
	 * and calls the appropriate method in the handler.
	 *
	 * If an error occurs recovering the packet then an exception is 
	 * generated. The pdu can be one of SnmpPduRequest or SnmpPduBulk. 
	 * The internal session AsnEncoder defined in the SnmpParameters is 
	 * used to recover the pdu.
	 *
	 * @param pkt	The datagram packet to be decoded
	 *
	 * @exception SnmpPduEncodingException	Thrown if a pdu or session level error occurs
	 * @exception AsnDecodingException	Thrown if the AsnEncoder encounters an error
	 *
	 * @see SnmpPduTrap
	 * @see SnmpPduPacket
	 * @see SnmpPduRequest
	 * @see SnmpPduBulk
	 * @see SnmpParameters
	 * @see org.opennms.protocols.snmp.asn1.AsnEncoder
	 *
	 */
	void handlePkt(DatagramPacket pkt) 
		throws	SnmpPduEncodingException, AsnDecodingException
	{
		//
		// first decode the header
		//
		byte[] buf = pkt.getData();
		int offset = 0;


		//
		// Decode the ASN.1 header from the front
		// of the SNMP message.
		//
		Object[] rVals = m_encoder.parseHeader(buf, offset);
		
		//
		// get the return vals
		//
		offset		= ((Integer)rVals[0]).intValue();
		byte asnType	= ((Byte)rVals[1]).byteValue();
		int asnLength	= ((Integer)rVals[2]).intValue();

		//
		// check the ASN.1 Type
		//
		if(asnType != (ASN1.SEQUENCE | ASN1.CONSTRUCTOR))
			throw new AsnDecodingException("Invalid SNMP ASN.1 type");

		//
		// Check the length of the datagram packet
		//
		if(asnLength > pkt.getLength() - offset)
		{
			throw new SnmpPduEncodingException("Insufficent data in packet");
		}

		//
		// get the snmp version.
		//
		SnmpInt32 int32 = new SnmpInt32();
		offset = int32.decodeASN(buf, offset, m_encoder);
		
		//
		// check the version
		// 
		if(int32.getValue() != SnmpSMI.SNMPV1 && int32.getValue() != SnmpSMI.SNMPV2)
		{
			throw new SnmpPduEncodingException("Invalid protocol version");
		}

		//
		// need to get the community
		// Postpone the community check until the pdu
		// has been recovered to determine which community
		// string needs to be verified against.
		//
		SnmpOctetString community = new SnmpOctetString();
		offset = community.decodeASN(buf, offset, m_encoder);
		
		//
		// get the pdu header, but DO NOT modify the offset
		// in effect we are peeking into the remainder of the
		// packet
		//
		rVals = m_encoder.parseHeader(buf, offset);

		//
		// The command should be sign extended to a 
		// negative number. Thus add 256 to wrap it
		//
		int cmd = ((Byte)rVals[1]).intValue() + 256;
		
		//
		// Now process the Protocol Data Unit
		//
		switch(cmd)
		{
		case SnmpPduPacket.SET:
		case SnmpPduPacket.GET:
		case SnmpPduPacket.GETNEXT:
		case SnmpPduPacket.RESPONSE:
		case SnmpPduPacket.INFORM:
		case SnmpPduPacket.V2TRAP:
		case SnmpPduPacket.REPORT:
			{
				SnmpPduPacket pdu = new SnmpPduRequest();
				offset = pdu.decodeASN(buf, offset, m_encoder);
				m_handler.processSnmpMessage(pkt.getAddress(),		// From Who?
							     pkt.getPort(),		// What Port?
							     int32,			// What Version
							     community,			// Community
							     cmd,			// Snmp Command (Wrapped!)
							     pdu);			// The Protocol Data Unit
			}
			break;

		case SnmpPduPacket.GETBULK:
			{
				SnmpPduPacket pdu = new SnmpPduBulk();
				offset = pdu.decodeASN(buf, offset, m_encoder);
				m_handler.processSnmpMessage(pkt.getAddress(),		// From Who?
							     pkt.getPort(),		// Port
							     int32,			// Version
							     community,			// Community
							     cmd,			// Command (positive wrapped)
							     pdu);			// Protocol Data Unit
			}
			break;

		case SnmpPduTrap.TRAP:
			{
				SnmpPduTrap trap=new SnmpPduTrap();
				offset = trap.decodeASN(buf, offset, m_encoder);
				m_handler.processSnmpTrap(pkt.getAddress(),
							  pkt.getPort(),
							  community,
							  trap);
			}
			break;

		default:
			throw new SnmpPduEncodingException("No matching PDU type found");
		}
	}

	/**
	 * Transmits the passed buffer to the respective peer 
	 * agent. If a failure occurs then an IOException is
	 * thrown.
	 *
	 * @param peer		The SNMP peer destination
	 * @param buf		The buffer to transmit.
	 * @param length	The valid length of the buffer
	 *
	 * @exception java.lang.IOException For more details see
	 *	java.net.DatagramSocket.
	 *
	 * @see java.net.DatagramSocket
	 *
	 */
	void send(SnmpPeer peer, byte[] buf, int length)
		throws java.io.IOException
	{
		//
		// create a new datagram packet
		//
		DatagramPacket pkt = new DatagramPacket(buf, 
							length,
							peer.getPeer(),
							peer.getPort());
		
		m_comm.send(pkt);
		
	}

	/**
	 * Transmits the passed buffer to the respective peer 
	 * agent. If a failure occurs then an IOException is
	 * thrown.
	 *
	 * @param peer		The SNMP peer destination
	 * @param buf		The buffer to transmit.
	 *
	 * @exception java.lang.IOException For more details see
	 *	java.net.DatagramSocket.
	 *
	 * @see java.net.DatagramSocket
	 *
	 */
	void send(SnmpPeer peer, byte[] buf)
		throws java.io.IOException
	{
		send(peer, buf, buf.length);
	}

	/**
	 * Sets the default SnmpPacketHandler.
	 *
	 * @param hdl	The new handler
	 *
	 */
	void setPacketHandler(SnmpPacketHandler hdl)
	{
		if(hdl == null)
			throw new IllegalArgumentException("The packet handler must not be null");

		m_handler = hdl;
	}

	/**
	 * Gets the default SnmpPacketHandler for the session. 
	 *
	 * @return the SnmpPacketHandler
	 */
	SnmpPacketHandler getPacketHandler()
	{
		return m_handler;
	}

	/**
	 * Sets the default encoder.
	 *
	 * @param encoder	The new encoder
	 *
	 */
	void setAsnEncoder(AsnEncoder encoder)
	{
		if(encoder == null)
			throw new IllegalArgumentException("The ASN.1 codec must not be null");

		m_encoder = encoder;
	}

	/**
	 * Gets the AsnEncoder for the session. 
	 *
	 * @return the AsnEncoder
	 */
	AsnEncoder getAsnEncoder()
	{
		return m_encoder;
	}

	/**
	 * Used to close the session. Once called the session should
	 * be considered invalid and unusable.
	 *
	 */
	void close()
	{
		m_isClosing = true;
		m_comm.close();

		try
		{
			//
			// make sure that the caller thread
			// is not the one we are trying to 
			// join!
			//
			if(m_recvThread.equals(Thread.currentThread()) == false)
			{
				m_recvThread.join();
			}
		}
		catch(InterruptedException err)
		{
			// do nothing
		}
	}
}

// 
//    JoeSNMP - SNMPv1 & v2 Compliant Libraries for Java
//    Copyright (C) 2000  PlatformWorks, Inc.
//
//    This library is free software; you can redistribute it and/or
//    modify it under the terms of the GNU Lesser General Public
//    License as published by the Free Software Foundation; either
//    version 2.1 of the License, or (at your option) any later version.
//
//    This library is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
//    Lesser General Public License for more details.
//
//    You should have received a copy of the GNU Lesser General Public
//    License along with this library; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//   
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
// $Id: SnmpIPAddress.java,v 1.3 2000/10/31 22:11:47 ben Exp $
//
//

//
// Log:
//
//	5/15/00 - Weave
//		Added the toString() method
//

package org.opennms.protocols.snmp;

import java.lang.*;
import java.net.*;

import org.opennms.protocols.snmp.SnmpSMI;
import org.opennms.protocols.snmp.SnmpOctetString;
import org.opennms.protocols.snmp.SnmpUtil;
import org.opennms.protocols.snmp.SnmpBadConversionException;

import org.opennms.protocols.snmp.asn1.AsnEncoder;
import org.opennms.protocols.snmp.asn1.AsnEncodingException;
import org.opennms.protocols.snmp.asn1.AsnDecodingException;

import org.opennms.protocols.ip.IPv4Address;

/**
 * This SnmpIPAddress is used to extend the Snmp 
 * Octet String SMI class. This is normally used to transmit
 * IP Addresses with a length of 4 bytes. 
 *
 * Most of the management of the data is handled by the
 * base class.
 *
 * @version	$Revision: 1.3 $
 * @author	<a href="mailto:weave@opennms.org>Brian Weaver</a>
 *
 */
public class SnmpIPAddress extends SnmpOctetString
{
	/**
	 * Required for evolving serialization format.
	 */
	static final long serialVersionUID = -4375760318106654741L;

	/**
	 * Defines the ASN.1 type for this object.
	 */
	public static final byte ASNTYPE = SnmpSMI.SMI_APPSTRING;

	/**
	 * Constructs a default object with a 
	 * length of zero. See the super class
	 * constructor for more details.
	 *
	 */
	public SnmpIPAddress( )
	{
		byte[] tmp = { 0, 0, 0, 0 };
		setString(tmp);
	}

	/**
	 * Constructs an Application String with the
	 * passed data. The data is managed by the 
	 * base class.
	 *
	 * @param data	The application string to manage (UTF-8)
	 */
	public SnmpIPAddress(byte[] data)
	{
		super(data);
	}
	
	/**
	 * Copy constructor. Constructs a duplicate object 
	 * based on the passed application string object.
	 *
	 * @param second The object to copy.
	 *
	 */
	public SnmpIPAddress(SnmpIPAddress second)
	{
		super(second);
	}

	/**
	 * Copy constructor based on the base class.
	 *
	 * @param second	The object to copy
	 *
	 */
	public SnmpIPAddress(SnmpOctetString second)
	{
		super(second);
	}

	/**
	 * Returns the ASN.1 type for this object.
	 *
	 * @return The ASN.1 value for this object.
	 *
	 */
	public byte typeId()
	{
		return SnmpSMI.SMI_APPSTRING;
	}

	/**
	 * Create a new object that is a duplicate of the
	 * current object.
	 *
	 * @return A newly created duplicate object.
	 *
	 */
	public SnmpSyntax duplicate() 
	{
		return new SnmpIPAddress(this);
	}

	/**
	 * Create a new object that is a duplicate of the
	 * current object.
	 *
	 * @return A newly created duplicate object.
	 *
	 */
	public Object clone()
	{
		return new SnmpIPAddress(this);
	}

	/**
	 * Converts the current Application String to 
	 * an IPv4Address object. If the length is not
	 * four bytes in length or an error occurs during
	 * the conversion then an exception is thrown.
	 *
	 * @return The IPv4Address converted from the appliation
	 *	string
	 *
	 * @exception SnmpBadConversionException Thrown if the length of the string
	 *		is invalid. Must be equal to four
	 *
	 */
	public IPv4Address convertToIpAddress( )
		throws SnmpBadConversionException
	{
		byte[] data = getString();
		if(data == null || data.length != 4)
			throw new SnmpBadConversionException("Invalid IP Address Length");

		return new IPv4Address(data);
	}

	/**
	 * Returns the application string as a
	 * IPv4 dotted decimal address
	 */
	public String toString()
	{
		return IPv4Address.addressToString(getString());
	}
		
}

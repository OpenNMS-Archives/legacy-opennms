//
//    JoeSNMP - SNMPv1 & v2 Compliant Libraries for Java
//    Copyright (C) 2000  PlatformWorks, Inc.
//
//    This library is free software; you can redistribute it and/or
//    modify it under the terms of the GNU Lesser General Public
//    License as published by the Free Software Foundation; either
//    version 2.1 of the License, or (at your option) any later version.
//
//    This library is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
//    Lesser General Public License for more details.
//
//    You should have received a copy of the GNU Lesser General Public
//    License along with this library; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//   
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
// $Id: SnmpCounter32.java,v 1.7 2000/10/31 22:11:47 ben Exp $
//
//

package org.opennms.protocols.snmp;

import java.lang.*;

import org.opennms.protocols.snmp.SnmpSMI;
import org.opennms.protocols.snmp.SnmpUInt32;
import org.opennms.protocols.snmp.SnmpUtil;

import org.opennms.protocols.snmp.asn1.AsnEncoder;
import org.opennms.protocols.snmp.asn1.AsnEncodingException;
import org.opennms.protocols.snmp.asn1.AsnDecodingException;

/**
 * Defines a SNMPv1 32-bit counter object. The object is a 
 * 32-bit unsigned value that is incremented periodically
 * by an agent normally. 
 *
 * The object inherients and uses most of the methods defined
 * by the SnmpUInt32 class. This class does not define any 
 * specific data, but is instead used to override the ASN.1 type
 * of the base class.
 *
 * @version $Revision: 1.7 $
 * @author  <a href="mailto:weave@opennms.org">Brian Weaver</a>
 */
public class SnmpCounter32 extends SnmpUInt32
{
	/**
	 * required for version control of serialization.
	 *
	 */
	static final long serialVersionUID = -5722134291677293080L;

	/**
	 * Defines the ASN.1 type for this object.
	 *
	 */
	public static final byte ASNTYPE = SnmpSMI.SMI_COUNTER32;
	
	/**
	 * Constructs the default counter object.
	 * The initial value is defined
	 * by the super class default constructor
	 */
	public SnmpCounter32( )
	{
		super();
	}
	/**
	 * Constructs the object with the specified
	 * value.
	 *
	 * @param value	The default value for the object.
	 */
	public SnmpCounter32(long value)
	{
		super(value);
	}

	/**
	 * Constructs the object with the specified value.
	 *
	 * @param value	The default value for the object.
	 *
	 */
	public SnmpCounter32(Long value)
	{
		super(value);
	}

	/**
	 * Constructs a new object with the same value
	 * as the passed object.
	 *
	 * @param second	The object to recover values from.
	 *
	 */
	public SnmpCounter32(SnmpCounter32 second)
	{
		super(second);
	}

	/**
	 * Constructs a new object with the value
	 * constained in the SnmpUInt32 object.
	 *
	 * @param uint32 The SnmpUInt32 object to copy.
	 *
	 */
	public SnmpCounter32(SnmpUInt32 uint32)
	{
		super(uint32);
	}

	/**
	 * Returns the ASN.1 type specific to this object.
	 *
	 * @return The ASN.1 value for this object.
	 */
	public byte typeId()
	{
		return ASNTYPE;
	}

	/**
	 * Creates a new object that is a duplicate of the
	 * current object.
	 *
	 * @return The newly created duplicate object.
	 *
	 */
	public SnmpSyntax duplicate() 
	{
		return new SnmpCounter32(this);
	}

	/**
	 * Creates a new object that is a duplicate of the
	 * current object.
	 *
	 * @return The newly created duplicate object.
	 *
	 */
	public Object clone()
	{
		return new SnmpCounter32(this);
	}

	/**
	 * Returns the string representation of the object.
	 *
	 */
	public String toString()
	{
		return "SNMP Counter32 [" + getValue() + "]";
	}
}

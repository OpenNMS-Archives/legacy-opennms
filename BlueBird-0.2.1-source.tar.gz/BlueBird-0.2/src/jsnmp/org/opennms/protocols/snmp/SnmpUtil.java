// 
//    JoeSNMP - SNMPv1 & v2 Compliant Libraries for Java
//    Copyright (C) 2000  PlatformWorks, Inc.
//
//    This library is free software; you can redistribute it and/or
//    modify it under the terms of the GNU Lesser General Public
//    License as published by the Free Software Foundation; either
//    version 2.1 of the License, or (at your option) any later version.
//
//    This library is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
//    Lesser General Public License for more details.
//
//    You should have received a copy of the GNU Lesser General Public
//    License along with this library; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//   
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
// $Id: SnmpUtil.java,v 1.10 2000/10/31 22:11:47 ben Exp $
//
//

package org.opennms.protocols.snmp;

import java.lang.*;
import java.io.PrintStream;
import java.util.ArrayList;

import org.opennms.protocols.snmp.SnmpSyntax;

/**
 * This class provides a set of utilities that may be used
 * by other package members. This class is not accessable
 * to non-package classes.
 *
 * The util class maintains a dynamically created list of
 * SnmpSyntax object that is uses to lookup received 
 * messages. The typeId() method of each SnmpSyntax object
 * provides the comparision data for the received ASN.1 type.
 *
 * @see SnmpInt32
 * @see SnmpCounter32
 * @see SnmpGauge32
 * @see SnmpTimeTicks
 * @see SnmpOctetString
 * @see SnmpIPAddress
 * @see SnmpObjectId
 * 
 * @author	<a href="mailto:weave@opennms.org>Brian Weaver</a>
 * @version	$Revision: 1.10 $
 */
class SnmpUtil extends Object
{
	/**
	 * The array of dynamically registred SnmpSyntax objects
	 *
	 */
	static ArrayList	m_syntaxArray = null;

	//
	// when the class is "created" and initiazlied
	// be sure to create an array to store the 
	// syntax object into.
	//
	static
	{
		m_syntaxArray = new ArrayList();
	}

	/**
	 * Used to register a SnmpSyntax object with the
	 * SnmpUtil class. Once registered it can be dynamically
	 * found based on it's typeId().
	 *
	 * @param obj The SnmpSyntax object to add
	 *
	 * @return True if the object is successfully added
	 *
	 */
	static boolean registerSyntax(SnmpSyntax obj)
	{
		boolean rc = false;
		synchronized(m_syntaxArray)
		{
			//
			// verify that the object is not in 
			// the list already
			//
			boolean addIt = true;
			for(int x = 0; x < m_syntaxArray.size(); x++)
			{
				SnmpSyntax tmp = (SnmpSyntax) m_syntaxArray.get(x);
				if(obj.typeId() == tmp.typeId())
				{
					addIt = false;
					break;
				}
			}
			if(addIt == true)
				rc = m_syntaxArray.add(obj);
		}
		return rc;
	}

	/**
	 * Used to dynamically lookup registered SnmpSyntax objects
	 *
	 * @param asnType The ASN.1 type to search for
	 *
	 * @return A new SnmpSyntax object of the appropiate type
	 *
	 */
	static SnmpSyntax getSyntaxObject(byte asnType)
	{
		SnmpSyntax obj = null;
		switch(asnType)
		{
		case SnmpInt32.ASNTYPE:
			obj = new SnmpInt32();
			break;
		
		case SnmpCounter32.ASNTYPE:
			obj = new SnmpCounter32();
			break;

		case SnmpGauge32.ASNTYPE:
			obj = new SnmpGauge32();
			break;
			
		case SnmpCounter64.ASNTYPE:
			obj = new SnmpCounter64();
			break;
		
		case SnmpTimeTicks.ASNTYPE:
			obj = new SnmpTimeTicks();
			break;

		case SnmpOctetString.ASNTYPE:
			obj = new SnmpOctetString();
			break;

		case SnmpOpaque.ASNTYPE:
			obj = new SnmpOpaque();
			break;

		case SnmpIPAddress.ASNTYPE:
			obj = new SnmpIPAddress();
			break;

		case SnmpObjectId.ASNTYPE:
			obj = new SnmpObjectId();
			break;

		case SnmpV2PartyClock.ASNTYPE:
			obj = new SnmpV2PartyClock();
			break;

		case SnmpNoSuchInstance.ASNTYPE:
			obj = new SnmpNoSuchInstance();
			break;

		case SnmpNoSuchObject.ASNTYPE:
			obj = new SnmpNoSuchObject();
			break;

		case SnmpEndOfMibView.ASNTYPE:
			obj = new SnmpEndOfMibView();
			break;

		case SnmpNull.ASNTYPE:
			obj = new SnmpNull();
			break;
		} // end case

		//
		// If the object is null then search
		// through user registered objects
		// see the SnmpSession.registerSyntaxObject 
		// method
		//
		if(obj == null)
		{
			synchronized(m_syntaxArray)
			{
				for(int x = m_syntaxArray.size()-1; x >= 0; --x)
				{
					SnmpSyntax o = (SnmpSyntax) m_syntaxArray.get(x);
					if(asnType == o.typeId())
					{
						obj = o.duplicate();
						break; // exit the loop
					}
				}
			}
		}
		return obj;
	}

	/**
	 * Used to copy data from one buffer to another. The method has the 
	 * flexability to allow the caller to specify an offset in each buffer
	 * and the total number of bytes to copy
	 *
	 * @param src		The source buffer
	 * @param srcOffset	The offset of the first byte in the source buffer
	 * @param dest		The destination buffer
	 * @param destOffset	The offset of the first byte in the destination buffer
	 * @param count		The number of elements to copy
	 *
	 */
	static void copy(byte[]	src,
			 int	srcOffset,
			 byte[]	dest,
			 int	destOffset,
			 int	count)
	{
		for(int x = 0; x < count; x++)
		{
			dest[destOffset + x] = src[srcOffset + x];
		}
	}

	/**
	 * Used to copy data from one buffer to another. The method has the 
	 * flexability to allow the caller to specify an offset in each buffer
	 * and the total number of bytes to copy
	 *
	 * @param src		The source buffer
	 * @param srcOffset	The offset of the first byte in the source buffer
	 * @param dest		The destination buffer
	 * @param destOffset	The offset of the first byte in the destination buffer
	 * @param count		The number of elements to copy
	 *
	 */
	static void copy(int[]	src,
			 int	srcOffset,
			 int[]	dest,
			 int	destOffset,
		         int	count)
	{
		for(int x = 0; x < count; x++)
		{
			dest[destOffset + x] = src[srcOffset + x];
		}
	}

	/**
	 * Rotates a give buffer area marked by begin, pivot, and end.
	 * The pivot marks the point where the bytes between [pivot..end)
	 * are moved to the position marked by begin. The bytes between
	 * [begin..pivot) are shifted such that begin is at [begin+(end-pivot)].
	 *
	 * @param buf	The buffer containing the data to rotate
	 * @param begin	The start of the rotation
	 * @param pivot	The pivot point for the rotation
	 * @param end	The end of the rotational buffer
	 *
	 */
	static void rotate(byte[]	buf,
			   int		begin,
			   int		pivot,
			   int		end)
	{
		int dist    = end - pivot;
		byte[] hold = new byte[dist];

		copy(buf,	// source
		     pivot,	// source offset
		     hold,	// destination
		     0,		// destination offset
		     dist);	// length

		//
		// shift from end of buffer to front. This 
		// way we do not have to worry about data 
		// corruption
		//
		for(int x = (pivot-begin)-1; x >= 0; x--)
		{
			buf[begin + dist + x]  = buf[begin + x]; // SHIFT!
		}

		copy(hold,	// source
		     0,		// source offset
		     buf,	// destination
		     begin,	// destination offset
		     dist);	// length
	}		

	/**
	 * Rotates a give buffer area marked by begin, pivot, and end.
	 * The pivot marks the point where the bytes between [pivot..end)
	 * are moved to the position marked by begin. The bytes between
	 * [begin..pivot) are shifted such that begin is at [begin+(end-pivot)].
	 *
	 * @param buf	The buffer containing the data to rotate
	 * @param begin	The start of the rotation
	 * @param pivot	The pivot point for the rotation
	 * @param end	The end of the rotational buffer
	 *
	 */
	static void rotate(int[]	buf,
			   int		begin,
			   int		pivot,
			   int		end)
	{
		int dist   = end - pivot;
		int[] hold = new int[dist];

		copy(buf,	// source
		     pivot,	// source offset
		     hold,	// destination
		     0,		// destination offset
		     dist);	// length

		//
		// shift from end of buffer to front. This 
		// way we do not have to worry about data 
		// corruption
		//
		for(int x = (pivot-begin)-1; x >= 0; x--)
		{
			buf[begin + dist + x]  = buf[begin + x]; // SHIFT!
		}

		copy(hold,	// source
		     0,		// source offset
		     buf,	// destination
		     begin,	// destination offset
		     dist);	// length
	}

	/**
	 * Dumps an array of byte to the output string
	 * as a sequence of hexadecimal digits.
	 *
	 * @param out	The output stream
	 * @param data	The data to dump
	 * @param offset The start location within the data
	 * @param length The length of data to dump
	 *
	 */
	static void dumpHex(PrintStream out, 
			    byte[]	data, 
			    int		offset, 
			    int		length)
	{
		if((offset + length) > data.length)
			return;

		while(length > 0)
		{
			byte b = data[offset];
			out.print("0x");
			out.print(Integer.toHexString((b >> 4) & 0xf));
			out.print(Integer.toHexString(b & 0xf));
			out.print(" ");
			--length;
			offset++;
		}
	}

		
}

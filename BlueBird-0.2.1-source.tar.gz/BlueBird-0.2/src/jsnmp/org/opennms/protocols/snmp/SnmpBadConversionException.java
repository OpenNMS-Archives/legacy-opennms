// 
//    JoeSNMP - SNMPv1 & v2 Compliant Libraries for Java
//    Copyright (C) 2000  PlatformWorks, Inc.
//
//    This library is free software; you can redistribute it and/or
//    modify it under the terms of the GNU Lesser General Public
//    License as published by the Free Software Foundation; either
//    version 2.1 of the License, or (at your option) any later version.
//
//    This library is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
//    Lesser General Public License for more details.
//
//    You should have received a copy of the GNU Lesser General Public
//    License along with this library; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//   
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//
//
// Tab Size = 8
//
// $Id: SnmpBadConversionException.java,v 1.7 2000/10/31 22:11:47 ben Exp $
//
package org.opennms.protocols.snmp;

import java.lang.Exception;

/**
 * Constructed when the library is unable to covert
 * a value to another. 
 *
 * @see SnmpIPAddress#convertToIpAddress()
 *
 * @version	$Revision: 1.7 $
 */
public class SnmpBadConversionException extends Exception
{
	/**
	 * The exception constructor
	 *
	 * @param why The reason the exception is being raised
	 *
	 */
	public SnmpBadConversionException(String why)
	{
		super(why);
	}

	/**
	 * The exception constructor
	 *
	 */
	public SnmpBadConversionException()
	{
		super();
	}
}

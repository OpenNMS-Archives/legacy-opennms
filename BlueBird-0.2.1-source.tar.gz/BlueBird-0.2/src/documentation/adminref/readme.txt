The admin ref guide consists of lots of XML which is rendered into various
stuff by FOP and XT.

Several XML files are built dynamically in the build file. The most
important one is the book.xml file. Do not manually change the book.xml
file or you will lose your changes when buid runs. Another file built
dynamically by the build scripts is the manual.fot file. This file is used
as input to the FOP process and is rebuilt every time a chapter changes,
however, it can be useful to look at the manual.fot to debug problems
with the style or FOP.  toc.xml is also built dynamically. It is used
to build the branching directory structure in the JAVA help app.

The figures used in the manual are kept in the ./figures directory.

The image files (logos, buttons etc) are kept in the ./images directory.

There are some flags for the xt usage which allows the formatter to
either build individual chapters or the entire manual. The flags
are  sep=yes|no (HR separators between chapters), internalanchor=yes|no
(link to the current html file rather than a separate chapter file,
toc=yes|no (generate a table of contents at the building of the file).
The build scripts set these three options to "yes".

To just build the documentation contained in this directory, from the
main source directory, run:

  build.bat doc.bluebird.admin (on Windows)
  -or-
  ./build.sh doc.bluebird.admin (on UNIX) 

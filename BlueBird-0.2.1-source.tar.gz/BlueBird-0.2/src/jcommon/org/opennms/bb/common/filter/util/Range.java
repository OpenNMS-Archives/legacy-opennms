//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.common.filter.util;

/**This is a data classed used for storing range information
   that is parsed from an octet in an ip string from the
   IPLIKE operation. A range consists of single integer or
   a max/min pair.

   @author <A HREF="mailto:jason@opennms.org">Jason Johns</A>
   @author <A HREF="http://www.opennms.org/">OpenNMS</A>
   @version $Revision: 1.2 $
 */
public class Range
{
    /**The maximum for the range
     */
    private Integer highNum;
    
    /**The minimum for the range
     */
    private Integer lowNum;

    /**Constructor to create a range knowing the max and 
       min values. A null high value indicates that this
       range should consist of just a single number, and the
       high value will be set equal to the low value. The 
       user is required to check this condition when getting
       and interpreting the range later.
       @param Integer low, the min value
       @param Integer high, the max value;
     */
    public Range(Integer low, Integer high)
    {
	lowNum = low;

	//in the case of a single number range the
	//high value may not be provided. The condition
	//high == low indicates a single value range.
	if (high == null)
	{
	    highNum = low;
	}
	else
	{
	    highNum = high;
	}
    }

    /**This method returns the low value range.
     */
    public int getLowNum()
    {
	return lowNum.intValue();
    }

    /**This method returns the high value range.
     */
    public int getHighNum()
    {
	return highNum.intValue();
    }
}

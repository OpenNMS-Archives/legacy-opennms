//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.common.filter.test;

import org.opennms.bb.common.filter.BBRulesParser;
import org.opennms.bb.common.filter.BBRulesLexer;
import org.opennms.bb.common.filter.sql.SQLConstruct;

import java_cup.runtime.Symbol;
import java.io.*;

public class RulesParserTest
{
	public RulesParserTest()
	{
	}
	
	public void test(String aRule)
	{
	    
	    StringReader reader = new StringReader(aRule);    

	    /* create a parsing object */
	    BBRulesParser parser = new BBRulesParser(new BBRulesLexer(reader));
	    
	    /* open input files, etc. here */
	    Symbol parse_tree = null;
	    
	    try 
	    {
		parse_tree = parser.parse();
		
		SQLConstruct sql = (SQLConstruct)parse_tree.value;
		
		System.out.println(aRule);
		System.out.println("");
		System.out.println(sql.toString());
		System.out.println("");
		System.out.println("");

		//System.out.println(aRule + " parsed successfully");
	    } 
	    catch (Exception e) 
	    {
		System.out.println(aRule + " didn't parse");
		System.out.println(e);
		e.printStackTrace();
	    } 
	}
	
	public static void main(String args[])
	{
		RulesParserTest parseTester = new RulesParserTest();
		
		FileReader reader = null;
		BufferedReader buffered;

		try
		{
		    reader = new FileReader("test/RulesTest.txt");
		    buffered = new BufferedReader(reader);
		    String inString;
		    
		    while((inString = buffered.readLine()) != null)
		    {
			parseTester.test(inString);
		    }
		    
		    reader.close();
		}
		catch (FileNotFoundException e)
		{
		    System.out.println(e);
		}
		catch (IOException e)
		{
		    System.out.println(e);
		}
	}
}

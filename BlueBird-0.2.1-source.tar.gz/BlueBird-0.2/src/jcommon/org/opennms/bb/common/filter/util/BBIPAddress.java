//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.common.filter.util;

import java.util.*;

import org.opennms.protocols.ip.IPv4Address;
import org.opennms.bb.common.filter.util.Range;

/**This class is responsible for parsing out an ip octet 
   string into ranges and comma lists.

   @author <A HREF="mailto:jason@opennms.org">Jason Johns</A>
   @author <A HREF="http://www.opennms.org/">OpenNMS</A>
   @version $Revision: 1.3 $
   
 */
public class BBIPAddress
{
    /**Array to of BBIPOctet objects to hold the octet data.
     */
    private BBIPOctet octets[];

    /**Constructor to build a BBIPAddress from an octet string mask
       from an IPLIKE operation.
       @param String ipLikeString, octet string from IPLIKE operation
     */
    public BBIPAddress(String ipLikeString)
    {
	String octetArray[] = parseOctets(ipLikeString);

	octets = new BBIPOctet[octetArray.length];
	
	for (int i = 0; i < octets.length; i++)
	{
	    octets[i] = new BBIPOctet(octetArray[i]);
       	}
    }

    /**This method parses the octetString into distinct octet
       pieces.
       @return String [], an array of all octets parsed out
       @param String octetString, original string from IPLIKE operation
     */
    public static String [] parseOctets(String octetString)
    {
	//break out into tokens where a dot separates octets
	StringTokenizer octetTokens = new StringTokenizer(octetString, ".");

	String octetArray[] = new String[octetTokens.countTokens()];

	//put each token into the array
	for (int i = 0; octetTokens.hasMoreTokens(); i++)
	{
	    octetArray[i] = octetTokens.nextToken();
	}

	return octetArray;
    }

    /**This method returns the number of octets parse from the
       original string.
       @return int, number of octets
     */
    public int numOctets()
    {
	return octets.length;
    }

    /**This method calls a method from BBIPOctet to get the
       number of ranges that occured in the octet.
       @return int, number of ranges in octet
       @param int octetIndex, the index of the octet in question
     */
    public int numOctetElements(int octetIndex)
    {
	return octets[octetIndex].numRanges();
    }

    /**This method returns a particular range in a particular
       octet.
       @return Range, a range object for the octet
       @param int octetIndex, the index of the octet in question
       @param int rangeIndex, the index of the range in question
     */
    public Range getOctetRange(int octetIndex, int rangeIndex)
    {
	return octets[octetIndex].getRange(rangeIndex);
    }

    /**This method returns the original octet string.
     */
    public String toString()
    {
	StringBuffer ipAddress = new StringBuffer(octets[0].toString());

	for (int i = 1; i < octets.length; i++)
	{
	    ipAddress.append(".").append(octets[i]);
	}

	return ipAddress.toString();
    }

    /**This method returns the octet string as an integer.
       Note that there can be no ranges present in  the octet
       string. This basically converts an string ip address
       to an integer.
       @return int, the integer representation of the ip address
       @param String octetString, the string representation of the ip address
     */
    public static int getIpAsInteger(String octetString)
    {
	IPv4Address address = new IPv4Address(octetString);
	
	return address.getAddress();
    }

    /**This method returns an integer ip address as an
       octet string.
       @return String, the string representation of the ip address
       @param int ipAddr, the integer representation of the ip address
     */
    public static String getIpAsOctetString(int ipAddr)
    {
	return IPv4Address.addressToString(ipAddr);
    }

    /**This method returns an integer ip address as an
       octet string.
       @return String, the string representation of the ip address
       @param Integer ipAddr, the integer representation of the ip address
    */
    public static String getIpAsOctetString(Integer ipAddr)
    {
	return getIpAsOctetString(ipAddr.intValue());
    }
}

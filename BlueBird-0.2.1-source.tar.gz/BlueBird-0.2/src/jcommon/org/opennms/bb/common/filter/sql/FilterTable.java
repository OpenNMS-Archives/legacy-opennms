//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.common.filter.sql;

import java.util.*;

import org.opennms.bb.common.filter.sql.JoinCondition;

/**This data class is responsible for holding information
   needed by the Fitler module about the tables that are 
   defined by the PollerDatabaseSchema.xml file. As that 
   file is parsed by the FilterSchemaParser object the
   information for each table will be stored in on of these
   class instances.

   @author <A HREF="mailto:jason@opennms.org">Jason Johns</A>
   @author <A HREF="http://www.opennms.org/">OpenNMS</A>
   @version $Revision: 1.6 $
 */
public class FilterTable
{
    /**Holds the table name.
     */
    private String tableName;
    
    /**Indicates if this table is to be used as the driver
       for determining the join conditions. This variable is
       set by determining if a table has a key="primary" attribute
       in the PollerDatabaseSchema.xml file.
    */
    private boolean driver;
    
    /**Data structure to hold the column names associated with
       this table.
     */
    private Hashtable columns;
    
    /**Data structure to hold the join conditions associated with
       this table.
     */
    private HashMap joinConditions;

    /**Defaut constructor, initializes data structures and
       sets driver to false as defaut.
    */
    public FilterTable()
    {
	driver = false;
	columns = new Hashtable();
	joinConditions = new HashMap();
    }

    /**Initializes a new FilterTable with the table name.
       @param String aTableName, name of the new table
     */
    public FilterTable(String aTableName)
    {
	this();
	
	tableName = aTableName;
    }

    /**This method adds a JoinCondition object to the joinConditions hashmap,
       keyed on the name of the foreign table (from a foreign key type relationship).
       @param JoinCondition aJoinCondition, new join condition to be added
    */
    public void addJoinCondition(JoinCondition aJoinCondition)
    {
	joinConditions.put(aJoinCondition.getForeignTableName(), aJoinCondition);
    }

    /**This method returns the list of join conditions for this table.
       @return HashMap, the map of all JoinCondition objects currently in this table
     */
    public HashMap getJoinConditions()
    {
	return joinConditions;
    }

    /**Returns the Join Condition object associated with the
       table name supplied.
       @param String aTableName, name of the table to get the join condition for
       @return JoinCondition, the particular JoinCondition object between the
               current table and the table name passed in
    */
    public JoinCondition getJoinConditions(String aTableName)
    {
	return (JoinCondition)joinConditions.get(aTableName);
    }

    /**This method sets the driver variable to true.
     */
    public void setDriver()
    {
	driver = true;
    }

    /**This method returns the value of the variable driver.
       @return boolean, indicating if this is the driver table
     */
    public boolean isDriver()
    {
	return driver;
    }

    /**This method adds a column name the hashmap. A null is inserted
       in place of an object (the null could be replaced by a data 
       structure if more information is needed about the column).
       @param String aColumn, the name of the new column to be added
    */
    public void addColumn(String aColumn)
    {
	columns.put(aColumn, aColumn);
    }

    /**This method returns a list of the column names belonging
       to this table.
       @return String [], an array of all the column names in this table
    */
    public String [] getColumnNames()
    {
	String columnNames [] = new String [columns.size()];

	//get an iterator over all of the keys, which are the column names
	Iterator i = columns.keySet().iterator();

	//loop over all keys and put each into the columnName array
	for (int j = 0; i.hasNext(); j++)
	{
	    columnNames[j] = (String)i.next();
	}

	return columnNames;
    }

    /**This method returns the hashtable of columns
       @return Hashtable, the hashtable of columns
    */
    public Hashtable getColumnsHash()
    {
	return columns;
    }

    /**This method returns the table name.
       @return String, the table name
     */
    public String getTableName()
    {
	return tableName;
    }

    /**This method returns a string representation of the table
       @return String, a string representation of this table
     */
    public String toString()
    {
	StringBuffer tableString = new StringBuffer("\r\n\tTable: " + tableName + "\r\n" +
						    "\tDriver: " + driver + "\r\n" +
						    "\tColumns: ");

	String columnNames[] = getColumnNames(); 

	for (int i = 0; i < columnNames.length; i++)
	{
	    tableString.append(columnNames[i] + ", ");
	}
	
	tableString.append("\r\n\tJoins: " + joinConditions + "\r\n");
	
	return tableString.toString();
    }
}

//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.common.filter.exceptions;

/**This exception is used to indicate that an expression
   rule contains an IP address that is out of range (ie. 
   at least one of the octets has a range outside of 0-255).

   @author <A HREF="mailto:jason@opennms.org">Jason Johns</A>
   @author <A HREF="http://www.opennms.org/">OpenNMS</A>
   @version $Revision: 1.1 $
*/
public class IPOutOfRangeException extends FailedParseException
{
    private String badRange;

    /**Default constructor, calls the Exception constructor.
       @param String detail, information of the exception being thrown
     */
    public IPOutOfRangeException(String detail)
    {
	super(detail);

	badRange = detail;
    }

    public String toString()
    {
	return "An octet of an IP address is outside the 0-255 bounds. Offending range = " + badRange;
    }
}

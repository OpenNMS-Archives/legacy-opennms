//
// Copyright (C) 2000 N*Manage Company, Inc.
//  
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
// 
// For more information contact: 
//	Brian Weaver	<weave@opennms.org>
//	http://www.opennms.org/
//

package org.opennms.bb.common.filter.util;

import java.util.*;

import org.opennms.bb.common.filter.util.Range;

/**This class is responsible for parsing an individual octet
   from an IPLIKE ip string. This octet can be a single number,
   a * (which gets transformed into the range 0-255), a range 
   consisting of a low value seperated from a high value with a dash, 
   or a combination of the above seperated by a comma (note: *
   will only ever appear by itself in a range).

   @author <A HREF="mailto:jason@opennms.org">Jason Johns</A>
   @author <A HREF="http://www.opennms.org/">OpenNMS</A>
   @version $Revision: 1.2 $
 */
public class BBIPOctet
{
    /**This vector will hold the list of ranges found in an octet.
     */
    private Vector ranges;

    /**This is the lowest value a member of a range octet can be.
     */
    private static final int LOW_VALUE = 0;
    
    /**This is the highest value a member of a range octet can be.
     */
    private static final int HIGH_VALUE = 255;

    /**A constructor that parses an octet into its individual ranges.
       @param String anOctet, the octet string to be parsed
     */
    public BBIPOctet(String anOctet)
    {
	ranges = new Vector();

	StringTokenizer rangeList = new StringTokenizer(anOctet, ",");

	while(rangeList.hasMoreTokens())
	{
	    parseRange(rangeList.nextToken());
	}
    }

    /**This method reconstructs a range into a string representation
       @return String, the ranges recombined into its original string
       @param int index, the index of the range to reconstruct
     */
    private String getRangeString(int index)
    {
	String rangeString = null;

	Range range = (Range)ranges.get(index);

	if(range.getHighNum() == range.getLowNum())
	{
	    //reconstruct the range as a single number
	    rangeString = range.getLowNum() + "";
	}
	else if (range.getLowNum() == LOW_VALUE && range.getHighNum() == HIGH_VALUE)
	{
	    //reconstruct the range as a *
	    rangeString = "*";
	}
	else
	{
	    //reconstruct the range with a low and high value
	    rangeString = range.getLowNum() + "-" + range.getHighNum();
	}

	return rangeString;
    }
    
    /**This method will parse an indiviual range (that was delimited by
       commas) and store it in the ranges vector.
       @param String rangeString, the range to be parsed
     */
    private void parseRange(String rangeString)
    {
	StringTokenizer range = new StringTokenizer(rangeString, "-");
	
	if (range.countTokens() > 1)
	{
	    ranges.add(new Range(new Integer(range.nextToken()), 
				 new Integer(range.nextToken())));
	}
	else
	{
	    if (rangeString.equals("*"))
	    {
		//break it up into the min-max range
		ranges.add(new Range(new Integer(LOW_VALUE), new Integer(HIGH_VALUE)));
	    }
	    else
	    {
		//create a range of a single number
		ranges.add(new Range(new Integer(rangeString), null));
	    }
	}
    }

    /**This method returns the number of ranges found in the octet
       @return int, the number of ranges in this octet
     */
    public int numRanges()
    {
	return ranges.size();
    }

    /**This method returns the Range object at a given index of
       an octet.
       @return Range, the Range objec for this index
       @int index, the index to return a Range for
     */
    public Range getRange(int index)
    {
	return (Range)ranges.get(index);
    }

    /**This method reconstructs a representation of the original
       octet with all ranges.
       @return String, the reconstructed octet
     */
    public String toString()
    {
	StringBuffer octet = new StringBuffer(getRangeString(0));

	for (int i = 1; i < ranges.size(); i++)
	{
	    octet.append(",").append(getRangeString(i));
	}

	return octet.toString();
    }
}



